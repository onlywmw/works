"""短信验证码通道模块：G1 个人认证前置（手机号 + 短信验证码）。

端点（由 register_sms_routes 挂到主 app，均走 main.py Bearer 中间件）：
- POST /v1/sms/send    手机号校验 + 频控 → 生成 6 位验证码存内存 → 触发发送器（当前 TODO 骨架）
- POST /v1/sms/verify  校验验证码（内存比对，5 次错 / 10min 过期）

关键取舍（用户拍板 2026-08-10）：
- **骨架预留**：短信发送器接口 `_send_code` 留 TODO（真实服务商 = 阿里云/腾讯云，待用户申请
  签名+模板后填 `.env` 的 SMS_* 配置即生效）。模板未就绪期，验证码只落服务端日志并回包返回，
  供 G1「本地声明」降级链路联调。
- **存储**：验证码存内存 dict（仿 pay.py 订单内存表，重启即丢）；手机号只落 SHA-256 哈希+时间，
  明文不出端（DESIGN_GIG_PLATFORM §七 红线）。
- **频控**：同一手机号 60s 内限 1 条，同一 IP 30s 内限 1 条（防轰炸）。
- 单测零网络：发送器/时钟/存储均可注入。

红线：不落明文手机号、不落验证码到磁盘、不出现验证码进审计日志。
"""
import hashlib
import hmac
import random
import re
import time

from fastapi import Request
from fastapi.responses import JSONResponse

# 中国大陆手机号：1 开头 11 位数字
_MOBILE_RE = re.compile(r"^1\d{10}$")
# 验证码 6 位数字
_CODE_RE = re.compile(r"^\d{6}$")
# 验证码有效期 600s（10 分钟）
_CODE_TTL = 600
# 单手机号验证码最多尝试 5 次，超限作废
_MAX_ATTEMPTS = 5
# 同一手机号发送间隔 60s（防轰炸）
_SEND_MOBILE_INTERVAL = 60
# 同一 IP 发送间隔 30s（防轰炸）
_SEND_IP_INTERVAL = 30


def _err(code: str, msg: str, status: int) -> JSONResponse:
    return JSONResponse({"error": {"code": code, "msg": msg}}, status_code=status)


def _mobile_hash(mobile: str) -> str:
    """手机号 SHA-256 哈希（仅用于审计落账，明文不出端）。"""
    return hashlib.sha256(mobile.encode("utf-8")).hexdigest()


def _send_code(mobile: str, code: str, mobile_hash: str) -> None:
    """发送短信验证码 —— **骨架预留**。

    真实服务商（阿里云/腾讯云）接入点。待用户申请短信签名+模板、填 .env 的
    SMS_ACCESS_KEY / SMS_SECRET_KEY / SMS_SIGN_NAME / SMS_TEMPLATE_ID 后，
    在此调用 SDK 发送 `code`。模板未就绪期，验证码落服务端日志供联调。

    TODO(短信服务商): 接入真实发送，删除下面两条日志。
    """
    # 落服务端日志仅用于开发联调；上线前必须删（验证码不进任何持久化面）
    import logging
    logging.getLogger("sms").info("SMS_DEV_CODE mobile=%s code=%s", mobile_hash, code)


def register_sms_routes(app, config, store: dict = None, clock=time.time):
    """把短信验证码端点挂到 app。

    store 为验证码内存表（None 则新建）；clock 注入便于零网络/时间可控单测。
    条目结构：{code, expires_at, attempts, sent_at, sent_ip}
    last_ip 为独立 IP 频控表（跨手机号防轰炸）：{ip: last_sent_at}
    """
    store = store if store is not None else {}
    last_ip = {}

    @app.post("/v1/sms/send")
    async def sms_send(request: Request):
        try:
            body = await request.json()
        except Exception:
            return _err("INVALID_BODY", "请求体须为 JSON", 400)
        body = body if isinstance(body, dict) else {}
        mobile = str(body.get("mobile") or "").strip()
        if not _MOBILE_RE.match(mobile):
            return _err("INVALID_MOBILE", "手机号须为 1 开头 11 位数字", 400)

        now = clock()
        client_ip = request.client.host if request.client else ""

        # 频控：同一手机号 60s 内限 1 条
        rec = store.get(mobile)
        if rec and now < rec.get("sent_at", 0) + _SEND_MOBILE_INTERVAL:
            remain = int(rec["sent_at"] + _SEND_MOBILE_INTERVAL - now)
            return _err("RATE_LIMITED", f"发送太频繁，请 {remain}s 后再试", 429)
        # 频控：同一 IP 30s 内限 1 条（独立表，跨手机号防轰炸）
        if client_ip:
            last_sent = last_ip.get(client_ip, 0)
            if now < last_sent + _SEND_IP_INTERVAL:
                remain = int(last_sent + _SEND_IP_INTERVAL - now)
                return _err("RATE_LIMITED", f"发送太频繁，请 {remain}s 后再试", 429)

        code = f"{random.randint(0, 999999):06d}"
        store[mobile] = {
            "code": code,
            "expires_at": now + _CODE_TTL,
            "attempts": 0,
            "sent_at": now,
            "sent_ip": client_ip,
        }
        if client_ip:
            last_ip[client_ip] = now
        mobile_hash = _mobile_hash(mobile)
        _send_code(mobile, code, mobile_hash)
        # 审计只落哈希+动作，不落手机号明文、不落验证码
        if hasattr(config, "audit_path") and config.audit_path:
            import json
            rec_audit = {"ts": int(now), "action": "sms.send", "mobile_hash": mobile_hash}
            try:
                with open(config.audit_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(rec_audit, ensure_ascii=False) + "\n")
            except OSError:
                pass
        return {"ok": True, "data": {"mobile_hash": mobile_hash}}

    @app.post("/v1/sms/verify")
    async def sms_verify(request: Request):
        try:
            body = await request.json()
        except Exception:
            return _err("INVALID_BODY", "请求体须为 JSON", 400)
        body = body if isinstance(body, dict) else {}
        mobile = str(body.get("mobile") or "").strip()
        code = str(body.get("code") or "").strip()
        if not _MOBILE_RE.match(mobile):
            return _err("INVALID_MOBILE", "手机号须为 1 开头 11 位数字", 400)
        if not _CODE_RE.match(code):
            return _err("INVALID_CODE", "验证码须为 6 位数字", 400)

        rec = store.get(mobile)
        if not rec:
            return _err("CODE_NOT_SENT", "请先获取验证码", 400)
        if clock() >= rec["expires_at"]:
            store.pop(mobile, None)
            return _err("CODE_EXPIRED", "验证码已过期，请重新获取", 400)
        if rec["attempts"] >= _MAX_ATTEMPTS:
            store.pop(mobile, None)
            return _err("CODE_TOO_MANY", "尝试次数过多，验证码已作废，请重新获取", 429)
        if not hmac.compare_digest(rec["code"], code):
            rec["attempts"] += 1
            remain = _MAX_ATTEMPTS - rec["attempts"]
            return _err("CODE_MISMATCH", f"验证码错误，剩余 {remain} 次机会", 400)

        store.pop(mobile, None)  # 校验成功即销毁，防重放
        # 校验成功只回执，认证档案由端侧以「手机号哈希+时间」落 journal（明文不出端）
        return {"ok": True, "data": {"verified": True, "mobile_hash": _mobile_hash(mobile)}}
