"""JSAPI 支付页模块：微信公众号内 JSAPI 支付。

端点（由 register_pay_routes 挂到主 app）：
- POST /v1/pay/create        Bearer 鉴权；登记订单，返回支付页 URL
- GET  /pay/{oid}            免鉴权；302 跳网页授权（snsapi_base）
- GET  /pay/{oid}/cb         免鉴权；code 换 openid → JSAPI 下单 → 渲染支付页
- GET  /v1/pay/{oid}/status  Bearer 鉴权；转发微信按商户订单号查单（MOV 轮询备用）

关键取舍：
- 订单存内存 dict，重启即丢（重新 create 即可，可接受）。
- 同一 out_trade_no 重复 create 返回 409 ORDER_EXISTS，不覆盖（防止已发出的支付链接被改价）。
"""
import hashlib
import html
import re
import time
import uuid
from urllib.parse import quote

import httpx
from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from .wxpay import WxPayError, sign

# out_trade_no 规则：6-64 位字母/数字/下划线
_OID_RE = re.compile(r"^[A-Za-z0-9_]{6,64}$")
# 公众号 token/ticket 有效期 7200s，缓存提前 300s 过期留余量
_CACHE_ADVANCE_EXPIRE = 300


class MpApiError(Exception):
    """公众号接口（token/ticket/网页授权）调用失败。"""


def _default_http_get(url: str) -> dict:
    """默认 HTTP 层：GET 并解析 JSON。测试注入假实现实现零网络。"""
    return httpx.get(url, timeout=15).json()


class MpCredentialCache:
    """公众号 access_token / jsapi_ticket 内存缓存（7200s，提前 300s 过期）。

    http_get / clock 均可注入，单测零网络、时间可控。
    """

    def __init__(self, appid: str, appsecret: str, http_get=None, clock=time.time):
        self.appid = appid
        self.appsecret = appsecret
        self._http_get = http_get or _default_http_get
        self._clock = clock
        self._token = None          # access_token 缓存值
        self._token_expires_at = 0  # access_token 缓存过期时刻
        self._ticket = None         # jsapi_ticket 缓存值
        self._ticket_expires_at = 0

    def _get(self, url: str) -> dict:
        """GET 公众号接口并统一处理 errcode。"""
        try:
            data = self._http_get(url)
        except MpApiError:
            raise
        except Exception as e:
            raise MpApiError(f"公众号接口请求失败：{e}")
        errcode = data.get("errcode", 0)
        if errcode:
            raise MpApiError(f"公众号接口错误 {errcode}：{data.get('errmsg', '')}")
        return data

    def get_access_token(self) -> str:
        """取（或复用缓存的）公众号 access_token。"""
        now = self._clock()
        if self._token and now < self._token_expires_at:
            return self._token
        data = self._get(
            "https://api.weixin.qq.com/cgi-bin/token"
            f"?grant_type=client_credential&appid={self.appid}&secret={self.appsecret}")
        self._token = data["access_token"]
        self._token_expires_at = now + int(data.get("expires_in", 7200)) - _CACHE_ADVANCE_EXPIRE
        return self._token

    def get_jsapi_ticket(self) -> str:
        """取（或复用缓存的）jsapi_ticket。"""
        now = self._clock()
        if self._ticket and now < self._ticket_expires_at:
            return self._ticket
        token = self.get_access_token()
        data = self._get(
            "https://api.weixin.qq.com/cgi-bin/ticket/getticket"
            f"?access_token={token}&type=jsapi")
        self._ticket = data["ticket"]
        self._ticket_expires_at = now + int(data.get("expires_in", 7200)) - _CACHE_ADVANCE_EXPIRE
        return self._ticket


def jsapi_config_signature(ticket: str, nonce: str, timestamp: str, url: str) -> str:
    """JS-SDK wx.config 签名：SHA1(jsapi_ticket=..&noncestr=..&timestamp=..&url=..)，hex。"""
    raw = f"jsapi_ticket={ticket}&noncestr={nonce}&timestamp={timestamp}&url={url}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()


def build_pay_sign(private_key, appid: str, timestamp: str, nonce: str, package: str) -> str:
    """chooseWXPay 二次签名：RSA-SHA256 签 appId\\ntimeStamp\\nnonceStr\\npackage\\n，base64。"""
    message = f"{appid}\n{timestamp}\n{nonce}\n{package}\n"
    return sign(private_key, message)


def _err(code: str, msg: str, status: int) -> JSONResponse:
    return JSONResponse({"error": {"code": code, "msg": msg}}, status_code=status)


def _error_page(msg: str) -> str:
    """人话错误页（订单失效 / 授权失败 / 下单失败等）。"""
    return (
        "<!DOCTYPE html><html lang='zh-CN'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        "<title>支付</title></head>"
        "<body style='font-family:sans-serif;text-align:center;padding-top:4em'>"
        f"<p>{html.escape(msg)}</p></body></html>"
    )


# 支付页模板：加载完 wx.ready 自动调起 chooseWXPay；{{}} 是 JS 大括号转义
_PAGE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>收银台</title>
<script src="https://res.wx.qq.com/open/js/jweixin-1.3.2.js"></script>
<style>
body{{font-family:sans-serif;background:#f6f6f6;margin:0;display:flex;justify-content:center}}
.card{{background:#fff;margin-top:3em;padding:2em;border-radius:12px;text-align:center;min-width:16em}}
.amount{{font-size:2.2em;font-weight:bold}}
.desc{{color:#666;margin-top:.5em}}
.status{{margin-top:1.5em;color:#07c160}}
</style>
</head>
<body>
<div class="card">
  <div class="amount">&yen;{yuan}</div>
  <div class="desc">{description}</div>
  <div id="status" class="status">调起支付中…</div>
</div>
<script>
var statusEl = document.getElementById('status');
wx.config({{debug:false,appId:'{appid}',timestamp:{ts},nonceStr:'{config_nonce}',signature:'{config_sig}',jsApiList:['chooseWXPay']}});
wx.ready(function(){{
  wx.chooseWXPay({{
    appId:'{appid}',
    timeStamp:'{ts}',
    nonceStr:'{pay_nonce}',
    package:'{package}',
    signType:'RSA',
    paySign:'{pay_sign}',
    success:function(){{statusEl.textContent='支付成功，可关闭本页';}},
    fail:function(){{statusEl.textContent='支付失败，请刷新重试';}},
    cancel:function(){{statusEl.textContent='已取消支付';}}
  }});
}});
wx.error(function(){{statusEl.textContent='页面初始化失败，请刷新重试';}});
</script>
</body>
</html>"""


def register_pay_routes(app, config, get_client, store: dict = None, http_get=None, clock=time.time):
    """把 JSAPI 支付页相关端点挂到 app。

    store 为订单内存表（None 则新建）；http_get/clock 注入便于零网络单测。
    """
    store = store if store is not None else {}
    mp = MpCredentialCache(config.mp_appid, config.mp_appsecret, http_get=http_get, clock=clock)
    http_get = http_get or _default_http_get
    base = config.pay_public_base

    @app.post("/v1/pay/create")
    async def pay_create(request: Request):
        try:
            body = await request.json()
        except Exception:
            return _err("INVALID_BODY", "请求体须为 JSON", 400)
        body = body if isinstance(body, dict) else {}
        oid = body.get("out_trade_no")
        fen = body.get("fen")
        description = str(body.get("description") or "").strip()
        if not isinstance(oid, str) or not _OID_RE.match(oid):
            return _err("INVALID_OUT_TRADE_NO", "out_trade_no 必填，且须为 6-64 位字母/数字/下划线", 400)
        # 注意 bool 是 int 子类，须排除
        if not isinstance(fen, int) or isinstance(fen, bool) or fen <= 0:
            return _err("INVALID_FEN", "fen 须为正整数（单位：分）", 400)
        if oid in store:
            # 幂等取舍：同 oid 重复 create 一律 409，不覆盖
            return _err("ORDER_EXISTS", "相同 out_trade_no 的订单已存在", 409)
        store[oid] = {"description": description or "MOV 订单", "fen": fen}
        return {"pay_url": f"{base}/pay/{oid}"}

    @app.get("/pay/{oid}")
    async def pay_entry(oid: str):
        if oid not in store:
            return HTMLResponse(_error_page("订单不存在或已失效，请重新获取支付链接"), status_code=404)
        redirect_uri = quote(f"{base}/pay/{oid}/cb", safe="")
        url = (
            "https://open.weixin.qq.com/connect/oauth2/authorize"
            f"?appid={config.mp_appid}&redirect_uri={redirect_uri}"
            f"&response_type=code&scope=snsapi_base&state={oid}#wechat_redirect"
        )
        return RedirectResponse(url, status_code=302)

    @app.get("/pay/{oid}/cb")
    async def pay_callback(request: Request, oid: str, code: str = ""):
        order = store.get(oid)
        if order is None:
            return HTMLResponse(_error_page("订单不存在或已失效，请重新获取支付链接"), status_code=404)
        if not code:
            return HTMLResponse(_error_page("缺少授权 code，请重新打开支付链接"), status_code=400)

        # a. 网页授权 code 换 openid（snsapi_base）
        try:
            data = http_get(
                "https://api.weixin.qq.com/sns/oauth2/access_token"
                f"?appid={config.mp_appid}&secret={config.mp_appsecret}"
                f"&code={code}&grant_type=authorization_code")
        except Exception as e:
            return HTMLResponse(_error_page(f"微信授权失败：{e}"), status_code=502)
        openid = data.get("openid")
        if not openid:
            return HTMLResponse(_error_page(f"微信授权失败：{data.get('errmsg') or data}"), status_code=502)

        # b. JSAPI 下单 → prepay_id
        client = get_client()
        payload = {
            "mchid": config.mchid,
            "appid": config.mp_appid,
            "description": order["description"],
            "out_trade_no": oid,
            "notify_url": f"{base}/wxpay/notify",
            "amount": {"total": order["fen"], "currency": "CNY"},
            "payer": {"openid": openid},
        }
        try:
            prepay_id = client.create_jsapi_transaction(payload)["prepay_id"]
        except WxPayError as e:
            return HTMLResponse(_error_page(f"下单失败：{e.message}"), status_code=502)
        except (KeyError, TypeError):
            return HTMLResponse(_error_page("下单失败：微信未返回 prepay_id"), status_code=502)

        # c. 两套签名（wx.config 用 SHA1，chooseWXPay 用 RSA-SHA256）并渲染支付页
        try:
            ticket = mp.get_jsapi_ticket()
        except MpApiError as e:
            return HTMLResponse(_error_page(str(e)), status_code=502)
        ts = str(int(clock()))
        config_nonce = uuid.uuid4().hex
        pay_nonce = uuid.uuid4().hex
        page_url = str(request.url)  # 当前页完整 URL（不含 #），JS-SDK 签名必须含 query
        config_sig = jsapi_config_signature(ticket, config_nonce, ts, page_url)
        package = f"prepay_id={prepay_id}"
        pay_sign = build_pay_sign(client.private_key, config.mp_appid, ts, pay_nonce, package)

        return HTMLResponse(_PAGE.format(
            yuan=f"{order['fen'] / 100:.2f}",
            description=html.escape(order["description"]),
            appid=config.mp_appid,
            ts=ts,
            config_nonce=config_nonce,
            config_sig=config_sig,
            pay_nonce=pay_nonce,
            package=package,
            pay_sign=pay_sign,
        ))

    @app.get("/v1/pay/{oid}/status")
    async def pay_status(oid: str):
        try:
            return get_client().query_transaction_by_out_trade_no(oid)  # 微信结果原样透传
        except WxPayError as e:
            return _err(e.code, e.message, 502)
