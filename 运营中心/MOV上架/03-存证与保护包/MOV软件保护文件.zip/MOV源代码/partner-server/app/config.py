"""服务配置：全部从环境变量读取，敏感配置不进 git。

未配置 AUTH_TOKEN 时服务 fail-closed（所有业务端点 401），见 main.py 鉴权中间件。
"""
import os
from dataclasses import dataclass


@dataclass
class Config:
    mchid: str                    # 服务商商户号
    private_key_path: str         # 服务商 APIv3 私钥（apiclient_key.pem）路径
    cert_serial_no: str           # 服务商 API 证书序列号
    apiv3_key: str                # APIv3 密钥（本服务暂只用于回调解密，预留）
    wxpay_public_key_id: str      # 微信支付公钥 ID（PUB_KEY_ID_...）
    wxpay_public_key_path: str    # 微信支付公钥（pub_key.pem）路径
    auth_token: str               # MOV 端共享 Bearer token；空 = fail-closed
    port: int                     # 监听端口，默认 8390
    audit_path: str               # 审计 JSONL 文件路径
    mp_appid: str = "wxb73491c14b5470e3"   # 公众号 appid（JSAPI 支付页用）
    mp_appsecret: str = ""        # 公众号 appsecret（网页授权换 openid / 取 ticket 用，部署时补）
    pay_public_base: str = "https://mow.kim"  # 支付页对外基础 URL（不含尾斜杠）


def load_config() -> Config:
    """从环境变量加载配置。"""
    return Config(
        mchid=os.environ.get("MCHID", ""),
        private_key_path=os.environ.get("PRIVATE_KEY_PATH", ""),
        cert_serial_no=os.environ.get("CERT_SERIAL_NO", ""),
        apiv3_key=os.environ.get("APIV3_KEY", ""),
        wxpay_public_key_id=os.environ.get("WXPAY_PUBLIC_KEY_ID", ""),
        wxpay_public_key_path=os.environ.get("WXPAY_PUBLIC_KEY_PATH", ""),
        auth_token=os.environ.get("AUTH_TOKEN", ""),
        port=int(os.environ.get("PORT", "8390")),
        audit_path=os.environ.get("AUDIT_PATH", "applyment_audit.jsonl"),
        mp_appid=os.environ.get("MP_APPID", "wxb73491c14b5470e3"),
        mp_appsecret=os.environ.get("MP_APPSECRET", ""),  # 敏感，仅部署环境注入
        pay_public_base=os.environ.get("PAY_PUBLIC_BASE", "https://mow.kim").rstrip("/"),
    )
