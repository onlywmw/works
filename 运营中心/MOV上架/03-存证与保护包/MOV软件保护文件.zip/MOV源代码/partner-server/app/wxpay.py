"""微信支付 APIv3 客户端封装。

- SHA256withRSA 签名（五段签名串）
- 敏感字段用「微信支付公钥」RSA-OAEP(SHA-1) 加密
- HTTP 层可注入（默认 httpx.Client），单测用 MockTransport 零网络
"""
import base64
import hashlib
import json
import time
import uuid

import httpx
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

BASE_URL = "https://api.mch.weixin.qq.com"

# OAEP 填充按微信支付规范固定使用 SHA-1
_OAEP = padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA1()), algorithm=hashes.SHA1(), label=None)


class WxPayError(Exception):
    """微信侧返回的业务错误（HTTP >= 400）。"""

    def __init__(self, code: str, message: str, status: int):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message
        self.status = status


def build_message(method: str, url_path: str, timestamp: str, nonce: str, body: str) -> str:
    """拼五段签名串：method / url / timestamp / nonce / body，行尾各带 \\n。"""
    return f"{method}\n{url_path}\n{timestamp}\n{nonce}\n{body}\n"


def sign(private_key, message: str) -> str:
    """SHA256withRSA 签名，返回 base64。"""
    signature = private_key.sign(message.encode("utf-8"), padding.PKCS1v15(), hashes.SHA256())
    return base64.b64encode(signature).decode("ascii")


def build_auth_header(mchid: str, serial_no: str, nonce: str, timestamp: str, signature: str) -> str:
    """拼 WECHATPAY2-SHA256-RSA2048 授权头。"""
    return (
        f'WECHATPAY2-SHA256-RSA2048 mchid="{mchid}",nonce_str="{nonce}",'
        f'signature="{signature}",timestamp="{timestamp}",serial_no="{serial_no}"'
    )


def encrypt_sensitive(public_key, text: str) -> str:
    """用微信支付公钥 RSA-OAEP 加密敏感字段，返回 base64 密文。"""
    ciphertext = public_key.encrypt(str(text).encode("utf-8"), _OAEP)
    return base64.b64encode(ciphertext).decode("ascii")


def load_private_key(path: str):
    with open(path, "rb") as f:
        return serialization.load_pem_private_key(f.read(), password=None)


def load_public_key(path: str):
    with open(path, "rb") as f:
        return serialization.load_pem_public_key(f.read())


class WechatPayClient:
    """微信 APIv3 客户端。http_client 可注入（需有 .request(method, url, ...) 接口）。"""

    def __init__(self, config, http_client=None):
        self.config = config
        self.private_key = load_private_key(config.private_key_path)
        self.http = http_client or httpx.Client(base_url=BASE_URL, timeout=30)

    def _request(self, method: str, url_path: str, body: str = "", headers_extra: dict = None, **kwargs):
        """签名并发起请求；HTTP >= 400 抛 WxPayError，否则返回解析后的 JSON。"""
        timestamp = str(int(time.time()))
        nonce = uuid.uuid4().hex
        message = build_message(method, url_path, timestamp, nonce, body)
        headers = {
            "Authorization": build_auth_header(
                self.config.mchid, self.config.cert_serial_no,
                nonce, timestamp, sign(self.private_key, message),
            ),
            "Accept": "application/json",
        }
        if headers_extra:
            headers.update(headers_extra)
        resp = self.http.request(method, BASE_URL + url_path, headers=headers, **kwargs)
        if resp.status_code >= 400:
            try:
                err = resp.json()
            except Exception:
                err = {}
            raise WxPayError(err.get("code", "UNKNOWN"), err.get("message", resp.text), resp.status_code)
        return resp.json() if resp.content else {}

    def submit_applyment(self, applyment: dict) -> dict:
        """提交申请单 POST /v3/applyment4sub/applyment/。

        applyment 须已完成敏感字段加密。返回 {"applyment_id": ...}。
        """
        body = json.dumps(applyment, ensure_ascii=False)
        return self._request(
            "POST", "/v3/applyment4sub/applyment/",
            body=body, content=body.encode("utf-8"),
            headers_extra={"Content-Type": "application/json",
                           "Wechatpay-Serial": self.config.wxpay_public_key_id},
        )

    def query_applyment(self, business_code: str) -> dict:
        """查询申请单状态 GET /v3/applyment4sub/applyment/business-code/{code}。"""
        return self._request("GET", f"/v3/applyment4sub/applyment/business-code/{business_code}")

    def upload_media(self, filename: str, content: bytes) -> dict:
        """图片上传 POST /v3/merchant/media/upload（multipart），返回 {"media_id": ...}。

        签名串 body 用 meta 的 JSON 串（微信规范）。
        """
        meta = {"filename": filename, "sha256": hashlib.sha256(content).hexdigest()}
        meta_json = json.dumps(meta, ensure_ascii=False)
        files = {
            "meta": (None, meta_json, "application/json"),
            "file": (filename, content, "application/octet-stream"),
        }
        return self._request("POST", "/v3/merchant/media/upload", body=meta_json, files=files)

    def create_jsapi_transaction(self, payload: dict) -> dict:
        """JSAPI 下单 POST /v3/pay/transactions/jsapi，返回 {"prepay_id": ...}。"""
        body = json.dumps(payload, ensure_ascii=False)
        return self._request(
            "POST", "/v3/pay/transactions/jsapi",
            body=body, content=body.encode("utf-8"),
            headers_extra={"Content-Type": "application/json"},
        )

    def query_transaction_by_out_trade_no(self, out_trade_no: str) -> dict:
        """按商户订单号查单 GET /v3/pay/transactions/out-trade-no/{oid}?mchid=。"""
        return self._request(
            "GET", f"/v3/pay/transactions/out-trade-no/{out_trade_no}?mchid={self.config.mchid}")
