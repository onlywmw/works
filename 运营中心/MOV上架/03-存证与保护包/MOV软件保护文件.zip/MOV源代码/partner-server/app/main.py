"""FastAPI 服务入口：微信支付服务商特约商户进件后端。

端点：
- GET  /healthz                       免鉴权
- POST /v1/applyment                  敏感字段公钥加密后转发微信提交申请单
- GET  /v1/applyment/{business_code}  查询申请单状态
- POST /v1/media                      图片上传（multipart → media_id）
- POST /v1/pay/create                 登记 JSAPI 支付订单，返回支付页 URL
- GET  /pay/{oid}                     免鉴权；302 跳网页授权（snsapi_base）
- GET  /pay/{oid}/cb                  免鉴权；code 换 openid → JSAPI 下单 → 支付页
- GET  /v1/pay/{oid}/status           按商户订单号查单（MOV 轮询备用）

鉴权：Bearer token（healthz 与 /pay/* 支付页除外），未配置 AUTH_TOKEN 时 fail-closed。
审计：applyment_audit.jsonl 只落时间/动作/business_code/结果码，不落敏感明文。
"""
import copy
import hmac
import json
import time
from datetime import datetime, timezone

from fastapi import FastAPI, Request, UploadFile
from fastapi.responses import JSONResponse

from .config import Config, load_config
from .pay import register_pay_routes
from .sms import register_sms_routes
from .wxpay import WechatPayClient, WxPayError, encrypt_sensitive, load_public_key

# 微信错误码 → 本服务 HTTP 状态映射
_ERROR_STATUS = {
    "PROCESSING": 409,
    "PARAM_ERROR": 400,
    "NO_AUTH": 403,
    "RATE_LIMITED": 429,
}

# contact_info / bank_account_info 的精确敏感键
_CONTACT_KEYS = ("contact_name", "contact_id_number", "mobile_phone", "contact_email")
_BANK_KEYS = ("account_name", "account_number")
# 证件类信息按后缀匹配
_CERT_SUFFIXES = ("_name", "_number", "_address")


def _encrypt_keys(d: dict, public_key, predicate) -> None:
    """就地加密 dict 中 predicate 命中的键（空值不处理）。"""
    for key, value in list(d.items()):
        if isinstance(value, str) and value and predicate(key):
            d[key] = encrypt_sensitive(public_key, value)


def encrypt_applyment(applyment: dict, public_key) -> dict:
    """返回敏感字段已用微信支付公钥加密的申请单副本（不改入参）。"""
    data = copy.deepcopy(applyment)

    contact = data.get("contact_info") or {}
    _encrypt_keys(contact, public_key, lambda k: k in _CONTACT_KEYS)

    identity = (data.get("subject_info") or {}).get("identity_info") or {}
    for block_key in ("id_card_info", "id_doc_info"):
        block = identity.get(block_key) or {}
        _encrypt_keys(block, public_key, lambda k: k.endswith(_CERT_SUFFIXES))
    for ubo in identity.get("ubo_info_list") or []:
        _encrypt_keys(ubo, public_key, lambda k: k.endswith(_CERT_SUFFIXES))

    bank = data.get("bank_account_info") or {}
    _encrypt_keys(bank, public_key, lambda k: k in _BANK_KEYS)

    return data


def create_app(config: Config = None, wx_client=None, pay_http_get=None,
               sms_store=None, sms_clock=None) -> FastAPI:
    """应用工厂；wx_client / pay_http_get / sms_store / sms_clock 可注入 mock 实现零网络单测。"""
    config = config or load_config()
    app = FastAPI(title="partner-server")
    _lazy = {"client": wx_client}  # 默认客户端惰性构造，避免无配置时 import 即崩

    def get_client() -> WechatPayClient:
        if _lazy["client"] is None:
            _lazy["client"] = WechatPayClient(config)
        return _lazy["client"]

    # 挂载 JSAPI 支付页端点（/v1/pay/* 与免鉴权的 /pay/*）
    register_pay_routes(app, config, get_client, http_get=pay_http_get)
    # 挂载短信验证码端点（/v1/sms/*，Bearer 鉴权）
    register_sms_routes(app, config, store=sms_store, clock=sms_clock or time.time)

    def audit(action: str, business_code: str, result_code: str) -> None:
        """append-only 审计：只落元信息，不落 body。"""
        record = {
            "time": datetime.now(timezone.utc).isoformat(),
            "action": action,
            "business_code": business_code,
            "result_code": result_code,
        }
        with open(config.audit_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    @app.middleware("http")
    async def bearer_auth(request: Request, call_next):
        # healthz 与 /pay/* 支付页免鉴权；其余端点校验 Bearer token，未配置 token 一律 401
        if request.url.path == "/healthz" or request.url.path.startswith("/pay/"):
            return await call_next(request)
        token = request.headers.get("Authorization", "")
        expected = f"Bearer {config.auth_token}" if config.auth_token else ""
        if not expected or not hmac.compare_digest(token, expected):
            return JSONResponse({"error": {"code": "UNAUTHORIZED", "msg": "invalid or missing token"}}, status_code=401)
        return await call_next(request)

    @app.get("/healthz")
    async def healthz():
        return {"status": "ok"}

    @app.post("/v1/applyment")
    async def submit_applyment(request: Request):
        applyment = await request.json()
        business_code = applyment.get("business_code", "")
        client = get_client()
        public_key = load_public_key(config.wxpay_public_key_path)
        try:
            result = client.submit_applyment(encrypt_applyment(applyment, public_key))
        except WxPayError as e:
            audit("submit_applyment", business_code, e.code)
            return JSONResponse({"error": {"code": e.code, "msg": e.message}},
                                status_code=_ERROR_STATUS.get(e.code, 502))
        audit("submit_applyment", business_code, "OK")
        return {"applyment_id": result.get("applyment_id")}

    @app.get("/v1/applyment/{business_code}")
    async def query_applyment(business_code: str):
        try:
            result = get_client().query_applyment(business_code)
        except WxPayError as e:
            audit("query_applyment", business_code, e.code)
            return JSONResponse({"error": {"code": e.code, "msg": e.message}},
                                status_code=_ERROR_STATUS.get(e.code, 502))
        audit("query_applyment", business_code, "OK")
        return result  # 微信结果原样透传

    @app.post("/v1/media")
    async def upload_media(file: UploadFile):
        content = await file.read()
        try:
            result = get_client().upload_media(file.filename or "image.jpg", content)
        except WxPayError as e:
            return JSONResponse({"error": {"code": e.code, "msg": e.message}},
                                status_code=_ERROR_STATUS.get(e.code, 502))
        return {"media_id": result.get("media_id")}

    return app


app = create_app()
