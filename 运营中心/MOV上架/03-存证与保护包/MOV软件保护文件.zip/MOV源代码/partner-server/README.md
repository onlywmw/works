# partner-server —— 微信支付服务商特约商户进件后端

独立 Python FastAPI 服务。MOV（Android 端）收集进件资料后经 HTTPS + Bearer token 调本服务，
本服务持服务商 API 私钥调微信支付 APIv3；私钥不出服务端。

## 端点

| 端点 | 说明 |
|---|---|
| `GET /healthz` | 免鉴权健康检查 |
| `POST /v1/applyment` | 提交申请单。敏感字段（联系人姓名/证件号/手机/邮箱、证件姓名/号码/地址含 UBO、银行户名/账号）在服务端用「微信支付公钥」RSA-OAEP 加密后转发微信，返回 `{"applyment_id"}` |
| `GET /v1/applyment/{business_code}` | 查询申请单状态，微信结果原样透传 |
| `POST /v1/media` | multipart 图片上传 → `{"media_id"}` |
| `POST /v1/pay/create` | 登记 JSAPI 支付订单 `{out_trade_no, description, fen}`（分），返回 `{"pay_url": "https://mow.kim/pay/{out_trade_no}"}`；同 oid 重复 create 返回 409 |
| `GET /pay/{oid}` | **免鉴权**。302 跳微信网页授权（snsapi_base）；oid 不存在 → 404 页面 |
| `GET /pay/{oid}/cb` | **免鉴权**。授权 code 换 openid → JSAPI 下单 → 渲染支付页（加载完自动调起 chooseWXPay） |
| `GET /v1/pay/{oid}/status` | 按商户订单号转发微信查单（MOV 轮询备用），结果原样透传 |

错误响应统一为 `{"error": {"code", "msg"}}`；微信码映射：PROCESSING→409、PARAM_ERROR→400、
NO_AUTH→403、RATE_LIMITED→429、其余→502。

## 鉴权与审计

- 除 `/healthz` 外全部端点要求 `Authorization: Bearer <AUTH_TOKEN>`（`hmac.compare_digest` 比对）。
- **未配置 `AUTH_TOKEN` 时 fail-closed**：所有业务端点一律 401。
- 审计追加到 `applyment_audit.jsonl`（路径可用 `AUDIT_PATH` 覆盖）：每行一条 JSON，
  只含时间 / 动作 / business_code / 结果码，**不落申请单 body、不落任何敏感明文**。

## 环境变量

见 `.env.example`：`MCHID`、`PRIVATE_KEY_PATH`、`CERT_SERIAL_NO`、`APIV3_KEY`、
`WXPAY_PUBLIC_KEY_ID`、`WXPAY_PUBLIC_KEY_PATH`、`AUTH_TOKEN`、`PORT`（默认 8390）、`AUDIT_PATH`、
`MP_APPID`（默认 `wxb73491c14b5470e3`）、`MP_APPSECRET`、`PAY_PUBLIC_BASE`（默认 `https://mow.kim`）。

## JSAPI 支付页（微信内打开 `https://mow.kim/pay/{orderId}`）

流程：

1. MOV 端 `POST /v1/pay/create`（Bearer）登记订单，拿到 `pay_url` 发给用户。
2. 用户在微信内打开 `/pay/{oid}` → 302 网页授权（snsapi_base，无感知）→ 回跳 `/pay/{oid}/cb?code=...`。
3. 服务端 code 换 openid → `POST /v3/pay/transactions/jsapi` 下单拿 `prepay_id` → 渲染支付页。
4. 支付页 `wx.config`（JS-SDK SHA1 签名）+ `wx.chooseWXPay`（RSA-SHA256 二次签名），加载完自动调起收银台。

说明与取舍：

- **订单存内存 dict，重启即丢**；同 `out_trade_no` 重复 create 返回 `409 ORDER_EXISTS`，不覆盖。
- `access_token` / `jsapi_ticket` 内存缓存 7200s（提前 300s 过期）。
- 支付结果回调 `notify_url` 固定为 `{PAY_PUBLIC_BASE}/wxpay/notify`（回调端点尚未实现，查单用 `GET /v1/pay/{oid}/status` 轮询）。
- 前置条件：公众号已配置网页授权域名与 JS 安全域名 `mow.kim`；部署必须补 `MP_APPSECRET`。

## 本地运行

```bash
cd partner-server
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
set -a; source .env; set +a   # 载入环境变量（Windows Git Bash 同此用法）
uvicorn app.main:app --host 127.0.0.1 --port 8390
```

## 测试

```bash
cd partner-server
pytest -q
```

零真实网络、零真实密钥：微信 HTTP 层全部 mock，RSA 密钥对由测试现场生成。

## 部署（mow.kim）

与现有 relay 同机部署，走已有 TLS 反代：

1. 密钥文件放 `/etc/partner-server/`（`apiclient_key.pem`、`wxpay_pub_key.pem`，权限 600，不入 git）。
2. 环境变量写 systemd unit 的 `Environment=` 或 `EnvironmentFile=/etc/partner-server/env`。
3. 服务只监听 `127.0.0.1:8390`，由现有 nginx/caddy 反代 `https://mow.kim/partner/` → `127.0.0.1:8390`（TLS 在反代层终止，与现有 relay 一致）。

systemd unit 示例（`/etc/systemd/system/partner-server.service`）：

```ini
[Unit]
Description=partner-server (wxpay applyment)
After=network.target

[Service]
Type=simple
User=partner
WorkingDirectory=/opt/partner-server
EnvironmentFile=/etc/partner-server/env
ExecStart=/opt/partner-server/.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8390
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

## 目录结构

```
partner-server/
├── app/
│   ├── config.py    # 环境变量配置
│   ├── wxpay.py     # 微信 APIv3 客户端（签名/加密/进件+JSAPI 下单查单，HTTP 层可注入）
│   ├── pay.py       # JSAPI 支付页（token/ticket 缓存、网页授权、支付页渲染）
│   └── main.py      # FastAPI 端点、Bearer 鉴权、敏感字段加密、审计
├── tests/           # pytest 单测（零网络零真实密钥）
├── requirements.txt
└── .env.example
```
