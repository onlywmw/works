"""JSAPI 支付页单测：零真实网络、零真实密钥（公众号 HTTP 层注入假实现，RSA 密钥现场生成）。"""
import base64
import hashlib

import pytest
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from fastapi.testclient import TestClient

from app.config import Config
from app.main import create_app
from app.pay import MpCredentialCache, build_pay_sign, jsapi_config_signature

TOKEN = "test-token"
MP_APPID = "wxTESTAPPID123"
OID = "ORDER_20260809_001"
FEN = 999  # 9.99 元


class MockWxClient:
    """mock 微信支付客户端：记录 JSAPI 下单参数，返回固定 prepay_id / 查单结果。"""

    def __init__(self, private_key):
        self.private_key = private_key
        self.jsapi_payload = None
        self.prepay_id = "PREPAY-123"
        self.query_result = {"trade_state": "SUCCESS", "out_trade_no": OID}

    def create_jsapi_transaction(self, payload):
        self.jsapi_payload = payload
        return {"prepay_id": self.prepay_id}

    def query_transaction_by_out_trade_no(self, out_trade_no):
        self.queried_oid = out_trade_no
        return self.query_result


class FakeMpHttp:
    """假公众号 HTTP 层：按 URL 分发，记录全部调用。"""

    def __init__(self):
        self.calls = []

    def __call__(self, url):
        self.calls.append(url)
        if "/sns/oauth2/access_token" in url:
            return {"openid": "OPENID-123"}
        if "/cgi-bin/token" in url:
            return {"access_token": "ACCESS-TOKEN", "expires_in": 7200}
        if "/cgi-bin/ticket/getticket" in url:
            return {"errcode": 0, "errmsg": "ok", "ticket": "TICKET-ABC", "expires_in": 7200}
        raise AssertionError(f"未预期的 URL: {url}")


@pytest.fixture(scope="module")
def rsa_pair():
    private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return private, private.public_key()


@pytest.fixture()
def mock_http():
    return FakeMpHttp()


@pytest.fixture()
def api(tmp_path, rsa_pair, mock_http):
    """已配置 token 的测试应用；mp_appid/pay_public_base 用测试值。"""
    private, _ = rsa_pair
    config = Config(
        mchid="1900000000", private_key_path="", cert_serial_no="SERIAL",
        apiv3_key="", wxpay_public_key_id="PUB_KEY_ID_TEST",
        wxpay_public_key_path="", auth_token=TOKEN, port=8390,
        audit_path=str(tmp_path / "audit.jsonl"),
        mp_appid=MP_APPID, mp_appsecret="test-secret",
        pay_public_base="https://mow.kim",
    )
    mock_wx = MockWxClient(private)
    client = TestClient(create_app(config, wx_client=mock_wx, pay_http_get=mock_http))
    client.config = config
    client.mock_wx = mock_wx
    return client


def _auth():
    return {"Authorization": f"Bearer {TOKEN}"}


def _create(api, oid=OID, fen=FEN, description="测试商品"):
    return api.post("/v1/pay/create",
                    json={"out_trade_no": oid, "description": description, "fen": fen},
                    headers=_auth())


# ---------- POST /v1/pay/create ----------

def test_create_returns_pay_url(api):
    resp = _create(api)
    assert resp.status_code == 200
    assert resp.json() == {"pay_url": f"https://mow.kim/pay/{OID}"}


def test_create_duplicate_oid_409(api):
    assert _create(api).status_code == 200
    resp = _create(api, fen=1)  # 同 oid 重复 create：409，不覆盖
    assert resp.status_code == 409
    assert resp.json()["error"]["code"] == "ORDER_EXISTS"


def test_create_bad_oid_400(api):
    for bad in ("短", "ab", "has space", "has-dash", "x" * 65, ""):
        resp = _create(api, oid=bad)
        assert resp.status_code == 400, bad
        assert resp.json()["error"]["code"] == "INVALID_OUT_TRADE_NO"


def test_create_bad_fen_400(api):
    for bad in (0, -5, "999", 9.99, True, None):
        resp = _create(api, fen=bad)
        assert resp.status_code == 400, bad
        assert resp.json()["error"]["code"] == "INVALID_FEN"


def test_create_missing_bearer_401(api):
    resp = api.post("/v1/pay/create", json={"out_trade_no": OID, "fen": FEN})
    assert resp.status_code == 401


# ---------- GET /pay/{oid} 授权跳转 ----------

def test_pay_entry_redirect(api):
    _create(api)
    resp = api.get(f"/pay/{OID}", follow_redirects=False)
    assert resp.status_code == 302
    loc = resp.headers["location"]
    assert loc.startswith("https://open.weixin.qq.com/connect/oauth2/authorize?")
    assert f"appid={MP_APPID}" in loc
    assert "redirect_uri=https%3A%2F%2Fmow.kim%2Fpay%2F" + OID + "%2Fcb" in loc
    assert "response_type=code" in loc
    assert "scope=snsapi_base" in loc
    assert f"state={OID}" in loc
    assert loc.endswith("#wechat_redirect")


def test_pay_entry_unknown_oid_404(api):
    resp = api.get("/pay/NOPE_404", follow_redirects=False)
    assert resp.status_code == 404
    assert "订单不存在" in resp.text


def test_pay_entry_no_auth_required(api):
    """/pay/* 免鉴权：不带 Bearer 也能跳转。"""
    _create(api)
    resp = api.get(f"/pay/{OID}", follow_redirects=False)
    assert resp.status_code == 302


# ---------- GET /pay/{oid}/cb 全流程 ----------

def test_cb_full_flow(api, mock_http):
    _create(api)
    resp = api.get(f"/pay/{OID}/cb?code=AUTH_CODE&state={OID}")
    assert resp.status_code == 200
    page = resp.text
    # 页面自动调起 chooseWXPay，package 与金额/商品名正确
    assert "chooseWXPay" in page
    assert "prepay_id=PREPAY-123" in page
    assert "9.99" in page
    assert "测试商品" in page
    assert "调起支付中" in page
    # JSAPI 下单参数正确（code 换的 openid 落到 payer）
    payload = api.mock_wx.jsapi_payload
    assert payload["mchid"] == "1900000000"
    assert payload["appid"] == MP_APPID
    assert payload["description"] == "测试商品"
    assert payload["out_trade_no"] == OID
    assert payload["notify_url"] == "https://mow.kim/wxpay/notify"
    assert payload["amount"] == {"total": FEN, "currency": "CNY"}
    assert payload["payer"] == {"openid": "OPENID-123"}
    # ticket 只取了一次（缓存生效）
    ticket_calls = [u for u in mock_http.calls if "/cgi-bin/ticket/getticket" in u]
    assert len(ticket_calls) == 1


def test_cb_oauth_url(api, mock_http):
    _create(api)
    api.get(f"/pay/{OID}/cb?code=AUTH_CODE")
    # code 换 openid 的 URL 带了 appid/secret/code/grant_type
    oauth_url = next(u for u in mock_http.calls if "/sns/oauth2/access_token" in u)
    assert f"appid={MP_APPID}" in oauth_url
    assert "secret=test-secret" in oauth_url
    assert "code=AUTH_CODE" in oauth_url
    assert "grant_type=authorization_code" in oauth_url


def test_cb_unknown_oid_404(api):
    resp = api.get("/pay/NOPE_404/cb?code=X")
    assert resp.status_code == 404


def test_cb_missing_code_400(api):
    _create(api)
    resp = api.get(f"/pay/{OID}/cb")
    assert resp.status_code == 400
    assert "code" in resp.text


# ---------- 签名 ----------

def test_config_signature_known_vector():
    """已知向量：固定 ticket/nonce/ts/url 手算 SHA1 必须对得上。"""
    ticket = "sM4AOVdWfPE4DxkXGEs8VMCPGGVi4C3VM0P37wVUCFvkVAy_90u5h9nbSlYy3-Sl-HhTdfl2fzFy1AOcHKP7qg"
    nonce = "Wm3WZYTPz0wzccnW"
    ts = "1414587457"
    url = "http://mp.weixin.qq.com?params=value"
    raw = f"jsapi_ticket={ticket}&noncestr={nonce}&timestamp={ts}&url={url}"
    expected = hashlib.sha1(raw.encode("utf-8")).hexdigest()
    assert jsapi_config_signature(ticket, nonce, ts, url) == expected
    # 微信官方文档示例值（进一步防手滑）
    assert expected == "0f9de62fce790f9a083d5c99e95740ceb90c27ed"


def test_pay_sign_roundtrip(rsa_pair):
    """paySign 可用对应公钥验签回环。"""
    private, public = rsa_pair
    ts, nonce, package = "1700000000", "nonce123", "prepay_id=PREPAY-123"
    signature = base64.b64decode(build_pay_sign(private, MP_APPID, ts, nonce, package))
    message = f"{MP_APPID}\n{ts}\n{nonce}\n{package}\n"
    public.verify(signature, message.encode("utf-8"), padding.PKCS1v15(), hashes.SHA256())


# ---------- token/ticket 缓存 ----------

def test_credential_cache():
    fake = FakeMpHttp()
    cache = MpCredentialCache(MP_APPID, "secret", http_get=fake)
    assert cache.get_access_token() == "ACCESS-TOKEN"
    assert cache.get_access_token() == "ACCESS-TOKEN"  # 第二次走缓存
    assert cache.get_jsapi_ticket() == "TICKET-ABC"
    assert cache.get_jsapi_ticket() == "TICKET-ABC"
    token_calls = [u for u in fake.calls if "/cgi-bin/token?" in u]
    ticket_calls = [u for u in fake.calls if "/cgi-bin/ticket/getticket" in u]
    assert len(token_calls) == 1
    assert len(ticket_calls) == 1


def test_credential_cache_expires():
    """缓存提前 300s 过期：时钟越过 6900s 后重新拉取。"""
    fake = FakeMpHttp()
    now = [1_000_000.0]
    cache = MpCredentialCache(MP_APPID, "secret", http_get=fake, clock=lambda: now[0])
    cache.get_access_token()
    now[0] += 6900  # 7200 - 300 = 6900s 后缓存失效
    cache.get_access_token()
    token_calls = [u for u in fake.calls if "/cgi-bin/token?" in u]
    assert len(token_calls) == 2


# ---------- GET /v1/pay/{oid}/status ----------

def test_pay_status(api, rsa_pair):
    private, _ = rsa_pair
    resp = api.get(f"/v1/pay/{OID}/status", headers=_auth())
    assert resp.status_code == 200
    assert resp.json()["trade_state"] == "SUCCESS"


def test_pay_status_requires_bearer(api):
    assert api.get(f"/v1/pay/{OID}/status").status_code == 401
