"""partner-server 单测：零真实网络、零真实密钥（RSA 密钥对现场生成，微信层全部 mock）。"""
import base64
import json

import pytest
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from fastapi.testclient import TestClient

from app.config import Config
from app.main import create_app
from app.wxpay import WxPayError, build_message, encrypt_sensitive, sign

TOKEN = "test-token"
_OAEP = padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA1()), algorithm=hashes.SHA1(), label=None)

# 示例申请单（含各类敏感字段）
APPLYMENT = {
    "business_code": "1900000000_1700000000",
    "contact_info": {
        "contact_type": "LEGAL",
        "contact_name": "张三",
        "contact_id_number": "110101199001011234",
        "mobile_phone": "13800138000",
        "contact_email": "zhangsan@example.com",
    },
    "subject_info": {
        "identity_info": {
            "id_doc_type": "IDENTIFICATION_TYPE_MAINLAND_IDCARD",
            "id_card_info": {
                "id_card_name": "张三",
                "id_card_number": "110101199001011234",
                "id_card_address": "北京市朝阳区某路1号",
            },
            "ubo_info_list": [
                {
                    "ubo_id_card_name": "李四",
                    "ubo_id_card_number": "110101199201021234",
                    "ubo_id_card_address": "北京市海淀区某路2号",
                }
            ],
        },
    },
    "bank_account_info": {
        "bank_account_type": "BANK_ACCOUNT_TYPE_CORPORATE",
        "account_name": "某某科技有限公司",
        "account_bank": "工商银行",
        "account_number": "6222020200112233445",
    },
}


class MockWxClient:
    """mock 微信客户端：记录上送参数，返回可配置结果/错误。"""

    def __init__(self):
        self.submitted = None
        self.submit_result = {"applyment_id": 123}
        self.submit_error = None
        self.query_result = {"applyment_state": "CHECKING"}
        self.uploaded = None
        self.upload_result = {"media_id": "MEDIA-123"}

    def submit_applyment(self, applyment):
        self.submitted = applyment
        if self.submit_error:
            raise self.submit_error
        return self.submit_result

    def query_applyment(self, business_code):
        return self.query_result

    def upload_media(self, filename, content):
        self.uploaded = (filename, content)
        return self.upload_result


@pytest.fixture(scope="module")
def rsa_pair():
    """现场生成 2048 位 RSA 密钥对。"""
    private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return private, private.public_key()


@pytest.fixture()
def mock_client():
    return MockWxClient()


@pytest.fixture()
def api(tmp_path, rsa_pair, mock_client):
    """已配置 token 的测试应用；微信支付公钥写入临时文件。"""
    _, public = rsa_pair
    pub_path = tmp_path / "wxpay_pub_key.pem"
    pub_path.write_bytes(public.public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo))
    config = Config(
        mchid="1900000000", private_key_path="", cert_serial_no="SERIAL",
        apiv3_key="", wxpay_public_key_id="PUB_KEY_ID_TEST",
        wxpay_public_key_path=str(pub_path), auth_token=TOKEN, port=8390,
        audit_path=str(tmp_path / "applyment_audit.jsonl"),
    )
    client = TestClient(create_app(config, wx_client=mock_client))
    client.config = config
    return client


def _auth():
    return {"Authorization": f"Bearer {TOKEN}"}


def _decrypt(private, ciphertext_b64: str) -> str:
    return private.decrypt(base64.b64decode(ciphertext_b64), _OAEP).decode("utf-8")


# ---------- 签名 ----------

def test_build_message_five_lines():
    msg = build_message("POST", "/v3/applyment4sub/applyment/", "1700000000", "nonce123", '{"a":1}')
    lines = msg.split("\n")
    # 五行内容 + 末尾换行产生的空串
    assert lines[:5] == ["POST", "/v3/applyment4sub/applyment/", "1700000000", "nonce123", '{"a":1}']
    assert msg.endswith("\n")


def test_sign_verifiable_with_public_key(rsa_pair):
    private, public = rsa_pair
    message = build_message("GET", "/v3/test", "1700000000", "abc", "")
    signature = base64.b64decode(sign(private, message))
    # 验签不抛异常即通过
    public.verify(signature, message.encode("utf-8"), padding.PKCS1v15(), hashes.SHA256())


# ---------- 敏感字段加密 ----------

def test_encrypt_sensitive_roundtrip(rsa_pair):
    private, public = rsa_pair
    ciphertext = encrypt_sensitive(public, "110101199001011234")
    assert ciphertext != "110101199001011234"
    assert _decrypt(private, ciphertext) == "110101199001011234"


# ---------- POST /v1/applyment ----------

def test_submit_applyment_success(api, mock_client, rsa_pair):
    private, _ = rsa_pair
    resp = api.post("/v1/applyment", json=APPLYMENT, headers=_auth())
    assert resp.status_code == 200
    assert resp.json() == {"applyment_id": 123}

    sent = mock_client.submitted
    sent_str = json.dumps(sent, ensure_ascii=False)
    # 上送 body 中不出现任何明文敏感值
    for plain in ("张三", "李四", "110101199001011234", "110101199201021234",
                  "13800138000", "zhangsan@example.com", "北京市朝阳区某路1号",
                  "某某科技有限公司", "6222020200112233445"):
        assert plain not in sent_str
    # 密文可被对应私钥解密还原
    contact = sent["contact_info"]
    assert _decrypt(private, contact["contact_name"]) == "张三"
    assert _decrypt(private, contact["contact_id_number"]) == "110101199001011234"
    assert _decrypt(private, contact["mobile_phone"]) == "13800138000"
    assert _decrypt(private, contact["contact_email"]) == "zhangsan@example.com"
    id_card = sent["subject_info"]["identity_info"]["id_card_info"]
    assert _decrypt(private, id_card["id_card_name"]) == "张三"
    assert _decrypt(private, id_card["id_card_number"]) == "110101199001011234"
    assert _decrypt(private, id_card["id_card_address"]) == "北京市朝阳区某路1号"
    ubo = sent["subject_info"]["identity_info"]["ubo_info_list"][0]
    assert _decrypt(private, ubo["ubo_id_card_name"]) == "李四"
    assert _decrypt(private, ubo["ubo_id_card_number"]) == "110101199201021234"
    assert _decrypt(private, ubo["ubo_id_card_address"]) == "北京市海淀区某路2号"
    bank = sent["bank_account_info"]
    assert _decrypt(private, bank["account_name"]) == "某某科技有限公司"
    assert _decrypt(private, bank["account_number"]) == "6222020200112233445"
    # 非敏感字段保持原样
    assert sent["business_code"] == APPLYMENT["business_code"]
    assert bank["account_bank"] == "工商银行"


def test_submit_applyment_processing(api, mock_client):
    mock_client.submit_error = WxPayError("PROCESSING", "已存在进行中的申请单", 200)
    resp = api.post("/v1/applyment", json=APPLYMENT, headers=_auth())
    assert resp.status_code == 409
    assert resp.json() == {"error": {"code": "PROCESSING", "msg": "已存在进行中的申请单"}}


def test_submit_applyment_param_error(api, mock_client):
    mock_client.submit_error = WxPayError("PARAM_ERROR", "contact_info.contact_name 不能为空", 400)
    resp = api.post("/v1/applyment", json=APPLYMENT, headers=_auth())
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "PARAM_ERROR"


# ---------- 鉴权 ----------

def test_no_auth_token_config_fails_closed(tmp_path, mock_client):
    config = Config(mchid="", private_key_path="", cert_serial_no="", apiv3_key="",
                    wxpay_public_key_id="", wxpay_public_key_path="", auth_token="",
                    port=8390, audit_path=str(tmp_path / "audit.jsonl"))
    api = TestClient(create_app(config, wx_client=mock_client))
    assert api.post("/v1/applyment", json=APPLYMENT).status_code == 401
    assert api.get("/v1/applyment/abc").status_code == 401
    # healthz 免鉴权
    assert api.get("/healthz").status_code == 200


def test_wrong_token_401(api):
    assert api.post("/v1/applyment", json=APPLYMENT,
                    headers={"Authorization": "Bearer wrong"}).status_code == 401
    assert api.get("/v1/applyment/abc").status_code == 401  # 无头也 401


def test_healthz_no_auth(api):
    assert api.get("/healthz").json() == {"status": "ok"}


# ---------- 查询 ----------

def test_query_applyment(api):
    resp = api.get("/v1/applyment/1900000000_1700000000", headers=_auth())
    assert resp.status_code == 200
    assert resp.json() == {"applyment_state": "CHECKING"}


# ---------- 媒体上传 ----------

def test_media_upload(api, mock_client):
    resp = api.post("/v1/media", files={"file": ("idcard.jpg", b"\xff\xd8fake-jpeg", "image/jpeg")},
                    headers=_auth())
    assert resp.status_code == 200
    assert resp.json() == {"media_id": "MEDIA-123"}
    filename, content = mock_client.uploaded
    assert filename == "idcard.jpg"
    assert content == b"\xff\xd8fake-jpeg"


# ---------- 审计 ----------

def test_audit_log(api):
    api.post("/v1/applyment", json=APPLYMENT, headers=_auth())
    api.get("/v1/applyment/1900000000_1700000000", headers=_auth())

    lines = [json.loads(l) for l in
             open(api.config.audit_path, encoding="utf-8").read().splitlines() if l.strip()]
    assert len(lines) == 2
    assert lines[0]["action"] == "submit_applyment"
    assert lines[0]["business_code"] == "1900000000_1700000000"
    assert lines[0]["result_code"] == "OK"
    assert lines[1]["action"] == "query_applyment"
    # 审计全文不含任何明文敏感值
    raw = open(api.config.audit_path, encoding="utf-8").read()
    for plain in ("张三", "李四", "110101199001011234", "13800138000",
                  "zhangsan@example.com", "6222020200112233445"):
        assert plain not in raw
