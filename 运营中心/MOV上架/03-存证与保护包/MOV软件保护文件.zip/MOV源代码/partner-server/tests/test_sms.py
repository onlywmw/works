"""短信验证码通道单测：零真实网络、时间可控（注入 clock）、验证码库可注入。

覆盖：发送格式校验 / 频控（手机号 60s + IP 30s）/ 校验成功 / 过期 / 超次 / 未发先验 / 重放作废。
"""
import pytest
from fastapi.testclient import TestClient

from app.config import Config
from app.main import create_app

TOKEN = "test-token"
MOBILE = "13800138000"


class _Clock:
    """可控时钟：测试里手动推进。"""

    def __init__(self):
        self.t = 1_000_000.0

    def __call__(self):
        return self.t

    def advance(self, seconds):
        self.t += seconds


@pytest.fixture
def env():
    clock = _Clock()
    store = {}
    cfg = Config(
        mchid="", private_key_path="", cert_serial_no="", apiv3_key="",
        wxpay_public_key_id="", wxpay_public_key_path="", auth_token=TOKEN,
        port=8390, audit_path="", mp_appid="", pay_public_base="https://mow.kim",
    )
    app = create_app(cfg, sms_store=store, sms_clock=clock)
    client = TestClient(app)
    client.headers.update({"Authorization": f"Bearer {TOKEN}"})
    return client, clock, store


def _send(client, mobile=MOBILE):
    return client.post("/v1/sms/send", json={"mobile": mobile})


def _verify(client, mobile=MOBILE, code="000000"):
    return client.post("/v1/sms/verify", json={"mobile": mobile, "code": code})


def test_send_ok(env):
    client, _, store = env
    r = _send(client)
    assert r.status_code == 200
    body = r.json()
    assert body["ok"] is True
    assert "mobile_hash" in body["data"]
    # 验证码已入内存，长度 6 位数字
    assert len(store[MOBILE]["code"]) == 6
    assert store[MOBILE]["code"].isdigit()


def test_send_invalid_mobile(env):
    client, _, _ = env
    assert _send(client, "12345").status_code == 400       # 位数不足
    assert _send(client, "23800138000").status_code == 400  # 非 1 开头
    assert _send(client, "1380013800a").status_code == 400  # 含字母


def test_send_rate_limit_same_mobile(env):
    client, clock, _ = env
    assert _send(client).status_code == 200
    # 60s 内再发 → 429
    clock.advance(30)
    r = _send(client)
    assert r.status_code == 429
    assert r.json()["error"]["code"] == "RATE_LIMITED"
    # 过 60s 后可再发
    clock.advance(31)
    assert _send(client).status_code == 200


def test_send_rate_limit_same_ip(env):
    client, clock, _ = env
    assert _send(client, "13900139000").status_code == 200
    # 换手机号同 IP，30s 内 → 429（IP 频控）
    clock.advance(1)
    r = _send(client, "13700137000")
    assert r.status_code == 429
    assert r.json()["error"]["code"] == "RATE_LIMITED"
    clock.advance(30)
    assert _send(client, "13700137000").status_code == 200


def test_verify_ok(env):
    client, _, store = env
    _send(client)
    code = store[MOBILE]["code"]
    r = _verify(client, code=code)
    assert r.status_code == 200
    body = r.json()
    assert body["ok"] is True
    assert body["data"]["verified"] is True
    assert "mobile_hash" in body["data"]
    # 校验成功即销毁（防重放）
    assert MOBILE not in store


def test_verify_wrong_code(env):
    client, _, store = env
    _send(client)
    code = store[MOBILE]["code"]
    wrong = "999999" if code != "999999" else "888888"
    r = _verify(client, code=wrong)
    assert r.status_code == 400
    assert r.json()["error"]["code"] == "CODE_MISMATCH"
    # 次数已扣减
    assert store[MOBILE]["attempts"] == 1


def test_verify_too_many_attempts(env):
    client, _, store = env
    _send(client)
    code = store[MOBILE]["code"]
    wrong = "999999" if code != "999999" else "888888"
    r = None
    # 5 次错（前 5 次每次扣 1），第 6 次触发「超次作废」→ 429
    for i in range(6):
        r = _verify(client, code=wrong)
    assert r.status_code == 429
    assert r.json()["error"]["code"] == "CODE_TOO_MANY"
    # 作废销毁
    assert MOBILE not in store


def test_verify_expired(env):
    client, clock, store = env
    _send(client)
    clock.advance(601)  # 过 10min 有效期
    code = store[MOBILE]["code"]
    r = _verify(client, code=code)
    assert r.status_code == 400
    assert r.json()["error"]["code"] == "CODE_EXPIRED"
    assert MOBILE not in store


def test_verify_without_send(env):
    client, _, _ = env
    r = _verify(client)
    assert r.status_code == 400
    assert r.json()["error"]["code"] == "CODE_NOT_SENT"


def test_auth_required(env):
    client, _, _ = env
    # 无 Bearer token → 401（鉴权中间件统一）
    bare = TestClient(client.app)
    assert bare.post("/v1/sms/send", json={"mobile": MOBILE}).status_code == 401
    assert bare.post("/v1/sms/verify", json={"mobile": MOBILE, "code": "000000"}).status_code == 401
