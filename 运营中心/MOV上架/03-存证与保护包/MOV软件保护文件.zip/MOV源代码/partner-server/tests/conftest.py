import sys
from pathlib import Path

# 让测试能 import app 包（partner-server/ 为根）
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
