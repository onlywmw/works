package com.hermes.android.mcp.server;

import com.hermes.android.agent.Journal;
import com.hermes.android.agent.ToolRegistry;

import org.json.JSONObject;
import org.junit.Test;

import java.io.File;
import java.nio.file.Files;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * mov.* 只读查询工具单测（工单 P5）——纯 JVM 零网络，走 Journal 既有 API。
 */
public class MovQueryToolsTest {

    @Test public void roomList_enumeratesRooms_sorted() throws Exception {
        File dir = Files.createTempDirectory("movq").toFile();
        try {
            Journal j = new Journal(dir);
            j.append("zeta", new JSONObject().put("type", "note").put("actor", "t"));
            j.append("alpha", new JSONObject().put("type", "note").put("actor", "t"));
            ToolRegistry.Result r = MovQueryTools.roomList(j).handler.run(new JSONObject());
            assertTrue(r.ok);
            JSONObject out = new JSONObject(r.text);
            assertEquals(2, out.optInt("count"));
            String arr = out.optJSONArray("rooms").toString();
            assertTrue("按字典序: " + arr, arr.indexOf("alpha") < arr.indexOf("zeta"));
        } finally {
            deleteRecursive(dir);
        }
    }

    @Test public void roomList_empty_noRooms() throws Exception {
        File dir = Files.createTempDirectory("movq2").toFile();
        try {
            Journal j = new Journal(dir);
            ToolRegistry.Result r = MovQueryTools.roomList(j).handler.run(new JSONObject());
            assertTrue(r.ok);
            assertEquals(0, new JSONObject(r.text).optInt("count"));
        } finally {
            deleteRecursive(dir);
        }
    }

    @Test public void journalTail_returnsRecentEvents() throws Exception {
        File dir = Files.createTempDirectory("movq3").toFile();
        try {
            Journal j = new Journal(dir);
            j.append("global", new JSONObject().put("type", "a").put("actor", "t"));
            j.append("global", new JSONObject().put("type", "b").put("actor", "t"));
            j.append("global", new JSONObject().put("type", "c").put("actor", "t"));
            ToolRegistry.Result r = MovQueryTools.journalTail(j).handler.run(
                    new JSONObject().put("roomId", "global").put("afterSeq", 0).put("count", 2));
            assertTrue(r.ok);
            JSONObject data = new JSONObject(r.text);
            assertEquals("count=2 取最近 2 条", 2, data.optJSONArray("events").length());
            assertEquals(3, data.optInt("latestSeq"));
        } finally {
            deleteRecursive(dir);
        }
    }

    @Test public void journalTail_afterSeq_incremental() throws Exception {
        File dir = Files.createTempDirectory("movq4").toFile();
        try {
            Journal j = new Journal(dir);
            j.append("global", new JSONObject().put("type", "a").put("actor", "t"));  // seq1
            j.append("global", new JSONObject().put("type", "b").put("actor", "t"));  // seq2
            ToolRegistry.Result r = MovQueryTools.journalTail(j).handler.run(
                    new JSONObject().put("roomId", "global").put("afterSeq", 1).put("count", 10));
            assertTrue(r.ok);
            JSONObject data = new JSONObject(r.text);
            assertEquals("只返回 seq>1 的事件", 1, data.optJSONArray("events").length());
            assertEquals("该事件 seq=2", 2, data.optJSONArray("events").optJSONObject(0).optInt("seq"));
        } finally {
            deleteRecursive(dir);
        }
    }

    @Test public void journalTail_invalidRoom_error() throws Exception {
        File dir = Files.createTempDirectory("movq5").toFile();
        try {
            Journal j = new Journal(dir);
            ToolRegistry.Result r = MovQueryTools.journalTail(j).handler.run(
                    new JSONObject().put("roomId", "bad!"));
            assertFalse("非法房间ID → 失败信封", r.ok);
        } finally {
            deleteRecursive(dir);
        }
    }

    @Test public void journalTail_missingRoom_emptyEvents() throws Exception {
        File dir = Files.createTempDirectory("movq6").toFile();
        try {
            Journal j = new Journal(dir);
            ToolRegistry.Result r = MovQueryTools.journalTail(j).handler.run(
                    new JSONObject().put("roomId", "emptyroom").put("count", 10));
            assertTrue(r.ok);
            assertEquals("不存在房间 → 空事件", 0,
                    new JSONObject(r.text).optJSONArray("events").length());
        } finally {
            deleteRecursive(dir);
        }
    }

    private static void deleteRecursive(File f) {
        File[] c = f.listFiles();
        if (c != null) for (File x : c) deleteRecursive(x);
        f.delete();
    }
}
