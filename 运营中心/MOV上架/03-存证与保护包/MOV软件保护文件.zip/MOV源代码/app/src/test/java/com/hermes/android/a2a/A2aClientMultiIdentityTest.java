package com.hermes.android.a2a;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * 工单26 M0-2：A2aClient 多身份支持——按 deviceId 分 key 存 token，双身份互不串。
 *
 * 零网络：TokenStore 内存 fake 注入；saveRegistration 是 register 成功路径的
 * 落盘函数，直接驱动存储层验证隔离语义。
 */
public class A2aClientMultiIdentityTest {

    /** 内存 fake（仿 McpServerStoreTest 的 Prefs 模式） */
    static class FakeStore implements A2aClient.TokenStore {
        final Map<String, String> m = new HashMap<>();
        @Override public String get(String key, String def) { return m.containsKey(key) ? m.get(key) : def; }
        @Override public void put(String key, String value) { m.put(key, value); }
    }

    @Test
    public void 双身份token独立互不串() {
        FakeStore s = new FakeStore();
        A2aClient seller = new A2aClient(s, "mov-seller");
        A2aClient buyer  = new A2aClient(s, "mov-buyer-test");
        assertNull("初始未注册", seller.getToken());
        assertNull("初始未注册", buyer.getToken());

        seller.saveRegistration("mov-seller", "tokA");
        buyer.saveRegistration("mov-buyer-test", "tokB");

        // 新实例读回各自 token（模拟重启后同进程双实例）
        A2aClient s2 = new A2aClient(s, "mov-seller");
        A2aClient b2 = new A2aClient(s, "mov-buyer-test");
        assertEquals("tokA", s2.getToken());
        assertEquals("tokB", b2.getToken());
        assertEquals("mov-seller", s2.getDeviceId());
        assertEquals("mov-buyer-test", b2.getDeviceId());
        assertEquals("seller token 与 buyer 不串", "tokA", s2.getToken());
        assertNotEquals("tokB", s2.getToken());
    }

    @Test
    public void 改一个身份不影响另一个() {
        FakeStore s = new FakeStore();
        A2aClient buyer = new A2aClient(s, "mov-buyer-test");
        buyer.saveRegistration("mov-buyer-test", "tokB1");

        A2aClient seller = new A2aClient(s, "mov-seller");
        seller.saveRegistration("mov-seller", "tokA1");
        seller.saveRegistration("mov-seller", "tokA2");   // 卖家重注册/轮换

        A2aClient b2 = new A2aClient(s, "mov-buyer-test");
        assertEquals("买家 token 不被卖家轮换影响", "tokB1", b2.getToken());
    }

    @Test
    public void 旧单身份行为兼容() {
        FakeStore s = new FakeStore();
        // 旧版本（幕一前）写入的无前缀 key —— 新代码必须仍能读回
        s.put("device_token", "tokL");
        s.put("device_id", "legacy-device");
        A2aClient l2 = new A2aClient(s, null);
        assertEquals("tokL", l2.getToken());
        assertEquals("legacy-device", l2.getDeviceId());
        assertNull("无前缀 token 不进多身份前缀 key", new A2aClient(s, "mov-seller").getToken());
    }
}
