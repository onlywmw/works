package com.hermes.android.serve;

import static org.junit.Assert.*;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.json.JSONObject;
import org.junit.Test;

import java.net.InetAddress;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * M5 后续 / 阶段3 A0 单测（零网络注入式）：直接调 MovInboundServer.dispatch 纯逻辑——
 * 路由分发（合法/非法 tool）、鉴权（有/无/错 token，fail-closed）、信封（成功/失败）、预留路由。
 * 不启真实 socket，无网络。
 */
public class MovInboundServerTest {

    private static final String TOKEN = "mov-a0-test-token";

    /** 造一个带 shell.exec 的 ToolRegistry（fake Tools，shell 走 canned 响应） */
    private static ToolRegistry registryWithShell(final Map<String, String> shellResponses) {
        AgentLoop.Tools tools = new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return "[]"; }
            @Override public String fileRead(String roomId, String path) { return ""; }
            @Override public String fileWrite(String roomId, String path, String c) { return "OK:"; }
            @Override public String capabilityOf(String text) { return ""; }
            @Override public String deviceCmd(String text) { return "ok"; }
            @Override public String packageApk(String roomId, String path, String n) { return "{\"ok\":false}"; }
            @Override public String shellExec(String cmd, int timeoutSec) {
                return shellResponses.getOrDefault(cmd, "exit=0\n");
            }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":false}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":false}"; }
        };
        return ToolRegistry.build(tools, "room1", HashSet::new,
                ToolRegistry.policyForTest(Collections.<String>emptySet()), true);
    }

    private static MovInboundServer server(Map<String, String> responses) {
        /* context 传 null：现有用例不触 /infer（infer 才用 context 取默认模型） */
        return new MovInboundServer(registryWithShell(responses), TOKEN, null);
    }

    private static InetAddress loopback() throws Exception {
        return InetAddress.getByName("127.0.0.1");
    }

    private static InetAddress nonLoopback() throws Exception {
        return InetAddress.getByAddress(new byte[]{10, 0, 0, 1});   // 无 DNS
    }

    private static JSONObject invokeBody(String cmd) throws Exception {
        return new JSONObject().put("params", new JSONObject().put("cmd", cmd));
    }

    // ==================== healthz（免鉴权） ====================

    @Test public void healthz_noAuth_ok() throws Exception {
        MovInboundServer.Response r = server(new HashMap<>())
                .dispatch("GET", "/healthz", null, null, loopback());
        assertEquals(200, r.status);
        JSONObject b = new JSONObject(r.body);
        assertTrue(b.optBoolean("ok"));
        assertTrue(b.has("data"));
    }

    @Test public void healthz_fromNonLoopback_rejected() throws Exception {
        MovInboundServer.Response r = server(new HashMap<>())
                .dispatch("GET", "/healthz", null, null, nonLoopback());
        assertEquals("非 127.0.0.1 来源必须拒绝", 401, r.status);
    }

    // ==================== 鉴权（fail-closed） ====================

    @Test public void invoke_noToken_401() throws Exception {
        MovInboundServer.Response r = server(new HashMap<>())
                .dispatch("POST", "/tools/shell.exec/invoke", invokeBody("echo hi"), null, loopback());
        assertEquals(401, r.status);
        assertTrue(new JSONObject(r.body).optString("error").contains("token"));
    }

    @Test public void invoke_wrongToken_401() throws Exception {
        MovInboundServer.Response r = server(new HashMap<>())
                .dispatch("POST", "/tools/shell.exec/invoke", invokeBody("echo hi"), "wrong", loopback());
        assertEquals(401, r.status);
        assertEquals("UNAUTHORIZED", new JSONObject(r.body).optJSONObject("error").optString("code"));
    }

    @Test public void invoke_serverWithoutToken_failClosed() throws Exception {
        // 服务端未配置 token → 一切非 healthz 请求 401
        MovInboundServer s = new MovInboundServer(registryWithShell(new HashMap<>()), "", null);
        MovInboundServer.Response r = s.dispatch("POST", "/tools/shell.exec/invoke",
                invokeBody("echo hi"), "anything", loopback());
        assertEquals(401, r.status);
    }

    // ==================== 工具调用（信封） ====================

    @Test public void invoke_validTool_correctToken_successEnvelope() throws Exception {
        Map<String, String> resp = new HashMap<>();
        resp.put("echo hi", "exit=0\nhello");
        MovInboundServer.Response r = server(resp)
                .dispatch("POST", "/tools/shell.exec/invoke", invokeBody("echo hi"), TOKEN, loopback());
        assertEquals(200, r.status);
        JSONObject b = new JSONObject(r.body);
        assertTrue("成功信封必须 ok=true", b.optBoolean("ok"));
        assertTrue("成功必须有 data", b.has("data"));
        assertTrue("data 里带工具结果文本: " + b, b.optJSONObject("data").has("text"));
    }

    @Test public void invoke_failingTool_errorEnvelope() throws Exception {
        Map<String, String> resp = new HashMap<>();
        resp.put("false", "exit=1\nboom");
        MovInboundServer.Response r = server(resp)
                .dispatch("POST", "/tools/shell.exec/invoke", invokeBody("false"), TOKEN, loopback());
        assertEquals(200, r.status);
        JSONObject b = new JSONObject(r.body);
        assertFalse("失败信封必须 ok=false", b.optBoolean("ok"));
        assertEquals("TOOL_FAILED", b.optJSONObject("error").optString("code"));
    }

    @Test public void invoke_unknownTool_404() throws Exception {
        MovInboundServer.Response r = server(new HashMap<>())
                .dispatch("POST", "/tools/no.such.tool/invoke", new JSONObject(), TOKEN, loopback());
        assertEquals(404, r.status);
        assertEquals("TOOL_NOT_FOUND", new JSONObject(r.body).optJSONObject("error").optString("code"));
    }

    // ==================== 预留路由（B/C 吃同一通道，A0 只留位） ====================

    @Test public void infer_implemented_noContext_errorsGracefully() throws Exception {
        /* B1: /infer 已实现；测试传 null context（无默认模型）→ 错误信封，断言 error.code */
        MovInboundServer.Response r = server(new HashMap<>())
                .dispatch("POST", "/infer", new JSONObject().put("messages",
                        new org.json.JSONArray().put(new JSONObject().put("role", "user").put("content", "hi"))),
                        TOKEN, loopback());
        assertEquals(200, r.status);
        JSONObject b = new JSONObject(r.body);
        assertFalse(b.optBoolean("ok"));
        String code = b.optJSONObject("error").optString("code");
        assertTrue("error.code 必须是 NOT_CONFIGURED 或 INFER_ERROR: " + code,
                "NOT_CONFIGURED".equals(code) || "INFER_ERROR".equals(code));
    }

    // ==================== B1 核心路径: splitInferMessages 纯函数（禁 mock LLM） ====================

    @Test public void splitMessages_lastUserIsPrompt_othersHistory() throws Exception {
        org.json.JSONArray msgs = new org.json.JSONArray()
                .put(new JSONObject().put("role", "system").put("content", "你是助手"))
                .put(new JSONObject().put("role", "user").put("content", "你好"))
                .put(new JSONObject().put("role", "assistant").put("content", "你好！"))
                .put(new JSONObject().put("role", "user").put("content", "1+1=?"));
        java.util.List<com.hermes.android.ai.AiClient.Message> history = new java.util.ArrayList<>();
        StringBuilder prompt = new StringBuilder();
        MovInboundServer.splitInferMessages(msgs, history, prompt);
        assertEquals("末条 user 当 prompt", "1+1=?", prompt.toString());
        assertEquals("history 顺序保留 (system,user,assistant)", 3, history.size());
        assertEquals("system", history.get(0).role);
        assertEquals("user", history.get(1).role);
        assertEquals("assistant", history.get(2).role);
        assertEquals("你是助手", history.get(0).content);
    }

    @Test public void splitMessages_lastNotUser_goesHistory_promptEmpty() throws Exception {
        org.json.JSONArray msgs = new org.json.JSONArray()
                .put(new JSONObject().put("role", "user").put("content", "问题"))
                .put(new JSONObject().put("role", "assistant").put("content", "回答"));
        java.util.List<com.hermes.android.ai.AiClient.Message> history = new java.util.ArrayList<>();
        StringBuilder prompt = new StringBuilder();
        MovInboundServer.splitInferMessages(msgs, history, prompt);
        assertEquals("末条非 user → prompt 空", "", prompt.toString());
        assertEquals("末条非 user 进 history", 2, history.size());
        assertEquals("assistant", history.get(1).role);
    }

    @Test public void splitMessages_emptyContentSkipped() throws Exception {
        org.json.JSONArray msgs = new org.json.JSONArray()
                .put(new JSONObject().put("role", "user").put("content", "有内容"))
                .put(new JSONObject().put("role", "assistant").put("content", ""))
                .put(new JSONObject().put("role", "user").put("content", "末条"));
        java.util.List<com.hermes.android.ai.AiClient.Message> history = new java.util.ArrayList<>();
        StringBuilder prompt = new StringBuilder();
        MovInboundServer.splitInferMessages(msgs, history, prompt);
        assertEquals("prompt = 末条", "末条", prompt.toString());
        assertEquals("空 content 跳过 → history 只有 1 条", 1, history.size());
    }

    @Test public void splitMessages_nullMessages_ok() {
        java.util.List<com.hermes.android.ai.AiClient.Message> history = new java.util.ArrayList<>();
        StringBuilder prompt = new StringBuilder();
        MovInboundServer.splitInferMessages(null, history, prompt);
        assertEquals(0, history.size());
        assertEquals("", prompt.toString());
    }

    @Test public void memory_implemented_noContext_errorsGracefully() throws Exception {
        /* C1: /memory 已实现；测试传 null context（无 StorageManager）→ 错误信封，不许崩 */
        MovInboundServer.Response r = server(new HashMap<>())
                .dispatch("POST", "/memory", new JSONObject().put("action", "read")
                        .put("roomId", "r1"), TOKEN, loopback());
        assertEquals(200, r.status);
        assertFalse(new JSONObject(r.body).optBoolean("ok"));
    }

    // ==================== 工单7 G15: /memory distill 懒生成调度入口 ====================

    @Test public void memory_distill_noContext_errorsGracefully() throws Exception {
        /* G15: /memory distill 已实现；测试传 null context（无 StorageManager/模型）→ 错误信封，不许崩 */
        MovInboundServer.Response r = server(new HashMap<>())
                .dispatch("POST", "/memory", new JSONObject().put("action", "distill")
                        .put("roomId", "rX"), TOKEN, loopback());
        assertEquals(200, r.status);
        JSONObject b = new JSONObject(r.body);
        assertFalse(b.optBoolean("ok"));
        assertEquals("NO_CONTEXT", b.optJSONObject("error").optString("code"));
    }

    @Test public void runDistill_withFakeBrain_injectsFrozenSummary() throws Exception {
        // G15 正路径（禁 mock LLM，fake Brain 只是替身）：临时目录 Journal + fake Brain →
        // 透传 distillMemory → _memory_summary 冻结注入（原文 journal 不动）
        java.io.File roomsDir = java.nio.file.Files.createTempDirectory("g15_d").toFile();
        com.hermes.android.agent.Journal j = new com.hermes.android.agent.Journal(roomsDir);
        j.appendDraft("rX", "记忆甲", "memory");
        j.appendDraft("rX", "记忆乙", "memory");
        j.appendDraft("rX", "记忆丙", "memory");
        JSONObject res = MovInboundServer.runDistill(j, "rX", 1, (s, u) -> "浓缩摘要");
        assertTrue("应成功注入", res.optBoolean("ok"));
        assertTrue("注入 seq > 0", res.optInt("seq") > 0);
        org.json.JSONArray evs = j.replay("rX", 50).optJSONObject("data").optJSONArray("events");
        boolean found = false;
        for (int i = 0; i < evs.length(); i++) {
            if (com.hermes.android.agent.Journal.TYPE_MEMORY_SUMMARY.equals(
                    evs.optJSONObject(i).optString("type"))) found = true;
        }
        assertTrue("_memory_summary 事件已注入", found);
    }

    @Test public void runDistill_nullBrain_notConfigured() throws Exception {
        java.io.File roomsDir = java.nio.file.Files.createTempDirectory("g15_n").toFile();
        com.hermes.android.agent.Journal j = new com.hermes.android.agent.Journal(roomsDir);
        JSONObject res = MovInboundServer.runDistill(j, "rX", 1, null);
        assertFalse("无 Brain → 失败", res.optBoolean("ok"));
        assertEquals("NOT_CONFIGURED", res.optJSONObject("error").optString("code"));
    }

    @Test public void unknownRoute_404() throws Exception {
        MovInboundServer.Response r = server(new HashMap<>())
                .dispatch("GET", "/nope", null, TOKEN, loopback());
        assertEquals(404, r.status);
    }

    // ==================== ① socket 级: 多字节 UTF-8 (中文) body (R4 打回修复回归) ====================

    /**
     * 真机实踩: 旧实现把 Content-Length (字节数) 当字符数, 用 BufferedReader 按字符读 body,
     * 中文参数永远凑不够 → 连接挂死到客户端超时 (causal.record 中文参数 120s 无响应)。
     * 本用例走真实 socket: 发中文 body, 断言 200 且参数完好到达 handler。
     * 变异亲杀: 恢复旧字符级读取后本用例必红 (读超时)。
     */
    @Test public void handle_chineseUtf8Body_200AndParamIntact() throws Exception {
        final String[] captured = new String[1];
        AgentLoop.Tools tools = new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return "[]"; }
            @Override public String fileRead(String roomId, String path) { return ""; }
            @Override public String fileWrite(String roomId, String path, String c) { return "OK:"; }
            @Override public String capabilityOf(String text) { return ""; }
            @Override public String deviceCmd(String text) { return "ok"; }
            @Override public String packageApk(String roomId, String path, String n) { return "{\"ok\":false}"; }
            @Override public String shellExec(String cmd, int timeoutSec) {
                captured[0] = cmd;
                return "exit=0\n收到了";
            }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":false}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":false}"; }
        };
        ToolRegistry registry = ToolRegistry.build(tools, "room1", HashSet::new,
                ToolRegistry.policyForTest(Collections.<String>emptySet()), true);
        MovInboundServer s = new MovInboundServer(registry, TOKEN, null);
        assertTrue("测试 server 应能绑定 8388", s.start());
        try {
            String cmd = "记录：验收员登记了P4真机欠账，金额5000元";   // 全中文多字节
            byte[] body = new JSONObject().put("params", new JSONObject().put("cmd", cmd))
                    .toString().getBytes("UTF-8");
            String head = "POST /tools/shell.exec/invoke HTTP/1.1\r\n"
                    + "Host: 127.0.0.1\r\n"
                    + "X-Mov-Token: " + TOKEN + "\r\n"
                    + "Content-Type: application/json\r\n"
                    + "Content-Length: " + body.length + "\r\n\r\n";
            java.net.Socket sock = new java.net.Socket("127.0.0.1", MovInboundServer.PORT);
            sock.setSoTimeout(8000);   // 旧实现在此必超时 → 红
            try {
                java.io.OutputStream out = sock.getOutputStream();
                out.write(head.getBytes("UTF-8"));
                out.write(body);
                out.flush();
                java.io.ByteArrayOutputStream resp = new java.io.ByteArrayOutputStream();
                java.io.InputStream in = sock.getInputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) != -1) resp.write(buf, 0, n);   // 读到 server 关连接
                String text = resp.toString("UTF-8");
                assertTrue("必须 200: " + text, text.startsWith("HTTP/1.1 200"));
                JSONObject b = new JSONObject(text.substring(text.indexOf("\r\n\r\n") + 4));
                assertTrue("信封 ok: " + text, b.optBoolean("ok"));
                assertEquals("中文参数必须完好到达 handler", cmd, captured[0]);
            } finally {
                sock.close();
            }
        } finally {
            s.stop();
        }
    }

    // ==================== 工单9 幕一 单表化: 8388 查的表含技能工具 → skill.echo 可调（销账工单4 批2 缺口①） ====================

    @Test public void invoke_skillEchoWhenRegistered() throws Exception {
        // 8388 的表（RegistryProvider 统一构建源已激活内置技能）含 skill.echo 时, /tools/skill.echo/invoke 应可调(非 TOOL_NOT_FOUND)
        ToolRegistry reg = registryWithShell(new HashMap<>());
        String skillJson = "{\"name\":\"mov-demo\",\"tools\":[{\"name\":\"skill.echo\",\"description\":\"回显\"}]}";
        int n = com.hermes.android.skill.SkillActivator.activate(reg, skillJson);
        assertEquals("skill.echo 应注册", 1, n);
        MovInboundServer s = new MovInboundServer(reg, TOKEN, null);
        JSONObject body = new JSONObject().put("params", new JSONObject().put("text", "hi"));
        MovInboundServer.Response resp = s.dispatch("POST", "/tools/skill.echo/invoke", body, TOKEN, loopback());
        assertEquals(200, resp.status);
        JSONObject b = new JSONObject(resp.body);
        assertTrue("skill.echo 应调用成功", b.optBoolean("ok"));
        assertTrue("回显内容", b.toString().contains("echo:hi"));
    }

    @Test public void invoke_skillEcho_notRegistered_stillNotFound() throws Exception {
        // 对照组: 表里无技能 → TOOL_NOT_FOUND(404)（单表化后 8388 查的是含技能的表, 此用例保证"查表"语义不误伤缺失工具）
        ToolRegistry reg = registryWithShell(new HashMap<>());
        MovInboundServer s = new MovInboundServer(reg, TOKEN, null);
        JSONObject body = new JSONObject().put("params", new JSONObject());
        MovInboundServer.Response resp = s.dispatch("POST", "/tools/skill.echo/invoke", body, TOKEN, loopback());
        assertEquals(404, resp.status);
        assertFalse(new JSONObject(resp.body).optBoolean("ok"));
    }

    // ==================== 工单9 幕一 出网网关: 8388 /v1/chat/completions（OpenAI 兼容, 客居 agent LLM 通道） ====================

    @Test public void openaiCompatible_noContext_errorsGracefully() throws Exception {
        /* 出网网关端点已实现; context null(无默认模型)→ 错误信封, 不许崩 */
        MovInboundServer.Response r = server(new HashMap<>())
                .dispatch("POST", "/v1/chat/completions",
                        new JSONObject().put("messages",
                                new org.json.JSONArray().put(new JSONObject()
                                        .put("role", "user").put("content", "hi"))),
                        TOKEN, loopback());
        assertEquals(200, r.status);
        JSONObject b = new JSONObject(r.body);
        assertFalse(b.optBoolean("ok"));
        String code = b.optJSONObject("error").optString("code", "");
        assertTrue("code 应为 NOT_CONFIGURED 或 INFER_ERROR: " + code,
                "NOT_CONFIGURED".equals(code) || "INFER_ERROR".equals(code));
    }

    @Test public void openaiCompatible_emptyMessages_badRequest() throws Exception {
        MovInboundServer.Response r = server(new HashMap<>())
                .dispatch("POST", "/v1/chat/completions",
                        new JSONObject().put("messages", new org.json.JSONArray()), TOKEN, loopback());
        assertEquals(200, r.status);
        assertEquals("BAD_REQUEST", new JSONObject(r.body).optJSONObject("error").optString("code"));
    }
}
