package com.hermes.android;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * H1 一致性单测（DESIGN_TOOL_HEALTH §二）——构建期防线。
 * 规则：代码硬编码引用的源/工具 id 必须 ⊆ 注册表。
 * mayi91 场景复现：临时删掉 video_sources.json 里 mayi91 条目 → 本测试必须红。
 * 防假覆盖：读真实 assets/video_sources.json + 真实 ToolRegistry 注册表（非副本）。
 */
public class ToolHealthConsistencyTest {

    /** 集中常量表：代码硬编码引用的源 id（DramaSource/BridgeDevice 的 registry.isUsable/开关引用） */
    static final String[] HARDCODED_SOURCE_IDS = {
            "mayi91", "douban", "bilibili", "douyin", "ddg", "tencent", "iqiyi",
    };

    /** 集中常量表：桥硬编码转发的工具 id（BridgeKernel fastRegistry().find） */
    static final String[] HARDCODED_TOOL_IDS = {
            "train_search", "music_search", "watch_history", "drama_memory",
            "face_history", "face_mine",
    };

    private static Set<String> readVideoSourceIds() throws Exception {
        File f = new File("src/main/assets/video_sources.json");
        assertTrue("真实 assets 必须存在（非副本）: " + f.getAbsolutePath(), f.exists());
        JSONObject root = new JSONObject(
                new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
        JSONArray sources = root.getJSONArray("sources");
        Set<String> ids = new HashSet<>();
        for (int i = 0; i < sources.length(); i++) {
            ids.add(sources.getJSONObject(i).optString("id", ""));
        }
        return ids;
    }

    private static ToolRegistry buildRegistry() {
        return ToolRegistry.build(new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return "[]"; }
            @Override public String fileRead(String roomId, String path) { return ""; }
            @Override public String fileWrite(String roomId, String path, String c) { return "OK:"; }
            @Override public String capabilityOf(String text) { return "unknown"; }
            @Override public String deviceCmd(String text) { return "ok"; }
            @Override public String packageApk(String roomId, String path, String appName) { return "ERR:"; }
            @Override public String shellExec(String cmd, int timeoutSec) { return "exit=0\n"; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":true}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":true}"; }
        }, "room1", HashSet::new, new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
    }

    @Test public void hardcodedSourceIds_areInVideoSourcesJson() throws Exception {
        Set<String> registered = readVideoSourceIds();
        for (String id : HARDCODED_SOURCE_IDS) {
            assertTrue("代码硬编码引用源 id 必须在 video_sources.json 注册: " + id
                    + "（mayi91 场景：删注册条目 → 本测试红）", registered.contains(id));
        }
    }

    @Test public void hardcodedToolIds_areRegisteredInToolRegistry() {
        ToolRegistry r = buildRegistry();
        for (String id : HARDCODED_TOOL_IDS) {
            assertNotNull("桥转发工具 id 必须在 ToolRegistry 注册: " + id, r.find(id));
        }
    }
}
