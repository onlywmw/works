package com.hermes.android.agent;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * ARCH_DEBT #6: 状态转换矩阵穷举。
 * 64 种 State×State 组合, 3 分钟内跑完, 替代 24h 冷静期。
 */
public class AgentStateTransitionTest {

    private static final AgentLoop.State[][] LEGAL = {
        {AgentLoop.State.PLANNING, AgentLoop.State.PLAN_GATE},
        {AgentLoop.State.PLANNING, AgentLoop.State.FAILED},
        {AgentLoop.State.PLANNING, AgentLoop.State.STOPPED},
        {AgentLoop.State.PLAN_GATE, AgentLoop.State.EXECUTING},
        {AgentLoop.State.PLAN_GATE, AgentLoop.State.FAILED},   // P1#6: 计划阶段 failMov 允许 → FAILED（防 IllegalStateException 崩溃）
        {AgentLoop.State.PLAN_GATE, AgentLoop.State.STOPPED},
        {AgentLoop.State.EXECUTING, AgentLoop.State.PAUSED},
        {AgentLoop.State.EXECUTING, AgentLoop.State.DONE},
        {AgentLoop.State.EXECUTING, AgentLoop.State.FAILED},
        {AgentLoop.State.EXECUTING, AgentLoop.State.STOPPED},
        {AgentLoop.State.EXECUTING, AgentLoop.State.PLAN_GATE},
        {AgentLoop.State.PAUSED, AgentLoop.State.EXECUTING},
        {AgentLoop.State.PAUSED, AgentLoop.State.STOPPED},
        {AgentLoop.State.RECOVERY, AgentLoop.State.EXECUTING},
        {AgentLoop.State.RECOVERY, AgentLoop.State.FAILED},
        {AgentLoop.State.RECOVERY, AgentLoop.State.STOPPED},
        {AgentLoop.State.RECOVERY, AgentLoop.State.PLANNING},   // BUG-5: recovery→planning 构造链
        {AgentLoop.State.PLANNING, AgentLoop.State.RECOVERY},    // BUG-5: planning→recovery 构造链
    };

    @Test
    public void legalTransitions_pass() {
        for (AgentLoop.State[] pair : LEGAL) {
            assertTrue(pair[0] + "→" + pair[1], pair[0].canTransitionTo(pair[1]));
        }
    }

    @Test
    public void illegalTransitions_fail() {
        AgentLoop.State[] all = AgentLoop.State.values();
        java.util.Set<String> leg = new java.util.HashSet<>();
        for (AgentLoop.State[] p : LEGAL) leg.add(p[0] + "→" + p[1]);
        for (AgentLoop.State f : all)
            for (AgentLoop.State t : all)
                if (f != t && !leg.contains(f + "→" + t))
                    assertFalse(f + "→" + t, f.canTransitionTo(t));
    }

    @Test
    public void terminals_done_fail_stopped() {
        assertTrue(AgentLoop.State.DONE.isTerminal());
        assertTrue(AgentLoop.State.FAILED.isTerminal());
        assertTrue(AgentLoop.State.STOPPED.isTerminal());
        assertFalse(AgentLoop.State.PLANNING.isTerminal());
        assertFalse(AgentLoop.State.EXECUTING.isTerminal());
    }

    @Test
    public void ctx_transition_legal() {
        AgentContext ctx = new AgentContext();
        ctx.transition(AgentLoop.State.PLAN_GATE);
        assertEquals(AgentLoop.State.PLAN_GATE, ctx.getState());
        ctx.transition(AgentLoop.State.EXECUTING);
        assertEquals(AgentLoop.State.EXECUTING, ctx.getState());
    }

    @Test(expected = IllegalStateException.class)
    public void ctx_transition_illegal_throws() {
        new AgentContext().transition(AgentLoop.State.DONE);
    }

    @Test(expected = IllegalStateException.class)
    public void ctx_reset_active_throws() {
        new AgentContext().reset(); // PLANNING is active
    }

    @Test
    public void ctx_reset_terminal_ok() {
        AgentContext ctx = new AgentContext();
        ctx.transition(AgentLoop.State.PLAN_GATE);
        ctx.transition(AgentLoop.State.EXECUTING);
        ctx.transition(AgentLoop.State.DONE);
        ctx.reset();
        assertEquals(AgentLoop.State.PLANNING, ctx.getState());
    }

    @Test
    public void stopped_isTerminal_canReset() {
        AgentContext ctx = new AgentContext();
        ctx.transition(AgentLoop.State.PLAN_GATE);
        ctx.transition(AgentLoop.State.EXECUTING);
        ctx.transition(AgentLoop.State.STOPPED);
        assertTrue(AgentLoop.State.STOPPED.isTerminal());
        ctx.reset();
        assertEquals(AgentLoop.State.PLANNING, ctx.getState());
    }
}
