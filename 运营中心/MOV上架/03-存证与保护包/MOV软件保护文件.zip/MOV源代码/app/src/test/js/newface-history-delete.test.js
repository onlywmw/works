/* ============================================================
   newface-history-delete 防回归测试（node）
   跑法: node app/src/test/js/newface-history-delete.test.js
   用户报障 2026-08-07: 左侧栏（新脸抽屉 history  tab）对话历史无法删除——
   条目原只有 onclick 回放，无删除入口。修复: data-hroom 标记 + 长按绑定
   + 确认 sheet + room_destroy 删房链路 + 重拉 face_history 刷新。
   ============================================================ */
'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const SRC = fs.readFileSync(path.join(__dirname, '../../main/assets/js/newface.js'), 'utf8');

function extractFn(name) {
  const i = SRC.indexOf('function ' + name + '(');
  assert.ok(i >= 0, '找不到 function ' + name);
  let depth = 0, j = SRC.indexOf('{', i);
  for (let k = j; k < SRC.length; k++) {
    if (SRC[k] === '{') depth++;
    else if (SRC[k] === '}') { depth--; if (depth === 0) return SRC.slice(i, k + 1); }
  }
  throw new Error(name + ' 函数体未闭合');
}

const DRAWER = extractFn('openDrawer');
const BIND = extractFn('bindHistoryLongPress');
const DEL = extractFn('historyRoomDelete');
const REPLAY = extractFn('replayConversation');

/* ① 历史条目必须带 data-hroom（长按绑定与删除的目标标识） */
assert.ok(DRAWER.includes('data-hroom'),
  'openDrawer history 分支: 历史条目必须带 data-hroom 属性（否则长按删除无目标）');

/* ② history 分支渲染后必须绑长按（否则删除入口不可达） */
assert.ok(DRAWER.includes('bindHistoryLongPress(content)'),
  'openDrawer history 分支: content.innerHTML 后必须调 bindHistoryLongPress');

/* ③ 长按手势: 500ms 触发 + 移动取消 + 抑制随后 click（同专家房卡手感） */
assert.ok(BIND.includes('500'), 'bindHistoryLongPress 必须是 500ms 长按');
assert.ok(BIND.includes('touchmove'), 'bindHistoryLongPress 必须有移动取消（滚动不误触）');
assert.ok(BIND.includes('_histLp = true'), 'bindHistoryLongPress 必须置 _histLp 抑制随后 click');

/* ④ 删除必须过确认 sheet（红线: 破坏性操作需用户确认）且走完整删房链路；
   且必须先 closeDrawer——抽屉 z-20 会盖住确认 sheet（2026-08-07 真机截图实证） */
assert.ok(DEL.includes('expertConfirm'), 'historyRoomDelete 必须过确认 sheet（不可一点就删）');
assert.ok(DEL.indexOf('closeDrawer()') >= 0 && DEL.indexOf('closeDrawer()') < DEL.indexOf('expertConfirm'),
  'historyRoomDelete 必须先 closeDrawer 再弹确认（否则 sheet 被抽屉 z-20 遮挡不可见）');
assert.ok(DEL.includes('B.roomDestroy(roomId)'), 'historyRoomDelete 必须调 room_destroy 拆磁盘房间');
assert.ok(DEL.includes("openDrawer('history')"), 'historyRoomDelete 删除后必须重拉 face_history 刷新列表');

/* ⑤ 回放入口必须吃 _histLp 守卫（长按后手指抬起不触发回放） */
assert.ok(REPLAY.includes('_histLp'), 'replayConversation 必须有 _histLp 守卫');

/* ⑥ 确认 sheet 必须保底建 overlay（2026-08-07 真机实证：overlay 原只在进专家模式时
   懒建，home 左侧栏长按删除时 expertConfirm 静默 return = 「删除不了」真根因） */
const CONFIRM = extractFn('expertConfirm');
const ENSURE = extractFn('ensureExpertOverlay');
assert.ok(CONFIRM.includes('ensureExpertOverlay()'),
  'expertConfirm 必须先 ensureExpertOverlay()（home 视图 overlay 未建时确认 sheet 静默失败）');
assert.ok(ENSURE.includes('expertPreviewOverlay'),
  'ensureExpertOverlay 必须创建 #expertPreviewOverlay');
assert.ok(ENSURE.includes("getElementById('view-face')"),
  'ensureExpertOverlay 必须挂 #view-face 直接子级（home 与专家共用）');

console.log('左侧栏历史删除 ✓（data-hroom 标记 / 长按绑定 / 确认闸 / room_destroy 链路 / 删后刷新 / click 抑制 / overlay 保底建）');
