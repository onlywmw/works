package com.hermes.android.agent;

import static org.junit.Assert.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.io.File;
import java.nio.file.Files;

/**
 * 工单12 健身竖闭环 MOV 侧核心（幕一落账 + 幕二周叙事 prompt 纯函数）。
 * 变异亲杀: 落账/记录缺失 → 必红。
 */
public class JournalFitnessTest {

    @Test public void fitnessIngest_landsFitnessDomainReceipt() throws Exception {
        File roomsDir = Files.createTempDirectory("fit").toFile();
        Journal j = new Journal(roomsDir);
        int seq = j.fitnessIngest("r1", "体重 70kg, 跑了 5 公里");
        assertTrue("入账 seq > 0", seq > 0);
        JSONArray receipts = j.domainReceipts("r1", "fitness");
        assertEquals("fitness 域 1 条 receipt", 1, receipts.length());
        assertTrue("payload 含原文", receipts.optJSONObject(0).optString("payload").contains("5 公里"));
        assertEquals("tool=ocr.local", "ocr.local", receipts.optJSONObject(0).optString("tool"));
    }

    @Test public void fitnessIngest_emptyText_rejected() throws Exception {
        File roomsDir = Files.createTempDirectory("fit2").toFile();
        assertEquals("空文本拒写", -2, new Journal(roomsDir).fitnessIngest("r1", "   "));
    }

    @Test public void weeklyNarrativePrompt_includesRecords() throws Exception {
        JSONArray r = new JSONArray()
                .put(new JSONObject().put("payload", "跑步 5km"))
                .put(new JSONObject().put("payload", "深蹲 3 组"));
        String p = Journal.weeklyNarrativePrompt("fitness", r);
        assertTrue("含域标签", p.contains("fitness"));
        assertTrue("含记录 1", p.contains("跑步 5km"));
        assertTrue("含记录 2", p.contains("深蹲 3 组"));
        assertTrue("含趋势要求", p.contains("趋势"));
    }

    @Test public void weeklyNarrativePrompt_emptyReceipts_headerOnly() throws Exception {
        String p = Journal.weeklyNarrativePrompt("fitness", new JSONArray());
        assertTrue("空记录只有头", p.contains("fitness"));
        assertFalse("无记录项", p.contains("- "));
    }
}
