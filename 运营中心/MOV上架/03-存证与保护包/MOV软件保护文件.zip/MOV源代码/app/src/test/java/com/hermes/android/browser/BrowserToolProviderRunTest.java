package com.hermes.android.browser;

import com.hermes.android.agent.ToolRegistry;

import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

/**
 * BrowserToolProvider runBrowser 接缝单测（P1 W2）——不触碰 ConnectWebActivity/Android stub。
 * 注入 fake ConnectWebSource，验证：open 未开→自动拉起 / 空 url 拒 / 非 open 未开→引导先 open /
 * open 已开→导航不重复拉起。@After 恢复默认源 + 关窗（防静态污染）。
 */
public class BrowserToolProviderRunTest {

    /** fake executor：setJavaCallback 同步回调（无线程/Looper，latch 立即释放） */
    private static class FakeExecutor implements BrowserToolProvider.BrowserExecutor {
        final String result;
        final List<String> actions = new ArrayList<>();

        FakeExecutor(String result) { this.result = result; }

        @Override public void setJavaCallback(String cbId, java.util.function.Consumer<String> cb) {
            if (cb != null) cb.accept(result);
        }
        @Override public void clearJavaCallback(String cbId) {}
        @Override public void executeBrowserAction(String actionJson, String cbId) {
            actions.add(actionJson);
        }
    }

    /** fake 源：可控 current/launch */
    private static class FakeSource implements BrowserToolProvider.ConnectWebSource {
        BrowserToolProvider.BrowserExecutor executor;
        boolean launchCalled = false;
        String lastUrl;
        String lastPlatform;
        String lastKeyword;

        @Override public BrowserToolProvider.BrowserExecutor current() { return executor; }
        @Override public boolean launch(String url, String platform, String keyword) {
            launchCalled = true;
            lastUrl = url;
            lastPlatform = platform;
            lastKeyword = keyword;
            executor = new FakeExecutor("{\"opened\":true}");
            return true;
        }
    }

    private FakeSource source;
    private BrowserToolProvider provider;

    @Before public void setUp() {
        ToolRuntimeLimits.closeWindow();
        source = new FakeSource();
        BrowserToolProvider.setConnectWebSource(source);
        provider = new BrowserToolProvider();
    }

    @After public void tearDown() {
        ToolRuntimeLimits.closeWindow();
        BrowserToolProvider.resetConnectWebSource();
    }

    private ToolRegistry.Tool tool(String name) {
        for (ToolRegistry.Tool t : provider.discover()) {
            if (t.name.equals(name)) return t;
        }
        return null;
    }

    private ToolRegistry.Result run(String name, String argsJson) throws Exception {
        ToolRegistry.Tool t = tool(name);
        assertNotNull("工具应存在: " + name, t);
        return t.handler.run(argsJson == null ? new JSONObject() : new JSONObject(argsJson));
    }

    @Test public void open_whenClosed_launchesAndSucceeds() throws Exception {
        ToolRegistry.Result r = run("browser.open", "{\"url\":\"https://www.douyin.com/\"}");
        assertTrue("open 未开应拉起并成功: " + r.text, r.ok);
        assertTrue("应触发 launch", source.launchCalled);
        assertEquals("URL 传给 launch", "https://www.douyin.com/", source.lastUrl);
        assertTrue("open 应开窗", ToolRuntimeLimits.windowOpen());
    }

    @Test public void open_whenClosed_missingUrl_rejected() throws Exception {
        ToolRegistry.Result r = run("browser.open", "{}");
        assertFalse("空 url 且空 platform/keyword 应拒", r.ok);
        assertTrue("提示需要 url/platform+keyword: " + r.text, r.text.contains("platform"));
        assertTrue("提示含 url", r.text.contains("url"));
        assertFalse("不应触发 launch", source.launchCalled);
    }

    @Test public void open_whenClosed_platformKeyword_launches() throws Exception {
        ToolRegistry.Result r = run("browser.open", "{\"platform\":\"douyin\",\"keyword\":\"庆余年 评价\"}");
        assertTrue("platform+keyword 应拉起并成功: " + r.text, r.ok);
        assertTrue("应触发 launch", source.launchCalled);
        assertEquals("platform 传给 launch", "douyin", source.lastPlatform);
        assertEquals("keyword 传给 launch", "庆余年 评价", source.lastKeyword);
        assertTrue("open 应开窗", ToolRuntimeLimits.windowOpen());
    }

    @Test public void snapshot_whenClosed_guidesToOpen() throws Exception {
        ToolRegistry.Result r = run("browser.snapshot", null);
        assertFalse("未开浏览器非 open 工具应拒", r.ok);
        assertTrue("引导先 browser.open: " + r.text, r.text.contains("browser.open"));
        assertFalse("不应触发 launch", source.launchCalled);
    }

    @Test public void open_whenAlreadyOpen_navigates() throws Exception {
        source.executor = new FakeExecutor("{\"opened\":true}");
        ToolRegistry.Result r = run("browser.open", "{\"url\":\"https://m.jd.com/\"}");
        assertTrue("已开浏览器 open 应成功", r.ok);
        assertFalse("不应重复 launch", source.launchCalled);
        assertTrue("open 应开窗", ToolRuntimeLimits.windowOpen());
    }

    @Test public void read_whenOpen_succeeds() throws Exception {
        source.executor = new FakeExecutor("正文内容");
        ToolRegistry.Result r = run("browser.read", null);
        assertTrue("已开浏览器 read 应成功: " + r.text, r.ok);
    }
}
