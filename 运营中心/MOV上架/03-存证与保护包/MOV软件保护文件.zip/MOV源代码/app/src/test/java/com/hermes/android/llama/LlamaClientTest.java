package com.hermes.android.llama;

import org.json.JSONObject;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * llama-server 客户端核心单测（纯 JVM，零网络注入式）——OpenAI payload/响应解析/错误映射。
 */
public class LlamaClientTest {

    @Test public void buildChatPayload_openAIFormat() throws Exception {
        String p = LlamaClient.buildChatPayload("unlimited-ocr", "识别这行字", 256);
        JSONObject o = new JSONObject(p);
        assertEquals("model", "unlimited-ocr", o.getString("model"));
        assertEquals("user content", "识别这行字",
                o.getJSONArray("messages").getJSONObject(0).getString("content"));
        assertEquals("role=user", "user",
                o.getJSONArray("messages").getJSONObject(0).getString("role"));
        assertEquals("max_tokens", 256, o.getInt("max_tokens"));
    }

    @Test public void buildChatPayload_defaults() throws Exception {
        String p = LlamaClient.buildChatPayload(null, "x", 0);
        JSONObject o = new JSONObject(p);
        assertEquals("默认模型", LlamaClient.DEFAULT_MODEL, o.getString("model"));
        assertEquals("默认 max_tokens 256", 256, o.getInt("max_tokens"));
    }

    @Test public void parseResponse_extractsContent() {
        String raw = "{\"choices\":[{\"message\":{\"content\":\"识别结果\"}}]}";
        assertEquals("识别结果", LlamaClient.parseResponse(raw));
    }

    @Test public void parseResponse_emptyOrInvalidNull() {
        assertNull("空 choices", LlamaClient.parseResponse("{\"choices\":[]}"));
        assertNull("非法 JSON", LlamaClient.parseResponse("not json"));
        assertNull("null", LlamaClient.parseResponse(null));
    }

    @Test public void mapError_honestCards() {
        assertEquals("连接失败诚实卡", "OCR 服务连不上（llama-server 未启动）", LlamaClient.mapError(-1, null));
        assertEquals("token 鉴权失败", "OCR 服务 token 鉴权失败，检查设置页", LlamaClient.mapError(401, ""));
        assertEquals("服务端异常", "OCR 服务异常（500），稍后再试", LlamaClient.mapError(500, ""));
        assertEquals("400 参数", "OCR 请求被拒（400），参数或模型名不对", LlamaClient.mapError(400, ""));
    }

    // ═══ 工单12 幕四: 视觉 payload 构造(纯函数) ═══

    @Test public void buildVisionPayload_includesImageAndText() {
        String p = LlamaClient.buildVisionPayload(null, "识别图片中的文字", "QUJDREVG", 512);
        assertTrue("含 image_url", p.contains("image_url"));
        assertTrue("含 data:image/jpeg;base64", p.contains("data:image/jpeg;base64,QUJDREVG"));
        assertTrue("含文本提示", p.contains("识别图片中的文字"));
        assertTrue("含 max_tokens", p.contains("\"max_tokens\":512"));
    }

    @Test public void buildVisionPayload_emptyText_omitsTextBlock() {
        String p = LlamaClient.buildVisionPayload(null, "", "QUJD", 256);
        assertFalse("空文本不输出 text block", p.contains("\"type\":\"text\""));
        assertTrue("仍含图像", p.contains("data:image/jpeg;base64,QUJD"));
    }
}
