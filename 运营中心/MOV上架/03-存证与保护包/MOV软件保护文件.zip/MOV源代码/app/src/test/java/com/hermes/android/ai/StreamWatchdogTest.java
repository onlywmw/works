package com.hermes.android.ai;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * StreamWatchdog 单测: 阈值/停滞/熔断/双速退避/分类/开火顺序。
 */
public class StreamWatchdogTest {

    // ==================== 阈值与开火顺序 ====================

    @Test
    public void thresholds_perMode() {
        assertEquals(180_000, StreamWatchdog.stallThresholdMs(StreamWatchdog.Mode.STREAM));
        assertEquals(300_000, StreamWatchdog.stallThresholdMs(StreamWatchdog.Mode.REASONING));
        assertEquals(600_000, StreamWatchdog.stallThresholdMs(StreamWatchdog.Mode.LOCAL));
        assertEquals(90_000, StreamWatchdog.stallThresholdMs(StreamWatchdog.Mode.NON_STREAM));
    }

    @Test
    public void readTimeout_exceedsThreshold() {
        /* 红线: readTimeout 永远 ≥ 阈值+30s, 看门狗先开火, 禁反转 */
        for (StreamWatchdog.Mode m : StreamWatchdog.Mode.values()) {
            assertTrue("readTimeout 必须 ≥ 阈值+30s: " + m,
                    StreamWatchdog.readTimeoutMs(m) >= StreamWatchdog.stallThresholdMs(m) + 30_000);
        }
    }

    @Test
    public void stallDetection_onlyRealChunkResets() {
        StreamWatchdog w = new StreamWatchdog(StreamWatchdog.Mode.STREAM);
        long t0 = 1_000_000L;
        w.recordChunk(t0);
        assertFalse(w.isStalled(t0 + 179_999));
        assertFalse("60s 无 chunk 不得误杀 (TC-SSE-02)", w.isStalled(t0 + 60_000));
        assertTrue("181s 无 chunk 必须触发 (TC-SSE-03)", w.isStalled(t0 + 181_000));
    }

    @Test
    public void circuitBreaksAtFive() {
        /* TC-SSE-04: 连续 5 次停滞熔断 */
        StreamWatchdog w = new StreamWatchdog(StreamWatchdog.Mode.STREAM);
        for (int i = 0; i < 4; i++) {
            w.noteStall();
            assertFalse("第 " + (i + 1) + " 次停滞不应熔断", w.isCircuitBroken());
        }
        w.noteStall();
        assertTrue("第 5 次停滞必须熔断", w.isCircuitBroken());
    }

    // ==================== 快退避 ====================

    @Test
    public void fastBackoff_sequence() {
        assertEquals(300, StreamWatchdog.fastBackoffMs(0, 0.0));
        assertEquals(600, StreamWatchdog.fastBackoffMs(1, 0.0));
        assertEquals(1200, StreamWatchdog.fastBackoffMs(2, 0.0));
        assertEquals(-1, StreamWatchdog.fastBackoffMs(3, 0.0));
        assertEquals(-1, StreamWatchdog.fastBackoffMs(99, 0.0));
    }

    @Test
    public void fastBackoff_cappedAndJittered() {
        /* 第 4 次起耗尽: 合同序列 300→600→1200 共 3 次 */
        assertEquals(-1, StreamWatchdog.fastBackoffMs(3, 0.0));
        long j = StreamWatchdog.fastBackoffMs(0, 1.0);
        assertEquals("jitter +50%", 450, j);
    }

    // ==================== 限流退避 ====================

    @Test
    public void rateLimit_respectsRetryAfter() {
        /* TC-SSE-10: Retry-After:5 → 恰 5s, 不提前 */
        assertEquals(5000, StreamWatchdog.rateLimitBackoffMs(0, 5));
        assertEquals(5000, StreamWatchdog.rateLimitBackoffMs(1, 5));
    }

    @Test
    public void rateLimit_retryAfterCapped() {
        assertEquals(600_000, StreamWatchdog.rateLimitBackoffMs(0, 9999));
    }

    @Test
    public void rateLimit_noHeaderLongBackoff() {
        assertEquals(30_000, StreamWatchdog.rateLimitBackoffMs(0, 0));
        assertEquals(60_000, StreamWatchdog.rateLimitBackoffMs(1, 0));
        assertEquals(120_000, StreamWatchdog.rateLimitBackoffMs(2, 0));
        assertEquals(-1, StreamWatchdog.rateLimitBackoffMs(3, 0));
    }

    // ==================== 错误分类 ====================

    @Test
    public void classify_http() {
        assertEquals(StreamWatchdog.ErrorClass.PROVIDER_AUTH, StreamWatchdog.classifyHttp(401));
        assertEquals(StreamWatchdog.ErrorClass.PROVIDER_AUTH, StreamWatchdog.classifyHttp(403));
        assertEquals(StreamWatchdog.ErrorClass.RATE_LIMIT, StreamWatchdog.classifyHttp(429));
        assertEquals(StreamWatchdog.ErrorClass.MODEL_CONFIG, StreamWatchdog.classifyHttp(400));
        assertEquals(StreamWatchdog.ErrorClass.MODEL_CONFIG, StreamWatchdog.classifyHttp(404));
        assertEquals(StreamWatchdog.ErrorClass.PROVIDER_API, StreamWatchdog.classifyHttp(500));
        assertEquals(StreamWatchdog.ErrorClass.PROVIDER_API, StreamWatchdog.classifyHttp(503));
    }

    @Test
    public void classify_throwable() {
        assertEquals(StreamWatchdog.ErrorClass.PROVIDER_CONNECTION,
                StreamWatchdog.classifyError(new java.net.SocketTimeoutException("x")));
        assertEquals(StreamWatchdog.ErrorClass.PROVIDER_CONNECTION,
                StreamWatchdog.classifyError(new java.net.ConnectException("x")));
        assertEquals(StreamWatchdog.ErrorClass.RUNTIME,
                StreamWatchdog.classifyError(new IllegalStateException("x")));
    }

    @Test
    public void recoverable_onlyNetworkClasses() {
        /* AUTH/MODEL_CONFIG 维持 fail, 不可续跑 */
        assertTrue(StreamWatchdog.isRecoverable(StreamWatchdog.ErrorClass.PROVIDER_CONNECTION));
        assertTrue(StreamWatchdog.isRecoverable(StreamWatchdog.ErrorClass.RATE_LIMIT));
        assertFalse(StreamWatchdog.isRecoverable(StreamWatchdog.ErrorClass.PROVIDER_AUTH));
        assertFalse(StreamWatchdog.isRecoverable(StreamWatchdog.ErrorClass.MODEL_CONFIG));
        assertFalse(StreamWatchdog.isRecoverable(StreamWatchdog.ErrorClass.RUNTIME));
    }
}
