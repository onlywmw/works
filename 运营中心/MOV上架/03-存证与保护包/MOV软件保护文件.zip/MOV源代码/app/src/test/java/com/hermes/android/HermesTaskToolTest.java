package com.hermes.android;

import static org.junit.Assert.*;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.json.JSONObject;
import org.junit.Test;

import java.util.Collections;
import java.util.HashSet;

/**
 * 工单20 幕二: hermes.task 工具注册与信封测试。
 * - linuxAvailable 时注册、分级 high、approval=plan（沿用审批闸）
 * - handler 调 Tools.hermesTask → 信封解析 ok/output/file
 * - 变异亲杀：Tools.hermesTask 恒失败（返回 {ok:false}）→ 测试必须红
 */
public class HermesTaskToolTest {

    /** Tools 桩：hermesTask 可配（默认成功信封） */
    private static AgentLoop.Tools toolsWith(String hermesTaskResult) {
        return new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return "[]"; }
            @Override public String fileRead(String roomId, String path) { return "x"; }
            @Override public String fileWrite(String roomId, String path, String c) { return "OK:"; }
            @Override public String capabilityOf(String text) { return "unknown"; }
            @Override public String deviceCmd(String text) { return "ok"; }
            @Override public String packageApk(String roomId, String path, String appName) { return "ERR: 不支持"; }
            @Override public String shellExec(String cmd, int timeoutSec) { return "exit=0\nok"; }
            @Override public String hermesTask(String goal, int timeoutSec) { return hermesTaskResult; }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":true}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":true}"; }
        };
    }

    private static ToolRegistry registryWithLinux(boolean linuxAvailable, String hermesTaskResult) {
        return ToolRegistry.build(toolsWith(hermesTaskResult), "room1",
                HashSet::new, new ToolRegistry.DevicePolicy(Collections.<String>emptySet()),
                linuxAvailable);
    }

    private static ToolRegistry.Result runTask(ToolRegistry r, String goal) throws Exception {
        ToolRegistry.Tool t = r.find("hermes.task");
        assertNotNull("linuxAvailable 时 hermes.task 必须注册", t);
        return t.handler.run(new JSONObject("{\"goal\":\"" + goal + "\"}"));
    }

    /* ① linuxAvailable=false → 不注册 */
    @Test
    public void linuxUnavailable_toolNotRegistered() {
        ToolRegistry r = registryWithLinux(false, "{\"ok\":true,\"output\":\"x\"}");
        assertNull("Linux 未就绪时 hermes.task 不得注册", r.find("hermes.task"));
    }

    /* ② linuxAvailable=true → 注册 + 分级 high + approval plan */
    @Test
    public void linuxAvailable_toolRegisteredWithDangerousGate() throws Exception {
        ToolRegistry r = registryWithLinux(true, "{\"ok\":true,\"output\":\"x\"}");
        ToolRegistry.Tool t = r.find("hermes.task");
        assertNotNull(t);
        assertEquals("approval 必须 plan（审批闸）", "plan", t.approval);
        assertNotNull("Manifest 必须存在", t.manifest);
        assertEquals("risk 必须 high（DANGEROUS 分级）", "high", t.manifest.risk);
        assertTrue("描述必须含开放式子任务口径", t.desc.contains("开放式子任务"));
    }

    /* ③ 成功信封：ok + output + file 透传 */
    @Test
    public void successEnvelope_carriesOutputAndFile() throws Exception {
        ToolRegistry r = registryWithLinux(true,
                "{\"ok\":true,\"output\":\"完成分析图\",\"file\":\"report.png\"}");
        ToolRegistry.Result res = runTask(r, "把 CSV 清洗后出分析图");
        assertTrue("成功信封必须 ok", res.ok);
        assertTrue("output 必须透传", res.text.contains("完成分析图"));
    }

    /* ④ 失败信封：ok=false + error 透传（含具体原因，非笼统） */
    @Test
    public void failEnvelope_carriesConcreteError() throws Exception {
        ToolRegistry r = registryWithLinux(true,
                "{\"ok\":false,\"error\":\"Hermes 执行超时\"}");
        ToolRegistry.Result res = runTask(r, "跑一个长任务");
        assertFalse("失败信封必须 !ok", res.ok);
        assertNotNull("失败必须有 reason", res.reason);
        assertTrue("reason 必须带具体原因", res.reason.contains("Hermes 执行超时"));
    }

    /* ⑤ goal 空 → 拒绝 */
    @Test
    public void emptyGoal_rejected() throws Exception {
        ToolRegistry r = registryWithLinux(true, "{\"ok\":true}");
        ToolRegistry.Result res = runTask(r, "");
        assertFalse("空 goal 必须拒绝", res.ok);
    }

    /* ⑥ 变异亲杀：Tools.hermesTask 恒失败 → 成功信封测试必须红 */
    @Test
    public void mutation_toolsAlwaysFails_breaksSuccess() throws Exception {
        ToolRegistry r = registryWithLinux(true, "{\"ok\":false,\"error\":\"变异: 恒失败\"}");
        ToolRegistry.Result res = runTask(r, "正常任务");
        /* 与 ③ 断言互斥：若变异未拦截，这里 res.ok 会是 true → assertTrue 红 */
        assertTrue("变异（恒失败）必须让成功断言红", !res.ok);
    }

    /* ⑦ 打回④-1：hermes.task 必须进 ESSENTIAL_TOOLS——compact 模式（默认）下完整文档（含 goal 参数）
       对模型可见，否则模型只能空猜参数（真机探针 tool_call arg:"" 实证） */
    @Test
    public void hermesTaskInEssentialTools_promptCarriesGoalParam() throws Exception {
        ToolRegistry r = registryWithLinux(true, "{\"ok\":true,\"output\":\"x\"}");
        String prompt = r.promptText();
        assertTrue("hermes.task 完整文档必须在 compact prompt 中（ESSENTIAL）",
                prompt.contains("hermes.task"));
        assertTrue("goal 参数文档必须可见（模型不再空猜）",
                prompt.contains("goal"));
        assertTrue("goal 参数必须标注必填",
                prompt.contains("开放式任务目标"));
    }
}
