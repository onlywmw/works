package com.hermes.android.bridge;

import static org.junit.Assert.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

/**
 * 工单9 幕二 三件套 b/c 可测核心：
 * - c: guestContextText(memoryCover → AGENTS.md 记忆段文本)
 * - b: exportSkills(名称读取器 → 目录复制)
 * 变异亲杀: 跳过导出/不输出 → 必红。
 */
public class GuestContextTest {

    @Test public void guestContextText_containsCoverEntries() throws Exception {
        JSONArray cover = new JSONArray()
                .put(new JSONObject().put("mode", "verbatim").put("text", "用户偏好黑咖啡"))
                .put(new JSONObject().put("mode", "verbatim").put("text", "明天健身"));
        String text = BridgeKernel.guestContextText(cover);
        assertTrue("含记忆段头", text.startsWith("# AGENTS"));
        assertTrue("含记忆文本", text.contains("用户偏好黑咖啡"));
        assertTrue("含第二记忆", text.contains("明天健身"));
    }

    @Test public void guestContextText_emptyCover_headerOnly() {
        assertEquals("空 cover 只有头", "# AGENTS 记忆段 (MOV memoryCover)\n",
                BridgeKernel.guestContextText(new JSONArray()));
    }

    @Test public void guestContextText_skipsEmptyText() throws Exception {
        JSONArray cover = new JSONArray()
                .put(new JSONObject().put("mode", "verbatim").put("text", "有效记忆"))
                .put(new JSONObject().put("mode", "summary").put("text", ""));
        String text = BridgeKernel.guestContextText(cover);
        assertTrue("含有效记忆", text.contains("有效记忆"));
        assertFalse("空文本不输出", text.contains("- \n"));
    }

    @Test public void exportSkills_copiesFiles() throws Exception {
        java.io.File dst = java.nio.file.Files.createTempDirectory("skills_test").toFile();
        int n = BridgeKernel.exportSkills(dst,
                () -> new String[]{"mov-demo.skill", "mov-webbridge.skill"},
                name -> ("skill:" + name).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        assertEquals("复制 2 个", 2, n);
        assertTrue("文件1存在", new java.io.File(dst, "mov-demo.skill").exists());
        assertTrue("文件2存在", new java.io.File(dst, "mov-webbridge.skill").exists());
    }

    @Test public void exportSkills_nullNames_zero() {
        assertEquals(0, BridgeKernel.exportSkills(new java.io.File("/tmp/x"),
                () -> null, name -> new byte[]{1}));
    }
}
