package com.hermes.android.causal;

import org.json.JSONObject;
import org.junit.Test;

import java.io.File;
import java.nio.file.Files;

import static org.junit.Assert.*;

/**
 * NarrativeBuilder 单测（DESIGN_CAUSAL_APIFACT §二）——脱敏红线：无真名/金额/原文。
 */
public class NarrativeBuilderTest {

    @Test public void narrate_desensitizesNamesAndAmounts() throws Exception {
        File dir = Files.createTempDirectory("narr").toFile();
        try {
            CausalEngine e = new CausalEngine(dir);
            e.record("global", new CausalEvent("张三", "欠款", "李四", "2026-06-01", "test",
                    new JSONObject().put("amount", 5000).put("outcome", "negative")));
            e.record("global", new CausalEvent("张三", "还款", "李四", "2026-06-10", "test", null));
            e.link("global", "张三", "李四", 0.6, "测试关联");
            String n = NarrativeBuilder.narrate(e, "global");
            assertFalse("叙事必须脱敏，无真名: " + n, n.contains("张三") || n.contains("李四"));
            assertFalse("叙事必须脱敏，无金额: " + n, n.contains("5000"));
            assertTrue("叙事应含实体标签: " + n, n.contains("实体"));
        } finally {
            deleteRecursive(dir);
        }
    }

    @Test public void narrate_noData_returnsEmpty() throws Exception {
        File dir = Files.createTempDirectory("narr2").toFile();
        try {
            CausalEngine e = new CausalEngine(dir);
            assertEquals("无 links → 空叙事", "", NarrativeBuilder.narrate(e, "global"));
        } finally {
            deleteRecursive(dir);
        }
    }

    @Test public void narrate_predicatePii_scrubbed() throws Exception {
        // 谓词是用户自由文本（隐私审计 2026-08-05 发现的主泄露路径）：
        // 谓词夹带手机号/金额 → 叙事「高频关系类型」段必须打码，原文不得出现。
        File dir = Files.createTempDirectory("narr3").toFile();
        try {
            CausalEngine e = new CausalEngine(dir);
            e.record("global", new CausalEvent("张三", "电话13800138000催款8000元", "李四", "2026-06-01", "test",
                    new JSONObject().put("outcome", "negative")));
            e.link("global", "张三", "李四", 0.6, "测试关联");
            String n = NarrativeBuilder.narrate(e, "global");
            assertFalse("谓词中的手机号不得进叙事: " + n, n.contains("13800138000"));
            assertFalse("谓词中的金额不得进叙事: " + n, n.contains("8000元"));
            assertTrue("应含脱敏占位符: " + n, n.contains("[手机号]"));
        } finally {
            deleteRecursive(dir);
        }
    }

    private static void deleteRecursive(File f) {
        File[] c = f.listFiles();
        if (c != null) for (File x : c) deleteRecursive(x);
        f.delete();
    }
}
