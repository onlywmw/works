package com.hermes.android.browser;

import static org.junit.Assert.*;

import org.json.JSONObject;
import org.junit.Test;

/** 批3: MovWebBridge 工具→CDP 命令映射单测（纯逻辑，不依赖浏览器） */
public class MovWebBridgeTest {

    @Test public void navigate_mapsToPageNavigate() throws Exception {
        JSONObject cmd = MovWebBridge.cdpCommand("wb.navigate", new JSONObject("{\"url\":\"https://example.com\"}"));
        assertEquals("Page.navigate", cmd.getString("method"));
        assertEquals("https://example.com", cmd.getJSONObject("params").getString("url"));
    }

    @Test public void evaluate_mapsToRuntimeEvaluate() throws Exception {
        JSONObject cmd = MovWebBridge.cdpCommand("wb.evaluate", new JSONObject("{\"expression\":\"1+1\"}"));
        assertEquals("Runtime.evaluate", cmd.getString("method"));
        assertTrue(cmd.getJSONObject("params").getBoolean("returnByValue"));
    }

    @Test public void snapshot_returnsInnerText() throws Exception {
        JSONObject cmd = MovWebBridge.cdpCommand("wb.snapshot", new JSONObject());
        String expr = cmd.getJSONObject("params").getString("expression");
        assertTrue("应读取 innerText: " + expr, expr.contains("innerText"));
        assertTrue("应含 title: " + expr, expr.contains("document.title"));
    }

    @Test public void click_selectorInjected() throws Exception {
        JSONObject cmd = MovWebBridge.cdpCommand("wb.click", new JSONObject("{\"selector\":\"#btn\"}"));
        String expr = cmd.getJSONObject("params").getString("expression");
        assertTrue("选择器应注入: " + expr, expr.contains("#btn"));
    }

    @Test public void screenshot_mapsToCapture() throws Exception {
        JSONObject cmd = MovWebBridge.cdpCommand("wb.screenshot", new JSONObject());
        assertEquals("Page.captureScreenshot", cmd.getString("method"));
        assertEquals("png", cmd.getJSONObject("params").getString("format"));
    }

    @Test public void unknownTool_null() throws Exception {
        assertNull(MovWebBridge.cdpCommand("wb.unknown", new JSONObject()));
    }

    @Test public void jsEscape_quotes() {
        assertEquals("a\\'b", MovWebBridge.jsEscape("a'b"));
    }
}
