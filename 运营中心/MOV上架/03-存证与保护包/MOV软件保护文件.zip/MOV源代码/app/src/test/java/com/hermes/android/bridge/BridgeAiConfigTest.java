package com.hermes.android.bridge;

import com.hermes.android.model.ModelConfig;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * aiChatAsync / aiInfo 旧配置链 fallback 口径验证。
 *
 * 调用方清单 (2026-07-30 grep 全项目):
 *   - JS chat.js:119 → B.aiAsync(text, onResp)          [旧链，常驻]
 *   - JS chat.js:140 → B.aiInfo()                        [旧链，常驻]
 *   - JS bridge.js:16 → b.aiChat(t)                      [旧链，无人调]
 *   - JS bridge.js:18 → b.aiChatAsync(t, id, roomId)     [旧链桥]
 *   - JS bridge.js:24 → b.aiChatWithModel(t, mid, id, r) [新链桥，正确]
 *
 * 修复: aiChatAsync/aiChat/aiInfo 在旧 AiProviderConfig 无 key 时
 * fallback 到 ModelRegistry.getDefault()。
 */
public class BridgeAiConfigTest {

    // ═══ ModelConfig.isConfigured 口径 ═══

    @Test
    public void modelConfig_withApiKey_isConfigured() {
        ModelConfig mc = new ModelConfig();
        mc.apiKey = "sk-xxx";
        assertTrue("有 apiKey → configured", mc.isConfigured());
    }

    @Test
    public void modelConfig_nullApiKey_notConfigured() {
        ModelConfig mc = new ModelConfig();
        mc.apiKey = null;
        assertFalse("null apiKey → not configured", mc.isConfigured());
    }

    @Test
    public void modelConfig_emptyApiKey_notConfigured() {
        ModelConfig mc = new ModelConfig();
        mc.apiKey = "";
        assertFalse("空 apiKey → not configured", mc.isConfigured());
    }

    // ═══ getAiInfo 口径: configured 判断逻辑 ═══

    @Test
    public void configuredCheck_defaultModelWithKey_true() {
        // 模拟 getAiInfo 的判断: dm != null && dm.apiKey 非空 → configured
        ModelConfig dm = new ModelConfig();
        dm.apiKey = "sk-test";
        boolean configured = dm.apiKey != null && !dm.apiKey.isEmpty();
        assertTrue(configured);
    }

    @Test
    public void configuredCheck_defaultModelNull_fallsBackToOldConfig() {
        // 没有默认模型时，退回旧 AiProviderConfig.isConfigured() 返回值
        ModelConfig dm = null;
        boolean oldConfigured = false; // AiProviderConfig 无 key
        boolean configured = (dm != null && dm.apiKey != null && !dm.apiKey.isEmpty())
                || oldConfigured;
        assertFalse("无默认模型+旧配置无key → false", configured);
    }

    // ═══ getAiInfo 口径: displayName/model 来源 ═══

    @Test
    public void displayNameFromDefaultModel_notOldConfig() {
        // BUGFIX: displayName 应来自 ModelRegistry 默认模型，不是 AiProviderConfig
        ModelConfig dm = new ModelConfig();
        dm.name = "MiMo";
        dm.provider = "minimax";
        dm.model = "minimax-m2";
        dm.apiKey = "sk-xxx";

        // getAiInfo 逻辑
        String displayName = dm.name != null && !dm.name.isEmpty() ? dm.name : dm.provider;
        assertEquals("displayName 来自新体系", "MiMo", displayName);
        assertEquals("model 来自新体系", "minimax-m2", dm.model);
    }

    @Test
    public void displayNameFallsBackToProvider_whenNameEmpty() {
        ModelConfig dm = new ModelConfig();
        dm.name = "";
        dm.provider = "deepseek";
        dm.apiKey = "sk-xxx";

        String displayName = dm.name != null && !dm.name.isEmpty() ? dm.name : dm.provider;
        assertEquals("name 为空时用 provider", "deepseek", displayName);
    }

    // ═══ aiChatAsync fallback: ModelRegistry 替代 AiProviderConfig ═══

    @Test
    public void fallbackCheck_defaultModelAvailable_shouldNotReturnError() {
        // 模拟 aiChatAsync 的 fallback:
        //   aiConfig.isConfigured()=false
        //   → dm=getDefault() 有 key
        //   → 用 new AiClient(dm) 而不返回错误
        ModelConfig dm = new ModelConfig();
        dm.apiKey = "sk-xxx";
        boolean aiConfigured = false; // 旧配置无 key
        boolean fallback = !aiConfigured
                && dm != null && dm.apiKey != null && !dm.apiKey.isEmpty();
        assertTrue("旧配置无key但默认模型可用 → 走 fallback", fallback);
    }

    @Test
    public void fallbackCheck_noModelNoOldConfig_shouldReturnError() {
        // 两头都没 key → 返回 "AI 尚未配置" 错误
        ModelConfig dm = null;
        boolean aiConfigured = false;
        boolean fallback = !aiConfigured
                && dm != null && dm.apiKey != null && !dm.apiKey.isEmpty();
        assertFalse("无默认模型+旧无key → 不走fallback，返回错误", fallback);
    }
}
