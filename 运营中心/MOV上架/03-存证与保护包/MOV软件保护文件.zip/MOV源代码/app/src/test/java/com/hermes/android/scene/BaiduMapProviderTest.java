package com.hermes.android.scene;

import static org.junit.Assert.*;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.junit.Test;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/**
 * BaiduMapProvider 单测 — 只测 discover() 元数据与注册表注册，绝不执行 handler（网络 IO）。
 * 红线：零网络（照 FastSceneProviderTest 风格）。
 */
public class BaiduMapProviderTest {

    private static AgentLoop.Tools emptyTools() {
        return new AgentLoop.Tools() {
            public String fileList(String roomId) { return ""; }
            public String fileRead(String roomId, String path) { return ""; }
            public String fileWrite(String roomId, String path, String content) { return ""; }
            public String capabilityOf(String text) { return ""; }
            public String deviceCmd(String text) { return ""; }
            public String packageApk(String roomId, String path, String appName) { return "{}"; }
            public String shellExec(String cmd, int timeoutSec) { return ""; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            public String filePush(String roomId, String path) { return "{}"; }
            public String filePull(String roomId, String name) { return "{}"; }
        };
    }

    private ToolRegistry builtRegistry() {
        return ToolRegistry.build(emptyTools(), "room1", HashSet::new,
                new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
    }

    @Test public void discover_returns10Tools() {
        BaiduMapProvider p = new BaiduMapProvider();
        List<ToolRegistry.Tool> tools = p.discover();
        assertEquals("百度地图工具应为 10 个", 10, tools.size());
        for (ToolRegistry.Tool t : tools) {
            assertNotNull("工具名非空", t.name);
            assertNotNull("manifest 非空", t.manifest);
            assertEquals("access 应 readonly: " + t.name, "readonly", t.access);
            assertNotNull("checkFn 非空（AK 拦截）: " + t.name, t.checkFn);
            assertEquals("toolset 应为 geo（地图/位置）: " + t.name, "geo", t.toolset);
        }
    }

    @Test public void all10NamesPresent() {
        BaiduMapProvider p = new BaiduMapProvider();
        java.util.Set<String> names = new java.util.HashSet<>();
        for (ToolRegistry.Tool t : p.discover()) names.add(t.name);
        assertEquals(10, names.size());
        for (String n : new String[]{"map_geocode", "map_reverse_geocode", "map_search_places",
                "map_place_details", "map_directions_matrix", "map_directions",
                "map_weather", "map_ip_location", "map_road_traffic", "map_poi_extract"}) {
            assertTrue("应含 " + n, names.contains(n));
        }
    }

    @Test public void allNetworkCardsSyncTrue() {
        BaiduMapProvider p = new BaiduMapProvider();
        for (ToolRegistry.Tool t : p.discover()) {
            assertTrue("百度工具全为网络 IO，sync=true: " + t.name, t.manifest.sync);
            assertTrue("timeoutMs>0: " + t.name, t.manifest.timeoutMs > 0);
        }
    }

    @Test public void poiExtractLongerTimeout() {
        BaiduMapProvider p = new BaiduMapProvider();
        ToolRegistry.Tool t = null;
        for (ToolRegistry.Tool x : p.discover()) if (x.name.equals("map_poi_extract")) t = x;
        assertNotNull(t);
        assertEquals("poi_extract 双段提交轮询，timeoutMs 15000", 15000, t.manifest.timeoutMs);
    }

    @Test public void akMissing_checkFnBlocks() {
        BaiduMapProvider p = new BaiduMapProvider();
        for (ToolRegistry.Tool t : p.discover()) {
            String reason = t.checkFn.check();
            assertNotNull("AK 未配置时 checkFn 应返回拦截原因: " + t.name, reason);
            assertTrue("原因含 AK: " + t.name, reason.contains("AK"));
        }
    }

    @Test public void toolMetaRequiredParams() {
        BaiduMapProvider p = new BaiduMapProvider();
        java.util.Map<String, ToolRegistry.Tool> byName = new java.util.HashMap<>();
        for (ToolRegistry.Tool t : p.discover()) byName.put(t.name, t);
        assertTrue("geocode address 必填",
            req(byName.get("map_geocode"), "address"));
        assertTrue("reverse_geocode latitude 必填",
            req(byName.get("map_reverse_geocode"), "latitude"));
        assertTrue("search_places query 必填",
            req(byName.get("map_search_places"), "query"));
        assertTrue("place_details uid 必填",
            req(byName.get("map_place_details"), "uid"));
        assertTrue("directions_matrix origins 必填",
            req(byName.get("map_directions_matrix"), "origins"));
        assertTrue("directions origin 必填",
            req(byName.get("map_directions"), "origin"));
        assertTrue("road_traffic model 必填",
            req(byName.get("map_road_traffic"), "model"));
        assertTrue("poi_extract text_content 必填",
            req(byName.get("map_poi_extract"), "text_content"));
    }

    private static boolean req(ToolRegistry.Tool t, String param) {
        if (t == null || t.params == null) return false;
        for (ToolRegistry.ParamDef p : t.params) {
            if (p.name.equals(param)) return p.required;
        }
        return false;
    }

    @Test public void registryFindMapTools() {
        ToolRegistry r = builtRegistry();
        // 单测环境无 Context → AK 未配置 → checkFn 拦截，但工具仍注册进表（只是 prompt 不展示）
        assertNotNull("map_geocode 应注册进 ToolRegistry", r.find("map_geocode"));
        assertNotNull("map_weather 应注册", r.find("map_weather"));
        assertNotNull("map_search_places 应注册", r.find("map_search_places"));
        assertEquals("readonly", r.find("map_geocode").access);
    }

    @Test public void allTools_includesMapTools() {
        ToolRegistry r = builtRegistry();
        boolean seen = false;
        for (ToolRegistry.Tool t : r.allTools()) {
            if (t.name.equals("map_weather")) seen = true;
        }
        assertTrue("allTools() 应包含 map_weather", seen);
    }
}
