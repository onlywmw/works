package com.hermes.android.workflow;

import org.json.JSONObject;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * 5 触发器真行为断言（纯 JVM，零网络）。
 */
public class TriggerEvaluatorTest {

    private Workflow wf() { return new Workflow("w1", null, null, null); }

    private JSONObject trig(String type) {
        try { return new JSONObject().put("type", type); } catch (Exception e) { throw new RuntimeException(e); }
    }

    // ── pageload ──
    @Test public void pageload_matchesPageLoadEvent() {
        assertTrue(TriggerEvaluator.matches(trig("pageload"),
                WorkflowEvent.pageLoad("https://x.com/a", 1000), wf(), 1000));
    }
    @Test public void pageload_doesNotMatchUrlChange() {
        assertFalse(TriggerEvaluator.matches(trig("pageload"),
                WorkflowEvent.urlChange("https://x.com/a", 1000), wf(), 1000));
    }

    // ── interval ──
    @Test public void interval_firesWhenDue() {
        JSONObject t = trig("interval");
        try { t.put("intervalMs", 10000); } catch (Exception e) {}
        Workflow w = wf();
        w.lastFireAt = 0;                 // 从未触发：起点 0
        assertTrue(TriggerEvaluator.matches(t, WorkflowEvent.of(WorkflowEvent.Type.TICK, 10000), w, 10000));
    }
    @Test public void interval_notDueBeforeElapsed() {
        JSONObject t = trig("interval");
        try { t.put("intervalMs", 10000); } catch (Exception e) {}
        Workflow w = wf();
        w.lastFireAt = 5000;              // 上次 5s 前，interval 10s → 未到
        assertFalse(TriggerEvaluator.matches(t, WorkflowEvent.of(WorkflowEvent.Type.TICK, 10000), w, 10000));
    }

    // ── element_appear ──
    @Test public void elementAppear_matchesSelector() {
        JSONObject t = trig("element_appear");
        try { t.put("selector", "#result"); } catch (Exception e) {}
        assertTrue(TriggerEvaluator.matches(t,
                WorkflowEvent.elementAppear("#result", "https://x.com", 1000), wf(), 1000));
    }
    @Test public void elementAppear_rejectsDifferentSelector() {
        JSONObject t = trig("element_appear");
        try { t.put("selector", "#result"); } catch (Exception e) {}
        assertFalse(TriggerEvaluator.matches(t,
                WorkflowEvent.elementAppear("#other", "https://x.com", 1000), wf(), 1000));
    }

    // ── text_match ──
    @Test public void textMatch_contains() {
        JSONObject t = trig("text_match");
        try { t.put("pattern", "已出票"); } catch (Exception e) {}
        assertTrue(TriggerEvaluator.matches(t,
                WorkflowEvent.textMatch("您的订单已出票成功", "https://x.com", 1000), wf(), 1000));
    }
    @Test public void textMatch_regex() {
        JSONObject t = trig("text_match");
        try { t.put("pattern", "订单\\d{6}"); t.put("match", "regex"); } catch (Exception e) {}
        assertTrue(TriggerEvaluator.matches(t,
                WorkflowEvent.textMatch("订单123456处理中", "https://x.com", 1000), wf(), 1000));
        assertFalse(TriggerEvaluator.matches(t,
                WorkflowEvent.textMatch("无订单号", "https://x.com", 1000), wf(), 1000));
    }

    // ── 设备事件触发器族（第一幕） ──

    @Test public void screenOn_matchesScreenOnEvent() {
        JSONObject t = trig("screen_on");
        assertTrue(TriggerEvaluator.matches(t,
                WorkflowEvent.device(WorkflowEvent.Type.SCREEN_ON, 1000), wf(), 1000));
        assertFalse("screen_on 不命中 screen_off 事件", TriggerEvaluator.matches(t,
                WorkflowEvent.device(WorkflowEvent.Type.SCREEN_OFF, 1000), wf(), 1000));
    }

    @Test public void batteryBelow_matchesBatteryBelowEvent() {
        JSONObject t = trig("battery_below");
        assertTrue(TriggerEvaluator.matches(t,
                WorkflowEvent.device(WorkflowEvent.Type.BATTERY_BELOW, 1000), wf(), 1000));
        assertFalse("battery_below 不命中 power 事件", TriggerEvaluator.matches(t,
                WorkflowEvent.device(WorkflowEvent.Type.POWER_CONNECTED, 1000), wf(), 1000));
    }

    @Test public void powerConnected_matches() {
        JSONObject t = trig("power_connected");
        assertTrue(TriggerEvaluator.matches(t,
                WorkflowEvent.device(WorkflowEvent.Type.POWER_CONNECTED, 1000), wf(), 1000));
        assertFalse(TriggerEvaluator.matches(t,
                WorkflowEvent.device(WorkflowEvent.Type.POWER_DISCONNECTED, 1000), wf(), 1000));
    }

    @Test public void headphonesWifiBt_matches() {
        assertTrue(TriggerEvaluator.matches(trig("headphones_plugged"),
                WorkflowEvent.device(WorkflowEvent.Type.HEADPHONES_PLUGGED, 1000), wf(), 1000));
        assertTrue(TriggerEvaluator.matches(trig("wifi_disconnected"),
                WorkflowEvent.device(WorkflowEvent.Type.WIFI_DISCONNECTED, 1000), wf(), 1000));
        assertTrue(TriggerEvaluator.matches(trig("bt_connected"),
                WorkflowEvent.device(WorkflowEvent.Type.BT_CONNECTED, 1000), wf(), 1000));
    }

    // ── 第二幕：time_cron / manual / boot ──

    @Test public void timeCron_matches() {
        JSONObject t = trig("time_cron");
        try { t.put("cron", "* * * *"); } catch (Exception e) {}
        assertTrue(CronParser.matches("* * * *", 1000));
        assertTrue(TriggerEvaluator.matches(t, WorkflowEvent.of(WorkflowEvent.Type.TICK, 1000), wf(), 1000));
    }

    @Test public void timeCron_noMatchOnCronMiss() {
        JSONObject t = trig("time_cron");
        try { t.put("cron", "0 9 * *"); } catch (Exception e) {}
        // 1000ms 是 1970 年某时刻，非 09:00 整 → 不匹配
        assertFalse(TriggerEvaluator.matches(t, WorkflowEvent.of(WorkflowEvent.Type.TICK, 1000), wf(), 1000));
    }

    @Test public void manual_matchesManualEvent() {
        assertTrue(TriggerEvaluator.matches(trig("manual"),
                WorkflowEvent.of(WorkflowEvent.Type.MANUAL, 1000), wf(), 1000));
        assertFalse("manual 不命中 TICK", TriggerEvaluator.matches(trig("manual"),
                WorkflowEvent.of(WorkflowEvent.Type.TICK, 1000), wf(), 1000));
    }

    @Test public void bootMatchesBootEvent() {
        assertTrue(TriggerEvaluator.matches(trig("boot_completed"),
                WorkflowEvent.of(WorkflowEvent.Type.BOOT_COMPLETED, 1000), wf(), 1000));
        assertFalse(TriggerEvaluator.matches(trig("boot_completed"),
                WorkflowEvent.of(WorkflowEvent.Type.TICK, 1000), wf(), 1000));
    }

    // ── url_change ──
    @Test public void urlChange_containsPattern() {
        JSONObject t = trig("url_change");
        try { t.put("pattern", "/vodplay/"); } catch (Exception e) {}
        assertTrue(TriggerEvaluator.matches(t,
                WorkflowEvent.urlChange("https://x.com/vodplay/123.html", 1000), wf(), 1000));
        assertFalse(TriggerEvaluator.matches(t,
                WorkflowEvent.urlChange("https://x.com/voddetail/1.html", 1000), wf(), 1000));
    }
}
