package com.hermes.android.serve;

import static org.junit.Assert.*;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * 阶段3 A3 单测：ToolManifest.toManifest 字段映射（name/level/tier/params/examples）。
 * 零网络注入式：直接喂 ToolRegistry（fake Tools），验证清单结构。
 */
public class ToolManifestTest {

    private static ToolRegistry registryWith() {
        AgentLoop.Tools tools = new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return "[]"; }
            @Override public String fileRead(String roomId, String path) { return ""; }
            @Override public String fileWrite(String roomId, String path, String c) { return "OK:"; }
            @Override public String capabilityOf(String text) { return ""; }
            @Override public String deviceCmd(String text) { return "ok"; }
            @Override public String packageApk(String roomId, String path, String n) { return "{\"ok\":false}"; }
            @Override public String shellExec(String cmd, int timeoutSec) { return "exit=0\n"; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":false}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":false}"; }
        };
        return ToolRegistry.build(tools, "room1", HashSet::new,
                ToolRegistry.policyForTest(Collections.<String>emptySet()), true);
    }

    private static JSONObject findTool(JSONArray arr, String name) throws Exception {
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            if (name.equals(o.optString("name"))) return o;
        }
        return null;
    }

    @Test public void manifest_containsShellExec_withFields() throws Exception {
        JSONArray arr = ToolManifest.toManifest(registryWith());
        assertTrue("清单非空", arr.length() > 0);
        JSONObject shell = findTool(arr, "shell.exec");
        assertNotNull("shell.exec 在清单", shell);
        assertEquals("name 映射", "shell.exec", shell.optString("name"));
        assertTrue("description 非空", shell.optString("description").length() > 0);
        assertEquals("level 默认 SLOW", "SLOW", shell.optString("level"));
        assertEquals("tier=ACTION (写工具)", "ACTION", shell.optString("tier"));
        assertTrue("params 数组存在", shell.has("params"));
        JSONArray params = shell.getJSONArray("params");
        assertTrue("shell.exec 有 cmd 参数", params.length() > 0);
        assertEquals("cmd", params.getJSONObject(0).optString("name"));
    }

    @Test public void manifest_readonlyTool_tierREADONLY() throws Exception {
        JSONArray arr = ToolManifest.toManifest(registryWith());
        JSONObject fileList = findTool(arr, "file.list");
        assertNotNull(fileList);
        assertEquals("只读工具 tier=READONLY", "READONLY", fileList.optString("tier"));
    }

    @Test public void manifest_examplesArrayPresent() throws Exception {
        JSONArray arr = ToolManifest.toManifest(registryWith());
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            assertTrue("每条有 examples 数组", o.has("examples"));
            assertTrue("每条有 params 数组", o.has("params"));
            assertTrue("每条有 tier", o.has("tier"));
            assertTrue("每条有 level", o.has("level"));
        }
    }

    @Test public void manifest_entriesHaveNoDuplicateNames() throws Exception {
        JSONArray arr = ToolManifest.toManifest(registryWith());
        Map<String, Integer> count = new HashMap<>();
        for (int i = 0; i < arr.length(); i++) {
            String n = arr.getJSONObject(i).optString("name");
            count.put(n, count.getOrDefault(n, 0) + 1);
        }
        for (Map.Entry<String, Integer> e : count.entrySet()) {
            assertEquals("工具名唯一: " + e.getKey(), 1, (int) e.getValue());
        }
    }
}
