package com.hermes.android.causal;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.io.File;
import java.nio.file.Files;

import static org.junit.Assert.*;

/**
 * PatchCompiler 单测（DESIGN_CAUSAL_APIFACT §四）——patch_rule → CausalRule 映射 + 落库。
 */
public class PatchCompilerTest {

    @Test public void compile_mapsPatchToRule() throws Exception {
        File dir = Files.createTempDirectory("patch").toFile();
        try {
            CausalEngine e = new CausalEngine(dir);
            JSONObject patch = new JSONObject()
                    .put("hidden_variables", new JSONArray().put("书面协议缺失"))
                    .put("probability_change", "降低约35%")
                    .put("patch_rule", new JSONObject()
                            .put("condition", "当与商务伙伴实体产生资金借出边且无书面协议边时")
                            .put("action", "INSERT_NODE")
                            .put("new_node", new JSONObject().put("suggested_trigger", "转账后1小时生成协议"))
                            .put("confidence_boost", 0.3));
            JSONObject r = PatchCompiler.compile(e, "global", patch);
            assertTrue("编译应成功: " + r.optString("error", ""), r.optBoolean("ok"));
            String ruleId = r.optString("ruleId");
            assertTrue("ruleId 应为 patch_*: " + ruleId, ruleId.startsWith("patch_"));

            // 规则已落库（query 可见），映射断言
            JSONObject q = e.query("global", 10);
            JSONArray rules = q.optJSONArray("rules");
            boolean found = false;
            for (int i = 0; i < rules.length(); i++) {
                JSONObject ro = rules.optJSONObject(i);
                if (ruleId.equals(ro.optString("ruleId"))) {
                    found = true;
                    JSONObject when = ro.optJSONObject("when");
                    assertEquals("condition → when.type=cooccur", "cooccur", when.optString("type"));
                    assertTrue("when.atoms 非空", when.optJSONArray("atoms").length() > 0);
                    JSONObject then = ro.optJSONObject("then");
                    assertTrue("INSERT_NODE → then.alert: " + then,
                            then.optString("alert").contains("因果助手建议"));
                    assertEquals("confidence_boost → then.linkDelta", 0.3, then.optDouble("linkDelta"), 0.001);
                    assertTrue("hidden_variables → then.diagnosis", then.has("diagnosis"));
                    break;
                }
            }
            assertTrue("补丁规则应出现在 query rules", found);
        } finally {
            deleteRecursive(dir);
        }
    }

    @Test public void compile_nullPatch_returnsFail() throws Exception {
        File dir = Files.createTempDirectory("patch2").toFile();
        try {
            CausalEngine e = new CausalEngine(dir);
            assertFalse("null patch → 失败", PatchCompiler.compile(e, "global", null).optBoolean("ok"));
        } finally {
            deleteRecursive(dir);
        }
    }

    @Test public void compile_piiWriteBack_rejected() throws Exception {
        // 隐私闸门（隐私审计 2026-08-05）：云端补丁把手机号/金额原文写回 condition/触发器 → 拒绝落库。
        File dir = Files.createTempDirectory("patch3").toFile();
        try {
            CausalEngine e = new CausalEngine(dir);
            JSONObject patch = new JSONObject()
                    .put("hidden_variables", new JSONArray().put("13800138000 未接来电"))
                    .put("patch_rule", new JSONObject()
                            .put("condition", "当张三欠5000元且电话13800138000无人接听时")
                            .put("action", "INSERT_NODE")
                            .put("new_node", new JSONObject().put("suggested_trigger", "拨打 13800138000"))
                            .put("confidence_boost", 0.3));
            JSONObject r = PatchCompiler.compile(e, "global", patch);
            assertFalse("含 PII 原文的补丁必须拒绝: " + r, r.optBoolean("ok"));
            assertTrue("错误信息应说明原因: " + r, r.optString("error").contains("PII"));
            // 确认未落库：query rules 里无 patch_ 规则
            JSONArray rules = e.query("global", 10).optJSONArray("rules");
            for (int i = 0; i < rules.length(); i++) {
                assertFalse("被拒补丁不得落库",
                        rules.optJSONObject(i).optString("ruleId").startsWith("patch_"));
            }
        } finally {
            deleteRecursive(dir);
        }
    }

    private static void deleteRecursive(File f) {
        File[] c = f.listFiles();
        if (c != null) for (File x : c) deleteRecursive(x);
        f.delete();
    }
}
