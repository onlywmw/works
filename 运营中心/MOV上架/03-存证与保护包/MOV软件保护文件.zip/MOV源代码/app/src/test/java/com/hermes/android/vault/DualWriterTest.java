package com.hermes.android.vault;

import org.junit.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyStore;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import static org.junit.Assert.*;

/**
 * DualWriter 双副本分流单测 — 真 JCEKS 白盒（与 SecureVaultTest 同款）。
 * 断言的是分流实物的真实性质：净化副本无 PII、原文进保险柜可还原、两区不许混存。
 */
public class DualWriterTest {

    private static class JceksCrypto implements SecureVault.CryptoEngine {
        final SecretKey key;

        JceksCrypto(File ksFile) throws Exception {
            char[] pw = "vault-test".toCharArray();
            KeyStore ks = KeyStore.getInstance("JCEKS");
            if (ksFile.exists()) {
                try (FileInputStream in = new FileInputStream(ksFile)) { ks.load(in, pw); }
            } else {
                ks.load(null, null);
            }
            SecretKey k = (SecretKey) ks.getKey("vault", pw);
            if (k == null) {
                KeyGenerator kg = KeyGenerator.getInstance("AES");
                kg.init(256);
                k = kg.generateKey();
                ks.setKeyEntry("vault", k, pw, null);
                try (FileOutputStream out = new FileOutputStream(ksFile)) { ks.store(out, pw); }
            }
            this.key = k;
        }

        @Override public byte[] encrypt(byte[] p) throws Exception { return AesGcm.encrypt(key, p); }
        @Override public byte[] decrypt(byte[] d) throws Exception { return AesGcm.decrypt(key, d); }
    }

    private File tempDir() throws Exception {
        File d = new File(System.getProperty("java.io.tmpdir"),
                "dual_" + System.currentTimeMillis() + "_" + (int) (Math.random() * 100000));
        d.mkdirs();
        return d;
    }

    private SecureVault newVault(File dir) throws Exception {
        return new SecureVault(new File(dir, "vault"), new JceksCrypto(new File(dir, "test-keystore.jks")));
    }

    // ==================== 双副本分流 ====================

    @Test public void split_masksPiiAndLocksOriginal() throws Exception {
        File dir = tempDir();
        SecureVault vault = newVault(dir);
        String raw = "收货人：李四，电话13812345678，身份证11010519491231002X";
        DualWriter.Result r = DualWriter.split(vault, "病历", raw, null);

        // ① 净化副本: 无 PII（PiiMasker 打码）
        assertFalse("净化副本无手机号", r.maskedText.contains("13812345678"));
        assertFalse("净化副本无身份证", r.maskedText.contains("11010519491231002X"));
        assertFalse("净化副本无姓名", r.maskedText.contains("李四"));
        assertTrue("手机号已泛化", r.maskedText.contains("[手机号]"));
        assertTrue("身份证已泛化", r.maskedText.contains("[证件号]"));

        // ② 原始副本: 保险柜解密还原原文
        assertEquals("原文入保险柜可还原", raw, vault.unlock(r.textVaultId));
        assertEquals("无原图时 1 条", 1, vault.list().size());
    }

    @Test public void split_imagePathLockedIntoVault() throws Exception {
        File dir = tempDir();
        SecureVault vault = newVault(dir);
        File img = new File(dir, "orig.png");
        byte[] imgBytes = "PNG-FAKE-BYTES-原始图".getBytes(StandardCharsets.UTF_8);
        Files.write(img.toPath(), imgBytes);

        DualWriter.Result r = DualWriter.split(vault, "扫描单", "原文内容", img.getAbsolutePath());

        assertNotNull("原图入保险柜", r.imageVaultId);
        assertArrayEquals("原图字节还原", imgBytes, vault.unlockBytes(r.imageVaultId));
        assertEquals("文本+原图共 2 条", 2, vault.list().size());
    }

    @Test public void split_missingImagePathSkipped() throws Exception {
        File dir = tempDir();
        SecureVault vault = newVault(dir);
        DualWriter.Result r = DualWriter.split(vault, "病历", "内容", dir + "/no_such.png");
        assertNull("不存在原图路径跳过", r.imageVaultId);
        assertEquals(1, vault.list().size());
    }

    @Test public void split_cleanTextNoPii_passesThrough() throws Exception {
        File dir = tempDir();
        SecureVault vault = newVault(dir);
        String clean = "今天天气不错，买了三本书";
        DualWriter.Result r = DualWriter.split(vault, "备忘录", clean, null);
        assertEquals("无 PII 内容原样进净化区", clean, r.maskedText);
        assertEquals("原文也入保险柜", clean, vault.unlock(r.textVaultId));
    }

    @Test public void split_emptyRawRejected() throws Exception {
        try {
            DualWriter.split(newVault(tempDir()), "病历", "", null);
            fail("空原文应拒绝");
        } catch (VaultException e) {
            assertEquals("EMPTY", e.code);
        }
    }

    @Test public void split_nullVaultRejected() throws Exception {
        try {
            DualWriter.split(null, "病历", "内容", null);
            fail("null vault 应拒绝");
        } catch (VaultException e) {
            assertEquals("NO_VAULT", e.code);
        }
    }

    // ==================== 两区不许混存断言 ====================

    @Test public void assertNoCrossStorage_rejectsWhenMaskedLeaksOriginalDigits() {
        // 净化区回存原文(≥16 位数字串 = 证件/卡号) → 断言拒绝
        try {
            DualWriter.assertNoCrossStorage("卡号6222020200112233445", "卡号6222020200112233445");
            fail("混存应被断言拒绝");
        } catch (IllegalStateException e) {
            assertTrue("拒绝信息含两区不许混存", e.getMessage().contains("两区不许混存"));
        }
    }

    @Test public void assertNoCrossStorage_okWhenMasked() {
        // 打码后净化副本无原文数字 → 放行
        DualWriter.assertNoCrossStorage("卡号6222020200112233445", "卡号[卡号]");
        DualWriter.assertNoCrossStorage("无敏感数字的普通文本", "无敏感数字的普通文本");
    }
}
