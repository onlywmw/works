package com.hermes.android.linux;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Assume;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;

/**
 * E-11（P0，2026-08-09 验收打回）：dirSize 防符号链接环——rootfs bin/X11、node doc 等
 * 循环符号链接曾致无限递归 → 分配风暴 → GC 死锁（App CPU 100% 真机实测）。
 * 修复后：walkFileTree NOFOLLOW，环链接 SKIP_SUBTREE，遍历有限返回。
 */
public class RootfsManagerDirSizeTest {

    @Rule public TemporaryFolder tmp = new TemporaryFolder();

    private static void write(File f, int bytes) throws Exception {
        f.getParentFile().mkdirs();
        try (FileOutputStream os = new FileOutputStream(f)) {
            os.write(new byte[bytes]);
        }
    }

    @Test
    public void 符号链接环不死循环() throws Exception {
        File root = tmp.newFolder("rootfs");
        File bin = new File(root, "bin");
        bin.mkdirs();
        write(new File(bin, "tool"), 100);   // 真实文件 100B

        try {
            // 自环：bin/X11 → bin（rootfs 实测 bin/X11 loop detected 的复刻）
            Files.createSymbolicLink(new File(bin, "X11").toPath(), bin.toPath());
            // 互环：node-18 → node-20 → node-18（rootfs 实测 node doc 循环链的复刻）
            File doc = new File(root, "usr/share/doc");
            doc.mkdirs();
            File nodeA = new File(doc, "node-18");
            File nodeB = new File(doc, "node-20");
            nodeA.mkdirs();
            nodeB.mkdirs();
            Files.createSymbolicLink(nodeA.toPath(), nodeB.toPath());
            Files.createSymbolicLink(nodeB.toPath(), nodeA.toPath());
        } catch (Exception e) {
            // Windows 无符号链接权限 → 诚实跳过（真机已有 loop detected 证据链）
            Assume.assumeNoException("本机无符号链接创建权限，跳过环用例", e);
        }

        long size = RootfsManager.dirSize(root);
        assertTrue("环不死循环且返回有限值（至少含真实文件 100B）", size >= 100);
        assertTrue("不会无限增长（只计真实文件，环被跳过）", size < 1000);
    }

    @Test
    public void 普通目录正常累计() throws Exception {
        File root = tmp.newFolder("rootfs2");
        write(new File(root, "a/b/x"), 100);
        write(new File(root, "a/y"), 50);
        write(new File(root, "z"), 30);
        assertEquals(180, RootfsManager.dirSize(root));
    }

    @Test
    public void 空目录与缺失路径() {
        assertEquals(0, RootfsManager.dirSize(null));
        assertEquals(0, RootfsManager.dirSize(new File("no-such-path-xyz")));
        File empty = new File(tmp.getRoot(), "empty-dir");
        empty.mkdirs();
        assertEquals(0, RootfsManager.dirSize(empty));
    }
}
