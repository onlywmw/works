package com.hermes.android.scene;

import static org.junit.Assert.*;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.junit.Test;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/**
 * Ticket12306Provider 单测 — 只测 discover() 元数据与注册表注册，绝不执行 handler（网络 IO）。
 * 红线：零网络（照 FastSceneProviderTest 风格）。
 */
public class Ticket12306ProviderTest {

    private static AgentLoop.Tools emptyTools() {
        return new AgentLoop.Tools() {
            public String fileList(String roomId) { return ""; }
            public String fileRead(String roomId, String path) { return ""; }
            public String fileWrite(String roomId, String path, String content) { return ""; }
            public String capabilityOf(String text) { return ""; }
            public String deviceCmd(String text) { return ""; }
            public String packageApk(String roomId, String path, String appName) { return "{}"; }
            public String shellExec(String cmd, int timeoutSec) { return ""; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            public String filePush(String roomId, String path) { return "{}"; }
            public String filePull(String roomId, String name) { return "{}"; }
        };
    }

    private ToolRegistry builtRegistry() {
        return ToolRegistry.build(emptyTools(), "room1", HashSet::new,
                new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
    }

    @Test public void discover_returns8Tools() {
        Ticket12306Provider p = new Ticket12306Provider();
        List<ToolRegistry.Tool> tools = p.discover();
        assertEquals("12306 工具应为 8 个", 8, tools.size());
        for (ToolRegistry.Tool t : tools) {
            assertNotNull("工具名非空", t.name);
            assertNotNull("manifest 非空", t.manifest);
            assertEquals("access 应 readonly: " + t.name, "readonly", t.access);
            assertEquals("approval 应 none: " + t.name, "none", t.approval);
            assertEquals("toolset 应为 travel（出行/票务）: " + t.name, "travel", t.toolset);
            assertFalse("name 不应为空串", t.name.isEmpty());
        }
    }

    @Test public void all8NamesPresent() {
        Ticket12306Provider p = new Ticket12306Provider();
        java.util.Set<String> names = new java.util.HashSet<>();
        for (ToolRegistry.Tool t : p.discover()) names.add(t.name);
        assertEquals(8, names.size());
        assertTrue("get-tickets", names.contains("get-tickets"));
        assertTrue("get-current-date", names.contains("get-current-date"));
        assertTrue("get-stations-code-in-city", names.contains("get-stations-code-in-city"));
        assertTrue("get-station-code-of-citys", names.contains("get-station-code-of-citys"));
        assertTrue("get-station-code-by-names", names.contains("get-station-code-by-names"));
        assertTrue("get-station-by-telecode", names.contains("get-station-by-telecode"));
        assertTrue("get-interline-tickets", names.contains("get-interline-tickets"));
        assertTrue("get-train-route-stations", names.contains("get-train-route-stations"));
    }

    @Test public void networkCardsSyncTrue() {
        Ticket12306Provider p = new Ticket12306Provider();
        for (ToolRegistry.Tool t : p.discover()) {
            if (t.name.equals("get-tickets") || t.name.equals("get-interline-tickets")
                    || t.name.equals("get-train-route-stations")) {
                assertTrue("网络 IO 工具 sync=true: " + t.name, t.manifest.sync);
                assertEquals("timeoutMs 12000: " + t.name, 12000, t.manifest.timeoutMs);
                assertTrue("Tool.timeoutSec=12: " + t.name, t.timeoutSec >= 12);
            }
        }
    }

    @Test public void localCardsSyncFalse() {
        Ticket12306Provider p = new Ticket12306Provider();
        for (ToolRegistry.Tool t : p.discover()) {
            if (t.name.equals("get-current-date") || t.name.equals("get-stations-code-in-city")
                    || t.name.equals("get-station-code-of-citys")
                    || t.name.equals("get-station-code-by-names")
                    || t.name.equals("get-station-by-telecode")) {
                assertFalse("本地/内存查询 sync=false: " + t.name, t.manifest.sync);
            }
        }
    }

    @Test public void getTicketsParamsComplete() {
        Ticket12306Provider p = new Ticket12306Provider();
        ToolRegistry.Tool t = null;
        for (ToolRegistry.Tool x : p.discover()) if (x.name.equals("get-tickets")) t = x;
        assertNotNull("get-tickets 存在", t);
        assertNotNull("params 非空", t.params);
        assertEquals("get-tickets 10 参数", 10, t.params.length);
        java.util.Map<String, ToolRegistry.ParamDef> byName = new java.util.HashMap<>();
        for (ToolRegistry.ParamDef pd : t.params) byName.put(pd.name, pd);
        assertTrue("date 必填", byName.containsKey("date") && byName.get("date").required);
        assertTrue("fromStation 必填", byName.containsKey("fromStation") && byName.get("fromStation").required);
        assertTrue("toStation 必填", byName.containsKey("toStation") && byName.get("toStation").required);
        assertTrue("trainFilterFlags 选填", byName.containsKey("trainFilterFlags") && !byName.get("trainFilterFlags").required);
        assertTrue("format 选填", byName.containsKey("format") && !byName.get("format").required);
        assertNotNull("examples 非空", t.examples);
        assertTrue("examples 应有示例", t.examples.length > 0);
    }

    @Test public void registryFindTicketTools() {
        ToolRegistry r = builtRegistry();
        assertNotNull("get-tickets 应注册进 ToolRegistry", r.find("get-tickets"));
        assertNotNull("get-current-date 应注册", r.find("get-current-date"));
        assertNotNull("get-station-code-by-names 应注册", r.find("get-station-code-by-names"));
        assertNotNull("get-interline-tickets 应注册", r.find("get-interline-tickets"));
        assertNotNull("get-train-route-stations 应注册", r.find("get-train-route-stations"));
        // readonly → MCP 暴露门槛（RegistryProvider.readonlyTools 语义）
        assertEquals("readonly", r.find("get-tickets").access);
    }

    @Test public void allTools_includesTicketTools() {
        ToolRegistry r = builtRegistry();
        boolean seen = false;
        for (ToolRegistry.Tool t : r.allTools()) {
            if (t.name.equals("get-tickets")) seen = true;
        }
        assertTrue("allTools() 应包含 get-tickets", seen);
    }
}
