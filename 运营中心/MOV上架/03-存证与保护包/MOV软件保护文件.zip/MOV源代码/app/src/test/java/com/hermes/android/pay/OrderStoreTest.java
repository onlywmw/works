package com.hermes.android.pay;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.hermes.android.agent.Journal;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.nio.file.Files;

/**
 * 工单26 M1-3：OrderStore 状态机——全合法迁移 / 跳态拒 / EXPIRED 旁路 / journal 重放重建。
 */
public class OrderStoreTest {

    @Rule public TemporaryFolder tmp = new TemporaryFolder();

    private Journal journal() throws Exception {
        return new Journal(tmp.newFolder("rooms"));
    }

    @Test
    public void 全合法迁移链() throws Exception {
        OrderStore s = new OrderStore(journal());
        OrderStore.Order o = s.create("pkg-accept-001", "mov-buyer-test", 1);
        assertEquals(OrderStore.State.CREATED, o.state);

        assertTrue(s.transit(o.orderId, OrderStore.State.PAYING, new JSONObject().put("codeUrl", "weixin://x")));
        assertTrue(s.transit(o.orderId, OrderStore.State.PAID, new JSONObject().put("trade_state", "SUCCESS")));
        assertTrue(s.transit(o.orderId, OrderStore.State.DELIVERED, null));
        assertTrue(s.transit(o.orderId, OrderStore.State.INSTALLED, null));
        assertEquals(OrderStore.State.INSTALLED, o.state);
    }

    @Test
    public void 跳态拒与终态拒() throws Exception {
        OrderStore s = new OrderStore(journal());
        OrderStore.Order o = s.create("pkg-accept-001", "mov-buyer-test", 1);
        assertFalse("CREATED→DELIVERED 跳态拒", s.transit(o.orderId, OrderStore.State.DELIVERED, null));
        assertFalse("CREATED→INSTALLED 跳态拒", s.transit(o.orderId, OrderStore.State.INSTALLED, null));
        assertEquals("跳态后仍在 CREATED", OrderStore.State.CREATED, o.state);

        assertTrue(s.transit(o.orderId, OrderStore.State.PAYING, null));
        assertTrue(s.transit(o.orderId, OrderStore.State.PAID, null));
        assertTrue(s.transit(o.orderId, OrderStore.State.DELIVERED, null));
        assertTrue(s.transit(o.orderId, OrderStore.State.INSTALLED, null));
        assertFalse("INSTALLED 终态再迁拒", s.transit(o.orderId, OrderStore.State.EXPIRED, null));
        assertFalse("INSTALLED 终态再迁拒", s.transit(o.orderId, OrderStore.State.MANUAL, null));
    }

    @Test
    public void E13下单失败直落MANUAL且journal留痕() throws Exception {
        // E-13（P0）：CREATED→MANUAL 合法——merchant_missing/wx_create_fail/order_send_fail 错误出口不再静默
        java.io.File rooms = tmp.newFolder("rooms-e13");
        Journal j = new Journal(rooms);
        OrderStore s = new OrderStore(j);
        OrderStore.Order o = s.create("pkg-accept-001", "mov-buyer-test", 1);

        // wx 下单失败 → 直落 MANUAL（带原因 extra）
        assertTrue("CREATED→MANUAL 必须合法（E-13）", s.transit(o.orderId, OrderStore.State.MANUAL,
                new JSONObject().put("wx_create_fail", "SIGN_ERROR:签名错误")));
        assertEquals(OrderStore.State.MANUAL, o.state);

        // journal 留痕（重放后仍是 MANUAL + 原因可读）
        OrderStore s2 = OrderStore.rebuild(j);
        OrderStore.Order o2 = s2.get(o.orderId);
        assertEquals("重放后订单 MANUAL", OrderStore.State.MANUAL, o2.state);
        assertEquals("MANUAL 原因留 journal", "SIGN_ERROR:签名错误",
                j.eventsOfType(OrderStore.ROOM, OrderStore.EVENT_TYPE)
                        .optJSONObject(j.eventsOfType(OrderStore.ROOM, OrderStore.EVENT_TYPE).length() - 1)
                        .optJSONObject("payload").optJSONObject("extra").optString("wx_create_fail"));
    }

    @Test
    public void EXPIRED与MANUAL旁路() throws Exception {
        OrderStore s = new OrderStore(journal());
        OrderStore.Order o = s.create("pkg-accept-001", "mov-buyer-test", 1);
        assertTrue(s.transit(o.orderId, OrderStore.State.PAYING, null));
        assertTrue(s.transit(o.orderId, OrderStore.State.EXPIRED, null));     // 超时旁路
        assertFalse("EXPIRED 终态拒", s.transit(o.orderId, OrderStore.State.PAID, null));

        OrderStore.Order o2 = s.create("pkg-accept-001", "mov-buyer-test", 1);
        assertTrue(s.transit(o2.orderId, OrderStore.State.PAYING, null));
        assertTrue(s.transit(o2.orderId, OrderStore.State.MANUAL, null));     // 查单异常旁路
        assertFalse("MANUAL 终态拒", s.transit(o2.orderId, OrderStore.State.PAID, null));
    }

    @Test
    public void 未知订单与空参数() throws Exception {
        OrderStore s = new OrderStore(journal());
        assertFalse("未知订单迁移拒", s.transit("MOV-unknown", OrderStore.State.PAID, null));
        try {
            s.create("", "buyer", 1);
            assertTrue("空 productId 应抛", false);
        } catch (IllegalArgumentException expected) {}
        try {
            s.create("pkg", "", 1);
            assertTrue("空 buyerId 应抛", false);
        } catch (IllegalArgumentException expected) {}
    }

    @Test
    public void journal重放重建状态一致() throws Exception {
        java.io.File rooms = tmp.newFolder("rooms2");
        Journal j = new Journal(rooms);
        OrderStore s = new OrderStore(j);
        OrderStore.Order o = s.create("pkg-accept-001", "mov-buyer-test", 1);
        s.transit(o.orderId, OrderStore.State.PAYING, new JSONObject().put("codeUrl", "weixin://pay"));
        s.transit(o.orderId, OrderStore.State.PAID, new JSONObject().put("trade_state", "SUCCESS"));
        s.transit(o.orderId, OrderStore.State.DELIVERED, null);

        // 模拟重启：新实例从 journal 重放
        OrderStore s2 = OrderStore.rebuild(j);
        OrderStore.Order o2 = s2.get(o.orderId);
        assertNotNull("重放后订单存在", o2);
        assertEquals("重放后状态一致", OrderStore.State.DELIVERED, o2.state);
        assertEquals("重放后订单字段一致", "mov-buyer-test", o2.buyerId);
        assertEquals("重放后 codeUrl 恢复", "weixin://pay", o2.codeUrl);
        // 重放后可继续迁移
        assertTrue(s2.transit(o.orderId, OrderStore.State.INSTALLED, null));
    }

    @Test
    public void 订单号格式合规() {
        String id = OrderStore.newOrderId();
        assertTrue("前缀 MOV", id.startsWith("MOV"));
        assertTrue("≤32 字符（微信限制）", id.length() <= 32);
        assertTrue("时间戳在中间", id.matches("MOV\\d{14}\\d{4}"));
        // 两次不同
        assertFalse(OrderStore.newOrderId().equals(OrderStore.newOrderId()));
    }

    @Test
    public void paying筛选仅PAYING态_E1重挂用() throws Exception {
        OrderStore s = new OrderStore(journal());
        OrderStore.Order a = s.create("pkg-accept-001", "mov-buyer-test", 1);   // CREATED
        OrderStore.Order b = s.create("pkg-accept-001", "mov-buyer-test", 1);
        s.transit(b.orderId, OrderStore.State.PAYING, null);
        OrderStore.Order c = s.create("pkg-accept-001", "mov-buyer-test", 1);
        s.transit(c.orderId, OrderStore.State.PAYING, null);
        s.transit(c.orderId, OrderStore.State.PAID, null);
        OrderStore.Order d = s.create("pkg-accept-001", "mov-buyer-test", 1);
        s.transit(d.orderId, OrderStore.State.PAYING, null);
        s.transit(d.orderId, OrderStore.State.EXPIRED, null);

        java.util.List<OrderStore.Order> paying = s.paying();
        assertEquals("仅 PAYING 态订单", 1, paying.size());
        assertEquals(b.orderId, paying.get(0).orderId);
        assertEquals("all 返回全部", 4, s.all().size());
    }

    /* ═══ 工单26 挂账⑧：滚动截尾后快照重建防丢单 ═══ */

    @Test
    public void snapshot事件每百条迁移写入() throws Exception {
        java.io.File rooms = tmp.newFolder("rooms-snap-write");
        Journal j = new Journal(rooms);
        OrderStore s = new OrderStore(j);
        // 每单 create+一次合法迁移 = 2 事件；凑 50 单 = 100 事件 → 触发 maybeSnapshot（≥1）
        for (int i = 0; i < 50; i++) {
            OrderStore.Order o = s.create("pkg-accept-001", "mov-buyer-test", 1);
            s.transit(o.orderId, OrderStore.State.EXPIRED, null);   // CREATED→EXPIRED 合法
        }
        JSONObject replay = j.replay(OrderStore.ROOM);
        JSONArray evs = replay.optJSONObject("data").optJSONArray("events");
        int snapCount = 0;
        for (int i = 0; i < evs.length(); i++) {
            if (OrderStore.SNAPSHOT_EVENT_TYPE.equals(evs.optJSONObject(i).optString("type"))) snapCount++;
        }
        assertTrue("每 100 条应写快照（期望 ≥1）", snapCount >= 1);
    }

    @Test
    public void snapshot重建恢复滚动截尾订单() throws Exception {
        java.io.File rooms = tmp.newFolder("rooms-snap-rebuild");
        Journal j = new Journal(rooms);
        OrderStore s = new OrderStore(j);
        // 每单 create + 一次合法迁移 = 2 事件；40 单 = 80 事件。第 5 单先到 PAYING。
        OrderStore.Order keep = null;
        for (int k = 0; k < 40; k++) {
            OrderStore.Order o = s.create("pkg-accept-001", "mov-buyer-test", 1);
            if (k == 4) {
                s.transit(o.orderId, OrderStore.State.PAYING, new JSONObject().put("codeUrl", "weixin://pay"));
                keep = o;
            } else {
                s.transit(o.orderId, OrderStore.State.EXPIRED, null);
            }
        }
        // 再补 20 单（+40 事件 → 累计 120，跨过 100 触发快照）
        for (int k = 0; k < 20; k++) {
            OrderStore.Order o = s.create("pkg-accept-001", "mov-buyer-test", 1);
            s.transit(o.orderId, OrderStore.State.EXPIRED, null);
        }
        // 模拟滚动截尾：journal 只保留最近 30 行（截掉早期事件；快照应已在尾部 30 行内）
        java.io.File jf = new java.io.File(rooms, OrderStore.ROOM + "/journal.jsonl");
        java.util.List<String> lines = java.nio.file.Files.readAllLines(jf.toPath());
        int keepFrom = Math.max(0, lines.size() - 30);
        java.nio.file.Files.write(jf.toPath(), lines.subList(keepFrom, lines.size()));

        OrderStore r = OrderStore.rebuild(j);
        assertNotNull("快照重建后早期订单存在", r.get(keep.orderId));
        assertEquals("PAYING 态恢复", OrderStore.State.PAYING, r.get(keep.orderId).state);
        assertTrue("重建后仍有订单", r.all().size() >= 1);
    }
}
