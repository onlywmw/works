package com.hermes.android.workflow;

import org.json.JSONObject;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * 设备触发器族规划单测（纯 JVM）——触发器→家族映射 + 按需集合（零启用零常驻）。
 */
public class DeviceTriggerPlannerTest {

    private Workflow wf(String triggerType) {
        JSONObject t = new JSONObject();
        try { t.put("type", triggerType); } catch (Exception e) {}
        return new Workflow("w", t, null, null);
    }

    @Test public void familyOf_mapsAllDeviceTriggers() {
        assertEquals(DeviceTriggerPlanner.Family.SCREEN, DeviceTriggerPlanner.familyOf("screen_on"));
        assertEquals(DeviceTriggerPlanner.Family.SCREEN, DeviceTriggerPlanner.familyOf("screen_off"));
        assertEquals(DeviceTriggerPlanner.Family.POWER, DeviceTriggerPlanner.familyOf("power_connected"));
        assertEquals(DeviceTriggerPlanner.Family.POWER, DeviceTriggerPlanner.familyOf("power_disconnected"));
        assertEquals(DeviceTriggerPlanner.Family.BATTERY, DeviceTriggerPlanner.familyOf("battery_below"));
        assertEquals(DeviceTriggerPlanner.Family.BATTERY, DeviceTriggerPlanner.familyOf("battery_above"));
        assertEquals(DeviceTriggerPlanner.Family.HEADPHONES, DeviceTriggerPlanner.familyOf("headphones_plugged"));
        assertEquals(DeviceTriggerPlanner.Family.HEADPHONES, DeviceTriggerPlanner.familyOf("headphones_unplugged"));
        assertEquals(DeviceTriggerPlanner.Family.WIFI, DeviceTriggerPlanner.familyOf("wifi_connected"));
        assertEquals(DeviceTriggerPlanner.Family.WIFI, DeviceTriggerPlanner.familyOf("wifi_disconnected"));
        assertEquals(DeviceTriggerPlanner.Family.BT, DeviceTriggerPlanner.familyOf("bt_connected"));
        assertEquals(DeviceTriggerPlanner.Family.BT, DeviceTriggerPlanner.familyOf("bt_disconnected"));
    }

    @Test public void familyOf_nonDeviceOrNull() {
        assertNull("非设备触发器 → null", DeviceTriggerPlanner.familyOf("pageload"));
        assertNull("null → null", DeviceTriggerPlanner.familyOf(null));
        assertNull("未知 → null", DeviceTriggerPlanner.familyOf("explode"));
    }

    @Test public void computeNeeded_zeroEnabledEmpty() {
        assertTrue("空列表 → 空集", DeviceTriggerPlanner.computeNeeded(Collections.emptyList()).isEmpty());
        assertTrue("null → 空集", DeviceTriggerPlanner.computeNeeded(null).isEmpty());
    }

    @Test public void computeNeeded_disabledWorkflowExcluded() {
        Workflow w = wf("screen_on");
        w.enabled = false;
        assertTrue("禁用设备 workflow 不注册", DeviceTriggerPlanner.computeNeeded(Collections.singletonList(w)).isEmpty());
    }

    @Test public void computeNeeded_collectsFamilies() {
        Set<DeviceTriggerPlanner.Family> need = DeviceTriggerPlanner.computeNeeded(Arrays.asList(
                wf("screen_on"), wf("battery_below"), wf("wifi_disconnected"), wf("pageload")));
        assertTrue("含 SCREEN", need.contains(DeviceTriggerPlanner.Family.SCREEN));
        assertTrue("含 BATTERY", need.contains(DeviceTriggerPlanner.Family.BATTERY));
        assertTrue("含 WIFI", need.contains(DeviceTriggerPlanner.Family.WIFI));
        assertEquals("pageload 非设备不进", 3, need.size());
    }
}
