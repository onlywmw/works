package com.hermes.android.causal;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

/**
 * CausalHash 测试 — 哈希地基：确定性、原子规范化、区块链篡改检测。
 */
public class CausalHashTest {

    @Test public void sha256Deterministic() {
        String a = CausalHash.sha256("张三欠李四");
        String b = CausalHash.sha256("张三欠李四");
        assertEquals("同一输入哈希应一致", a, b);
        assertEquals("SHA-256 hex 长度", 64, a.length());
        assertNotEquals("不同输入哈希应不同", a, CausalHash.sha256("李四欠张三"));
    }

    @Test public void atomNormalizationCollapsesWhitespace() {
        assertEquals("前后空白折叠", "张三", CausalHash.normalize("  张三  "));
        assertEquals("内部空白折叠", "张 三", CausalHash.normalize("张   三"));
        // 原子哈希对同一标签不同空白应一致（索引键稳定）
        assertEquals("同原子不同空白哈希一致",
                CausalHash.atomHash("张三"), CausalHash.atomHash("  张三  "));
    }

    @Test public void atomHashEmptyAtomNotIndexed() {
        assertEquals("空原子返回空串（不索引）", "", CausalHash.atomHash("   "));
        assertEquals("null 返回空串", "", CausalHash.atomHash(null));
    }

    @Test public void blockHashChainsAndDetectsTamper() {
        String genesis = CausalHash.blockHash(null, "data1");
        String second = CausalHash.blockHash(genesis, "data2");
        assertEquals("链式：第二块绑定第一块", second,
                CausalHash.blockHash(CausalHash.blockHash(null, "data1"), "data2"));
        // 篡改任一 dataHash → 链断
        String tampered = CausalHash.blockHash(genesis, "data2-X");
        assertNotEquals("篡改 dataHash 后区块哈希变化", second, tampered);
        // 篡改 prevHash → 对不上
        assertNotEquals("篡改 prevHash 后区块哈希变化",
                CausalHash.blockHash("deadbeef", "data2"), second);
    }

    @Test public void normalizeNfkcUnifiesFullHalfWidth() {
        // NFKC：全角字母 → 半角（索引键统一）
        assertTrue(CausalHash.normalize("ＡＢＣ").equals("ABC"));
    }
}
