/* ============================================================
   newface-delivery 回归测试（node，无需构建）
   跑法: node app/src/test/js/newface-delivery.test.js
   FUSION F5: deliver 事件 → 交付卡数据提取
   ============================================================ */
'use strict';
const assert = require('assert');
const delivery = require('../../main/assets/js/newface-delivery.js');

// ══ 正常 deliver 事件 → 摘要截断 + 产物计数 ══
const d1 = delivery.toCardData({
  summary: '已生成贪吃蛇游戏，含打包 APK 与说明文档，共三步完成',
  files: ['snake.apk', 'readme.md'],
  goal: '做一个贪吃蛇游戏'
});
assert.strictEqual(d1.filesN, 2, '产物计数');
assert.ok(d1.summary.length <= 48, '摘要截断到 48');
assert.strictEqual(d1.goal, '做一个贪吃蛇游戏');

// ══ 空/无产物 → filesN 0 ══
const d2 = delivery.toCardData({ summary: '小任务完成', files: [] });
assert.strictEqual(d2.filesN, 0);
assert.strictEqual(d2.summary, '小任务完成');

// ══ files 缺失（旧事件/非数组）→ 容错 0 ══
const d3 = delivery.toCardData({ summary: 'x' });
assert.strictEqual(d3.filesN, 0);
const d4 = delivery.toCardData({ summary: 'x', files: 'not-array' });
assert.strictEqual(d4.filesN, 0);

// ══ null/undefined → 空数据不崩 ══
const d5 = delivery.toCardData(null);
assert.deepStrictEqual(d5, { summary: '', filesN: 0, goal: '' });
const d6 = delivery.toCardData(undefined);
assert.deepStrictEqual(d6, { summary: '', filesN: 0, goal: '' });

// ══ 摘要太长 → 省略号 ══
const long = '好'.repeat(100);
const d7 = delivery.toCardData({ summary: long, files: [] });
assert.strictEqual(d7.summary.endsWith('…'), true, '超长摘要应省略号结尾');
assert.strictEqual(d7.summary.length, 48);

// ══ clip 纯函数 ══
assert.strictEqual(delivery.clip('abc', 5), 'abc');
assert.strictEqual(delivery.clip('abcdef', 5), 'abcd…');

console.log('✅ newface-delivery 全部断言通过（F5 交付卡数据提取）');
