package com.hermes.android.mcp.server;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.junit.Test;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * RegistryProvider 工具暴露过滤单测（工单 P5）——纯 JVM 零网络。
 *
 * 核心断言：
 *  - writeTools 含 file.write（非危险可审批暴露），永不含 device.cmd / shell.exec（DANGEROUS）；
 *  - exposedTools 默认（enableWrite=false）不含写工具——写工具默认不出现在 tools/list；
 *  - exposedTools 开启后含写工具但仍不含 DANGEROUS；
 *  - isDangerous 判定（approval==always / risk==high / category==device）。
 */
public class RegistryProviderTest {

    private static AgentLoop.Tools emptyTools() {
        return new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return ""; }
            @Override public String fileRead(String roomId, String path) { return ""; }
            @Override public String fileWrite(String roomId, String path, String content) { return "OK:" + path; }
            @Override public String capabilityOf(String text) { return ""; }
            @Override public String deviceCmd(String text) { return ""; }
            @Override public String packageApk(String roomId, String path, String appName) { return "{\"ok\":false}"; }
            @Override public String shellExec(String cmd, int timeoutSec) { return ""; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":false}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":false}"; }
        };
    }

    private static ToolRegistry registry() {
        return ToolRegistry.build(emptyTools(), "room1", HashSet::new,
                new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
    }

    @Test public void writeTools_excludesDangerous() {
        List<ToolRegistry.Tool> writes = RegistryProvider.writeTools(registry());
        assertTrue("含 file.write（非危险可审批暴露）", has(writes, "file.write"));
        assertFalse("device.cmd 永不开", has(writes, "device.cmd"));
        assertFalse("shell.exec 永不开", has(writes, "shell.exec"));
    }

    @Test public void exposedTools_readonlyOnly_whenDisabled() {
        List<ToolRegistry.Tool> exposed = RegistryProvider.exposedTools(registry(), false);
        assertTrue("含只读 file.read", has(exposed, "file.read"));
        assertFalse("写工具默认不暴露", has(exposed, "file.write"));
    }

    @Test public void exposedTools_includesWrite_whenEnabled() {
        List<ToolRegistry.Tool> exposed = RegistryProvider.exposedTools(registry(), true);
        assertTrue("开启后含 file.write", has(exposed, "file.write"));
        assertFalse("开启后仍无 device.cmd", has(exposed, "device.cmd"));
        assertFalse("开启后仍无 shell.exec", has(exposed, "shell.exec"));
    }

    @Test public void isDangerous_judgements() {
        assertTrue("risk=high → 危险", RegistryProvider.isDangerous(tool("t1", "plan", "high", "exec")));
        assertTrue("approval=always → 危险", RegistryProvider.isDangerous(tool("t2", "always", "low", "io")));
        assertTrue("category=device → 危险", RegistryProvider.isDangerous(tool("t3", "plan", "low", "device")));
        assertFalse("medium/io/plan → 非危险（可暴露）", RegistryProvider.isDangerous(tool("t4", "plan", "medium", "io")));
        assertFalse("只读工具非危险", RegistryProvider.isDangerous(
                new ToolRegistry.Tool("file.read", "d", null, a -> null)));
    }

    private static ToolRegistry.Tool tool(String name, String approval, String risk, String cat) {
        return new ToolRegistry.Tool(name, "desc-" + name, null, a -> new ToolRegistry.Result(true, "ok"),
                "native", "write", approval, true, 10, "t", null, "r", null, null, 8000,
                new ToolRegistry.Manifest("标题", risk, "描述", true, cat), null);
    }

    private static boolean has(List<ToolRegistry.Tool> list, String name) {
        for (ToolRegistry.Tool t : list) {
            if (name.equals(t.name)) return true;
        }
        return false;
    }
}
