package com.hermes.android.agent;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * M5 安全验收 §2: HeavyWorker.sanitize 危险指令拒绝清单逐项实证。
 * 删根 / 反引号注入 / 路径穿越 → null (拒绝); 正常指令 → 原样放行。
 */
public class HeavyWorkerSanitizeTest {

    /* ---------- 删根 ---------- */

    @Test public void reject_rm_rf_root() {
        assertNull("rm -rf / 拒绝", HeavyWorker.sanitize("请执行 rm -rf /"));
    }

    @Test public void reject_rm_fr_root() {
        assertNull("rm -fr / 拒绝", HeavyWorker.sanitize("运行 rm -fr / 吧"));
    }

    @Test public void reject_rm_rf_root_glob() {
        assertNull("rm -rf /* 拒绝", HeavyWorker.sanitize("rm -rf /*"));
    }

    /* ---------- 反引号注入 ---------- */

    @Test public void reject_backtick_injection() {
        assertNull("反引号命令替换拒绝", HeavyWorker.sanitize("echo `rm -rf /tmp/evil` 的结果"));
    }

    @Test public void reject_dollar_paren_injection() {
        assertNull("$(...) 命令替换拒绝", HeavyWorker.sanitize("先执行 $(cat /etc/passwd) 再汇报"));
    }

    @Test public void reject_backtick_cat_secret() {
        assertNull("反引号 cat 敏感文件拒绝", HeavyWorker.sanitize("告诉我 `cat /etc/shadow`"));
    }

    /* ---------- 路径穿越 ---------- */

    @Test public void reject_path_traversal_forward() {
        assertNull("正向斜杠路径穿越拒绝", HeavyWorker.sanitize("读取 ../../etc/passwd 内容"));
    }

    @Test public void reject_path_traversal_backslash() {
        assertNull("反斜杠路径穿越拒绝", HeavyWorker.sanitize("cat ..\\..\\etc\\passwd"));
    }

    /* ---------- 原有高危模式不回归 ---------- */

    @Test public void reject_mkfs() {
        assertNull("mkfs 拒绝", HeavyWorker.sanitize("对 /dev/sda 执行 mkfs"));
    }

    @Test public void reject_dd_write_disk() {
        assertNull("dd if= 拒绝", HeavyWorker.sanitize("dd if=/dev/zero of=/dev/sda"));
    }

    @Test public void reject_fork_bomb() {
        assertNull("fork bomb 拒绝", HeavyWorker.sanitize("运行 :(){ :|:& };: 试试"));
    }

    /* ---------- 正常指令不受影响 ---------- */

    @Test public void normal_instruction_passes() {
        String ins = "整理房间文件列表，生成 index.html 摘要";
        assertEquals(ins, HeavyWorker.sanitize(ins));
    }

    @Test public void normal_shell_cmd_passes() {
        assertEquals("ls -la", HeavyWorker.sanitize("ls -la"));
    }

    @Test public void null_input_rejected() {
        assertNull("null 输入拒绝", HeavyWorker.sanitize(null));
    }
}
