package com.hermes.android.linux;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * ProotDiag 单测 — classify 纯函数判定。零网络，注入式。
 *
 * 防假覆盖：每条用例喂不同证据组合，断言分类；变异亲杀（classify 恒回 OK 时
 * SELINUX/ROOTFS 用例必红）。
 */
public class ProotDiagTest {

    private static List<String> avc(String... lines) {
        return new ArrayList<>(Arrays.asList(lines));
    }

    // ══════════ OK 路径 ══════════

    @Test public void classify_ok_whenProbeAndExecPass() {
        // 真实 proot --version 首行是 ASCII art banner（不是 "proot version" 字样）
        String cls = ProotDiag.classify(0, "_____ _____              ___",
                0, "Linux mov 5.15 aarch64\nPython 3.12.1\ngit version 2.43.0", "",
                false, avc());
        assertEquals(ProotDiag.OK, cls);
    }

    @Test public void classify_ok_ignoresNoiseAvc() {
        // search/setattr 噪声不判失败（env execute granted 才是强信号）
        String cls = ProotDiag.classify(0, "_____ _____ ___",
                0, "UNAME:Linux mov", "",
                false, avc(
                    "avc: denied { search } for name=tests scontext=u:r:untrusted_app",
                    "avc: denied { setattr } for name=/ scontext=u:r:untrusted_app"));
        assertEquals(ProotDiag.OK, cls);
    }

    @Test public void classify_ok_bannerPlusHermesBattery() {
        // 真机实测形态：banner + uname/python3/git/bash/hermes 全过
        String out = "UNAME:Linux localhost 5.15 aarch64\nPY:Python 3.12.3\nGIT:git version 2.43.0\n"
                + "BASH:5.2.21(1)-release\nENV_OK:yes\nHermes Agent v0.19.0";
        String cls = ProotDiag.classify(0, "_____ _____              ___",
                0, out, "", false, avc());
        assertEquals(ProotDiag.OK, cls);
    }

    // ══════════ SELinux 拦截 ══════════

    @Test public void classify_selinuxBlock_onExecDenied() {
        String cls = ProotDiag.classify(-1, "ERROR: exit=1 Operation not permitted",
                0, "", "", false, avc(
                    "avc: denied { execute } for name=libproot.so scontext=u:r:untrusted_app"));
        assertEquals(ProotDiag.SELINUX_BLOCK, cls);
    }

    @Test public void classify_selinuxBlock_onErrnoPermWithoutAvc() {
        // 无 avc 日志（dontaudit）但 errno 明确 → 仍判 SELINUX
        String cls = ProotDiag.classify(-1, "ERROR: Permission denied", 0, "", "",
                false, avc());
        assertEquals(ProotDiag.SELINUX_BLOCK, cls);
    }

    // ══════════ loader 陈旧 ══════════

    @Test public void classify_loaderStale_onNoent() {
        String cls = ProotDiag.classify(-1, "ERROR: No such file or directory",
                0, "", "", false, avc());
        assertEquals(ProotDiag.LOADER_STALE, cls);
    }

    // ══════════ rootfs 半残 ══════════

    @Test public void classify_rootfsBroken_whenProbeOkButExecFailNoent() {
        String cls = ProotDiag.classify(0, "proot version 5.4.0",
                127, "", "/usr/bin/env: No such file or directory",
                false, avc());
        assertEquals(ProotDiag.ROOTFS_BROKEN, cls);
    }

    @Test public void classify_rootfsBroken_commandNotFound() {
        String cls = ProotDiag.classify(0, "proot version 5.4.0",
                127, "sh: python3: command not found", "", false, avc());
        assertEquals(ProotDiag.ROOTFS_BROKEN, cls);
    }

    // ══════════ 超时 ══════════

    @Test public void classify_timeout_whenTimeoutFlag() {
        String cls = ProotDiag.classify(-1, "", -1, "", "", true, avc());
        assertEquals(ProotDiag.TIMEOUT, cls);
    }

    // ══════════ 变异亲杀 ══════════

    /** 变异：classify 恒回 OK → SELINUX 用例必红。 */
    @Test public void mutate_classifyConstantOk_makesSelinuxCaseRed() {
        String cls = ProotDiag.classify(-1, "ERROR: exit=1 Operation not permitted",
                0, "", "", false, avc(
                    "avc: denied { execute } for name=libproot.so scontext=u:r:untrusted_app"));
        // 若 classify 被变异成恒回 OK，此处会 fail——正是变异要抓的
        assertNotEquals("变异恒回 OK 会红", ProotDiag.OK, cls);
        assertEquals(ProotDiag.SELINUX_BLOCK, cls);
    }

    /** 变异：classify 恒回 SELINUX → OK 用例必红。 */
    @Test public void mutate_classifyConstantSelinux_makesOkCaseRed() {
        String cls = ProotDiag.classify(0, "proot version 5.4.0",
                0, "Linux mov aarch64", "", false, avc());
        // 若 classify 被变异成恒回 SELINUX，此处会 fail
        assertNotEquals("变异恒回 SELINUX 会红", ProotDiag.SELINUX_BLOCK, cls);
        assertEquals(ProotDiag.OK, cls);
    }

    // ══════════ hasAvcDeniedExec ══════════

    @Test public void hasAvcDeniedExec_detectsExecute() {
        assertTrue(ProotDiag.hasAvcDeniedExec(avc(
            "avc: denied { execute } for name=env scontext=u:r:untrusted_app")));
    }

    @Test public void hasAvcDeniedExec_ignoresGrantedAndOther() {
        assertFalse(ProotDiag.hasAvcDeniedExec(avc(
            "avc: granted { execute } for name=env scontext=u:r:untrusted_app",
            "avc: denied { search } for name=tests scontext=u:r:untrusted_app")));
    }

    @Test public void hasAvcDeniedExec_nullSafe() {
        assertFalse(ProotDiag.hasAvcDeniedExec(null));
        assertFalse(ProotDiag.hasAvcDeniedExec(new ArrayList<>()));
    }
}
