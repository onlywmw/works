package com.hermes.android.serve;

import static org.junit.Assert.*;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.mcp.server.RegistryProvider;

import org.json.JSONObject;
import org.junit.Test;

import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashSet;

/**
 * 工单9 幕一 单表化行为测试（打回修复）——覆盖生产接缝 activateBuiltinSkills:
 * 假读取器喂内置 skill JSON → 产物含 skill.echo → MovInboundServer(该表) invoke skill.echo 200 ok 且回显正确。
 * 变异亲杀: 接缝跳过激活 → 本测试必红。
 */
public class RegistryProviderSkillBehaviorTest {

    /** 简单 fake tools（build registry 用, 本测试只关心技能工具） */
    private static class SimpleTools implements AgentLoop.Tools {
        @Override public String fileList(String roomId) { return "[]"; }
        @Override public String fileRead(String roomId, String path) { return ""; }
        @Override public String fileWrite(String roomId, String path, String content) { return "OK"; }
        @Override public String capabilityOf(String text) { return ""; }
        @Override public String deviceCmd(String text) { return "ok"; }
        @Override public String packageApk(String roomId, String path, String appName) { return "{\"ok\":false}"; }
        @Override public String shellExec(String cmd, int timeoutSec) { return "exit=0\n"; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
        @Override public String filePush(String roomId, String path) { return "{\"ok\":true}"; }
        @Override public String filePull(String roomId, String name) { return "{\"ok\":true}"; }
    }

    private static ToolRegistry registry() {
        return ToolRegistry.build(new SimpleTools(), "r1", () -> new HashSet<>(),
                ToolRegistry.policyForTest(Collections.<String>emptySet()), false);
    }

    private static final String SKILL_JSON =
            "{\"name\":\"mov-demo\",\"tools\":[{\"name\":\"skill.echo\",\"description\":\"回显\"}]}";

    @Test
    public void activateBuiltinSkills_behavioral_e2e() throws Exception {
        // 1) 接缝激活: 假读取器喂内置 skill JSON（测真激活, 禁 mock）
        ToolRegistry reg = registry();
        int n = RegistryProvider.activateBuiltinSkills(reg,
                () -> new String[]{"mov-demo.skill"},
                name -> SKILL_JSON.getBytes(StandardCharsets.UTF_8));
        assertEquals("skill.echo 应注册", 1, n);
        assertNotNull("产物 registry 应含 skill.echo", reg.find("skill.echo"));

        // 2) 8388 查该表 invoke skill.echo → 200 ok 且回显正确（生产接线同一张表）
        MovInboundServer s = new MovInboundServer(reg, "tok", null);
        JSONObject body = new JSONObject().put("params", new JSONObject().put("text", "hi"));
        MovInboundServer.Response resp = s.dispatch("POST", "/tools/skill.echo/invoke",
                body, "tok", InetAddress.getByName("127.0.0.1"));
        assertEquals(200, resp.status);
        JSONObject b = new JSONObject(resp.body);
        assertTrue("skill.echo 应调用成功", b.optBoolean("ok"));
        assertTrue("回显正确", b.toString().contains("echo:hi"));
    }
}
