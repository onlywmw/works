package com.hermes.android.pay;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * PollGuard 单测（验收打回 P3）：三条不变量亲验。
 * 变异亲杀预案：tryAcquire 恒真 → 「双挂被拒」必红；release 改空操作 → 「释放后可重占」必红。
 */
public class PollGuardTest {

    @Test
    public void 同订单双挂被拒() {
        PollGuard g = new PollGuard();
        assertTrue(g.tryAcquire("o1"));      // 首次占链成功
        assertFalse(g.tryAcquire("o1"));     // 重复占链必拒（P3 核心：防双轮询链）
        assertTrue(g.isPolling("o1"));
    }

    @Test
    public void 不同订单互不影响() {
        PollGuard g = new PollGuard();
        assertTrue(g.tryAcquire("o1"));
        assertTrue(g.tryAcquire("o2"));
        assertFalse(g.tryAcquire("o2"));
    }

    @Test
    public void 释放后可重占() {
        PollGuard g = new PollGuard();
        assertTrue(g.tryAcquire("o1"));
        g.release("o1");                     // 链终结/后台链死释放
        assertFalse(g.isPolling("o1"));
        assertTrue(g.tryAcquire("o1"));      // onResume 可重挂
    }

    @Test
    public void clear全释放() {
        PollGuard g = new PollGuard();
        g.tryAcquire("o1");
        g.tryAcquire("o2");
        g.clear();                           // onPause 清空 handler 配套
        assertFalse(g.isPolling("o1"));
        assertFalse(g.isPolling("o2"));
        assertTrue(g.tryAcquire("o1"));
    }
}
