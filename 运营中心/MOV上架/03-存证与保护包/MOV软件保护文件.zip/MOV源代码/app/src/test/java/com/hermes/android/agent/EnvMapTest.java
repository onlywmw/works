package com.hermes.android.agent;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

import static org.junit.Assert.*;

/**
 * EnvMap 单测 — 零网络注入式。覆盖纯逻辑：截断 / 系统豁免 / 目录收集 / 树 / 搜索 / 摘要。
 * Android 依赖（SecureVault/MediaStore/ModelRegistry）留真机验收。
 */
public class EnvMapTest {

    private File tmpDir;

    @Before public void setUp() throws Exception {
        tmpDir = Files.createTempDirectory("envmap_test").toFile();
    }

    @After public void tearDown() throws Exception {
        deleteRecursive(tmpDir);
    }

    private void deleteRecursive(File f) {
        File[] c = f.listFiles();
        if (c != null) for (File x : c) deleteRecursive(x);
        f.delete();
    }

    // ==================== truncate（防上下文洪水） ====================

    @Test public void truncateKeepsShort() {
        assertEquals("abc", EnvMap.truncate("abc", 10));
    }

    @Test public void truncateCutsLong() {
        String r = EnvMap.truncate("1234567890", 5);
        assertEquals(6, r.length());            // 5 + "…"
        assertTrue(r.startsWith("12345"));
        assertTrue(r.endsWith("…"));
    }

    @Test public void truncateNullIsEmpty() {
        assertEquals("", EnvMap.truncate(null, 10));
    }

    // ==================== 系统区豁免 ====================

    @Test public void systemExemptPathsBlocked() {
        assertTrue(EnvMap.isSystemExempt("/data/local/tmp"));
        assertTrue(EnvMap.isSystemExempt("/system/bin"));
        assertTrue(EnvMap.isSystemExempt("/proc/cpuinfo"));
        assertTrue(EnvMap.isSystemExempt("/dev/null"));
    }

    @Test public void appPathsAllowed() {
        assertFalse(EnvMap.isSystemExempt("/sdcard/MOV/test.txt"));
        assertFalse(EnvMap.isSystemExempt("/data/data/com.hermes.android/files/test"));
    }

    // ==================== 目录收集（限深 + 豁免） ====================

    @Test public void collectFilesLimitedDepth() throws Exception {
        // a.txt, b/ (c.txt), b/d/ (e.txt) —— 深 3 收集 a.txt + b/c.txt，d/e.txt 超深不取
        new File(tmpDir, "a.txt").createNewFile();
        new File(tmpDir, "b").mkdirs();
        new File(tmpDir, "b/c.txt").createNewFile();
        new File(tmpDir, "b/d").mkdirs();
        new File(tmpDir, "b/d/e.txt").createNewFile();

        java.util.List<File> files = EnvMap.collectFiles(tmpDir, 2);
        assertEquals("限深 2 只收 a.txt + b/c.txt", 2, files.size());
    }

    // ==================== 目录树 ====================

    @Test public void treeShowsHierarchy() throws Exception {
        new File(tmpDir, "a.txt").createNewFile();
        new File(tmpDir, "sub").mkdirs();
        new File(tmpDir, "sub/b.txt").createNewFile();

        String t = EnvMap.tree(tmpDir, 3);
        assertTrue(t.contains("a.txt"));
        assertTrue(t.contains("sub"));
        assertTrue(t.contains("b.txt"));
        // 层级缩进：sub 下的 b.txt 有缩进
        assertTrue(t.indexOf("b.txt") > t.indexOf("sub"));
    }

    @Test public void treeEmptyDir() {
        assertEquals("（空目录）", EnvMap.tree(tmpDir, 3));
    }

    // ==================== 文件名搜索 ====================

    @Test public void searchByNameFindsKeyword() throws Exception {
        new File(tmpDir, "report_final.md").createNewFile();
        new File(tmpDir, "notes.txt").createNewFile();
        new File(tmpDir, "sub").mkdirs();
        new File(tmpDir, "sub/report_draft.md").createNewFile();

        java.util.List<File> hits = EnvMap.searchByName(tmpDir, "report", 3);
        assertEquals(2, hits.size());
    }

    // ==================== 文件摘要 ====================

    @Test public void peekSummaryTextPreview() throws Exception {
        File f = new File(tmpDir, "hello.md");
        Files.write(f.toPath(), "第一行\n第二行\n内容".getBytes(StandardCharsets.UTF_8));

        String s = EnvMap.peekSummary(f, 100);
        assertTrue(s.contains("md"));
        assertTrue(s.contains("大小"));
        assertTrue(s.contains("第一行"));
    }

    @Test public void peekSummaryBinaryDetected() throws Exception {
        File f = new File(tmpDir, "bin.dat");
        byte[] bytes = new byte[16];
        bytes[0] = 0; bytes[1] = 1; bytes[2] = 2;   // 含 NUL → 二进制
        Files.write(f.toPath(), bytes);

        String s = EnvMap.peekSummary(f, 100);
        assertTrue(s.contains("二进制"));
    }

    @Test public void peekMissingFile() {
        String s = EnvMap.peekSummary(new File(tmpDir, "nope.txt"), 100);
        assertTrue(s.contains("不存在"));
    }

    // ==================== 巡检#45 洞3: 无尾斜杠系统根豁免 ====================

    @Test public void systemRootWithoutSlashExempt() {
        assertTrue(EnvMap.isSystemExempt("/system"));
        assertTrue(EnvMap.isSystemExempt("/proc"));
        assertTrue(EnvMap.isSystemExempt("/data"));
    }

    // ==================== 巡检#45 洞2: 追剧记忆搜索 ====================

    @Test public void searchWatchHistoryMatchesTitle() throws Exception {
        File wh = new File(tmpDir, "watch_history.json");
        Files.write(wh.toPath(),
                ("{\"凡人修仙传\":{\"episode\":5,\"url\":\"x\"},\"琅琊榜\":{\"episode\":3}}").getBytes(StandardCharsets.UTF_8));
        java.util.List<String> hits = EnvMap.searchWatchHistory(wh, "凡人");
        assertEquals(1, hits.size());
        assertTrue(hits.contains("凡人修仙传"));
    }

    @Test public void searchWatchHistoryNoMatch() throws Exception {
        File wh = new File(tmpDir, "watch_history.json");
        Files.write(wh.toPath(), "{\"琅琊榜\":{}}".getBytes(StandardCharsets.UTF_8));
        assertEquals(0, EnvMap.searchWatchHistory(wh, "凡人").size());
    }

    @Test public void searchWatchHistoryMissingFile() {
        assertEquals(0, EnvMap.searchWatchHistory(new File(tmpDir, "nope.json"), "x").size());
    }
}
