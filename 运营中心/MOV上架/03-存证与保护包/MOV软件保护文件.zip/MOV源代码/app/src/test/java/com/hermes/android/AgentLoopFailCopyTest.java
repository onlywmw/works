package com.hermes.android;

import static org.junit.Assert.*;

import org.junit.Test;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * 顺手② 防回归（批次1）：失败文案不笼统——AgentLoop 兜底失败必须带具体原因。
 * 源码静态断言：禁「出了点问题，已记录」笼统文案，必须拼接异常信息。
 * 变异亲杀：把具体原因改回笼统文案 → 本测试必须红。
 */
public class AgentLoopFailCopyTest {

    private static File resolve() {
        String[][] candidates = {
                {"src/main/java", "com/hermes/android/agent/AgentLoop.java"},
                {"app/src/main/java", "com/hermes/android/agent/AgentLoop.java"},
        };
        for (String[] c : candidates) {
            File f = new File(c[0], c[1]);
            if (f.exists()) return f;
        }
        throw new AssertionError("AgentLoop.java 未找到 (working dir="
                + new File(".").getAbsolutePath() + ")");
    }

    @Test
    public void fallbackFailMsg_carriesConcreteReason() throws Exception {
        String src = new String(Files.readAllBytes(resolve().toPath()), StandardCharsets.UTF_8);
        /* 笼统文案必须消失 */
        assertFalse("不得再出现「出了点问题，已记录」笼统文案",
                src.contains("出了点问题，已记录"));
        /* 兜底失败必须带具体原因（异常 message 或类型名） */
        assertTrue("failMov 必须拼接具体原因（e.getMessage()）",
                src.contains("e.getMessage() != null ? e.getMessage()"));
        assertTrue("失败文案必须以「任务失败：」开头带原因",
                src.contains("\"任务失败：\" + reason"));
        /* 兜底 catch 块内必须调用 failMov 落 FAILED 终态 */
        assertTrue("兜底必须走 failMov",
                src.contains("failMov(MovError.internal(\"LOOP_EXCEPTION\""));
    }
}
