package com.hermes.android.causal;

import static org.junit.Assert.*;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.ai.AiClient;
import com.hermes.android.toolprovider.CausalToolProvider;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

/**
 * 工单22 幕三: 文本→四元组自动抽取器测试。
 * - 模型返回结构化四元组 → 入库（causal 引擎纯 Java 长在 journal）
 * - 模型返回 [] → 不入库
 * - 模型失败/解析失败 → 静默降级（返回 0 不抛）
 * - 变异亲杀：抽取器恒空（模型返回 [] 也被忽略）→ 测试红
 */
public class CausalExtractorTest {

    @Rule
    public TemporaryFolder tmp = new TemporaryFolder();

    @Before
    public void setUp() {
        CausalToolProvider.initForTest(tmp.getRoot());
    }

    /** 模型桩：返回指定内容 */
    private static AgentLoop.Brain brainReturning(String content) {
        return (sysPrompt, userText) -> new AiClient.AiResponse(true, content);
    }

    @Test
    public void extractRecord_textWithDebt_storesQuadruple() {
        /* 「我周三借了张三 500 块」→ 模型抽出 {张三,欠款/借出,500} → 入库 */
        String modelOut = "[{\"subject\":\"我\",\"predicate\":\"借出\",\"object\":\"张三\","
                + "\"meta\":{\"amount\":500}}]";
        int n = CausalExtractor.extractAndRecord(brainReturning(modelOut), "我周三借了张三 500 块");
        assertEquals("必须入库 1 条四元组", 1, n);

        CausalEngine engine = CausalToolProvider.engine();
        assertNotNull(engine);
        org.json.JSONObject q = engine.query(CausalToolProvider.ROOM, 20);
        assertTrue("查询必须 ok", q.optBoolean("ok", false));
        int eventCount = q.optInt("eventCount", 0);
        assertEquals("causal 库必须有 1 条事件", 1, eventCount);
    }

    @Test
    public void extractRecord_noFact_emptyArrayStoresNothing() {
        int n = CausalExtractor.extractAndRecord(brainReturning("[]"), "今天天气不错");
        assertEquals(0, n);
        CausalEngine engine = CausalToolProvider.engine();
        org.json.JSONObject q = engine.query(CausalToolProvider.ROOM, 20);
        assertEquals("无事实不得入库", 0, q.optInt("eventCount", 0));
    }

    @Test
    public void extractRecord_modelFailure_silentDowngrade() {
        /* 模型失败 → 静默返回 0 不抛 */
        int n = CausalExtractor.extractAndRecord(
                (sysPrompt, userText) -> new AiClient.AiResponse(false, "模型不可用"), "借钱");
        assertEquals(0, n);
    }

    @Test
    public void extractRecord_garbageResponse_silentDowngrade() {
        /* 模型返回非 JSON 垃圾 → 静默 0 */
        int n = CausalExtractor.extractAndRecord(brainReturning("我不懂你在说什么"), "借钱");
        assertEquals(0, n);
    }

    @Test
    public void extractRecord_nullBrain_skips() {
        assertEquals(0, CausalExtractor.extractAndRecord(null, "借钱"));
    }

    /* 变异亲杀：把「抽取成功」路径改坏（模型返回正常四元组但解析被吞）→ 本测试红 */
    @Test
    public void mutation_extractorAlwaysEmpty_breaksStore() {
        String modelOut = "[{\"subject\":\"我\",\"predicate\":\"借出\",\"object\":\"张三\","
                + "\"meta\":{\"amount\":500}}]";
        int n = CausalExtractor.extractAndRecord(brainReturning(modelOut), "我借了张三 500");
        /* 与 extractRecord_textWithDebt 互斥：变异后 n 变 0 → 断言红 */
        assertTrue("变异（恒空）必须让入库断言红", n == 1);
    }
}
