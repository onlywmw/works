package com.hermes.android.causal;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.nio.file.Files;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * CausalPromptBuilder 测试 — 提示词注入段：活性钩子注入/过期排除、强关联注入、到期提醒、预算截断、空引擎不崩。
 */
public class CausalPromptBuilderTest {

    private File tmp;
    private CausalEngine engine;

    @Before public void setUp() throws Exception {
        tmp = Files.createTempDirectory("causal-prompt-").toFile();
        engine = new CausalEngine(tmp);
    }

    @After public void tearDown() throws Exception {
        deleteRecursive(tmp);
    }

    private void deleteRecursive(File f) {
        File[] all = f.listFiles();
        if (all != null) for (File c : all) deleteRecursive(c);
        f.delete();
    }

    private JSONObject cooccurRule(String ruleId) throws Exception {
        return new JSONObject()
                .put("ruleId", ruleId)
                .put("label", ruleId)
                .put("when", new JSONObject().put("type", "cooccur")
                        .put("atoms", new JSONArray(java.util.Arrays.asList("张三", "李四", "欠款"))))
                .put("then", new JSONObject().put("linkDelta", 0.3).put("alert", "债务需复核"))
                .put("enabled", true);
    }

    @Test public void freshRuleInjected() throws Exception {
        engine.upsertRule("r1", cooccurRule("r_debt"));
        engine.record("r1", new CausalEvent("张三", "欠款", "李四"));
        String out = CausalPromptBuilder.build(engine, "r1", 5);
        assertTrue("应含活性规则", out.contains("r_debt"));
        assertTrue("应带标题", out.startsWith("【因果记忆】"));
    }

    @Test public void staleRuleExcluded() throws Exception {
        JSONObject rule = new JSONObject()
                .put("ruleId", "r_old")
                .put("label", "过期规则")
                .put("when", new JSONObject().put("type", "cooccur").put("atoms", new JSONArray()))
                .put("then", new JSONObject().put("expireAt", "2020-01-01"))
                .put("enabled", true);
        engine.upsertRule("r1", rule);
        String out = CausalPromptBuilder.build(engine, "r1", 5);
        assertFalse("过期规则不注入", out.contains("过期规则"));
    }

    @Test public void highStrengthLinkInjected() throws Exception {
        engine.link("r1", "张三", "李四", 0.8, "manual");
        String out = CausalPromptBuilder.build(engine, "r1", 5);
        assertTrue("高强关联注入", out.contains("张三"));
        assertTrue("关联标注", out.contains("关联"));
    }

    @Test public void dueAlertInjected() throws Exception {
        JSONObject rule = new JSONObject()
                .put("ruleId", "r_due")
                .put("label", "到期提醒")
                .put("when", new JSONObject().put("type", "dateAfter").put("whenDateField", "dueDate"))
                .put("then", new JSONObject().put("alert", "债务到期"))
                .put("enabled", true);
        engine.upsertRule("r1", rule);
        engine.record("r1", new CausalEvent("张三", "欠款", "李四", null, null,
                new JSONObject().put("dueDate", "2020-01-01")));
        String out = CausalPromptBuilder.build(engine, "r1", 5);
        assertTrue("到期提醒注入", out.contains("债务到期"));
    }

    @Test public void emptyEngineNoCrash() throws Exception {
        String out = CausalPromptBuilder.build(engine, "nonexistent", 5);
        assertEquals("空房返回空串", "", out);
        assertEquals("null engine 返回空串", "", CausalPromptBuilder.build(null, "r1", 5));
    }

    /* 工单22 幕一: 具体事实必须注入（模型被问「张三欠我钱吗」需看到「我 借给 张三 500」本体） */
    @Test public void recentFactInjected() throws Exception {
        engine.record("r1", new CausalEvent("我", "借给", "张三", "周三", "extractor",
                new JSONObject().put("amount", 500)));
        String out = CausalPromptBuilder.build(engine, "r1", 10);
        assertTrue("具体事实必须注入（subject）", out.contains("我"));
        assertTrue("具体事实必须注入（predicate 借给）", out.contains("借给"));
        assertTrue("具体事实必须注入（object 张三）", out.contains("张三"));
        assertTrue("金额 meta 必须注入", out.contains("500"));
        assertTrue("事实行格式", out.contains("- 事实:"));
    }

    @Test public void recentFact_budgetRespected() throws Exception {
        for (int i = 0; i < 10; i++) {
            engine.record("r1", new CausalEvent("主体" + i, "关系", "客体" + i, null, "extractor", null));
        }
        String out = CausalPromptBuilder.build(engine, "r1", 3);
        int facts = 0;
        for (String line : out.split("\n")) if (line.contains("- 事实:")) facts++;
        assertTrue("事实行不得超过预算（maxLines=3 最多 3 行事实）", facts <= 3);
    }

    /* 变异亲杀：事实注入块被删 → 本测试红 */
    @Test public void mutation_factInjectionRemoved_breaks() throws Exception {
        engine.record("r1", new CausalEvent("我", "借给", "张三", "周三", "extractor",
                new JSONObject().put("amount", 500)));
        String out = CausalPromptBuilder.build(engine, "r1", 10);
        /* 与 recentFactInjected 互斥：变异（无事实注入）→ contains("借给") 假 → 红 */
        assertTrue("变异（事实注入缺失）必须让断言红", out.contains("借给"));
    }

    @Test public void budgetClipped() throws Exception {
        for (int i = 0; i < 10; i++) {
            engine.link("r1", "原子" + i, "原子" + (i + 1), 0.7, "manual");
        }
        String out = CausalPromptBuilder.build(engine, "r1", 2);
        assertTrue("超预算截断", out.split("\n").length <= 3);  // 标题 + 2 行
    }
}
