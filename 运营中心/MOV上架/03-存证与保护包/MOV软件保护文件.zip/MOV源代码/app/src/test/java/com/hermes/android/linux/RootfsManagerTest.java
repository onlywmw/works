package com.hermes.android.linux;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * RootfsManager 状态机纯逻辑单测 (安装流程要真机 proot/网络, 不在本地单测范围)。
 */
public class RootfsManagerTest {

    @Test
    public void normalizeRestored_transientStatesFallBack() {
        /* 进程死在安装中途 → 重启后不得谎称 DOWNLOADING/EXTRACTING/BOOTSTRAPPING */
        assertEquals(RootfsManager.State.NOT_INSTALLED,
                RootfsManager.normalizeRestored(RootfsManager.State.DOWNLOADING));
        assertEquals(RootfsManager.State.NOT_INSTALLED,
                RootfsManager.normalizeRestored(RootfsManager.State.EXTRACTING));
        assertEquals(RootfsManager.State.NOT_INSTALLED,
                RootfsManager.normalizeRestored(RootfsManager.State.BOOTSTRAPPING));
    }

    @Test
    public void normalizeRestored_terminalStatesKept() {
        assertEquals(RootfsManager.State.READY,
                RootfsManager.normalizeRestored(RootfsManager.State.READY));
        assertEquals(RootfsManager.State.ERROR,
                RootfsManager.normalizeRestored(RootfsManager.State.ERROR));
        assertEquals(RootfsManager.State.NOT_INSTALLED,
                RootfsManager.normalizeRestored(RootfsManager.State.NOT_INSTALLED));
    }

    @Test
    public void clearDirectory_removesAllAndKeepsDir() throws Exception {
        /* 重装前必须彻底清空: 带残渣解压 GNU tar 会报 "Cannot open: File exists" */
        java.io.File dir = java.nio.file.Files.createTempDirectory("rf").toFile();
        java.io.File sub = new java.io.File(dir, "usr/bin");
        assertTrue(sub.mkdirs());
        assertTrue(new java.io.File(sub, "perl").createNewFile());
        assertTrue(new java.io.File(dir, "etc").mkdirs());

        assertNull(RootfsManager.clearDirectory(dir));
        assertTrue("目录本身保留", dir.isDirectory());
        String[] left = dir.list();
        assertNotNull(left);
        assertEquals("必须全清", 0, left.length);

        /* 空调用幂等: 不存在/已空目录都返回 null */
        assertNull(RootfsManager.clearDirectory(dir));
        assertNull(RootfsManager.clearDirectory(new java.io.File(dir, "ghost")));
        dir.delete();
    }

    // ==================== diskUsage 单飞守卫 (R4 打回修复回归) ====================

    /** ② 多实例并发触发 → 只有一条计算线程占位成功 (静态字段语义; 修复前每实例各起一条) */
    @Test
    public void diskUsage_singleFlight_concurrentTriggersOnlyOneThread() throws Exception {
        java.util.concurrent.CountDownLatch entered = new java.util.concurrent.CountDownLatch(1);
        java.util.concurrent.CountDownLatch release = new java.util.concurrent.CountDownLatch(1);
        java.util.concurrent.atomic.AtomicInteger started = new java.util.concurrent.atomic.AtomicInteger();
        java.util.concurrent.atomic.AtomicInteger granted = new java.util.concurrent.atomic.AtomicInteger();
        Runnable compute = () -> {
            started.incrementAndGet();
            entered.countDown();
            try { release.await(5, java.util.concurrent.TimeUnit.SECONDS); }
            catch (InterruptedException ignored) {}
        };
        /* 第一条先占位并确认进计算 */
        assertTrue("首调必须占位", RootfsManager.startDiskUsageIfIdle(compute));
        assertTrue("计算线程应已启动", entered.await(5, java.util.concurrent.TimeUnit.SECONDS));
        /* 并发 8 路(模拟各处 new RootfsManager 的构造触发)全部应被拒 */
        java.util.List<Thread> ts = new java.util.ArrayList<>();
        for (int i = 0; i < 8; i++) {
            Thread t = new Thread(() -> {
                if (RootfsManager.startDiskUsageIfIdle(compute)) granted.incrementAndGet();
            });
            ts.add(t); t.start();
        }
        for (Thread t : ts) t.join(5000);
        release.countDown();
        assertEquals("单飞: 并发触发不许有第二个占位", 0, granted.get());
        /* 等首条跑完, 守卫应复位 */
        assertTrue("守卫复位后应能再占位", waitGuardFree());
    }

    /** ②b 计算抛未受检异常 → 守卫必须复位 (修复前 diskUsageRunning 永真, 单飞永久卡死) */
    @Test
    public void diskUsage_guardResetsWhenComputeThrows() throws Exception {
        /* 吞掉工作线程的未捕获异常打印, 防测试输出噪音 */
        Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {});
        try {
            assertTrue(RootfsManager.startDiskUsageIfIdle(() -> {
                throw new RuntimeException("模拟 dirSize 炸掉");
            }));
            assertTrue("异常后守卫必须复位", waitGuardFree());
        } finally {
            Thread.setDefaultUncaughtExceptionHandler(old);
        }
    }

    /** 轮询守卫复位 (观察口直读, 无副作用) */
    private static boolean waitGuardFree() throws InterruptedException {
        long deadline = System.currentTimeMillis() + 5000;
        while (System.currentTimeMillis() < deadline) {
            if (RootfsManager.diskUsageIdleForTest()) return true;
            Thread.sleep(20);
        }
        return false;
    }
}
