package com.hermes.android.security;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * PaymentGate 单测 — domain 匹配 + 金额掩码。
 * 对照 docs/contracts/PAYMENT_GATE_SCHEMA.md §8 测试向量。
 */
public class PaymentGateTest {

    // ==================== §8.1 域名匹配 ====================

    @Test
    public void matches_wildcardAlipay() {
        assertTrue(PaymentGate.matchesDomain("www.alipay.com", "*.alipay.com"));
    }

    @Test
    public void matches_mobileAlipay() {
        assertTrue(PaymentGate.matchesDomain("mobile.alipay.com", "*.alipay.com"));
    }

    @Test
    public void matches_exactTenpay() {
        assertTrue(PaymentGate.matchesDomain("tenpay.com", "tenpay.com"));
    }

    @Test
    public void matches_exactWeixinPay() {
        assertTrue(PaymentGate.matchesDomain("pay.weixin.qq.com", "pay.weixin.qq.com"));
    }

    @Test
    public void domainOnly_alipayComSlashCashier_triggers() {
        // domain-only: alipay.com/cashier → 命中（path 不参与触发）
        assertTrue(PaymentGate.matchesDomain("www.alipay.com", "*.alipay.com"));
    }

    @Test
    public void domainOnly_exampleComSlashCashier_doesNotTrigger() {
        // domain-only: example.com 不在白名单，即使 path 是 /cashier
        assertFalse(PaymentGate.matchesDomain("example.com", "*.alipay.com"));
        assertFalse(PaymentGate.matchesDomain("example.com", "tenpay.com"));
        assertFalse(PaymentGate.matchesDomain("example.com", "pay.weixin.qq.com"));
    }

    @Test
    public void rejects_suffixSpoofing() {
        // 左锚定防后缀欺骗: alipay.com.evil.com 不应匹配 *.alipay.com
        assertFalse(PaymentGate.matchesDomain("alipay.com.evil.com", "*.alipay.com"));
    }

    @Test
    public void rejects_exactSuffix() {
        // *.alipay.com 不匹配 alipay.com 本身（至少一级子域）
        assertFalse(PaymentGate.matchesDomain("alipay.com", "*.alipay.com"));
    }

    @Test
    public void hostExtraction() {
        assertEquals("www.alipay.com",
                PaymentGate.extractHost("https://www.alipay.com/cashier/pay?amount=128"));
        assertEquals("pay.weixin.qq.com",
                PaymentGate.extractHost("https://pay.weixin.qq.com/order"));
    }

    // ==================== §8.2 金额掩码 ====================

    @Test
    public void maskAmount_basic() {
        PaymentGate pg = new PaymentGate(null);
        String result = pg.maskAmount("price=128.50");
        assertTrue(result.contains("¥"));
        assertFalse("掩码后不应暴露原始金额", result.contains("128.50"));
    }

    @Test
    public void maskAmount_singleDigit() {
        PaymentGate pg = new PaymentGate(null);
        String result = pg.maskAmount("amount=5");
        assertTrue(result.contains("¥*"));
    }

    @Test
    public void maskAmount_smallDecimal() {
        PaymentGate pg = new PaymentGate(null);
        String result = pg.maskAmount("total=0.01");
        assertTrue(result.contains("¥"));
        assertFalse("掩码后不应暴露原始金额", result.contains("0.01"));
    }

    @Test
    public void maskOrderId() {
        PaymentGate pg = new PaymentGate(null);
        String result = pg.maskOrderId("order=2026073012345678");
        assertEquals("2026****5678", result);
    }

    @Test
    public void maskOrderId_short() {
        PaymentGate pg = new PaymentGate(null);
        String result = pg.maskOrderId("order=1234");
        assertEquals("不足 8 位全部掩码", "****", result);
    }
}
