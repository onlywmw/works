package com.hermes.android.serve;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * RoomStaticServer 路由分发纯逻辑单测 (零网络, 真实临时目录)。
 * 范式同 MovInboundServerTest (dispatch 直调) + StorageManagerCanonicalTest (临时目录)。
 */
public class RoomStaticServerTest {

    private File roomsDir;

    @Before
    public void setUp() throws Exception {
        roomsDir = Files.createTempDirectory("roomstat").toFile();
        File proj = new File(roomsDir, "testroom/files/work/proj");
        proj.mkdirs();
        write(proj, "index.html", "<!DOCTYPE html><html><body>hi</body></html>");
        write(proj, "style.css", "body{background:#e11d48}");
        write(proj, "app.js", "document.title='ok';");
        /* 二进制图片 (PNG magic bytes) */
        write(proj, "pic.png", new byte[]{ (byte) 0x89, 'P', 'N', 'G', 0x0d, 0x0a, 0x1a, 0x0a });
        /* work 目录外的文件 (越界目标) */
        write(new File(roomsDir, "testroom/files"), "secret.txt", "secret");
    }

    @After
    public void tearDown() {
        deleteRec(roomsDir);
    }

    @Test
    public void getHtml_returns200() {
        RoomStaticServer.Response r = RoomStaticServer.dispatch("GET",
                "/rooms/testroom/files/work/proj/index.html", roomsDir);
        assertEquals(200, r.status);
        assertTrue(r.mime.startsWith("text/html"));
        assertEquals("<!DOCTYPE html><html><body>hi</body></html>",
                new String(r.body, StandardCharsets.UTF_8));
    }

    @Test
    public void getCss_mime() {
        RoomStaticServer.Response r = RoomStaticServer.dispatch("GET",
                "/rooms/testroom/files/work/proj/style.css", roomsDir);
        assertEquals(200, r.status);
        assertTrue(r.mime.startsWith("text/css"));
    }

    @Test
    public void getJs_mime() {
        RoomStaticServer.Response r = RoomStaticServer.dispatch("GET",
                "/rooms/testroom/files/work/proj/app.js", roomsDir);
        assertEquals(200, r.status);
        assertTrue(r.mime.contains("javascript"));
    }

    @Test
    public void getBinary_imageBytesRoundtrip() {
        RoomStaticServer.Response r = RoomStaticServer.dispatch("GET",
                "/rooms/testroom/files/work/proj/pic.png", roomsDir);
        assertEquals(200, r.status);
        assertEquals("image/png", r.mime);
        assertEquals(8, r.body.length);
        assertEquals((byte) 0x89, r.body[0]);
        assertEquals((byte) 0x0a, r.body[7]);
    }

    @Test
    public void pathTraversal_rejected() {
        RoomStaticServer.Response r = RoomStaticServer.dispatch("GET",
                "/rooms/testroom/files/work/../secret.txt", roomsDir);
        assertEquals(400, r.status);
    }

    @Test
    public void badRoomId_rejected() {
        /* roomId 含 . (正则白名单外) → 400 */
        RoomStaticServer.Response r = RoomStaticServer.dispatch("GET",
                "/rooms/test..room/files/work/x.html", roomsDir);
        assertEquals(400, r.status);
    }

    @Test
    public void missingFile_404() {
        RoomStaticServer.Response r = RoomStaticServer.dispatch("GET",
                "/rooms/testroom/files/work/nope.html", roomsDir);
        assertEquals(404, r.status);
    }

    @Test
    public void nonGet_405() {
        RoomStaticServer.Response r = RoomStaticServer.dispatch("POST",
                "/rooms/testroom/files/work/proj/index.html", roomsDir);
        assertEquals(405, r.status);
    }

    @Test
    public void notUnderFilesWork_404() {
        /* work 目录外的文件 (files/ 下但不在 work/) → 404 */
        RoomStaticServer.Response r = RoomStaticServer.dispatch("GET",
                "/rooms/testroom/files/secret.txt", roomsDir);
        assertEquals(404, r.status);
    }

    @Test
    public void badPrefix_404() {
        RoomStaticServer.Response r = RoomStaticServer.dispatch("GET",
                "/other/testroom/files/work/x.html", roomsDir);
        assertEquals(404, r.status);
    }

    @Test
    public void isWithin_canonical() {
        File base = new File(roomsDir, "testroom/files/work");
        assertTrue(RoomStaticServer.isWithin(base, new File(base, "proj/index.html")));
        assertFalse(RoomStaticServer.isWithin(base,
                new File(roomsDir, "testroom/files/secret.txt")));
    }

    private static void write(File dir, String name, String content) throws Exception {
        Files.write(new File(dir, name).toPath(), content.getBytes(StandardCharsets.UTF_8));
    }

    private static void write(File dir, String name, byte[] data) throws Exception {
        Files.write(new File(dir, name).toPath(), data);
    }

    private static void deleteRec(File f) {
        if (f == null || !f.exists()) return;
        File[] cs = f.listFiles();
        if (cs != null) for (File c : cs) deleteRec(c);
        f.delete();
    }
}
