package com.hermes.android.workflow;

import org.junit.Test;

import java.util.Calendar;

import static org.junit.Assert.*;

/**
 * CronParser 最小集单测（纯 JVM，设备时区）——合法/非法/边界 0 分 0 时/next-fire。
 */
public class CronParserTest {

    /** "yyyy-MM-dd HH:mm" → epoch（设备时区） */
    private static long at(String yyyyMMddHHmm) {
        String[] d = yyyyMMddHHmm.split(" ");
        String[] date = d[0].split("-");
        String[] time = d[1].split(":");
        Calendar c = Calendar.getInstance();
        c.set(Integer.parseInt(date[0]), Integer.parseInt(date[1]) - 1, Integer.parseInt(date[2]),
                Integer.parseInt(time[0]), Integer.parseInt(time[1]), 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    @Test public void anyFieldMatches() {
        assertTrue(CronParser.matches("* * * *", at("2026-08-01 09:15")));
    }

    @Test public void specificHourMinute() {
        assertTrue(CronParser.matches("15 9 * *", at("2026-08-01 09:15")));
        assertFalse("分钟不匹配", CronParser.matches("15 9 * *", at("2026-08-01 09:16")));
        assertFalse("小时不匹配", CronParser.matches("15 9 * *", at("2026-08-01 10:15")));
    }

    @Test public void stepMinutes() {
        assertTrue(CronParser.matches("*/15 * * *", at("2026-08-01 09:15")));
        assertTrue(CronParser.matches("*/15 * * *", at("2026-08-01 09:30")));
        assertFalse(CronParser.matches("*/15 * * *", at("2026-08-01 09:17")));
    }

    @Test public void zeroBoundary() {
        // 边界 0 分 0 时：00:00 匹配，00:01 不匹配
        assertTrue(CronParser.matches("0 0 * *", at("2026-08-01 00:00")));
        assertFalse(CronParser.matches("0 0 * *", at("2026-08-01 00:01")));
    }

    @Test public void dayOfWeekMatches() {
        // 2026-08-01 是周六（cron dow 0=Sun, 6=Sat）
        assertTrue(CronParser.matches("0 9 * 6", at("2026-08-01 09:00")));
        assertFalse(CronParser.matches("0 9 * 0", at("2026-08-01 09:00")));
    }

    @Test public void invalidCronRejected() {
        assertFalse("空表达式", CronParser.matches("", at("2026-08-01 09:15")));
        assertFalse("null", CronParser.matches(null, at("2026-08-01 09:15")));
        assertFalse("3 字段非法", CronParser.matches("0 9 *", at("2026-08-01 09:15")));
        assertFalse("5 字段非法", CronParser.matches("0 9 1 1 1", at("2026-08-01 09:15")));
    }

    @Test public void nextFireCalculation() {
        long from = at("2026-08-01 09:00");
        assertEquals("下一个 10:00", at("2026-08-01 10:00"), CronParser.nextFire("0 10 * *", from));
        assertEquals("下一个整分", at("2026-08-01 09:01"), CronParser.nextFire("* * * *", from));
    }

    @Test public void nextFire_invalidReturnsMinusOne() {
        assertEquals(-1, CronParser.nextFire("", at("2026-08-01 09:00")));
    }
}
