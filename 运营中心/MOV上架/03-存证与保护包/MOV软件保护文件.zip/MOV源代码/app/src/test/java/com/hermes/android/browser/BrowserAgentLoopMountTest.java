package com.hermes.android.browser;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.junit.Test;

import java.util.Collections;
import java.util.HashSet;

import static org.junit.Assert.*;

/**
 * P2#2: AgentLoop 侧 browser_* 挂载验证——
 * BrowserToolProvider 经 addProvider + buildFromProviders 进 ToolRegistry（AgentLoop 用同一构建路径），
 * 挂载后 find("browser.*") 可达。零网络，纯 JVM。
 */
public class BrowserAgentLoopMountTest {

    private static AgentLoop.Tools minimalTools() {
        return new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return "[]"; }
            @Override public String fileRead(String roomId, String path) { return ""; }
            @Override public String fileWrite(String roomId, String path, String c) { return "OK:"; }
            @Override public String capabilityOf(String text) { return ""; }
            @Override public String deviceCmd(String text) { return "ok"; }
            @Override public String packageApk(String roomId, String path, String n) { return "{\"ok\":false}"; }
            @Override public String shellExec(String cmd, int timeoutSec) { return "exit=0\n"; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":false}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":false}"; }
        };
    }

    private static ToolRegistry registryWithBrowser() {
        ToolRegistry r = ToolRegistry.build(minimalTools(), "room1",
                HashSet::new, ToolRegistry.policyForTest(Collections.<String>emptySet()), true);
        r.addProvider(new BrowserToolProvider());
        r.buildFromProviders();
        return r;
    }

    @Test public void browserTools_mounted_discoverableViaFind() {
        ToolRegistry r = registryWithBrowser();
        assertNotNull("browser.open 挂载可达", r.find("browser.open"));
        assertNotNull("browser.wait_for 挂载可达", r.find("browser.wait_for"));
        assertNotNull("browser.scroll 挂载可达", r.find("browser.scroll"));
        assertNotNull("browser.click 挂载可达", r.find("browser.click"));
        assertNotNull("browser.type 挂载可达", r.find("browser.type"));
        assertNotNull("browser.submit 挂载可达", r.find("browser.submit"));
        assertNotNull("browser.click_and_read 挂载可达", r.find("browser.click_and_read"));
        assertNotNull("browser.done 挂载可达（双超时收尾）", r.find("browser.done"));
    }

    @Test public void browserTools_mounted_haveActionTier() {
        ToolRegistry r = registryWithBrowser();
        ToolRegistry.Tool open = r.find("browser.open");
        assertNotNull(open);
        assertEquals("browser.open 是 ACTION（写/导航）", "ACTION", tierOf(open));
        assertTrue("browser.open 声明的 timeoutSec 不超硬超时 30s",
                open.timeoutSec <= ToolRuntimeLimits.PER_TOOL_HARD_TIMEOUT_S);
    }

    private static String tierOf(ToolRegistry.Tool t) {
        if ("readonly".equals(t.access)) return "READONLY";
        if ("always".equals(t.approval)) return "DANGEROUS";
        return "ACTION";
    }
}
