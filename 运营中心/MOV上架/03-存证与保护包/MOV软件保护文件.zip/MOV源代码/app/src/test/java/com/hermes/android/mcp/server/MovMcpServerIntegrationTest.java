package com.hermes.android.mcp.server;

import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.mcp.Jackson2McpJsonMapper;

import io.modelcontextprotocol.json.McpJsonMapper;
import io.modelcontextprotocol.server.McpServer;
import io.modelcontextprotocol.server.McpServerFeatures;
import io.modelcontextprotocol.server.McpSyncServer;
import io.modelcontextprotocol.spec.McpSchema;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * 集成测试 — AndroidStreamableHttpTransport + AndroidHttpServer + McpServer.sync 全栈。
 *
 * 两条验证路径：
 *  1. 原生 HTTP 帧：initialize 握手拿 Mcp-Session-Id / 鉴权 fail-closed / tools/list·call SSE
 *  2. 官方 McpSyncClient（streamable HTTP）直连：initialize → listTools → callTool 全通
 *     ——证明协议层是官方 SDK 状态机，主流 MCP client 天然兼容。
 */
public class MovMcpServerIntegrationTest {

    private static final String TOKEN = "mov-test-token-8389";
    private static AndroidHttpServer http;
    private static McpSyncServer server;

    @BeforeClass
    public static void setUp() throws Exception {
        McpJsonMapper mapper = new Jackson2McpJsonMapper();
        AndroidStreamableHttpTransport transport = new AndroidStreamableHttpTransport(mapper, TOKEN);

        server = McpServer.sync(transport)
                .serverInfo("mov", "1.0.0")
                .capabilities(McpSchema.ServerCapabilities.builder().tools(true).build())
                .jsonMapper(mapper)
                .build();

        // 注册 echo 只读工具（P1 暴露语义：readonly）
        ToolRegistry.Tool echo = new ToolRegistry.Tool("echo", "Echo test", null,
                a -> new ToolRegistry.Result(true, "pong:" + a.optString("text")),
                "native", "readonly", "none", true, 10);
        server.addTool(new McpServerFeatures.SyncToolSpecification(
                McpToolAdapter.toSchema(echo), McpToolAdapter.handlerFor(echo)));

        http = new AndroidHttpServer(0, transport);
        assertTrue("HTTP server 应启动", http.start());
    }

    @AfterClass
    public static void tearDown() {
        if (http != null) http.stop();
        if (server != null) server.closeGracefully();
    }

    private static String url() {
        return "http://127.0.0.1:" + http.getPort();
    }

    // ═══ 原生 HTTP 帧 ═══

    private HttpURLConnection post(String path, String body, String accept, String sessionId) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(url() + path).openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Accept", accept);
        conn.setRequestProperty("Authorization", "Bearer " + TOKEN);
        if (sessionId != null) conn.setRequestProperty("Mcp-Session-Id", sessionId);
        conn.setDoOutput(true);
        conn.getOutputStream().write(body.getBytes(StandardCharsets.UTF_8));
        return conn;
    }

    private String read(HttpURLConnection conn) throws IOException {
        InputStream is = conn.getErrorStream() != null ? conn.getErrorStream() : conn.getInputStream();
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] b = new byte[4096];
        int n;
        while ((n = is.read(b)) != -1) buf.write(b, 0, n);
        return buf.toString("UTF-8");
    }

    private static final String INIT_BODY = "{\"jsonrpc\":\"2.0\",\"method\":\"initialize\",\"id\":1,"
            + "\"params\":{\"protocolVersion\":\"2024-11-05\",\"capabilities\":{\"tools\":{}},"
            + "\"clientInfo\":{\"name\":\"mov-test\",\"version\":\"1.0\"}}}";

    @Test public void initialize_returnsSessionId() throws Exception {
        HttpURLConnection conn = post("/mcp", INIT_BODY, "application/json, text/event-stream", null);
        assertEquals(200, conn.getResponseCode());
        String sid = conn.getHeaderField("Mcp-Session-Id");
        assertNotNull("initialize 应返回 Mcp-Session-Id", sid);
        String body = read(conn);
        assertTrue("响应含协议版本", body.contains("protocolVersion"));
        assertTrue("响应含 serverInfo", body.contains("serverInfo"));
    }

    @Test public void auth_missingToken_401() throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url() + "/mcp").openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Accept", "application/json, text/event-stream");
        conn.setDoOutput(true);
        conn.getOutputStream().write(INIT_BODY.getBytes(StandardCharsets.UTF_8));
        assertEquals("缺 token 应 401", 401, conn.getResponseCode());
        assertTrue(read(conn).contains("token"));
    }

    @Test public void auth_wrongToken_401() throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url() + "/mcp").openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Accept", "application/json, text/event-stream");
        conn.setRequestProperty("Authorization", "Bearer wrong-token");
        conn.setDoOutput(true);
        conn.getOutputStream().write(INIT_BODY.getBytes(StandardCharsets.UTF_8));
        assertEquals(401, conn.getResponseCode());
    }

    @Test public void unknownPath_404() throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url() + "/nope").openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + TOKEN);
        conn.setDoOutput(true);
        conn.getOutputStream().write("{}".getBytes(StandardCharsets.UTF_8));
        assertEquals(404, conn.getResponseCode());
    }

    @Test public void toolsList_streamableSse() throws Exception {
        // initialize 拿 session id
        HttpURLConnection init = post("/mcp", INIT_BODY, "application/json, text/event-stream", null);
        String sid = init.getHeaderField("Mcp-Session-Id");
        read(init);

        String listBody = "{\"jsonrpc\":\"2.0\",\"method\":\"tools/list\",\"id\":2,"
                + "\"params\":{\"cursor\":null}}";
        HttpURLConnection conn = post("/mcp", listBody, "application/json, text/event-stream", sid);
        assertEquals(200, conn.getResponseCode());
        assertTrue("应为 text/event-stream，实际: " + conn.getContentType(),
                conn.getContentType() != null && conn.getContentType().contains("text/event-stream"));
        String body = read(conn);
        assertTrue("SSE 事件含 data 帧", body.contains("event: message"));
        assertTrue("含注册工具 echo", body.contains("\"echo\""));
        assertTrue("含标准 inputSchema", body.contains("inputSchema"));
    }

    @Test public void toolsCall_echo_returnsPong() throws Exception {
        HttpURLConnection init = post("/mcp", INIT_BODY, "application/json, text/event-stream", null);
        String sid = init.getHeaderField("Mcp-Session-Id");
        read(init);

        String callBody = "{\"jsonrpc\":\"2.0\",\"method\":\"tools/call\",\"id\":3,"
                + "\"params\":{\"name\":\"echo\",\"arguments\":{\"text\":\"hi\"}}}";
        HttpURLConnection conn = post("/mcp", callBody, "application/json, text/event-stream", sid);
        assertEquals(200, conn.getResponseCode());
        String body = read(conn);
        assertTrue("调用结果含 pong", body.contains("pong:hi"));
        assertFalse("结果不带 error", body.contains("\"error\""));
    }

    @Test public void toolsCall_unknownTool_errorEnvelope() throws Exception {
        HttpURLConnection init = post("/mcp", INIT_BODY, "application/json, text/event-stream", null);
        String sid = init.getHeaderField("Mcp-Session-Id");
        read(init);

        String callBody = "{\"jsonrpc\":\"2.0\",\"method\":\"tools/call\",\"id\":4,"
                + "\"params\":{\"name\":\"nope\",\"arguments\":{}}}";
        HttpURLConnection conn = post("/mcp", callBody, "application/json, text/event-stream", sid);
        assertEquals(200, conn.getResponseCode());
        String body = read(conn);
        assertTrue("未知工具返回 JSON-RPC error", body.contains("\"error\""));
    }

    @Test public void missingSessionId_400() throws Exception {
        String listBody = "{\"jsonrpc\":\"2.0\",\"method\":\"tools/list\",\"id\":5}";
        HttpURLConnection conn = post("/mcp", listBody, "application/json, text/event-stream", null);
        assertEquals(400, conn.getResponseCode());
    }

    /*
     * 注：SDK client 直连（McpClient.sync + HttpClientStreamableHttpTransport）在 JVM 单测中
     * 无法编译——android.jar bootclasspath 不含 java.net.http（Android 平台无该模块），
     * 而官方 client transport 依赖它。SDK client 兼容性验证留待真机：MCP Inspector
     * （官方 SDK client）连 127.0.0.1:8389/mcp，即 P1 验证清单的 initialize/tools/list/call。
     * 本测试已用原生 HTTP 帧覆盖协议全路径（握手/session/SSE/鉴权/错误信封），
     * 帧格式与官方 HttpServletStreamableServerTransportProvider 同构。
     */
}
