package com.hermes.android.mcp;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.Socket;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * McpServer 行为测试 — 构造真实 JSON-RPC 请求字符串，走 dispatch 全路径，断言响应码/结构。
 *
 * 原则：每条断言都能回答"它防住什么回归"。
 * 不测 org.json 库行为，不锁定内部实现细节。
 *
 * 技巧：工具注册用 static 方法 → Method.invoke(null, args) 有效，
 * 无需注入 bridge 字段（bridge 可为 null，因为 static 方法忽略实例）。
 */
public class McpServerTest {

    // ═══ 测试桩: static 方法, invoke 时不需要实例 ═══

    @android.webkit.JavascriptInterface
    public static String echo(String text) {
        return text;
    }

    @android.webkit.JavascriptInterface
    public static String greet(String name) {
        return "Hello, " + name;
    }

    @android.webkit.JavascriptInterface
    public static String noArgs() {
        return "ok";
    }

    // ═══ 辅助方法 ═══

    /** 反射调用 McpServer.dispatch(String) */
    private String dispatch(McpServer server, String json) throws Exception {
        Method m = McpServer.class.getDeclaredMethod("dispatch", String.class);
        m.setAccessible(true);
        return (String) m.invoke(server, json);
    }

    /**
     * 创建 McpServer 并注册一个测试工具（使用 static 方法，无需 bridge）。
     * @return {server, firstParamName}
     */
    private Object[] serverWithTool(String toolName, String methodName) throws Exception {
        McpServer server = new McpServer();

        Field toolsField = McpServer.class.getDeclaredField("tools");
        toolsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<String, McpServer.ToolDescriptor> tools =
                (Map<String, McpServer.ToolDescriptor>) toolsField.get(server);

        Method bridgeMethod = McpServerTest.class.getMethod(methodName, String.class);
        McpServer.ToolDescriptor td = McpServer.ToolDescriptor.from(bridgeMethod);
        tools.put(toolName, td.withDesc("测试工具: " + toolName));

        return new Object[]{server, td.paramNames};
    }

    /** 创建 McpServer 并注册一个无参工具 */
    private McpServer serverWithNoArgTool(String toolName, String methodName) throws Exception {
        McpServer server = new McpServer();

        Field toolsField = McpServer.class.getDeclaredField("tools");
        toolsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<String, McpServer.ToolDescriptor> tools =
                (Map<String, McpServer.ToolDescriptor>) toolsField.get(server);

        Method bridgeMethod = McpServerTest.class.getMethod(methodName);
        McpServer.ToolDescriptor td = McpServer.ToolDescriptor.from(bridgeMethod);
        tools.put(toolName, td.withDesc("无参工具: " + toolName));

        return server;
    }

    /** 从 server 获取已注册工具的第一个参数名 */
    private String firstParamName(McpServer server) throws Exception {
        Field toolsField = McpServer.class.getDeclaredField("tools");
        toolsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<String, McpServer.ToolDescriptor> tools =
                (Map<String, McpServer.ToolDescriptor>) toolsField.get(server);
        return tools.values().iterator().next().paramNames[0];
    }

    // ═══ 测试: JSON-RPC 协议路由 ═══

    @Test
    public void toolsList_returnsValidJsonRpcWithToolsArray() throws Exception {
        // 防回归: tools/list 返回合法的 JSON-RPC 响应，外部 MCP 客户端依赖此格式
        Object[] setup = serverWithTool("echo", "echo");
        McpServer server = (McpServer) setup[0];

        String resp = dispatch(server,
                "{\"jsonrpc\":\"2.0\",\"method\":\"tools/list\",\"id\":1}");
        JSONObject r = new JSONObject(resp);

        assertEquals("jsonrpc 版本", "2.0", r.getString("jsonrpc"));
        assertEquals("id 回传", 1, r.getInt("id"));
        assertFalse("无 error 字段", r.has("error"));
        assertTrue("有 result", r.has("result"));
        JSONArray tools = r.getJSONObject("result").getJSONArray("tools");
        assertEquals("工具数", 1, tools.length());
        assertEquals("工具名", "echo", tools.getJSONObject(0).getString("name"));
        assertTrue("有 inputSchema", tools.getJSONObject(0).has("inputSchema"));
    }

    @Test
    public void toolsList_emptyRegistry_returnsEmptyArray() throws Exception {
        // 防回归: 无工具注册时 tools/list 不崩溃，返回空数组
        McpServer server = new McpServer();
        String resp = dispatch(server,
                "{\"jsonrpc\":\"2.0\",\"method\":\"tools/list\",\"id\":1}");
        JSONObject r = new JSONObject(resp);
        assertEquals(0, r.getJSONObject("result").getJSONArray("tools").length());
    }

    @Test
    public void unknownMethod_returnsMinus32601() throws Exception {
        // 防回归: JSON-RPC 协议要求未知方法返回 -32601 Method not found
        McpServer server = new McpServer();
        String resp = dispatch(server,
                "{\"jsonrpc\":\"2.0\",\"method\":\"nonexistent\",\"id\":1}");
        JSONObject r = new JSONObject(resp);
        assertTrue("有 error", r.has("error"));
        assertEquals("错误码 -32601", -32601, r.getJSONObject("error").getInt("code"));
        assertTrue("错误信息包含方法名",
                r.getJSONObject("error").getString("message").contains("nonexistent"));
    }

    @Test
    public void invalidJson_returnsMinus32700() throws Exception {
        // 防回归: 非法 JSON 导致 -32700 Parse error，不导致服务崩溃
        McpServer server = new McpServer();
        String resp = dispatch(server, "this is not valid json at all");
        JSONObject r = new JSONObject(resp);
        assertTrue("有 error", r.has("error"));
        assertEquals("错误码 -32700", -32700, r.getJSONObject("error").getInt("code"));
    }

    @Test
    public void toolsCall_missingParams_returnsMinus32602() throws Exception {
        // 防回归: tools/call 缺少 params 时拒绝，不 NPE
        McpServer server = new McpServer();
        String resp = dispatch(server,
                "{\"jsonrpc\":\"2.0\",\"method\":\"tools/call\",\"id\":1}");
        JSONObject r = new JSONObject(resp);
        assertTrue("有 error", r.has("error"));
        assertEquals("错误码 -32602", -32602, r.getJSONObject("error").getInt("code"));
        assertTrue("错误信息提及 params",
                r.getJSONObject("error").getString("message").contains("params"));
    }

    // ═══ 测试: args / arguments 双键兼容 (BUG-2 回归) ═══

    @Test
    public void toolsCall_argumentsKey_mcpStandardCompat() throws Exception {
        // BUG-2 回归: MCP 标准协议使用 arguments 键，callTool 必须兼容。
        // 构造真实 MCP 标准请求走 dispatch → callTool 全路径，不做"把 mock 答案
        // 喂给解析器再断言解析结果"的自我循环论证。
        Object[] setup = serverWithTool("echo", "echo");
        McpServer server = (McpServer) setup[0];
        String pn = firstParamName(server);

        String json = "{\"jsonrpc\":\"2.0\",\"method\":\"tools/call\"," +
                "\"params\":{\"name\":\"echo\",\"arguments\":{\"" + pn + "\":\"mcp_standard\"}},\"id\":2}";
        String resp = dispatch(server, json);
        JSONObject r = new JSONObject(resp);

        assertFalse("无 error — arguments 键被正确识别", r.has("error"));
        assertTrue("有 result", r.has("result"));
        String content = r.getJSONObject("result").optString("content", "");
        assertEquals("回显 MCP 标准键传入的值", "mcp_standard", content);
    }

    @Test
    public void toolsCall_argsKey_movCustomKeyAlsoWorks() throws Exception {
        // BUG-2 回归: 确保 args 键（MOV 自定义键）没被 arguments 兼容逻辑破坏
        Object[] setup = serverWithTool("echo", "echo");
        McpServer server = (McpServer) setup[0];
        String pn = firstParamName(server);

        String json = "{\"jsonrpc\":\"2.0\",\"method\":\"tools/call\"," +
                "\"params\":{\"name\":\"echo\",\"args\":{\"" + pn + "\":\"mov_custom\"}},\"id\":3}";
        String resp = dispatch(server, json);
        JSONObject r = new JSONObject(resp);

        assertFalse("无 error — args 键仍有效", r.has("error"));
        String content = r.getJSONObject("result").optString("content", "");
        assertEquals("回显 MOV 键传入的值", "mov_custom", content);
    }

    @Test
    public void toolsCall_argsPriority_overArguments() throws Exception {
        // BUG-2 回归: 同时有 args 和 arguments 时，args 优先（args 先 opt，
        // 只有 args==null 时才 fallback 到 arguments）。
        Object[] setup = serverWithTool("echo", "echo");
        McpServer server = (McpServer) setup[0];
        String pn = firstParamName(server);

        JSONObject args = new JSONObject();
        args.put(pn, "from_args");
        JSONObject arguments = new JSONObject();
        arguments.put(pn, "from_arguments");
        JSONObject params = new JSONObject();
        params.put("name", "echo");
        params.put("args", args);
        params.put("arguments", arguments);
        JSONObject req = new JSONObject();
        req.put("jsonrpc", "2.0");
        req.put("method", "tools/call");
        req.put("params", params);
        req.put("id", 4);

        String resp = dispatch(server, req.toString());
        JSONObject r = new JSONObject(resp);
        assertFalse("无 error", r.has("error"));
        String content = r.getJSONObject("result").optString("content", "");
        assertEquals("args 优先于 arguments", "from_args", content);
    }

    // ═══ 测试: 缺参与未知工具 ═══

    @Test
    public void toolsCall_unknownTool_returnsMinus32602() throws Exception {
        // 防回归: 工具不存在时返回明确错误，而不是不明 NPE
        Object[] setup = serverWithTool("echo", "echo");
        McpServer server = (McpServer) setup[0];

        String resp = dispatch(server,
                "{\"jsonrpc\":\"2.0\",\"method\":\"tools/call\"," +
                "\"params\":{\"name\":\"does_not_exist\",\"arguments\":{}},\"id\":5}");
        JSONObject r = new JSONObject(resp);
        assertEquals("错误码 -32602", -32602, r.getJSONObject("error").getInt("code"));
        assertTrue("错误信息包含工具名",
                r.getJSONObject("error").getString("message").contains("does_not_exist"));
    }

    @Test
    public void toolsCall_missingRequiredArg_returnsMinus32602() throws Exception {
        // BUG-13b 回归: 必填参数缺参 → -32602 拒绝，防止 null 传入 UI 方法导致主线程崩溃。
        // 注意：echo 有一个必填参数，传空 arguments 对象即触发缺参检查。
        Object[] setup = serverWithTool("echo", "echo");
        McpServer server = (McpServer) setup[0];

        String resp = dispatch(server,
                "{\"jsonrpc\":\"2.0\",\"method\":\"tools/call\"," +
                "\"params\":{\"name\":\"echo\",\"arguments\":{}},\"id\":6}");
        JSONObject r = new JSONObject(resp);
        assertEquals("错误码 -32602", -32602, r.getJSONObject("error").getInt("code"));
        assertTrue("错误信息提示缺参",
                r.getJSONObject("error").getString("message").contains("缺少必填参数"));
    }

    // ═══ 测试: 空参数工具正常工作 (验证无参工具不被缺参检查误杀) ═══

    @Test
    public void toolsCall_noArgs_works() throws Exception {
        // 防回归: 无参工具不应该被"缺少必填参数"检查误杀
        McpServer server = serverWithNoArgTool("noArgs", "noArgs");

        String resp = dispatch(server,
                "{\"jsonrpc\":\"2.0\",\"method\":\"tools/call\"," +
                "\"params\":{\"name\":\"noArgs\",\"arguments\":{}},\"id\":7}");
        JSONObject r = new JSONObject(resp);
        assertFalse("无 error — 无参工具正常工作", r.has("error"));
        assertEquals("返回 ok", "ok", r.getJSONObject("result").optString("content"));
    }

    // ═══ 测试: 参数名可用性 (仅验证非空，不锁定实现) ═══

    @Test
    public void toolDescriptor_from_hasParamNames() throws Exception {
        // 防回归: ToolDescriptor.from() 总是产生非空 paramNames。
        // 编译时已开 -parameters，能拿到真实参数名。
        // 但即使反射失败，fallback 为 arg0/arg1... 也不能返回 null。
        Method m = McpServerTest.class.getMethod("greet", String.class);
        McpServer.ToolDescriptor td = McpServer.ToolDescriptor.from(m);

        assertEquals("参数数量", 1, td.paramNames.length);
        assertNotNull("参数名非空", td.paramNames[0]);
        assertFalse("参数名非空串", td.paramNames[0].isEmpty());
    }

    // ═══ 测试: 响应格式规范 ═══

    @Test
    public void errorResponse_hasJsonRpcAndId() throws Exception {
        // 防回归: 错误响应也必须带 jsonrpc 版本和 id，
        // 外部 MCP 客户端依赖 id 做请求-响应匹配
        McpServer server = new McpServer();
        String resp = dispatch(server,
                "{\"jsonrpc\":\"2.0\",\"method\":\"no_such\",\"id\":99}");
        JSONObject r = new JSONObject(resp);
        assertEquals("jsonrpc 版本", "2.0", r.getString("jsonrpc"));
        assertEquals("id 回传", 99, r.getInt("id"));
        assertTrue("有 error", r.has("error"));
        assertFalse("无 result（错误响应不含 result）", r.has("result"));
    }

    @Test
    public void successResponse_hasJsonRpcAndId() throws Exception {
        // 防回归: 成功响应格式一致
        Object[] setup = serverWithTool("echo", "echo");
        McpServer server = (McpServer) setup[0];
        String resp = dispatch(server,
                "{\"jsonrpc\":\"2.0\",\"method\":\"tools/list\",\"id\":42}");
        JSONObject r = new JSONObject(resp);
        assertEquals("jsonrpc 版本", "2.0", r.getString("jsonrpc"));
        assertEquals("id 回传", 42, r.getInt("id"));
        assertTrue("有 result", r.has("result"));
        assertFalse("无 error", r.has("error"));
    }

    @Test
    public void sensitiveBridgeMethods_denylistedFromRegistry() throws Exception {
        // R7 安全打回：旧 McpServer（127.0.0.1:10000-20000，dispatch 无 token 鉴权）不得把
        // getServeToken / setMcpWriteEnabled 反射成 MCP 工具（否则任意本机 App 匿名取走 serve token）
        McpServer server = new McpServer();
        Method btr = McpServer.class.getDeclaredMethod("buildToolRegistry");
        btr.setAccessible(true);
        btr.invoke(server);

        Field toolsField = McpServer.class.getDeclaredField("tools");
        toolsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<String, McpServer.ToolDescriptor> tools =
                (Map<String, McpServer.ToolDescriptor>) toolsField.get(server);

        assertFalse("getServeToken 不得注册成 MCP 工具（serve token 泄漏面）",
                tools.containsKey("getServeToken"));
        assertFalse("setMcpWriteEnabled 不得注册成 MCP 工具（写开关绕过面）",
                tools.containsKey("setMcpWriteEnabled"));
        assertTrue("普通桥方法仍暴露（denylist 只排除敏感方法）",
                tools.containsKey("getDeviceInfo"));
    }

    @Test
    public void buildToolRegistry_allowlist_onlyMcpExpose() throws Exception {
        // R7 存量安全整治：反射注册从 denylist 改 allowlist——只有 @McpExpose 标注的只读安全方法注册，
        // 危险/写/敏感方法默认不上网
        McpServer server = new McpServer();
        Method btr = McpServer.class.getDeclaredMethod("buildToolRegistry");
        btr.setAccessible(true);
        btr.invoke(server);
        Field toolsField = McpServer.class.getDeclaredField("tools");
        toolsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<String, McpServer.ToolDescriptor> tools =
                (Map<String, McpServer.ToolDescriptor>) toolsField.get(server);

        // @McpExpose 只读安全方法暴露
        assertTrue("getDeviceInfo（@McpExpose 只读）应暴露", tools.containsKey("getDeviceInfo"));
        assertTrue("query（@McpExpose 只读）应暴露", tools.containsKey("query"));
        // 危险方法未标 @McpExpose → 不上网
        assertFalse("execCommand（任意命令执行）不得暴露", tools.containsKey("execCommand"));
        assertFalse("installApk（装应用）不得暴露", tools.containsKey("installApk"));
        assertFalse("addModel（写模型含 Key）不得暴露", tools.containsKey("addModel"));
        assertFalse("saveWorkFile（写文件）不得暴露", tools.containsKey("saveWorkFile"));
        assertFalse("startServe（启动 serve daemon）不得暴露", tools.containsKey("startServe"));
        // mov.models 只留脱敏只读
        assertTrue("mov.models.list 保留（只读脱敏）", tools.containsKey("mov.models.list"));
        assertFalse("mov.models.add 移除（含 apiKey 写入，危险）", tools.containsKey("mov.models.add"));
        assertFalse("mov.models.set_default 移除（改默认大脑，危险）", tools.containsKey("mov.models.set_default"));
    }

    @Test
    public void authError_failClosed() {
        // R7：token 鉴权 fail-closed（无 token / 错 token / 服务端未配置 → 401；真 token → 通过）
        String okBody = "POST /mcp HTTP/1.1\r\nContent-Type: application/json\r\n\r\n";
        assertNotNull("无 token → 401", McpServer.authError(okBody, "secret-token"));
        assertNotNull("错 Bearer token → 401",
                McpServer.authError("POST /mcp HTTP/1.1\r\nAuthorization: Bearer wrong\r\n\r\n", "secret-token"));
        assertNotNull("错 X-Mov-Token → 401",
                McpServer.authError("POST /mcp HTTP/1.1\r\nX-Mov-Token: wrong\r\n\r\n", "secret-token"));
        assertNotNull("服务端未配置 token → 401（fail-closed）",
                McpServer.authError("POST /mcp HTTP/1.1\r\nAuthorization: Bearer x\r\n\r\n", ""));
        assertNull("真 Bearer token → 通过",
                McpServer.authError("POST /mcp HTTP/1.1\r\nAuthorization: Bearer secret-token\r\n\r\n", "secret-token"));
        assertNull("真 X-Mov-Token → 通过",
                McpServer.authError("POST /mcp HTTP/1.1\r\nX-Mov-Token: secret-token\r\n\r\n", "secret-token"));
    }

    @Test
    public void responseHeader_noCorsWildcard() {
        // R7：CORS 收紧——响应头不含 Access-Control-Allow-Origin: *
        byte[] body = "{}".getBytes();
        String h = McpServer.responseHeader(200, "200 OK", body);
        assertTrue("含状态行", h.startsWith("HTTP/1.1 200 OK"));
        assertTrue("含 Content-Length", h.contains("Content-Length: 2"));
        assertFalse("不含 Access-Control-Allow-Origin（CORS 收紧）",
                h.toLowerCase().contains("access-control-allow-origin"));
    }

    @Test
    public void maskKey_masksApiKey() {
        // R7：mov.models.export 明文 Key → 掩码（保留前后 4 位）
        assertEquals("长 key 保留前后4位", "skey****7890", McpServer.maskKey("skeyabcd7890"));
        assertEquals("短 key 全掩", "****", McpServer.maskKey("abc"));
        assertEquals("空 key 全掩", "****", McpServer.maskKey(""));
    }

    @Test
    public void handle_socketUnauthenticated_returns401() throws Exception {
        // R8：socket 级 401——McpServer.handle() 里的鉴权调用点（authError）被删时本测试必红
        // （无 token 请求应被拦 401，不拦则返回 200）。127.0.0.1 本机 socket，零外网。
        McpServer server = new McpServer("test-token");
        int port = server.start(null);
        assertTrue("server 应启动", port > 0);
        try {
            Socket s = new Socket("127.0.0.1", port);
            s.setSoTimeout(5000);
            OutputStream out = s.getOutputStream();
            out.write(("POST /mcp HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Type: application/json\r\n"
                    + "Content-Length: 2\r\n\r\n{}").getBytes());
            out.flush();
            String resp = readAll(s.getInputStream());
            assertTrue("无 token 请求应 401: " + resp, resp.startsWith("HTTP/1.1 401"));
            s.close();
        } finally {
            server.stop();
        }
    }

    private static String readAll(java.io.InputStream is) throws Exception {
        StringBuilder sb = new StringBuilder();
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) != -1) {
            sb.append(new String(buf, 0, n, "UTF-8"));
            if (sb.length() > 4096) break;
        }
        return sb.toString();
    }
}
