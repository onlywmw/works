/* ============================================================
   newface-match 回归测试（node，W1 清欠）
   跑法: node app/src/test/js/newface-match.test.js
   fuzzyScore 从 newface.js 抽出的真代码，node 直接测。
   ============================================================ */
'use strict';
const assert = require('assert');
const match = require('../../main/assets/js/newface-match.js');

// ══ 完全匹配 → 1.0 ══
assert.strictEqual(match.fuzzyScore('牛奶', '牛奶'), 1.0);
assert.strictEqual(match.fuzzyScore('红烧肉', '红烧肉'), 1.0);

// ══ 包含关系 → 0.85 ══
assert.strictEqual(match.fuzzyScore('牛奶', '鲜牛奶'), 0.85);   // 候选含目标
assert.strictEqual(match.fuzzyScore('牛肉面', '面'), 0.85);     // 目标含候选

// ══ 字符级匹配（共同字符/字长） ══
// 共同字符 0.67 ≥0.6 → 0.5 + 0.67*0.3 ≈ 0.70
const high = match.fuzzyScore('牛肉面', '牛肉汤');
assert.ok(high >= 0.6 && high <= 0.8, '高共同字符应 0.6-0.8，实际 ' + high);
// 共同字符 0.5 在 [0.4,0.6) → 0.45
assert.strictEqual(match.fuzzyScore('鱼香肉丝', '鱼香茄子'), 0.45);
// 共同字符 <0.4 → 0
assert.strictEqual(match.fuzzyScore('龙虾', '番茄炒蛋'), 0);

// ══ 空白归一化 ══
assert.strictEqual(match.fuzzyScore(' 红烧 肉 ', '红烧肉'), 1.0);

// ══ null/undefined 容错 ══
assert.strictEqual(match.fuzzyScore(null, 'x'), 0);
assert.strictEqual(match.fuzzyScore('x', undefined), 0);

// ══ 阈值边界：newface 调用处 fuzzyScore >= 0.6 判定命中 ══
assert.ok(match.fuzzyScore('漫长的季节', '漫长的季节 全集') >= 0.6, '追剧续播命中');
assert.ok(match.fuzzyScore('小苹果', '小苹果') >= 0.6);

// ══ 标签算法（badgeFor）：第 0 位最佳匹配 / score>0.7 推荐 / 否则空（W1 第一幕欠账清欠） ══
assert.strictEqual(match.badgeFor(0, 0.5), '🏆 最佳匹配');   // 排序第一恒最佳匹配
assert.strictEqual(match.badgeFor(0, 1.0), '🏆 最佳匹配');
assert.strictEqual(match.badgeFor(1, 0.85), '✨ 推荐');       // 非首位但高分 → 推荐
assert.strictEqual(match.badgeFor(1, 0.71), '✨ 推荐');
assert.strictEqual(match.badgeFor(1, 0.7), '');               // 阈值 0.7 不含（>0.7 才推荐）
assert.strictEqual(match.badgeFor(2, 0.7), '');
assert.strictEqual(match.badgeFor(1, 0.5), '');
assert.strictEqual(match.badgeFor(1, 0), '');

// ══ 随机抽评抽签（reviewDrawn）：确定性 + 40% 分布（W1 第二幕） ══
// 确定性：同 order 同日期结果一致（跑两次相等）
const r1 = match.reviewDrawn('ORD-001', '2026-08-03');
assert.strictEqual(r1, match.reviewDrawn('ORD-001', '2026-08-03'), '同 order 同日期应一致');
// 不同日期：至少跨多天时结果有变化（确定性但随盐变）
let varies = false;
for (let d = 0; d < 30; d++) {
  const day = '2026-08-' + String(d + 1).padStart(2, '0');
  if (match.reviewDrawn('ORD-001', day) !== r1) { varies = true; break; }
}
assert.ok(varies, '不同日期盐应改变抽签结果（30 天内有变化）');
// 40% 阈值：500 个不同 order 同日期，抽中率应大致符合（±10%）
let drawn = 0, N = 500;
for (let i = 0; i < N; i++) if (match.reviewDrawn('o' + i, '2026-08-03')) drawn++;
assert.ok(drawn >= N * 0.30 && drawn <= N * 0.50, '40% 抽中率应大致符合，实际 ' + drawn + '/' + N);
// 空 orderId 确定性（不崩）
assert.strictEqual(match.reviewDrawn('', '2026-08-03'), match.reviewDrawn('', '2026-08-03'));

console.log('✅ newface-match 全部断言通过（fuzzyScore + badgeFor + reviewDrawn 随机抽评）');
