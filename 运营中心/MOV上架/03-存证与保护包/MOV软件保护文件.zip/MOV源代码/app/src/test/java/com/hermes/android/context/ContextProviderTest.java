package com.hermes.android.context;

import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

/**
 * ContextProvider 单测 — fake SensorSource 驱动事件序列，走生产路径。
 *
 * <h3>审阅重点</h3>
 * 所有 4 族事件测试（battery/wifi/power/screen）均通过 inject*() → on*Changed()
 * 走完整的生产逻辑路径。变异测试（删穿越条件、删断连去重）必须红。
 */
public class ContextProviderTest {

    private File tmpDir;
    private ContextPersister persister;
    private FakeSensor fakeSensor;

    @Before
    public void setUp() {
        tmpDir = new File(System.getProperty("java.io.tmpdir"), "cp_test_" + System.nanoTime());
        tmpDir.mkdirs();
        persister = new ContextPersister(tmpDir);
        fakeSensor = new FakeSensor();
    }

    @After
    public void tearDown() {
        File[] files = tmpDir.listFiles();
        if (files != null) for (File f : files) f.delete();
        tmpDir.delete();
    }

    // ========================================================================
    //  Snapshot API
    // ========================================================================

    @Test
    public void snapshot_forwardsSensorData() {
        fakeSensor.wifiSsid = "OfficeWiFi";
        fakeSensor.batteryLevel = 75;
        fakeSensor.charging = true;
        fakeSensor.screenOn = true;
        fakeSensor.foregroundApp = "com.test";

        ContextProvider cp = newProvider();
        cp.start();
        ContextSnapshot s = cp.snapshot();

        assertEquals("OfficeWiFi", s.wifiSsid);
        assertEquals(Integer.valueOf(75), s.batteryLevel);
        assertTrue(s.isCharging);
        assertTrue(s.screenOn);
        assertEquals("com.test", s.foregroundApp);
        cp.stop();
    }

    // ========================================================================
    //  Battery — 生产路径：fake SensorSource 驱动电量序列
    //  变异靶心：删 onBatteryChanged 里的 prevLevel >= t / prevLevel < t 条件
    //            变异后同侧下降/上升也会触发 → RecordingListener 收到事件 → 断言 0 失败 → 红
    // ========================================================================

    @Test
    public void battery_below_crossingDown_fires() {
        // 25% → 19%：穿越 20% 线 → 触发 BATTERY_BELOW
        fakeSensor.batteryLevel = 25;
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.addBatteryListener(l, 20, false);

        fakeSensor.batteryLevel = 19;
        cp.injectBatteryEvent();

        assertEquals(1, l.events.size());
        ContextEvent ev = l.events.get(0);
        assertEquals(ContextEventType.BATTERY_BELOW, ev.type);
        assertEquals(Integer.valueOf(19), ev.after.batteryLevel);
        assertEquals(20, ev.getThreshold());
        cp.stop();
    }

    @Test
    public void battery_below_sameSide_doesNotFire() {
        // 15% → 12%：都在 20% 以下 → 非穿越 → 不触发
        fakeSensor.batteryLevel = 15;
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.addBatteryListener(l, 20, false);

        fakeSensor.batteryLevel = 12;
        cp.injectBatteryEvent();

        assertEquals("同侧不触发——删了穿越条件这行断言变红", 0, l.events.size());
        cp.stop();
    }

    @Test
    public void battery_above_crossingUp_fires() {
        // 78% → 82%：穿越 80% 线 → 触发 BATTERY_ABOVE
        fakeSensor.batteryLevel = 78;
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.addBatteryListener(l, 80, true);

        fakeSensor.batteryLevel = 82;
        cp.injectBatteryEvent();

        assertEquals(1, l.events.size());
        assertEquals(ContextEventType.BATTERY_ABOVE, l.events.get(0).type);
        assertEquals(80, l.events.get(0).getThreshold());
        cp.stop();
    }

    @Test
    public void battery_above_sameSide_doesNotFire() {
        // 85% → 92%：都在 80% 以上 → 非穿越 → 不触发
        fakeSensor.batteryLevel = 85;
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.addBatteryListener(l, 80, true);

        fakeSensor.batteryLevel = 92;
        cp.injectBatteryEvent();

        assertEquals("同侧不触发——删了穿越条件这行断言变红", 0, l.events.size());
        cp.stop();
    }

    @Test
    public void battery_exactThreshold_crossingDown_fires() {
        // 50% → 49%：≥50 变 <50 → 触发
        fakeSensor.batteryLevel = 50;
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.addBatteryListener(l, 50, false);

        fakeSensor.batteryLevel = 49;
        cp.injectBatteryEvent();

        assertEquals(1, l.events.size());
        assertEquals(ContextEventType.BATTERY_BELOW, l.events.get(0).type);
        cp.stop();
    }

    @Test
    public void battery_exactThreshold_crossingUp_fires() {
        // 49% → 50%：<50 变 ≥50 → 触发
        fakeSensor.batteryLevel = 49;
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.addBatteryListener(l, 50, true);

        fakeSensor.batteryLevel = 50;
        cp.injectBatteryEvent();

        assertEquals(1, l.events.size());
        assertEquals(ContextEventType.BATTERY_ABOVE, l.events.get(0).type);
        cp.stop();
    }

    @Test
    public void battery_twoListeners_bothNotified() {
        fakeSensor.batteryLevel = 30;
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l1 = new RecordingListener();
        RecordingListener l2 = new RecordingListener();
        cp.addBatteryListener(l1, 20, false);
        cp.addBatteryListener(l2, 20, false);

        fakeSensor.batteryLevel = 15;
        cp.injectBatteryEvent();

        assertEquals(1, l1.events.size());
        assertEquals(1, l2.events.size());
        cp.stop();
    }

    // ========================================================================
    //  WiFi — 生产路径：fake SensorSource 驱动 SSID
    //  变异靶心：删 onWifiChanged 的 !lastWifiConnected / lastWifiConnected 去重
    // ========================================================================

    @Test
    public void wifi_connect_fires() {
        fakeSensor.wifiSsid = null;
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.subscribe(l, ContextEventType.WIFI_CONNECTED);

        fakeSensor.wifiSsid = "HomeWiFi";
        cp.injectWifiEvent();

        assertEquals(1, l.events.size());
        assertEquals(ContextEventType.WIFI_CONNECTED, l.events.get(0).type);
        assertEquals("HomeWiFi", l.events.get(0).after.wifiSsid);
        cp.stop();
    }

    @Test
    public void wifi_sameState_doesNotFire() {
        // 已连 HomeWiFi → 仍然是 HomeWiFi → 不触发
        fakeSensor.wifiSsid = "HomeWiFi";
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.subscribe(l, ContextEventType.WIFI_CONNECTED);

        fakeSensor.wifiSsid = "HomeWiFi";
        cp.injectWifiEvent();

        assertEquals("重复 connect 不触发——删了去重这行变红", 0, l.events.size());
        cp.stop();
    }

    @Test
    public void wifi_disconnect_fires() {
        fakeSensor.wifiSsid = "HomeWiFi";
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.subscribe(l, ContextEventType.WIFI_DISCONNECTED);

        fakeSensor.wifiSsid = null;
        cp.injectWifiEvent();

        assertEquals(1, l.events.size());
        assertEquals(ContextEventType.WIFI_DISCONNECTED, l.events.get(0).type);
        cp.stop();
    }

    // ========================================================================
    //  Power — 生产路径：fake SensorSource 驱动充电状态
    //  变异靶心：删 onPowerChanged 的 !lastPowerConnected / lastPowerConnected 去重
    // ========================================================================

    @Test
    public void power_connect_fires() {
        fakeSensor.charging = false;
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.subscribe(l, ContextEventType.POWER_CONNECTED);

        fakeSensor.charging = true;
        cp.injectPowerEvent(true);

        assertEquals(1, l.events.size());
        assertEquals(ContextEventType.POWER_CONNECTED, l.events.get(0).type);
        cp.stop();
    }

    @Test
    public void power_sameState_doesNotFire() {
        fakeSensor.charging = true;
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.subscribe(l, ContextEventType.POWER_CONNECTED);

        fakeSensor.charging = true;
        cp.injectPowerEvent(true);

        assertEquals("重复 connect 不触发——删了去重这行变红", 0, l.events.size());
        cp.stop();
    }

    @Test
    public void power_disconnect_fires() {
        fakeSensor.charging = true;
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.subscribe(l, ContextEventType.POWER_DISCONNECTED);

        fakeSensor.charging = false;
        cp.injectPowerEvent(false);

        assertEquals(1, l.events.size());
        assertEquals(ContextEventType.POWER_DISCONNECTED, l.events.get(0).type);
        cp.stop();
    }

    // ========================================================================
    //  Screen — 生产路径：fake SensorSource 驱动屏幕状态
    //  变异靶心：删 onScreenChanged 的重复态去重（receiver 保证不会重复，
    //           但 inject 路径可构造，测试验证不依赖 receiver 假设）
    // ========================================================================

    @Test
    public void screen_on_fires() {
        fakeSensor.screenOn = false;
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.subscribe(l, ContextEventType.SCREEN_ON);

        fakeSensor.screenOn = true;
        cp.injectScreenEvent(true);

        assertEquals(1, l.events.size());
        assertEquals(ContextEventType.SCREEN_ON, l.events.get(0).type);
        cp.stop();
    }

    @Test
    public void screen_off_fires() {
        fakeSensor.screenOn = true;
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.subscribe(l, ContextEventType.SCREEN_OFF);

        fakeSensor.screenOn = false;
        cp.injectScreenEvent(false);

        assertEquals(1, l.events.size());
        assertEquals(ContextEventType.SCREEN_OFF, l.events.get(0).type);
        cp.stop();
    }

    // ========================================================================
    //  Subscription lifecycle
    // ========================================================================

    @Test
    public void zeroListeners_zeroReceivers() {
        ContextProvider cp = newProvider();
        cp.start();
        assertEquals(0, cp.getActiveReceiverCount());
        cp.stop();
    }

    @Test
    public void subscribe_increasesListenerCount() {
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.subscribe(l, ContextEventType.WIFI_CONNECTED);
        assertEquals(1, cp.getListenerCount());
        cp.unsubscribe(l);
        assertEquals(0, cp.getListenerCount());
        cp.stop();
    }

    @Test
    public void unsubscribe_nonexistent_noop() {
        ContextProvider cp = newProvider();
        cp.start();
        RecordingListener l = new RecordingListener();
        cp.unsubscribe(l);
        assertEquals(0, cp.getListenerCount());
        cp.stop();
    }

    // ========================================================================
    //  Event JSON roundtrip
    // ========================================================================

    @Test
    public void contextEvent_toJson_roundtrip() {
        ContextSnapshot before = new ContextSnapshot.Builder()
                .batteryLevel(25).isCharging(false).screenOn(true).build();
        ContextSnapshot after = new ContextSnapshot.Builder()
                .batteryLevel(19).isCharging(false).screenOn(true).build();
        JSONObject meta = new JSONObject();
        try { meta.put("threshold", 20); } catch (Exception e) {}
        ContextEvent ev = ContextEvent.of(ContextEventType.BATTERY_BELOW, before, after, meta);

        JSONObject json = ev.toJson();
        assertEquals("BATTERY_BELOW", json.optString("type"));
        assertTrue(json.has("before"));
        assertTrue(json.has("after"));
        assertEquals(20, json.optJSONObject("metadata").optInt("threshold"));
    }

    // ========================================================================
    //  Helpers
    // ========================================================================

    private ContextProvider newProvider() {
        return new ContextProvider(null, fakeSensor, persister);
    }

    static class FakeSensor implements SensorSource {
        String wifiSsid;
        Integer batteryLevel;
        boolean charging;
        boolean screenOn;
        String foregroundApp;

        @Override public String getWifiSsid() { return wifiSsid; }
        @Override public Integer getBatteryLevel() { return batteryLevel; }
        @Override public boolean isCharging() { return charging; }
        @Override public boolean isScreenOn() { return screenOn; }
        @Override public String getForegroundApp() { return foregroundApp; }
    }

    static class RecordingListener implements TransitionListener {
        final List<ContextEvent> events = new ArrayList<>();
        @Override public void onTransition(ContextEvent event) { events.add(event); }
    }
}
