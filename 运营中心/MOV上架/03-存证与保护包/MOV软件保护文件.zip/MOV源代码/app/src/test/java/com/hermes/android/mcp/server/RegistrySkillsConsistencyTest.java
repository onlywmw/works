package com.hermes.android.mcp.server;

import static org.junit.Assert.*;

import org.junit.Test;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * 工单9 幕一 单表化【辅助守卫】（打回修复降级）：RegistryProvider（8388/8389 统一构建源）应激活内置技能。
 * 本测试仅文本扫描辅助守卫（生产接线仍调 activateBuiltinSkills 的调用点存在）。
 * 行为级守护见 RegistryProviderSkillBehaviorTest（假读取器喂 skill → 产物含 skill.echo → 8388 invoke 200 回显）。
 */
public class RegistrySkillsConsistencyTest {

    private static File resolve() {
        String[][] candidates = {
                {"src/main/java/com/hermes/android/mcp/server/RegistryProvider.java", null},
                {"app/src/main/java/com/hermes/android/mcp/server/RegistryProvider.java", null},
        };
        for (String[] c : candidates) {
            File f = new File(c[0]);
            if (f.exists()) return f;
        }
        throw new AssertionError("RegistryProvider.java 未找到 (working dir=" + new File(".").getAbsolutePath() + ")");
    }

    @Test
    public void registryProviderActivatesBuiltinSkills() throws Exception {
        String src = new String(Files.readAllBytes(resolve().toPath()), StandardCharsets.UTF_8);
        // 去掉注释行
        StringBuilder code = new StringBuilder();
        for (String line : src.split("\n")) {
            String t = line.trim();
            if (t.startsWith("//") || t.startsWith("*") || t.startsWith("/*") || t.isEmpty()) continue;
            code.append(line).append('\n');
        }
        String c = code.toString();
        assertTrue("RegistryProvider 必须激活内置技能（SkillActivator.activate），否则 8388 调 skill.echo 会 TOOL_NOT_FOUND",
                c.contains("SkillActivator.activate"));
    }
}
