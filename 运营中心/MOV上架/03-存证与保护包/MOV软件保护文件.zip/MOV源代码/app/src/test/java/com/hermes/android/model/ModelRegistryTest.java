package com.hermes.android.model;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * 工单13: 模型编辑合并纯函数测试。
 * 背景: 前端编辑模型时 API Key 不回显(安全), 若用户只改显示名/模型名就保存,
 * 旧实现整体替换会把 key 清空 → 下次派活必失败(新人路径断点)。
 */
public class ModelRegistryTest {

    private static ModelConfig cfg(String id, String key) {
        ModelConfig c = new ModelConfig();
        c.id = id;
        c.name = "测试模型";
        c.provider = "deepseek";
        c.model = "deepseek-chat";
        c.apiKey = key;
        return c;
    }

    @Test public void updateWithEmptyKey_keepsOldKey() {
        ModelConfig cur = cfg("m1", "sk-original-key");
        ModelConfig incoming = cfg("m1", "");   // 编辑表单 key 留空(不回显)
        ModelConfig merged = ModelRegistry.mergeOnUpdate(cur, incoming);
        assertEquals("空 key 应保留旧 key", "sk-original-key", merged.apiKey);
    }

    @Test public void updateWithWhitespaceKey_keepsOldKey() {
        ModelConfig cur = cfg("m1", "sk-original-key");
        ModelConfig incoming = cfg("m1", "   ");
        assertEquals("空白 key 应保留旧 key", "sk-original-key",
                ModelRegistry.mergeOnUpdate(cur, incoming).apiKey);
    }

    @Test public void updateWithNewKey_replaces() {
        ModelConfig cur = cfg("m1", "sk-old");
        ModelConfig incoming = cfg("m1", "sk-new");
        assertEquals("显式新 key 应替换", "sk-new",
                ModelRegistry.mergeOnUpdate(cur, incoming).apiKey);
    }

    @Test public void updateNullKey_keepsOldKey() {
        ModelConfig cur = cfg("m1", "sk-original-key");
        ModelConfig incoming = cfg("m1", null);
        assertEquals("null key 应保留旧 key", "sk-original-key",
                ModelRegistry.mergeOnUpdate(cur, incoming).apiKey);
    }

    @Test public void update_keepsDefaultAndNonFormFields() {
        ModelConfig cur = cfg("m1", "sk-original-key");
        cur.isDefault = true;          // 默认大脑
        cur.role = "数据";             // 用户改过的非表单字段
        cur.color = "#123456";
        cur.enabled = false;
        ModelConfig incoming = cfg("m1", "sk-new");
        incoming.isDefault = false;    // 前端表单固定 false
        incoming.role = "通用";
        incoming.color = "#D97706";
        incoming.enabled = true;
        ModelConfig merged = ModelRegistry.mergeOnUpdate(cur, incoming);
        assertTrue("编辑保存不得丢默认大脑", merged.isDefault);
        assertEquals("role 保留旧值", "数据", merged.role);
        assertEquals("color 保留旧值", "#123456", merged.color);
        assertFalse("enabled 保留旧值", merged.enabled);
        assertEquals("id 保留", "m1", merged.id);
    }

    @Test public void update_changesFormFields() {
        ModelConfig cur = cfg("m1", "sk-old");
        ModelConfig incoming = cfg("m1", "sk-new");
        incoming.name = "新名字";
        incoming.model = "deepseek-v4-flash";
        ModelConfig merged = ModelRegistry.mergeOnUpdate(cur, incoming);
        assertEquals("name 可改", "新名字", merged.name);
        assertEquals("model 可改", "deepseek-v4-flash", merged.model);
        assertEquals("key 可改", "sk-new", merged.apiKey);
    }
}
