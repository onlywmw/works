package com.hermes.android.workflow;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.io.File;

import static org.junit.Assert.*;

/**
 * Workflow 单 JSON 文件存储 CRUD + JSON 往返（纯 JVM，临时目录）。
 */
public class WorkflowRepositoryTest {

    private WorkflowRepository repo() {
        File dir = new File(System.getProperty("java.io.tmpdir"),
                "wf_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 100000));
        dir.mkdirs();
        return new WorkflowRepository(dir);
    }

    private Workflow make(String id) {
        JSONObject trigger = new JSONObject();
        try { trigger.put("type", "pageload"); } catch (Exception e) {}
        JSONArray conds = new JSONArray();
        JSONArray acts = new JSONArray();
        Workflow w = new Workflow(id, trigger, conds, acts);
        w.name = "wf " + id;
        w.cooldownMs = 5000;
        w.maxRunsPerDay = 3;
        return w;
    }

    @Test public void save_thenListAndGet() {
        WorkflowRepository r = repo();
        r.save(make("w1"));
        r.save(make("w2"));

        assertEquals("list 应含 2 条", 2, r.list().size());
        Workflow g = r.get("w1");
        assertNotNull(g);
        assertEquals("w1", g.id);
        assertEquals("wf w1", g.name);
        assertEquals("cooldown 持久化", 5000, g.cooldownMs);
        assertEquals("maxRunsPerDay 持久化", 3, g.maxRunsPerDay);
        assertEquals("trigger 类型持久化", "pageload", g.triggerType());
    }

    @Test public void save_upsertReplaces() {
        WorkflowRepository r = repo();
        r.save(make("w1"));
        Workflow w2 = make("w1");
        w2.maxRunsPerDay = 9;
        r.save(w2);

        assertEquals("upsert 后仍 1 条", 1, r.list().size());
        assertEquals("覆盖后 maxRunsPerDay=9", 9, r.get("w1").maxRunsPerDay);
    }

    @Test public void delete_removes() {
        WorkflowRepository r = repo();
        r.save(make("w1"));
        r.save(make("w2"));
        r.delete("w1");

        assertNull(r.get("w1"));
        assertNotNull(r.get("w2"));
    }

    @Test public void jsonRoundTrip_preservesState() {
        WorkflowRepository r = repo();
        Workflow w = make("state");
        w.enabled = false;
        w.lastFireAt = 123456;
        w.runsToday = 2;
        w.runCount = 7;
        r.save(w);

        Workflow back = r.get("state");
        assertFalse("enabled 持久化", back.enabled);
        assertEquals("lastFireAt 持久化", 123456, back.lastFireAt);
        assertEquals("runsToday 持久化", 2, back.runsToday);
        assertEquals("runCount 持久化", 7, back.runCount);
    }

    @Test public void missingFile_returnsEmpty() {
        WorkflowRepository r = new WorkflowRepository(new File(System.getProperty("java.io.tmpdir"),
                "no_such_dir_" + System.currentTimeMillis()));
        assertTrue("缺失文件 → 空列表", r.list().isEmpty());
        assertNull(r.get("x"));
    }
}
