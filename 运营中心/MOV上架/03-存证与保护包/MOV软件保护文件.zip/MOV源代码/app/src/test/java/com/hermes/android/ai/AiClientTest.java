package com.hermes.android.ai;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * AiClient 错误友好化单元测试 — HTTP 状态码中文提示 + 服务端 message 提取。
 * 纯 Java 测试，不依赖 Android 运行时。
 */
public class AiClientTest {

    @Test public void error402IsFriendly() {
        String body = "{\"error\":{\"code\":\"InsufficientBalance\",\"message\":\"account balance not enough\"}}";
        String r = AiClient.friendlyError(402, body);
        assertTrue(r.startsWith("余额不足"));
        assertTrue(r.contains("account balance not enough")); // 服务端详情保留
    }

    @Test public void error402WithoutBody() {
        assertEquals("余额不足，请充值后重试", AiClient.friendlyError(402, ""));
        assertEquals("余额不足，请充值后重试", AiClient.friendlyError(402, null));
    }

    @Test public void error401IsFriendly() {
        assertEquals("API Key 无效或已过期", AiClient.friendlyError(401, "{}"));
    }

    @Test public void error404IsFriendly() {
        assertEquals("模型不存在或接口地址错误", AiClient.friendlyError(404, "Not Found"));
    }

    @Test public void error429IsFriendly() {
        assertEquals("请求过于频繁，请稍后再试", AiClient.friendlyError(429, ""));
    }

    @Test public void unknownCodeUsesServerMessage() {
        String body = "{\"error\":{\"message\":\"model overloaded\"}}";
        assertEquals("model overloaded", AiClient.friendlyError(500, body));
    }

    @Test public void unknownCodeFallsBackToFirstLine() {
        assertEquals("gateway error", AiClient.friendlyError(502, "gateway error\nstack..."));
        assertEquals("无详细信息", AiClient.friendlyError(502, ""));
    }

    @Test public void extractServerMessageVariants() {
        assertEquals("m1", AiClient.extractServerMessage("{\"error\":{\"message\":\"m1\"}}"));
        assertEquals("m2", AiClient.extractServerMessage("{\"message\":\"m2\"}"));
        assertEquals("", AiClient.extractServerMessage("not json"));
        assertEquals("", AiClient.extractServerMessage(""));
    }

    @Test public void retryBackoff_incrementsAcrossAttempts() {
        // BUG-1: 验证退避递增（计数器跨迭代保留）
        long d1 = StreamWatchdog.rateLimitBackoffMs(0, 0);
        long d2 = StreamWatchdog.rateLimitBackoffMs(1, 0);
        long d3 = StreamWatchdog.rateLimitBackoffMs(2, 0);
        assertTrue("第1次应30s: " + d1, d1 >= 30000);
        assertTrue("第2次应60s: " + d2, d2 >= 60000);
        assertTrue("第3次应120s: " + d3, d3 >= 120000);
    }

    @Test public void fastBackoff_hasCap() {
        // BUG-1: MAX_FAST_RETRIES=3, attempt从0起, attempt>=3返回-1
        long d0 = StreamWatchdog.fastBackoffMs(0, 0);
        long d2 = StreamWatchdog.fastBackoffMs(2, 0);
        long d3 = StreamWatchdog.fastBackoffMs(3, 0);
        assertTrue("首次应>0: " + d0, d0 > 0);
        assertTrue("第3次应>0: " + d2, d2 > 0);
        assertTrue("第4次应负值(熔断): " + d3, d3 < 0);
    }

    // ============ Anthropic Messages 协议（批1）============

    @Test public void extractAnthropicContent_textBlocks() throws Exception {
        org.json.JSONObject json = new org.json.JSONObject(
                "{\"content\":[{\"type\":\"text\",\"text\":\"你好\"},{\"type\":\"tool_use\",\"name\":\"shell_exec\"}],\"stop_reason\":\"end_turn\"}");
        assertEquals("你好", AiClient.extractAnthropicContent(json));
    }

    @Test public void buildAnthropicBody_isAnthropicFormat() throws Exception {
        com.hermes.android.model.ModelConfig mc = new com.hermes.android.model.ModelConfig();
        mc.provider = "anthropic"; mc.apiKey = "k"; mc.model = "claude-sonnet-4-6"; mc.baseUrl = "https://api.anthropic.com/v1";
        AiClient c = new AiClient(mc);
        org.json.JSONObject body = c.buildAnthropicBody("hi", null, false);
        assertEquals("claude-sonnet-4-6", body.getString("model"));
        assertEquals(4096, body.getInt("max_tokens"));
        assertTrue("anthropic body 应有 system", body.has("system"));
        assertFalse("anthropic body 不应有 choices", body.has("choices"));
        org.json.JSONArray msgs = body.getJSONArray("messages");
        assertEquals("user", msgs.getJSONObject(0).getString("role"));
    }

    @Test public void buildBody_anthropicProvider_usesAnthropicFormat() throws Exception {
        /* 走 buildBody → isAnthropic 分支（变异防护：isAnthropic 失效则此测试红） */
        com.hermes.android.model.ModelConfig mc = new com.hermes.android.model.ModelConfig();
        mc.provider = "anthropic"; mc.apiKey = "k"; mc.model = "claude-sonnet-4-6"; mc.baseUrl = "https://api.anthropic.com/v1";
        AiClient c = new AiClient(mc);
        org.json.JSONObject body = c.buildBody("hi", null, false);
        assertTrue("anthropic provider 的 buildBody 应有 system", body.has("system"));
        assertEquals(4096, body.getInt("max_tokens"));
        assertFalse("不应有 choices", body.has("choices"));
    }

    @Test public void buildBody_openaiNotRegressed() throws Exception {
        com.hermes.android.model.ModelConfig mc = new com.hermes.android.model.ModelConfig();
        mc.provider = "deepseek"; mc.apiKey = "k";
        AiClient c = new AiClient(mc);
        org.json.JSONObject body = c.buildBody("hi", null, true);
        assertTrue("openai body 应有 stream", body.has("stream"));
        assertEquals("openai body 应有 max_tokens 上限（2026-08-05 防 deepseek 计划阶段元思考失控）",
                4096, body.getInt("max_tokens"));
        org.json.JSONArray msgs = body.getJSONArray("messages");
        assertEquals("system", msgs.getJSONObject(0).getString("role"));
    }
}