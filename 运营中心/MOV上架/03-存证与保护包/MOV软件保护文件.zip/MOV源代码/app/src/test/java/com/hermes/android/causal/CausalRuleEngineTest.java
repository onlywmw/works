package com.hermes.android.causal;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * CausalRuleEngine 测试 — 逻辑钩子匹配：cooccur 全命中触发/缺原子不误触、dateAfter 到期触发、
 * linkDelta 强度应用、alert 占位替换、过期规则跳过、禁用规则不触发。
 */
public class CausalRuleEngineTest {

    private static final long NOW = 1_800_000_000_000L;

    private CausalRuleStore storeWith(JSONObject ruleJson) {
        CausalRuleStore store = new CausalRuleStore();
        store.upsert(CausalRule.fromJSON(ruleJson));
        return store;
    }

    private static JSONObject cooccurRule(String ruleId, String... atoms) throws Exception {
        return new JSONObject()
                .put("ruleId", ruleId)
                .put("label", ruleId)
                .put("when", new JSONObject().put("type", "cooccur")
                        .put("atoms", new JSONArray(java.util.Arrays.asList(atoms))))
                .put("then", new JSONObject().put("linkDelta", 0.3).put("alert", ruleId + " 命中"))
                .put("enabled", true);
    }

    private static JSONObject dateAfterRule(String ruleId, String field, String alert) throws Exception {
        return new JSONObject()
                .put("ruleId", ruleId)
                .put("label", ruleId)
                .put("when", new JSONObject().put("type", "dateAfter").put("whenDateField", field))
                .put("then", new JSONObject().put("alert", alert))
                .put("enabled", true);
    }

    @Test public void cooccurRuleFiresOnAllAtoms() throws Exception {
        CausalRuleStore store = storeWith(cooccurRule("r_debt", "张三", "李四", "欠款"));
        CausalIndex idx = new CausalIndex();
        CausalRuleEngine engine = new CausalRuleEngine();
        CausalRuleEngine.CausalMatchResult r = engine.match(store,
                new CausalEvent("张三", "欠款", "李四"), idx, NOW);
        assertTrue("三原子同现应命中", r.firedRules.contains("r_debt"));
        assertFalse("alerts 应有输出", r.alerts.isEmpty());
    }

    @Test public void missingAtomNoFire() throws Exception {
        CausalRuleStore store = storeWith(cooccurRule("r_debt", "张三", "李四", "欠款"));
        CausalRuleEngine engine = new CausalRuleEngine();
        CausalRuleEngine.CausalMatchResult r = engine.match(store,
                new CausalEvent("张三", "还款", "李四"), new CausalIndex(), NOW);
        assertTrue("缺『欠款』原子不误触", r.firedRules.isEmpty());
        assertTrue("无 alert", r.alerts.isEmpty());
    }

    @Test public void linkDeltaAppliedToMatchedPairs() throws Exception {
        CausalRuleStore store = storeWith(cooccurRule("r_debt", "张三", "李四", "欠款"));
        CausalIndex idx = new CausalIndex();
        CausalRuleEngine engine = new CausalRuleEngine();
        CausalRuleEngine.CausalMatchResult r = engine.match(store,
                new CausalEvent("张三", "欠款", "李四"), idx, NOW);
        assertEquals("命中触发 3 条原子对", 3, r.links.size());
        assertEquals("索引里 3 条关联", 3, idx.links().size());
        for (CausalIndex.LinkEntry l : idx.links().values()) {
            assertEquals("每条强度 0.3", 0.3, l.strength, 1e-9);
        }
    }

    @Test public void dateAfterHookFiresAfterDueDate() throws Exception {
        CausalRuleStore store = storeWith(dateAfterRule("r_due", "dueDate", "债务到期 {dueDate}"));
        CausalRuleEngine engine = new CausalRuleEngine();
        long afterDue = CausalRule.parseDateMs("2025-06-02") + 1000;
        CausalEvent ev = new CausalEvent("张三", "欠款", "李四", null, null,
                new JSONObject().put("dueDate", "2025-06-01"));
        CausalRuleEngine.CausalMatchResult r = engine.match(store, ev, new CausalIndex(), afterDue);
        assertTrue("到期后命中", r.firedRules.contains("r_due"));
        assertEquals("alert 占位替换为到期日", "债务到期 2025-06-01",
                r.alerts.get(0).optString("alert", ""));
    }

    @Test public void dateAfterHookSilentBeforeDueDate() throws Exception {
        CausalRuleStore store = storeWith(dateAfterRule("r_due", "dueDate", "到期"));
        CausalRuleEngine engine = new CausalRuleEngine();
        long beforeDue = CausalRule.parseDateMs("2025-05-31") + 1000;
        CausalEvent ev = new CausalEvent("张三", "欠款", "李四", null, null,
                new JSONObject().put("dueDate", "2025-06-01"));
        CausalRuleEngine.CausalMatchResult r = engine.match(store, ev, new CausalIndex(), beforeDue);
        assertTrue("到期前不触发", r.firedRules.isEmpty());
    }

    @Test public void expiredRuleSkipped() throws Exception {
        JSONObject rule = cooccurRule("r_old", "张三", "欠款")
                .put("then", new JSONObject().put("alert", "旧规则").put("expireAt", "2025-06-01"));
        CausalRuleStore store = storeWith(rule);
        CausalRuleEngine engine = new CausalRuleEngine();
        long afterExpire = CausalRule.parseDateMs("2025-06-02") + 1000;
        CausalRuleEngine.CausalMatchResult r = engine.match(store,
                new CausalEvent("张三", "欠款", "李四"), new CausalIndex(), afterExpire);
        assertTrue("硬到期规则跳过", r.firedRules.isEmpty());
    }

    @Test public void disabledRuleNotFired() throws Exception {
        CausalRuleStore store = storeWith(cooccurRule("r_dis", "张三", "欠款").put("enabled", false));
        CausalRuleEngine engine = new CausalRuleEngine();
        CausalRuleEngine.CausalMatchResult r = engine.match(store,
                new CausalEvent("张三", "欠款", "李四"), new CausalIndex(), NOW);
        assertTrue("禁用规则不触发", r.firedRules.isEmpty());
    }
}
