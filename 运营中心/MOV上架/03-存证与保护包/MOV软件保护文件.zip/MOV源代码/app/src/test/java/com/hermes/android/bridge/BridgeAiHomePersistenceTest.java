package com.hermes.android.bridge;

import com.hermes.android.ai.AiClient;

import org.junit.Test;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;

/**
 * 工单17: 首页对话持久化（方案 b — 固定房间 r_home）写读回路测试。
 *
 * 覆盖：
 * - persistHomeChat 产出的事件格式（user_input actor=user payload.text / deliver payload.summary）
 *   与 rebuildHistoryFromJournal 提取规则匹配（杀进程后懒重建可恢复）
 * - 多轮首页对话写入 r_home journal → 重建后顺序完整（73921 测试法：记数字 → 重启 → 追问答对）
 * - 变异亲杀：事件类型/actor 变异后测试必须红
 */
public class BridgeAiHomePersistenceTest {

    private File mkdirs(File parent, String... parts) {
        File d = parent;
        for (String p : parts) d = new File(d, p);
        d.mkdirs();
        return d;
    }

    /** 照 BridgeAi.persistHomeChat 的事件格式写 r_home journal（两轮对话） */
    private void writeHomeJournal(File f, String[][] turns) throws Exception {
        f.getParentFile().mkdirs();
        try (FileWriter w = new FileWriter(f)) {
            w.write("{\"v\":1,\"type\":\"_header\"}\n");
            int seq = 1;
            for (String[] turn : turns) {
                w.write("{\"seq\":" + (seq++) + ",\"type\":\"user_input\",\"actor\":\"user\","
                        + "\"taskId\":null,\"payload\":{\"text\":\"" + turn[0] + "\"}}\n");
                w.write("{\"seq\":" + (seq++) + ",\"type\":\"deliver\",\"actor\":\"assistant\","
                        + "\"taskId\":null,\"payload\":{\"summary\":\"" + turn[1] + "\"}}\n");
            }
        }
    }

    /** 模拟 getHistory(null) 的全局桶重建路径：r_home journal → 历史桶 */
    private List<AiClient.Message> rebuildHome(String[][] turns) throws Exception {
        File rooms = mkdirs(new File(System.getProperty("java.io.tmpdir"),
                "bridge-home-test-" + System.nanoTime()), "rooms");
        File jf = new File(new File(rooms, "r_home"), "journal.jsonl");
        writeHomeJournal(jf, turns);
        List<AiClient.Message> hist = Collections.synchronizedList(new ArrayList<>());
        BridgeAi.rebuildHistoryFromJournal(jf, hist, 50);
        return hist;
    }

    // ═══ 写读回路 ═══

    @Test
    public void twoTurns_roundTrip_preservesOrder() throws Exception {
        // 73921 测试法：记数字 → 杀进程 → 重进 → 追问
        String[][] turns = {
                {"记住数字 73921", "好的，已记住 73921。"},
                {"上一轮我让你记的数字是多少", "你让我记住的数字是 73921。"}
        };
        List<AiClient.Message> hist = rebuildHome(turns);
        assertEquals("两轮对话 = 4 条消息", 4, hist.size());
        assertEquals("user", hist.get(0).role);
        assertEquals("记住数字 73921", hist.get(0).content);
        assertEquals("assistant", hist.get(1).role);
        assertEquals("好的，已记住 73921。", hist.get(1).content);
        assertEquals("user", hist.get(2).role);
        assertEquals("上一轮我让你记的数字是多少", hist.get(2).content);
        assertEquals("assistant", hist.get(3).role);
        assertTrue("追问必须答对（数字在历史中）", hist.get(3).content.contains("73921"));
    }

    @Test
    public void homeRoomId_validForJournal() {
        // r_home 必须通过 Journal 的 isValidId（字母开头，字母数字下划线）
        // 间接验证：Journal.append 对 r_home 不拒绝（防路径穿越白名单格式）
        assertTrue("r_home 必须匹配 ^[a-zA-Z][a-zA-Z0-9_-]*$",
                "r_home".matches("^[a-zA-Z][a-zA-Z0-9_-]*$"));
    }

    @Test
    public void emptyHomeJournal_rebuildsZero() throws Exception {
        List<AiClient.Message> hist = rebuildHome(new String[][]{});
        assertEquals(0, hist.size());
    }

    // ═══ 变异亲杀 ═══

    @Test
    public void mutation_assistantEventTypeChanged_breaks() throws Exception {
        // 变异：deliver 事件类型被改成 note（模拟 persistHomeChat 写错类型）→ 助手消息丢失
        File rooms = mkdirs(new File(System.getProperty("java.io.tmpdir"),
                "bridge-home-mut-" + System.nanoTime()), "rooms");
        File jf = new File(new File(rooms, "r_home"), "journal.jsonl");
        jf.getParentFile().mkdirs();
        try (FileWriter w = new FileWriter(jf)) {
            w.write("{\"v\":1,\"type\":\"_header\"}\n");
            w.write("{\"seq\":1,\"type\":\"user_input\",\"actor\":\"user\",\"taskId\":null,"
                    + "\"payload\":{\"text\":\"记住 73921\"}}\n");
            w.write("{\"seq\":2,\"type\":\"note\",\"actor\":\"assistant\",\"taskId\":null,"
                    + "\"payload\":{\"summary\":\"好的\"}}\n");   // ← 变异：deliver→note
        }
        List<AiClient.Message> hist = Collections.synchronizedList(new ArrayList<>());
        int n = BridgeAi.rebuildHistoryFromJournal(jf, hist, 50);
        assertEquals("变异后助手消息必须丢失（测试拦截）", 1, n);
        assertEquals(1, hist.size());
    }
}
