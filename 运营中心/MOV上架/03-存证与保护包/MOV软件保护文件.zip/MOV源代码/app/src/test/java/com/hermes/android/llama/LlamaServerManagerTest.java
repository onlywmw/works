package com.hermes.android.llama;

import org.junit.After;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * LlamaServerManager 单测 — 零网络注入式。
 * 覆盖：决策纯函数 decide（4 分支）+ 懒启动状态机（healthz 探针注入）+ token 生成。
 * 真实 llama-server 启动/停止留真机验收（需要二进制 + GGUF + rootfs）。
 */
public class LlamaServerManagerTest {

    @After public void cleanup() {
        LlamaServerManager.setProbeForTest(null);
        LlamaServerManager.stop();
    }

    // ==================== decide 决策纯函数（4 分支） ====================

    @Test public void decideReuseWhenHealthy() {
        assertEquals("healthz 通 → 复用，不重启", LlamaServerManager.Decision.REUSE,
                LlamaServerManager.decide(true, false, false));
    }

    @Test public void decideWaitWhenProcessAlive() {
        assertEquals("进程在但 healthz 不通 → 等待重查", LlamaServerManager.Decision.WAIT,
                LlamaServerManager.decide(false, true, true));
    }

    @Test public void decideNoInstallWhenMissing() {
        assertEquals("无进程且未安装 → 不可用", LlamaServerManager.Decision.NO_INSTALL,
                LlamaServerManager.decide(false, false, false));
    }

    @Test public void decideStartWhenReady() {
        assertEquals("无进程但安装就绪 → 启动", LlamaServerManager.Decision.START,
                LlamaServerManager.decide(false, false, true));
    }

    // ==================== 懒启动状态机（探针注入，零网络） ====================

    @Test public void ensureRunningReuseWhenHealthy() {
        LlamaServerManager.setProbeForTest(() -> true);
        assertTrue("healthz 通 → 就绪复用", LlamaServerManager.ensureRunning(null));
        assertEquals(LlamaServerManager.State.READY, LlamaServerManager.status());
    }

    @Test public void ensureRunningNoInstallWhenMissing() {
        LlamaServerManager.setProbeForTest(() -> false);
        assertFalse("healthz 不通 + 未安装 → 返回失败", LlamaServerManager.ensureRunning(null));
        assertEquals(LlamaServerManager.State.IDLE, LlamaServerManager.status());
    }

    @Test public void ensureRunningTransitionIdleToReady() {
        // 先不通 → IDLE；探针转通 → 下一次 REUSE
        LlamaServerManager.setProbeForTest(() -> false);
        LlamaServerManager.ensureRunning(null);
        assertEquals(LlamaServerManager.State.IDLE, LlamaServerManager.status());

        LlamaServerManager.setProbeForTest(() -> true);
        assertTrue(LlamaServerManager.ensureRunning(null));
        assertEquals(LlamaServerManager.State.READY, LlamaServerManager.status());
    }

    // ==================== token ====================

    @Test public void urlSafeTokenLengthAndCharset() {
        String t = LlamaServerManager.urlSafeToken(24);
        assertEquals("token 长度", 24, t.length());
        assertTrue("token 只含 URL 安全字符", t.matches("[A-Za-z0-9_-]{24}"));
    }

    // ==================== 空闲 30min 退出（Manager 层计时，纯函数） ====================

    @Test public void idleTimeoutFiresAfterWindow() {
        long now = System.currentTimeMillis();
        assertTrue("距上次调用超 30min → 触发退出", LlamaServerManager.isIdleTimedOut(true,
                now - 31L * 60 * 1000, now));
    }

    @Test public void idleTimeoutNotFiredWhenRecent() {
        long now = System.currentTimeMillis();
        assertFalse("刚调用过 → 不触发", LlamaServerManager.isIdleTimedOut(true, now, now));
    }

    @Test public void idleTimeoutNotFiredWithoutProcess() {
        long now = System.currentTimeMillis();
        assertFalse("无进程 → 不触发", LlamaServerManager.isIdleTimedOut(false,
                now - 9999999L, now));
    }

    @Test public void idleTimeoutNotFiredWithoutLastCall() {
        assertFalse("无 lastCall 记录 → 不触发", LlamaServerManager.isIdleTimedOut(true, 0,
                System.currentTimeMillis()));
    }

    // ═══ 工单12 幕四: llama-server 命令含 mmproj(视觉投影) ═══

    @Test public void buildServerCommand_includesMmproj() {
        String cmd = LlamaServerManager.buildServerCommand(
                LlamaServerManager.DEFAULT_MODEL, LlamaServerManager.MMPROJ_MODEL, "tok123");
        assertTrue("含 -m 模型", cmd.contains("-m /models/q4_K_M.gguf"));
        assertTrue("含 --mmproj", cmd.contains("--mmproj /models/mmproj-f16.gguf"));
        assertTrue("含 --api-key", cmd.contains("--api-key tok123"));
        assertTrue("含 -t 6", cmd.contains("-t 6"));
    }

    @Test public void buildServerCommand_withoutMmproj_omitsFlag() {
        String cmd = LlamaServerManager.buildServerCommand("q4_K_M.gguf", "", "tok");
        assertFalse("无 mmproj 名时不输出 --mmproj", cmd.contains("--mmproj"));
    }
}
