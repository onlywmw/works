package com.hermes.android;

import static org.junit.Assert.*;

import com.hermes.android.agent.Journal;

import org.junit.Test;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * 工单7 幕二 P1 G4：双脑读一致性——serve 8388 curated 与工具 memory.read
 * 读同一 journal 的投影必须一致（都走 Journal.memoryCurated(memoryDrafts)，共享单一投影）。
 * 行为测试 + 源码防分叉；变异亲杀：投影分叉/一端改走 → 必红。
 */
public class DualBrainReadConsistencyTest {

    @Test public void bothEndsShareProjection() throws Exception {
        // 两端共享的投影逻辑：memoryCurated(memoryDrafts) → § 分隔（serve:426 / 工具:293 同源）
        File roomsDir = Files.createTempDirectory("dualread").toFile();
        Journal j = new Journal(roomsDir);
        j.appendDraft("r1", "记忆一", "memory");
        j.appendDraft("r1", "记忆二", "memory");
        String curated = j.memoryCurated(j.memoryDrafts("r1"));
        assertEquals("§ 分隔投影", "记忆一§记忆二", curated);
        assertEquals("count", 2, j.memoryDrafts("r1").length());
    }

    @Test public void serveAndToolBothUseMemoryCurated() throws Exception {
        // 防双端投影分叉：serve curated 与 工具 read 都必须调 Journal.memoryCurated
        assertTrue("serve 侧(8388)须用 memoryCurated 投影",
                source("serve/MovInboundServer.java").contains("memoryCurated"));
        assertTrue("工具侧(memory.read)须用 memoryCurated 投影",
                source("toolprovider/MemoryToolProvider.java").contains("memoryCurated"));
    }

    private static String source(String rel) throws Exception {
        String[][] candidates = {
                {"src/main/java/com/hermes/android", rel},
                {"app/src/main/java/com/hermes/android", rel},
        };
        for (String[] c : candidates) {
            File f = new File(c[0], c[1]);
            if (f.exists()) return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
        }
        throw new AssertionError("源码未找到: " + rel);
    }
}
