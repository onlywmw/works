package com.hermes.android;

import static org.junit.Assert.*;

import org.junit.Test;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * 根治单（工单7 G14 打回同类）：目录一致性单测——
 * 全仓禁 `getFilesDir()/rooms` 硬编码（journal 真理源在 StorageManager 外部目录，
 * 与 serve/McpProvider/AgentLoop 一致）。扫描关键文件源码（非注释行），
 * 断言无残留；变种（改回内部目录）必红。
 */
public class JournalDirConsistencyTest {

    /** 待扫描文件（相对模块根 src/main/java） */
    private static final String[] TARGETS = {
            "com/hermes/android/agent/AgentLoop.java",
            "com/hermes/android/ErrorReporter.java",
    };

    private static File resolve(String rel) {
        String[][] candidates = {
                {"src/main/java", rel},
                {"app/src/main/java", rel},
        };
        for (String[] c : candidates) {
            File f = new File(c[0], c[1]);
            if (f.exists()) return f;
        }
        throw new AssertionError("源码文件未找到: " + rel + " (working dir=" + new File(".").getAbsolutePath() + ")");
    }

    /** 去掉注释行（//、/*、* 开头），保留下实际代码 */
    private static String stripComments(String src) {
        StringBuilder sb = new StringBuilder();
        for (String line : src.split("\n")) {
            String t = line.trim();
            if (t.startsWith("//") || t.startsWith("*") || t.startsWith("/*") || t.isEmpty()) continue;
            sb.append(line).append('\n');
        }
        return sb.toString();
    }

    @Test
    public void noFilesDirRoomsResidual() throws Exception {
        for (String rel : TARGETS) {
            String src = new String(Files.readAllBytes(resolve(rel).toPath()), StandardCharsets.UTF_8);
            String code = stripComments(src);
            // 精确判定: getFilesDir() 与 rooms 路径字面量组合（排除 getRoomsDir() 方法名 / 独立临时文件）
            boolean hasResidual = code.contains("getFilesDir()")
                    && (code.contains("\"rooms/") || code.contains("\"rooms\""));
            assertFalse(rel + " 存在 filesDir+rooms 硬编码残留（应走 StorageManager.getRoomsDir()）", hasResidual);
        }
    }
}
