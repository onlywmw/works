package com.hermes.android.context;

import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;

import static org.junit.Assert.*;

/**
 * ContextPersister — JSONL 追加 + snapshot 读写测试。
 */
public class ContextPersisterTest {

    private File tmpDir;
    private ContextPersister persister;

    @Before
    public void setUp() throws Exception {
        tmpDir = File.createTempFile("ctx_test_", "_dir");
        tmpDir.delete(); // 删除文件，重建为目录
        tmpDir.mkdirs();
        persister = new ContextPersister(tmpDir);
    }

    @After
    public void tearDown() {
        File[] files = tmpDir.listFiles();
        if (files != null) {
            for (File f : files) f.delete();
        }
        tmpDir.delete();
    }

    @Test
    public void appendEvent_createsJsonl() {
        ContextSnapshot before = snap().batteryLevel(80).build();
        ContextSnapshot after = snap().batteryLevel(79).build();
        ContextEvent event = ContextEvent.of(
                ContextEventType.BATTERY_BELOW, before, after,
                new JSONObject() {{ try { put("threshold", 80); } catch (Exception e) {} }}
        );

        persister.appendEvent(event);

        File eventsFile = new File(tmpDir, "context_events.jsonl");
        assertTrue(eventsFile.exists());
        assertTrue(eventsFile.length() > 0);
    }

    @Test
    public void appendEvent_multipleLines_allWritten() {
        for (int i = 0; i < 5; i++) {
            ContextSnapshot a = snap().batteryLevel(80 - i).build();
            ContextSnapshot b = snap().batteryLevel(79 - i).build();
            persister.appendEvent(ContextEvent.of(ContextEventType.POWER_CONNECTED, a, b));
        }

        File eventsFile = new File(tmpDir, "context_events.jsonl");
        assertTrue(eventsFile.exists());
        try {
            java.util.List<String> lines = java.nio.file.Files.readAllLines(eventsFile.toPath());
            assertEquals(5, lines.size());
            // 每行都是合法 JSON
            for (String line : lines) {
                new JSONObject(line);
            }
        } catch (Exception e) {
            fail("read JSONL failed: " + e.getMessage());
        }
    }

    @Test
    public void writeSnapshot_overwrites() {
        ContextSnapshot s1 = snap().batteryLevel(80).isCharging(true).build();
        persister.writeSnapshot(s1);

        ContextSnapshot read1 = persister.readSnapshot();
        assertNotNull(read1);
        assertEquals(Integer.valueOf(80), read1.batteryLevel);
        assertTrue(read1.isCharging);

        // 覆盖写
        ContextSnapshot s2 = snap().batteryLevel(50).isCharging(false).build();
        persister.writeSnapshot(s2);

        ContextSnapshot read2 = persister.readSnapshot();
        assertNotNull(read2);
        assertEquals(Integer.valueOf(50), read2.batteryLevel);
        assertFalse(read2.isCharging);
    }

    @Test
    public void readSnapshot_noFile_returnsNull() {
        // 新目录无文件
        ContextPersister fresh = new ContextPersister(new File(tmpDir, "empty_sub"));
        assertNull(fresh.readSnapshot());
    }

    @Test
    public void readSnapshot_roundtrip_allFields() {
        ContextSnapshot original = snap()
                .wifiSsid("TestWiFi")
                .batteryLevel(99)
                .isCharging(true)
                .screenOn(false)
                .foregroundApp("com.test.app")
                .capturedAtMs(1700000000000L)
                .build();

        persister.writeSnapshot(original);
        ContextSnapshot read = persister.readSnapshot();

        assertNotNull(read);
        assertEquals("TestWiFi", read.wifiSsid);
        assertEquals(Integer.valueOf(99), read.batteryLevel);
        assertTrue(read.isCharging);
        assertFalse(read.screenOn);
        assertEquals("com.test.app", read.foregroundApp);
        assertEquals(1700000000000L, read.capturedAtMs);
    }

    private ContextSnapshot.Builder snap() {
        return new ContextSnapshot.Builder().capturedAtMs(System.currentTimeMillis());
    }
}
