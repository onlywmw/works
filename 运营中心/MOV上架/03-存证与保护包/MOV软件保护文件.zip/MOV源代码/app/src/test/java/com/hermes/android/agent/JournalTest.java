package com.hermes.android.agent;

import static org.junit.Assert.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.File;

/**
 * Journal 单测 (CONTRACT: Envelope v1.0, P0 验收 TC-K-01~03)。
 * 纯 JVM, 无 Android 依赖 (Logger 注入 no-op)。
 */
public class JournalTest {

    @Rule
    public TemporaryFolder tmp = new TemporaryFolder();

    private Journal journal;
    private File roomsDir;

    @Before
    public void setUp() throws Exception {
        Journal.setLogger(null); // no-op logger for tests
        roomsDir = tmp.newFolder("rooms");
        journal = new Journal(roomsDir);
    }

    // ==================== 基础写入 ====================

    @Test
    public void deleteRoom_removesWholeDirectory() throws Exception {
        /* 用户报障 2026-08-07「点了删除列表没少」：room_destroy 原只落 journal 标记
           不删磁盘目录，face_history 扫磁盘仍列出。deleteRoom 必须连目录递归删净 */
        JSONObject ev = new JSONObject()
                .put("actor", "user").put("type", "user_input")
                .put("payload", new JSONObject().put("text", "bye"));
        journal.append("r_del", ev);
        File workDir = new File(new File(roomsDir, "r_del"), "files/work");
        assertTrue(workDir.mkdirs());
        assertTrue(new File(workDir, "a.txt").createNewFile());

        assertTrue(journal.deleteRoom("r_del"));
        assertFalse("房间目录必须整体删除", new File(roomsDir, "r_del").exists());
    }

    @Test
    public void deleteRoom_rejectsInvalidId() {
        /* 路径穿越防护：isValidId 之外的 id 一律拒删 */
        assertFalse(journal.deleteRoom("../escape"));
        assertFalse(journal.deleteRoom(""));
        assertFalse(journal.deleteRoom(null));
        assertTrue("rooms 目录必须完好", roomsDir.exists());
    }

    /* 顺手①: room_destroy 竞态——删房后临终 append 不得重建目录（查验员探针实证：活 loop 删房目录会复活） */
    @Test
    public void appendAfterDelete_doesNotRebuildDir() throws Exception {
        JSONObject ev = new JSONObject()
                .put("actor", "user").put("type", "user_input")
                .put("payload", new JSONObject().put("text", "task"));
        journal.append("r_race", ev);
        assertTrue(new File(roomsDir, "r_race").exists());

        assertTrue(journal.deleteRoom("r_race"));
        assertFalse("删房后目录必须不存在", new File(roomsDir, "r_race").exists());

        /* 模拟 loop 临终事件（deliver/stopped 等任意 append）——必须被拒绝，目录不得重建 */
        JSONObject late = new JSONObject()
                .put("actor", "kernel").put("type", "stopped")
                .put("payload", new JSONObject().put("reason", "late"));
        int seq = journal.append("r_race", late);
        assertEquals("已删房间 append 必须拒绝（返回 -1）", -1, seq);
        assertFalse("已删房间 append 后目录不得重建", new File(roomsDir, "r_race").exists());
    }

    @Test
    public void appendAfterDelete_otherRoomsUnaffected() throws Exception {
        /* 竞态防御只锁已删房间，不影响其他房间写入 */
        JSONObject ev = new JSONObject()
                .put("actor", "user").put("type", "user_input")
                .put("payload", new JSONObject().put("text", "hi"));
        journal.append("r_keep", ev);
        journal.append("r_gone", ev);
        assertTrue(journal.deleteRoom("r_gone"));

        int seq = journal.append("r_keep", ev);
        assertTrue("未删房间必须照常可写（seq >= 0）", seq >= 0);
        assertTrue(new File(roomsDir, "r_keep").exists());
        assertFalse(new File(roomsDir, "r_gone").exists());
    }

    /* ═══ 工单22: Journal 跨实例并发 append 不再重号（修复前：实例 synchronized 锁跨实例失效，seq 6,6） ═══ */

    @Test
    public void concurrentAppend_twoInstances_noSeqDup() throws Exception {
        /* 双实例并发 append 同一房间 40 次——seq 必须全唯一（修复前会重号） */
        final Journal j1 = new Journal(roomsDir);
        final Journal j2 = new Journal(roomsDir);
        final JSONObject ev = new JSONObject()
                .put("actor", "user").put("type", "user_input")
                .put("payload", new JSONObject().put("text", "x"));
        final int N = 40;
        final java.util.Set<Integer> seqs = java.util.Collections.synchronizedSet(new java.util.HashSet<>());
        final int[] dups = {0};
        final java.util.concurrent.CountDownLatch ready = new java.util.concurrent.CountDownLatch(1);
        final java.util.concurrent.CountDownLatch go = new java.util.concurrent.CountDownLatch(1);

        Runnable task = () -> {
            try {
                ready.countDown();
                go.await();
                for (int i = 0; i < N; i++) {
                    int s = (Thread.currentThread().getName().contains("2") ? j2 : j1).append("r_race", ev);
                    if (s < 0) continue;
                    if (!seqs.add(s)) dups[0]++;
                }
            } catch (Exception ignored) {}
        };
        Thread t1 = new Thread(task, "w1"); Thread t2 = new Thread(task, "w2");
        t1.start(); t2.start();
        ready.await(); go.countDown();
        t1.join(15000); t2.join(15000);

        assertEquals("双实例并发 append 不得重号（工单13 实证 seq 6,6 根因）", 0, dups[0]);
        assertEquals("共写入 2N 条唯一 seq", 2 * N, seqs.size());
    }

    @Test
    public void concurrentAppend_seqIsContiguous() throws Exception {
        /* 双实例并发后 seq 从 1 连续无空洞（文件级锁串行化验证） */
        final Journal j1 = new Journal(roomsDir);
        final Journal j2 = new Journal(roomsDir);
        final JSONObject ev = new JSONObject()
                .put("actor", "user").put("type", "user_input")
                .put("payload", new JSONObject().put("text", "y"));
        final java.util.Set<Integer> seqs = java.util.Collections.synchronizedSet(new java.util.HashSet<>());
        final java.util.concurrent.CountDownLatch go = new java.util.concurrent.CountDownLatch(1);
        Runnable task = () -> {
            try { go.await(); for (int i = 0; i < 20; i++) seqs.add(j2.append("r_seq", ev)); }
            catch (Exception ignored) {}
        };
        Runnable task2 = () -> {
            try { go.await(); for (int i = 0; i < 20; i++) seqs.add(j1.append("r_seq", ev)); }
            catch (Exception ignored) {}
        };
        Thread a = new Thread(task); Thread b = new Thread(task2);
        a.start(); b.start(); go.countDown();
        a.join(15000); b.join(15000);

        assertEquals(40, seqs.size());
        for (int i = 1; i <= 40; i++) {
            assertTrue("seq 必须连续无空洞（缺 " + i + "）", seqs.contains(i));
        }
    }

    @Test
    public void deleteRoom_missingReturnsFalse() {
        assertFalse(journal.deleteRoom("r_not_exist"));
    }

    @Test
    public void orphanRooms_detectsDirsWithoutJournal() throws Exception {
        // 工单15: 磁盘有目录但无 journal(历史删房不删磁盘残留) → 孤儿
        journal.append("r_ok", new JSONObject().put("actor", "u").put("type", "note")
                .put("payload", new JSONObject().put("text", "x")));
        new File(new File(roomsDir, "r_orphan"), "files/work").mkdirs();  // 无 journal
        java.util.List<String> orphans = journal.orphanRooms();
        assertTrue("孤儿目录应检出", orphans.contains("r_orphan"));
        assertFalse("有效房间不算孤儿", orphans.contains("r_ok"));
    }

    @Test
    public void append_assignsSeqFromOne() throws Exception {
        JSONObject ev = new JSONObject()
                .put("actor", "user")
                .put("type", "user_input")
                .put("payload", new JSONObject().put("text", "hello"));
        int seq1 = journal.append("r1001", ev);
        assertEquals(1, seq1);

        JSONObject ev2 = new JSONObject()
                .put("actor", "brain")
                .put("type", "note")
                .put("payload", new JSONObject().put("text", "thinking"));
        int seq2 = journal.append("r1001", ev2);
        assertEquals(2, seq2);
    }

    @Test
    public void append_writesHeaderFirst() throws Exception {
        JSONObject ev = new JSONObject()
                .put("actor", "user")
                .put("type", "user_input")
                .put("payload", new JSONObject().put("text", "hi"));
        journal.append("r1001", ev);

        File journalFile = new File(roomsDir, "r1001/journal.jsonl");
        assertTrue(journalFile.exists());
        String content = new String(java.nio.file.Files.readAllBytes(journalFile.toPath()));
        String[] lines = content.trim().split("\n");
        assertTrue(lines.length >= 2);
        JSONObject header = new JSONObject(lines[0]);
        assertEquals(1, header.optInt("v"));
        assertEquals("_header", header.optString("type"));
    }

    @Test
    public void append_fillsSeqAndTs() throws Exception {
        JSONObject ev = new JSONObject()
                .put("actor", "kernel")
                .put("type", "phase")
                .put("payload", new JSONObject().put("phase", "执行中"));
        journal.append("r1001", ev);

        JSONObject tail = journal.tail("r1001", 0, 10);
        assertTrue(tail.optBoolean("ok"));
        JSONArray events = tail.optJSONObject("data").optJSONArray("events");
        assertEquals(1, events.length());
        JSONObject stored = events.optJSONObject(0);
        assertEquals(1, stored.optInt("seq"));
        assertTrue(stored.optLong("ts") > 0);
        assertEquals("kernel", stored.optString("actor"));
        assertEquals("phase", stored.optString("type"));
    }

    @Test
    public void append_rejectsInvalidRoomId() throws Exception {
        JSONObject ev = new JSONObject().put("type", "note");
        assertEquals(-1, journal.append("123bad", ev));
        assertEquals(-1, journal.append("../escape", ev));
        assertEquals(-1, journal.append("", ev));
        assertEquals(-1, journal.append(null, ev));
    }

    // ==================== index.json ====================

    @Test
    public void append_maintainsIndex() throws Exception {
        for (int i = 0; i < 5; i++) {
            journal.append("r1001", new JSONObject()
                    .put("actor", "user")
                    .put("type", "user_input")
                    .put("payload", new JSONObject().put("text", "msg" + i)));
        }
        JSONObject idx = journal.readIndex("r1001");
        assertTrue(idx.optBoolean("ok"));
        JSONObject data = idx.optJSONObject("data");
        assertEquals(1, data.optInt("version"));
        JSONArray entries = data.optJSONArray("entries");
        assertEquals(5, entries.length());
        // 验证索引条目格式
        JSONObject first = entries.optJSONObject(0);
        assertEquals(1, first.optInt("seq"));
        assertEquals("user_input", first.optString("type"));
        assertTrue(first.optLong("ts") > 0);
        assertTrue(first.optString("summary").length() <= 80);
    }

    @Test
    public void index_summaryTruncatedTo80() throws Exception {
        String longText = "a".repeat(200);
        journal.append("r1001", new JSONObject()
                .put("actor", "user")
                .put("type", "user_input")
                .put("payload", new JSONObject().put("text", longText)));
        JSONObject idx = journal.readIndex("r1001");
        JSONArray entries = idx.optJSONObject("data").optJSONArray("entries");
        assertTrue(entries.optJSONObject(0).optString("summary").length() <= 80);
    }

    // ==================== tail 查询 ====================

    @Test
    public void tail_returnsAfterSeq() throws Exception {
        for (int i = 0; i < 10; i++) {
            journal.append("r1001", new JSONObject()
                    .put("actor", "user")
                    .put("type", "note")
                    .put("payload", new JSONObject().put("text", "n" + i)));
        }
        JSONObject result = journal.tail("r1001", 5, 100);
        assertTrue(result.optBoolean("ok"));
        JSONArray events = result.optJSONObject("data").optJSONArray("events");
        assertEquals(5, events.length()); // seq 6..10
        assertEquals(6, events.optJSONObject(0).optInt("seq"));
        assertEquals(10, result.optJSONObject("data").optInt("latestSeq"));
    }

    @Test
    public void tail_respectsCountLimit() throws Exception {
        for (int i = 0; i < 10; i++) {
            journal.append("r1001", new JSONObject()
                    .put("actor", "user")
                    .put("type", "note")
                    .put("payload", new JSONObject().put("text", "n" + i)));
        }
        JSONObject result = journal.tail("r1001", 0, 3);
        JSONArray events = result.optJSONObject("data").optJSONArray("events");
        assertEquals(3, events.length());
        // 最后 3 条: seq 8, 9, 10
        assertEquals(8, events.optJSONObject(0).optInt("seq"));
    }

    @Test
    public void tail_emptyRoom() throws Exception {
        JSONObject result = journal.tail("r9999", 0, 10);
        assertTrue(result.optBoolean("ok"));
        assertEquals(0, result.optJSONObject("data").optJSONArray("events").length());
        assertEquals(0, result.optJSONObject("data").optInt("latestSeq"));
    }

    @Test
    public void tail_invalidRoomId() throws Exception {
        JSONObject result = journal.tail("123bad", 0, 10);
        assertFalse(result.optBoolean("ok"));
        assertEquals("BAD_REQUEST",
                result.optJSONObject("error").optString("code"));
    }

    // ==================== replay ====================

    @Test
    public void replay_returnsTailN() throws Exception {
        for (int i = 0; i < 10; i++) {
            journal.append("r1001", new JSONObject()
                    .put("actor", "user")
                    .put("type", "note")
                    .put("payload", new JSONObject().put("text", "n" + i)));
        }
        JSONObject result = journal.replay("r1001", 5);
        assertTrue(result.optBoolean("ok"));
        JSONArray events = result.optJSONObject("data").optJSONArray("events");
        assertEquals(5, events.length());
        assertEquals(10, result.optJSONObject("data").optInt("latestSeq"));
    }

    @Test
    public void replay_emptyRoom() throws Exception {
        JSONObject result = journal.replay("r9999");
        assertTrue(result.optBoolean("ok"));
        assertEquals(0, result.optJSONObject("data").optJSONArray("events").length());
    }

    // ==================== historyPage ====================

    @Test
    public void historyPage_beforeSeq() throws Exception {
        for (int i = 0; i < 10; i++) {
            journal.append("r1001", new JSONObject()
                    .put("actor", "user")
                    .put("type", "note")
                    .put("payload", new JSONObject().put("text", "n" + i)));
        }
        JSONObject result = journal.historyPage("r1001", 8, 3);
        assertTrue(result.optBoolean("ok"));
        JSONArray events = result.optJSONObject("data").optJSONArray("events");
        assertEquals(3, events.length());
        // seq < 8 的最后 3 条: 5, 6, 7
        assertEquals(5, events.optJSONObject(0).optInt("seq"));
        assertEquals(7, events.optJSONObject(2).optInt("seq"));
        assertTrue(result.optJSONObject("data").optBoolean("hasMore"));
    }

    @Test
    public void historyPage_noMore() throws Exception {
        for (int i = 0; i < 3; i++) {
            journal.append("r1001", new JSONObject()
                    .put("actor", "user")
                    .put("type", "note")
                    .put("payload", new JSONObject().put("text", "n" + i)));
        }
        JSONObject result = journal.historyPage("r1001", 100, 50);
        assertTrue(result.optBoolean("ok"));
        assertEquals(3, result.optJSONObject("data").optJSONArray("events").length());
        assertFalse(result.optJSONObject("data").optBoolean("hasMore"));
    }

    // ==================== 错误信封 ====================

    @Test
    public void errorEnvelope_format() throws Exception {
        JSONObject result = journal.tail("123bad", 0, 10);
        assertFalse(result.optBoolean("ok"));
        JSONObject error = result.optJSONObject("error");
        assertNotNull(error);
        assertFalse(error.optString("code").isEmpty());
        assertFalse(error.optString("msg").isEmpty());
        // 红线: catch 禁止返回 ok:true
        assertFalse(result.optBoolean("ok"));
    }

    // ==================== 滚动 ====================

    @Test
    public void roll_triggersOnLargeJournal() throws Exception {
        // 用较大的 payload 快速触发 1MB 滚动 (~500 条 × ~2KB ≈ 1MB)
        String bigSummary = "x".repeat(1800);
        for (int i = 0; i < 600; i++) {
            journal.append("r1001", new JSONObject()
                    .put("actor", "worker")
                    .put("type", "tool_result")
                    .put("payload", new JSONObject()
                            .put("ok", true)
                            .put("summary", "result-" + i + "-" + bigSummary)));
        }

        File journalFile = new File(roomsDir, "r1001/journal.jsonl");
        File archiveFile = new File(roomsDir, "r1001/journal.archive.jsonl");
        File snapshotFile = new File(roomsDir, "r1001/snapshot.json");

        // 滚动后 journal 应该小于 1MB
        assertTrue("journal should be < 1MB after roll", journalFile.length() < 1024 * 1024);
        // archive 应该存在
        assertTrue("archive should exist after roll", archiveFile.exists());
        assertTrue("archive should have content", archiveFile.length() > 0);
        // snapshot 应该存在
        assertTrue("snapshot should exist after roll", snapshotFile.exists());

        // snapshot 格式
        String snapContent = new String(java.nio.file.Files.readAllBytes(snapshotFile.toPath()));
        JSONObject snap = new JSONObject(snapContent);
        assertEquals(1, snap.optInt("version"));
        assertTrue(snap.optInt("seq") > 0);
        assertTrue(snap.optLong("ts") > 0);

        // 回放仍然正常
        JSONObject replay = journal.replay("r1001");
        assertTrue(replay.optBoolean("ok"));
        assertTrue(replay.optJSONObject("data").optInt("latestSeq") > 0);
    }

    // ==================== TC-K-03 性能闸 ====================

    @Test
    public void performance_5000events_replayUnder1500ms() throws Exception {
        // 构造 5000 条 journal 的大房间
        for (int i = 0; i < 5000; i++) {
            journal.append("r1001", new JSONObject()
                    .put("actor", "worker")
                    .put("type", "tool_result")
                    .put("payload", new JSONObject()
                            .put("ok", true)
                            .put("durMs", 42)
                            .put("summary", "step-" + i)));
        }

        // 冷启动进房间: replay 应 ≤1.5s
        long t0 = System.currentTimeMillis();
        JSONObject result = journal.replay("r1001");
        long elapsed = System.currentTimeMillis() - t0;

        assertTrue("replay should succeed", result.optBoolean("ok"));
        assertTrue("replay should take ≤1500ms, took " + elapsed + "ms", elapsed <= 1500);

        // 默认只回放 500 条, 不是全量
        JSONArray events = result.optJSONObject("data").optJSONArray("events");
        assertTrue("should replay ≤500 events, got " + events.length(),
                events.length() <= Journal.REPLAY_TAIL_N);

        // 索引摘要先行: readIndex 应该很快
        long t1 = System.currentTimeMillis();
        JSONObject idx = journal.readIndex("r1001");
        long idxElapsed = System.currentTimeMillis() - t1;
        assertTrue("readIndex should be fast", idxElapsed < 200);
        assertTrue(idx.optBoolean("ok"));
    }

    // ==================== 多房间隔离 ====================

    @Test
    public void multiRoom_isolated() throws Exception {
        journal.append("r1001", new JSONObject()
                .put("actor", "user").put("type", "note")
                .put("payload", new JSONObject().put("text", "room1")));
        journal.append("r2002", new JSONObject()
                .put("actor", "user").put("type", "note")
                .put("payload", new JSONObject().put("text", "room2")));

        JSONObject t1 = journal.tail("r1001", 0, 10);
        JSONObject t2 = journal.tail("r2002", 0, 10);
        assertEquals(1, t1.optJSONObject("data").optJSONArray("events").length());
        assertEquals(1, t2.optJSONObject("data").optJSONArray("events").length());
        assertEquals("room1", t1.optJSONObject("data").optJSONArray("events")
                .optJSONObject(0).optJSONObject("payload").optString("text"));
        assertEquals("room2", t2.optJSONObject("data").optJSONArray("events")
                .optJSONObject(0).optJSONObject("payload").optString("text"));
    }

    // ==================== seq 单调递增 ====================

    @Test
    public void append_doesNotReuseSeq_whenIndexBehindJournal() throws Exception {
        // 工单7 G2: 崩溃于 updateIndex 前 → index 落后于 journal → append 不得复用 journal 已有 seq
        JSONObject e1 = new JSONObject().put("actor", "u").put("type", "user_input")
                .put("payload", new JSONObject().put("text", "a"));
        JSONObject e2 = new JSONObject().put("actor", "u").put("type", "user_input")
                .put("payload", new JSONObject().put("text", "b"));
        JSONObject e3 = new JSONObject().put("actor", "u").put("type", "user_input")
                .put("payload", new JSONObject().put("text", "c"));
        assertEquals(1, journal.append("r1001", e1));
        assertEquals(2, journal.append("r1001", e2));
        assertEquals(3, journal.append("r1001", e3));
        // 模拟崩溃: index.json 只到 seq2（journal 已到 seq3）
        File index = new File(roomsDir, "r1001/index.json");
        String idx = "{\"version\":1,\"entries\":[{\"seq\":1,\"type\":\"x\",\"ts\":0,\"summary\":\"s\"},"
                + "{\"seq\":2,\"type\":\"x\",\"ts\":0,\"summary\":\"s\"}]}";
        java.nio.file.Files.write(index.toPath(),
                idx.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        JSONObject e4 = new JSONObject().put("actor", "u").put("type", "user_input")
                .put("payload", new JSONObject().put("text", "d"));
        int seq4 = journal.append("r1001", e4);
        assertEquals("不得复用 journal 已有最大 seq(3)", 4, seq4);
    }

    @Test
    public void seq_monotonicAcrossAppends() throws Exception {
        int prev = 0;
        for (int i = 0; i < 20; i++) {
            int seq = journal.append("r1001", new JSONObject()
                    .put("actor", "user").put("type", "note")
                    .put("payload", new JSONObject().put("text", "m" + i)));
            assertTrue("seq should be > prev (" + prev + "), got " + seq, seq > prev);
            prev = seq;
        }
    }

    // ==================== 阶段3 C2: journal 按内容检索 ====================

    @Test
    public void search_positiveMatch_findsEvent() throws Exception {
        journal.append("rSearch", new JSONObject()
                .put("actor", "user")
                .put("type", "user_input")
                .put("payload", new JSONObject().put("text", "我要看凡人修仙传第 5 章")));
        journal.append("rSearch", new JSONObject()
                .put("actor", "brain")
                .put("type", "note")
                .put("payload", new JSONObject().put("text", "检索到凡人修仙传资源")));

        JSONObject r = journal.search("rSearch", "凡人修仙传", 10);
        assertTrue("检索必须 ok", r.optBoolean("ok"));
        JSONArray events = r.optJSONObject("data").optJSONArray("events");
        assertEquals("两个事件都含关键词", 2, events.length());
        assertEquals("时间倒序: 后写的在前", "note", events.optJSONObject(0).optString("type"));
        assertEquals("user_input", events.optJSONObject(1).optString("type"));
    }

    @Test
    public void search_negativeNoMatch_empty() throws Exception {
        journal.append("rSearch", new JSONObject()
                .put("actor", "user")
                .put("type", "user_input")
                .put("payload", new JSONObject().put("text", "今天天气不错")));
        JSONObject r = journal.search("rSearch", "不存在的关键词xyz", 10);
        assertTrue(r.optBoolean("ok"));
        assertEquals(0, r.optJSONObject("data").optInt("count"));
    }

    @Test
    public void search_caseInsensitive() throws Exception {
        journal.append("rSearch", new JSONObject()
                .put("actor", "user")
                .put("type", "user_input")
                .put("payload", new JSONObject().put("text", "Watch history 里有 MOV 视频")));
        JSONObject r = journal.search("rSearch", "watch", 10);
        assertEquals(1, r.optJSONObject("data").optInt("count"));
    }

    @Test
    public void search_emptyQuery_badRequest() throws Exception {
        JSONObject r = journal.search("rSearch", "  ", 10);
        assertFalse(r.optBoolean("ok"));
        assertEquals("BAD_REQUEST", r.optJSONObject("error").optString("code"));
    }

    @Test
    public void search_archiveCovered() throws Exception {
        // 直接往 archive 写历史事件（模拟滚动归档），检索应覆盖
        File roomDir = new File(roomsDir, "rSearch");
        roomDir.mkdirs();
        try (java.io.OutputStreamWriter w = new java.io.OutputStreamWriter(
                new java.io.FileOutputStream(new File(roomDir, "journal.archive.jsonl"), true),
                java.nio.charset.StandardCharsets.UTF_8)) {
            w.write("{\"actor\":\"user\",\"type\":\"user_input\",\"seq\":5,\"ts\":1000,"
                    + "\"payload\":{\"text\":\"旧历史里有归档内容\"}}\n");
        }
        JSONObject r = journal.search("rSearch", "归档内容", 10);
        assertTrue("archive 里的历史也要搜得到: " + r, r.optBoolean("ok"));
        assertEquals(1, r.optJSONObject("data").optInt("count"));
    }

    @Test
    public void searchableText_extractsPayloadText() throws Exception {
        JSONObject ev = new JSONObject()
                .put("type", "user_input")
                .put("payload", new JSONObject().put("text", "你好").put("summary", "摘要"));
        String t = Journal.searchableText(ev);
        assertTrue("text 提取", t.contains("你好"));
        assertTrue("summary 提取", t.contains("摘要"));
    }
}
