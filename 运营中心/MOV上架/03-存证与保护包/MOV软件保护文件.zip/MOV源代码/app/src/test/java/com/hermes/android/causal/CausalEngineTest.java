package com.hermes.android.causal;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.nio.file.Files;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * CausalEngine 门面测试 — 端到端：记录→规则命中→alert+强度、衰减清理、查询、账本审计、link 钳制。
 */
public class CausalEngineTest {

    private File tmp;
    private CausalEngine engine;

    @Before public void setUp() throws Exception {
        tmp = Files.createTempDirectory("causal-engine-").toFile();
        engine = new CausalEngine(tmp);
    }

    @After public void tearDown() throws Exception {
        deleteRecursive(tmp);
    }

    private void deleteRecursive(File f) {
        File[] all = f.listFiles();
        if (all != null) for (File c : all) deleteRecursive(c);
        f.delete();
    }

    private JSONObject debtRule() throws Exception {
        return new JSONObject()
                .put("ruleId", "r_debt")
                .put("label", "债务提醒")
                .put("when", new JSONObject().put("type", "cooccur")
                        .put("atoms", new JSONArray(java.util.Arrays.asList("张三", "李四", "欠款"))))
                .put("then", new JSONObject().put("linkDelta", 0.3).put("alert", "张三对李四的欠款需复核"))
                .put("enabled", true);
    }

    @Test public void recordDebtTriggersAlertAndStrength() throws Exception {
        engine.upsertRule("r1", debtRule());
        JSONObject r = engine.record("r1", new CausalEvent("张三", "欠款", "李四"));
        assertTrue("记录应成功", r.optBoolean("ok", false));
        assertEquals("命中规则 r_debt", "r_debt", r.optJSONArray("fired").optString(0));
        assertEquals("alert 产出", "张三对李四的欠款需复核",
                r.optJSONArray("alerts").optJSONObject(0).optString("alert"));
        JSONObject q = engine.query("r1", 10);
        assertTrue("关联强度产生", q.optJSONArray("links").length() >= 1);
        assertEquals("3 原子入索引", 3, q.optInt("atomCount"));
    }

    @Test public void recordThenQueryRoundtrip() throws Exception {
        engine.record("r1", new CausalEvent("张三", "欠款", "李四"));
        engine.record("r1", new CausalEvent("王五", "还款", "李四"));
        JSONObject q = engine.query("r1", 10);
        assertTrue("记录成功", q.optBoolean("ok", false));
        assertEquals("2 条事件", 2, q.optInt("eventCount"));
        assertEquals("4 个不同原子（张三/李四/欠款/王五/还款）",
                5, q.optInt("atomCount"));
    }

    @Test public void sweepDecaysAndRemovesStale() throws Exception {
        engine.record("r1", new CausalEvent("张三", "欠款", "李四"));
        long farFuture = System.currentTimeMillis() + 8L * 86400000L;
        JSONObject r = engine.sweep("r1", farFuture);
        assertTrue("衰减清理成功", r.optBoolean("ok", false));
        assertTrue("应清理 stale 原子", r.optInt("swept") > 0);
        JSONObject q = engine.query("r1", 10);
        assertEquals("清理后原子归零", 0, q.optInt("atomCount"));
    }

    @Test public void sweepFreshAtomNotRemoved() throws Exception {
        engine.record("r1", new CausalEvent("张三", "欠款", "李四"));
        JSONObject r = engine.sweep("r1", System.currentTimeMillis());
        assertEquals("新鲜原子不清扫", 0, r.optInt("swept"));
    }

    @Test public void sweepExpiredRuleRemovedAndForgetTombstone() throws Exception {
        JSONObject rule = new JSONObject()
                .put("ruleId", "r_exp")
                .put("label", "过期规则")
                .put("when", new JSONObject().put("type", "cooccur").put("atoms", new JSONArray()))
                .put("then", new JSONObject().put("expireAt", "2020-01-01"))
                .put("enabled", true);
        engine.upsertRule("r1", rule);
        JSONObject r = engine.sweep("r1", System.currentTimeMillis());
        assertTrue("过期规则被移除", r.optInt("removedRules") >= 1);
        JSONObject q = engine.query("r1", 10);
        assertEquals("活性规则清空", 0, q.optJSONArray("rules").length());
        // 墓碑长在 journal
        assertTrue("forget 墓碑落 journal",
                engine.journal().eventsOfType("r1", "_causal_forget").length() > 0);
    }

    @Test public void replayAuditShowsReasoning() throws Exception {
        engine.upsertRule("r1", debtRule());
        JSONObject rec = engine.record("r1", new CausalEvent("张三", "欠款", "李四"));
        int eventSeq = rec.optInt("seq");
        JSONObject chain = engine.chain("r1");
        assertTrue("账本校验通过", chain.optBoolean("verified", false));
        assertTrue("至少 2 区块（规则+触发）", chain.optJSONArray("blocks").length() >= 2);
        // 找到含 eventSeq 的 evidence（审计：哪天基于哪条事件）
        boolean found = false;
        JSONArray blocks = chain.optJSONArray("blocks");
        for (int i = 0; i < blocks.length(); i++) {
            JSONObject b = blocks.optJSONObject(i);
            JSONObject evidence = b.optJSONObject("evidence");
            if (evidence != null && evidence.optInt("eventSeq", -1) == eventSeq) {
                found = true;
                break;
            }
        }
        assertTrue("触发区块带 evidence.eventSeq（可回放推理依据）", found);
    }

    @Test public void linkManualClampsStrength() throws Exception {
        JSONObject r = engine.link("r1", "张三", "李四", 2.0, "manual");
        assertTrue("link 成功", r.optBoolean("ok", false));
        assertEquals("强度钳制上限 1.0", 1.0, r.optDouble("strength"), 1e-9);
        JSONObject r2 = engine.link("r1", "张三", "李四", -3.0, "manual");
        assertEquals("强度钳制下限 0.0", 0.0, r2.optDouble("strength"), 1e-9);
    }

    @Test public void sweepDueAlertsForDateAfter() throws Exception {
        JSONObject rule = new JSONObject()
                .put("ruleId", "r_due")
                .put("label", "到期提醒")
                .put("when", new JSONObject().put("type", "dateAfter").put("whenDateField", "dueDate"))
                .put("then", new JSONObject().put("alert", "债务到期"))
                .put("enabled", true);
        engine.upsertRule("r1", rule);
        // 事件带过去日期
        JSONObject meta = new JSONObject().put("dueDate", "2020-01-01");
        engine.record("r1", new CausalEvent("张三", "欠款", "李四", null, null, meta));
        JSONObject r = engine.sweep("r1", System.currentTimeMillis());
        assertTrue("sweep 补触发到期提醒", r.optJSONArray("dueAlerts").length() >= 1);
    }

    @Test public void forgetRemovesAtomAndWritesTombstone() throws Exception {
        engine.record("r1", new CausalEvent("张三", "欠款", "李四"));
        JSONObject r = engine.forget("r1", "张三", "user_request");
        assertTrue("遗忘成功", r.optBoolean("ok", false));
        JSONObject q = engine.query("r1", 10);
        assertEquals("张三 移除后剩 2 原子", 2, q.optInt("atomCount"));
        assertTrue("forget 墓碑落 journal",
                engine.journal().eventsOfType("r1", "_causal_forget").length() == 1);
    }

    @Test public void emptyRoomSafe() throws Exception {
        JSONObject q = engine.query("r1", 10);
        assertTrue("空房查询不崩", q.optBoolean("ok", false));
        assertEquals("空房 0 原子", 0, q.optInt("atomCount"));
        assertFalse("空房无活性规则", q.optJSONArray("rules").length() > 0);
    }
}
