package com.hermes.android.causal;

import org.json.JSONObject;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * CausalOracle 单测（DESIGN_CAUSAL_APIFACT §三）——fake Brain 注入，验证补丁契约解析与错误静默。
 */
public class CausalOracleTest {

    @Test public void analyze_parsesPatchJson() {
        CausalOracle.Brain fake = (s, u) -> "{\"hidden_variables\":[\"书面协议缺失\"],\"probability_change\":\"降低约35%\","
                + "\"patch_rule\":{\"condition\":\"当与商务伙伴产生资金借出且无书面协议\",\"action\":\"INSERT_NODE\","
                + "\"new_node\":{\"suggested_trigger\":\"转账后1小时生成协议\"},\"confidence_boost\":0.3}}";
        JSONObject p = CausalOracle.analyze(fake, "脱敏叙事");
        assertNotNull("应解析出补丁", p);
        assertEquals("hidden_variables 提取", "书面协议缺失", p.optJSONArray("hidden_variables").optString(0));
        JSONObject pr = p.optJSONObject("patch_rule");
        assertEquals("action 提取", "INSERT_NODE", pr.optString("action"));
        assertEquals("confidence_boost 提取", 0.3, pr.optDouble("confidence_boost"), 0.001);
    }

    @Test public void analyze_markdownFenced_parses() {
        CausalOracle.Brain fake = (s, u) -> "```json\n{\"patch_rule\":{\"action\":\"INSERT_NODE\"}}\n```";
        JSONObject p = CausalOracle.analyze(fake, "叙事");
        assertNotNull("markdown 围栏应剥掉", p);
        assertEquals("INSERT_NODE", p.optJSONObject("patch_rule").optString("action"));
    }

    @Test public void analyze_nonJson_returnsNull() {
        CausalOracle.Brain fake = (s, u) -> "这不是JSON";
        assertNull("非 JSON → 静默 null", CausalOracle.analyze(fake, "叙事"));
    }

    @Test public void analyze_patchRuleAsString_rejected() {
        // 真机发现：DeepSeek 曾把 patch_rule 返回成字符串 → PatchCompiler 编译失败。analyze 必须拒绝。
        CausalOracle.Brain fake = (s, u) -> "{\"hidden_variables\":[\"缺书面协议\"],\"patch_rule\":\"在涉及转账的事件链中加强制步骤\"}";
        assertNull("patch_rule 是字符串 → 拒绝 null", CausalOracle.analyze(fake, "叙事"));
    }

    @Test public void analyze_nullBrain_returnsNull() {
        assertNull("null brain → null", CausalOracle.analyze(null, "叙事"));
    }

    @Test public void analyze_scrubsPiiBeforeSending() {
        // 出网 payload 断言（隐私审计 2026-08-05）：fake Brain 捕获实际发送文本，
        // 喂含手机号/身份证/邮箱/金额的叙事 → 出网文本里这些串全部不存在。
        String[] captured = new String[1];
        CausalOracle.Brain spy = (s, u) -> {
            captured[0] = u;
            return "{\"patch_rule\":{\"action\":\"INSERT_NODE\"}}";
        };
        String dirty = "实体A 通过电话 13800138000 催实体B 还款 8000元，"
                + "证件 11010119900307771X，邮箱 zhangsan@example.com";
        JSONObject p = CausalOracle.analyze(spy, dirty);
        assertNotNull("补丁应正常解析", p);
        assertNotNull("brain 必须被调用", captured[0]);
        assertFalse("手机号不得出网: " + captured[0], captured[0].contains("13800138000"));
        assertFalse("身份证不得出网: " + captured[0], captured[0].contains("11010119900307771X"));
        assertFalse("邮箱不得出网: " + captured[0], captured[0].contains("zhangsan@example.com"));
        assertFalse("金额不得出网: " + captured[0], captured[0].contains("8000元"));
        assertTrue("脱敏占位符应出网: " + captured[0], captured[0].contains("[手机号]"));
    }
}
