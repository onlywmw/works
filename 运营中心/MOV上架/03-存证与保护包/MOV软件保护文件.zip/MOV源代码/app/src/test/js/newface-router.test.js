/* ============================================================
   newface-router 回归测试（node，无需构建）
   跑法: node app/src/test/js/newface-router.test.js
   P1-3 核心回归向量：订机票（LLM 判 intent=unknown+domain=travel）→ 'none'，
   绝不路由到 startTrainSearch（火车票）。
   ============================================================ */
'use strict';
const assert = require('assert');
const router = require('../../main/assets/js/newface-router.js');

// ══ P1-3 回归向量：机票不走火车票 ══
assert.strictEqual(
  router.resolve('帮我订明天去北京的机票',
    { intent: 'unknown', type: 'service', domain: 'travel', confidence: 0.8 }),
  'none',
  '【回归向量】订机票(intent=unknown+travel) 不得路由到 train'
);

// ══ 火车票 → train（intent 权威 + 正则快速通道） ══
assert.strictEqual(
  router.resolve('帮我订明天去北京的火车票',
    { intent: 'train', type: 'service', domain: 'travel', confidence: 0.95 }),
  'train');
assert.strictEqual(router.resolve('订后天上海到广州的高铁', null), 'train');

// ══ 音乐 → music（intent + 正则） ══
assert.strictEqual(
  router.resolve('来点轻音乐',
    { intent: 'music', type: 'service', domain: 'entertainment', confidence: 0.85 }),
  'music');
assert.strictEqual(router.resolve('我要听小苹果', null), 'music');

// ══ 追剧 → drama ══
assert.strictEqual(
  router.resolve('继续看漫长的季节',
    { intent: 'drama', type: 'service', domain: 'entertainment', confidence: 0.9 }),
  'drama');

// ══ A2A → a2a（正则） ══
assert.strictEqual(router.resolve('来一份盖浇饭', null), 'a2a');

// ══ 网页搜索 → browser（P1 B：搜评价/资讯/价格 → 浏览器链路，正则优先防误归 drama） ══
assert.strictEqual(
  router.resolve('帮我在抖音搜一下庆余年的评价',
    { intent: 'drama', type: 'service', domain: 'entertainment', confidence: 0.9 }),
  'browser', '正则「搜…评价」优先命中 browser，即使 LLM 误判 drama 也不被路由到追剧');
assert.strictEqual(
  router.resolve('查小米15的价格',
    { intent: 'browser', type: 'service', domain: 'general', confidence: 0.9 }),
  'browser', 'LLM intent=browser → browser');
assert.strictEqual(router.resolve('用浏览器打开 example.com', null), 'browser', '用浏览器打开 → browser');
assert.strictEqual(router.resolve('搜一下庆余年的评价', null, 'regex'), 'browser', 'regex 模式浏览器搜索正则也走');

// ══ 旧响应（无 intent 字段）domain 补位仍生效 ══
assert.strictEqual(
  router.resolve('明天到上海', { type: 'service', domain: 'travel', confidence: 0.9 }),
  'train', '无 intent 的旧响应 domain=travel 仍补位 train（兼容旧行为）');
assert.strictEqual(
  router.resolve('听点音乐', { type: 'service', domain: 'entertainment', confidence: 0.8 }),
  'music', '无 intent 的旧响应 entertainment+音乐正则 → music');

// ══ creation → handoff ══
assert.strictEqual(
  router.resolve('帮我写个贪吃蛇',
    { intent: 'creation', type: 'creation', domain: 'development', confidence: 0.9 }),
  'handoff');

// ══ chat → chat ══
assert.strictEqual(
  router.resolve('你好', { intent: 'chat', type: 'chat', domain: 'general', confidence: 0.95 }),
  'chat');

// ══ data 缺失 → none（不崩） ══
assert.strictEqual(router.resolve('随便说点啥', null), 'none');

// ══ 意图路由模式（DESIGN_SETTINGS ①：regex 仅快速通道，省 token 不读 LLM） ══
assert.strictEqual(router.resolve('我要听小苹果', null, 'regex'), 'music', 'regex 模式正则命中仍走');
assert.strictEqual(router.resolve('来点轻音乐', null, 'regex'), 'none', 'regex 模式正则未命中即不猜（省 token）');
assert.strictEqual(
  router.resolve('帮我订明天去北京的机票',
    { intent: 'train', type: 'service', domain: 'travel', confidence: 0.9 }, 'regex'),
  'none', 'regex 模式有 intent 也不读（不调 LLM 就不会有 data）');

console.log('✅ newface-router 全部断言通过（含 P1-3 机票回归向量 + regex 模式）');
