package com.hermes.android;

import com.hermes.android.security.PiiMasker;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * S2 PII 打码器单测（纯 JVM）——三证号型 + 姓名 + 误伤控制 + 性能。
 */
public class PiiMaskerTest {

    @Test public void idcardMasked() {
        assertEquals("身份证 → [证件号]", "证件号是[证件号]",
                PiiMasker.mask("证件号是11010519491231002X"));
        assertEquals("身份证保留尾号 X", "我的[证件号]",
                PiiMasker.mask("我的11010519491231002x"));
    }

    @Test public void bankcardMasked() {
        assertEquals("银行卡 → [卡号]", "卡号[卡号]",
                PiiMasker.mask("卡号6222020200112233445"));
    }

    @Test public void phoneMasked() {
        assertEquals("手机号 → [手机号]", "电话[手机号]",
                PiiMasker.mask("电话13812345678"));
    }

    @Test public void nameMasked() {
        assertEquals("叫+姓名 → 叫[姓名]", "他叫[姓名]是司机",
                PiiMasker.mask("他叫王小明是司机"));
        assertEquals("我是+姓名", "我是[姓名]",
                PiiMasker.mask("我是李四"));
        assertEquals("姓名：", "姓名：[姓名]",
                PiiMasker.mask("姓名：张三"));
    }

    @Test public void noFalsePositiveOnOrdinaryNumbers() {
        // 误伤控制：普通数字/短数字不打码
        assertEquals("普通数字保留", "价格 99 元，共 3 个",
                PiiMasker.mask("价格 99 元，共 3 个"));
    }

    @Test public void endToEnd_recognitionToMaskNoPii() {
        // 端到端：识别结果 → 打码 → 无 PII 残留
        String ocr = "收货人：李四，电话13812345678，身份证11010519491231002X";
        String masked = PiiMasker.mask(ocr);
        assertFalse("无手机号残留", masked.contains("13812345678"));
        assertFalse("无身份证残留", masked.contains("110105"));
        assertFalse("无姓名残留", masked.contains("李四"));
        assertTrue("姓名已泛化", masked.contains("[姓名]"));
        assertTrue("手机号已泛化", masked.contains("[手机号]"));
    }

    @Test public void performance_100kCharsUnder1s() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10000; i++) sb.append("姓名：张三 电话13812345678 身份证11010519491231002X\n");
        long start = System.currentTimeMillis();
        String masked = PiiMasker.mask(sb.toString());
        long elapsed = System.currentTimeMillis() - start;
        assertTrue("10 万字 <1s，实际 " + elapsed + "ms", elapsed < 1000);
        assertFalse("无 PII 残留", masked.contains("张三") || masked.contains("13812345678"));
    }

    @Test public void nullInputPassesThrough() {
        assertNull(PiiMasker.mask(null));
    }
}
