package com.hermes.android.model;

import android.content.SharedPreferences;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * BUG-7①: 加密不可用时纯内存 SharedPreferences — 行为测试。
 *
 * 不可用态使用 MemSharedPreferences (纯内存 Map)，不落盘。
 * 测试走生产代码 createMemPrefs() 返回的实例，不写字面量比较。
 *
 * 完整集成验证由验收人真机完成：
 * - Keystore 可用: 模型配置正常读写 (回归)
 * - Keystore 不可用: isEncrypted=false, setApiKey 会话内可读,
 *   进程重启(新实例)后 key 消失, 磁盘无明文文件
 */
public class KeystoreFallbackTest {

    // ═══ MemSharedPreferences: 内存读写, 不落盘 ═══

    @Test
    public void memPrefs_putAndGet_sameSession() {
        // 行为: 同一会话内 set 后立即可读 (内存操作)
        SharedPreferences prefs = com.hermes.android.ai.AiProviderConfig.createMemPrefs();
        prefs.edit().putString("api_key", "sk-secret").apply();
        assertEquals("同会话可读", "sk-secret", prefs.getString("api_key", ""));
    }

    @Test
    public void memPrefs_newInstance_readsEmpty() {
        // 行为: 新实例 = 全新内存 → 旧数据不可读 (不持久化)
        SharedPreferences prefs1 = com.hermes.android.ai.AiProviderConfig.createMemPrefs();
        prefs1.edit().putString("api_key", "sk-secret").apply();

        // 新实例 — 模拟进程重启
        SharedPreferences prefs2 = com.hermes.android.ai.AiProviderConfig.createMemPrefs();
        assertEquals("新实例读不到旧数据", "", prefs2.getString("api_key", ""));
    }

    @Test
    public void memPrefs_clear_thenReadReturnsDefault() {
        SharedPreferences prefs = com.hermes.android.ai.AiProviderConfig.createMemPrefs();
        prefs.edit().putString("api_key", "sk-temp").apply();
        prefs.edit().clear().apply();
        assertEquals("clear 后读不到", "", prefs.getString("api_key", ""));
    }

    @Test
    public void memPrefs_contains_afterPut() {
        SharedPreferences prefs = com.hermes.android.ai.AiProviderConfig.createMemPrefs();
        prefs.edit().putString("key", "val").apply();
        assertTrue("contains 已写入 key", prefs.contains("key"));
        assertFalse("contains 未写入 key", prefs.contains("nonexistent"));
    }

    // ═══ MemSharedPreferences: 不落盘 ═══

    @Test
    public void memPrefs_doesNotCreateDiskFile() {
        // 行为验证: 写入 apiKey 后, 不产生任何磁盘文件
        SharedPreferences prefs = com.hermes.android.ai.AiProviderConfig.createMemPrefs();
        prefs.edit().putString("api_key", "sk-should-not-persist").apply();

        // MemSharedPreferences 无文件路径, 全程 HashMap.
        // 验证方式: 新实例读不到 (同 memPrefs_newInstance_readsEmpty),
        // 且在 shared_prefs 目录中找不到对应文件 (由真机验收确认)
        SharedPreferences prefs2 = com.hermes.android.ai.AiProviderConfig.createMemPrefs();
        assertEquals("重启后 key 消失 — 证明未落盘", "",
                prefs2.getString("api_key", ""));
    }

    // ═══ MemSharedPreferences: int/boolean 类型 ═══

    @Test
    public void memPrefs_intType() {
        SharedPreferences prefs = com.hermes.android.ai.AiProviderConfig.createMemPrefs();
        prefs.edit().putInt("port", 8080).apply();
        assertEquals(8080, prefs.getInt("port", 0));
    }

    @Test
    public void memPrefs_booleanType() {
        SharedPreferences prefs = com.hermes.android.ai.AiProviderConfig.createMemPrefs();
        prefs.edit().putBoolean("enabled", true).apply();
        assertTrue(prefs.getBoolean("enabled", false));
    }

    // ═══ 回归: MemSharedPreferences 不是明文 SharedPreferences ═══

    @Test
    public void memPrefs_doesNotOverlapWithRealPrefs() {
        // 两个独立 MemSharedPreferences 实例互不干扰
        SharedPreferences a = com.hermes.android.ai.AiProviderConfig.createMemPrefs();
        SharedPreferences b = com.hermes.android.ai.AiProviderConfig.createMemPrefs();
        a.edit().putString("secret", "only_in_a").apply();
        assertEquals("only_in_a", a.getString("secret", ""));
        assertEquals("b 不受 a 影响", "", b.getString("secret", ""));
    }

    // ═══ ModelConfig 口径不受 isEncrypted 影响 ═══

    @Test
    public void modelConfig_isConfigured_independentOfEncryption() {
        // ModelConfig.isConfigured 只看 apiKey 是否非空, 不依赖 isEncrypted
        ModelConfig mc = new ModelConfig();
        mc.apiKey = "sk-xxx";
        assertTrue(mc.isConfigured());
        assertTrue("有 key 即 configured, 与加密状态无关", mc.isConfigured());
    }

    @Test
    public void fallback_memPrefs_apiKeyInMemoryOnly() {
        // 端到端行为链: write → same-session read OK → new session read EMPTY
        // Step 1: 写入
        SharedPreferences s1 = com.hermes.android.ai.AiProviderConfig.createMemPrefs();
        s1.edit().putString("api_key", "sk-behavioral-test").apply();
        assertEquals("同会话可读", "sk-behavioral-test", s1.getString("api_key", ""));

        // Step 2: 新会话 (新实例)
        SharedPreferences s2 = com.hermes.android.ai.AiProviderConfig.createMemPrefs();
        assertEquals("新会话 key 消失 — 满足'不持久化'", "", s2.getString("api_key", ""));

        // Step 3: 原始实例不受影响 (各自独立 HashMap)
        assertEquals("原实例数据未丢失", "sk-behavioral-test", s1.getString("api_key", ""));
    }

    // ═══ 接线测试: call-site 变异必红 ═══

    @Test
    public void modelRegistry_fallback_doesNotTouchGetSharedPreferences() throws Exception {
        // 接线测试: 加密不可用时 ModelRegistry.createFallbackPrefs()
        // 必须返回 MemSharedPreferences (纯内存), 不是明文 SharedPreferences。
        //
        // 变异法: 把 createFallbackPrefs() 改回
        //   context.getSharedPreferences("mov_models", MODE_PRIVATE)
        // → 此测试的 instanceOf 检查必红。
        //
        // JVM 单测环境无法构造 ModelRegistry (Context stub 不可用),
        // 故直接测工厂方法——它是线上构造的唯一 fallback 入口。
        SharedPreferences prefs = ModelRegistry.createFallbackPrefs();
        assertNotNull(prefs);
        String clsName = prefs.getClass().getName();
        assertTrue("fallback prefs 是 MemSharedPreferences, 不是明文降级: " + clsName,
                clsName.contains("MemSharedPreferences"));
    }
}
