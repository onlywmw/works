package com.hermes.android.browser;
import com.hermes.android.browser.BrowserToolProvider;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.junit.Test;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import static org.junit.Assert.*;

/**
 * BrowserToolProvider 单元测试 — W2 browser_* 分级收编。
 * 红线：零网络。只验证 discover() 元数据分级与注册表注册，不执行 handler（需 ConnectWeb）。
 */
public class BrowserToolProviderTest {

    private static AgentLoop.Tools emptyTools() {
        return new AgentLoop.Tools() {
            public String fileList(String roomId) { return ""; }
            public String fileRead(String roomId, String path) { return ""; }
            public String fileWrite(String roomId, String path, String content) { return ""; }
            public String capabilityOf(String text) { return ""; }
            public String deviceCmd(String text) { return ""; }
            public String packageApk(String roomId, String path, String appName) { return "{}"; }
            public String shellExec(String cmd, int timeoutSec) { return ""; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            public String filePush(String roomId, String path) { return "{}"; }
            public String filePull(String roomId, String name) { return "{}"; }
        };
    }

    private ToolRegistry builtRegistry() {
        return ToolRegistry.build(emptyTools(), "room1", HashSet::new,
                new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
    }

    @Test public void discover_returnsBrowserTools() {
        BrowserToolProvider p = new BrowserToolProvider();
        List<ToolRegistry.Tool> tools = p.discover();
        assertEquals("browser 工具 11 个 (W2 加 snapshot/read + P2 双超时 browser.done)", 11, tools.size());
        List<String> names = new java.util.ArrayList<>();
        for (ToolRegistry.Tool t : tools) names.add(t.name);
        assertTrue("含 open", names.contains("browser.open"));
        assertTrue("含 wait_for", names.contains("browser.wait_for"));
        assertTrue("含 scroll", names.contains("browser.scroll"));
        assertTrue("含 click", names.contains("browser.click"));
        assertTrue("含 type", names.contains("browser.type"));
        assertTrue("含 submit", names.contains("browser.submit"));
        assertTrue("含 click_and_read", names.contains("browser.click_and_read"));
        assertTrue("含 execute", names.contains("browser.execute"));
    }

    @Test public void readToolsReadonly() {
        BrowserToolProvider p = new BrowserToolProvider();
        for (ToolRegistry.Tool t : p.discover()) {
            if (t.name.equals("browser.wait_for") || t.name.equals("browser.scroll")) {
                assertEquals("读工具 access 应为 readonly: " + t.name, "readonly", t.access);
                assertEquals("读工具 approval 应为 none", "none", t.approval);
                assertEquals("读工具 manifest risk 应为 low", "low", t.manifest.risk);
            }
        }
    }

    @Test public void writeToolsAction() {
        BrowserToolProvider p = new BrowserToolProvider();
        for (ToolRegistry.Tool t : p.discover()) {
            if (t.name.equals("browser.click") || t.name.equals("browser.type")
                    || t.name.equals("browser.submit") || t.name.equals("browser.click_and_read")) {
                assertEquals("写工具 access 应为 write: " + t.name, "write", t.access);
                assertEquals("写工具 approval 应为 plan: " + t.name, "plan", t.approval);
            }
        }
    }

    @Test public void executeDangerous() {
        BrowserToolProvider p = new BrowserToolProvider();
        for (ToolRegistry.Tool t : p.discover()) {
            if (t.name.equals("browser.execute")) {
                assertEquals("execute access write", "write", t.access);
                assertEquals("execute approval always（高危）", "always", t.approval);
                assertEquals("execute manifest risk high", "high", t.manifest.risk);
            }
        }
    }

    @Test public void allFastWithCheckFn() {
        BrowserToolProvider p = new BrowserToolProvider();
        for (ToolRegistry.Tool t : p.discover()) {
            assertEquals("level 应为 FAST: " + t.name, "FAST", t.manifest.level);
            assertNotNull("checkFn 非空（ConnectWeb 探测）: " + t.name, t.checkFn);
        }
    }

    @Test public void registryFindBrowserTools() {
        ToolRegistry r = builtRegistry();
        assertNotNull("browser.click 应注册", r.find("browser.click"));
        assertNotNull("browser.wait_for 应注册", r.find("browser.wait_for"));
        assertNotNull("browser.execute 应注册", r.find("browser.execute"));
        assertEquals("browser.click level FAST", "FAST", r.find("browser.click").manifest.level);
    }

    // ==================== P1: checkFn 窗口门控（不再依赖 ConnectWeb 打开与否） ====================

    @Test public void checkFn_allowsWhenWindowFresh() {
        ToolRuntimeLimits.closeWindow();
        BrowserToolProvider p = new BrowserToolProvider();
        for (ToolRegistry.Tool t : p.discover()) {
            assertNull("窗口未超时 → browser 工具可用: " + t.name, t.checkFn.check());
        }
    }

    @Test public void checkFn_gatesAfterWindowExpired() {
        ToolRuntimeLimits.windowDeadlineMs = 1;   // 窗尽
        BrowserToolProvider p = new BrowserToolProvider();
        for (ToolRegistry.Tool t : p.discover()) {
            assertNotNull("窗尽 → browser 工具不可用: " + t.name, t.checkFn.check());
        }
        ToolRuntimeLimits.closeWindow();
    }

    @Test public void open_exposesPlatformKeywordParams() {
        // P1 A: browser.open 必须暴露 platform+keyword（LLM 免构造 URL）
        BrowserToolProvider p = new BrowserToolProvider();
        for (ToolRegistry.Tool t : p.discover()) {
            if (t.name.equals("browser.open")) {
                assertNotNull("browser.open 应有 params", t.params);
                java.util.Set<String> names = new java.util.HashSet<>();
                for (ToolRegistry.ParamDef pd : t.params) names.add(pd.name);
                assertTrue("含 url", names.contains("url"));
                assertTrue("含 platform（A 修复）", names.contains("platform"));
                assertTrue("含 keyword（A 修复）", names.contains("keyword"));
                assertTrue("描述提及 platform+keyword", t.desc.contains("platform"));
                assertTrue("示例提及平台搜索", t.examples != null && t.examples.length > 0
                        && t.examples[0].contains("搜"));
            }
        }
    }
}
