package com.hermes.android.pay;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.json.JSONObject;
import org.junit.Test;

/**
 * 工单26：MarketEngine 纯逻辑（零 Android 依赖）——未付款不发货守卫是变异靶①。
 */
public class MarketEngineLogicTest {

    @Test
    public void 未付款不发货() {
        assertTrue("SUCCESS 才发货", MarketEngine.shouldDeliver("SUCCESS"));
        assertFalse("NOTPAY 不发货（变异靶①：恒返 SUCCESS 此处必红）", MarketEngine.shouldDeliver("NOTPAY"));
        assertFalse("USERPAYING 不发货", MarketEngine.shouldDeliver("USERPAYING"));
        assertFalse("CLOSED 不发货", MarketEngine.shouldDeliver("CLOSED"));
        assertFalse("PAYERROR 不发货", MarketEngine.shouldDeliver("PAYERROR"));
        assertFalse("空串不发货", MarketEngine.shouldDeliver(""));
        assertFalse("null 不发货", MarketEngine.shouldDeliver(null));
    }

    @Test
    public void 金额分转元() {
        assertEquals("1 分 = ¥0.01", "0.01", MarketEngine.fenToYuan(1));
        assertEquals("100 分 = ¥1.00", "1.00", MarketEngine.fenToYuan(100));
        assertEquals("990 分 = ¥9.90", "9.90", MarketEngine.fenToYuan(990));
    }

    @Test
    public void 货架有验收包且公钥可加载() throws Exception {
        Shelf.Item item = Shelf.find("pkg-accept-001");
        assertNotNull("验收包在货架", item);
        assertEquals("0.01 元 = 1 分", 1, item.fen);
        assertEquals("config 型", "config", item.type);
        assertNotNull("卖家公钥可解析", item.sellerPubKey());
        assertNotNull("manifest 含 orderId 绑定", item.manifest("MOV202608090001").optString("orderId"));
    }

    @Test
    public void 未知商品不在货架() {
        assertEquals(null, Shelf.find("no-such-product"));
    }

    @Test
    public void E8点购买直达出单() {
        // buy 不再经过锁屏闸：payload 纯函数直出（无 prompt 环节，参数已删）
        JSONObject req = MarketEngine.buyRequest("pkg-accept-001");
        assertEquals("pkg-accept-001", req.optString("productId"));
        assertEquals("mov-buyer-test", req.optString("buyerId"));
        // 无 USER_REJECTED 分支残留（编译层面：buy 签名无 prompter 参数）
        assertEquals(null, req.optString("rejected", null));
    }

    @Test
        public void E14查单等买家不计连错() {
            // JSAPI 惰性建单：买家开支付页前微信侧 ORDER_NOT_EXIST = 等买家，非故障
            assertTrue(MarketEngine.isWaitingBuyer("ORDER_NOT_EXIST"));
            assertFalse(MarketEngine.isWaitingBuyer("SYSTEM_ERROR"));
            assertFalse(MarketEngine.isWaitingBuyer("SIGN_ERROR"));
            assertFalse(MarketEngine.isWaitingBuyer("NET"));
        }
}
