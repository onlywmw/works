package com.hermes.android.agent;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

/**
 * H2 HealthMonitor 单测（零网络注入式）——退避计算 / 探测状态记录 / 超时 / healthJson 输出。
 * 探测函数 Fake 注入，不碰网络。
 */
public class HealthMonitorTest {

    private static HealthMonitor.Target target(String id, HealthMonitor.ProbeFn fn) {
        // 通过反射/构造 — 用公共方式: HealthMonitor 构造 List<Target>, Target 是 public static class
        // Target 构造是包私有, 测试同包(com.hermes.android.agent)可访问
        return new HealthMonitor.Target(id, "video", fn);
    }

    // ==================== 退避 ====================

    @Test public void nextInterval_backoffDoublesCapAt2h() {
        assertEquals("正常 30min", 30 * 60 * 1000L, HealthMonitor.nextInterval(0));
        assertEquals("1 次失败 → 60min", 60 * 60 * 1000L, HealthMonitor.nextInterval(1));
        assertEquals("2 次失败 → 120min", 2 * 60 * 60 * 1000L, HealthMonitor.nextInterval(2));
        assertEquals("3 次失败 → cap 2h", 2 * 60 * 60 * 1000L, HealthMonitor.nextInterval(3));
        assertEquals("更多失败 → 恒 cap 2h", 2 * 60 * 60 * 1000L, HealthMonitor.nextInterval(10));
    }

    // ==================== 探测状态记录 ====================

    @Test public void probeTarget_successResets() {
        HealthMonitor.Target t = target("mayi91", () -> null);   // 正常
        HealthMonitor hm = new HealthMonitor(List.of(t));
        hm.probeTarget(t);
        assertNull("正常 → reason null", t.reason);
        assertEquals("连续失败清零", 0, t.consecutiveFailures);
        assertEquals("下次 30min 后", HealthMonitor.BASE_INTERVAL_MS,
                t.nextProbeMs - t.lastCheckedMs);
    }

    @Test public void probeTarget_failureRecordsReasonAndBackoff() {
        HealthMonitor.Target t = target("mayi91",
                () -> new HealthMonitor.ProbeResult(ToolRegistry.Result.REASON_SOURCE_DOWN, "站点挂"));
        HealthMonitor hm = new HealthMonitor(List.of(t));
        hm.probeTarget(t);
        assertEquals("失败 reason 记录", ToolRegistry.Result.REASON_SOURCE_DOWN, t.reason);
        assertEquals("detail 记录", "站点挂", t.detail);
        assertEquals("连续失败 1", 1, t.consecutiveFailures);
        assertEquals("退避到 60min", 60 * 60 * 1000L, t.nextProbeMs - t.lastCheckedMs);
    }

    @Test public void probeTarget_consecutiveFailuresBackoffDoubles() {
        HealthMonitor.Target t = target("mayi91",
                () -> new HealthMonitor.ProbeResult(ToolRegistry.Result.REASON_SOURCE_DOWN, "挂"));
        HealthMonitor hm = new HealthMonitor(List.of(t));
        hm.probeTarget(t);
        hm.probeTarget(t);   // 连续第 2 次失败
        assertEquals("连续失败 2", 2, t.consecutiveFailures);
        assertEquals("退避到 120min", 2 * 60 * 60 * 1000L, t.nextProbeMs - t.lastCheckedMs);
    }

    @Test public void probeTarget_timeoutRecordsSourceDown() {
        HealthMonitor.Target t = target("slow", () -> {
            Thread.sleep(20_000);   // 超时
            return null;
        });
        // 用短超时验证 runWithTimeout 路径
        HealthMonitor.ProbeResult r = HealthMonitor.runWithTimeout(t.fn, 100);
        assertNotNull("超时算失败", r);
        assertEquals("超时归因 SOURCE_DOWN", ToolRegistry.Result.REASON_SOURCE_DOWN, r.reason);
    }

    @Test public void probeTarget_exceptionRecordsUnknown() {
        HealthMonitor.Target t = target("err", () -> { throw new RuntimeException("boom"); });
        HealthMonitor.ProbeResult r = HealthMonitor.runWithTimeout(t.fn, 1000);
        assertNotNull(r);
        assertEquals("异常归因 UNKNOWN", ToolRegistry.Result.REASON_UNKNOWN, r.reason);
    }

    // ==================== healthJson ====================

    @Test public void healthJson_mapsStatus() throws Exception {
        HealthMonitor.Target ok = target("a", () -> null);
        HealthMonitor.Target warn = target("b",
                () -> new HealthMonitor.ProbeResult(ToolRegistry.Result.REASON_SOURCE_DOWN, "挂"));
        HealthMonitor.Target down = target("c",
                () -> new HealthMonitor.ProbeResult(ToolRegistry.Result.REASON_PARSE_DRIFT, "解析漂移"));
        HealthMonitor hm = new HealthMonitor(List.of(ok, warn, down));
        hm.probeTarget(ok); hm.probeTarget(warn);
        // down 连败 3 次
        hm.probeTarget(down); hm.probeTarget(down); hm.probeTarget(down);

        JSONArray arr = hm.healthJson();
        assertEquals("3 目标", 3, arr.length());
        JSONObject oa = arr.getJSONObject(0);
        assertEquals("a", oa.getString("id"));
        assertEquals("ok", oa.getString("status"));
        assertFalse("ok 无 reason", oa.has("reason"));

        JSONObject ob = arr.getJSONObject(1);
        assertEquals("b 连续 1 次 → warn", "warn", ob.getString("status"));
        assertEquals(ToolRegistry.Result.REASON_SOURCE_DOWN, ob.getString("reason"));
        assertEquals(1, ob.getInt("consecutiveFailures"));

        JSONObject oc = arr.getJSONObject(2);
        assertEquals("c 连续 3 次 → down", "down", oc.getString("status"));
        assertEquals(3, oc.getInt("consecutiveFailures"));
    }

    // ==================== runRound / retest ====================

    @Test public void runRound_probesOnlyDueTargets() {
        HealthMonitor.Target due = target("due", () -> null);
        HealthMonitor.Target notDue = target("not-due", () -> null);
        HealthMonitor hm = new HealthMonitor(List.of(due, notDue));
        hm.probeTarget(notDue);   // notDue 刚探过, nextProbeMs 在未来
        long before = notDue.lastCheckedMs;

        hm.runRound();            // due 未探过 → 到期; notDue 未到期
        assertTrue("due 被探", due.lastCheckedMs > 0);
        assertEquals("notDue 未到期不探", before, notDue.lastCheckedMs);
    }

    @Test public void retest_probesSpecificTarget() {
        HealthMonitor.Target t = target("mayi91", () -> null);
        HealthMonitor hm = new HealthMonitor(List.of(t));
        hm.retest("mayi91");
        assertTrue("手动重测触发", t.lastCheckedMs > 0);
        hm.retest("nonexistent");   // 不崩
    }
}
