package com.hermes.android;

import org.junit.Test;

import java.io.File;
import java.nio.file.Files;

import static org.junit.Assert.*;

/**
 * M5 安全验收 §3: 产物回写路径 canonical 校验 (StorageManager.isSafe) —
 * 越界路径 (路径穿越/外部绝对路径) 拒收, 房间内路径放行。
 * 用真实临时目录 + getCanonicalPath, 零 Context, 纯 JVM。
 */
public class StorageManagerCanonicalTest {

    private static File tmpBase() throws Exception {
        File base = Files.createTempDirectory("mov-room-test").toFile();
        new File(base, "work").mkdirs();
        return base;
    }

    @Test public void inRoomPath_allowed() throws Exception {
        File base = tmpBase();
        assertTrue("房间内文件放行",
                StorageManager.isCanonicalWithin(base, new File(base, "work/out.html")));
        assertTrue("房间本身放行", StorageManager.isCanonicalWithin(base, base));
    }

    @Test public void pathTraversal_rejected() throws Exception {
        File base = tmpBase();
        assertFalse(".. 穿越到父目录拒收",
                StorageManager.isCanonicalWithin(base, new File(base, "work/../../evil.txt")));
        assertFalse(".. 直接出房间拒收",
                StorageManager.isCanonicalWithin(base, new File(base, "../escape.txt")));
    }

    @Test public void absolutePathOutside_rejected() throws Exception {
        File base = tmpBase();
        File outside = Files.createTempFile("mov-outside", ".txt").toFile();
        assertFalse("房间外绝对路径拒收", StorageManager.isCanonicalWithin(base, outside));
        assertFalse("/etc/passwd 拒收", StorageManager.isCanonicalWithin(base, new File("/etc/passwd")));
    }

    @Test public void nonexistentPathOutside_rejected() throws Exception {
        File base = tmpBase();
        File tmpParent = Files.createTempDirectory("mov-parent").toFile();
        assertFalse("不存在但穿越的路径拒收 (canonical 解析后越界)",
                StorageManager.isCanonicalWithin(base, new File(tmpParent, "x/../../" + base.getName() + "/../..")));
    }
}
