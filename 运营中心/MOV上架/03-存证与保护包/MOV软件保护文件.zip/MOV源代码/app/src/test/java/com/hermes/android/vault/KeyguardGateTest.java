package com.hermes.android.vault;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * KeyguardGate 单测 — 闸状态机四路径（过/拒/取消/无锁屏）+ 当次有效 + 并发防抖 + 迟到结果忽略。
 * 纯 JVM：FakePrompter 驱动真实状态机，不断言 mock 输入（断言的是状态转换与当次条目绑定）。
 */
public class KeyguardGateTest {

    /** 可控 Prompter：捕获 handler，测试手动驱动 approve/reject */
    private static class FakePrompter implements KeyguardGate.Prompter {
        KeyguardGate.ResultHandler handler;
        String lastDesc;

        @Override public void prompt(String desc, KeyguardGate.ResultHandler h) {
            this.lastDesc = desc;
            this.handler = h;
        }

        void approve() { handler.onApproved(); }
        void reject(String reason) { handler.onRejected(reason); }
    }

    private static class Cb implements KeyguardGate.ResultHandler {
        boolean approved;
        String rejectedReason;

        @Override public void onApproved() { approved = true; }
        @Override public void onRejected(String reason) { rejectedReason = reason; }
    }

    @Test public void approved_path_onlyForCurrentEntry() {
        KeyguardGate g = new KeyguardGate();
        FakePrompter fp = new FakePrompter();
        Cb cb = new Cb();

        assertTrue("闸可发起", g.request(fp, "entry-1", "解锁保险柜", cb));
        assertEquals("动作描述透传", "解锁保险柜", fp.lastDesc);
        assertEquals(KeyguardGate.State.PENDING, g.state());

        fp.approve();
        assertEquals(KeyguardGate.State.APPROVED, g.state());
        assertTrue("当次条目批准", g.isApprovedFor("entry-1"));
        assertFalse("其他条目不批准(不搞解锁全场)", g.isApprovedFor("entry-2"));
        assertTrue("批准回调触发", cb.approved);

        g.consume();
        assertEquals("消费后复位 IDLE", KeyguardGate.State.IDLE, g.state());
        assertFalse("消费后不再批准", g.isApprovedFor("entry-1"));
    }

    @Test public void rejected_path() {
        KeyguardGate g = new KeyguardGate();
        FakePrompter fp = new FakePrompter();
        Cb cb = new Cb();

        g.request(fp, "entry-1", "解锁保险柜", cb);
        fp.reject("rejected");

        assertEquals(KeyguardGate.State.REJECTED, g.state());
        assertEquals("rejected", cb.rejectedReason);
        assertFalse("拒绝后拿不到内容", g.isApprovedFor("entry-1"));
    }

    @Test public void cancelled_path() {
        KeyguardGate g = new KeyguardGate();
        FakePrompter fp = new FakePrompter();
        Cb cb = new Cb();

        g.request(fp, "entry-1", "解锁保险柜", cb);
        fp.reject("cancelled");

        assertEquals("取消不崩, 状态=CANCELLED", KeyguardGate.State.CANCELLED, g.state());
        assertEquals("cancelled", cb.rejectedReason);
        assertFalse("取消后拿不到内容", g.isApprovedFor("entry-1"));
    }

    @Test public void noLockscreen_path_honestDowngrade() {
        KeyguardGate g = new KeyguardGate();
        FakePrompter fp = new FakePrompter();
        Cb cb = new Cb();

        // 无锁屏设备: prompter 直接 onRejected(no_lockscreen_denied) → 诚实降级, 不许静默跳过
        g.request(fp, "entry-1", "解锁保险柜", cb);
        fp.reject("no_lockscreen_denied");

        assertEquals(KeyguardGate.State.NO_LOCKSCREEN, g.state());
        assertEquals("no_lockscreen_denied", cb.rejectedReason);
        assertFalse("无锁屏绝不批准(静默跳过被禁)", g.isApprovedFor("entry-1"));
    }

    @Test public void rejectedThenConsume_allowsNextRequest() {
        // v1.1 GATE_BUSY 自愈: 拒绝/取消/无锁屏后必须能复位继续用, 不需 force-stop
        KeyguardGate g = new KeyguardGate();
        FakePrompter fp = new FakePrompter();
        Cb cb1 = new Cb(), cb2 = new Cb();

        g.request(fp, "a", "解锁", cb1);
        fp.reject("cancelled");
        assertEquals("拒绝后状态 REJECTED/CANCELLED", KeyguardGate.State.CANCELLED, g.state());
        assertFalse("拒绝后不批准", g.isApprovedFor("a"));

        g.consume();   // 调用方复位（VaultToolProvider/BridgeVault 拒绝后 consume）
        assertEquals(KeyguardGate.State.IDLE, g.state());

        assertTrue("复位后能再次 request", g.request(fp, "b", "解锁", cb2));
        fp.approve();
        assertTrue("b 正常批准", g.isApprovedFor("b"));
        assertFalse("a 不跨条目", g.isApprovedFor("a"));
    }

    @Test public void oneUnlockPerRequest_secondEntryNeedsNewGate() {
        KeyguardGate g = new KeyguardGate();
        FakePrompter fp = new FakePrompter();
        Cb cb1 = new Cb(), cb2 = new Cb();

        g.request(fp, "a", "解锁", cb1);
        fp.approve();
        assertTrue(g.isApprovedFor("a"));
        g.consume();

        // 第二次解锁 b → 必须重新过闸, 不继承 a 的授权
        assertTrue("b 重新发起闸", g.request(fp, "b", "解锁", cb2));
        assertEquals(KeyguardGate.State.PENDING, g.state());
        assertFalse("b 未过闸前不批准", g.isApprovedFor("b"));
        fp.approve();
        assertTrue("b 过闸后批准", g.isApprovedFor("b"));
        assertFalse("a 的授权不跨条目生效", g.isApprovedFor("a"));
    }

    @Test public void concurrentRequestRejectedWhilePending() {
        KeyguardGate g = new KeyguardGate();
        FakePrompter fp = new FakePrompter();
        Cb cb1 = new Cb(), cb2 = new Cb();

        assertTrue(g.request(fp, "a", "解锁", cb1));
        assertEquals(KeyguardGate.State.PENDING, g.state());
        assertFalse("PENDING 中再次发起被拒(busy)", g.request(fp, "b", "解锁", cb2));
        // 原请求不受影响, 仍可批准
        fp.approve();
        assertTrue(g.isApprovedFor("a"));
    }

    @Test public void staleResultAfterConsumeIgnored() {
        KeyguardGate g = new KeyguardGate();
        FakePrompter fp = new FakePrompter();
        Cb cb = new Cb();

        g.request(fp, "a", "解锁", cb);
        g.consume();          // 闸已关闭（授权过期）
        fp.approve();         // 迟到的结果 → 忽略, 不触发回调
        assertFalse("迟到批准不触发回调", cb.approved);
        assertEquals("状态保持 IDLE", KeyguardGate.State.IDLE, g.state());
    }
}
