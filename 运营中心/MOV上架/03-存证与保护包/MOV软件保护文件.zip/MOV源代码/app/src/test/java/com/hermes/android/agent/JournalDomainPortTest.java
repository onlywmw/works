package com.hermes.android.agent;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.File;

/**
 * 域记忆移植（工单8，DESIGN_MEM_DOMAIN_PORT §七 验收 1-3）：
 * ① 信封截取（三格式回执 payload 逐字节 + 失败/空不落账）
 * ② 域过滤
 * ③ 工具弃用模拟（注销→历史可查→新工具同域续写→连续无断裂）
 * ④ 变异亲杀由验收员执行（截取改恒空→必红）；本类为变异目标基线。
 */
public class JournalDomainPortTest {

    @Rule public TemporaryFolder tmp = new TemporaryFolder();
    private File roomsDir;
    private Journal journal;

    @Before
    public void setup() throws Exception {
        roomsDir = tmp.newFolder("rooms");
        journal = new Journal(roomsDir);
    }

    /** ① 信封截取：三格式回执（JSON/文本/XML）→ 四字段完整 + payload 逐字节保留 */
    @Test
    public void envelopeThreeFormatsPayloadPreserved() throws Exception {
        String json = "{\"steps\":8432,\"hr\":{\"avg\":72}}";
        String text = "76.5kg";
        String xml = "<run dist=\"5.2\" dur=\"28:40\"/>";
        appendReceipt("mcp.fitbit.sync", "fitness", json);
        appendReceipt("mcp.smartscale.weight", "fitness", text);
        appendReceipt("mcp.strava.run", "fitness", xml);

        JSONArray r = journal.domainReceipts("global", "fitness");
        assertEquals(3, r.length());
        assertEquals("mcp.fitbit.sync", r.getJSONObject(0).getString("tool"));
        assertEquals("fitness", r.getJSONObject(0).getString("domain"));
        assertEquals(json, r.getJSONObject(0).getString("payload"));   // 逐字节完整
        assertEquals(text, r.getJSONObject(1).getString("payload"));
        assertEquals(xml, r.getJSONObject(2).getString("payload"));
    }

    /** ① 失败/空不落账：无成功回执 → 域查询为空 */
    @Test
    public void noReceiptEmptyResult() {
        assertTrue(journal.domainReceipts("global", "fitness").length() == 0);
    }

    /** ② 域过滤：跨域隔离，同域聚合（seq 升序） */
    @Test
    public void domainFilterIsolated() throws Exception {
        appendReceipt("mcp.fitbit.sync", "fitness", "{\"steps\":1}");
        appendReceipt("mcp.note.save", "notes", "{\"text\":\"hi\"}");
        appendReceipt("mcp.oura.sync", "fitness", "{\"steps\":2}");

        JSONArray f = journal.domainReceipts("global", "fitness");
        assertEquals(2, f.length());
        assertEquals("mcp.fitbit.sync", f.getJSONObject(0).getString("tool"));
        assertEquals("mcp.oura.sync", f.getJSONObject(1).getString("tool"));

        JSONArray n = journal.domainReceipts("global", "notes");
        assertEquals(1, n.length());
        assertEquals("mcp.note.save", n.getJSONObject(0).getString("tool"));
    }

    /** ③ 工具弃用模拟：A 工具 → 弃用 → 新工具同域续写 → 历史连续无断裂 + 预算覆盖投影 */
    @Test
    public void toolDeprecationContinuity() throws Exception {
        appendReceipt("mcp.fitbit.sync", "fitness", "{\"steps\":8432}");
        appendReceipt("mcp.strava.run", "fitness", "<run dist=\"5.2\"/>");
        // 弃用 fitbit（不再注册新事件）→ 新工具 oura 同域续写
        appendReceipt("mcp.oura.sync", "fitness", "{\"steps\":9100,\"sleep\":390}");

        JSONArray r = journal.domainReceipts("global", "fitness");
        assertEquals(3, r.length());   // 连续无断裂：fitbit + strava + oura
        assertEquals("mcp.fitbit.sync", r.getJSONObject(0).getString("tool"));
        assertEquals("mcp.strava.run", r.getJSONObject(1).getString("tool"));
        assertEquals("mcp.oura.sync", r.getJSONObject(2).getString("tool"));

        // 预算覆盖投影：预算内逐字；超预算塌缩成一行摘要
        JSONArray cover = journal.domainCover("global", "fitness", 3);
        assertEquals(3, cover.length());
        assertEquals("verbatim", cover.getJSONObject(0).getString("mode"));

        JSONArray coverTight = journal.domainCover("global", "fitness", 1);
        assertEquals(2, coverTight.length());   // 1 verbatim + 1 summary
        assertEquals("summary", coverTight.getJSONObject(1).getString("mode"));
        assertEquals(2, coverTight.getJSONObject(1).getInt("collapsed"));
    }

    /** 域解析链：Tool.domain → Manifest.domain → toolset 推导 → other（DESIGN §四 拍板C） */
    @Test
    public void effectiveDomainChain() {
        // Tool.domain 显式优先
        ToolRegistry.Tool t1 = new ToolRegistry.Tool("t", "d", null, args -> null,
                "native", "readonly", "none", true, 30,
                "file", null, null, null, null, 8000, null, null, "work");
        assertEquals("work", t1.effectiveDomain());

        // Manifest.domain 兜底
        ToolRegistry.Manifest m = new ToolRegistry.Manifest("title", "low", "desc", false, "io",
                "SLOW", false, 30000, "fitness");
        ToolRegistry.Tool t2 = new ToolRegistry.Tool("t", "d", null, args -> null,
                "native", "readonly", "none", true, 30,
                "file", null, null, null, null, 8000, m, null);
        assertEquals("fitness", t2.effectiveDomain());

        // toolset 推导
        ToolRegistry.Tool t3 = new ToolRegistry.Tool("t", "d", null, args -> null,
                "remote", "readonly", "none", true, 30,
                "biz", null, null, null, null, 8000, null, null);
        assertEquals("biz", t3.effectiveDomain());

        // 全空 → other
        ToolRegistry.Tool t4 = new ToolRegistry.Tool("t", "d", null, args -> null);
        assertEquals("other", t4.effectiveDomain());
    }

    private void appendReceipt(String tool, String domain, String payload) throws Exception {
        JSONObject ev = Journal.toolReceiptEvent(tool, domain, payload);
        assertNotNull("toolReceiptEvent 不应为 null", ev);
        assertTrue("落账应成功", journal.append("global", ev) > 0);
    }
}
