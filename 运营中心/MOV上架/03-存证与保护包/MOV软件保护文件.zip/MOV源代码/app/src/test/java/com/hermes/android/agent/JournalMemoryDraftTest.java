package com.hermes.android.agent;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.nio.file.Files;

import static org.junit.Assert.*;

/**
 * L1 记忆草案区单测（DESIGN_MEMORY_LAYERS，P6 №5）——零网络注入式（临时目录 journal）。
 * 覆盖：单行硬顶（修正②）/ 14 天衰减（修正①）/ 晋升链路（修正①，晋升排除）。
 */
public class JournalMemoryDraftTest {

    private File roomsDir;
    private Journal j;

    @Before public void setUp() throws Exception {
        roomsDir = Files.createTempDirectory("journal_draft_test").toFile();
        j = new Journal(roomsDir);
    }

    @After public void tearDown() throws Exception {
        deleteRecursive(roomsDir);
    }

    private void deleteRecursive(File f) {
        File[] c = f.listFiles();
        if (c != null) for (File x : c) deleteRecursive(x);
        f.delete();
    }

    // ==================== 单行硬顶（修正②） ====================

    @Test public void appendDraftSingleLineOk() {
        int seq = j.appendDraft("r1", "用户偏好黑咖啡", "memory");
        assertTrue("单行草案应写入", seq > 0);
    }

    @Test public void appendDraftMultilineRejected() {
        int seq = j.appendDraft("r1", "第一行\n第二行", "memory");
        assertEquals("含换行 → 超行拒写", -1, seq);
    }

    @Test public void appendDraftCarriageRejected() {
        assertEquals("含回车 → 拒写", -1, j.appendDraft("r1", "a\rb", "todo"));
    }

    @Test public void appendDraftEmptyRejected() {
        assertEquals("空草案 → 拒写", -2, j.appendDraft("r1", "  ", "memory"));
    }

    // ==================== 有效草案读取 ====================

    @Test public void memoryDraftsReturnsValid() {
        j.appendDraft("r1", "记住用户偏好", "memory");
        j.appendDraft("r1", "当前任务: 修 bug", "todo");
        JSONArray drafts = j.memoryDrafts("r1");
        assertEquals("两条有效草案", 2, drafts.length());
    }

    @Test public void memoryDraftsUnknownRoomEmpty() {
        assertEquals(0, j.memoryDrafts("r_不存在").length());
    }

    // ==================== 14 天衰减（修正①） ====================

    @Test public void staleDraftCleanedAfterTtl() {
        j.appendDraft("r1", "过期草案", "memory");
        long future = System.currentTimeMillis() + 15L * 24 * 3600 * 1000;  // 15 天后
        int cleaned = j.expireStaleDrafts("r1", future);
        assertEquals("超 14 天未引用 → 清理 1 条", 1, cleaned);
    }

    @Test public void freshDraftNotCleaned() {
        j.appendDraft("r1", "新鲜草案", "memory");
        int cleaned = j.expireStaleDrafts("r1", System.currentTimeMillis());
        assertEquals("未超 TTL → 不清理", 0, cleaned);
    }

    // ═══ 工单7 P1 G10: expire 幂等（连续跑只写一条 _memory_draft_expired） ═══

    @Test public void expireStaleDrafts_idempotent() {
        j.appendDraft("r1", "过期草案", "memory");
        long future = System.currentTimeMillis() + 15L * 24 * 3600 * 1000;
        assertEquals("第一次清理 1 条", 1, j.expireStaleDrafts("r1", future));
        assertEquals("第二次幂等, 不再清理", 0, j.expireStaleDrafts("r1", future));
        org.json.JSONArray evs = j.replay("r1", 50).optJSONObject("data").optJSONArray("events");
        int expired = 0;
        for (int i = 0; i < evs.length(); i++) {
            if (Journal.TYPE_DRAFT_EXPIRE.equals(evs.optJSONObject(i).optString("type"))) expired++;
        }
        assertEquals("只写一条 expired 事件", 1, expired);
    }

    // ==================== 晋升链路（修正①：晋升排除，裁判是使用） ====================

    @Test public void promoteExcludesFromDrafts() {
        j.appendDraft("r1", "关键结论 A", "memory");
        j.promoteDraft("r1", "关键结论 A");   // 被引用验证 → 晋升
        JSONArray drafts = j.memoryDrafts("r1");
        assertEquals("已晋升草案不再出现在草案区", 0, drafts.length());
    }

    @Test public void promoteWritesVerifiedEvent() {
        j.appendDraft("r1", "关键结论 B", "memory");
        j.promoteDraft("r1", "关键结论 B");
        JSONArray events = j.replay("r1", 50).optJSONObject("data").optJSONArray("events");
        boolean found = false;
        for (int i = 0; i < events.length(); i++) {
            if (Journal.TYPE_PROMOTED.equals(events.optJSONObject(i).optString("type"))) {
                found = true;
                break;
            }
        }
        assertTrue("晋升事件已写入", found);
    }

    @Test public void draftAndPromoteAreJournalEvents() {
        // 修正③: 草案/晋升都是 journal 事件（replay 可见），不平行造系统
        j.appendDraft("r1", "草案即事件", "memory");
        j.promoteDraft("r1", "草案即事件");
        JSONArray events = j.replay("r1", 50).optJSONObject("data").optJSONArray("events");
        boolean draft = false, promoted = false;
        for (int i = 0; i < events.length(); i++) {
            String t = events.optJSONObject(i).optString("type");
            if (Journal.TYPE_DRAFT.equals(t)) draft = true;
            if (Journal.TYPE_PROMOTED.equals(t)) promoted = true;
        }
        assertTrue("草案是 journal 事件", draft);
        assertTrue("晋升是 journal 事件", promoted);
    }

    // ==================== L3 周期策展（记忆整合） ====================

    @Test public void curatePromotesRepeatedDraft() {
        // 重复写入 ≥2 = 使用证据（修正①）→ L3 整合晋升
        j.appendDraft("r1", "用户经常加班到很晚", "memory");
        j.appendDraft("r1", "用户经常加班到很晚", "memory");
        int actions = j.memoryCurate("r1");
        assertTrue("重复草案应触发晋升", actions >= 1);
        assertEquals("已晋升不再出现在草案区", 0, j.memoryDrafts("r1").length());
    }

    @Test public void curateDoesNotPromoteSingleDraft() {
        j.appendDraft("r1", "单次记录", "memory");
        int actions = j.memoryCurate("r1");
        assertEquals("单次草案不晋升", 0, actions);
        assertEquals("草案仍保留", 1, j.memoryDrafts("r1").length());
    }

    @Test public void curateCleansStaleDrafts() {
        j.appendDraft("r1", "过期草案", "memory");
        long future = System.currentTimeMillis() + 15L * 24 * 3600 * 1000;
        int actions = j.memoryCurate("r1");
        // 用未来时间模拟——但 curate 用真实 now，这里验证 curate 至少不崩 + 有效草案保留
        assertTrue(actions >= 0);
    }

    @Test public void curateDistinctDraftsNoPromote() {
        j.appendDraft("r1", "草案A", "memory");
        j.appendDraft("r1", "草案B", "todo");
        int actions = j.memoryCurate("r1");
        assertEquals("不同草案不晋升", 0, actions);
        assertEquals("两条草案保留", 2, j.memoryDrafts("r1").length());
    }

    @Test public void curateRespectsDraftLimit() {
        // 修正④ 时长钳制护栏（巡检#53）：51+ 草案单次只扫 CURATE_DRAFT_LIMIT=50。
        // 构造: A×2（前 50 内, count=2 → 晋升）+ 48 不同 + 超限×2（第 51/52 位, 被钳制不晋升）。
        j.appendDraft("r1", "重复草案A", "memory");
        j.appendDraft("r1", "重复草案A", "memory");
        for (int i = 0; i < 48; i++) j.appendDraft("r1", "不同" + i, "memory");
        j.appendDraft("r1", "超限草案", "memory");
        j.appendDraft("r1", "超限草案", "memory");

        int actions = j.memoryCurate("r1");
        assertEquals("钳制生效：只晋升前 50 内的重复草案A，超限草案被钳制", 1, actions);
    }

    @Test public void curateLimitMutantKilled() {
        // 反证：若 CURATE_DRAFT_LIMIT 被改大（钳制失效），超限草案也晋升 → 本测试红。
        // 与 curateRespectsDraftLimit 同构，额外断言超限草案未晋升（仍在草案区）。
        j.appendDraft("r1", "A", "memory");
        j.appendDraft("r1", "A", "memory");
        for (int i = 0; i < 48; i++) j.appendDraft("r1", "d" + i, "memory");
        j.appendDraft("r1", "Z超限", "memory");
        j.appendDraft("r1", "Z超限", "memory");
        j.memoryCurate("r1");
        JSONArray drafts = j.memoryDrafts("r1");
        // 超限草案未晋升 → 仍在草案区（若钳制失效被晋升 → 排除 → 本断言红）
        boolean zStill = false;
        for (int i = 0; i < drafts.length(); i++) {
            if (drafts.optJSONObject(i).optString("draft").equals("Z超限")) zStill = true;
        }
        assertTrue("超限草案被钳制未晋升，仍留在草案区", zStill);
    }

    // ==================== 读取时按需覆盖（DESIGN_MEMORY_LAYERS v2 §六，吸收 OptMem cover） ====================

    @Test public void coverWithinBudgetAllVerbatim() {
        j.appendDraft("r1", "草案1", "memory");
        j.appendDraft("r1", "草案2", "todo");
        JSONArray cover = j.memoryCover("r1", 10);
        assertEquals("预算内全部逐字", 2, cover.length());
        for (int i = 0; i < cover.length(); i++) {
            assertEquals("逐字模式", "verbatim", cover.optJSONObject(i).optString("mode"));
            assertFalse("逐字条不待压缩", cover.optJSONObject(i).optBoolean("needsCompress"));
        }
    }

    @Test public void coverOverBudgetCollapsesOld() {
        for (int i = 0; i < 5; i++) j.appendDraft("r1", "草案" + i, i % 2 == 0 ? "memory" : "todo");
        JSONArray cover = j.memoryCover("r1", 3);
        assertEquals("预算 3 + 1 摘要 = 4 条", 4, cover.length());
        org.json.JSONObject first = cover.optJSONObject(0);
        assertEquals("旧条塌缩成摘要", "summary", first.optString("mode"));
        assertTrue("摘要标记待压缩（懒触发）", first.optBoolean("needsCompress"));
        assertTrue("摘要含塌缩数量", first.optString("text").contains("2 条"));
        assertTrue("摘要含 kind 统计", first.optString("text").contains("memory"));
        for (int i = 1; i < cover.length(); i++) {
            assertEquals("新条逐字", "verbatim", cover.optJSONObject(i).optString("mode"));
        }
    }

    @Test public void coverKeepsOriginalInJournal() {
        // 修正③：塌缩只影响"读到什么"，原文 5 条仍在 journal
        for (int i = 0; i < 5; i++) j.appendDraft("r1", "原文" + i, "memory");
        JSONArray cover = j.memoryCover("r1", 2);
        assertEquals("3 旧塌缩 + 2 新逐字", 3, cover.length());
        assertEquals("最旧的在摘要", "summary", cover.optJSONObject(0).optString("mode"));
        JSONArray events = j.replay("r1", 50).optJSONObject("data").optJSONArray("events");
        int drafts = 0;
        for (int i = 0; i < events.length(); i++) {
            if (Journal.TYPE_DRAFT.equals(events.optJSONObject(i).optString("type"))) drafts++;
        }
        assertEquals("原文仍在 journal", 5, drafts);
    }

    @Test public void coverEmptyRoomEmpty() {
        assertEquals("空房覆盖为空", 0, j.memoryCover("r1", 10).length());
    }

    @Test public void coverBudgetClampedToAtLeastOne() {
        j.appendDraft("r1", "单条", "memory");
        JSONArray cover = j.memoryCover("r1", 0);
        assertEquals("预算钳制 ≥1，单条逐字", 1, cover.length());
        assertEquals("verbatim", cover.optJSONObject(0).optString("mode"));
    }

    // ═══ 批2 memory curated 层（一表双脑真共用） ═══

    @Test public void memoryRemoveTombstoneExcludesFromDrafts() {
        j.appendDraft("r1", "张三欠我5000", "memory");
        int seq = j.memoryRemove("r1", "张三欠我5000");
        assertTrue("remove 写入 tombstone", seq > 0);
        JSONArray drafts = j.memoryDrafts("r1");
        assertEquals("tombstone 标记的条目从草案排除", 0, drafts.length());
    }

    // ═══ 工单7 G1: tombstone 按 seq 生效——删除后重新 add 同文本恢复有效（不永久压制） ═══

    @Test public void tombstoneDoesNotSuppressReAdd() {
        // 删除 A 后又想起 → 重新 add 同文本 → 应恢复有效（旧实现按文本永久压制 = 缺陷）
        j.appendDraft("r1", "A", "memory");
        j.memoryRemove("r1", "A");
        int seq = j.appendDraft("r1", "A", "memory");
        assertTrue("重新 add 应写入", seq > 0);
        JSONArray drafts = j.memoryDrafts("r1");
        assertEquals("重新 add 的同文本应恢复有效", 1, drafts.length());
        assertEquals("A", drafts.optJSONObject(0).optString("draft"));
    }

    @Test public void tombstoneStillSuppressesDraftBeforeIt() {
        // tombstone 只压制"其之前的"同文本草案；同文本在 remove 之前的草案仍被排除
        j.appendDraft("r1", "A", "memory");
        j.memoryRemove("r1", "A");
        assertEquals("remove 之前的 A 仍被排除", 0, j.memoryDrafts("r1").length());
    }

    @Test public void tombstoneDoesNotAffectOtherText() {
        j.appendDraft("r1", "A", "memory");
        j.appendDraft("r1", "B", "memory");
        j.memoryRemove("r1", "A");
        JSONArray drafts = j.memoryDrafts("r1");
        assertEquals("B 不受影响", 1, drafts.length());
        assertEquals("B", drafts.optJSONObject(0).optString("draft"));
    }

    @Test public void memoryReplaceUpdatesCurated() {
        j.appendDraft("r1", "旧记忆：A", "memory");
        j.memoryReplace("r1", "旧记忆：A", "新记忆：B", "memory");
        String curated = j.memoryCurated(j.memoryDrafts("r1"));
        assertTrue("curated 含新条目", curated.contains("新记忆：B"));
        assertFalse("curated 不含旧条目", curated.contains("旧记忆：A"));
    }

    @Test public void memoryCuratedJoinsWithSep() {
        j.appendDraft("r1", "记忆一", "memory");
        j.appendDraft("r1", "记忆二", "memory");
        j.appendDraft("r1", "记忆三", "memory");
        String curated = j.memoryCurated(j.memoryDrafts("r1"));
        assertEquals("§ 分隔对齐 Hermes MEMORY.md", "记忆一§记忆二§记忆三", curated);
    }

    // ═══ L3 模型提炼（摘要懒生成，DESIGN_MEMORY_LAYERS v2 §六） ═══

    @Test public void distill_injectsSummaryEventFrozen() {
        // 预算 1 超预算 → 塌缩 → brain 提炼 → _memory_summary 事件注入（append-only，原文不动）
        j.appendDraft("r1", "记忆甲", "memory");
        j.appendDraft("r1", "记忆乙", "memory");
        j.appendDraft("r1", "记忆丙", "memory");
        Journal.Brain fake = (s, u) -> "记忆甲+乙+丙 的浓缩摘要";
        JSONObject r = j.distillMemory("r1", fake, 1);
        assertTrue("提炼应成功", r.optBoolean("ok"));
        assertTrue("注入 seq > 0", r.optInt("seq") > 0);
        // 冻结注入事件存在
        JSONObject rep = j.replay("r1", 50);
        JSONArray evs = rep.optJSONObject("data").optJSONArray("events");
        boolean found = false;
        for (int i = 0; i < evs.length(); i++) {
            JSONObject e = evs.optJSONObject(i);
            if (Journal.TYPE_MEMORY_SUMMARY.equals(e.optString("type"))) {
                found = true;
                JSONObject pl = e.optJSONObject("payload");
                assertEquals("摘要文本", "记忆甲+乙+丙 的浓缩摘要", pl.optString("summary"));
                assertFalse("冻结注入 payload 不携带逐条原文", pl.has("draft"));
                assertFalse("actor 标记 l3", !"l3".equals(e.optString("actor")));
            }
        }
        assertTrue("应写入 _memory_summary 事件", found);
        // 原文仍在 drafts（append-only 不动原文）
        assertEquals("原文草案仍可读", 3, j.memoryDrafts("r1").length());
    }

    @Test public void distill_coverHitsCachedSummary() {
        j.appendDraft("r1", "甲", "memory");
        j.appendDraft("r1", "乙", "memory");
        j.appendDraft("r1", "丙", "memory");
        Journal.Brain fake = (s, u) -> "真摘要";
        j.distillMemory("r1", fake, 1);
        JSONArray cover = j.memoryCover("r1", 1);
        JSONObject summary = cover.optJSONObject(0);
        assertEquals("mode=summary", "summary", summary.optString("mode"));
        assertEquals("命中缓存返回真摘要", "真摘要", summary.optString("text"));
        assertFalse("缓存命中 → needsCompress=false", summary.optBoolean("needsCompress"));
    }

    @Test public void distill_nullBrain_notConfigured() {
        j.appendDraft("r1", "甲", "memory");
        j.appendDraft("r1", "乙", "memory");
        j.appendDraft("r1", "丙", "memory");
        JSONObject r = j.distillMemory("r1", null, 1);
        assertFalse("未配置模型 → 失败", r.optBoolean("ok"));
        assertEquals("归因 NOT_CONFIGURED", "NOT_CONFIGURED", r.optString("reason"));
    }

    @Test public void distill_brainThrows_sourceDown() {
        j.appendDraft("r1", "甲", "memory");
        j.appendDraft("r1", "乙", "memory");
        j.appendDraft("r1", "丙", "memory");
        Journal.Brain fake = (s, u) -> { throw new RuntimeException("网络不通"); };
        JSONObject r = j.distillMemory("r1", fake, 1);
        assertFalse("调用异常 → 失败", r.optBoolean("ok"));
        assertEquals("归因 SOURCE_DOWN", "SOURCE_DOWN", r.optString("reason"));
    }

    @Test public void distill_emptySummary_sourceDown() {
        j.appendDraft("r1", "甲", "memory");
        j.appendDraft("r1", "乙", "memory");
        j.appendDraft("r1", "丙", "memory");
        Journal.Brain fake = (s, u) -> "   ";
        JSONObject r = j.distillMemory("r1", fake, 1);
        assertFalse("空摘要 → 失败", r.optBoolean("ok"));
        assertEquals("归因 SOURCE_DOWN", "SOURCE_DOWN", r.optString("reason"));
    }

    @Test public void distill_withinBudget_skipped() {
        j.appendDraft("r1", "甲", "memory");
        j.appendDraft("r1", "乙", "memory");
        JSONObject r = j.distillMemory("r1", (s, u) -> "不该调用", 10);
        assertTrue("预算内 → ok", r.optBoolean("ok"));
        assertTrue("无待提炼 → skipped", r.optBoolean("skipped"));
    }

    @Test public void distill_spanChange_recompress() {
        j.appendDraft("r1", "甲", "memory");
        j.appendDraft("r1", "乙", "memory");
        j.appendDraft("r1", "丙", "memory");
        Journal.Brain fake = (s, u) -> "旧摘要";
        j.distillMemory("r1", fake, 1);
        // 原文变化：新草案加入 → 塌缩占位 span 变 → 缓存失效，重新 needsCompress=true
        j.appendDraft("r1", "丁", "memory");
        JSONArray cover = j.memoryCover("r1", 1);
        JSONObject summary = cover.optJSONObject(0);
        assertTrue("原文变 span 变 → 重新 needsCompress=true", summary.optBoolean("needsCompress"));
    }

    // ═══ 工单7 P1 G7+G6: 演化状态视图脱离 tail500（全量 eventsOfType，滚动/超 tail 不丢） ═══

    @Test public void memoryDrafts_seesDraftsBeyondTail500() {
        // G6: tail 500 外的未晋升草案仍可见（旧实现 replay tail 500 会漏）
        for (int i = 0; i < 510; i++) j.appendDraft("r1", "草案" + i, "memory");
        JSONArray drafts = j.memoryDrafts("r1");
        assertEquals("全部草案可见(510 条)", 510, drafts.length());
        boolean seen = false;
        for (int i = 0; i < drafts.length(); i++) {
            if ("草案0".equals(drafts.optJSONObject(i).optString("draft"))) seen = true;
        }
        assertTrue("tail 500 外的未晋升草案仍可见", seen);
    }

    @Test public void promotionBeyondTail_doesNotRevive() {
        // G7: 晋升事件在 tail 外仍生效——已晋升草案(tail 外)不复活
        for (int i = 0; i < 510; i++) j.appendDraft("r1", "草案" + i, "memory");
        j.promoteDraft("r1", "草案0");   // 晋升第 1 条(tail 500 外)
        JSONArray drafts = j.memoryDrafts("r1");
        assertEquals("晋升排除后 509 条", 509, drafts.length());
        boolean seen = false;
        for (int i = 0; i < drafts.length(); i++) {
            if ("草案0".equals(drafts.optJSONObject(i).optString("draft"))) seen = true;
        }
        assertFalse("已晋升草案(tail 外)不出现", seen);
    }

    // ═══ 工单7 P1 G8: span 原文指纹防碰撞（不同原文同统计形状不误命中缓存） ═══

    @Test public void cover_spanFingerprint_noFalseCacheHitAcrossBatches() {
        // 批次1: 3 条 memory, 预算 1 塌缩 2 → distill 缓存"摘要A"
        j.appendDraft("r1", "甲1", "memory");
        j.appendDraft("r1", "乙1", "memory");
        j.appendDraft("r1", "丙1", "memory");
        j.distillMemory("r1", (s, u) -> "摘要A", 1);
        // 批次2: 不同原文, 同统计形状(N=2/最早 MM-dd/kind=memory×2) → 旧实现占位串相同会误命中
        j.memoryRemove("r1", "甲1");
        j.memoryRemove("r1", "乙1");
        j.memoryRemove("r1", "丙1");
        j.appendDraft("r1", "甲2", "memory");
        j.appendDraft("r1", "乙2", "memory");
        j.appendDraft("r1", "丙2", "memory");
        JSONArray cover = j.memoryCover("r1", 1);
        JSONObject summary = cover.optJSONObject(0);
        assertTrue("不同原文同形状 → 不误命中 → 需重压缩", summary.optBoolean("needsCompress"));
        assertFalse("不应返回批次1 的摘要A", "摘要A".equals(summary.optString("text")));
    }
}
