package com.hermes.android.workflow;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * WorkflowEngine fire 链路（纯 JVM，fake ActionExecutor 断言动作被调）。
 */
public class WorkflowEngineTest {

    /** fake 动作执行器：记录被调用的 (workflowId, actionCount)，默认 SUCCESS */
    private static class FakeExecutor implements ActionExecutor {
        final List<String> calls = new ArrayList<>();
        public ActionReceipt execute(JSONArray actions, Map<String, Object> context) {
            calls.add(context.get("workflowId") + ":" + (actions != null ? actions.length() : 0));
            return ActionReceipt.SUCCESS;
        }
    }

    private static class Harness {
        final WorkflowRepository repo;
        final FakeExecutor ex;
        final WorkflowEngine eng;
        Harness() {
            File dir = new File(System.getProperty("java.io.tmpdir"),
                    "wfe_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 100000));
            dir.mkdirs();
            this.ex = new FakeExecutor();
            this.repo = new WorkflowRepository(dir);
            this.eng = new WorkflowEngine(repo, ex);
        }
    }

    private Workflow pageloadWf(String id, boolean enabled) {
        JSONObject t = new JSONObject();
        try { t.put("type", "pageload"); } catch (Exception e) {}
        JSONArray acts = new JSONArray().put(new JSONObject());
        Workflow w = new Workflow(id, t, null, acts);
        w.enabled = enabled;
        return w;
    }

    private Snapshot snap(long now, String url) {
        return new Snapshot(now, url, null, 0, null);
    }

    @Test public void fire_triggerHit_conditionPass_executesAction() {
        Harness h = new Harness();
        h.repo.save(pageloadWf("a", true));

        WorkflowEngine.FireResult r = h.eng.fire(WorkflowEvent.pageLoad("https://x.com", 1000), snap(1000, "https://x.com"));

        assertEquals("触发 1 个", 1, r.fired.size());
        assertEquals("a", r.fired.get(0));
        assertEquals("动作被调 1 次", 1, h.ex.calls.size());
        assertEquals("a:1", h.ex.calls.get(0));
    }

    @Test public void fire_disabledWorkflow_skipped() {
        Harness h = new Harness();
        h.repo.save(pageloadWf("a", false));

        WorkflowEngine.FireResult r = h.eng.fire(WorkflowEvent.pageLoad("https://x.com", 1000), snap(1000, "https://x.com"));

        assertTrue("禁用不触发", r.fired.isEmpty());
        assertTrue("动作不被调", h.ex.calls.isEmpty());
    }

    @Test public void fire_conditionBlocks() {
        Harness h = new Harness();
        Workflow w = pageloadWf("a", true);
        JSONObject c = new JSONObject();
        try { c.put("type", "text").put("pattern", "已出票"); } catch (Exception e) {}
        w.conditions.put(c);
        h.repo.save(w);

        WorkflowEngine.FireResult r = h.eng.fire(WorkflowEvent.pageLoad("https://x.com", 1000),
                snap(1000, "https://x.com"));   // text=null → 条件不通过

        assertTrue("条件拦，不触发", r.fired.isEmpty());
        assertTrue("skipped 标 condition", r.skipped.get(0).endsWith(":condition"));
        assertTrue("动作不被调", h.ex.calls.isEmpty());
    }

    @Test public void fire_cooldownBlocksSecond() {
        Harness h = new Harness();
        Workflow w = pageloadWf("a", true);
        w.cooldownMs = 5000;
        h.repo.save(w);

        h.eng.fire(WorkflowEvent.pageLoad("https://x.com", 10000), snap(10000, "https://x.com"));
        WorkflowEngine.FireResult r2 = h.eng.fire(WorkflowEvent.pageLoad("https://x.com", 13000), snap(13000, "https://x.com"));

        assertEquals("cooldown 内第二次被拦", 0, r2.fired.size());
        assertTrue(r2.skipped.get(0).endsWith(":cooldown"));
        assertEquals("动作只调 1 次", 1, h.ex.calls.size());
    }

    @Test public void fire_dailyCapBlocks() {
        Harness h = new Harness();
        Workflow w = pageloadWf("a", true);
        w.maxRunsPerDay = 1;
        h.repo.save(w);

        h.eng.fire(WorkflowEvent.pageLoad("https://x.com", 1000), snap(1000, "https://x.com"));
        WorkflowEngine.FireResult r2 = h.eng.fire(WorkflowEvent.pageLoad("https://x.com", 2000), snap(2000, "https://x.com"));

        assertEquals("日配额 1 → 第二次被拦", 0, r2.fired.size());
        assertTrue(r2.skipped.get(0).endsWith(":daily_cap"));
    }

    @Test public void fire_traceReportsEachGate() {
        File dir = new File(System.getProperty("java.io.tmpdir"),
                "wft_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 100000));
        dir.mkdirs();
        WorkflowRepository repo = new WorkflowRepository(dir);
        FakeExecutor ex = new FakeExecutor();
        java.util.List<String> trace = new java.util.ArrayList<>();
        WorkflowEngine eng = new WorkflowEngine(repo, ex, trace::add);

        Workflow w = pageloadWf("a", true);
        repo.save(w);
        eng.fire(WorkflowEvent.pageLoad("https://x.com", 1000), snap(1000, "https://x.com"));

        String joined = String.join("\n", trace);
        assertTrue("trace 含 event/trigger hit: " + joined, joined.contains("trigger=pageload hit=true"));
        assertTrue("trace 含 condition PASS: " + joined, joined.contains("condition=PASS"));
        assertTrue("trace 含 FIRED: " + joined, joined.contains("FIRED actions=1"));
    }

    @Test public void fire_traceReportsConditionFail() {
        File dir = new File(System.getProperty("java.io.tmpdir"),
                "wft_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 100000));
        dir.mkdirs();
        WorkflowRepository repo = new WorkflowRepository(dir);
        FakeExecutor ex = new FakeExecutor();
        java.util.List<String> trace = new java.util.ArrayList<>();
        WorkflowEngine eng = new WorkflowEngine(repo, ex, trace::add);

        Workflow w = pageloadWf("a", true);
        JSONObject c = new JSONObject();
        try { c.put("type", "text").put("pattern", "已出票"); } catch (Exception e) {}
        w.conditions.put(c);
        repo.save(w);
        eng.fire(WorkflowEvent.pageLoad("https://x.com", 1000), snap(1000, "https://x.com"));

        String joined = String.join("\n", trace);
        assertTrue("trace 含 condition FAIL: " + joined, joined.contains("condition=FAIL"));
        assertFalse("未 FIRED: " + joined, joined.contains("FIRED"));
    }

    @Test public void fire_timeoutReceipt_doesNotPersist() {
        File dir = new File(System.getProperty("java.io.tmpdir"),
                "wft_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 100000));
        dir.mkdirs();
        WorkflowRepository repo = new WorkflowRepository(dir);
        // F2: 全超时 → 不落账（mutant 防护：验收人会杀「全超时仍落 lastFireAt」）
        WorkflowEngine eng = new WorkflowEngine(repo,
                (a, c) -> ActionExecutor.ActionReceipt.TIMEOUT);
        Workflow w = pageloadWf("a", true);
        repo.save(w);

        WorkflowEngine.FireResult r = eng.fire(WorkflowEvent.pageLoad("https://x.com", 1000), snap(1000, "https://x.com"));

        assertTrue("超时不进 fired", r.fired.isEmpty());
        assertTrue("skipped 标 no_effect", r.skipped.get(0).contains("no_effect"));
        Workflow back = repo.get("a");
        assertEquals("超时不落 lastFireAt", 0, back.lastFireAt);
        assertEquals("超时不落 runsToday", 0, back.runsToday);
        assertEquals("超时不落 runCount", 0, back.runCount);
    }

    @Test public void fire_rejectedReceipt_doesNotPersist() {
        File dir = new File(System.getProperty("java.io.tmpdir"),
                "wft_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 100000));
        dir.mkdirs();
        WorkflowRepository repo = new WorkflowRepository(dir);
        WorkflowEngine eng = new WorkflowEngine(repo,
                (a, c) -> ActionExecutor.ActionReceipt.REJECTED);
        Workflow w = pageloadWf("a", true);
        repo.save(w);

        WorkflowEngine.FireResult r = eng.fire(WorkflowEvent.pageLoad("https://x.com", 1000), snap(1000, "https://x.com"));

        assertTrue(r.fired.isEmpty());
        assertEquals("拒绝也不落 lastFireAt", 0, repo.get("a").lastFireAt);
    }

    @Test public void fire_lastRunAgo_usesWorkflowLastFireAt() {
        // 打回修复：last_run_ago 条件用 per-workflow lastFireAt
        File dir = new File(System.getProperty("java.io.tmpdir"),
                "wfe_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 100000));
        dir.mkdirs();
        WorkflowRepository repo = new WorkflowRepository(dir);
        WorkflowEngine eng = new WorkflowEngine(repo, (a, c) -> ActionExecutor.ActionReceipt.SUCCESS);
        Workflow w = pageloadWf("a", true);
        JSONObject cond = new JSONObject();
        try { cond.put("type", "last_run_ago").put("withinMinutes", 5); } catch (Exception e) {}
        w.conditions.put(cond);
        repo.save(w);

        // 首次 fire（lastFireAt=0 → 未知 FAIL），不落账
        eng.fire(WorkflowEvent.pageLoad("https://x.com", 10000), snap(10000, "https://x.com"));
        assertTrue("首次 lastFireAt=0 条件 FAIL 不触发", repo.get("a").lastFireAt == 0);

        // 手动设 lastFireAt=1min 前 → 条件 PASS
        Workflow saved = repo.get("a");
        saved.lastFireAt = 9940000;   // 1min 前（now=10000000 - 60000）
        repo.save(saved);
        WorkflowEngine.FireResult r2 = eng.fire(WorkflowEvent.pageLoad("https://x.com", 10000000),
                snap(10000000, "https://x.com"));
        assertTrue("lastFireAt 1min 前在 5min 窗口内 → 触发", r2.fired.contains("a"));
    }

    @Test public void fire_countCondition_cascade() {
        Harness h = new Harness();
        Workflow b = pageloadWf("b", true);
        JSONObject c = new JSONObject();
        try { c.put("type", "count").put("min", 2); } catch (Exception e) {}
        b.conditions.put(c);
        h.repo.save(b);

        // snapshot.count=1 < 2 → 拦
        WorkflowEngine.FireResult r1 = h.eng.fire(WorkflowEvent.pageLoad("https://x.com", 1000),
                new Snapshot(1000, "https://x.com", null, 1, null));
        assertTrue(r1.fired.isEmpty());

        // snapshot.count=2 >= 2 → 触发
        WorkflowEngine.FireResult r2 = h.eng.fire(WorkflowEvent.pageLoad("https://x.com", 2000),
                new Snapshot(2000, "https://x.com", null, 2, null));
        assertEquals("count 条件满足触发", 1, r2.fired.size());
    }
}
