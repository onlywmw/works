package com.hermes.android.mcp;

import static org.junit.Assert.*;

import org.json.JSONArray;
import org.junit.Test;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;

/**
 * McpClient 单测 — Streamable HTTP 纯逻辑（SSE 帧解析 / 会话重连 / 关闭），零网络。
 *
 * 红线：不真发网络请求。网络层经包级 Transport 注入记录型 fake。
 */
public class McpClientTest {

    // ══════════ SSE 帧解析 ══════════

    @Test public void sseData_extractsJsonFromEventFrame() {
        String frame = "id: 1\nevent: message\ndata: {\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{}}\n\n";
        assertEquals("提取 data JSON", "{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{}}", McpClient.sseData(frame));
    }

    @Test public void sseData_multipleLinesJoins() {
        String frame = "event: message\ndata: {\"a\":1,\ndata: \"b\":2}\n\n";
        // 多行 data 拼接（标准 SSE 多行 data 用 \n 连接）
        assertEquals("{\"a\":1,\n\"b\":2}", McpClient.sseData(frame));
    }

    @Test public void sseData_noDataReturnsNull() {
        assertEquals("无 data 行 → null", null, McpClient.sseData("event: ping\n\n"));
        assertEquals("空 → null", null, McpClient.sseData(null));
        assertEquals("空串 → null", null, McpClient.sseData(""));
    }

    @Test public void sseData_crlfHandled() {
        String frame = "event: message\r\ndata: {\"ok\":true}\r\n\r\n";
        assertEquals("CRLF 也能解析", "{\"ok\":true}", McpClient.sseData(frame));
    }

    @Test public void sseData_plainJsonPassthrough() {
        // 某些实现直接回 JSON 而非 SSE 帧 —— request() 走 fallback，这里验证 sseData 对纯 JSON 的处理
        assertEquals("纯 JSON 无 data: 行 → null（由 request fallback 处理）", null, McpClient.sseData("{\"jsonrpc\":\"2.0\"}"));
    }

    // ══════════ 缺陷 1：SSE 跨帧拼接 ══════════

    @Test public void sseData_notificationFrameBeforeResult_picksResult() {
        // 一个响应里多个 SSE 事件帧：notification 帧在前、result 帧在后
        String body = "event: message\ndata: {\"jsonrpc\":\"2.0\",\"method\":\"notifications/progress\",\"params\":{\"p\":1}}\n\n"
                    + "event: message\ndata: {\"jsonrpc\":\"2.0\",\"id\":2,\"result\":{\"tools\":[]}}\n\n";
        assertEquals("跳过 notification 帧取 result 帧",
            "{\"jsonrpc\":\"2.0\",\"id\":2,\"result\":{\"tools\":[]}}", McpClient.sseData(body));
    }

    @Test public void sseData_multiFrameCrlf_picksErrorFrame() {
        String body = "data: {\"jsonrpc\":\"2.0\",\"method\":\"notifications/message\"}\r\n\r\n"
                    + "data: {\"jsonrpc\":\"2.0\",\"id\":3,\"error\":{\"code\":-1,\"message\":\"boom\"}}\r\n\r\n";
        assertEquals("CRLF 分帧取 error 帧",
            "{\"jsonrpc\":\"2.0\",\"id\":3,\"error\":{\"code\":-1,\"message\":\"boom\"}}", McpClient.sseData(body));
    }

    @Test public void sseData_noResponseFrame_returnsLastFrameData() {
        // 没有任何帧含 result/error → 返回最后一帧 data（保持契约不返回 null）
        String body = "data: {\"a\":1}\n\ndata: {\"b\":2}\n\n";
        assertEquals("{\"b\":2}", McpClient.sseData(body));
    }

    // ══════════ 记录型 fake 传输层（零网络） ══════════

    static class FakeTransport implements McpClient.Transport {
        static class Call { String method; String sessionId; String json; }
        final List<Call> calls = new ArrayList<>();
        final Queue<McpClient.PostResult> script = new ArrayDeque<>();
        @Override public McpClient.PostResult send(String url, String token, String sessionId,
                                                   String json, String accept, String method) {
            Call c = new Call();
            c.method = method; c.sessionId = sessionId; c.json = json;
            calls.add(c);
            return script.poll();
        }
    }

    private static McpClient.PostResult ok(String sessionId, String sseBody) {
        Map<String, String> h = new HashMap<>();
        if (sessionId != null) h.put("mcp-session-id", sessionId);
        return new McpClient.PostResult(200, "text/event-stream", sseBody, h);
    }

    private static McpClient.PostResult raw(int status) {
        return new McpClient.PostResult(status, null, "", new HashMap<>());
    }

    private static McpClient.StreamableSession connect(FakeTransport t, String sid) throws Exception {
        t.script.add(ok(sid, "data: {\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{\"protocolVersion\":\"2025-06-18\"}}\n\n"));
        t.script.add(raw(202)); // notifications/initialized
        return McpClient.StreamableSession.connect("http://fake/mcp", null, t);
    }

    // ══════════ 缺陷 2：会话过期重连不更新 sessionId ══════════

    @Test public void request_sessionExpired_reconnectsAndReusesNewSessionId() throws Exception {
        FakeTransport t = new FakeTransport();
        McpClient.StreamableSession s = connect(t, "sess-1");
        assertEquals("sess-1", s.sessionId);

        // tools/list 用 sess-1 → 404 过期；重连得 sess-2；重试成功
        t.script.add(raw(404));
        t.script.add(ok("sess-2", "data: {\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{}}\n\n"));
        t.script.add(raw(202)); // 重连后的 initialized 通知
        t.script.add(ok(null, "data: {\"jsonrpc\":\"2.0\",\"id\":2,\"result\":{\"tools\":[{\"name\":\"x\"}]}}\n\n"));

        JSONArray tools = s.listTools();
        assertEquals(1, tools.length());
        assertEquals("重连成功必须写回新 sessionId（不是用完即弃）", "sess-2", s.sessionId);
        FakeTransport.Call retry = t.calls.get(5);
        assertEquals("POST", retry.method);
        assertEquals("重试请求必须带新 session id", "sess-2", retry.sessionId);

        // 后续调用继续沿用新 session
        t.script.add(ok(null, "data: {\"jsonrpc\":\"2.0\",\"id\":2,\"result\":{\"tools\":[]}}\n\n"));
        s.listTools();
        assertEquals("后续调用沿用重连后的 sessionId", "sess-2", t.calls.get(6).sessionId);
    }

    // ══════════ 缺陷 3：close() 必须发 HTTP DELETE ══════════

    @Test public void close_sendsHttpDeleteAndClearsLocalState() throws Exception {
        FakeTransport t = new FakeTransport();
        McpClient.StreamableSession s = connect(t, "sess-9");

        t.script.add(raw(200)); // DELETE 响应
        s.close();

        FakeTransport.Call last = t.calls.get(t.calls.size() - 1);
        assertEquals("close 必须发 HTTP DELETE（MCP Streamable HTTP 规范）", "DELETE", last.method);
        assertEquals("DELETE 必须带 Mcp-Session-Id", "sess-9", last.sessionId);
        assertNull("close 后本地 sessionId 清空", s.sessionId);
    }

    @Test public void close_deleteFails_stillCleansUpWithoutThrowing() throws Exception {
        FakeTransport t = new FakeTransport();
        McpClient.StreamableSession s = connect(t, "sess-9");

        // 传输层失败：script 队列已空 → send 返回 null（等价 postRaw 异常 → null）
        s.close(); // 不抛错、不阻塞

        FakeTransport.Call last = t.calls.get(t.calls.size() - 1);
        assertEquals("DELETE 仍被尝试", "DELETE", last.method);
        assertNull("DELETE 失败也清理本地状态", s.sessionId);
    }
}
