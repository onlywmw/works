package com.hermes.android.scene;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.junit.Test;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import static org.junit.Assert.*;

/**
 * FastSceneProvider 单元测试 — FUSION F2 快脑场景卡注册表。
 *
 * 红线：零网络。只验证 discover() 元数据与注册表注册，绝不执行 handler（网络 IO 卡）。
 */
public class FastSceneProviderTest {

    private static AgentLoop.Tools emptyTools() {
        return new AgentLoop.Tools() {
            public String fileList(String roomId) { return ""; }
            public String fileRead(String roomId, String path) { return ""; }
            public String fileWrite(String roomId, String path, String content) { return ""; }
            public String capabilityOf(String text) { return ""; }
            public String deviceCmd(String text) { return ""; }
            public String packageApk(String roomId, String path, String appName) { return "{}"; }
            public String shellExec(String cmd, int timeoutSec) { return ""; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            public String filePush(String roomId, String path) { return "{}"; }
            public String filePull(String roomId, String name) { return "{}"; }
        };
    }

    private ToolRegistry builtRegistry() {
        return ToolRegistry.build(emptyTools(), "room1", HashSet::new,
                new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
    }

    @Test public void discover_returns8FastCards() {
        FastSceneProvider p = new FastSceneProvider();
        List<ToolRegistry.Tool> tools = p.discover();
        assertEquals("场景卡数量应为 9 (W3 加 shop_search)", 9, tools.size());
        for (ToolRegistry.Tool t : tools) {
            assertNotNull("工具名非空", t.name);
            assertNotNull("manifest 非空", t.manifest);
            assertEquals("level 应为 FAST: " + t.name, "FAST", t.manifest.level);
            assertFalse("name 不应为空串", t.name.isEmpty());
        }
    }

    @Test public void networkCardsSyncTrue() {
        FastSceneProvider p = new FastSceneProvider();
        int networkCards = 0;
        for (ToolRegistry.Tool t : p.discover()) {
            if (t.name.equals("train_search") || t.name.equals("music_search")
                    || t.name.equals("face_search_drama") || t.name.equals("mayi_latest")) {
                networkCards++;
                assertTrue("网络 IO 卡应 sync=true（禁同步桥红线）: " + t.name, t.manifest.sync);
            }
        }
        assertEquals("应有 4 张网络卡", 4, networkCards);
    }

    @Test public void localCardsSyncFalse() {
        FastSceneProvider p = new FastSceneProvider();
        for (ToolRegistry.Tool t : p.discover()) {
            if (t.name.equals("video_sources") || t.name.equals("web_sites")
                    || t.name.equals("web_adapt") || t.name.equals("check_drama_updates")) {
                assertFalse("本地/静态卡 sync 应为 false: " + t.name, t.manifest.sync);
            }
        }
    }

    @Test public void trainMetaMatchesContract() {
        FastSceneProvider p = new FastSceneProvider();
        boolean found = false;
        for (ToolRegistry.Tool t : p.discover()) {
            if (t.name.equals("train_search")) {
                found = true;
                assertEquals("toolset 应为 travel", "travel", t.toolset);
                assertEquals("timeoutMs 应为 8000", 8000, t.manifest.timeoutMs);
                assertEquals("Tool.timeoutSec 应为 8", 8, t.timeoutSec);
                assertNotNull("params 非空", t.params);
                assertTrue("params 应有 from", t.params.length >= 1 && "from".equals(t.params[0].name));
                assertNotNull("examples 非空", t.examples);
                assertTrue("examples 应有示例", t.examples.length > 0);
            }
        }
        assertTrue("train_search 应在 discover 中", found);
    }

    @Test public void registryFindFastCards() {
        ToolRegistry r = builtRegistry();
        ToolRegistry.Tool t = r.find("train_search");
        assertNotNull("train_search 应注册进 ToolRegistry", t);
        assertEquals("level 应为 FAST", "FAST", t.manifest.level);
        assertTrue("train_search sync 应为 true", t.manifest.sync);
        assertNotNull("music_search 应注册", r.find("music_search"));
        assertNotNull("face_search_drama 应注册", r.find("face_search_drama"));
        assertNotNull("mayi_latest 应注册", r.find("mayi_latest"));
        assertNotNull("check_drama_updates 应注册", r.find("check_drama_updates"));
    }

    @Test public void allTools_includesFastCards() {
        ToolRegistry r = builtRegistry();
        boolean trainSeen = false;
        for (ToolRegistry.Tool t : r.allTools()) {
            if (t.name.equals("train_search")) trainSeen = true;
        }
        assertTrue("allTools() 应包含 train_search", trainSeen);
    }
}
