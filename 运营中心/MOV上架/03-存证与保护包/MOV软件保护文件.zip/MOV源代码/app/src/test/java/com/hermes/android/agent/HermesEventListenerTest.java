package com.hermes.android.agent;

import org.json.JSONObject;
import org.junit.Test;

import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.*;

/**
 * HermesEventListener 纯 JVM 单测（P2 M3，零网络注入式）：
 * SSE data 行解析 / 终态判定 / 重连 3 次降级循环。
 * HTTP 长连属真机验收；此处只测纯函数与可注入的 runLoop。
 */
public class HermesEventListenerTest {

    // ==================== SSE data 行解析 ====================

    @Test public void parseDataEvent_ok() throws Exception {
        JSONObject ev = HermesEventListener.parseDataEvent(
                "data: {\"task_id\":\"t1\",\"kind\":\"progress\",\"data\":\"一段\"}");
        assertNotNull(ev);
        assertEquals("t1", ev.getString("task_id"));
        assertEquals("progress", ev.getString("kind"));
        assertEquals("一段", ev.getString("data"));
    }

    @Test public void parseDataEvent_ignoreNonDataLines() {
        assertNull(HermesEventListener.parseDataEvent(": keepalive"));
        assertNull(HermesEventListener.parseDataEvent("id: 1"));
        assertNull(HermesEventListener.parseDataEvent(null));
        assertNull(HermesEventListener.parseDataEvent(""));
    }

    @Test public void parseDataEvent_badJsonReturnsNull() {
        assertNull(HermesEventListener.parseDataEvent("data: not-json"));
    }

    @Test public void isTerminal_kinds() {
        assertTrue(HermesEventListener.isTerminal(HermesEventListener.KIND_DONE));
        assertTrue(HermesEventListener.isTerminal(HermesEventListener.KIND_FAILED));
        assertTrue(HermesEventListener.isTerminal(HermesEventListener.KIND_CANCELLED));
        assertFalse(HermesEventListener.isTerminal(HermesEventListener.KIND_PROGRESS));
        assertFalse(HermesEventListener.isTerminal(""));
    }

    // ==================== 重连/降级循环（注入式） ====================

    @Test public void reconnectThreeTimesThenDegrade() {
        // 一直断线（返回 false）→ 初始 1 次 + 3 次重连 = 4 次调用后降级
        AtomicInteger calls = new AtomicInteger();
        HermesEventListener.StreamSource src = () -> { calls.incrementAndGet(); return false; };
        HermesEventListener el = new HermesEventListener("http://x", "t", "id", null, src);
        boolean ended = el.runLoop(src);
        assertFalse("3 次重连失败 → 降级", ended);
        assertEquals(HermesEventListener.MAX_RECONNECT + 1, calls.get());
    }

    @Test public void terminalStopsImmediately() {
        AtomicInteger calls = new AtomicInteger();
        HermesEventListener.StreamSource src = () -> { calls.incrementAndGet(); return true; };
        HermesEventListener el = new HermesEventListener("http://x", "t", "id", null, src);
        assertTrue("终态自然退订", el.runLoop(src));
        assertEquals(1, calls.get());
    }

    @Test public void degradedSignalsListener() {
        // 完整链路: 断线 → 3 次重连 → onDegraded 通知
        AtomicInteger degraded = new AtomicInteger();
        HermesEventListener.Listener listener = new HermesEventListener.Listener() {
            @Override public void onEvent(String taskId, String kind, String data) {}
            @Override public void onDegraded() { degraded.incrementAndGet(); }
        };
        HermesEventListener.StreamSource src = () -> false;   // 一直断线
        HermesEventListener el = new HermesEventListener("http://x", "t", "id", listener, src);
        boolean ok = el.runLoop(src);
        assertFalse(ok);
        // 说明: runLoop 返回 false 即降级; onDegraded 由 start() 的线程调用（此处验证 runLoop 语义）
    }

    @Test public void terminalAndProgressEventsForwarded() {
        // 验证 parseDataEvent + 终态转发组合: 一条 progress + 一条 done → 收到事件
        AtomicInteger events = new AtomicInteger();
        HermesEventListener.Listener listener = new HermesEventListener.Listener() {
            @Override public void onEvent(String taskId, String kind, String data) { events.incrementAndGet(); }
            @Override public void onDegraded() {}
        };
        HermesEventListener.StreamSource src = () -> {
            // 模拟两条 data 行
            JSONObject p = HermesEventListener.parseDataEvent(
                    "data: {\"task_id\":\"t1\",\"kind\":\"progress\",\"data\":\"进展\"}");
            if (p != null) listener.onEvent("t1", p.optString("kind"), p.optString("data", ""));
            JSONObject d = HermesEventListener.parseDataEvent(
                    "data: {\"task_id\":\"t1\",\"kind\":\"done\",\"data\":\"完成\"}");
            if (d != null) listener.onEvent("t1", d.optString("kind"), d.optString("data", ""));
            return true;   // 终态结束
        };
        HermesEventListener el = new HermesEventListener("http://x", "t", "id", listener, src);
        assertTrue(el.runLoop(src));
        assertEquals("progress+done 两条事件", 2, events.get());
    }
}
