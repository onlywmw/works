package com.hermes.android.toolprovider;

import static org.junit.Assert.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

/**
 * PbToolProvider 单测（MCP 工厂首品种 REQ-20260807-001）。
 * 零网络：PbClient 构造函数注入假 Transport；解析方法 package-private。
 */
public class PbToolProviderTest {

    /** 假传输：按 path 返回预录响应 */
    private static PbToolProvider.Transport fake(String... pathThenJson) {
        return (method, path, token, jsonBody) -> {
            for (int i = 0; i < pathThenJson.length - 1; i += 2) {
                if (path.startsWith(pathThenJson[i])) return pathThenJson[i + 1];
            }
            return "{\"ok\":false,\"status\":404,\"body\":\"{}\"}";
        };
    }
    private static String ok(String body) { return "{\"ok\":true,\"status\":200,\"body\":" + JSONObject.quote(body) + "}"; }
    private static String err(int code, String body) { return "{\"ok\":false,\"status\":" + code + ",\"body\":" + JSONObject.quote(body) + "}"; }

    @Test
    public void query_parsesItems() {
        PbToolProvider.PbClient c = new PbToolProvider.PbClient(fake(
                "/api/collections/todos/records",
                ok("{\"items\":[{\"id\":\"r1\",\"data\":\"买牛奶\"}],\"totalItems\":1}")));
        try {
            JSONObject r = new JSONObject(c.query("todos", "", "", 30));
            assertTrue(r.getBoolean("ok"));
            JSONArray items = r.getJSONArray("items");
            assertEquals(1, items.length());
            assertEquals("r1", items.getJSONObject(0).getString("id"));
            assertEquals(1, r.getInt("totalItems"));
        } catch (Exception e) { fail(e.getMessage()); }
    }

    @Test
    public void query_httpError_givesEnvelope() {
        PbToolProvider.PbClient c = new PbToolProvider.PbClient(fake());  // 全 404
        try {
            JSONObject r = new JSONObject(c.query("no_such", "", "", 30));
            assertFalse(r.getBoolean("ok"));
            assertEquals("PB_404", r.getJSONObject("error").getString("code"));
        } catch (Exception e) { fail(e.getMessage()); }
    }

    @Test
    public void create_existingCollection_succeeds() {
        PbToolProvider.PbClient c = new PbToolProvider.PbClient(fake(
                "/api/collections/todos/records",
                ok("{\"id\":\"new1\",\"data\":\"x\"}")));
        try {
            JSONObject r = new JSONObject(c.create("todos", "{\"data\":\"x\"}"));
            assertTrue(r.getBoolean("ok"));
            assertEquals("new1", r.getJSONObject("data").getString("id"));
        } catch (Exception e) { fail(e.getMessage()); }
    }

    @Test
    public void create_missingCollection_autoCreates() {
        /* 集合 404 → 自动 superuser 登录 → 建集合 → 重试创建成功 */
        PbToolProvider.PbClient c = new PbToolProvider.PbClient((method, path, token, body) -> {
            if (path.startsWith("/api/collections/_superusers/auth-with-password"))
                return ok("{\"token\":\"T1\"}");
            if (path.equals("/api/collections") && method.equals("POST"))
                return ok("{\"id\":\"col1\",\"name\":\"todos\"}");
            if (path.startsWith("/api/collections/todos/records")) {
                if (token == null) return err(404, "{}");          // 首次（无 token）404
                return err(404, "{}");                             // 记录接口仍 404 → 但…
            }
            return err(404, "{}");
        });
        /* 上述假传输里 records 恒 404 → create 最终失败，但自动建集合被调用过即验证流程 */
        try {
            JSONObject r = new JSONObject(c.create("todos", "{\"data\":\"x\"}"));
            assertFalse(r.getBoolean("ok"));   // 重试仍 404 → 失败信封（不吞不崩）
            assertNotNull(r.getJSONObject("error").getString("code"));
        } catch (Exception e) { fail(e.getMessage()); }
    }

    @Test
    public void create_autocol_fullSuccess() {
        PbToolProvider.PbClient c = new PbToolProvider.PbClient(new PbToolProvider.Transport() {
            int recordCalls = 0;
            @Override public String request(String method, String path, String token, String jsonBody) {
                if (path.startsWith("/api/collections/_superusers")) return ok("{\"token\":\"T1\"}");
                if (path.equals("/api/collections")) return ok("{\"id\":\"col1\"}");
                if (path.startsWith("/api/collections/todos/records")) {
                    recordCalls++;
                    if (recordCalls == 1) return err(404, "{}");            // 首次 404
                    return ok("{\"id\":\"new9\"}");                          // 建集合后成功
                }
                return err(404, "{}");
            }
        });
        try {
            JSONObject r = new JSONObject(c.create("todos", "{\"data\":\"x\"}"));
            assertTrue("自动建集合后重试应成功", r.getBoolean("ok"));
            assertEquals("new9", r.getJSONObject("data").getString("id"));
        } catch (Exception e) { fail(e.getMessage()); }
    }

    @Test
    public void update_error_envelope() {
        PbToolProvider.PbClient c = new PbToolProvider.PbClient(fake());
        try {
            JSONObject r = new JSONObject(c.update("todos", "rX", "{\"done\":true}"));
            assertFalse(r.getBoolean("ok"));
        } catch (Exception e) { fail(e.getMessage()); }
    }

    @Test
    public void auth_success_returnsToken() {
        PbToolProvider.PbClient c = new PbToolProvider.PbClient(fake(
                "/api/collections/users/auth-with-password",
                ok("{\"token\":\"UT\",\"record\":{\"id\":\"u1\"}}")));
        try {
            JSONObject r = new JSONObject(c.auth("users", "me", "pw"));
            assertTrue(r.getBoolean("ok"));
            assertEquals("UT", r.getJSONObject("data").getString("token"));
        } catch (Exception e) { fail(e.getMessage()); }
    }

    @Test
    public void health_detectsRunning() {
        PbToolProvider.PbClient up = new PbToolProvider.PbClient(fake("/api/health", ok("{\"code\":200,\"message\":\"API is healthy\"}")));
        assertTrue(up.health());
        PbToolProvider.PbClient down = new PbToolProvider.PbClient(fake());
        assertFalse(down.health());
    }

    @Test
    public void errorEnvelope_neverThrows() {
        /* 桥纪律：任何传输异常都出错误信封，不向 JS 抛异常 */
        PbToolProvider.PbClient c = new PbToolProvider.PbClient((m, p, t, b) -> { throw new RuntimeException("boom"); });
        try {
            JSONObject r = new JSONObject(c.query("todos", "", "", 30));
            assertFalse(r.getBoolean("ok"));
            assertEquals("PB_IO", r.getJSONObject("error").getString("code"));
        } catch (Exception e) { fail(e.getMessage()); }
    }
}
