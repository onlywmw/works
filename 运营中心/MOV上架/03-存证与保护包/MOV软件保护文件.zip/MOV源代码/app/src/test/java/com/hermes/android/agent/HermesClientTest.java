package com.hermes.android.agent;

import org.json.JSONObject;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * HermesClient 纯 JVM 核心单测（P2 M2）——照 LlamaClient 模式：
 * payload 构造 / task_id 解析 / 状态解析 / 错误映射 / token 生成。
 * 不碰网络（serve HTTP 属真机验收；此处只测纯函数）。
 */
public class HermesClientTest {

    // ==================== payload 构造 ====================

    @Test public void buildTaskPayload_includesInstructionAndConstraints() throws Exception {
        String body = HermesClient.buildTaskPayload("整理病历", false, 120, 4000);
        JSONObject o = new JSONObject(body);
        assertEquals("instruction 透传", "整理病历", o.getString("instruction"));
        JSONObject c = o.getJSONObject("constraints");
        assertFalse("禁网默认 false（network=false）", c.getBoolean("network"));
        assertEquals(120, c.getInt("timeoutSec"));
        assertEquals(4000, c.getInt("maxTokens"));
    }

    @Test public void buildTaskPayload_defaultsForNonPositive() throws Exception {
        JSONObject o = new JSONObject(HermesClient.buildTaskPayload("x", true, 0, 0));
        JSONObject c = o.getJSONObject("constraints");
        assertEquals("timeoutSec 缺省 120", 120, c.getInt("timeoutSec"));
        assertEquals("maxTokens 缺省 8000", 8000, c.getInt("maxTokens"));
        assertTrue("network=true 透传", c.getBoolean("network"));
    }

    // ==================== task_id 解析 ====================

    @Test public void parseTaskId_ok() {
        assertEquals("abc123", HermesClient.parseTaskId("{\"task_id\":\"abc123\"}"));
    }

    @Test public void parseTaskId_nullOnMissing() {
        assertNull(HermesClient.parseTaskId("{}"));
        assertNull(HermesClient.parseTaskId(null));
        assertNull(HermesClient.parseTaskId("not-json"));
    }

    // ==================== 状态解析 ====================

    @Test public void parseTaskStatus_done() {
        HermesClient.TaskResult r = HermesClient.parseTaskStatus(
                "{\"task_id\":\"t1\",\"status\":\"done\",\"output\":\"结果\"}");
        assertEquals(HermesClient.STATUS_DONE, r.status);
        assertEquals("结果", r.output);
        assertTrue("done 是终态", r.isTerminal());
    }

    @Test public void parseTaskStatus_failed() {
        HermesClient.TaskResult r = HermesClient.parseTaskStatus(
                "{\"task_id\":\"t1\",\"status\":\"failed\",\"error\":\"超时\"}");
        assertEquals(HermesClient.STATUS_FAILED, r.status);
        assertEquals("超时", r.error);
        assertTrue(r.isTerminal());
    }

    @Test public void parseTaskStatus_running_notTerminal() {
        HermesClient.TaskResult r = HermesClient.parseTaskStatus(
                "{\"task_id\":\"t1\",\"status\":\"running\"}");
        assertEquals(HermesClient.STATUS_RUNNING, r.status);
        assertFalse("running 非终态", r.isTerminal());
    }

    @Test public void parseTaskStatus_invalidJson_fallsBackToFailed() {
        HermesClient.TaskResult r = HermesClient.parseTaskStatus("garbage");
        assertEquals(HermesClient.STATUS_FAILED, r.status);
        assertNotNull(r.error);
        assertTrue(r.isTerminal());
    }

    // ==================== 错误映射 ====================

    @Test public void mapError_codes() {
        assertTrue(HermesClient.mapError(0, "").contains("未启动"));
        assertTrue(HermesClient.mapError(401, "").contains("token"));
        assertTrue(HermesClient.mapError(409, "").contains("串行"));
        assertTrue(HermesClient.mapError(404, "").contains("不存在"));
        assertTrue(HermesClient.mapError(500, "").contains("异常"));
    }

    // ==================== token 生成 ====================

    @Test public void tokenUrlSafe_isUrlsafeUnique() {
        String t1 = HermesClient.tokenUrlSafe();
        String t2 = HermesClient.tokenUrlSafe();
        assertNotEquals("两次生成不同", t1, t2);
        assertEquals("无 padding（= 不允许进 header）", -1, t1.indexOf('='));
        assertTrue("只含 urlsafe 字符", t1.matches("[A-Za-z0-9_-]+"));
        assertTrue("足够长", t1.length() >= 32);
    }

    // ==================== 阶段3 A2: invokeTool 信封 ====================

    @Test public void buildInvokePayload_wrapsParams() throws Exception {
        JSONObject params = new JSONObject().put("cmd", "echo hi");
        JSONObject o = new JSONObject(HermesClient.buildInvokePayload(params));
        assertEquals("echo hi", o.getJSONObject("params").getString("cmd"));
    }

    @Test public void buildInvokePayload_nullParams_ok() throws Exception {
        JSONObject o = new JSONObject(HermesClient.buildInvokePayload(null));
        assertTrue("null params 兜底空对象", o.has("params"));
    }

    @Test public void parseInvokeResult_success() throws Exception {
        String body = "{\"ok\":true,\"data\":{\"text\":\"命令完成\",\"aiFeedback\":\"exit=0\"}}";
        HermesClient.InvokeResult r = HermesClient.parseInvokeResult(body);
        assertTrue(r.ok);
        assertEquals("命令完成", r.data.optString("text"));
        assertNull(r.errorCode);
    }

    @Test public void parseInvokeResult_failure_codeMsg() throws Exception {
        String body = "{\"ok\":false,\"error\":{\"code\":\"TOOL_FAILED\",\"msg\":\"exit=1\"}}";
        HermesClient.InvokeResult r = HermesClient.parseInvokeResult(body);
        assertFalse(r.ok);
        assertEquals("TOOL_FAILED", r.errorCode);
        assertEquals("exit=1", r.errorMsg);
    }

    @Test public void parseInvokeResult_nullBody() {
        HermesClient.InvokeResult r = HermesClient.parseInvokeResult(null);
        assertFalse(r.ok);
        assertEquals("EMPTY", r.errorCode);
    }

    @Test public void parseInvokeResult_garbageBody() {
        HermesClient.InvokeResult r = HermesClient.parseInvokeResult("not json");
        assertFalse(r.ok);
        assertEquals("PARSE", r.errorCode);
    }
}
