package com.hermes.android.scene;

import org.json.JSONObject;
import org.junit.Test;
import static org.junit.Assert.*;

import java.io.File;

/**
 * WatchBridge 单测 — JSON report 解析/覆盖更新/时间格式化。
 */
public class WatchBridgeTest {

    @Test public void testReportParsesJSON() throws Exception {
        String json = "{\"title\":\"凡人修仙传\",\"episode\":12,\"positionMs\":30500,\"url\":\"https://example.com/play/12\"}";
        JSONObject r = new JSONObject(json);
        assertEquals("凡人修仙传", r.optString("title"));
        assertEquals(12, r.optInt("episode"));
        assertEquals(30500, r.optLong("positionMs"));
    }

    @Test public void testReportOverwriteSameTitle() throws Exception {
        File dir = File.createTempFile("mov_wh_test", "");
        dir.delete(); dir.mkdirs();
        WatchBridge wb = new WatchBridge(dir);
        wb.report("{\"title\":\"折金枝\",\"episode\":3,\"positionMs\":120000}");
        wb.report("{\"title\":\"折金枝\",\"episode\":4,\"positionMs\":45000}");
        // 同 title → 覆盖：episode=4（非 3），positionMs=45000（非 120000）
        java.util.Map<String, org.json.JSONObject> map = wb.load();
        org.json.JSONObject entry = map.get("折金枝");
        assertNotNull("折金枝 应存在", entry);
        assertEquals("覆盖后 episode=4", 4, entry.optInt("episode"));
        assertEquals("覆盖后 positionMs=45000", 45000, entry.optLong("positionMs"));
        new File(dir, "watch_history.json").delete();
        dir.delete();
    }

    @Test public void testDifferentTitlesDontConflict() throws Exception {
        File dir = File.createTempFile("mov_wh_test2", "");
        dir.delete(); dir.mkdirs();
        WatchBridge wb = new WatchBridge(dir);
        wb.report("{\"title\":\"凡人修仙传\",\"episode\":12,\"positionMs\":30000}");
        wb.report("{\"title\":\"折金枝\",\"episode\":5,\"positionMs\":120000}");
        java.util.Map<String, org.json.JSONObject> map = wb.load();
        assertEquals("两条记录", 2, map.size());
        assertEquals("凡人修仙传 ep=12", 12, map.get("凡人修仙传").optInt("episode"));
        assertEquals("折金枝 ep=5", 5, map.get("折金枝").optInt("episode"));
        new File(dir, "watch_history.json").delete();
        dir.delete();
    }

    @Test public void testPositionFormatting() {
        assertEquals("00:30", formatPositionTest(30500));
        assertEquals("02:00", formatPositionTest(120000));
        assertEquals("08:32", formatPositionTest(512000));
        assertEquals("", formatPositionTest(500));
        assertEquals("", formatPositionTest(0));
    }

    private String formatPositionTest(long ms) {
        if (ms < 1000) return "";
        int s = (int) (ms / 1000);
        int m = s / 60;
        int sec = s % 60;
        return String.format("%02d:%02d", m, sec);
    }
}
