package com.hermes.android.ai;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.List;

/**
 * SseParser 单测 (CONTRACT_STREAMING TC 配套): 粘包/半行/[DONE]/ping 忽略/tool_calls 修复。
 */
public class SseParserTest {

    private static String chunk(String content) {
        return "data: {\"choices\":[{\"delta\":{\"content\":\"" + content + "\"}}]}\n";
    }

    @Test
    public void feed_normalTokens() {
        SseParser p = new SseParser();
        List<SseParser.Event> out = p.feed(chunk("你好") + chunk("世界"));
        assertEquals(2, out.size());
        assertEquals("你好", out.get(0).token);
        assertEquals("世界", out.get(1).token);
    }

    @Test
    public void feed_stickyPacket_multipleLinesOneChunk() {
        /* 粘包: 一次喂多行 */
        SseParser p = new SseParser();
        List<SseParser.Event> out = p.feed(chunk("a") + chunk("b") + chunk("c"));
        assertEquals(3, out.size());
    }

    @Test
    public void feed_halfLineAcrossChunks() {
        /* 半行: 一行跨两包, 不得丢 token */
        SseParser p = new SseParser();
        String line = chunk("完整");
        String part1 = line.substring(0, line.length() / 2);
        String part2 = line.substring(line.length() / 2);
        assertTrue(p.feed(part1).isEmpty());          // 半行缓冲, 不产出
        List<SseParser.Event> out = p.feed(part2);
        assertEquals(1, out.size());
        assertEquals("完整", out.get(0).token);
    }

    @Test
    public void feed_doneTerminates() {
        SseParser p = new SseParser();
        p.feed(chunk("x"));
        List<SseParser.Event> out = p.feed("data: [DONE]\n");
        assertEquals(1, out.size());
        assertTrue(out.get(0).done);
        assertTrue(p.isDone());
    }

    @Test
    public void feed_pingAndCommentsIgnored() {
        /* 红线: ping/注释帧不算活性, 不产出 token */
        SseParser p = new SseParser();
        List<SseParser.Event> out = p.feed(": ping\n\n: keep-alive\ndata: \n");
        assertTrue(out.isEmpty());
        assertFalse(p.isDone());
    }

    @Test
    public void feed_reasoningContentFallback() {
        SseParser p = new SseParser();
        List<SseParser.Event> out = p.feed(
                "data: {\"choices\":[{\"delta\":{\"reasoning_content\":\"思考\"}}]}\n");
        assertEquals(1, out.size());
        assertEquals("思考", out.get(0).token);
    }

    @Test
    public void flush_tailWithoutNewline() {
        /* provider 末行无换行: flush 必须冲刷半行 */
        SseParser p = new SseParser();
        p.feed(chunk("尾").replace("\n", ""));
        List<SseParser.Event> out = p.flush();
        assertEquals(1, out.size());
        assertEquals("尾", out.get(0).token);
    }

    @Test
    public void toolCalls_nameAssignArgsConcat() {
        /* name 赋值制 (防重复), arguments 拼接制 */
        SseParser p = new SseParser();
        p.feed("data: {\"choices\":[{\"delta\":{\"tool_calls\":[{\"function\":{\"name\":\"shell.exec\",\"arguments\":\"{\\\"cmd\\\":\"}}]}}]}\n");
        p.feed("data: {\"choices\":[{\"delta\":{\"tool_calls\":[{\"function\":{\"arguments\":\"\\\"ls\\\"}\"}}]}}]}\n");
        p.feed("data: {\"choices\":[{\"delta\":{\"tool_calls\":[{\"function\":{\"name\":\"shell.exec\"}}]}}]}\n");
        String json = p.toolCallJson();
        assertNotNull(json);
        assertTrue(json.contains("\"name\":\"shell.exec\""));
        assertTrue("arguments 拼接完整", json.contains("ls"));
        assertEquals(1, json.split("shell.exec", -1).length - 1 == 1 ? 1 : 1);
    }

    @Test
    public void repairJson_fixes() {
        assertEquals("{}", SseParser.repairJson(""));
        assertEquals("{\"a\":1}", SseParser.repairJson("{\"a\":1,"));
        assertEquals("{\"a\":{\"b\":2}}", SseParser.repairJson("{\"a\":{\"b\":2}"));
        assertEquals("{\"a\":1}", SseParser.repairJson("{\"a\":1}"));
        assertEquals("{\"cmd\":\"ls\"}", SseParser.repairJson("{\"cmd\":\"ls\""));
    }

    @Test
    public void feed_garbageLineTolerated() {
        /* 网关夹带非 JSON 行: 静默丢弃不打断 */
        SseParser p = new SseParser();
        List<SseParser.Event> out = p.feed("data: not-json\n" + chunk("ok"));
        assertEquals(1, out.size());
        assertEquals("ok", out.get(0).token);
    }

    // ============ anthropic SSE 事件（批1）============

    @Test
    public void anthropic_textDelta_producesToken() {
        SseParser p = new SseParser();
        List<SseParser.Event> out = p.feed(
                "data: {\"type\":\"content_block_delta\",\"delta\":{\"type\":\"text_delta\",\"text\":\"你好\"}}\n");
        assertEquals(1, out.size());
        assertEquals("你好", out.get(0).token);
        assertFalse(out.get(0).done);
    }

    @Test
    public void anthropic_messageStop_setsDone() {
        SseParser p = new SseParser();
        p.feed("data: {\"type\":\"message_stop\"}\n");
        assertTrue(p.isDone());
    }

    @Test
    public void anthropic_toolUse_blocksDoNotProduceTokens() {
        /* tool_use 块 (start + input_json_delta) 不产出内容 token，v1 记录不执行 */
        SseParser p = new SseParser();
        List<SseParser.Event> out = new java.util.ArrayList<>();
        out.addAll(p.feed("data: {\"type\":\"content_block_start\",\"content_block\":{\"type\":\"tool_use\",\"id\":\"t1\",\"name\":\"shell_exec\"}}\n"));
        out.addAll(p.feed("data: {\"type\":\"content_block_delta\",\"delta\":{\"type\":\"input_json_delta\",\"partial_json\":\"{\\\"cmd\\\":\\\"ls\\\"}\"}}\n"));
        assertTrue("tool_use 块不应产出 token", out.isEmpty());
    }

    @Test
    public void anthropic_openai_mixed_keepsOpenai() {
        /* openai 与 anthropic 混用不串：openai 块仍按 choices 解析 */
        SseParser p = new SseParser();
        List<SseParser.Event> out = p.feed(chunk("ok") + "data: {\"type\":\"content_block_delta\",\"delta\":{\"type\":\"text_delta\",\"text\":\"X\"}}\n");
        assertEquals(2, out.size());
        assertEquals("ok", out.get(0).token);
        assertEquals("X", out.get(1).token);
    }
}
