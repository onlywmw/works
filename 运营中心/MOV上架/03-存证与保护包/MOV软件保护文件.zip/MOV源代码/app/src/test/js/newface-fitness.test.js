// newface-fitness.test.js — 工单12 幕三 健身卡纯逻辑（时间线排序/叙事解析）
const { test } = require('node:test');
const assert = require('node:assert');
const path = require('path');

global.window = {};
require(path.join(__dirname, '../../main/assets/js/newface-fitness.js'));
const NS = global.window.MovFitness;

test('timeline 时间倒序 + 过滤 verbatim', () => {
  const data = { data: { cover: [
    { mode: 'verbatim', ts: 100, text: '旧记录' },
    { mode: 'summary', ts: 999, text: '摘要' },
    { mode: 'verbatim', ts: 300, text: '新记录' },
  ]}};
  const items = NS.timeline(data);
  assert.equal(items.length, 2, '只保留 verbatim');
  assert.equal(items[0].text, '新记录', '时间倒序: 300 在前');
  assert.equal(items[1].text, '旧记录');
});

test('timeline 空 cover 返回空', () => {
  assert.deepEqual(NS.timeline({ data: { cover: [] } }), []);
  assert.deepEqual(NS.timeline({}), []);
});

test('narrative 解析非空行', () => {
  const resp = { data: { narrative: '趋势：良好\n\n异常：无\n建议：坚持' } };
  assert.deepEqual(NS.narrative(resp), ['趋势：良好', '异常：无', '建议：坚持']);
});

test('narrative 空/缺返回空数组', () => {
  assert.deepEqual(NS.narrative({ data: {} }), []);
  assert.deepEqual(NS.narrative({}), []);
});
