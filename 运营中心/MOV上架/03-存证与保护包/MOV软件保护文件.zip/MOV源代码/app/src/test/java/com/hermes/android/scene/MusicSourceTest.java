package com.hermes.android.scene;

import org.json.JSONObject;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.List;

/**
 * MusicSource 回归向量 — 零网络，5条真行为断言。
 */
public class MusicSourceTest {

    private static final String FIXTURE = "{\"result\":{\"songs\":["
        + "{\"id\":108998,\"name\":\"小苹果\",\"artists\":[{\"name\":\"筷子兄弟\"}],"
        + "\"album\":{\"name\":\"小苹果\"},\"fee\":8,\"duration\":238698},"
        + "{\"id\":186056,\"name\":\"七里香\",\"artists\":[{\"name\":\"周杰伦\"}],"
        + "\"album\":{\"name\":\"七里香\"},\"fee\":1,\"duration\":299000}"
        + "]}}";

    @Test public void testParseSongs() throws Exception {
        MusicSource ms = new MusicSource();
        List<MusicSource.Song> songs = ms.parseSongs(new JSONObject(FIXTURE));
        assertEquals(2, songs.size());
        assertEquals("小苹果", songs.get(0).name);
        assertEquals("筷子兄弟", songs.get(0).artist);
        assertEquals(108998L, songs.get(0).id);
    }

    @Test public void testFeeZeroPlayable() throws Exception {
        MusicSource ms = new MusicSource();
        List<MusicSource.Song> songs = ms.parseSongs(new JSONObject(FIXTURE));
        assertTrue("fee=8应可播", songs.get(0).playable);
        assertFalse("fee=1应不可播", songs.get(1).playable);
    }

    @Test public void testDurationFormat() {
        assertEquals("3:58", MusicSource.Song.formatDuration(238698));
        assertEquals("4:59", MusicSource.Song.formatDuration(299000));
        assertEquals("0:00", MusicSource.Song.formatDuration(0));
    }

    @Test public void testEmptyResult() throws Exception {
        MusicSource ms = new MusicSource();
        List<MusicSource.Song> songs = ms.parseSongs(new JSONObject("{\"result\":{}}"));
        assertTrue("空result→空列表", songs.isEmpty());
        songs = ms.parseSongs(new JSONObject("{}"));
        assertTrue("无result→空列表", songs.isEmpty());
    }

    @Test public void testPlayUrl() {
        MusicSource.Song s = new MusicSource.Song(108998, "t", "a", "b", 0, 1000);
        assertTrue(s.playUrl().contains("108998.mp3"));
        assertTrue("可播", s.playable);
    }

    @Test public void testVipSongGreyed() {
        MusicSource.Song vip = new MusicSource.Song(186056, "七里香", "周杰伦", "七里香", 1, 299000);
        assertFalse("VIP歌 playable=false", vip.playable);
        MusicSource.Song ok = new MusicSource.Song(108998, "小苹果", "a", "b", 8, 238698);
        assertTrue("fee=8可播", ok.playable);
    }
}
