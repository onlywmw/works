package com.hermes.android.llama;

import org.json.JSONObject;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/**
 * M1 语义召回：EmbeddingClient 纯 JVM 单测（零网络）。
 * 验收见 docs/PLAN_SEMANTIC_RECALL_2026-08-09.md §七 M1。
 */
public class EmbeddingClientTest {

    @Test
    public void buildEmbeddingPayload_defaultModel_inputArray() throws Exception {
        String raw = EmbeddingClient.buildEmbeddingPayload(null, Arrays.asList("凌晨三点才睡", "睡眠不足"));
        assertNotNull(raw);
        JSONObject o = new JSONObject(raw);
        assertEquals("bge-small-zh-v1.5", o.getString("model"));
        assertEquals(2, o.getJSONArray("input").length());
        assertEquals("凌晨三点才睡", o.getJSONArray("input").getString(0));
        assertEquals("睡眠不足", o.getJSONArray("input").getString(1));
    }

    @Test
    public void buildEmbeddingPayload_customModel() throws Exception {
        String raw = EmbeddingClient.buildEmbeddingPayload("my-model", Arrays.asList("x"));
        assertEquals("my-model", new JSONObject(raw).getString("model"));
    }

    @Test
    public void buildEmbeddingPayload_nullOrEmptyInput_returnsNull() {
        assertNull(EmbeddingClient.buildEmbeddingPayload(null, null));
        assertNull(EmbeddingClient.buildEmbeddingPayload(null, Arrays.asList()));
    }

    @Test
    public void buildEmbeddingPayload_nullElement_blankString() throws Exception {
        String raw = EmbeddingClient.buildEmbeddingPayload(null, Arrays.asList("a", null));
        assertEquals("", new JSONObject(raw).getJSONArray("input").getString(1));
    }

    @Test
    public void parseResponse_multiEmbedding_byIndex() {
        String raw = "{\"data\":["
                + "{\"object\":\"embedding\",\"index\":0,\"embedding\":[1.0,2.0]},"
                + "{\"object\":\"embedding\",\"index\":1,\"embedding\":[3.0,4.0,5.0]}]}";
        float[][] v = EmbeddingClient.parseResponse(raw);
        assertNotNull(v);
        assertEquals(2, v.length);
        assertEquals(2, v[0].length);
        assertEquals(1.0f, v[0][0], 1e-6);
        assertEquals(2.0f, v[0][1], 1e-6);
        assertEquals(3, v[1].length);
        assertEquals(5.0f, v[1][2], 1e-6);
    }

    @Test
    public void parseResponse_outOfOrderIndex_placesCorrectly() {
        // index 乱序也应落到对应槽位（契约按 index，llama.cpp 正常有序，防御乱序）
        String raw = "{\"data\":["
                + "{\"object\":\"embedding\",\"index\":1,\"embedding\":[9.0]},"
                + "{\"object\":\"embedding\",\"index\":0,\"embedding\":[7.0]}]}";
        float[][] v = EmbeddingClient.parseResponse(raw);
        assertEquals(7.0f, v[0][0], 1e-6);
        assertEquals(9.0f, v[1][0], 1e-6);
    }

    @Test
    public void parseResponse_badInput_returnsNull() {
        assertNull(EmbeddingClient.parseResponse(null));
        assertNull(EmbeddingClient.parseResponse("not json"));
        assertNull(EmbeddingClient.parseResponse("{\"data\":[]}"));
        assertNull(EmbeddingClient.parseResponse("{\"data\":[{\"index\":0}]}")); // 缺 embedding 字段
    }

    @Test
    public void cosine_same_orthogonal_opposite() {
        assertEquals(1.0, EmbeddingClient.cosine(new float[]{1, 0}, new float[]{1, 0}), 1e-9);
        assertEquals(0.0, EmbeddingClient.cosine(new float[]{1, 0}, new float[]{0, 1}), 1e-9);
        assertEquals(-1.0, EmbeddingClient.cosine(new float[]{1, 0}, new float[]{-1, 0}), 1e-9);
        assertEquals(Math.sqrt(0.5), EmbeddingClient.cosine(new float[]{1, 1}, new float[]{1, 0}), 1e-9);
    }

    @Test
    public void cosine_zeroVectorOrDimMismatch_returnsZero() {
        assertEquals(0.0, EmbeddingClient.cosine(new float[]{0, 0}, new float[]{1, 0}), 1e-9);
        assertEquals(0.0, EmbeddingClient.cosine(new float[]{1}, new float[]{1, 0}), 1e-9);
        assertEquals(0.0, EmbeddingClient.cosine(null, new float[]{1, 0}), 1e-9);
        assertEquals(0.0, EmbeddingClient.cosine(new float[]{1, 0}, null), 1e-9);
    }

    @Test
    public void mapError_allBranches() {
        assertTrue(EmbeddingClient.mapError(0, "").contains("未启动"));
        assertTrue(EmbeddingClient.mapError(401, "").contains("鉴权"));
        assertTrue(EmbeddingClient.mapError(403, "").contains("鉴权"));
        assertTrue(EmbeddingClient.mapError(500, "").contains("异常"));
        assertTrue(EmbeddingClient.mapError(400, "").contains("400"));
        assertTrue(EmbeddingClient.mapError(429, "").contains("429"));
    }
}
