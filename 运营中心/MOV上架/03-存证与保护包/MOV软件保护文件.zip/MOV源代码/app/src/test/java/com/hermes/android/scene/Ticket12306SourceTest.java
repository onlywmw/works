package com.hermes.android.scene;

import static org.junit.Assert.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * Ticket12306Source 单测 — 解析引擎纯逻辑，零网络。
 *
 * fixture 用真实 12306 竖线串格式（TrainSourceTest 已有同类，这里对齐权威 TicketDataKeys 索引）。
 */
public class Ticket12306SourceTest {

    // ══════════ 竖线串解析 ══════════

    /** 构造一条 57 字段竖线串。返回 URL 编码后的完整串。 */
    private static String pipeTicket(String trainNo, String code, String from, String to,
                                     String start, String arrive, String lishi,
                                     String ypInfoNew, String seatDiscount, String dwFlag) {
        String[] f = new String[57];
        for (int i = 0; i < 57; i++) f[i] = "x";
        f[0] = "secret"; f[1] = "预订";
        f[2] = trainNo;           // IDX_TRAIN_NO=2
        f[3] = code;              // IDX_TRAIN_CODE=3
        f[4] = from; f[5] = "SHH";
        f[6] = from; f[7] = to;   // IDX_FROM/TO_TELECODE=6/7
        f[8] = start;             // IDX_START_TIME=8
        f[9] = arrive;            // IDX_ARRIVE_TIME=9
        f[10] = lishi;            // IDX_LISHI=10
        f[12] = "yyyyyp";
        f[13] = "20260815";       // IDX_START_DATE=13 (yyyyMMdd)
        f[20] = "0"; f[21] = "0"; f[22] = "0"; f[23] = "0"; f[24] = "0"; f[25] = "0";
        f[26] = "无"; f[27] = "0"; f[28] = "0"; f[29] = "0";
        f[30] = "20"; f[31] = "10"; f[32] = "5"; f[33] = "0";  // ze_num=30 zy_num=31 swz_num=32
        f[39] = ypInfoNew;        // IDX_YP_INFO_NEW=39
        f[46] = dwFlag;           // IDX_DW_FLAG=46
        f[54] = seatDiscount;     // IDX_SEAT_DISCOUNT=54
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 57; i++) {
            if (i > 0) sb.append("|");
            sb.append(f[i]);
        }
        return java.net.URLEncoder.encode(sb.toString(), java.nio.charset.StandardCharsets.UTF_8);
    }

    /** 构造 data.map：telecode → 中文站名。 */
    private static JSONObject mapOf(String... pairs) throws Exception {
        JSONObject map = new JSONObject();
        for (int i = 0; i + 1 < pairs.length; i += 2) map.put(pairs[i], pairs[i + 1]);
        return map;
    }

    @Test public void parseTicketsData_indexesAlign() throws Exception {
        // 票价段：商务座9 价格 850.0("08500"/10) + 一等座M 价格 448.5("04485"/10)
        String yp = "9085000000M044850000";  // 商务座 [0..9] + 一等座 [10..19]
        String seatDisc = "900050000";          // 商务座 折扣50 + 一等座 折扣(5)
        String raw = pipeTicket("76000G10300", "G103", "BJP", "SHH",
                "08:35", "10:55", "02:20", yp, seatDisc, "5#1#Q###");
        JSONArray result = new JSONArray().put(raw);
        List<Ticket12306Source.TicketData> data = Ticket12306Source.parseTicketsData(result);
        assertEquals(1, data.size());
        Ticket12306Source.TicketData td = data.get(0);
        assertEquals("车次[3]", "G103", td.get(Ticket12306Source.IDX_TRAIN_CODE));
        assertEquals("发时[8]", "08:35", td.get(Ticket12306Source.IDX_START_TIME));
        assertEquals("到时[9]", "10:55", td.get(Ticket12306Source.IDX_ARRIVE_TIME));
        assertEquals("历时[10]", "02:20", td.get(Ticket12306Source.IDX_LISHI));
        assertEquals("yp_info_new[39]", yp, td.get(Ticket12306Source.IDX_YP_INFO_NEW));
        assertEquals("dw_flag[46]", "5#1#Q###", td.get(Ticket12306Source.IDX_DW_FLAG));
        assertEquals("seat_discount[54]", seatDisc, td.get(Ticket12306Source.IDX_SEAT_DISCOUNT));
        assertEquals("train_no[2]", "76000G10300", td.get(Ticket12306Source.IDX_TRAIN_NO));
        assertEquals("start_date[13]", "20260815", td.get(Ticket12306Source.IDX_START_DATE));
    }

    @Test public void parseTicketsInfo_mapToChineseNames() throws Exception {
        String yp = "9085000000M044850000";
        String raw = pipeTicket("76000G10300", "G103", "BJP", "SHH",
                "08:35", "10:55", "02:20", yp, "900050000", "5#1#Q###");
        JSONArray result = new JSONArray().put(raw);
        List<Ticket12306Source.TicketData> data = Ticket12306Source.parseTicketsData(result);
        JSONObject map = mapOf("BJP", "北京", "SHH", "上海");
        List<Ticket12306Source.TicketInfo> infos = Ticket12306Source.parseTicketsInfo(data, map);
        assertEquals(1, infos.size());
        Ticket12306Source.TicketInfo t = infos.get(0);
        assertEquals("出发站中文", "北京", t.fromStation);
        assertEquals("到达站中文", "上海", t.toStation);
        assertEquals("车次", "G103", t.startTrainCode);
        assertEquals("出发日期 yyyy-MM-dd", "2026-08-15", t.startDate);
        assertEquals("到达日期（同日不跨天）", "2026-08-15", t.arriveDate);
        assertEquals(2, t.prices.size());
        assertEquals("商务座", t.prices.get(0).seatName);
        assertEquals(850.0, t.prices.get(0).price, 0.01);
        assertEquals("一等座", t.prices.get(1).seatName);
        assertEquals(448.5, t.prices.get(1).price, 0.01);
        // dw_flag 解析
        assertTrue("复兴号", t.dwFlags.contains("复兴号"));
        assertTrue("智能动车组", t.dwFlags.contains("智能动车组"));
        assertTrue("静音车厢", t.dwFlags.contains("静音车厢"));
    }

    @Test public void parseTicketsInfo_arriveNextDay() throws Exception {
        // 历时 10 小时跨天
        String yp = "9085000000";
        String raw = pipeTicket("76000G10300", "G103", "BJP", "SHH",
                "20:35", "06:55", "10:20", yp, "", "5#1#Q###");
        JSONArray result = new JSONArray().put(raw);
        List<Ticket12306Source.TicketInfo> infos =
            Ticket12306Source.parseTicketsInfo(Ticket12306Source.parseTicketsData(result), mapOf());
        assertEquals("跨天到达次日", "2026-08-16", infos.get(0).arriveDate);
    }

    @Test public void extractPrices_unknownCodeAndWz() {
        // W 无座：价格段 [6:10]>=3000 → 无座
        // H 其他：未知席别码
        List<Ticket12306Source.Price> prices =
            Ticket12306Source.extractPrices("9095003000Z000100000", "", new String[57]);
        // 第一条：价格段 [6:10]=3000 ≥3000 → W(无座)，价格 "09500"/10=950.0
        // 第二条：未知席别码 Z → H(其他)，价格 "00010"/10=1.0
        assertEquals(2, prices.size());
        assertEquals("无座", prices.get(0).seatName);
        assertEquals(950.0, prices.get(0).price, 0.01);
        assertEquals("其他", prices.get(1).seatName);
        assertEquals(1.0, prices.get(1).price, 0.01);
    }

    // ══════════ 过滤 / 排序 / 限量 ══════════

    private static Ticket12306Source.TicketInfo info(String code, String startTime, String arriveTime, String lishi) {
        List<Ticket12306Source.Price> prices = new ArrayList<>();
        return new Ticket12306Source.TicketInfo(
            "76000" + code, code, "2026-08-15", startTime,
            "2026-08-15", arriveTime, lishi,
            "北京", "上海", "BJP", "SHH", prices, new ArrayList<>());
    }

    @Test public void filter_flagsOrSemantics() {
        List<Ticket12306Source.TicketInfo> in = new ArrayList<>();
        in.add(info("G103", "08:00", "10:00", "02:00"));
        in.add(info("D123", "09:00", "12:00", "03:00"));
        in.add(info("K555", "10:00", "15:00", "05:00"));
        Ticket12306Source.QueryOptions o = new Ticket12306Source.QueryOptions();
        o.trainFilterFlags = "GD";  // G 或 D → 前两条
        List<Ticket12306Source.TicketInfo> out = Ticket12306Source.filterTicketsInfo(in, o);
        assertEquals(2, out.size());
        assertEquals("G103", out.get(0).startTrainCode);
        assertEquals("D123", out.get(1).startTrainCode);
    }

    @Test public void filter_timeWindow() {
        List<Ticket12306Source.TicketInfo> in = new ArrayList<>();
        in.add(info("G103", "08:00", "10:00", "02:00"));
        in.add(info("G104", "13:00", "15:00", "02:00"));
        in.add(info("G105", "20:00", "22:00", "02:00"));
        Ticket12306Source.QueryOptions o = new Ticket12306Source.QueryOptions();
        o.earliestStartTime = 8; o.latestStartTime = 14;
        List<Ticket12306Source.TicketInfo> out = Ticket12306Source.filterTicketsInfo(in, o);
        assertEquals("8<=h<14", 2, out.size());
        assertEquals("G103", out.get(0).startTrainCode);
        assertEquals("G104", out.get(1).startTrainCode);
    }

    @Test public void filter_sortAndLimit() {
        List<Ticket12306Source.TicketInfo> in = new ArrayList<>();
        in.add(info("G103", "08:00", "10:00", "02:00"));
        in.add(info("G104", "06:00", "12:00", "06:00"));
        in.add(info("G105", "07:00", "09:00", "02:00"));
        Ticket12306Source.QueryOptions o = new Ticket12306Source.QueryOptions();
        o.sortFlag = "duration"; o.limitedNum = 2;
        List<Ticket12306Source.TicketInfo> out = Ticket12306Source.filterTicketsInfo(in, o);
        assertEquals(2, out.size());
        assertEquals("历时最短在前", "G103", out.get(0).startTrainCode);
        assertEquals("G105", out.get(1).startTrainCode);
    }

    @Test public void filter_sortReverse() {
        List<Ticket12306Source.TicketInfo> in = new ArrayList<>();
        in.add(info("G103", "08:00", "10:00", "02:00"));
        in.add(info("G104", "06:00", "09:00", "02:00"));
        Ticket12306Source.QueryOptions o = new Ticket12306Source.QueryOptions();
        o.sortFlag = "startTime"; o.sortReverse = true;
        List<Ticket12306Source.TicketInfo> out = Ticket12306Source.filterTicketsInfo(in, o);
        assertEquals("逆向：晚发在前", "G103", out.get(0).startTrainCode);
    }

    @Test public void filter_flagO_others() {
        List<Ticket12306Source.TicketInfo> in = new ArrayList<>();
        in.add(info("G103", "08:00", "10:00", "02:00"));
        in.add(info("Y801", "09:00", "12:00", "03:00"));
        Ticket12306Source.QueryOptions o = new Ticket12306Source.QueryOptions();
        o.trainFilterFlags = "O";
        List<Ticket12306Source.TicketInfo> out = Ticket12306Source.filterTicketsInfo(in, o);
        assertEquals("O=其他（非G/D/Z/T/K）", 1, out.size());
        assertEquals("Y801", out.get(0).startTrainCode);
    }

    // ══════════ 格式化 ══════════

    @Test public void formatText_stable() {
        List<Ticket12306Source.TicketInfo> in = new ArrayList<>();
        in.add(info("G103", "08:00", "10:00", "02:00"));
        String text = Ticket12306Source.formatText(in);
        assertTrue(text.contains("车次|出发站 -> 到达站"));
        assertTrue(text.contains("G103 北京(telecode:BJP) -> 上海(telecode:SHH)"));
    }

    @Test public void formatCsv_header() {
        List<Ticket12306Source.TicketInfo> in = new ArrayList<>();
        in.add(info("G103", "08:00", "10:00", "02:00"));
        String csv = Ticket12306Source.formatCsv(in);
        assertTrue(csv.startsWith("车次,出发站,到达站"));
        assertTrue(csv.contains("G103"));
    }

    @Test public void formatJson_keys() throws Exception {
        List<Ticket12306Source.TicketInfo> in = new ArrayList<>();
        in.add(info("G103", "08:00", "10:00", "02:00"));
        JSONArray arr = Ticket12306Source.formatJson(in);
        JSONObject o = arr.getJSONObject(0);
        assertTrue(o.has("train_no"));
        assertTrue(o.has("start_train_code"));
        assertTrue(o.has("prices"));
        assertTrue(o.has("from_station"));
    }

    @Test public void format_empty() {
        assertEquals("没有查询到相关车次信息", Ticket12306Source.formatText(new ArrayList<>()));
    }

    // ══════════ 日期 ══════════

    @Test public void checkDate_rejectsPast() {
        assertFalse("昨天被拒", Ticket12306Source.checkDate(java.time.LocalDate.now().minusDays(1).toString()));
        assertTrue("今天通过", Ticket12306Source.checkDate(java.time.LocalDate.now().toString()));
        assertTrue("明天通过", Ticket12306Source.checkDate(java.time.LocalDate.now().plusDays(1).toString()));
        assertFalse("非法格式", Ticket12306Source.checkDate("2026/08/15"));
    }

    @Test public void currentDateShanghai_format() {
        assertTrue(Ticket12306Source.currentDateShanghai().matches("\\d{4}-\\d{2}-\\d{2}"));
    }

    // ══════════ 历时归一化 ══════════

    @Test public void extractLishi_variants() {
        assertEquals("1小时30分钟 → 01:30", "01:30", Ticket12306Source.extractLishi("1小时30分钟"));
        assertEquals("45分钟 → 00:45", "00:45", Ticket12306Source.extractLishi("45分钟"));
        assertEquals("空 → 00:00", "00:00", Ticket12306Source.extractLishi(null));
    }

    // ══════════ 经停站解析 ══════════

    @Test public void parseRouteStationsInfo_firstHasClass() throws Exception {
        JSONArray arr = new JSONArray();
        arr.put(new JSONObject()
            .put("station_name", "北京南").put("station_train_code", "G103")
            .put("arrive_time", "----").put("start_time", "08:00")
            .put("running_time", "00:00").put("arrive_day_str", "当日到达")
            .put("train_class_name", "G").put("service_type", "1").put("end_station_name", "上海虹桥"));
        arr.put(new JSONObject()
            .put("station_name", "济南西").put("station_train_code", "G103")
            .put("arrive_time", "09:30").put("start_time", "09:32")
            .put("running_time", "01:32").put("arrive_day_str", "当日到达"));
        List<Ticket12306Source.RouteStationInfo> infos = Ticket12306Source.parseRouteStationsInfo(arr);
        assertEquals(2, infos.size());
        assertEquals("首站带车次类别", "G", infos.get(0).trainClassName);
        assertEquals("济南西", infos.get(1).stationName);
        assertEquals("有空调", "有空调", "1".equals(infos.get(0).serviceType) ? "有空调" : "无空调");
    }

    // ══════════ 中转解析 ══════════

    @Test public void parseInterlinesInfo_basic() throws Exception {
        List<Ticket12306Source.InterlineTicketData> fullList = new ArrayList<>();
        JSONObject ft = new JSONObject()
            .put("train_no", "76000G101").put("station_train_code", "G101")
            .put("start_train_date", "20260815").put("start_time", "08:00")
            .put("arrive_time", "09:30").put("lishi", "01:30")
            .put("from_station_name", "北京南").put("to_station_name", "南京南")
            .put("from_station_telecode", "VNP").put("to_station_telecode", "NKH")
            .put("yp_info", "985000000000").put("seat_discount_info", "").put("dw_flag", "");
        fullList.add(new Ticket12306Source.InterlineTicketData(ft));
        JSONObject o = new JSONObject()
            .put("all_lishi", "3小时45分钟").put("start_time", "08:00")
            .put("train_date", "2026-08-15").put("middle_date", "2026-08-15")
            .put("arrive_date", "2026-08-15").put("arrive_time", "12:00")
            .put("from_station_code", "VNP").put("from_station_name", "北京南")
            .put("middle_station_code", "NKH").put("middle_station_name", "南京南")
            .put("end_station_code", "SHH").put("end_station_name", "上海")
            .put("first_train_no", "76000G101").put("second_train_no", "76000G102")
            .put("wait_time", "00:30").put("train_count", 2)
            .put("same_station", "0").put("same_train", "Y");
        List<Ticket12306Source.InterlineData> data = new ArrayList<>();
        data.add(new Ticket12306Source.InterlineData(o, fullList));
        List<Ticket12306Source.InterlineInfo> infos = Ticket12306Source.parseInterlinesInfo(data);
        assertEquals(1, infos.size());
        Ticket12306Source.InterlineInfo info = infos.get(0);
        assertEquals("总历时 03:45", "03:45", info.lishi);
        assertEquals("同车换乘", true, info.sameTrain);
        assertEquals("G101", info.startTrainCode);
        assertEquals("北京南", info.fromName);
        assertEquals("上海", info.endName);
        assertEquals(1, info.ticketList.size());
        assertEquals("商务座", info.ticketList.get(0).prices.get(0).seatName);
    }

    @Test public void parseInterlinesInfo_emptyFullListSkipped() throws Exception {
        List<Ticket12306Source.InterlineData> data = new ArrayList<>();
        data.add(new Ticket12306Source.InterlineData(new JSONObject()
            .put("all_lishi", "1小时").put("start_time", "08:00")
            .put("train_date", "2026-08-15").put("middle_date", "2026-08-15")
            .put("arrive_date", "2026-08-15").put("arrive_time", "09:00")
            .put("from_station_name", "北京南").put("middle_station_name", "南京南")
            .put("end_station_name", "上海")
            .put("same_station", "0").put("same_train", "N"), new ArrayList<>()));
        List<Ticket12306Source.InterlineInfo> infos = Ticket12306Source.parseInterlinesInfo(data);
        assertEquals("空 fullList 跳过", 0, infos.size());
    }
}
