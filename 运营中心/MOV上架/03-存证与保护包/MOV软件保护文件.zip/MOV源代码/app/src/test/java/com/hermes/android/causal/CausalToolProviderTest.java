package com.hermes.android.causal;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.toolprovider.CausalToolProvider;

import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.nio.file.Files;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * CausalToolProvider 测试 — 元数据契约 + 注册表集成 + handler roundtrip（临时目录注入 engine）。
 */
public class CausalToolProviderTest {

    private File tmp;

    @Before public void setUp() throws Exception {
        tmp = Files.createTempDirectory("causal-provider-").toFile();
        CausalToolProvider.initForTest(tmp);
    }

    @After public void tearDown() throws Exception {
        deleteRecursive(tmp);
    }

    private void deleteRecursive(File f) {
        File[] all = f.listFiles();
        if (all != null) for (File c : all) deleteRecursive(c);
        f.delete();
    }

    private static AgentLoop.Tools emptyTools() {
        return new AgentLoop.Tools() {
            public String fileList(String roomId) { return ""; }
            public String fileRead(String roomId, String path) { return ""; }
            public String fileWrite(String roomId, String path, String content) { return ""; }
            public String capabilityOf(String text) { return ""; }
            public String deviceCmd(String text) { return ""; }
            public String packageApk(String roomId, String path, String appName) { return "{}"; }
            public String shellExec(String cmd, int timeoutSec) { return ""; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            public String filePush(String roomId, String path) { return "{}"; }
            public String filePull(String roomId, String name) { return "{}"; }
        };
    }

    private static ToolRegistry.Tool find(List<ToolRegistry.Tool> tools, String name) {
        for (ToolRegistry.Tool t : tools) if (t.name.equals(name)) return t;
        return null;
    }

    @Test public void discover_returns5CausalTools() {
        CausalToolProvider p = new CausalToolProvider();
        List<ToolRegistry.Tool> tools = p.discover();
        assertEquals("因果工具应为 6（含 causal.reflect）", 6, tools.size());
        for (ToolRegistry.Tool t : tools) {
            assertNotNull("manifest 非空", t.manifest);
            assertEquals("toolset 应为 memory: " + t.name, "memory", t.toolset);
            assertFalse("本地记忆 sync 应为 false: " + t.name, t.manifest.sync);
            assertTrue("因果引擎 SLOW 级别: " + t.name,
                    "SLOW".equals(t.manifest.level));
        }
    }

    @Test public void discover_namesAndAccessCorrect() {
        CausalToolProvider p = new CausalToolProvider();
        List<ToolRegistry.Tool> tools = p.discover();
        assertNotNull("含 causal.record", find(tools, "causal.record"));
        assertNotNull("含 causal.query", find(tools, "causal.query"));
        assertNotNull("含 causal.link", find(tools, "causal.link"));
        assertNotNull("含 causal.forget", find(tools, "causal.forget"));
        assertNotNull("含 causal.rule", find(tools, "causal.rule"));
        assertNotNull("含 causal.reflect（API 归因层）", find(tools, "causal.reflect"));
        assertEquals("record access write", "write", find(tools, "causal.record").access);
        assertEquals("query access readonly", "readonly", find(tools, "causal.query").access);
        assertNotNull("record 参数非空", find(tools, "causal.record").params);
    }

    @Test public void buildRegistryContainsCausalTools() {
        ToolRegistry r = ToolRegistry.build(emptyTools(), "room1", HashSet::new,
                new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
        assertNotNull("注册表含 causal.record", r.find("causal.record"));
        assertNotNull("注册表含 causal.query", r.find("causal.query"));
        assertNotNull("注册表含 causal.rule", r.find("causal.rule"));
    }

    @Test public void causalToolsVisibleWithParamsInCompactPrompt() {
        // 模型融合前提：compact 模式（默认）下 causal 工具进 ESSENTIAL_TOOLS → 完整文档（含参数）对模型可见
        ToolRegistry r = ToolRegistry.build(emptyTools(), "room1", HashSet::new,
                new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
        String prompt = r.promptText();
        assertTrue("causal.record 完整文档在 prompt", prompt.contains("causal.record"));
        assertTrue("causal.record 参数 subject 可见", prompt.contains("subject"));
        assertTrue("causal.record 参数 object 可见", prompt.contains("object"));
        assertTrue("causal.rule 完整文档在 prompt", prompt.contains("causal.rule"));
        assertTrue("causal.query 完整文档在 prompt", prompt.contains("causal.query"));
    }

    @Test public void recordHandlerRoundtrip() throws Exception {
        CausalToolProvider p = new CausalToolProvider();
        ToolRegistry.Tool record = find(p.discover(), "causal.record");
        ToolRegistry.Result r = record.handler.run(new JSONObject()
                .put("subject", "张三").put("predicate", "欠款").put("object", "李四")
                .put("meta", "{\"amount\":5000}"));
        assertTrue("记录成功: " + (r.ok ? "" : r.text), r.ok);
        assertNotNull("produced 携带结果 JSON", r.produced);

        ToolRegistry.Tool query = find(p.discover(), "causal.query");
        ToolRegistry.Result q = query.handler.run(new JSONObject());
        assertTrue("查询成功", q.ok);
        JSONObject qj = new JSONObject(q.produced);
        assertEquals("3 原子入索引", 3, qj.optInt("atomCount"));
        assertEquals("1 条事件", 1, qj.optInt("eventCount"));
    }

    @Test public void ruleViaHandlerTriggersOnRecord() throws Exception {
        CausalToolProvider p = new CausalToolProvider();
        ToolRegistry.Tool rule = find(p.discover(), "causal.rule");
        ToolRegistry.Result rr = rule.handler.run(new JSONObject()
                .put("ruleId", "r_debt")
                .put("op", "upsert")
                .put("label", "债务")
                .put("when", "{\"type\":\"cooccur\",\"atoms\":[\"张三\",\"李四\",\"欠款\"]}")
                .put("then", "{\"linkDelta\":0.3,\"alert\":\"债务需复核\"}"));
        assertTrue("规则注册成功: " + (rr.ok ? "" : rr.text), rr.ok);

        ToolRegistry.Tool record = find(p.discover(), "causal.record");
        ToolRegistry.Result r = record.handler.run(new JSONObject()
                .put("subject", "张三").put("predicate", "欠款").put("object", "李四"));
        assertTrue("记录成功", r.ok);
        JSONObject rj = new JSONObject(r.produced);
        assertEquals("命中规则 r_debt", "r_debt", rj.optJSONArray("fired").optString(0));
        assertEquals("alert 产出", "债务需复核",
                rj.optJSONArray("alerts").optJSONObject(0).optString("alert"));
    }

    @Test public void recordMissingSubjectFailsGracefully() throws Exception {
        CausalToolProvider p = new CausalToolProvider();
        ToolRegistry.Tool record = find(p.discover(), "causal.record");
        ToolRegistry.Result r = record.handler.run(new JSONObject()
                .put("subject", "").put("predicate", "欠款").put("object", "李四"));
        // 空主体记录：事件仍写入（空原子不索引），不崩溃
        assertTrue("空主体记录不崩溃", r.ok || !r.ok);
        assertNotNull("返回结果非空", r.text);
    }
}
