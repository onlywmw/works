package com.hermes.android.scene;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Ticket12306Stations 单测 — 站表解析纯逻辑，零网络。
 *
 * fixture 模拟真实 station_name.js 格式：`@code|站名|电报码|拼音|缩写|序号|二级码|城市|r1|r2|...`
 * 每 10 字段一组；city 在字段[7]。
 */
public class Ticket12306StationsTest {

    /** 真实格式 fixture：北京(主站) + 北京南 + 上海 + 上海虹桥。 */
    private static final String STATION_JS =
        "@BJP|北京|BJP|beijing|bj|0|beijing|北京|0|0|"
      + "@VNP|北京南|VNP|beijingnan|bjn|1|beijing|北京|0|0|"
      + "@SHH|上海|SHH|shanghai|sh|0|shanghai|上海|0|0|"
      + "@AOH|上海虹桥|AOH|shanghaihongqiao|shhq|1|shanghai|上海|0|0";

    @Test public void parse_chunkOf10_buildsFourTables() {
        Ticket12306Stations s = Ticket12306Stations.parse(STATION_JS);
        // byCode
        assertEquals("北京→BJP", "北京", s.byCode().get("BJP").name);
        assertEquals("北京南→VNP", "北京南", s.byCode().get("VNP").name);
        assertEquals("上海→SHH", "上海", s.byCode().get("SHH").name);
        assertEquals("上海虹桥→AOH", "上海虹桥", s.byCode().get("AOH").name);
        // byName
        assertEquals("byName 北京", "BJP", s.byName().get("北京").code);
        assertEquals("byName 北京南", "VNP", s.byName().get("北京南").code);
        // byCity：北京 2 站、上海 2 站
        assertEquals("北京 2 站", 2, s.byCity().get("北京").size());
        assertEquals("上海 2 站", 2, s.byCity().get("上海").size());
        // cityRep：station_name==city 的代表站
        assertEquals("北京代表站", "BJP", s.cityRep().get("北京").code);
        assertEquals("上海代表站", "SHH", s.cityRep().get("上海").code);
    }

    @Test public void parse_skipsEmptyCode() {
        // 第二条 code(字段2) 为空 → 跳过；有效 1 条 + 成都东补齐 = 2
        String js = "@BJP|北京|BJP|beijing|bj|0|beijing|北京|0|0|"
                  + "@X|无名||x|0|||0|0";  // 缺 code（字段2 空）
        Ticket12306Stations s = Ticket12306Stations.parse(js);
        assertEquals("跳过空 code（北京+成都东）", 2, s.byCode().size());
        assertNotNull("北京在", s.byCode().get("BJP"));
        assertNull("空 code 条不进表", s.byCode().get("@X"));
    }

    @Test public void parse_skipDuplicateCode() {
        String js = "@BJP|北京|BJP|beijing|bj|0|beijing|北京|0|0|"
                  + "@BJP|北京重复|BJP|beijing2|bj2|1|beijing|北京|0|0";
        Ticket12306Stations s = Ticket12306Stations.parse(js);
        assertEquals("重复 code 只留一个（北京+成都东）", 2, s.byCode().size());
        assertEquals("保留首个", "北京", s.byCode().get("BJP").name);
        assertNull("重复条不进表", s.byName().get("北京重复"));
    }

    @Test public void parse_missingStationPatched() {
        // 无成都东 → 自动补齐 WEI（code 修正）
        Ticket12306Stations s = Ticket12306Stations.parse(STATION_JS);
        assertNotNull("成都东应补齐", s.byCode().get("WEI"));
        assertEquals("成都东名", "成  都东", s.byCode().get("WEI").name);
        assertEquals("成都东城市", "成都", s.byCode().get("WEI").city);
        assertEquals("成都东加入 byCity", 1, s.byCity().get("成都").size());
    }

    @Test public void resolveCode_chineseName() {
        Ticket12306Stations s = Ticket12306Stations.parse(STATION_JS);
        assertEquals("北京", "BJP", s.resolveCode("北京"));
        assertEquals("北京南", "VNP", s.resolveCode("北京南"));
        assertEquals("上海虹桥", "AOH", s.resolveCode("上海虹桥"));
    }

    @Test public void resolveCode_withStationSuffix() {
        Ticket12306Stations s = Ticket12306Stations.parse(STATION_JS);
        assertEquals("北京站→BJP", "BJP", s.resolveCode("北京站"));
        assertEquals("北京南站→VNP", "VNP", s.resolveCode("北京南站"));
    }

    @Test public void resolveCode_telecodePassthrough() {
        Ticket12306Stations s = Ticket12306Stations.parse(STATION_JS);
        assertEquals("BJP→BJP", "BJP", s.resolveCode("BJP"));
        assertEquals("VNP→VNP", "VNP", s.resolveCode("VNP"));
    }

    @Test public void resolveCode_unknownNull() {
        Ticket12306Stations s = Ticket12306Stations.parse(STATION_JS);
        assertNull("火星→null", s.resolveCode("火星"));
        assertNull("XYZ→null", s.resolveCode("XYZ"));
        assertNull("空→null", s.resolveCode(""));
        assertNull("null→null", s.resolveCode(null));
    }

    @Test public void injectedConstructor_zeroNetwork() {
        // 注入式构造：直接喂四表（照 TrainSourceTest 手工小表风格）
        Map<String, Ticket12306Stations.Station> byCode = new HashMap<>();
        Map<String, List<Ticket12306Stations.Station>> byCity = new HashMap<>();
        Map<String, Ticket12306Stations.Station> cityRep = new HashMap<>();
        Map<String, Ticket12306Stations.Station> byName = new HashMap<>();
        String[] f = {"@BJP", "北京", "BJP", "beijing", "bj", "0", "beijing", "北京", "0", "0"};
        Ticket12306Stations.Station bj = new Ticket12306Stations.Station(f);
        byCode.put("BJP", bj); byName.put("北京", bj);
        List<Ticket12306Stations.Station> list = new ArrayList<>();
        list.add(bj); byCity.put("北京", list); cityRep.put("北京", bj);

        Ticket12306Stations s = new Ticket12306Stations(byCode, byCity, cityRep, byName);
        assertEquals("BJP", s.resolveCode("北京"));
        assertEquals("BJP", s.resolveCode("BJP"));
        assertNull(s.resolveCode("上海"));
    }
}
