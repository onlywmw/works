package com.hermes.android;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.json.JSONObject;
import org.junit.Test;

import java.util.Collections;
import java.util.HashSet;

import static org.junit.Assert.*;

/**
 * H1 reason code 体系单测（零网络注入式，DESIGN_TOOL_HEALTH §一）。
 * 测纯函数（isEnvBroken/withReason/常量）+ shell.exec ENV_BROKEN 注入式链路。
 * provider 真实填码（DramaSource PARSE_DRIFT/SOURCE_DOWN、模型 NOT_CONFIGURED、
 * Hermes ENV_BROKEN）靠 diff 可见 + 验收人抽查；这里锁死纯逻辑不回归。
 */
public class ToolHealthReasonTest {

    @Test public void reasonConstants_areSevenDefinedCodes() {
        assertEquals("NOT_CONFIGURED", ToolRegistry.Result.REASON_NOT_CONFIGURED);
        assertEquals("SOURCE_DOWN", ToolRegistry.Result.REASON_SOURCE_DOWN);
        assertEquals("PARSE_DRIFT", ToolRegistry.Result.REASON_PARSE_DRIFT);
        assertEquals("PERMISSION_MISSING", ToolRegistry.Result.REASON_PERMISSION_MISSING);
        assertEquals("ENV_BROKEN", ToolRegistry.Result.REASON_ENV_BROKEN);
        assertEquals("NOT_REGISTERED", ToolRegistry.Result.REASON_NOT_REGISTERED);
        assertEquals("UNKNOWN", ToolRegistry.Result.REASON_UNKNOWN);
    }

    @Test public void result_okHasNullReason_failureCanCarryCode() {
        ToolRegistry.Result ok = new ToolRegistry.Result(true, "好");
        assertNull("成功 reason 为 null", ok.reason);

        ToolRegistry.Result fail = new ToolRegistry.Result(false, "解析漂移", null, null,
                ToolRegistry.Result.REASON_PARSE_DRIFT);
        assertEquals(ToolRegistry.Result.REASON_PARSE_DRIFT, fail.reason);

        ToolRegistry.Result viaWith = new ToolRegistry.Result(false, "env").withReason(
                ToolRegistry.Result.REASON_ENV_BROKEN);
        assertEquals("withReason 携带归因码", ToolRegistry.Result.REASON_ENV_BROKEN, viaWith.reason);
    }

    @Test public void isEnvBroken_detectsEnvironmentSignals() {
        assertTrue(ToolRegistry.isEnvBroken("cannot open shared object file: libc.so.6"));
        assertTrue(ToolRegistry.isEnvBroken("curl: (60) SSL certificate verify failed"));
        assertTrue(ToolRegistry.isEnvBroken("Segmentation fault (core dumped)"));
        assertTrue(ToolRegistry.isEnvBroken("Illegal instruction (core dumped)"));
        assertFalse("null 不是 env broken", ToolRegistry.isEnvBroken(null));
        assertFalse("空串不是 env broken", ToolRegistry.isEnvBroken(""));
    }

    @Test public void isEnvBroken_ignoresNormalCommandErrors() {
        // 普通命令错误（文件不存在/命令拼错）不是环境坏，不许误判
        assertFalse(ToolRegistry.isEnvBroken("No such file or directory"));
        assertFalse(ToolRegistry.isEnvBroken("python3: command not found"));
        assertFalse(ToolRegistry.isEnvBroken("bash: line 1: foo: command not found"));
    }

    /** 注入式链路：Tools 桩返回 exit=1 + env-broken 输出 → shell.exec 带 ENV_BROKEN reason */
    @Test public void shellExec_envBrokenFailure_carriesReason() throws Exception {
        ToolRegistry r = ToolRegistry.build(new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return "[]"; }
            @Override public String fileRead(String roomId, String path) { return ""; }
            @Override public String fileWrite(String roomId, String path, String c) { return "OK:"; }
            @Override public String capabilityOf(String text) { return "unknown"; }
            @Override public String deviceCmd(String text) { return "ok"; }
            @Override public String packageApk(String roomId, String path, String appName) { return "ERR:"; }
            @Override public String shellExec(String cmd, int timeoutSec) {
                return "exit=1\ncannot open shared object file: libproot.so.1: No such file";
            }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":true}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":true}"; }
        }, "room1", HashSet::new,
                new ToolRegistry.DevicePolicy(Collections.<String>emptySet()), true);

        ToolRegistry.Tool shell = r.find("shell.exec");
        assertNotNull("linuxAvailable=true 应注册 shell.exec", shell);
        ToolRegistry.Result res = shell.handler.run(new JSONObject("{\"cmd\":\"hermes --version\"}"));
        assertFalse("env-broken 输出应为失败", res.ok);
        assertEquals("应填 ENV_BROKEN", ToolRegistry.Result.REASON_ENV_BROKEN, res.reason);
    }

    /** 对照：普通命令失败（文件不存在）不该带 ENV_BROKEN */
    @Test public void shellExec_normalFailure_noEnvBrokenReason() throws Exception {
        ToolRegistry r = ToolRegistry.build(new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return "[]"; }
            @Override public String fileRead(String roomId, String path) { return ""; }
            @Override public String fileWrite(String roomId, String path, String c) { return "OK:"; }
            @Override public String capabilityOf(String text) { return "unknown"; }
            @Override public String deviceCmd(String text) { return "ok"; }
            @Override public String packageApk(String roomId, String path, String appName) { return "ERR:"; }
            @Override public String shellExec(String cmd, int timeoutSec) {
                return "exit=2\nbash: line 1: nosuchcmd: command not found";
            }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":true}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":true}"; }
        }, "room1", HashSet::new,
                new ToolRegistry.DevicePolicy(Collections.<String>emptySet()), true);

        ToolRegistry.Result res = r.find("shell.exec").handler.run(new JSONObject("{\"cmd\":\"nosuchcmd\"}"));
        assertFalse(res.ok);
        assertNull("普通命令失败不该填 ENV_BROKEN", res.reason);
    }
}
