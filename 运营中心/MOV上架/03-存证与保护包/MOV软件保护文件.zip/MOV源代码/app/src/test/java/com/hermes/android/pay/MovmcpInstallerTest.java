package com.hermes.android.pay;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.hermes.android.agent.Journal;
import com.hermes.android.mcp.McpServerStore;
import com.hermes.android.vault.AesGcm;

import org.json.JSONObject;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.spec.SecretKeySpec;

/**
 * 工单26 M3-3：MovmcpInstaller——config 型安装落 store（origin=market/paid=true）、
 * 验签失败拒装 + journal 留痕、K 用毕即焚（不落盘断言）。
 */
public class MovmcpInstallerTest {

    @Rule public TemporaryFolder tmp = new TemporaryFolder();

    private static final KeyPair KP = gen();
    private static final PrivateKey PRIV = KP.getPrivate();
    private static final PublicKey PUB = KP.getPublic();

    private static KeyPair gen() {
        try {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048);
            return g.generateKeyPair();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /** fake store prefs（仿 McpServerStoreTest） */
    static class FakePrefs implements McpServerStore.Prefs {
        final Map<String, String> m = new HashMap<>();
        @Override public String getString(String key, String def) { return m.containsKey(key) ? m.get(key) : def; }
        @Override public void putString(String key, String value) { m.put(key, value); }
    }

    private static JSONObject manifest(String orderId) {
        JSONObject m = new JSONObject();
        try {
            m.put("id", "pkg-accept-001").put("name", "验收包").put("type", "config")
                    .put("sellerDeviceId", "mov-seller").put("orderId", orderId);
        } catch (Exception ignored) {}
        return m;
    }

    /** 构造一单 config 型加密包 */
    private MovmcpPackager.Pack packConfig(String orderId) throws Exception {
        byte[] payload = Shelf.configPayload("http://127.0.0.1:8389", "", "官方能力包", "验收", "net");
        return MovmcpPackager.pack(manifest(orderId), new JSONObject(), new JSONObject(), payload, PRIV);
    }

    private static class Recorder {
        final java.util.List<String> installed = new java.util.ArrayList<>();
        MovmcpInstaller.InstallSink sink() { return installed::add; }
    }

    @Test
    public void config安装落store且originMarketPaidTrue() throws Exception {
        FakePrefs prefs = new FakePrefs();
        McpServerStore store = new McpServerStore(prefs);
        Journal j = new Journal(tmp.newFolder("rooms"));
        File binDir = tmp.newFolder("bin");
        MovmcpPackager.Pack p = packConfig("MOV202608090001");
        Recorder rec = new Recorder();

        boolean ok = MovmcpInstaller.install(p.zipBytes, p.key, PUB, store, j, binDir,
                (n, d, h) -> {}, (t, m) -> true, rec.sink());

        assertTrue("安装成功", ok);
        assertEquals("回执回调", 1, rec.installed.size());
        assertEquals("回执订单号", "MOV202608090001", rec.installed.get(0));
        // store 含条目且 origin=market paid=true
        assertEquals(1, store.list().size());
        McpServerStore.Entry e = store.list().get(0);
        assertEquals(McpServerStore.ORIGIN_MARKET, e.origin);
        assertTrue("paid=true", e.paid);
        assertTrue("enabled", e.enabled);
        assertEquals("http://127.0.0.1:8389", e.url);
        assertEquals("官方能力包", e.name);
        // journal 落 mkt.installed
        assertEquals(1, j.eventsOfType(OrderStore.ROOM, "mkt.installed").length());
    }

    @Test
    public void 验签失败拒装且journal留痕() throws Exception {
        FakePrefs prefs = new FakePrefs();
        McpServerStore store = new McpServerStore(prefs);
        Journal j = new Journal(tmp.newFolder("rooms2"));
        File binDir = tmp.newFolder("bin2");
        MovmcpPackager.Pack p = packConfig("MOV202608090002");
        // 用其他公钥验签（错误卖家）→ 必败
        KeyPair other = gen();

        boolean ok = MovmcpInstaller.install(p.zipBytes, p.key, other.getPublic(), store, j, binDir,
                (n, d, h) -> {}, (t, m) -> true, orderId -> {});

        assertFalse("验签失败拒装", ok);
        assertEquals("store 无条目", 0, store.list().size());
        assertEquals("journal 留 mkt.install_rejected",
                1, j.eventsOfType(OrderStore.ROOM, "mkt.install_rejected").length());
    }

    @Test
    public void K用毕即焚() throws Exception {
        FakePrefs prefs = new FakePrefs();
        McpServerStore store = new McpServerStore(prefs);
        Journal j = new Journal(tmp.newFolder("rooms3"));
        File binDir = tmp.newFolder("bin3");
        MovmcpPackager.Pack p = packConfig("MOV202608090003");
        byte[] K = p.key;

        assertTrue(MovmcpInstaller.install(p.zipBytes, K, PUB, store, j, binDir,
                (n, d, h) -> {}, (t, m) -> true, orderId -> {}));

        // K 已清零（即焚：不落盘不 journal）
        for (byte b : K) assertEquals("K 全部清零", 0, b);
    }

    @Test
    public void E3早退路径K也清零() throws Exception {
        // 验签失败路径（E-3：K 即焚提到外层 finally 覆盖早退）
        FakePrefs prefs = new FakePrefs();
        McpServerStore store = new McpServerStore(prefs);
        Journal j = new Journal(tmp.newFolder("rooms-e3"));
        File binDir = tmp.newFolder("bin-e3");
        MovmcpPackager.Pack p = packConfig("MOV202608090006");
        byte[] K1 = p.key;
        KeyPair other = gen();

        assertFalse(MovmcpInstaller.install(p.zipBytes, K1, other.getPublic(), store, j, binDir,
                (n, d, h) -> {}, (t, m) -> true, orderId -> {}));
        for (byte b : K1) assertEquals("验签败 K 已清零", 0, b);

        // 用户取消路径（另一单新 K）
        MovmcpPackager.Pack p2 = packConfig("MOV202608090007");
        byte[] K2 = p2.key;
        assertFalse(MovmcpInstaller.install(p2.zipBytes, K2, PUB, store, j, binDir,
                (n, d, h) -> {}, (t, m) -> false, orderId -> {}));
        for (byte b : K2) assertEquals("用户取消 K 已清零", 0, b);
    }

    @Test
    public void 用户取消拒装() throws Exception {
        FakePrefs prefs = new FakePrefs();
        McpServerStore store = new McpServerStore(prefs);
        Journal j = new Journal(tmp.newFolder("rooms4"));
        File binDir = tmp.newFolder("bin4");
        MovmcpPackager.Pack p = packConfig("MOV202608090004");

        boolean ok = MovmcpInstaller.install(p.zipBytes, p.key, PUB, store, j, binDir,
                (n, d, h) -> {}, (t, m) -> false, orderId -> {});

        assertFalse("用户取消拒装", ok);
        assertEquals("store 无条目", 0, store.list().size());
        assertEquals("journal 留 user_cancelled",
                1, j.eventsOfType(OrderStore.ROOM, "mkt.install_rejected").length());
    }

    @Test
    public void package型脚本落盘可执行并注册() throws Exception {
        FakePrefs prefs = new FakePrefs();
        McpServerStore store = new McpServerStore(prefs);
        Journal j = new Journal(tmp.newFolder("rooms5"));
        File binDir = tmp.newFolder("bin5");
        byte[] script = "#!/bin/sh\necho hi\n".getBytes(StandardCharsets.UTF_8);
        JSONObject m = new JSONObject();
        m.put("id", "pkg-tool").put("name", "hello.sh").put("type", "package").put("orderId", "MOV202608090005");
        MovmcpPackager.Pack p = MovmcpPackager.pack(m, new JSONObject(), new JSONObject(), script, PRIV);
        java.util.List<String> registered = new java.util.ArrayList<>();

        boolean ok = MovmcpInstaller.install(p.zipBytes, p.key, PUB, store, j, binDir,
                (n, d, h) -> registered.add(n), (t, msg) -> true, orderId -> {});

        assertTrue("package 安装成功", ok);
        File f = new File(binDir, "hello.sh");
        assertTrue("脚本落盘", f.exists());
        assertTrue("可执行", f.canExecute());
        assertEquals("工具注册", 1, registered.size());
        assertEquals("hello.sh", registered.get(0));
    }
}
