package com.hermes.android.agent;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.List;

/**
 * ProductDigest 纯函数单测 (M-QUALITY): finish summary 自检清单解析。
 * (2026-07-30: 多模型评审机制移除, 交互元素/产物摘要用例随评审一并删除)
 */
public class ProductDigestTest {

    // ==================== 自检清单解析 ====================

    @Test
    public void parseChecklist_realAndDemo() {
        List<ProductDigest.CheckItem> items = ProductDigest.parseChecklist(
                "做好了。\n- ✅ 界面: 真实现\n- ⚠️ 扫一扫: 演示版(无相机)");
        assertEquals(2, items.size());
        assertTrue(items.get(0).real);
        assertEquals("界面: 真实现", items.get(0).text);
        assertFalse(items.get(1).real);
        assertEquals("扫一扫: 演示版(无相机)", items.get(1).text);
    }

    @Test
    public void parseChecklist_noMarkers() {
        assertTrue(ProductDigest.parseChecklist("普通交付说明").isEmpty());
        assertTrue(ProductDigest.parseChecklist(null).isEmpty());
    }
}
