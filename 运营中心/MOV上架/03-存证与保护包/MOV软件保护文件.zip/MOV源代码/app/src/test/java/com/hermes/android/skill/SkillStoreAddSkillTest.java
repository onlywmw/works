package com.hermes.android.skill;

import static org.junit.Assert.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

/**
 * 工单24: addSkill 确认卡入库——triggers/steps/validation 必须保留（parseSkill 原丢弃，修复后全保留）。
 */
public class SkillStoreAddSkillTest {

    @Test public void parseSkill_keepsTriggersStepsValidation() throws Exception {
        String skillJson = "{\"name\":\"csv-maker\",\"description\":\"创建CSV\","
                + "\"triggers\":[\"创建CSV\",\"写CSV\"],\"steps\":[\"写文件\",\"读回\"],"
                + "\"validation\":\"读回一致\",\"params\":{\"path\":\"文件路径\"}}";
        JSONObject s = SkillStore.parseSkill(skillJson);
        assertNotNull(s);
        assertEquals("csv-maker", s.optString("name"));
        JSONArray triggers = s.optJSONArray("triggers");
        assertNotNull("triggers 必须保留", triggers);
        assertEquals(2, triggers.length());
        assertEquals("创建CSV", triggers.optString(0));
        assertEquals("写文件", s.optJSONArray("steps").optString(0));
        assertEquals("读回一致", s.optString("validation"));
        assertTrue("params 保留", s.optJSONObject("params").has("path"));
    }

    @Test public void parseSkill_frontmatterStillWorks() {
        String md = "---\nname: demo-skill\ndescription: 示例\n---\n正文";
        JSONObject s = SkillStore.parseSkill(md);
        assertNotNull(s);
        assertEquals("demo-skill", s.optString("name"));
    }
}
