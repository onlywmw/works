/* ============================================================
   newface-entry-unify 防回归测试（node 静态断言）
   跑法: node app/src/test/js/newface-entry-unify.test.js
   工单19: 入口归一 — 历史条目进房 / 交付卡落所属房间 / 显式入口清零
   ============================================================ */
'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const SRC = fs.readFileSync(path.join(__dirname, '../../main/assets/js/newface.js'), 'utf8');

function extractFn(name) {
  const i = SRC.indexOf('function ' + name + '(');
  assert.ok(i >= 0, '找不到 function ' + name);
  let depth = 0, j = SRC.indexOf('{', i);
  for (let k = j; k < SRC.length; k++) {
    if (SRC[k] === '{') depth++;
    else if (SRC[k] === '}') { depth--; if (depth === 0) return SRC.slice(i, k + 1); }
  }
  throw new Error(name + ' 函数体未闭合');
}

const GOTO = extractFn('gotoDelivery');
const OPENHIST = extractFn('openRoomFromHistory');
const REPLAY = extractFn('replayConversation');
const DELIVERY = extractFn('onDelivery');
const HIST = extractFn('openDrawer');
const OPENROOM = extractFn('expertOpenRoom');
const SWITCH = extractFn('switchToExpert');

/* ⓪ 工单19 打回③：所有进房入口必须先显示面板（view-face act + cover 隐藏 + pane flex） */
assert.ok(SRC.includes('function showExpertPane()'), '必须有 showExpertPane() 公共显示序列');
assert.ok(OPENROOM.includes('showExpertPane()'), 'expertOpenRoom 必须先显示面板再进房（打回③根因修复）');
assert.ok(SWITCH.includes('showExpertPane()'), 'switchToExpert 必须复用 showExpertPane()');
const SHOW = extractFn('showExpertPane');
assert.ok(SHOW.includes("classList.add('act')"), 'showExpertPane 必须激活 view-face');
assert.ok(SHOW.includes("cover.style.display = 'none'"), 'showExpertPane 必须隐藏 cover（首页封面）');
assert.ok(SHOW.includes("pane.style.display = 'flex'"), 'showExpertPane 必须显示 expertPane');
assert.ok(SHOW.includes("closeDrawer"), 'showExpertPane 必须关抽屉（防 z-20 遮挡）');

/* ① 历史条目点按 → 进房（非只读回放） */
assert.ok(HIST.includes('openRoomFromHistory'), '历史条目点按必须走 openRoomFromHistory（进房）');
assert.ok(!HIST.includes("replayConversation('"), '历史条目点按不得再走 replayConversation 回放');
assert.ok(OPENHIST.includes('expertOpenRoom(roomId)'), 'openRoomFromHistory 必须调 expertOpenRoom 进真实会话');
assert.ok(OPENHIST.includes('_histLp'), '进房必须保留长按守卫（点按=进房，长按=删除）');
assert.ok(OPENHIST.includes('ROOMS.find'), '进房前必须查 ROOMS（不存在时兜底补建）');
assert.ok(REPLAY.includes('openRoomFromHistory'), 'replayConversation 退役为 openRoomFromHistory 代理');

/* ② 交付卡「去查看」→ 落所属房间 */
assert.ok(DELIVERY.includes('roomId'), 'onDelivery 必须把 roomId 写入交付卡数据');
assert.ok(DELIVERY.includes("card.roomId"), '交付卡数据必须带 roomId');
assert.ok(GOTO.includes('d.roomId'), 'gotoDelivery 必须读交付卡 roomId');
assert.ok(GOTO.includes('expertOpenRoom(d.roomId)'), 'gotoDelivery 必须进所属房间');
assert.ok(GOTO.includes('expertGoFiles'), 'gotoDelivery 必须落到文件/交付区');
/* 变异亲杀：条件被改成恒假（if(false && d.roomId)）时下面断言必须红 */
assert.ok(/if \(d && d\.roomId\)\s*\{/.test(GOTO),
  'gotoDelivery 的 roomId 分支条件必须是「if (d && d.roomId)」真条件（变异恒假拦截）');
assert.ok(GOTO.indexOf('expertOpenRoom(d.roomId)') > GOTO.indexOf('if (d && d.roomId)'),
  'expertOpenRoom(d.roomId) 必须在 roomId 条件分支内');
assert.ok(GOTO.indexOf('switchToExpert()') > GOTO.indexOf('expertOpenRoom(d.roomId)'),
  'switchToExpert 兜底必须在进房分支之后（无 roomId 才兜底）');

/* ③ 显式入口清零：switchToExpert 调用点仅剩自动承接/进房兜底 */
const CALLS = SRC.split('\n').filter(function(l) {
  return l.includes('switchToExpert()') && !l.includes('function switchToExpert') && !l.includes('switchToExpert:');
});
assert.ok(CALLS.length <= 1, 'switchToExpert() 调用点必须 ≤1（仅 gotoDelivery 无 roomId 兜底），实际 ' + CALLS.length);

/* 用户可见字符串检查（注释/标识符除外） */
const CODE = SRC.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/[^\n]*/g, '');
assert.ok(!CODE.includes('→ 专家模式'), '「→ 专家模式」显式入口必须清零');
assert.ok(!CODE.includes('expert-enter'), 'expert-enter 显式入口类必须清零');
assert.ok(!CODE.includes('专 家 模 式'), '面板顶栏不得含「专 家 模 式」');
assert.ok(CODE.includes('开始执行'), '交接卡按钮必须为「开始执行」');
assert.ok(CODE.includes('正在为你安排'), '自动交接提示必须为「正在为你安排」');
assert.ok(CODE.includes('任 务'), '面板顶栏必须为「任 务」');
assert.ok(CODE.includes('返 回 首 页'), '退出链接必须为「返 回 首 页」');
assert.ok(CODE.includes('任务 · 每个任务都有专人负责'), '列表 dateline 必须为「任务 · 每个任务都有专人负责」');
assert.ok(!CODE.includes('专家模式'), '用户可见字符串不得含「专家模式」');
assert.ok(!CODE.includes('新脸'), '用户可见字符串不得含「新脸」');

console.log('入口归一 ✓（历史点按进房 / 交付卡落房间 / switchToExpert 调用点清零 / 显式入口与专家模式文案清零）');
