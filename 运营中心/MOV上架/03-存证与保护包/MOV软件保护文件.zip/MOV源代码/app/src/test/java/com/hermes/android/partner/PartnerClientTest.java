package com.hermes.android.partner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.json.JSONObject;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/**
 * PartnerClient 单测（零网络：FakeTransport 队列假回包）。
 * 覆盖：提交成功/参数错/PROCESSING/401/网络异常、查询成功、上传成功与文件缺失、
 * baseUrl 尾斜杠归一、错误信封两形态（后端 error 对象 / 微信 code+message）。
 */
public class PartnerClientTest {

    /** 队列假回包；记录请求便于断言 */
    static class FakeTransport implements PartnerClient.HttpTransport {
        final List<PartnerClient.Reply> queue = new ArrayList<>();
        final List<String> seen = new ArrayList<>();   // method url token body 摘要
        IOException nextError;

        @Override public PartnerClient.Reply exec(String method, String url, String token, String body) throws IOException {
            if (nextError != null) throw nextError;
            seen.add(method + " " + url + " token=" + token + " body=" + body);
            return queue.remove(0);
        }

        @Override public PartnerClient.Reply upload(String url, String token, String fileName, byte[] data, String mime) throws IOException {
            if (nextError != null) throw nextError;
            seen.add("UPLOAD " + url + " token=" + token + " file=" + fileName + " mime=" + mime + " bytes=" + data.length);
            return queue.remove(0);
        }
    }

    private static PartnerClient client(FakeTransport t) {
        return new PartnerClient("https://mow.kim:8390/", "tok123", t);   // 故意带尾斜杠测归一
    }

    @Test
    public void submit_success_returnsApplymentId() throws Exception {
        FakeTransport t = new FakeTransport();
        t.queue.add(new PartnerClient.Reply(200, "{\"applyment_id\":2000002124775691}"));
        PartnerClient.Resp r = client(t).submitApplyment(new JSONObject().put("business_code", "1900013511_10000"));
        assertTrue(r.ok);
        assertEquals(2000002124775691L, r.data.getLong("applyment_id"));
        // URL 尾斜杠归一 + POST 到 /v1/applyment + Bearer token 传递
        assertTrue(t.seen.get(0).startsWith("POST https://mow.kim:8390/v1/applyment token=tok123"));
        assertTrue(t.seen.get(0).contains("1900013511_10000"));
    }

    @Test
    public void submit_nullApplyment_badRequest() {
        FakeTransport t = new FakeTransport();
        PartnerClient.Resp r = client(t).submitApplyment(null);
        assertFalse(r.ok);
        assertEquals("BAD_REQUEST", r.code);
        assertTrue(t.seen.isEmpty());   // 不发请求
    }

    @Test
    public void submit_wxParamError_mapped() {
        FakeTransport t = new FakeTransport();
        t.queue.add(new PartnerClient.Reply(400, "{\"code\":\"PARAM_ERROR\",\"message\":\"contact_info.contact_name 不能为空\"}"));
        PartnerClient.Resp r = client(t).submitApplyment(new JSONObject());
        assertFalse(r.ok);
        assertEquals("PARAM_ERROR", r.code);
        assertTrue(r.msg.contains("contact_name"));
    }

    @Test
    public void submit_processing_mapped() {
        FakeTransport t = new FakeTransport();
        t.queue.add(new PartnerClient.Reply(409, "{\"error\":{\"code\":\"PROCESSING\",\"msg\":\"存在流程进行中的申请单\"}}"));
        PartnerClient.Resp r = client(t).submitApplyment(new JSONObject());
        assertFalse(r.ok);
        assertEquals("PROCESSING", r.code);
    }

    @Test
    public void submit_unauthorized_401() {
        FakeTransport t = new FakeTransport();
        t.queue.add(new PartnerClient.Reply(401, "{\"error\":{\"code\":\"UNAUTHORIZED\",\"msg\":\"token 无效\"}}"));
        PartnerClient.Resp r = client(t).submitApplyment(new JSONObject());
        assertFalse(r.ok);
        assertEquals("UNAUTHORIZED", r.code);
    }

    @Test
    public void submit_networkError_netCode() {
        FakeTransport t = new FakeTransport();
        t.nextError = new IOException("timeout");
        PartnerClient.Resp r = client(t).submitApplyment(new JSONObject());
        assertFalse(r.ok);
        assertEquals("NET", r.code);
        assertEquals("timeout", r.msg);
    }

    @Test
    public void submit_nonJsonReply_httpCode() {
        FakeTransport t = new FakeTransport();
        t.queue.add(new PartnerClient.Reply(502, "<html>bad gateway</html>"));
        PartnerClient.Resp r = client(t).submitApplyment(new JSONObject());
        assertFalse(r.ok);
        assertEquals("HTTP_502", r.code);
    }

    @Test
    public void query_success_passesBusinessCode() throws Exception {
        FakeTransport t = new FakeTransport();
        t.queue.add(new PartnerClient.Reply(200, "{\"applyment_state\":\"APPLYMENT_STATE_AUDITING\"}"));
        PartnerClient.Resp r = client(t).queryApplyment("1900013511_10000");
        assertTrue(r.ok);
        assertEquals("APPLYMENT_STATE_AUDITING", r.data.getString("applyment_state"));
        assertTrue(t.seen.get(0).startsWith("GET https://mow.kim:8390/v1/applyment/1900013511_10000"));
    }

    @Test
    public void query_emptyCode_badRequest() {
        FakeTransport t = new FakeTransport();
        PartnerClient.Resp r = client(t).queryApplyment("  ");
        assertFalse(r.ok);
        assertEquals("BAD_REQUEST", r.code);
        assertTrue(t.seen.isEmpty());
    }

    @Test
    public void uploadMedia_success_returnsMediaId() throws Exception {
        File tmp = File.createTempFile("license", ".png");
        Files.write(tmp.toPath(), new byte[]{1, 2, 3});
        try {
            FakeTransport t = new FakeTransport();
            t.queue.add(new PartnerClient.Reply(200, "{\"media_id\":\"MEDIA-123\"}"));
            PartnerClient.Resp r = client(t).uploadMedia(tmp);
            assertTrue(r.ok);
            assertEquals("MEDIA-123", r.data.getString("media_id"));
            assertTrue(t.seen.get(0).contains("mime=image/png"));
        } finally {
            tmp.delete();
        }
    }

    @Test
    public void uploadMedia_missingFile_badRequest() {
        FakeTransport t = new FakeTransport();
        PartnerClient.Resp r = client(t).uploadMedia(new File("/nonexistent/x.jpg"));
        assertFalse(r.ok);
        assertEquals("BAD_REQUEST", r.code);
        assertTrue(t.seen.isEmpty());
    }

    @Test
    public void createPayOrder_success_returnsPayUrl() throws Exception {
        FakeTransport t = new FakeTransport();
        t.queue.add(new PartnerClient.Reply(200, "{\"pay_url\":\"https://mow.kim/pay/MOV123\"}"));
        PartnerClient.Resp r = client(t).createPayOrder("MOV123", "验收包", 1);
        assertTrue(r.ok);
        assertEquals("https://mow.kim/pay/MOV123", r.data.getString("pay_url"));
        String seen = t.seen.get(0);
        assertTrue(seen.startsWith("POST https://mow.kim:8390/v1/pay/create token=tok123"));
        assertTrue(seen.contains("MOV123") && seen.contains("\"fen\":1"));
    }

    @Test
    public void createPayOrder_badArgs_rejected() {
        FakeTransport t = new FakeTransport();
        assertEquals("BAD_REQUEST", client(t).createPayOrder("", "x", 1).code);
        assertEquals("BAD_REQUEST", client(t).createPayOrder("MOV123", "x", 0).code);
        assertTrue(t.seen.isEmpty());
    }

    @Test
    public void createPayOrder_serverError_mapped() {
        FakeTransport t = new FakeTransport();
        t.queue.add(new PartnerClient.Reply(400, "{\"error\":{\"code\":\"BAD_REQUEST\",\"msg\":\"oid 非法\"}}"));
        PartnerClient.Resp r = client(t).createPayOrder("bad oid!", "x", 1);
        assertFalse(r.ok);
        assertEquals("BAD_REQUEST", r.code);
    }

    @Test
    public void envelope_errorShape() {
        JSONObject env = PartnerClient.Resp.fail("PROCESSING", "进行中").toEnvelope();
        assertFalse(env.optBoolean("ok"));
        assertEquals("PROCESSING", env.optJSONObject("error").optString("code"));
        JSONObject okEnv = PartnerClient.Resp.ok(new JSONObject()).toEnvelope();
        assertTrue(okEnv.optBoolean("ok"));
    }
}
