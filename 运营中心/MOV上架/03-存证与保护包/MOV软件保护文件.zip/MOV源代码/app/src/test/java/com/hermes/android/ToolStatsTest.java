package com.hermes.android;

import org.json.JSONArray;
import org.json.JSONObject;

import org.junit.Test;

import java.io.File;
import java.io.FileWriter;

import static org.junit.Assert.*;

/**
 * ToolStats 单元测试 — FUSION F6 晋升统计。
 * 零网络：临时目录注入 journal.jsonl（照 TrainSourceTest 注入式）。
 */
public class ToolStatsTest {

    private File tempRoomsDir() throws Exception {
        File dir = new File(System.getProperty("java.io.tmpdir"),
                "stats_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 100000));
        dir.mkdirs();
        return dir;
    }

    private void writeJournal(File roomDir, String... lines) throws Exception {
        roomDir.mkdirs();
        File jf = new File(roomDir, "journal.jsonl");
        try (FileWriter w = new FileWriter(jf)) {
            for (String line : lines) w.write(line + "\n");
        }
    }

    @Test public void collect_countsStepEventsPerTool() throws Exception {
        File dir = tempRoomsDir();
        writeJournal(new File(dir, "room1"),
                "{\"type\":\"step\",\"name\":\"file.write\",\"ok\":true,\"result\":\"x\"}",
                "{\"type\":\"step\",\"name\":\"file.write\",\"ok\":true,\"result\":\"x\"}",
                "{\"type\":\"step\",\"name\":\"train_search\",\"ok\":false,\"result\":\"err\"}",
                "{\"type\":\"deliver\",\"goal\":\"x\"}");  // 非 step 忽略

        JSONArray arr = ToolStats.collect(dir);
        assertEquals("应统计 2 个工具", 2, arr.length());

        JSONObject first = arr.getJSONObject(0);
        assertEquals("file.write 频次最高", "file.write", first.getString("name"));
        assertEquals("count=2", 2, first.getInt("count"));
        assertEquals("ok=2", 2, first.getInt("ok"));
        assertEquals("fail=0", 0, first.getInt("fail"));

        JSONObject second = arr.getJSONObject(1);
        assertEquals("train_search 次之", "train_search", second.getString("name"));
        assertEquals("count=1", 1, second.getInt("count"));
        assertEquals("fail=1", 1, second.getInt("fail"));
    }

    @Test public void collect_sortsByCountDesc() throws Exception {
        File dir = tempRoomsDir();
        writeJournal(new File(dir, "room1"),
                "{\"type\":\"step\",\"name\":\"a\",\"ok\":true}",
                "{\"type\":\"step\",\"name\":\"a\",\"ok\":true}",
                "{\"type\":\"step\",\"name\":\"b\",\"ok\":true}");

        JSONArray arr = ToolStats.collect(dir);
        assertEquals(2, arr.length());
        assertEquals("a 应在最前（频次 2）", "a", arr.getJSONObject(0).getString("name"));
        assertEquals("b 次之（频次 1）", "b", arr.getJSONObject(1).getString("name"));
    }

    @Test public void collect_multipleRoomsAggregated() throws Exception {
        File dir = tempRoomsDir();
        writeJournal(new File(dir, "room1"),
                "{\"type\":\"step\",\"name\":\"shell.exec\",\"ok\":true}");
        writeJournal(new File(dir, "room2"),
                "{\"type\":\"step\",\"name\":\"shell.exec\",\"ok\":true}",
                "{\"type\":\"step\",\"name\":\"file.read\",\"ok\":true}");

        JSONArray arr = ToolStats.collect(dir);
        assertEquals("跨房间聚合 2 工具", 2, arr.length());
        assertEquals("shell.exec 跨 2 房间共 2 次", 2, arr.getJSONObject(0).getInt("count"));
    }

    @Test public void collect_emptyOrMissingDir() throws Exception {
        JSONArray arr = ToolStats.collect(new File(System.getProperty("java.io.tmpdir"),
                "no_such_dir_" + System.currentTimeMillis()));
        assertEquals("空目录返回空数组", 0, arr.length());
    }
}
