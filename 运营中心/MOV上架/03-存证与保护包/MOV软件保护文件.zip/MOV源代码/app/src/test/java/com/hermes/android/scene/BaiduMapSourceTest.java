package com.hermes.android.scene;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * BaiduMapSource 单测 — URL/参数组装、status!=0 报错、AK 打码等纯逻辑，零网络。
 *
 * 不真发请求：BaiduMapSource.get/post 的 httpGet 是 static（可测失败路径），
 * 此处只测纯函数：hasAk / maskAk / 参数 map 构造。
 */
public class BaiduMapSourceTest {

    @Test public void hasAk_trueWhenConfigured() {
        assertTrue(new BaiduMapSource("test-ak-12345").hasAk());
        assertFalse(new BaiduMapSource("").hasAk());
        assertFalse(new BaiduMapSource((String) null).hasAk());
    }

    @Test public void maskAk_longKey() {
        BaiduMapSource s = new BaiduMapSource("1234567890abcdef");
        String masked = s.maskAk("error contains 1234567890abcdef in message");
        assertFalse("AK 不应再出现", masked.contains("1234567890abcdef"));
        assertTrue("前4位保留", masked.contains("1234****"));
        assertTrue("后4位保留", masked.contains("cdef"));
    }

    @Test public void maskAk_shortKey() {
        BaiduMapSource s = new BaiduMapSource("abcd1234");
        String masked = s.maskAk("err abcd1234 here");
        assertFalse(masked.contains("abcd1234"));
        assertTrue(masked.contains("ab****34"));
    }

    @Test public void maskAk_noKeyInText() {
        BaiduMapSource s = new BaiduMapSource("sekrit-key");
        String text = "no key present";
        assertEquals("无 AK 的原样返回", text, s.maskAk(text));
    }

    @Test public void maskAk_emptyAk() {
        BaiduMapSource s = new BaiduMapSource("");
        assertEquals("空 AK 原样返回", "hello world", s.maskAk("hello world"));
    }

    @Test public void map_kvDropsNull() {
        Map<String, String> m = BaiduMapSource.map("a", "1", "b", null, "c", "3");
        assertEquals(2, m.size());
        assertEquals("1", m.get("a"));
        assertFalse("null 值不放入", m.containsKey("b"));
        assertEquals("3", m.get("c"));
    }

    @Test public void map_oddArgsIgnored() {
        Map<String, String> m = BaiduMapSource.map("a", "1", "dangling");
        assertEquals(1, m.size());
        assertEquals("1", m.get("a"));
    }

    @Test public void enc_utf8() {
        // URLEncoder 中文 → %XX 编码（HTTP GET 参数）
        assertEquals("%E5%8C%97%E4%BA%AC", BaiduMapSource.enc("北京"));
        assertEquals("abc", BaiduMapSource.enc("abc"));
    }

    @Test public void httpGet_badUrlReturnsNull() {
        assertNull("坏 URL 返回 null", BaiduMapSource.httpGet("not a url"));
    }

    @Test public void staticHelpers_noThrow() {
        // 组装相关纯函数不应抛异常
        Map<String, String> params = new HashMap<>();
        params.put("query", "美食");
        BaiduMapSource.map("query", "美食", "region", "北京市");
        assertNotNull(BaiduMapSource.map("x", "y"));
    }
}
