package com.hermes.android.skill;

import static org.junit.Assert.*;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.json.JSONObject;
import org.junit.Test;

import java.util.Collections;
import java.util.HashSet;

/** 批2: SkillActivator 单测——handler 分发 + 技能工具注册 */
public class SkillActivatorTest {

    private static ToolRegistry registry() {
        return ToolRegistry.build(new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return "[]"; }
            @Override public String fileRead(String roomId, String path) { return ""; }
            @Override public String fileWrite(String roomId, String path, String c) { return "OK:"; }
            @Override public String capabilityOf(String text) { return "unknown"; }
            @Override public String deviceCmd(String text) { return "ok"; }
            @Override public String packageApk(String roomId, String path, String appName) { return ""; }
            @Override public String shellExec(String cmd, int timeoutSec) { return "exit=0\nok"; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":true}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":true}"; }
        }, "room1", HashSet::new, new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
    }

    @Test public void handlerFor_skillEcho_works() throws Exception {
        ToolRegistry.Handler h = SkillActivator.handlerFor("skill.echo");
        assertNotNull("skill.echo 应有实现", h);
        ToolRegistry.Result r = h.run(new JSONObject("{\"text\":\"hi\"}"));
        assertTrue(r.ok);
        assertEquals("echo:hi", r.text);
    }

    @Test public void handlerFor_unknown_null() {
        assertNull(SkillActivator.handlerFor("no-such-tool"));
    }

    @Test public void activate_registersOnlyImplementedTools() {
        ToolRegistry r = registry();
        String skillJson = "{\"name\":\"mov-demo\",\"tools\":[" +
                "{\"name\":\"skill.echo\",\"description\":\"回显\"}," +
                "{\"name\":\"no-impl\",\"description\":\"无实现\"}]}";
        int n = SkillActivator.activate(r, skillJson);
        assertEquals("只有 skill.echo 有实现", 1, n);
        assertNotNull(r.find("skill.echo"));
        assertNull("无实现的工具不得注册", r.find("no-impl"));
    }

    @Test public void activate_invalidSkill_zero() {
        assertEquals(0, SkillActivator.activate(registry(), "not-json"));
    }

    @Test public void activate_emptyTools_zero() {
        assertEquals(0, SkillActivator.activate(registry(), "{\"name\":\"a\"}"));
    }

    @Test public void activate_wbTools_notReadonly() {
        // 验收修复回归：wb.* 操控真实浏览器，不得以 readonly 混入（否则会被 MCP 只读服务对外暴露）
        ToolRegistry r = registry();
        String skillJson = "{\"name\":\"mov-webbridge\",\"tools\":[" +
                "{\"name\":\"wb.navigate\",\"description\":\"导航\"}," +
                "{\"name\":\"wb.evaluate\",\"description\":\"执行JS\"}," +
                "{\"name\":\"skill.echo\",\"description\":\"回显\"}]}";
        assertEquals(3, SkillActivator.activate(r, skillJson));
        assertEquals("write", r.find("wb.navigate").access);
        assertEquals("dangerous", r.find("wb.evaluate").access);
        assertEquals("readonly", r.find("skill.echo").access);
    }
}
