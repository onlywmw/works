package com.hermes.android.a2a;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * 职业注册表端侧 payload 单测（纯 JVM，零网络，注入式）。
 * - buildRegisterPayload：role 缺省 buyer、professions 缺省不加（旧调用点兼容）
 * - buildQueryProPayload：craft/radiusKm/online 参数构造
 * - parseDevices：relay 响应解析（含/不含 professions 都兼容）
 */
public class A2aClientPayloadTest {

    @Test public void buildRegisterPayload_defaultsBuyer() throws Exception {
        JSONObject b = A2aClient.buildRegisterPayload("d1", "name", null, null);
        assertEquals("device_id", "d1", b.getString("device_id"));
        assertEquals("name", "name", b.getString("name"));
        assertEquals("缺省 role=buyer", "buyer", b.getString("role"));
        assertFalse("缺省不传 professions", b.has("professions"));
    }

    @Test public void buildRegisterPayload_withProfessions() throws Exception {
        JSONArray profs = new JSONArray().put(
                new JSONObject().put("craft", "shop").put("form", "instant"));
        JSONObject b = A2aClient.buildRegisterPayload("d1", "老王", "pro", profs);
        assertEquals("role=pro", "pro", b.getString("role"));
        assertEquals("professions 序列化", 1, b.getJSONArray("professions").length());
        assertEquals("craft 保留", "shop", b.getJSONArray("professions").getJSONObject(0).getString("craft"));
    }

    @Test public void buildRegisterPayload_nullProfessionsNoField() throws Exception {
        JSONObject b = A2aClient.buildRegisterPayload("d1", "n", "pro", null);
        assertFalse("null professions 不加字段", b.has("professions"));
    }

    @Test public void buildQueryProPayload_params() throws Exception {
        JSONObject b = A2aClient.buildQueryProPayload("delivery", 2, true);
        assertEquals("craft", "delivery", b.getString("craft"));
        assertEquals("radius_km", 2, b.getInt("radius_km"));
        assertTrue("online", b.getBoolean("online"));
    }

    @Test public void buildQueryProPayload_craftOptional() throws Exception {
        JSONObject b = A2aClient.buildQueryProPayload(null, 0, false);
        assertFalse("craft 可选", b.has("craft"));
        assertFalse("online", b.getBoolean("online"));
    }

    @Test public void parseDevices_compatBothKeyShapes() throws Exception {
        // 含 professions 的新响应（device_id）+ 旧响应（deviceId）都能解析
        JSONObject resp = new JSONObject().put("devices", new JSONArray()
                .put(new JSONObject().put("device_id", "d1").put("name", "老王"))
                .put(new JSONObject().put("deviceId", "d2").put("name", "小赵")));
        List<A2aClient.Peer> peers = A2aClient.parseDevices(resp);
        assertEquals(2, peers.size());
        assertEquals("device_id key 兼容", "d1", peers.get(0).deviceId);
        assertEquals("deviceId key 兼容", "d2", peers.get(1).deviceId);
    }

    @Test public void parseDevices_emptyOrNull() {
        assertEquals(0, A2aClient.parseDevices(null).size());
        assertEquals(0, A2aClient.parseDevices(new JSONObject()).size());
    }
}
