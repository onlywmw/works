/* ============================================================
   newface-chat-continuity 防回归测试（node 静态断言）
   跑法: node app/src/test/js/newface-chat-continuity.test.js
   工单17: 首页对话连续性 — 幕一视觉连续 + 幕二B同房派活
   断言: 追加式渲染 / utter 防重 / 清屏仅限显式动作 / 同房复用
   ============================================================ */
'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const SRC = fs.readFileSync(path.join(__dirname, '../../main/assets/js/newface.js'), 'utf8');

function extractFn(name) {
  const i = SRC.indexOf('function ' + name + '(');
  assert.ok(i >= 0, '找不到 function ' + name);
  let depth = 0, j = SRC.indexOf('{', i);
  for (let k = j; k < SRC.length; k++) {
    if (SRC[k] === '{') depth++;
    else if (SRC[k] === '}') { depth--; if (depth === 0) return SRC.slice(i, k + 1); }
  }
  throw new Error(name + ' 函数体未闭合');
}

const SAY = extractFn('say');
const ROUTE = extractFn('routeByIntent');
const MUSIC = extractFn('startMusicSearch');
const TRAIN = extractFn('startTrainSearch');
const A2A = extractFn('startA2A');
const FLOW = extractFn('startFlow');
const FAIL = extractFn('startFail');
const AUTO = extractFn('autoHandoff');
const INLINE = extractFn('showInlineChat');
const RESET = extractFn('resetFace');
const CREATE = extractFn('expertCreateRoom');
const STREAM = extractFn('ensureStream');

/* ── ① 幕一：追加式基础设施 ── */
assert.ok(SRC.includes('function ensureStream()'), '必须有 ensureStream 对话流基础设施');
assert.ok(SRC.includes('_chatStreamOn'), '必须有 _chatStreamOn 会话状态');
assert.ok(STREAM.includes("cover.innerHTML = ''"), 'ensureStream 首轮清屏（唯一合法初始化清屏点）');

/* ── ② 幕一：say/routeByIntent 不再整体清屏 ── */
assert.ok(!SAY.includes("cover.innerHTML = ''"), 'say() 不得整体清屏（追加式）');
assert.ok(SAY.includes('ensureStream()'), 'say() 必须走 ensureStream');
assert.ok(!ROUTE.includes("cover.innerHTML = ''"), 'routeByIntent 不得整体清屏');
assert.ok(!ROUTE.includes("el('<div class=\"utter\""), 'routeByIntent 不得重复追加 utter（say 已渲染）');

/* ── ③ 幕一：各路由分支追加式 + utter 防重 ── */
[MUSIC, TRAIN, A2A, FAIL].forEach(function(fn, i) {
  assert.ok(!fn.includes("cover.innerHTML = ''"), '路由分支 #' + i + ' 不得整体清屏');
  assert.ok(fn.includes('ensureStream()') || fn.includes('streamHasUtter()'),
    '路由分支 #' + i + ' 必须走对话流（ensureStream/streamHasUtter）');
});
assert.ok(FLOW.includes('ensureStream()'), 'startFlow 必须走 ensureStream');
assert.ok(AUTO.includes('ensureStream()'), 'autoHandoff 必须走 ensureStream');
assert.ok(INLINE.includes('ensureStream()'), 'showInlineChat 必须走 ensureStream');

/* ── ④ 幕一：清屏仅限显式动作（resetFace/showEmpty） + 工单19 历史回放退役（进房） ── */
assert.ok(RESET.includes('_chatStreamOn = false'), 'resetFace 恢复封面必须重置对话流（新会话）');
assert.ok(extractFn('showEmpty').includes('_chatStreamOn = false'), 'showEmpty 必须重置对话流');
const REPLAY = extractFn('replayConversation');
assert.ok(REPLAY.includes('openRoomFromHistory'), 'replayConversation 已退役为进房（工单19：历史条目点按进房）');
const OPENHIST = extractFn('openRoomFromHistory');
assert.ok(OPENHIST.includes('expertOpenRoom'), '历史条目进房必须走 expertOpenRoom（真实会话视图）');
assert.ok(OPENHIST.includes('_histLp'), '历史条目进房必须有长按守卫（点按=进房，长按=删除分工）');

/* ── ⑤ 幕二B：同房派活 ── */
assert.ok(SRC.includes('var _homeRoomId = null'), '必须有 _homeRoomId 状态');
assert.ok(SRC.includes('var _homeHandoff = false'), '必须有 _homeHandoff 标记');
assert.ok(CREATE.includes('_homeHandoff && _homeRoomId'), 'expertCreateRoom 必须复用首页房间（同房派活）');
assert.ok(CREATE.includes('sendExpertMsg(_homeRoomId, text)'), '复用分支必须发消息进同一房间');
assert.ok(CREATE.includes('_homeRoomId = id'), '新建分支必须记录首页房间');
assert.ok(AUTO.includes('_homeHandoff = true'), 'autoHandoff 必须置 _homeHandoff 标记（仅首页自动交接复用）');
assert.ok(RESET.includes('_homeRoomId = null'), 'resetFace 必须清空 _homeRoomId（回封面=新会话）');

/* ── ⑥ §六补充条款：短→长升级必带情境（验收打回②修法） ── */
const HANDOFF = extractFn('handoffToExpert');
const WATCH = extractFn('currentWatchingContext');
assert.ok(HANDOFF.includes('currentWatchingContext()'), 'handoffToExpert 必须注入当前情境（升级必带情境）');
assert.ok(WATCH.includes("q:'watch_history'"), 'currentWatchingContext 必须读 watch_history');
assert.ok(WATCH.includes('当前情境'), '情境注入文案必须为「当前情境」');
assert.ok(WATCH.includes('第 '), '情境注入必须含集数（第 N 话）');
assert.ok(WATCH.includes('在看《'), '情境注入必须含剧名（在看《X》）');
assert.ok(WATCH.includes('catch(e) { return \'\'; }'), '情境读取失败必须静默（不阻塞交接）');

console.log('首页对话连续性 ✓（ensureStream 追加式 / say·routeByIntent 不清屏 / 分支 utter 防重 / 清屏仅限显式动作 / 同房派活复用 / §六升级情境注入）');
