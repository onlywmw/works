package com.hermes.android.mcp;

import io.modelcontextprotocol.server.McpServer;
import io.modelcontextprotocol.server.McpStatelessServerFeatures;
import io.modelcontextprotocol.server.McpStatelessSyncServer;
import io.modelcontextprotocol.spec.McpSchema;
import io.modelcontextprotocol.spec.McpStatelessServerTransport;
import org.junit.Test;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * P1 spike: 验证官方 MCP Java SDK（mcp-core 1.0.2）协议层在 JVM 可用——
 * McpServer.sync 创建、addTool、listTools 返回标准 schema。
 * 不验证 Android 运行时（records desugar/Reactor）——那是真机 spike。
 */
public class McpSpikeTest {

    /** mcp-core 用 ServiceLoader 找 JSON 提供者（classloader 不含 test resources）——反射注入 Jackson2 mapper。 */
    @BeforeClass
    public static void injectJsonMapper() throws Exception {
        io.modelcontextprotocol.util.McpServiceLoader<io.modelcontextprotocol.json.McpJsonMapperSupplier, io.modelcontextprotocol.json.McpJsonMapper> sl =
                new io.modelcontextprotocol.util.McpServiceLoader<>(io.modelcontextprotocol.json.McpJsonMapperSupplier.class);
        sl.setSupplier(new Jackson2McpJsonMapperSupplier());
        java.lang.reflect.Field f = io.modelcontextprotocol.json.McpJsonDefaults.class.getDeclaredField("mcpMapperServiceLoader");
        f.setAccessible(true);
        f.set(null, sl);
        // 诊断：注入后 getMapper 是否可用
        io.modelcontextprotocol.json.McpJsonMapper m = io.modelcontextprotocol.json.McpJsonDefaults.getMapper();
        System.out.println("注入后 getMapper ok: " + (m != null));
    }

    private McpStatelessServerTransport memoryTransport() {
        return new McpStatelessServerTransport() {
            @Override public void setMcpHandler(io.modelcontextprotocol.server.McpStatelessServerHandler h) {}
            @Override public Mono<Void> closeGracefully() { return Mono.empty(); }
        };
    }

    @Test public void jsonSupplierLoads() {
        java.util.ServiceLoader<io.modelcontextprotocol.json.McpJsonMapperSupplier> sl =
                java.util.ServiceLoader.load(io.modelcontextprotocol.json.McpJsonMapperSupplier.class);
        int n = 0;
        for (io.modelcontextprotocol.json.McpJsonMapperSupplier s : sl) { n++; }
        System.out.println("ServiceLoader 找到 McpJsonMapperSupplier 数: " + n);
        assertEquals("应能找到 Jackson2 supplier（test resources 注册）", 1, n);
    }

    @Test public void sdkSyncSpecCreates() {
        Object spec = McpServer.sync(memoryTransport());
        assertNotNull("McpServer.sync 应返回 specification", spec);
    }

    @Test public void sdkAddToolAndListTools() {
        // 诊断：build() 前 getMapper 是否可用
        io.modelcontextprotocol.json.McpJsonMapper m0 = io.modelcontextprotocol.json.McpJsonDefaults.getMapper();
        assertNotNull("build 前 getMapper 应可用", m0);
        McpStatelessSyncServer server = McpServer.sync(memoryTransport())
                .serverInfo("mov", "1.0.0")
                .capabilities(McpSchema.ServerCapabilities.builder().tools(true).build())
                .build();
        assertNotNull(server);

        McpSchema.JsonSchema schema = new McpSchema.JsonSchema("object",
                Map.of("text", Map.of("type", "string")), List.of(), false, null, null);
        // McpSchema.Tool = (name, title, description, inputSchema, ...) — description 放第 3 参
        McpSchema.Tool tool = new McpSchema.Tool("echo", null, "Echo test", schema, null, null, null);
        server.addTool(new McpStatelessServerFeatures.SyncToolSpecification(tool,
                (ex, req) -> new McpSchema.CallToolResult(
                        List.of(new McpSchema.TextContent("pong")), false, null, null)));

        List<McpSchema.Tool> tools = server.listTools();
        assertEquals("应注册 1 个工具", 1, tools.size());
        assertEquals("echo", tools.get(0).name());
        assertEquals("Echo test", tools.get(0).description());
    }
}
