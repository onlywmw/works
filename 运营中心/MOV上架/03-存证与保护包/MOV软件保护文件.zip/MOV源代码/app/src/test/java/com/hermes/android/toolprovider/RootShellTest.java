package com.hermes.android.toolprovider;

import static org.junit.Assert.*;

import com.hermes.android.agent.ToolRegistry;

import org.junit.Test;

import java.util.List;

/**
 * 工单10: RootShell 纯函数(黑名单/命令构造, 单测零 root) + UiToolProvider DANGEROUS 注册。
 * 变异亲杀: 黑名单改恒放行 → 必红。
 */
public class RootShellTest {

    // ═══ 红线黑名单 ═══

    @Test public void deniedPackages_rejected() {
        assertTrue("支付宝", RootShell.isDenied("com.alipay.sdk", null));
        assertTrue("微信", RootShell.isDenied("com.tencent.mm", null));
        assertTrue("银联", RootShell.isDenied("com.unionpay", null));
        assertTrue("短信", RootShell.isDenied("com.android.mms", null));
        assertTrue("通讯录", RootShell.isDenied("com.android.contacts", null));
        assertTrue("通话记录/拨号", RootShell.isDenied("com.android.dialer", null));
    }

    @Test public void deniedActions_rejected() {
        assertTrue("CALL", RootShell.isDenied(null, "android.intent.action.CALL"));
        assertTrue("DIAL", RootShell.isDenied(null, "android.intent.action.DIAL"));
        assertTrue("SENDTO(短信)", RootShell.isDenied(null, "android.intent.action.SENDTO"));
    }

    @Test public void safeNotDenied() {
        assertFalse("设置", RootShell.isDenied("com.android.settings", null));
        assertFalse("MOV", RootShell.isDenied("com.mov.test", null));
        assertFalse("MAIN action", RootShell.isDenied(null, "android.intent.action.MAIN"));
    }

    // ═══ 命令构造纯函数 ═══

    @Test public void buildCommand_quotes() {
        assertEquals("su -c \"echo hi\"", RootShell.buildCommand("echo hi"));
        assertEquals("su -c \"\"", RootShell.buildCommand(null));
        assertEquals("su -c \"input tap 100 200\"", RootShell.buildCommand("input tap 100 200"));
    }

    // ═══ UiToolProvider DANGEROUS 注册 ═══

    @Test public void uiTools_registered_dangerous() {
        UiToolProvider p = new UiToolProvider();
        List<ToolRegistry.Tool> tools = p.discover();
        assertEquals("UI 三件套 4 工具(ui.dump/tap/swipe/input)", 4, tools.size());
        for (ToolRegistry.Tool t : tools) {
            assertEquals("approval=plan(DANGEROUS 闸): " + t.name, "plan", t.approval);
            assertEquals("risk=high: " + t.name, "high", t.manifest.risk);
        }
    }
}
