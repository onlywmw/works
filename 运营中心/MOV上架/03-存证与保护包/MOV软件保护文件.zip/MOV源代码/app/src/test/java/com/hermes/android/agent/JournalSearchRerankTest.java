package com.hermes.android.agent;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * M3 接缝测试：Journal.search 方案 B 语义补充（注入 SearchReranker）。
 * 靶点 = 接缝：注入后按返回序重排 / 返回 null 回退 / 返回子集按序取 / 子串命中 ≥K 保底不触发。
 * 真实现（cosine/阈值/前缀/截断）逻辑见 llama/SemanticRerankerTest。
 * 验收见 docs/PLAN_SEMANTIC_RECALL_2026-08-09.md §七 M3。
 */
public class JournalSearchRerankTest {

    @Rule
    public TemporaryFolder tmp = new TemporaryFolder();

    private Journal journal;

    @Before
    public void setUp() throws Exception {
        Journal.setLogger(null);
        Journal.setSearchReranker(null);
        journal = new Journal(tmp.newFolder("rooms"));
    }

    @After
    public void tearDown() {
        Journal.setSearchReranker(null);
    }

    private int appendText(String room, String text) throws Exception {
        return journal.append(room, new JSONObject()
                .put("actor", "user").put("type", "user_input")
                .put("payload", new JSONObject().put("text", text)));
    }

    @Test
    public void semanticSupplement_zeroSubstringHits_reranked() throws Exception {
        String room = "rSem";
        int s1 = appendText(room, "凌晨三点才睡 第二天开会打哈欠");
        int s2 = appendText(room, "午餐吃了米饭和西红柿");
        int s3 = appendText(room, "傍晚去公园跑步五公里");
        // 搜索词子串 0 命中 → 语义补充。recentEvents 按 seq 倒序：cand=[s3,s2,s1]
        Journal.setSearchReranker((q, texts) -> {
            List<Integer> order = new ArrayList<>();
            for (int i = texts.size() - 1; i >= 0; i--) order.add(i);
            return order;   // [2,1,0] → 结果顺序 s1,s2,s3
        });
        JSONObject r = journal.search(room, "睡眠不足", 10);
        assertTrue("ok", r.optBoolean("ok"));
        JSONArray events = r.optJSONObject("data").optJSONArray("events");
        assertEquals(3, events.length());
        assertEquals(s1, events.getJSONObject(0).getInt("seq"));
        assertEquals(s2, events.getJSONObject(1).getInt("seq"));
        assertEquals(s3, events.getJSONObject(2).getInt("seq"));
    }

    @Test
    public void rerankerReturnsNull_fallsBackToPlainSubstring() throws Exception {
        String room = "rNull";
        int s1 = appendText(room, "记录投资理财计划");
        appendText(room, "今天天气不错");
        Journal.setSearchReranker((q, texts) -> null);   // 语义层失败 → 回退纯子串
        JSONObject r = journal.search(room, "投资", 10);
        assertTrue(r.optBoolean("ok"));
        JSONArray events = r.optJSONObject("data").optJSONArray("events");
        assertEquals(1, events.length());
        assertEquals(s1, events.getJSONObject(0).getInt("seq"));
    }

    @Test
    public void rerankerReturnsSubset_onlyKeepsListedIndex() throws Exception {
        String room = "rSub";
        int s1 = appendText(room, "甲");
        int s2 = appendText(room, "乙");
        appendText(room, "丙");
        Journal.setSearchReranker((q, texts) -> {
            List<Integer> subset = new ArrayList<>();
            subset.add(1);   // 只保留 cand[1]（recent 倒序 = s2）
            return subset;
        });
        JSONObject r = journal.search(room, "无关词", 10);
        JSONArray events = r.optJSONObject("data").optJSONArray("events");
        assertEquals(1, events.length());
        assertEquals(s2, events.getJSONObject(0).getInt("seq"));
    }

    @Test
    public void substringHitsAtOrAboveK_rerankerNotCalled() throws Exception {
        String room = "rK";
        AtomicInteger calls = new AtomicInteger();
        appendText(room, "睡眠不足导致头痛");
        appendText(room, "睡眠不足影响专注力");
        appendText(room, "改善睡眠不足的方法");
        Journal.setSearchReranker((q, texts) -> {
            calls.incrementAndGet();
            return new ArrayList<>();
        });
        JSONObject r = journal.search(room, "睡眠不足", 10);
        JSONArray events = r.optJSONObject("data").optJSONArray("events");
        assertEquals("子串命中 ≥K 走保底，count=3", 3, events.length());
        assertEquals("保底路径不得调用 reranker", 0, calls.get());
    }

    @Test
    public void substringHitsPrecedeSemanticHits_tsSeqOrderKept() throws Exception {
        String room = "rMerge";
        int s1 = appendText(room, "项目 A 进度延期");     // 含"延期"
        int s2 = appendText(room, "延期说明写了没有");     // 含"延期"，更晚
        int s3 = appendText(room, "今天心情不错");         // 无关
        // 子串命中 2 条（<K=3）→ 语义补充；reranker 返回 cand[0]（recent 倒序 = s3）
        Journal.setSearchReranker((q, texts) -> {
            List<Integer> order = new ArrayList<>();
            order.add(0);
            return order;
        });
        JSONObject r = journal.search(room, "延期", 10);
        JSONArray events = r.optJSONObject("data").optJSONArray("events");
        // 子串命中（s2,s1，ts+seq 倒序）前置 + 语义命中（s3）后置
        assertEquals(3, events.length());
        assertEquals(s2, events.getJSONObject(0).getInt("seq"));
        assertEquals(s1, events.getJSONObject(1).getInt("seq"));
        assertEquals(s3, events.getJSONObject(2).getInt("seq"));
    }
}
