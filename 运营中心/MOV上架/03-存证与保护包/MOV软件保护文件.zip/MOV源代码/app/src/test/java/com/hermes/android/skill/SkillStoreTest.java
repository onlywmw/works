package com.hermes.android.skill;

import static org.junit.Assert.*;

import org.json.JSONObject;
import org.junit.Test;

/** 批2: SkillStore.parseSkill 纯逻辑单测（技能 JSON 解析，不依赖 Android context） */
public class SkillStoreTest {

    @Test public void parseSkill_valid() throws Exception {
        JSONObject s = SkillStore.parseSkill(
                "{\"name\":\"mov-demo\",\"description\":\"示例\",\"tools\":[{\"name\":\"skill.echo\"}]}");
        assertNotNull(s);
        assertEquals("mov-demo", s.getString("name"));
        assertEquals("示例", s.getString("description"));
        assertEquals(1, s.getJSONArray("tools").length());
    }

    @Test public void parseSkill_missingName_null() {
        assertNull(SkillStore.parseSkill("{\"description\":\"x\"}"));
    }

    @Test public void parseSkill_invalidJson_null() {
        assertNull(SkillStore.parseSkill("not-json"));
    }

    @Test public void parseSkill_noTools_emptyArray() throws Exception {
        JSONObject s = SkillStore.parseSkill("{\"name\":\"a\"}");
        assertNotNull(s);
        assertEquals(0, s.getJSONArray("tools").length());
    }
}
