/* ============================================================
   newface-settings 防回归测试（node 静态断言）
   跑法: node app/src/test/js/newface-settings.test.js
   工单14: 设置页用户视角重做 — 全屏一级页 + 二级页导航
   断言: 结构 / 术语清零 / 迁移映射调用点在案 / 破坏性操作确认闸
   ============================================================ */
'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const SRC = fs.readFileSync(path.join(__dirname, '../../main/assets/js/newface.js'), 'utf8');

function extractFn(name) {
  const i = SRC.indexOf('function ' + name + '(');
  assert.ok(i >= 0, '找不到 function ' + name);
  let depth = 0, j = SRC.indexOf('{', i);
  for (let k = j; k < SRC.length; k++) {
    if (SRC[k] === '{') depth++;
    else if (SRC[k] === '}') { depth--; if (depth === 0) return SRC.slice(i, k + 1); }
  }
  throw new Error(name + ' 函数体未闭合');
}
/* 排除注释后检查（注释内的术语是验收允许的） */
function stripComments(code) {
  return code.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/[^\n]*/g, '');
}

const TREE = extractFn('renderSettingsTree');
const SUB = extractFn('renderSubPage');
const MODEL = extractFn('renderModelPage');
const VAULT = extractFn('renderVaultPage');
const FEED = extractFn('renderFeedbackPage');
const THEME = extractFn('renderThemePage');
const UNDER = extractFn('renderUnderstandPage');
const DEVICE = extractFn('renderDevicePage');
const SCENE = extractFn('renderScenePage');
const PERM = extractFn('renderPermPage');
const SERVICE = extractFn('renderServicePage');
const SYSTEM = extractFn('renderSystemPage');
const CLEAR = extractFn('clearRecordsSheet');
const REC = extractFn('_clearRec');
const MDEL = extractFn('_mdelete');
const RSYS = extractFn('resetSystemConfirm');
const CLEAN = extractFn('cleanupRooms');
const OPEN = extractFn('openSettings');
const PAGES = [TREE, SUB, MODEL, VAULT, FEED, THEME, UNDER, DEVICE, SCENE, PERM, SERVICE, SYSTEM];

/* ── ① 一级页结构（demo 定稿 8 行：用户行 + 外观/AI 模型/保险柜/清除/检查更新/意见反馈 + 高级） ── */
['本地用户','外观','AI 模型','保险柜','清除对话记录','检查更新','意见反馈','高级'].forEach(function(k) {
  assert.ok(TREE.includes(k), '一级页必须含「' + k + '」行');
});
/* 一级页 6 个高级子页入口 */
['理解方式','设备协作','快捷场景','权限与功能','服务连接','系统'].forEach(function(k) {
  assert.ok(TREE.includes(k), '高级折叠必须含「' + k + '」入口');
});
/* 高级默认收起 + 折叠 key 只用 mv:set:adv */
assert.ok(TREE.includes("getFoldState('adv')"), '高级折叠状态必须走 mv:set:adv');
assert.ok(!TREE.includes("getFoldState('brain')") && !TREE.includes("getFoldState('caps')"),
  '旧折叠 key 不得再被读取');

/* ── ② 二级页分发器：10 个页面全部注册 ── */
['theme','model','vault','feedback','understand','device','scene','perm','service','system'].forEach(function(id) {
  assert.ok(SUB.includes("render" + id.charAt(0).toUpperCase() + id.slice(1) + "Page()"),
    'renderSubPage 必须分发 ' + id + ' 页面');
});

/* ── ③ 术语清零（验收标准 2）：设置区渲染代码不含 大脑|意图路由|场景卡|A2A|TOKEN（注释除外） ── */
const TERMS = ['大脑','意图路由','场景卡','A2A','TOKEN'];
PAGES.forEach(function(fn, i) {
  const code = stripComments(fn);
  TERMS.forEach(function(t) {
    assert.ok(!code.includes(t), '设置页渲染代码（注释除外）不得含术语「' + t + '」，违规函数 #' + i);
  });
});

/* ── ④ 迁移映射调用点在案（验收标准 3：功能零误删） ── */
assert.ok(MODEL.includes('B.listModels'), 'AI 模型页必须读 listModels');
assert.ok(MODEL.includes('B.tokenStats'), 'AI 模型页必须读 tokenStats（用量条迁入）');
assert.ok(MODEL.includes('_mform'), 'AI 模型页必须保留添加模型入口');
assert.ok(MODEL.includes('B.listLocalModels'), '本地模型(OCR)必须保留');
assert.ok(VAULT.includes('loadVaultEntries'), '保险柜页必须保留条目列表');
assert.ok(VAULT.includes('解锁查看') && VAULT.includes('loadVaultEntries'), '保险柜解锁查看必须保留');
assert.ok(UNDER.includes("setRoutingMode") || UNDER.includes('mv:routing'), '理解方式必须复用 mv:routing');
assert.ok(DEVICE.includes('genA2aPairCode'), '设备协作必须保留配对码');
assert.ok(DEVICE.includes('refreshA2aBlock'), '设备协作必须保留已配对列表');
assert.ok(DEVICE.includes('saveA2aRelay'), '设备协作必须保留 Relay 配置');
assert.ok(SCENE.includes("q:'tool_manifest'"), '快捷场景必须读 tool_manifest');
assert.ok(SCENE.includes('renderSourcesSection'), '视频源开关不得丢（收编快捷场景底部）');
assert.ok(PERM.includes('B.permState'), '权限与功能必须读 permState');
assert.ok(PERM.includes("q:'health'"), '权限与功能必须含健康行');
assert.ok(SERVICE.includes('connectPlatforms'), '服务连接必须读 web_sites（经 connectPlatforms）');
assert.ok(extractFn('connectPlatforms').includes("q:'web_sites'"), 'connectPlatforms 必须查 web_sites');
assert.ok(SERVICE.includes('clearConnect'), '服务连接必须保留清除登态');
assert.ok(SYSTEM.includes('_mcpSave') && SYSTEM.includes('_sshEdit') && SYSTEM.includes('_diagExport'),
  '系统页必须保留 MCP/SSH/诊断（技术区块原样收编）');
assert.ok(SYSTEM.includes('resetSystemConfirm'), '系统页必须含重置入口');
assert.ok(SYSTEM.includes('cleanupRooms'), '系统页必须含清理残留房间（工单15）');
assert.ok(FEED.includes("q:'watch_history'") === false, '观看历史清空走清除对话记录 sheet');
assert.ok(CLEAR.includes("q:'watch_history'") && CLEAR.includes("q:'drama_memory'"),
  '清除对话记录 sheet 必须并列观看历史/追剧记忆');
assert.ok(REC.includes('B.roomDestroy'), '清空全部对话必须走 room_destroy');

/* ── ⑤ 破坏性操作必过确认（红线） ── */
assert.ok(CLEAR.includes('expertPreviewOverlay'), '清除对话记录必须过确认 sheet（overlay）');
assert.ok(MDEL.includes('expertConfirm'), '删除模型必须过确认 sheet');
assert.ok(RSYS.indexOf('expertConfirm') >= 0 && RSYS.indexOf('expertConfirm', RSYS.indexOf('expertConfirm') + 1) > 0,
  '重置系统必须两步确认');
assert.ok(CLEAN.includes('expertConfirm'), '清理残留房间必须过确认');

/* ── ⑥ 全屏宿主：设置不再走抽屉 ── */
assert.ok(OPEN.includes('closeDrawer()'), 'openSettings 必须先关抽屉（齿轮在抽屉底部）');
assert.ok(OPEN.includes('settingsPane'), 'openSettings 必须渲染全屏 settingsPane');
assert.ok(!OPEN.includes("openDrawer('settings')"), 'openSettings 不得再走抽屉 settings 分支');
assert.ok(OPEN.includes("['brain','connect','scenes','a2a','caps','privacy','tech']"),
  'openSettings 必须清理旧 mv:set 折叠 key');

/* ── ⑦ 版本常量与检查更新 ── */
assert.ok(SRC.includes("MOV_APP_VERSION = '3.3.0'"), '版本常量必须与 build.gradle versionName 同步');
assert.ok(TREE.includes('MOV_APP_VERSION'), '一级页检查更新行必须展示版本常量');

/* ── ⑧ 外观三态 ── */
assert.ok(THEME.includes('light') && THEME.includes('dark') && THEME.includes('auto'),
  '外观页必须三选一（浅色/深色/跟随系统）');
assert.ok(SRC.includes("localStorage.setItem('mov_theme'"), '主题持久化必须写 mov_theme');

console.log('设置页工单14 ✓（一级 8 行 / 10 二级页分发 / 术语清零 / 迁移映射在案 / 破坏性操作确认闸 / 全屏宿主 / 版本常量）');
