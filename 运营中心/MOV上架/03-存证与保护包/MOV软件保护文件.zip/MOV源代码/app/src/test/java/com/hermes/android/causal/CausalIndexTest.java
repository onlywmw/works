package com.hermes.android.causal;

import org.json.JSONObject;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/**
 * CausalIndex 测试 — 哈希索引：原子入索引、count/lastTs 维护、关联强度钳制、衰减、序列化往返。
 */
public class CausalIndexTest {

    private static final long NOW = 1_800_000_000_000L;  // 固定基准时间

    @Test public void recordAddsThreeAtoms() {
        CausalIndex idx = new CausalIndex();
        idx.applyEvent(new CausalEvent("张三", "欠款", "李四"), NOW);
        assertEquals("三原子入索引", 3, idx.atoms().size());
        assertNotNull("主体可 O(1) 命中", idx.getByAtom("张三"));
        assertNotNull("谓词可命中", idx.getByAtom("欠款"));
        assertNotNull("客体可命中", idx.getByAtom("李四"));
        assertEquals("count 初始 1", 1, idx.getByAtom("张三").count);
    }

    @Test public void repeatRecordIncrementsCountAndUpdatesLastTs() {
        CausalIndex idx = new CausalIndex();
        idx.applyEvent(new CausalEvent("张三", "欠款", "李四"), NOW);
        idx.applyEvent(new CausalEvent("张三", "还款", "李四"), NOW + 1000);
        assertEquals("主体二次出现 count=2", 2, idx.getByAtom("张三").count);
        assertEquals("lastTs 更新为最近", NOW + 1000, idx.getByAtom("张三").lastTs);
        assertEquals("firstTs 保持首见", NOW, idx.getByAtom("张三").firstTs);
    }

    @Test public void addStrengthClampsToUnit() {
        CausalIndex idx = new CausalIndex();
        double s1 = idx.addStrength("张三", "李四", 0.3, NOW);
        assertEquals("首次增量 0.3", 0.3, s1, 1e-9);
        double s2 = idx.addStrength("张三", "李四", 0.5, NOW);
        assertEquals("累计 0.8", 0.8, s2, 1e-9);
        double s3 = idx.addStrength("张三", "李四", 0.9, NOW);
        assertEquals("钳制上限 1.0", 1.0, s3, 1e-9);
        double s4 = idx.addStrength("张三", "李四", -2.0, NOW);
        assertEquals("钳制下限 0.0", 0.0, s4, 1e-9);
    }

    @Test public void addStrengthSelfOrEmptyIgnored() {
        CausalIndex idx = new CausalIndex();
        assertEquals("同原子不加", 0, idx.addStrength("张三", "张三", 0.5, NOW), 1e-9);
        assertEquals("空原子不加", 0, idx.addStrength("", "李四", 0.5, NOW), 1e-9);
    }

    @Test public void decayFreshnessFollowsExponential() {
        CausalIndex idx = new CausalIndex();
        idx.applyEvent(new CausalEvent("张三", "欠款", "李四"), NOW);
        CausalIndex.AtomEntry a = idx.getByAtom("张三");
        double d0 = a.freshness(NOW);
        assertEquals("刚写入 freshness≈1", 1.0, d0, 0.05);
        double d7 = a.freshness(NOW + 7L * 86400000L);
        assertEquals("7 天 ≈ e^-0.7 ≈ 0.5", 0.497, d7, 0.02);
        double d23 = a.freshness(NOW + 25L * 86400000L);
        assertTrue("25 天 < 0.1", d23 < 0.1);
    }

    @Test public void staleAtomsDetectedAfterIdleWindow() {
        CausalIndex idx = new CausalIndex();
        idx.applyEvent(new CausalEvent("张三", "欠款", "李四"), NOW);
        assertTrue("7 天内非 stale", idx.staleAtoms(NOW).isEmpty());
        assertEquals("超 7 天判 stale", 3, idx.staleAtoms(NOW + 8L * 86400000L).size());
    }

    @Test public void removeAtomByLabelRemoves() {
        CausalIndex idx = new CausalIndex();
        idx.applyEvent(new CausalEvent("张三", "欠款", "李四"), NOW);
        idx.removeAtomByLabel("张三");
        assertNull("移除后不可命中", idx.getByAtom("张三"));
        assertNotNull("其余原子保留", idx.getByAtom("李四"));
    }

    @Test public void toJsonLoadRoundTrip() {
        CausalIndex idx = new CausalIndex();
        idx.setRoom("r1");
        idx.applyEvent(new CausalEvent("张三", "欠款", "李四"), NOW);
        idx.addStrength("张三", "李四", 0.3, NOW);
        idx.tagRule("张三", "r_debt");

        JSONObject json = idx.toJson();
        CausalIndex loaded = new CausalIndex();
        loaded.load(json);
        assertEquals("往返后原子数一致", 3, loaded.atoms().size());
        assertEquals("往返后 count 一致", 1, loaded.getByAtom("张三").count);
        assertEquals("往返后规则标记一致", 1, loaded.getByAtom("张三").rules.size());
        assertEquals("往返后关联 1 条", 1, loaded.links().size());
        assertEquals("往返后强度一致", 0.3, loaded.links().values().iterator().next().strength, 1e-9);
    }

    @Test public void loadFromNullIsSafe() {
        CausalIndex idx = new CausalIndex();
        idx.load(null);
        assertEquals("null 加载安全", 0, idx.atoms().size());
    }
}
