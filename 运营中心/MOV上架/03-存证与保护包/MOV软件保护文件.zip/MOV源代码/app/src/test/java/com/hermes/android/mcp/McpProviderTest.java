package com.hermes.android.mcp;

import static org.junit.Assert.*;

import com.hermes.android.agent.ToolRegistry.Tool;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * McpProvider 单测 — 多 server discover（工单25 幕一 D），零网络。
 *
 * 覆盖：discover 只注册 enabled 条目、多 server 各自注册、不可达 server 跳过。
 * store / client 均经构造函数注入 fake（记录型，非 mock 喂答案：
 * fake 只替代网络传输层，发现/过滤/注册逻辑走真实 McpProvider 代码）。
 */
public class McpProviderTest {

    /** 记录型 fake 客户端：按 url 脚本化健康状态与工具清单，记录健康检查调用。 */
    static class FakeClient extends McpClient {
        final Set<String> healthyUrls = new HashSet<>();
        final Map<String, JSONArray> toolsByUrl = new HashMap<>();
        final List<String> healthChecked = new ArrayList<>();

        @Override public boolean healthCheck(String serverUrl, String token) {
            healthChecked.add(serverUrl);
            return healthyUrls.contains(serverUrl);
        }

        @Override public JSONArray listTools(String serverUrl, String token) {
            return toolsByUrl.get(serverUrl);
        }
    }

    private static JSONArray toolList(String... names) {
        JSONArray arr = new JSONArray();
        for (String n : names) {
            try {
                arr.put(new JSONObject().put("name", n).put("description", "desc-" + n));
            } catch (Exception e) { throw new RuntimeException(e); }
        }
        return arr;
    }

    private static List<String> namesOf(List<Tool> tools) {
        List<String> names = new ArrayList<>();
        for (Tool t : tools) names.add(t.name);
        return names;
    }

    @Test public void discover_registersOnlyEnabledEntries() {
        McpServerStore store = new McpServerStore(new McpServerStoreTest.MemPrefs());
        McpServerStore.Entry on = store.add("http://on/mcp", "", McpServerStore.ORIGIN_MANUAL);
        McpServerStore.Entry off = store.add("http://off/mcp", "", McpServerStore.ORIGIN_MANUAL);
        store.setEnabled(off.id, false);

        FakeClient client = new FakeClient();
        client.healthyUrls.add("http://on/mcp");
        client.healthyUrls.add("http://off/mcp");
        client.toolsByUrl.put("http://on/mcp", toolList("alpha", "beta"));
        client.toolsByUrl.put("http://off/mcp", toolList("ghost"));

        List<Tool> tools = new McpProvider(store, client).discover();

        assertEquals("只注册 enabled 条目的工具",
                java.util.Arrays.asList("mcp.alpha", "mcp.beta"), namesOf(tools));
        assertFalse("停用条目的 url 不应发起健康检查",
                client.healthChecked.contains("http://off/mcp"));
    }

    @Test public void discover_disabledThenReenabled_picksUpAgain() {
        McpServerStore store = new McpServerStore(new McpServerStoreTest.MemPrefs());
        McpServerStore.Entry e = store.add("http://on/mcp", "", McpServerStore.ORIGIN_MARKET);
        store.setEnabled(e.id, false);

        FakeClient client = new FakeClient();
        client.healthyUrls.add("http://on/mcp");
        client.toolsByUrl.put("http://on/mcp", toolList("alpha"));

        McpProvider provider = new McpProvider(store, client);
        assertTrue("停用后 discover 为空", provider.discover().isEmpty());

        store.setEnabled(e.id, true);
        assertEquals("重新启用后 discover 注册",
                java.util.Arrays.asList("mcp.alpha"), namesOf(provider.discover()));
    }

    @Test public void discover_skipsUnreachableServer_keepsOthers() {
        McpServerStore store = new McpServerStore(new McpServerStoreTest.MemPrefs());
        store.add("http://down/mcp", "", McpServerStore.ORIGIN_MANUAL);
        store.add("http://up/mcp", "", McpServerStore.ORIGIN_MANUAL);

        FakeClient client = new FakeClient();
        client.healthyUrls.add("http://up/mcp");
        client.toolsByUrl.put("http://up/mcp", toolList("beta"));
        client.toolsByUrl.put("http://down/mcp", toolList("ghost"));

        List<Tool> tools = new McpProvider(store, client).discover();

        assertEquals("不可达 server 跳过，其余正常注册",
                java.util.Arrays.asList("mcp.beta"), namesOf(tools));
        assertTrue("enabled 条目都要做健康检查",
                client.healthChecked.contains("http://down/mcp"));
    }

    @Test public void discover_emptyStore_returnsEmpty() {
        FakeClient client = new FakeClient();
        List<Tool> tools = new McpProvider(
                new McpServerStore(new McpServerStoreTest.MemPrefs()), client).discover();
        assertTrue(tools.isEmpty());
        assertTrue("无条目不发起任何健康检查", client.healthChecked.isEmpty());
    }

    @Test public void discover_legacyMigration_feedsDiscover() {
        // 旧单条配置迁移为启用条目后，discover 直接接上（升级不丢接入）
        McpServerStoreTest.MemPrefs p = new McpServerStoreTest.MemPrefs();
        p.putString(McpServerStore.LEGACY_URL, "http://legacy/mcp");
        p.putString(McpServerStore.LEGACY_TOKEN, "legacy-tok");

        FakeClient client = new FakeClient();
        client.healthyUrls.add("http://legacy/mcp");
        client.toolsByUrl.put("http://legacy/mcp", toolList("alpha"));

        List<Tool> tools = new McpProvider(new McpServerStore(p), client).discover();
        assertEquals(java.util.Arrays.asList("mcp.alpha"), namesOf(tools));
    }
}
