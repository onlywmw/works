package com.hermes.android.browser;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

/** JsStringCodec.unescapeJsString：evaluateJavascript 返回的 JSON 字符串反解（HtmlViewer 编辑模式保存链路） */
public class JsStringCodecTest {

    @Test public void unescape_nullAndShort_returnNull() {
        assertNull(JsStringCodec.unescapeJsString(null));
        assertNull(JsStringCodec.unescapeJsString(""));
        assertNull(JsStringCodec.unescapeJsString("x"));
    }

    @Test public void unescape_stripsOuterQuotes() {
        assertEquals("abc", JsStringCodec.unescapeJsString("\"abc\""));
    }

    @Test public void unescape_commonEscapes() {
        // 模拟 evaluateJavascript 返回: "line1\nline2\ttab\"quote\"\\slash"
        String jsJson = "\"line1\\nline2\\ttab\\\"quote\\\"\\\\slash\"";
        assertEquals("line1\nline2\ttab\"quote\"\\slash",
                JsStringCodec.unescapeJsString(jsJson));
    }

    @Test public void unescape_unicodeEscape() {
        // 中文「中」= U+4E2D；evaluateJavascript 对非 ASCII 输出 unicode 转义
        // 注：Java 编译器对源码做 unicode 预处理，字面量需拼接绕过
        assertEquals("中文", JsStringCodec.unescapeJsString("\"\\" + "u4E2D\\" + "u6587\""));
    }

    @Test public void unescape_malformedUnicode_keepsLiteral() {
        // 残缺 unicode 转义不崩溃：不足 4 位时保留字面 u
        assertEquals("au", JsStringCodec.unescapeJsString("\"a\\" + "u\""));
    }

    @Test public void unescape_emptyJsonString_returnsEmpty() {
        assertEquals("", JsStringCodec.unescapeJsString("\"\""));
    }
}
