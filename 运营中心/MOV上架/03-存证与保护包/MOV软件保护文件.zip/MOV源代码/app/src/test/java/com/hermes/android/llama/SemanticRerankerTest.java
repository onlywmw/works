package com.hermes.android.llama;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.json.JSONObject;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * M3 语义召回实现测试（A9 靶点：cosine 排序 / 阈值过滤 / query 前缀 / 截断）。
 * 零网络：注入假 Transport（ctx null 跳过 A4 就绪检查）。
 * 变异靶：本文件断言排序与阈值——实现逻辑被变异（恒等/恒零/恒过）时必红。
 * 验收见 docs/PLAN_SEMANTIC_RECALL_2026-08-09.md §七 M3。
 */
public class SemanticRerankerTest {

    private static String embJson(int index, float... vals) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"object\":\"embedding\",\"index\":").append(index)
                .append(",\"embedding\":[");
        for (int i = 0; i < vals.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(vals[i]);
        }
        return sb.append("]}").toString();
    }

    @Test
    public void rerank_queryPrefixAdded_candidatesNot() throws Exception {
        String[] payload = new String[1];
        // query 向量 [1,0,0]；cand0 同向 sim=1.0（过），cand1 正交 sim=0（阈值滤掉）
        String raw = "{\"data\":[" + embJson(0, 1, 0, 0) + ","
                + embJson(1, 1, 0, 0) + ","
                + embJson(2, 0, 1, 0) + "]}";
        SemanticReranker rr = new SemanticReranker(null, (p, t) -> {
            payload[0] = p;
            return raw;
        });
        List<Integer> order = rr.rerank("睡眠不足", Arrays.asList("凌晨三点才睡", "今天天气好"));
        assertNotNull(order);
        assertEquals(1, order.size());
        assertEquals(0, order.get(0).intValue());
        // payload：input[0] 带 BGE 前缀，input[1..] 候选不带
        JSONObject p = new JSONObject(payload[0]);
        String q0 = p.getJSONArray("input").getString(0);
        assertNotNull(q0);
        if (!q0.startsWith(SemanticReranker.QUERY_PREFIX)) {
            throw new AssertionError("query 必须带 BGE 前缀, got: " + q0);
        }
        assertEquals("凌晨三点才睡", p.getJSONArray("input").getString(1));
        assertEquals("今天天气好", p.getJSONArray("input").getString(2));
    }

    @Test
    public void rerank_sortsByCosineDesc_thresholdFilters() throws Exception {
        // query [1,0,0]；cand0 (idx1) [0.8,0.6,0] sim=0.8；cand1 (idx2) [0,1,0] sim=0 滤；cand2 (idx3) [0.5,0.3,0] sim≈0.857
        String raw = "{\"data\":[" + embJson(0, 1, 0, 0) + ","
                + embJson(1, 0.8f, 0.6f, 0) + ","
                + embJson(2, 0, 1, 0) + ","
                + embJson(3, 0.5f, 0.3f, 0) + "]}";
        SemanticReranker rr = new SemanticReranker(null, (p, t) -> raw);
        List<Integer> order = rr.rerank("q", Arrays.asList("a", "b", "c"));
        assertNotNull(order);
        assertEquals("cand2 高相似在前，cand1 被阈值滤掉", Arrays.asList(2, 0), order);
    }

    @Test
    public void truncate_overMax_chopsTail_underMaxKeepsAll() {
        char[] longText = new char[SemanticReranker.MAX_EMBED_CHARS + 100];
        Arrays.fill(longText, '甲');
        String s = new String(longText);
        String t = SemanticReranker.truncate(s);
        assertEquals(SemanticReranker.MAX_EMBED_CHARS, t.length());
        assertEquals("超长截尾保留尾部", new String(longText, 100, SemanticReranker.MAX_EMBED_CHARS), t);
        assertEquals("短文本", SemanticReranker.truncate("短文本"));
        assertEquals("", SemanticReranker.truncate(null));
    }

    @Test
    public void transportThrows_returnsNull() {
        SemanticReranker rr = new SemanticReranker(null, (p, t) -> {
            throw new RuntimeException("net down");
        });
        assertNull(rr.rerank("q", Arrays.asList("a")));
    }

    @Test
    public void badResponse_returnsNull() {
        SemanticReranker rr = new SemanticReranker(null, (p, t) -> "not json");
        assertNull(rr.rerank("q", Arrays.asList("a")));
    }

    @Test
    public void emptyQueryOrTexts_returnsNull_beforeTransport() {
        final int[] calls = {0};
        SemanticReranker rr = new SemanticReranker(null, (p, t) -> {
            calls[0]++;
            return "{}";
        });
        assertNull(rr.rerank("", Arrays.asList("a")));
        assertNull(rr.rerank("  ", Arrays.asList("a")));
        assertNull(rr.rerank("q", null));
        assertNull(rr.rerank(null, Arrays.asList("a")));
        assertNull(rr.rerank("q", new ArrayList<>()));
        assertEquals("空入参不得触发 transport", 0, calls[0]);
    }
}
