package com.hermes.android.toolprovider;

import com.hermes.android.agent.ToolRegistry;

import org.junit.Test;

import java.io.File;
import java.util.List;

import static org.junit.Assert.*;

/**
 * OCR 工具骨架单测（零网络，零 Android 依赖路径）——元数据分级 + OOM 防线（模型存在判断纯 JVM）。
 */
public class OcrToolProviderTest {

    private ToolRegistry.Tool ocrTool() {
        OcrToolProvider p = new OcrToolProvider();
        List<ToolRegistry.Tool> tools = p.discover();
        assertEquals("只注册 1 个工具", 1, tools.size());
        return tools.get(0);
    }

    @Test public void ocrTool_metadataMatchesSpec() {
        ToolRegistry.Tool t = ocrTool();
        assertEquals("name", "ocr", t.name);
        assertEquals("level FAST", "FAST", t.manifest.level);
        assertEquals("toolset ocr", "ocr", t.toolset);
        assertEquals("access readonly", "readonly", t.access);
        assertFalse("sync=false（本地）", t.manifest.sync);
        assertEquals("timeoutSec 30", 30, t.timeoutSec);
        assertEquals("manifest timeoutMs 30000", 30000, t.manifest.timeoutMs);
        assertNotNull("checkFn 非空（模型+内存探测）", t.checkFn);
    }

    @Test public void hasModelFile_emptyDirFalse() {
        File dir = new File(System.getProperty("java.io.tmpdir"),
                "ocr_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 100000));
        dir.mkdirs();
        assertFalse("空目录 = 无模型", OcrToolProvider.hasModelFile(dir));
    }

    @Test public void hasModelFile_withFileTrue() throws Exception {
        File dir = new File(System.getProperty("java.io.tmpdir"),
                "ocr_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 100000));
        dir.mkdirs();
        new File(dir, "model.gguf").createNewFile();
        assertTrue("有模型文件 = 有模型", OcrToolProvider.hasModelFile(dir));
    }

    @Test public void hasModelFile_nullOrMissingDir() {
        assertFalse("null → false", OcrToolProvider.hasModelFile(null));
        assertFalse("不存在目录 → false", OcrToolProvider.hasModelFile(
                new File(System.getProperty("java.io.tmpdir"), "no_such_" + System.currentTimeMillis())));
    }
}
