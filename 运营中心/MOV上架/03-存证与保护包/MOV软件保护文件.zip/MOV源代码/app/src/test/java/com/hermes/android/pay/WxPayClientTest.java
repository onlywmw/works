package com.hermes.android.pay;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.json.JSONObject;
import org.junit.Test;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * 工单26 M1-2：WxPayClient 六态解析（fake transport 注入，零网络）。
 */
public class WxPayClientTest {

    private static final KeyPair KP = gen();
    private static final MerchantCreds CREDS =
            new MerchantCreds("1900000001", "SER123", "apiv3-secret", "wxb73491c14b5470e3", KP.getPrivate(), null);

    private static KeyPair gen() {
        try {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048);
            return g.generateKeyPair();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /** fake transport：按序出队回包；记录 Authorization 头与请求体（验签名/报文） */
    static class FakeTransport implements WxPayClient.HttpTransport {
        final Queue<WxPayClient.Reply> replies = new ArrayDeque<>();
        final java.util.List<String> auths = new java.util.ArrayList<>();
        final java.util.List<String> bodies = new java.util.ArrayList<>();
        FakeTransport(WxPayClient.Reply... rs) { for (WxPayClient.Reply r : rs) replies.add(r); }

        @Override public WxPayClient.Reply exec(String method, String url, String auth, String body)
                throws java.io.IOException {
            auths.add(auth);
            bodies.add(body);
            WxPayClient.Reply r = replies.poll();
            return r != null ? r : new WxPayClient.Reply(200, "{}");
        }
    }

    @Test
    public void 查单六态解析() throws Exception {
        assertState("SUCCESS", 200, "{\"trade_state\":\"SUCCESS\",\"transaction_id\":\"T001\",\"success_time\":\"2026-08-09T10:00:00+08:00\"}");
        assertState("USERPAYING", 200, "{\"trade_state\":\"USERPAYING\"}");
        assertState("NOTPAY", 200, "{\"trade_state\":\"NOTPAY\"}");
        assertState("CLOSED", 200, "{\"trade_state\":\"CLOSED\"}");
        assertErr("RESOURCE_NOT_EXISTS", 404, "{\"code\":\"RESOURCE_NOT_EXISTS\",\"message\":\"订单不存在\"}");
        assertErr("SIGN_ERROR", 401, "{\"code\":\"SIGN_ERROR\",\"message\":\"签名错误\"}");
    }

    private void assertState(String expect, int code, String body) throws Exception {
        FakeTransport t = new FakeTransport(new WxPayClient.Reply(code, body));
        AtomicReference<String> out = new AtomicReference<>();
        AtomicReference<String> err = new AtomicReference<>();
        CountDownLatch l = new CountDownLatch(1);
        new WxPayClient(CREDS, t).queryByOutTradeNo("MOVX", new WxPayClient.Cb<JSONObject>() {
            @Override public void ok(JSONObject v) { out.set(v.optString("trade_state")); l.countDown(); }
            @Override public void fail(String c, String m) { err.set(c); l.countDown(); }
        });
        assertTrue("回调超时", l.await(5, TimeUnit.SECONDS));
        assertEquals(expect, out.get());
        assertEquals(null, err.get());
        assertTrue("请求带 Authorization 签名头", t.auths.get(0).startsWith("WECHATPAY2-SHA256-RSA2048"));
    }

    private void assertErr(String expectCode, int code, String body) throws Exception {
        AtomicReference<String> err = new AtomicReference<>();
        CountDownLatch l = new CountDownLatch(1);
        new WxPayClient(CREDS, new FakeTransport(new WxPayClient.Reply(code, body)))
                .queryByOutTradeNo("MOVX", new WxPayClient.Cb<JSONObject>() {
                    @Override public void ok(JSONObject v) { l.countDown(); }
                    @Override public void fail(String c, String m) { err.set(c); l.countDown(); }
                });
        assertTrue("回调超时", l.await(5, TimeUnit.SECONDS));
        assertEquals(expectCode, err.get());
    }

    @Test
    public void native下单返回codeUrl() throws Exception {
        FakeTransport t = new FakeTransport(new WxPayClient.Reply(200,
                "{\"code_url\":\"weixin://wxpay/bizpayurl?pr=abc123\"}"));
        AtomicReference<String> out = new AtomicReference<>();
        AtomicReference<String> err = new AtomicReference<>();
        CountDownLatch l = new CountDownLatch(1);
        new WxPayClient(CREDS, t).nativeCreateOrder("验收包", "MOV202608090001", 1, "pkg-accept-001",
                new WxPayClient.Cb<String>() {
                    @Override public void ok(String v) { out.set(v); l.countDown(); }
                    @Override public void fail(String c, String m) { err.set(c + ":" + m); l.countDown(); }
                });
        assertTrue("回调超时", l.await(5, TimeUnit.SECONDS));
        assertEquals("weixin://wxpay/bizpayurl?pr=abc123", out.get());
        assertEquals(null, err.get());
        // 下单报文带必填 notify_url（微信不传直接 400）+ 金额 + E-12 appid
        assertTrue(t.bodies.get(0).contains("notify_url"));
        assertTrue(t.bodies.get(0).contains("\"total\":1"));
        assertTrue("body 必须带 appid（E-12：缺省微信直接报错）", t.bodies.get(0).contains("\"appid\":\"wxb73491c14b5470e3\""));
        assertTrue("下单 GET 之外应带签名头", t.auths.get(0).startsWith("WECHATPAY2"));
    }

    @Test
    public void 网络异常走NET错误() throws Exception {
        FakeTransport t = new FakeTransport() {
            @Override public WxPayClient.Reply exec(String method, String url, String auth, String body)
                    throws java.io.IOException {
                throw new java.io.IOException("connect refused");
            }
        };
        AtomicReference<String> err = new AtomicReference<>();
        CountDownLatch l = new CountDownLatch(1);
        new WxPayClient(CREDS, t).queryByOutTradeNo("MOVX", new WxPayClient.Cb<JSONObject>() {
            @Override public void ok(JSONObject v) { l.countDown(); }
            @Override public void fail(String c, String m) { err.set(c); l.countDown(); }
        });
        assertTrue("回调超时", l.await(5, TimeUnit.SECONDS));
        assertEquals("NET", err.get());
    }
}
