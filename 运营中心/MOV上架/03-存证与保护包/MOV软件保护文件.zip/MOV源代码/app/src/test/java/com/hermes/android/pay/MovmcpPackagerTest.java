package com.hermes.android.pay;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.hermes.android.vault.AesGcm;

import org.json.JSONObject;
import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;

import javax.crypto.spec.SecretKeySpec;

/**
 * 工单26 M3-1：MovmcpPackager——打包→解包往返 / 篡改验签败 / K 每单随机。
 */
public class MovmcpPackagerTest {

    private static final KeyPair KP = gen();
    private static final PrivateKey PRIV = KP.getPrivate();
    private static final PublicKey PUB = KP.getPublic();

    private static KeyPair gen() {
        try {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048);
            return g.generateKeyPair();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static JSONObject manifest() {
        JSONObject m = new JSONObject();
        try {
            m.put("id", "pkg-accept-001").put("name", "验收包").put("type", "config")
                    .put("sellerDeviceId", "mov-seller").put("orderId", "MOV202608090001");
        } catch (Exception ignored) {}
        return m;
    }

    @Test
    public void 打包解包往返byte级一致() throws Exception {
        byte[] plain = "hello-movmcp-配置内容".getBytes(StandardCharsets.UTF_8);
        MovmcpPackager.Pack p = MovmcpPackager.pack(manifest(), new JSONObject(), new JSONObject(),
                plain, PRIV);

        MovmcpPackager.Unpacked u = MovmcpPackager.unpack(p.zipBytes);
        assertNotNull(u.manifest);
        assertTrue("验签通过", MovmcpPackager.verify(u.payload,
                u.manifest.getBytes(StandardCharsets.UTF_8), u.signature, PUB));
        byte[] decrypted = AesGcm.decrypt(new SecretKeySpec(p.key, "AES"), u.payload);
        assertArrayEquals("解密后与原文 byte 级一致", plain, decrypted);
    }

    @Test
    public void 篡改payload一字节验签必败() throws Exception {
        byte[] plain = "tamper-me".getBytes(StandardCharsets.UTF_8);
        MovmcpPackager.Pack p = MovmcpPackager.pack(manifest(), new JSONObject(), new JSONObject(),
                plain, PRIV);
        MovmcpPackager.Unpacked u = MovmcpPackager.unpack(p.zipBytes);
        u.payload[0] ^= 0x01;   // 篡改 1 字节

        assertFalse("篡改 payload → 验签失败", MovmcpPackager.verify(u.payload,
                u.manifest.getBytes(StandardCharsets.UTF_8), u.signature, PUB));
    }

    @Test
    public void 篡改manifest验签必败() throws Exception {
        byte[] plain = "tamper-manifest".getBytes(StandardCharsets.UTF_8);
        MovmcpPackager.Pack p = MovmcpPackager.pack(manifest(), new JSONObject(), new JSONObject(),
                plain, PRIV);
        MovmcpPackager.Unpacked u = MovmcpPackager.unpack(p.zipBytes);

        String evil = u.manifest.replace("验收包", "evil");
        assertFalse("篡改 manifest → 验签失败", MovmcpPackager.verify(u.payload,
                evil.getBytes(StandardCharsets.UTF_8), u.signature, PUB));
    }

    @Test
    public void K每单随机() throws Exception {
        byte[] plain = "random-k".getBytes(StandardCharsets.UTF_8);
        MovmcpPackager.Pack p1 = MovmcpPackager.pack(manifest(), new JSONObject(), new JSONObject(), plain, PRIV);
        MovmcpPackager.Pack p2 = MovmcpPackager.pack(manifest(), new JSONObject(), new JSONObject(), plain, PRIV);
        assertFalse("两单 K 不等", java.util.Arrays.equals(p1.key, p2.key));
        assertTrue("K 长度 32B", p1.key.length == 32);
    }

    @Test
    public void 不同卖家密钥验签互斥() throws Exception {
        KeyPair other = gen();
        byte[] plain = "wrong-signer".getBytes(StandardCharsets.UTF_8);
        MovmcpPackager.Pack p = MovmcpPackager.pack(manifest(), new JSONObject(), new JSONObject(),
                plain, PRIV);
        MovmcpPackager.Unpacked u = MovmcpPackager.unpack(p.zipBytes);
        assertFalse("其他卖家公钥验签必败", MovmcpPackager.verify(u.payload,
                u.manifest.getBytes(StandardCharsets.UTF_8), u.signature, other.getPublic()));
    }

    @Test
    public void 缺件包拒收() {
        byte[] zip = new byte[0];
        try {
            MovmcpPackager.unpack(zip);
            assertTrue("空包应抛", false);
        } catch (Exception expected) {}
    }
}
