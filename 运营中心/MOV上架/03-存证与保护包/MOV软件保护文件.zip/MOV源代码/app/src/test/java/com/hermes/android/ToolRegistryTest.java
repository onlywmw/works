package com.hermes.android;

import static org.junit.Assert.*;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.json.JSONObject;
import org.junit.Test;

import java.util.Collections;
import java.util.HashSet;

/**
 * ToolRegistry file.read 分页单测:
 * 默认 32k 页 / offset 续读 / length 钳制 / 越界拒绝 / 显式页脚 (读完/未完)。
 * 背景: 2k 截断时代大脑读不全自产文件反问用户; 32k 截断时代大脑幻觉"文件超 32k"。
 */
public class ToolRegistryTest {

    /** 造一个 content 可配的 Tools (其余方法用不到) */
    private static AgentLoop.Tools toolsWith(String content) {
        return new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return "[]"; }
            @Override public String fileRead(String roomId, String path) { return content; }
            @Override public String fileWrite(String roomId, String path, String c) { return "OK:"; }
            @Override public String capabilityOf(String text) { return "unknown"; }
            @Override public String deviceCmd(String text) { return "ok"; }
            @Override public String packageApk(String roomId, String path, String appName) { return "ERR: 不支持"; }
            @Override public String shellExec(String cmd, int timeoutSec) { return "exit=0\nok"; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":true}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":true}"; }
        };
    }

    private static ToolRegistry registryWith(String content) {
        return ToolRegistry.build(toolsWith(content), "room1",
                HashSet::new, new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
    }

    private static ToolRegistry.Result read(ToolRegistry r, String json) throws Exception {
        ToolRegistry.Tool t = r.find("file.read");
        assertNotNull(t);
        return t.handler.run(new JSONObject(json));
    }

    private static String repeat(char c, int n) {
        StringBuilder sb = new StringBuilder(n);
        for (int i = 0; i < n; i++) sb.append(c);
        return sb.toString();
    }

    @Test
    public void read_smallFile_fullWithDoneFooter() throws Exception {
        ToolRegistry.Result res = read(registryWith("hello snake"), "{\"path\":\"a.html\"}");
        assertTrue(res.ok);
        assertTrue(res.text.startsWith("hello snake"));
        assertTrue("小文件必须给『读完』确定信号: " + res.text, res.text.contains("文件读完, 共 11 字符"));
    }

    @Test
    public void read_bigFile_firstPageHasContinueHint() throws Exception {
        String big = repeat('x', 40000);
        ToolRegistry.Result res = read(registryWith(big), "{\"path\":\"a.html\"}");
        assertTrue(res.ok);
        assertTrue("首页必须带续读指引: " + res.text.substring(res.text.length() - 80),
                res.text.contains("offset=32768"));
        assertTrue(res.text.contains("/40000 字符"));
    }

    @Test
    public void read_bigFile_secondPageCompletes() throws Exception {
        String big = repeat('y', 40000);
        ToolRegistry.Result res = read(registryWith(big), "{\"path\":\"a.html\",\"offset\":32768}");
        assertTrue(res.ok);
        assertTrue(res.text.contains("文件读完, 共 40000 字符"));
        /* 第二页正文长度 = 40000-32768 */
        assertTrue(res.text.startsWith(repeat('y', 100)));
    }

    @Test
    public void read_offsetBeyondRejected() throws Exception {
        ToolRegistry.Result res = read(registryWith("short"), "{\"path\":\"a.html\",\"offset\":999}");
        assertFalse(res.ok);
        assertTrue(res.text.contains("越界"));
    }

    @Test
    public void read_lengthClampedTo32k() throws Exception {
        String big = repeat('z', 100000);
        ToolRegistry.Result res = read(registryWith(big), "{\"path\":\"a.html\",\"length\":999999}");
        assertTrue(res.ok);
        /* 钳到 32768 → 继续提示 offset=32768 */
        assertTrue(res.text.contains("offset=32768"));
    }

    @Test
    public void read_errorPassthrough() throws Exception {
        ToolRegistry r = ToolRegistry.build(new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return "[]"; }
            @Override public String fileRead(String roomId, String path) { return "ERROR: 文件不存在"; }
            @Override public String fileWrite(String roomId, String path, String c) { return "OK:"; }
            @Override public String capabilityOf(String text) { return "unknown"; }
            @Override public String deviceCmd(String text) { return "ok"; }
            @Override public String packageApk(String roomId, String path, String appName) { return "ERR:"; }
            @Override public String shellExec(String cmd, int timeoutSec) { return "exit=0\nok"; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":true}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":true}"; }
        }, "room1", HashSet::new, new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
        ToolRegistry.Result res = read(r, "{\"path\":\"ghost.html\"}");
        assertFalse(res.ok);
        assertTrue(res.text.startsWith("ERROR:"));
    }

    @Test
    public void promptText_documentsPagination() {
        String p = registryWith("x").promptText();
        // M1a: promptText() 改用结构化 ParamDef 文档, 检查 offset/length 参数说明存在
        assertTrue("prompt 必须写明分页参数 offset: " + p, p.contains("offset"));
        assertTrue("prompt 必须写明分页参数 length: " + p, p.contains("length"));
        assertTrue("prompt 应有默认值说明", p.contains("32768"));
    }

    @Test
    public void promptText_containsBrowserChain_whenConnectWebClosed() {
        // P1 W2: checkFn 改窗口门控后，ConnectWeb 未开时 browser_* 完整文档也进 prompt
        // （否则 LLM 计划阶段看不到浏览器工具 → 计划跑偏）。旧 checkFn 依赖 getCurrent() 会在此过滤掉。
        com.hermes.android.browser.ToolRuntimeLimits.closeWindow();
        String p = registryWith("x").promptText();
        assertTrue("prompt 必须含 browser.open: " + p, p.contains("browser.open"));
        assertTrue("prompt 必须含 browser.snapshot", p.contains("browser.snapshot"));
        assertTrue("prompt 必须含 browser.read", p.contains("browser.read"));
        assertTrue("prompt 必须含 browser.click", p.contains("browser.click"));
    }

    // ==================== app.package 结构化解析 ====================

    /** 造一个 packageApk 返回值可配的注册表 */
    private static ToolRegistry registryWithPackageRes(String packageRes) {
        return ToolRegistry.build(new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return "[]"; }
            @Override public String fileRead(String roomId, String path) { return ""; }
            @Override public String fileWrite(String roomId, String path, String c) { return "OK:"; }
            @Override public String capabilityOf(String text) { return "unknown"; }
            @Override public String deviceCmd(String text) { return "ok"; }
            @Override public String packageApk(String roomId, String path, String appName) { return packageRes; }
            @Override public String shellExec(String cmd, int timeoutSec) { return "exit=0\nok"; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":true}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":true}"; }
        }, "room1", HashSet::new, new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
    }

    private static ToolRegistry.Result runPackage(ToolRegistry r, String path) throws Exception {
        ToolRegistry.Tool t = r.find("app.package");
        assertNotNull(t);
        return t.handler.run(new JSONObject("{\"path\":\"" + path + "\"}"));
    }

    @Test
    public void appPackage_jsonResultParsed() throws Exception {
        ToolRegistry.Result res = runPackage(registryWithPackageRes(
                "{\"ok\":true,\"file\":\"snake.apk\",\"msg\":\"snake.apk · 24KB\"}"), "snake.html");
        assertTrue(res.ok);
        assertEquals("snake.apk", res.produced);
        assertEquals("snake.apk · 24KB", res.text);
    }

    @Test
    public void appPackage_jsonErrorPropagated() throws Exception {
        ToolRegistry.Result res = runPackage(registryWithPackageRes(
                "{\"ok\":false,\"error\":\"模板不兼容, 请重新构建模板\"}"), "snake.html");
        assertFalse(res.ok);
        assertTrue(res.text.contains("模板不兼容"));
    }

    @Test
    public void appPackage_legacyFormatFallback() throws Exception {
        /* 旧文本格式仍兼容; 文件名含 " · " 时旧逻辑切错但不抛异常 */
        ToolRegistry.Result res = runPackage(registryWithPackageRes(
                "OK: snake.apk · 24KB · com.mov.test"), "snake.html");
        assertTrue(res.ok);
        assertEquals("snake.apk", res.produced);
        ToolRegistry.Result weird = runPackage(registryWithPackageRes(
                "OK: done"), "snake.html");
        assertTrue("无分隔符的旧格式不得抛异常", weird.ok);
        assertEquals("done", weird.produced);
    }

    // ==================== linuxAvailable 门控 (内嵌 Linux) ====================

    @Test
    public void linuxTools_hiddenWhenUnavailable() {
        ToolRegistry r = registryWith("x");
        assertNull("rootfs 未就绪不得注册 shell.exec", r.find("shell.exec"));
        // M1a: message.send 等工具描述引用了 shell.exec 作为替代方案，不检查 prompt 文本
    }

    @Test
    public void linuxTools_registeredWhenAvailable() throws Exception {
        ToolRegistry r = ToolRegistry.build(toolsWith("x"), "room1",
                HashSet::new, new ToolRegistry.DevicePolicy(Collections.<String>emptySet()), true);
        assertNotNull(r.find("shell.exec"));
        /* M-ARCH: file.push/file.pull 已退役 (房间即 /room, 零搬运) */
        assertNull("file.push 已退役", r.find("file.push"));
        assertNull("file.pull 已退役", r.find("file.pull"));
        assertFalse("prompt 不得再提 file.pull", r.promptText().contains("file.pull"));
        assertTrue("prompt 必须写明 cmd 参数: " + r.promptText(),
                r.promptText().contains("\"cmd\""));
        assertTrue("shell.exec desc 必须讲清 /room 世界观: " + r.promptText(),
                r.promptText().contains("/room"));
        ToolRegistry.Result res = r.find("shell.exec").handler.run(
                new JSONObject("{\"cmd\":\"uname -a\"}"));
        assertTrue(res.ok);
        assertTrue("shell 反馈应有 exit=0: " + res.aiFeedback, res.aiFeedback != null && res.aiFeedback.contains("exit=0"));
        ToolRegistry.Result empty = r.find("shell.exec").handler.run(new JSONObject("{}"));
        assertFalse("空 cmd 应拒绝", empty.ok);
    }

    // ═══════════════════════════════════════════════════════════
    // FUSION F2: Manifest 注册表元数据 (level/sync/timeoutMs)
    // ═══════════════════════════════════════════════════════════

    @Test
    public void manifest_legacyConstructorDefaults() {
        // 旧 5 参构造保持兼容：默认 SLOW / 非同步 / 30s
        ToolRegistry.Manifest m = new ToolRegistry.Manifest("写文件", "low", "写入文件", true, "io");
        assertEquals("旧构造 level 默认 SLOW", "SLOW", m.level);
        assertFalse("旧构造 sync 默认 false", m.sync);
        assertEquals("旧构造 timeoutMs 默认 30000", 30000, m.timeoutMs);
    }

    @Test
    public void manifest_fullConstructorAssigns() {
        ToolRegistry.Manifest m = new ToolRegistry.Manifest(
                "查火车票", "low", "查 12306 火车票", false, "io", "FAST", true, 8000);
        assertEquals("FAST", m.level);
        assertTrue(m.sync);
        assertEquals(8000, m.timeoutMs);
        assertEquals("查火车票", m.title);
    }

    @Test
    public void fastCards_registeredInToolRegistry() {
        // FastSceneProvider 随 build 自动注册，8 张场景卡全进同表
        ToolRegistry r = ToolRegistry.build(toolsWith("x"), "room1",
                HashSet::new, new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
        ToolRegistry.Tool train = r.find("train_search");
        assertNotNull("train_search 应注册", train);
        assertEquals("level FAST", "FAST", train.manifest.level);
        assertTrue("train sync", train.manifest.sync);
        assertNotNull("music_search 应注册", r.find("music_search"));
        assertNotNull("face_search_drama 应注册", r.find("face_search_drama"));
        assertNotNull("mayi_latest 应注册", r.find("mayi_latest"));
        assertNotNull("check_drama_updates 应注册", r.find("check_drama_updates"));
    }

    // ═══════════════════════════════════════════════════════════
    // FUSION F4: intentPromptText — 意图分类器专用工具清单
    // ═══════════════════════════════════════════════════════════

    @Test
    public void intentPromptText_listsFastCards() {
        ToolRegistry r = ToolRegistry.build(toolsWith("x"), "room1",
                HashSet::new, new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
        String p = r.intentPromptText();
        assertTrue("应含 train_search: " + p, p.contains("train_search"));
        assertTrue("应含 music_search", p.contains("music_search"));
        assertTrue("应含记忆工具 face_history", p.contains("face_history"));
        assertTrue("应标注可直达", p.contains("可直达"));
        assertTrue("应含专家模式工具列表", p.contains("专家模式"));
        // 意图分类器不需要 tool.execute 调用格式（那是慢脑 AgentLoop 的）
        assertFalse("不应含 tool.execute 调用格式", p.contains("tool.execute"));
        assertFalse("不应含 args JSON 格式", p.contains("\"action\":\"tool.execute\""));
    }

    @Test
    public void intentPromptText_fastCardsFirstThenSlow() {
        ToolRegistry r = ToolRegistry.build(toolsWith("x"), "room1",
                HashSet::new, new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
        String p = r.intentPromptText();
        // FAST 场景卡区在 SLOW 工具名列表之前
        int fastIdx = p.indexOf("可直达");
        int slowIdx = p.indexOf("专家模式");
        assertTrue("可直达区应在专家模式前", fastIdx >= 0 && slowIdx > fastIdx);
    }

    // ═══════════════════════════════════════════════════════════
    // 批2: 动态技能工具注册（registerDynamicTool）
    // ═══════════════════════════════════════════════════════════

    @Test
    public void registerDynamicTool_registersAndFindable() throws Exception {
        ToolRegistry r = ToolRegistry.build(toolsWith("x"), "room1",
                HashSet::new, new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
        r.registerDynamicTool("skill.echo", "回显输入",
                args -> new ToolRegistry.Result(true, "echo:" + args.optString("text")));
        ToolRegistry.Tool t = r.find("skill.echo");
        assertNotNull("动态技能工具应注册", t);
        assertEquals("回显输入", t.desc);
        ToolRegistry.Result res = t.handler.run(new JSONObject("{\"text\":\"hi\"}"));
        assertTrue(res.ok);
        assertEquals("echo:hi", res.text);
    }
}
