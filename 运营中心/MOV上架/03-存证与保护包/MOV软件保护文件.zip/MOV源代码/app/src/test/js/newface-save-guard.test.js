/* ============================================================
   newface-save-guard 防回归测试（node）
   跑法: node app/src/test/js/newface-save-guard.test.js
   工单13 断点5: 新建模型保存必须校验 API Key 非空(与测连接同口径),
   否则新人可保存空 key 模型 → 派活必失败(虽然报错已明确, 仍应拦截在保存前)。
   编辑保存(editId 非空)允许 key 留空 —— 服务端 mergeOnUpdate 保留旧 key。
   ============================================================ */
'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const SRC = fs.readFileSync(path.join(__dirname, '../../main/assets/js/newface.js'), 'utf8');

function extractFn(name) {
  const i = SRC.indexOf('function ' + name + '(');
  assert.ok(i >= 0, '找不到 function ' + name);
  let depth = 0, j = SRC.indexOf('{', i);
  for (let k = j; k < SRC.length; k++) {
    if (SRC[k] === '{') depth++;
    else if (SRC[k] === '}') { depth--; if (depth === 0) return SRC.slice(i, k + 1); }
  }
  throw new Error(name + ' 函数体未闭合');
}

const SAVE = extractFn('_msave');
const TEST = extractFn('_mtestForm');

assert.ok(SAVE.includes('先填 API Key'),
  '_msave 必须校验 API Key 非空(否则空 key 模型可保存, 派活必失败)');
assert.ok(SAVE.includes('!_mState.editId'),
  '_msave 校验仅限新建(编辑 key 留空 = 不改, 服务端保留旧 key)');
assert.ok(TEST.includes('先填 API Key'),
  '_mtestForm 的测连接校验仍在(基线)');

console.log('_msave 空 key 校验 ✓（新建拦截 / 编辑放行留空）');
