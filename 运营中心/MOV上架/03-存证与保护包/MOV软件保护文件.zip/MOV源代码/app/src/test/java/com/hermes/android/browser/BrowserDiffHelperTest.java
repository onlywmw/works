package com.hermes.android.browser;
import com.hermes.android.browser.BrowserDiffHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

/**
 * BrowserDiffHelper 单测 — 全分支覆盖。
 */
public class BrowserDiffHelperTest {

    @Test public void testUnchanged() throws JSONException {
        JSONObject r = BrowserDiffHelper.diff("hello world", "hello world");
        assertTrue("相同内容应标记 unchanged", r.optBoolean("unchanged"));
    }

    @Test public void testUnchanged_whitespaceFolded() throws org.json.JSONException {
        JSONObject r = BrowserDiffHelper.diff("hello   world", "hello world");
        assertTrue("whitespace 折叠后相同应 unchanged", r.optBoolean("unchanged"));
    }

    @Test public void testAddedLines() throws org.json.JSONException {
        JSONObject r = BrowserDiffHelper.diff("line1\nline2", "line1\nline2\nline3");
        assertFalse("内容不同不应 unchanged", r.optBoolean("unchanged"));
        JSONArray added = r.optJSONArray("added");
        assertNotNull(added);
        assertEquals(1, added.length());
        assertTrue(added.optString(0).contains("line3"));
        JSONArray removed = r.optJSONArray("removed");
        assertEquals(0, removed.length());
    }

    @Test public void testRemovedLines() throws org.json.JSONException {
        JSONObject r = BrowserDiffHelper.diff("line1\nline2\nline3", "line1\nline3");
        JSONArray removed = r.optJSONArray("removed");
        assertEquals(1, removed.length());
        assertTrue(removed.optString(0).contains("line2"));
        JSONArray added = r.optJSONArray("added");
        assertEquals(0, added.length());
    }

    @Test public void testBothAddedAndRemoved() throws org.json.JSONException {
        JSONObject r = BrowserDiffHelper.diff("A\nB\nC", "B\nC\nD");
        JSONArray added = r.optJSONArray("added");
        JSONArray removed = r.optJSONArray("removed");
        assertEquals(1, added.length());
        assertEquals(1, removed.length());
        assertTrue(added.optString(0).contains("D"));
        assertTrue(removed.optString(0).contains("A"));
    }

    @Test public void testDuplicateLines() throws org.json.JSONException {
        JSONObject r = BrowserDiffHelper.diff("A\nA\nB", "A\nB\nB");
        // 去重后行集合相同 → unchanged
        assertTrue("去重后行集合相同应 unchanged", r.optBoolean("unchanged"));
    }

    @Test public void testNullInputs() throws org.json.JSONException {
        JSONObject r = BrowserDiffHelper.diff(null, null);
        assertTrue(r.optBoolean("unchanged"));
        r = BrowserDiffHelper.diff(null, "hello");
        assertFalse(r.optBoolean("unchanged"));
        assertEquals(1, r.optJSONArray("added").length());
    }

    @Test public void testTruncated() throws org.json.JSONException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 200; i++) sb.append("line").append(i).append("\n");
        JSONObject r = BrowserDiffHelper.diff("", sb.toString());
        assertTrue("超量应 truncated", r.optBoolean("truncated"));
    }

    @Test public void testAddedCharsCount() throws org.json.JSONException {
        JSONObject r = BrowserDiffHelper.diff("", "hello world again");
        int addedChars = r.optInt("added_chars");
        assertTrue("added_chars > 0", addedChars > 0);
    }

    @Test public void testRemovedCharsCount() throws org.json.JSONException {
        JSONObject r = BrowserDiffHelper.diff("hello world again", "");
        int removedChars = r.optInt("removed_chars");
        assertTrue("removed_chars > 0", removedChars > 0);
    }

    @Test public void testWhitespaceFolding() throws org.json.JSONException {
        // 行内空白折叠 (tab/space → 单空格)，换行保留
        String s1 = "hello\t\tworld\nfoo   bar";
        String s2 = "hello world\nfoo bar";
        JSONObject r = BrowserDiffHelper.diff(s1, s2);
        assertTrue("行内空白折叠后应 unchanged", r.optBoolean("unchanged"));
    }

    @Test public void testLongLineClippedInPack() throws org.json.JSONException {
        List<String> lines = Arrays.asList("a".repeat(250));
        JSONObject packed = BrowserDiffHelper.packLines(lines);
        JSONArray arr = packed.optJSONArray("lines");
        assertTrue(arr.optString(0).endsWith("..."));
        assertTrue(arr.optString(0).length() <= 200);
    }

    @Test public void testEmptyStrings() throws org.json.JSONException {
        JSONObject r = BrowserDiffHelper.diff("", "");
        assertTrue("空字符串应 unchanged", r.optBoolean("unchanged"));
        // unchanged 时不包含 added/removed 字段
    }
}
