package com.hermes.android.context;

import org.json.JSONObject;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * ContextSnapshot — 不可变值对象 + JSON 序列化测试。
 */
public class ContextSnapshotTest {

    @Test
    public void builder_constructsImmutableSnapshot() {
        ContextSnapshot s = new ContextSnapshot.Builder()
                .wifiSsid("HomeWiFi")
                .batteryLevel(85)
                .isCharging(true)
                .screenOn(true)
                .foregroundApp("com.hermes.android")
                .capturedAtMs(1700000000000L)
                .build();

        assertEquals("HomeWiFi", s.wifiSsid);
        assertEquals(Integer.valueOf(85), s.batteryLevel);
        assertTrue(s.isCharging);
        assertTrue(s.screenOn);
        assertEquals("com.hermes.android", s.foregroundApp);
        assertEquals(1700000000000L, s.capturedAtMs);
    }

    @Test
    public void nullFields_permitted() {
        ContextSnapshot s = new ContextSnapshot.Builder().build();

        assertNull(s.wifiSsid);
        assertNull(s.batteryLevel);
        assertFalse(s.isCharging);
        assertFalse(s.screenOn);
        assertNull(s.foregroundApp);
    }

    @Test
    public void equals_sameFields_true() {
        ContextSnapshot a = new ContextSnapshot.Builder()
                .wifiSsid("WiFi").batteryLevel(50).isCharging(false)
                .screenOn(true).foregroundApp("app.x").build();
        ContextSnapshot b = new ContextSnapshot.Builder()
                .wifiSsid("WiFi").batteryLevel(50).isCharging(false)
                .screenOn(true).foregroundApp("app.x").build();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void equals_differentWifi_false() {
        ContextSnapshot a = new ContextSnapshot.Builder().wifiSsid("A").batteryLevel(50).build();
        ContextSnapshot b = new ContextSnapshot.Builder().wifiSsid("B").batteryLevel(50).build();
        assertNotEquals(a, b);
    }

    @Test
    public void equals_differentBattery_false() {
        ContextSnapshot a = new ContextSnapshot.Builder().batteryLevel(80).build();
        ContextSnapshot b = new ContextSnapshot.Builder().batteryLevel(20).build();
        assertNotEquals(a, b);
    }

    @Test
    public void derive_preservesFields() {
        ContextSnapshot base = new ContextSnapshot.Builder()
                .wifiSsid("WiFi").batteryLevel(50).isCharging(true)
                .screenOn(false).foregroundApp("app.x").build();

        ContextSnapshot derived = base.derive().batteryLevel(60).build();

        assertEquals("WiFi", derived.wifiSsid);       // unchanged
        assertEquals(Integer.valueOf(60), derived.batteryLevel); // overwritten
        assertTrue(derived.isCharging);                // unchanged
        assertFalse(derived.screenOn);                 // unchanged
        assertEquals("app.x", derived.foregroundApp);  // unchanged
    }

    @Test
    public void toJson_includesNonNullFields() {
        ContextSnapshot s = new ContextSnapshot.Builder()
                .wifiSsid("TestWiFi")
                .batteryLevel(42)
                .isCharging(true)
                .screenOn(true)
                .capturedAtMs(1700000000000L)
                .build();

        JSONObject json = s.toJson();

        assertEquals("TestWiFi", json.optString("wifi_ssid"));
        assertEquals(42, json.optInt("battery_level"));
        assertTrue(json.optBoolean("is_charging"));
        assertTrue(json.optBoolean("screen_on"));
        assertEquals(1700000000000L, json.optLong("captured_at_ms"));
    }

    @Test
    public void toJson_omitsNullWifiSsid() {
        ContextSnapshot s = new ContextSnapshot.Builder()
                .batteryLevel(30).isCharging(false).screenOn(false).build();

        JSONObject json = s.toJson();
        assertFalse(json.has("wifi_ssid"));
        assertFalse(json.has("foreground_app"));
    }

    @Test
    public void toJson_nullBatteryLevel_serializesAsNull() {
        ContextSnapshot s = new ContextSnapshot.Builder()
                .batteryLevel(null).build();

        JSONObject json = s.toJson();
        assertTrue(json.isNull("battery_level"));
    }
}
