package com.hermes.android.agent;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * M5 安全验收 §3: 产物越界拒收 — HeavyWorker.fromTaskResult 输出上限校验。
 * 产物超 maxTokens×4 → OUTPUT_TOO_LARGE 拒绝; 限内放行; failed/cancelled 语义保留。
 */
public class HeavyWorkerOutputTest {

    @Test public void outputOverMaxTokens_rejected() {
        HermesClient.TaskResult r = new HermesClient.TaskResult(
                HermesClient.STATUS_DONE, new String(new char[1000]), null);
        Worker.WorkerResult wr = HeavyWorker.fromTaskResult(r, 100);   // 限 100 token → 400 字符
        assertFalse("越界产物必须拒收", wr.ok);
        assertEquals(Worker.WorkerResult.OUTPUT_TOO_LARGE, wr.errorCode);
        assertTrue(wr.errorMsg.contains("maxTokens"));
    }

    @Test public void outputWithinLimit_accepted() {
        HermesClient.TaskResult r = new HermesClient.TaskResult(
                HermesClient.STATUS_DONE, "short output", null);
        Worker.WorkerResult wr = HeavyWorker.fromTaskResult(r, 100);
        assertTrue("限内产物放行", wr.ok);
        assertEquals("short output", wr.text);
    }

    @Test public void outputEmpty_doneAccepted() {
        HermesClient.TaskResult r = new HermesClient.TaskResult(HermesClient.STATUS_DONE, "", null);
        Worker.WorkerResult wr = HeavyWorker.fromTaskResult(r, 100);
        assertTrue(wr.ok);
    }

    @Test public void failedStatus_keepsError() {
        HermesClient.TaskResult r = new HermesClient.TaskResult(
                HermesClient.STATUS_FAILED, null, "执行失败");
        Worker.WorkerResult wr = HeavyWorker.fromTaskResult(r, 100);
        assertFalse(wr.ok);
        assertTrue(wr.errorMsg.contains("执行失败"));
    }

    @Test public void cancelledStatus_keepsCancelled() {
        HermesClient.TaskResult r = new HermesClient.TaskResult(
                HermesClient.STATUS_CANCELLED, null, null);
        Worker.WorkerResult wr = HeavyWorker.fromTaskResult(r, 100);
        assertFalse(wr.ok);
        assertEquals(Worker.WorkerResult.CANCELLED, wr.errorCode);
    }
}
