package com.hermes.android.workflow;

import org.json.JSONObject;
import org.junit.Test;

import java.util.Calendar;

import static org.junit.Assert.*;

/**
 * 5 条件真行为断言（纯 JVM，time 用 GMT 固定时区可控）。
 */
public class ConditionEvaluatorTest {

    /** 构造设备时区 2026-08-01 HH:mm 的 epoch（与 evaluate 默认时区一致） */
    private static long at(String hhmm) {
        Calendar c = Calendar.getInstance();
        c.set(2026, Calendar.AUGUST, 1,
                Integer.parseInt(hhmm.split(":")[0]), Integer.parseInt(hhmm.split(":")[1]), 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private static JSONObject cond(String type) {
        try { return new JSONObject().put("type", type); } catch (Exception e) { throw new RuntimeException(e); }
    }

    private static Snapshot snap(long now, String url, String text, int count, String presentSel) {
        return new Snapshot(now, url, text, count,
                sel -> sel != null && sel.equals(presentSel));
    }

    // ── time ──
    @Test public void time_inRange() {
        JSONObject c = cond("time");
        try { c.put("start", "09:00").put("end", "17:00"); } catch (Exception e) {}
        Snapshot in = snap(at("09:30"), null, null, 0, null);
        assertTrue(ConditionEvaluator.evaluate(c, in));
    }
    @Test public void time_outOfRange() {
        JSONObject c = cond("time");
        try { c.put("start", "09:00").put("end", "17:00"); } catch (Exception e) {}
        Snapshot out = snap(at("18:00"), null, null, 0, null);
        assertFalse(ConditionEvaluator.evaluate(c, out));
    }
    @Test public void time_crossMidnight() {
        JSONObject c = cond("time");
        try { c.put("start", "22:00").put("end", "06:00"); } catch (Exception e) {}
        assertTrue(ConditionEvaluator.evaluate(c, snap(at("23:30"), null, null, 0, null)));
        assertTrue(ConditionEvaluator.evaluate(c, snap(at("02:00"), null, null, 0, null)));
        assertFalse(ConditionEvaluator.evaluate(c, snap(at("12:00"), null, null, 0, null)));
    }
    @Test public void time_invert() {
        JSONObject c = cond("time");
        try { c.put("start", "09:00").put("end", "17:00").put("invert", true); } catch (Exception e) {}
        Snapshot out = snap(at("18:00"), null, null, 0, null);
        assertTrue("invert 应反转", ConditionEvaluator.evaluate(c, out));
    }

    // ── element ──
    @Test public void element_exists() {
        JSONObject c = cond("element");
        try { c.put("selector", "#result"); } catch (Exception e) {}
        assertTrue(ConditionEvaluator.evaluate(c, snap(at("09:00"), null, null, 0, "#result")));
        assertFalse(ConditionEvaluator.evaluate(c, snap(at("09:00"), null, null, 0, "#loading")));
    }

    // ── text ──
    @Test public void text_contains() {
        JSONObject c = cond("text");
        try { c.put("pattern", "出票"); } catch (Exception e) {}
        assertTrue(ConditionEvaluator.evaluate(c, snap(at("09:00"), null, "订单已出票", 0, null)));
        assertFalse(ConditionEvaluator.evaluate(c, snap(at("09:00"), null, "订单已取消", 0, null)));
    }

    // ── url ──
    @Test public void url_contains() {
        JSONObject c = cond("url");
        try { c.put("pattern", "/vodplay/"); } catch (Exception e) {}
        assertTrue(ConditionEvaluator.evaluate(c, snap(at("09:00"), "https://x.com/vodplay/1.html", null, 0, null)));
        assertFalse(ConditionEvaluator.evaluate(c, snap(at("09:00"), "https://x.com/voddetail/1.html", null, 0, null)));
    }

    // ── count ──
    @Test public void count_minReached() {
        JSONObject c = cond("count");
        try { c.put("min", 3); } catch (Exception e) {}
        assertTrue(ConditionEvaluator.evaluate(c, snap(at("09:00"), null, null, 3, null)));
        assertFalse(ConditionEvaluator.evaluate(c, snap(at("09:00"), null, null, 2, null)));
    }

    // ── 第三幕：条件扩展 9 个（正反两例） ──

    private static Snapshot fullSnap(int battery, boolean charging, boolean screenOn, String net,
                                     String fg, long lastRunAt, java.util.Map<String, String> vars,
                                     java.util.function.Function<String, Integer> elCount) {
        return new Snapshot(at("09:00"), "https://x.com", "text", 0, sel -> false,
                battery, charging, screenOn, net, fg, lastRunAt, vars, elCount);
    }

    private static JSONObject c(String type) { return cond(type); }

    @Test public void battery_range() throws Exception {
        JSONObject q = c("battery_range");
        q.put("min", 20).put("max", 80);
        assertTrue("50 在区间", ConditionEvaluator.evaluate(q, fullSnap(50, false, false, null, null, 0, null, null)));
        assertFalse("10 低于区间", ConditionEvaluator.evaluate(q, fullSnap(10, false, false, null, null, 0, null, null)));
        assertFalse("缺数据(-1) FAIL", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, null, null, 0, null, null)));
    }

    @Test public void network_type() throws Exception {
        JSONObject q = c("network_type");
        q.put("net", "wifi");
        assertTrue("wifi 命中", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, "wifi", null, 0, null, null)));
        assertFalse("mobile 不命中", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, "mobile", null, 0, null, null)));
        assertFalse("缺数据 FAIL", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, null, null, 0, null, null)));
    }

    @Test public void app_foreground() throws Exception {
        JSONObject q = c("app_foreground");
        q.put("package", "com.example.shop");
        assertTrue("前台命中", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, null, "com.example.shop", 0, null, null)));
        assertFalse("其他 App 不命中", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, null, "com.other", 0, null, null)));
    }

    @Test public void last_run_ago() throws Exception {
        JSONObject q = c("last_run_ago");
        q.put("withinMinutes", 5);
        assertTrue("2 分钟前在窗口内", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, null, null, at("08:58"), null, null)));
        assertFalse("10 分钟前超出", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, null, null, at("08:50"), null, null)));
        assertFalse("未知(0) FAIL", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, null, null, 0, null, null)));
    }

    @Test public void day_of_week_in() throws Exception {
        // 2026-08-01 是周六（ISO dow=6）
        JSONObject q = c("day_of_week_in");
        q.put("days", new org.json.JSONArray().put(6));
        assertTrue("周六命中", ConditionEvaluator.evaluate(q, snap(at("09:00"), null, null, 0, null)));
        JSONObject q2 = c("day_of_week_in");
        q2.put("days", new org.json.JSONArray().put(1).put(2));
        assertFalse("周一/周二不命中周六", ConditionEvaluator.evaluate(q2, snap(at("09:00"), null, null, 0, null)));
    }

    @Test public void is_charging() {
        assertTrue(ConditionEvaluator.evaluate(c("is_charging"), fullSnap(-1, true, false, null, null, 0, null, null)));
        assertFalse(ConditionEvaluator.evaluate(c("is_charging"), fullSnap(-1, false, false, null, null, 0, null, null)));
    }

    @Test public void screen_is_on() {
        assertTrue(ConditionEvaluator.evaluate(c("screen_is_on"), fullSnap(-1, false, true, null, null, 0, null, null)));
        assertFalse(ConditionEvaluator.evaluate(c("screen_is_on"), fullSnap(-1, false, false, null, null, 0, null, null)));
    }

    @Test public void element_count() throws Exception {
        JSONObject q = c("element_count");
        q.put("selector", "#list").put("min", 3);
        java.util.function.Function<String, Integer> cnt = sel -> "#list".equals(sel) ? 3 : 0;
        assertTrue("3 个元素 ≥3", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, null, null, 0, null, cnt)));
        assertFalse("2 个 <3", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, null, null, 0, null, sel -> 2)));
        assertFalse("缺数据(-1) FAIL", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, null, null, 0, null, null)));
    }

    @Test public void variable_equal() throws Exception {
        JSONObject q = c("variable_equal");
        q.put("key", "status").put("value", "paid");
        java.util.Map<String, String> vars = new java.util.HashMap<>();
        vars.put("status", "paid");
        assertTrue("变量相等", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, null, null, 0, vars, null)));
        assertFalse("变量不等", ConditionEvaluator.evaluate(q, fullSnap(-1, false, false, null, null, 0, null, null)));
    }

    // ── AND 组合 ──
    @Test public void evaluateAll_andCombined() {
        JSONObject c1 = cond("text");
        try { c1.put("pattern", "A"); } catch (Exception e) {}
        JSONObject c2 = cond("url");
        try { c2.put("pattern", "/x/"); } catch (Exception e) {}
        org.json.JSONArray both = new org.json.JSONArray().put(c1).put(c2);
        Snapshot ok = snap(at("09:00"), "https://x.com/x/1", "A", 0, null);
        assertTrue(ConditionEvaluator.evaluateAll(both, ok));
        Snapshot urlMiss = snap(at("09:00"), "https://y.com", "A", 0, null);
        assertFalse(ConditionEvaluator.evaluateAll(both, urlMiss));
    }
}
