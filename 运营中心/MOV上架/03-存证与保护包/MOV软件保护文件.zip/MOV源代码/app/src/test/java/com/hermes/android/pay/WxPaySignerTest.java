package com.hermes.android.pay;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.util.Base64;

/**
 * 工单26 M1-1：微信 API v3 签名——固定向量签名可验签回环；篡改必败。
 */
public class WxPaySignerTest {

    private static final KeyPair KP = gen();
    private static final PrivateKey PRIV = KP.getPrivate();
    private static final PublicKey PUB = KP.getPublic();

    private static KeyPair gen() {
        try {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048);
            return g.generateKeyPair();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private boolean verify(String msg, String sigB64) throws Exception {
        Signature v = Signature.getInstance("SHA256withRSA");
        v.initVerify(PUB);
        v.update(msg.getBytes(StandardCharsets.UTF_8));
        return v.verify(Base64.getDecoder().decode(sigB64));
    }

    @Test
    public void 固定向量签名可验签回环() throws Exception {
        long ts = 1700000000L;
        String nonce = "fixed-nonce-123";
        String body = "{\"mchid\":\"1900000001\",\"amount\":{\"total\":1}}";
        String sig = WxPaySigner.sign(PRIV, "POST", "/v3/pay/transactions/native", ts, nonce, body);

        String expectMsg = "POST\n/v3/pay/transactions/native\n1700000000\nfixed-nonce-123\n" + body + "\n";
        assertTrue("签名串可被公钥验签", verify(expectMsg, sig));
        assertFalse("篡改 body 一字节 → 验签失败",
                verify(expectMsg.replace("total\":1", "total\":2"), sig));
        assertFalse("篡改 timestamp → 验签失败",
                verify(expectMsg.replace("1700000000", "1700000001"), sig));
    }

    @Test
    public void get请求body为空签名串末尾仍有换行() throws Exception {
        long ts = 1700000001L;
        String sig = WxPaySigner.sign(PRIV, "GET", "/v3/pay/transactions/out-trade-no/MOV1", ts, "n2", null);
        assertTrue(verify("GET\n/v3/pay/transactions/out-trade-no/MOV1\n1700000001\nn2\n\n", sig));
    }

    @Test
    public void authHeader字段与顺序() {
        String h = WxPaySigner.authHeader("mch1", "ser1", "SIG", 1700000000L, "nonce1");
        assertTrue(h.startsWith("WECHATPAY2-SHA256-RSA2048 "));
        assertTrue(h.contains("mchid=\"mch1\""));
        assertTrue(h.contains("serial_no=\"ser1\""));
        assertTrue(h.contains("nonce_str=\"nonce1\""));
        assertTrue(h.contains("timestamp=\"1700000000\""));
        assertTrue(h.contains("signature=\"SIG\""));
        assertEquals(1, count(h, "WECHATPAY2-SHA256-RSA2048"));
    }

    private static int count(String s, String sub) {
        int n = 0, i = 0;
        while ((i = s.indexOf(sub, i)) >= 0) { n++; i += sub.length(); }
        return n;
    }
}
