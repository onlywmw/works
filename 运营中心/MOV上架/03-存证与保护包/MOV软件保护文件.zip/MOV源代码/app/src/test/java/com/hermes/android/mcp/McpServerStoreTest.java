package com.hermes.android.mcp;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * McpServerStore 单测 — 多 server 配置存储（工单25 幕一 D），零网络零 Android。
 *
 * 覆盖：列表增删 / enable 开关 / 旧单条配置自动迁移（旧键保留）。
 * Prefs 经构造函数注入内存 fake。
 */
public class McpServerStoreTest {

    /** 内存 fake Prefs（等价 SharedPreferences 行为：key 缺席 → 返回 def）。 */
    static class MemPrefs implements McpServerStore.Prefs {
        final Map<String, String> map = new HashMap<>();
        @Override public String getString(String key, String def) {
            return map.containsKey(key) ? map.get(key) : def;
        }
        @Override public void putString(String key, String value) { map.put(key, value); }
    }

    private static McpServerStore.Entry onlyEntry(McpServerStore s) {
        List<McpServerStore.Entry> l = s.list();
        assertEquals("预期恰好 1 条", 1, l.size());
        return l.get(0);
    }

    // ══════════ 增删 ══════════

    @Test public void add_appendsEntryWithGeneratedId() {
        McpServerStore s = new McpServerStore(new MemPrefs());
        McpServerStore.Entry a = s.add("http://a/mcp", "tok-a", McpServerStore.ORIGIN_MANUAL);
        McpServerStore.Entry b = s.add("http://b/mcp", "tok-b", McpServerStore.ORIGIN_MARKET);

        List<McpServerStore.Entry> l = s.list();
        assertEquals(2, l.size());
        assertEquals(a.id, l.get(0).id);
        assertEquals(b.id, l.get(1).id);
        assertFalse("id 必须生成且唯一", a.id.equals(b.id));
        assertEquals("http://a/mcp", l.get(0).url);
        assertEquals("tok-b", l.get(1).token);
        assertTrue("新增默认启用", l.get(0).enabled);
        assertEquals(McpServerStore.ORIGIN_MARKET, l.get(1).origin);
    }

    @Test public void add_rejectsBadInput() {
        McpServerStore s = new McpServerStore(new MemPrefs());
        try {
            s.add("", "tok", McpServerStore.ORIGIN_MANUAL);
            fail("空 url 必须拒绝");
        } catch (IllegalArgumentException expected) {}
        try {
            s.add("http://a/mcp", "tok", "partner");
            fail("origin∉{manual,market} 必须拒绝");
        } catch (IllegalArgumentException expected) {}
        assertEquals("非法输入不落账", 0, s.list().size());
    }

    @Test public void remove_deletesById() {
        McpServerStore s = new McpServerStore(new MemPrefs());
        McpServerStore.Entry a = s.add("http://a/mcp", "", McpServerStore.ORIGIN_MANUAL);
        McpServerStore.Entry b = s.add("http://b/mcp", "", McpServerStore.ORIGIN_MANUAL);

        assertTrue("存在的 id 删除成功", s.remove(a.id));
        List<McpServerStore.Entry> l = s.list();
        assertEquals(1, l.size());
        assertEquals("留下的应是 b", b.id, l.get(0).id);

        assertFalse("不存在的 id 删除返回 false", s.remove(a.id));
        assertFalse("空 id 不炸", s.remove(""));
    }

    // ══════════ enable 开关 ══════════

    @Test public void setEnabled_togglesFlag() {
        McpServerStore s = new McpServerStore(new MemPrefs());
        McpServerStore.Entry a = s.add("http://a/mcp", "", McpServerStore.ORIGIN_MANUAL);
        McpServerStore.Entry b = s.add("http://b/mcp", "", McpServerStore.ORIGIN_MANUAL);

        assertTrue(s.setEnabled(a.id, false));
        List<McpServerStore.Entry> l = s.list();
        assertFalse("a 已停用", l.get(0).enabled);
        assertTrue("b 不受影响", l.get(1).enabled);

        assertTrue(s.setEnabled(a.id, true));
        assertTrue("a 重新启用", s.list().get(0).enabled);

        assertFalse("不存在的 id 返回 false", s.setEnabled("srv-nope", false));
    }

    @Test public void toggle_persistsAcrossStoreInstances() {
        // 同一 Prefs 新建 store 实例（等价进程重启后重读）状态仍在
        MemPrefs p = new MemPrefs();
        McpServerStore.Entry a = new McpServerStore(p).add("http://a/mcp", "", McpServerStore.ORIGIN_MANUAL);
        new McpServerStore(p).setEnabled(a.id, false);
        assertFalse(new McpServerStore(p).list().get(0).enabled);
    }

    // ══════════ 旧单条配置自动迁移 ══════════

    @Test public void legacyConfig_migratesToFirstEntry() {
        MemPrefs p = new MemPrefs();
        p.putString(McpServerStore.LEGACY_URL, "http://legacy/mcp");
        p.putString(McpServerStore.LEGACY_TOKEN, "legacy-tok");

        McpServerStore s = new McpServerStore(p);
        McpServerStore.Entry e = onlyEntry(s);
        assertEquals("url 从旧键迁移", "http://legacy/mcp", e.url);
        assertEquals("token 从旧键迁移", "legacy-tok", e.token);
        assertTrue("迁移条目默认启用", e.enabled);
        assertEquals("迁移条目 origin=manual", McpServerStore.ORIGIN_MANUAL, e.origin);
        assertFalse("迁移条目必须带 id", e.id.isEmpty());

        assertTrue("迁移后写入 mcp_servers 键", p.map.containsKey(McpServerStore.KEY_SERVERS));
        assertEquals("旧 server_url 键保留不删", "http://legacy/mcp",
                p.map.get(McpServerStore.LEGACY_URL));
        assertEquals("旧 server_token 键保留不删", "legacy-tok",
                p.map.get(McpServerStore.LEGACY_TOKEN));
    }

    @Test public void legacyConfig_migratesOnlyOnce() {
        MemPrefs p = new MemPrefs();
        p.putString(McpServerStore.LEGACY_URL, "http://legacy/mcp");

        McpServerStore s = new McpServerStore(p);
        String firstId = onlyEntry(s).id;
        s.add("http://b/mcp", "", McpServerStore.ORIGIN_MARKET);

        List<McpServerStore.Entry> l = s.list();
        assertEquals("迁移只发生一次，不重复生成旧条目", 2, l.size());
        assertEquals("首条仍是迁移条目（id 稳定）", firstId, l.get(0).id);
        assertEquals("http://b/mcp", l.get(1).url);
    }

    @Test public void noLegacyConfig_staysEmpty() {
        MemPrefs p = new MemPrefs();
        McpServerStore s = new McpServerStore(p);
        assertEquals(0, s.list().size());
        assertNull("无旧配置不凭空写 mcp_servers 键", s.first());
    }

    @Test public void legacyUrlEmpty_noMigration() {
        MemPrefs p = new MemPrefs();
        p.putString(McpServerStore.LEGACY_URL, "");
        assertEquals("旧 url 为空 → 不迁移", 0, new McpServerStore(p).list().size());
    }

    // ══════════ 兼容默认条目（mcp.get / mcp.set） ══════════

    @Test public void firstAndSetFirst_compatBehavior() {
        McpServerStore s = new McpServerStore(new MemPrefs());
        assertNull("空列表 first() → null", s.first());

        // 空列表 setFirst → 新建 manual 启用条目
        s.setFirst("http://x/mcp", "tok-x");
        McpServerStore.Entry e = onlyEntry(s);
        assertEquals("http://x/mcp", e.url);
        assertEquals("tok-x", e.token);
        assertTrue(e.enabled);
        assertEquals(McpServerStore.ORIGIN_MANUAL, e.origin);

        // 非空 setFirst → 只改第一条 url/token，不动其余字段和第二条
        s.add("http://y/mcp", "", McpServerStore.ORIGIN_MARKET);
        s.setFirst("http://x2/mcp", "tok-x2");
        List<McpServerStore.Entry> l = s.list();
        assertEquals(2, l.size());
        assertEquals("http://x2/mcp", l.get(0).url);
        assertEquals("tok-x2", l.get(0).token);
        assertEquals(e.id, l.get(0).id);
        assertEquals("http://y/mcp", l.get(1).url);
    }

    // ══════════ 工单25 本地页定稿：分类/简介/付费字段 + 组内排序 + 默认语义 ══════════

    @Test public void extendedFields_roundtrip() {
        McpServerStore s = new McpServerStore(new MemPrefs());
        McpServerStore.Entry e = s.add("http://a/mcp", "t", McpServerStore.ORIGIN_MARKET,
                "PocketBase 包", "本地数据库五件套", "db", true);
        McpServerStore.Entry got = onlyEntry(s);
        assertEquals(e.id, got.id);
        assertEquals("PocketBase 包", got.name);
        assertEquals("本地数据库五件套", got.desc);
        assertEquals("db", got.cat);
        assertTrue(got.paid);
    }

    @Test public void add_defaults_otherNotPaid() {
        McpServerStore s = new McpServerStore(new MemPrefs());
        s.add("http://a/mcp", "", McpServerStore.ORIGIN_MANUAL);
        McpServerStore.Entry got = onlyEntry(s);
        assertEquals("缺省分类 → other", McpServerStore.CAT_OTHER, got.cat);
        assertFalse("缺省非付费", got.paid);
        assertEquals("", got.name);
        assertEquals("", got.desc);
    }

    @Test public void oldEntriesWithoutNewFields_stillLoad() {
        // 幕一存量数据（无 name/desc/cat/paid 键）升级后能读，字段兜底
        MemPrefs p = new MemPrefs();
        p.putString(McpServerStore.KEY_SERVERS,
                "[{\"id\":\"srv-old1\",\"url\":\"http://old/mcp\",\"token\":\"\",\"enabled\":true,\"origin\":\"manual\"}]");
        McpServerStore.Entry got = onlyEntry(new McpServerStore(p));
        assertEquals("srv-old1", got.id);
        assertEquals(McpServerStore.CAT_OTHER, got.cat);
        assertFalse(got.paid);
    }

    @Test public void moveWithinCat_reordersOnlyInsideGroup() {
        McpServerStore s = new McpServerStore(new MemPrefs());
        s.add("http://db1/mcp", "", McpServerStore.ORIGIN_MARKET, "db1", "", "db", true);
        s.add("http://net1/mcp", "", McpServerStore.ORIGIN_MARKET, "net1", "", "net", false);
        s.add("http://db2/mcp", "", McpServerStore.ORIGIN_MARKET, "db2", "", "db", true);
        s.add("http://db3/mcp", "", McpServerStore.ORIGIN_MARKET, "db3", "", "db", true);
        List<McpServerStore.Entry> l = s.list();
        String db3 = l.get(3).id;

        // db3 提到组内第 0 位 → 成为 db 组第一；net1 相对位置不受影响（全局序 [db3,db1,net1,db2]）
        assertTrue(s.moveWithinCat(db3, 0));
        l = s.list();
        assertEquals("db3", l.get(0).name);
        assertEquals("db1", l.get(1).name);
        assertEquals("net1", l.get(2).name);
        assertEquals("db2", l.get(3).name);

        // 组内第 1 位 → 全局序 [db1,net1,db3,db2]，db 组内序 db1 < db3 < db2
        assertTrue(s.moveWithinCat(db3, 1));
        l = s.list();
        assertEquals("db1", l.get(0).name);
        assertEquals("net1", l.get(1).name);
        assertEquals("db3", l.get(2).name);
        assertEquals("db2", l.get(3).name);

        // 不存在的 id → false，列表不变
        int before = s.list().size();
        assertFalse(s.moveWithinCat("srv-nope", 0));
        assertEquals(before, s.list().size());
    }

    @Test public void defaultForCat_firstEnabledWins() {
        McpServerStore s = new McpServerStore(new MemPrefs());
        s.add("http://db1/mcp", "", McpServerStore.ORIGIN_MARKET, "db1", "", "db", true);
        s.add("http://db2/mcp", "", McpServerStore.ORIGIN_MARKET, "db2", "", "db", true);
        String first = s.list().get(0).id;
        assertEquals("组内第一即默认", first, s.defaultForCat("db").id);

        // 停掉第一 → 默认落到第二
        s.setEnabled(first, false);
        assertEquals("db2", s.defaultForCat("db").name);

        // 全停 → null；未知分类 → null
        s.setEnabled(s.list().get(1).id, false);
        assertNull(s.defaultForCat("db"));
        assertNull(s.defaultForCat("net"));
    }
}
