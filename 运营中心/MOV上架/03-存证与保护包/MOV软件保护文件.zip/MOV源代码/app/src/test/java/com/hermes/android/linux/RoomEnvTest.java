package com.hermes.android.linux;

import static org.junit.Assert.*;

import org.json.JSONObject;
import org.junit.Test;

/**
 * RoomEnv 纯函数单测 (M-ARCH-ENV): 工具链版本解析。
 */
public class RoomEnvTest {

    private static final String SAMPLE =
            "PY:Python 3.12.3\n"
            + "NODE:v18.19.1\n"
            + "GIT:git version 2.43.0\n"
            + "JQ:jq-1.7\n"
            + "RG:ripgrep 14.1.0\n"
            + "HERMES:Hermes Agent v0.19.0 (2026.7.20)\n";

    @Test
    public void parseToolVersions_full() throws Exception {
        JSONObject env = RoomEnv.parseToolVersions(SAMPLE);
        assertEquals("24.04", env.getString("ubuntu"));
        assertEquals("3.12.3", env.getString("python"));
        assertEquals("18.19.1", env.getString("node"));
        assertEquals("2.43.0", env.getString("git"));
        assertEquals("1.7", env.getString("jq"));
        assertEquals("14.1.0", env.getString("rg"));
        assertEquals("v0.19.0 (2026.7.20)", env.getString("hermes"));
    }

    @Test
    public void parseToolVersions_hermesMissing() throws Exception {
        JSONObject env = RoomEnv.parseToolVersions(
                "PY:Python 3.12.3\nHERMES:\n");
        assertEquals("3.12.3", env.getString("python"));
        assertTrue("hermes 未装必须为 null", env.isNull("hermes"));
    }

    @Test
    public void parseToolVersions_partialOutput() throws Exception {
        /* 某项命令失败时该项为 null, 不影响其他项 */
        JSONObject env = RoomEnv.parseToolVersions(
                "PY:Python 3.12.3\nNODE:\nGIT:git version 2.43.0\n");
        assertEquals("3.12.3", env.getString("python"));
        assertTrue(env.isNull("node"));
        assertEquals("2.43.0", env.getString("git"));
    }

    @Test
    public void lineVal_extracts() {
        assertEquals("Python 3.12.3", RoomEnv.lineVal(SAMPLE, "PY:"));
        assertEquals("", RoomEnv.lineVal(SAMPLE, "NOPE:"));
        assertEquals("", RoomEnv.lineVal(null, "PY:"));
    }

    @Test
    public void firstVersion_extracts() {
        assertEquals("3.12.3", RoomEnv.firstVersion("Python 3.12.3"));
        assertEquals("18.19.1", RoomEnv.firstVersion("v18.19.1"));
        assertEquals("1.7", RoomEnv.firstVersion("jq-1.7"));
        assertEquals("14.1.0", RoomEnv.firstVersion("ripgrep 14.1.0"));
        assertNull(RoomEnv.firstVersion(""));
        assertNull(RoomEnv.firstVersion(null));
    }
}
