package com.hermes.android.mcp.server;

import com.hermes.android.agent.Journal;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.io.File;
import java.nio.file.Files;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

/**
 * McpApprovalGate 审批闸单测（工单 P5）——纯 JVM 零网络零模型。
 *
 * 覆盖：未批准→PENDING / 批准→ALLOWED（路径进白名单）/ 驳回→DENIED / 路径级审批 /
 * 工具级审批（*）/ 房间确认闭环（journal 事件）/ 明确 error code / 未知请求返回 false。
 */
public class McpApprovalGateTest {

    private static JSONObject args(String... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i < kv.length; i += 2) o.put(kv[i], kv[i + 1]);
        } catch (org.json.JSONException e) {
            throw new RuntimeException(e);
        }
        return o;
    }

    @Test public void unapproved_pending() {
        McpApprovalGate g = new McpApprovalGate(null, "global");
        assertEquals("未批准 → PENDING", McpApprovalGate.Decision.PENDING, g.check("file.write", "index.html"));
        assertEquals("空路径归一化 * → PENDING", McpApprovalGate.Decision.PENDING, g.check("app.scaffold", ""));
    }

    @Test public void requestApproval_registersPending() {
        McpApprovalGate g = new McpApprovalGate(null, "global");
        String rid = g.requestApproval("file.write", "index.html", args("path", "index.html", "content", "x"));
        assertTrue("requestId 前缀 mcp_ap_", rid.startsWith("mcp_ap_"));
        assertTrue(g.hasPending("file.write", "index.html"));
        assertEquals(1, g.pendingRequests().size());
        assertEquals("file.write", g.pendingRequests().get(0).tool);
        assertEquals("index.html", g.pendingRequests().get(0).path);
    }

    @Test public void approve_thenAllowed() {
        McpApprovalGate g = new McpApprovalGate(null, "global");
        String rid = g.requestApproval("file.write", "index.html", args("path", "index.html"));
        assertTrue(g.respond(rid, true, "用户批准"));
        assertEquals(McpApprovalGate.Decision.ALLOWED, g.check("file.write", "index.html"));
        assertTrue("批准路径进共享白名单", g.getPathAllowSet().contains("index.html"));
        assertFalse("pending 已清", g.hasPending("file.write", "index.html"));
        assertEquals(0, g.pendingRequests().size());
    }

    @Test public void deny_thenDenied() {
        McpApprovalGate g = new McpApprovalGate(null, "global");
        String rid = g.requestApproval("file.write", "index.html", args("path", "index.html"));
        assertTrue(g.respond(rid, false, "用户驳回"));
        assertEquals(McpApprovalGate.Decision.DENIED, g.check("file.write", "index.html"));
        assertFalse("驳回不进白名单", g.getPathAllowSet().contains("index.html"));
    }

    @Test public void pathLevelApproval_onlyApprovedPathPasses() {
        McpApprovalGate g = new McpApprovalGate(null, "global");
        String rid = g.requestApproval("file.write", "index.html", args("path", "index.html"));
        g.respond(rid, true, "批 index.html");
        assertEquals(McpApprovalGate.Decision.ALLOWED, g.check("file.write", "index.html"));
        assertEquals("其他路径仍需审批", McpApprovalGate.Decision.PENDING, g.check("file.write", "style.css"));
    }

    @Test public void wildcardPath_toolLevelApproval() {
        McpApprovalGate g = new McpApprovalGate(null, "global");
        String rid = g.requestApproval("app.scaffold", "*", args("name", "app"));
        g.respond(rid, true, "批");
        assertEquals(McpApprovalGate.Decision.ALLOWED, g.check("app.scaffold", "*"));
        assertEquals("空路径归一化 * → 已批准", McpApprovalGate.Decision.ALLOWED, g.check("app.scaffold", ""));
    }

    @Test public void respond_unknownRequest_returnsFalse() {
        McpApprovalGate g = new McpApprovalGate(null, "global");
        assertFalse(g.respond("no_such", true, null));
    }

    @Test public void journalWrites_requestAndResultEvents() throws Exception {
        File dir = Files.createTempDirectory("mcpgate").toFile();
        try {
            Journal j = new Journal(dir);
            McpApprovalGate g = new McpApprovalGate(j, "global");
            String rid = g.requestApproval("file.write", "index.html", args("path", "index.html"));
            g.respond(rid, true, "批");
            JSONArray reqs = j.eventsOfType("global", McpApprovalGate.TYPE_REQUEST);
            JSONArray res = j.eventsOfType("global", McpApprovalGate.TYPE_RESULT);
            assertEquals("发起事件 1 条", 1, reqs.length());
            assertEquals("结果事件 1 条", 1, res.length());
            assertEquals("事件含路径", "index.html",
                    reqs.optJSONObject(0).optJSONObject("payload").optString("path"));
            assertTrue("结果含批准标记",
                    res.optJSONObject(0).optJSONObject("payload").optBoolean("approved"));
        } finally {
            deleteRecursive(dir);
        }
    }

    @Test public void requestId_uniqueAcrossInstances() {
        // 技术债修复回归（工单5）：seq 为实例字段非持久化，重启重号 → 加时间戳组件保证跨实例唯一
        McpApprovalGate g1 = new McpApprovalGate(null, "global");
        McpApprovalGate g2 = new McpApprovalGate(null, "global");   // 模拟重启（新实例）
        String a = g1.requestApproval("file.write", "a.html", args("path", "a.html"));
        String b = g2.requestApproval("file.write", "b.html", args("path", "b.html"));
        assertNotEquals("重启后新实例 requestId 不得重号", a, b);
        assertTrue("requestId 仍以 mcp_ap_ 开头", a.startsWith("mcp_ap_"));
        assertTrue("requestId 含时间戳段", a.length() > "mcp_ap_1".length());
    }

    @Test public void errorCodesExplicit() {
        assertEquals("APPROVAL_PENDING", McpApprovalGate.CODE_PENDING);
        assertEquals("APPROVAL_DENIED", McpApprovalGate.CODE_DENIED);
        assertEquals("_mcp_approval_request", McpApprovalGate.TYPE_REQUEST);
        assertEquals("_mcp_approval_result", McpApprovalGate.TYPE_RESULT);
    }

    private static void deleteRecursive(File f) {
        File[] c = f.listFiles();
        if (c != null) for (File x : c) deleteRecursive(x);
        f.delete();
    }
}
