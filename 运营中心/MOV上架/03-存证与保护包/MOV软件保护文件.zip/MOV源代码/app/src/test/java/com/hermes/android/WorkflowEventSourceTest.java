package com.hermes.android;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.io.File;
import java.util.Map;

import com.hermes.android.workflow.ActionExecutor;
import com.hermes.android.workflow.DeviceStateProvider;
import com.hermes.android.workflow.Workflow;
import com.hermes.android.workflow.WorkflowEngine;
import com.hermes.android.workflow.WorkflowEvent;
import com.hermes.android.workflow.WorkflowRepository;
import com.hermes.android.workflow.WorkflowEventSource;

import static org.junit.Assert.*;

/**
 * ConnectWeb 页面事件源（纯 JVM，fake ActionExecutor）：
 * onPageFinished → PAGE_LOAD + URL_CHANGE；tick → interval。
 */
public class WorkflowEventSourceTest {

    private static class Harness {
        final WorkflowRepository repo;
        final WorkflowEngine engine;
        final WorkflowEventSource source;
        Harness() {
            File dir = new File(System.getProperty("java.io.tmpdir"),
                    "wfs_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 100000));
            dir.mkdirs();
            this.repo = new WorkflowRepository(dir);
            this.engine = new WorkflowEngine(repo, new ActionExecutor() {
                public ActionReceipt execute(JSONArray actions, Map<String, Object> ctx) { return ActionReceipt.SUCCESS; }
            });
            this.source = new WorkflowEventSource(engine);
        }
    }

    private Workflow wf(String id, String triggerType) {
        JSONObject t = new JSONObject();
        try { t.put("type", triggerType); } catch (Exception e) {}
        return new Workflow(id, t, null, new JSONArray());
    }

    @Test public void onPageFinished_firesPageLoad() {
        Harness h = new Harness();
        h.repo.save(wf("load", "pageload"));
        h.repo.save(wf("change", "url_change"));

        WorkflowEngine.FireResult r = h.source.onPageFinished("https://x.com/a", 1000);

        assertTrue("pageload 触发", r.fired.contains("load"));
        assertFalse("首次加载 URL_CHANGE 不触发（无上次 URL 对比）", r.fired.contains("change"));
    }

    @Test public void onPageFinished_urlChangeFiresOnNewUrl() {
        Harness h = new Harness();
        h.repo.save(wf("load", "pageload"));
        h.repo.save(wf("change", "url_change"));

        h.source.onPageFinished("https://x.com/a", 1000);
        WorkflowEngine.FireResult r2 = h.source.onPageFinished("https://x.com/b", 2000);

        assertTrue("URL 变化触发 url_change", r2.fired.contains("change"));
        assertTrue("仍触发 pageload", r2.fired.contains("load"));
    }

    @Test public void onPageFinished_sameUrl_noUrlChange() {
        Harness h = new Harness();
        h.repo.save(wf("change", "url_change"));

        h.source.onPageFinished("https://x.com/a", 1000);
        WorkflowEngine.FireResult r2 = h.source.onPageFinished("https://x.com/a", 2000);

        assertFalse("同 URL 不触发 url_change", r2.fired.contains("change"));
    }

    @Test public void onElementAppear_firesElementTrigger() {
        Harness h = new Harness();
        Workflow w = wf("e", "element_appear");
        try { w.trigger.put("selector", "#result"); } catch (Exception e) {}
        h.repo.save(w);

        WorkflowEngine.FireResult r = h.source.onElementAppear("#result", "https://x.com", 1000);

        assertTrue("element_appear 触发", r.fired.contains("e"));
    }

    @Test public void onElementAppear_mismatchNoFire() {
        Harness h = new Harness();
        Workflow w = wf("e", "element_appear");
        try { w.trigger.put("selector", "#result"); } catch (Exception e) {}
        h.repo.save(w);

        WorkflowEngine.FireResult r = h.source.onElementAppear("#loading", "https://x.com", 1000);

        assertFalse("selector 不匹配不触发", r.fired.contains("e"));
    }

    @Test public void onTextMatch_firesTextTrigger() {
        Harness h = new Harness();
        Workflow w = wf("t", "text_match");
        try { w.trigger.put("pattern", "已出票"); } catch (Exception e) {}
        h.repo.save(w);

        WorkflowEngine.FireResult r = h.source.onTextMatch("订单已出票成功", "https://x.com", 1000);

        assertTrue("text_match 触发", r.fired.contains("t"));
    }

    @Test public void setPageSnapshot_enablesTextCondition() {
        Harness h = new Harness();
        Workflow w = wf("t", "pageload");
        JSONObject cond = new JSONObject();
        try { cond.put("type", "text").put("pattern", "已出票"); } catch (Exception e) {}
        w.conditions.put(cond);
        h.repo.save(w);

        h.source.setPageSnapshot("订单已出票成功", new java.util.ArrayList<>());
        WorkflowEngine.FireResult r = h.source.onPageFinished("https://x.com", 1000);

        assertTrue("text 条件用页面快照评估通过", r.fired.contains("t"));
    }

    @Test public void setPageSnapshot_enablesElementCondition() {
        Harness h = new Harness();
        Workflow w = wf("e", "pageload");
        JSONObject cond = new JSONObject();
        try { cond.put("type", "element").put("selector", "#result"); } catch (Exception e) {}
        w.conditions.put(cond);
        h.repo.save(w);

        java.util.List<String> present = new java.util.ArrayList<>();
        present.add("#result");
        h.source.setPageSnapshot("", present);
        WorkflowEngine.FireResult r = h.source.onPageFinished("https://x.com", 1000);

        assertTrue("element 条件用页面快照评估通过", r.fired.contains("e"));
    }

    @Test public void elementCondition_failsWithoutSnapshot() {
        Harness h = new Harness();
        Workflow w = wf("e", "pageload");
        JSONObject cond = new JSONObject();
        try { cond.put("type", "element").put("selector", "#result"); } catch (Exception e) {}
        w.conditions.put(cond);
        h.repo.save(w);

        WorkflowEngine.FireResult r = h.source.onPageFinished("https://x.com", 1000);   // 未回填快照

        assertFalse("未回填快照时 element 条件不通过", r.fired.contains("e"));
    }

    @Test public void onDeviceEvent_firesMatchingWorkflow() {
        Harness h = new Harness();
        Workflow w = wf("s", "screen_on");
        h.repo.save(w);

        WorkflowEngine.FireResult r = h.source.onDeviceEvent(WorkflowEvent.Type.SCREEN_ON, 1000);

        assertTrue("screen_on 事件触发 screen_on workflow", r.fired.contains("s"));
    }

    @Test public void onDeviceEvent_wrongTypeNoFire() {
        Harness h = new Harness();
        Workflow w = wf("s", "screen_on");
        h.repo.save(w);

        WorkflowEngine.FireResult r = h.source.onDeviceEvent(WorkflowEvent.Type.POWER_CONNECTED, 1000);

        assertFalse("power 事件不触发 screen_on workflow", r.fired.contains("s"));
    }

    @Test public void onManual_firesManualWorkflow() {
        Harness h = new Harness();
        Workflow w = wf("m", "manual");
        h.repo.save(w);

        WorkflowEngine.FireResult r = h.source.onManual("m", 1000);

        assertTrue("manual 精确触发指定 workflow", r.fired.contains("m"));
    }

    @Test public void onManual_onlyFiresTargetWorkflow() {
        Harness h = new Harness();
        h.repo.save(wf("m1", "manual"));
        h.repo.save(wf("m2", "manual"));

        WorkflowEngine.FireResult r = h.source.onManual("m1", 1000);

        assertTrue("只触发 m1", r.fired.contains("m1"));
        assertFalse("不触发 m2", r.fired.contains("m2"));
    }

    @Test public void onBoot_firesBootWorkflow() {
        Harness h = new Harness();
        Workflow w = wf("b", "boot_completed");
        h.repo.save(w);

        WorkflowEngine.FireResult r = h.source.onBoot(1000);

        assertTrue("boot 事件触发 boot_completed workflow", r.fired.contains("b"));
    }

    @Test public void setDeviceSnapshot_enablesScreenCondition() {
        Harness h = new Harness();
        Workflow w = wf("s", "screen_on");
        JSONObject cond = new JSONObject();
        try { cond.put("type", "screen_is_on"); } catch (Exception e) {}
        w.conditions.put(cond);
        h.repo.save(w);

        h.source.setDeviceStateProvider(() -> new DeviceStateProvider.DeviceState(-1, false, true, "wifi"));   // 亮屏拉取
        WorkflowEngine.FireResult r = h.source.onDeviceEvent(WorkflowEvent.Type.SCREEN_ON, 1000);

        assertTrue("拉取亮屏后 screen_is_on 条件通过", r.fired.contains("s"));
    }

    @Test public void setDeviceSnapshot_screenOffFailsCondition() {
        Harness h = new Harness();
        Workflow w = wf("s", "screen_on");
        JSONObject cond = new JSONObject();
        try { cond.put("type", "screen_is_on"); } catch (Exception e) {}
        w.conditions.put(cond);
        h.repo.save(w);

        h.source.setDeviceStateProvider(() -> new DeviceStateProvider.DeviceState(-1, false, false, null));   // 灭屏拉取
        WorkflowEngine.FireResult r = h.source.onDeviceEvent(WorkflowEvent.Type.SCREEN_ON, 1000);

        assertFalse("灭屏时 screen_is_on 条件不通过", r.fired.contains("s"));
    }

    @Test public void setDeviceSnapshot_chargingCondition() {
        Harness h = new Harness();
        Workflow w = wf("p", "power_connected");
        JSONObject cond = new JSONObject();
        try { cond.put("type", "is_charging"); } catch (Exception e) {}
        w.conditions.put(cond);
        h.repo.save(w);

        h.source.setDeviceStateProvider(() -> new DeviceStateProvider.DeviceState(80, true, false, null));   // 充电中拉取
        WorkflowEngine.FireResult r = h.source.onDeviceEvent(WorkflowEvent.Type.POWER_CONNECTED, 1000);

        assertTrue("拉取充电中后 is_charging 条件通过", r.fired.contains("p"));
    }

    @Test public void tick_firesInterval() {
        Harness h = new Harness();
        Workflow w = wf("every", "interval");
        try { w.trigger.put("intervalMs", 10000); } catch (Exception e) {}
        h.repo.save(w);

        h.source.tick(5000);   // 未到 interval
        h.source.tick(15000);  // 距上次（0）15s >= 10s → 触发

        // 第二次 tick 触发（15000-0=15000 >= 10000）
        WorkflowEngine.FireResult r2 = h.source.tick(26000);   // 距上次 fire(15000) 11s
        assertTrue("interval 到期触发", r2.fired.contains("every"));
    }
}
