package com.hermes.android.causal;

import com.hermes.android.agent.Journal;

import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.nio.file.Files;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * CausalChain 测试 — 认知账本：区块追加、回放有序、篡改检测（变异反证：删链校验护栏必红）、head 定位。
 */
public class CausalChainTest {

    private File tmp;
    private Journal journal;
    private CausalChain chain;

    @Before public void setUp() throws Exception {
        tmp = Files.createTempDirectory("causal-chain-").toFile();
        journal = new Journal(tmp);
        chain = new CausalChain();
    }

    @After public void tearDown() throws Exception {
        deleteRecursive(tmp);
    }

    private void deleteRecursive(File f) {
        File[] all = f.listFiles();
        if (all != null) for (File c : all) deleteRecursive(c);
        f.delete();
    }

    @Test public void appendCreatesBlock() {
        String h = chain.append(journal, "r1", CausalHash.dataHash("{\"a\":1}"), "rule upsert", null);
        assertNotNull("append 返回区块哈希", h);
        assertEquals("非空", 64, h.length());
        assertEquals("1 个区块", 1, chain.size(journal, "r1"));
    }

    @Test public void replayReturnsOrderedBlocks() {
        chain.append(journal, "r1", CausalHash.dataHash("{\"a\":1}"), "first", null);
        chain.append(journal, "r1", CausalHash.dataHash("{\"a\":2}"), "second", null);
        JSONObject replay = chain.replay(journal, "r1");
        assertTrue("链完整校验通过", replay.optBoolean("verified", false));
        assertEquals("2 个区块", 2, replay.optJSONArray("blocks").length());
        assertEquals("第二块 reason", "second",
                replay.optJSONArray("blocks").optJSONObject(1).optString("reason"));
    }

    @Test public void tamperedBlockFailsVerify() throws Exception {
        chain.append(journal, "r1", CausalHash.dataHash("{\"a\":1}"), "first", null);
        chain.append(journal, "r1", CausalHash.dataHash("{\"a\":2}"), "second", null);
        assertTrue("篡改前链完整", chain.verify(journal, "r1"));

        // 篡改第二块 dataHash → 链断
        File jf = new File(tmp, "r1/journal.jsonl");
        String content = new String(Files.readAllBytes(jf.toPath()), "UTF-8");
        String tampered = content.replace("\"dataHash\":\"" + CausalHash.dataHash("{\"a\":2}") + "\"",
                "\"dataHash\":\"deadbeef\"");
        assertFalse("篡改内容应不同", content.equals(tampered));
        Files.write(jf.toPath(), tampered.getBytes("UTF-8"));

        assertFalse("篡改后链校验失败（删护栏必红）", chain.verify(journal, "r1"));
    }

    @Test public void chainHeadIsLastBlock() {
        String first = chain.append(journal, "r1", CausalHash.dataHash("{\"a\":1}"), "first", null);
        String second = chain.append(journal, "r1", CausalHash.dataHash("{\"a\":2}"), "second", null);
        assertEquals("head = 最后区块", second, chain.lastBlockHash(journal, "r1"));
        assertEquals("首块非尾块", false, first.equals(second));
    }

    @Test public void evidenceRecordedInBlock() throws Exception {
        JSONObject evidence = new JSONObject().put("eventSeq", 7).put("ruleId", "r_debt");
        chain.append(journal, "r1", CausalHash.dataHash("{\"a\":1}"), "rule fire", evidence);
        JSONObject block = chain.replay(journal, "r1").optJSONArray("blocks").optJSONObject(0);
        assertEquals("evidence 记录事件 seq（回答哪天基于哪条事件）", 7,
                block.optJSONObject("evidence").optInt("eventSeq"));
    }
}
