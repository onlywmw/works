package com.hermes.android.agent;

import org.junit.Test;

import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.*;

/**
 * M4 韧性恢复状态机单测（零网络注入式）：ensureServeUp 决策——
 * healthz 通 → 直接用；不通 → startDaemon 拉起 → waitHealthy；恢复失败 → false（落回 exec）。
 * 用假 HermesClient（覆写 healthz/waitHealthy）驱动生产决策路径，非手写布尔自证。
 */
public class HeavyWorkerLifecycleTest {

    private static HermesClient fake(boolean hz, boolean wait) {
        return new HermesClient("t") {
            @Override public boolean healthz(long timeoutMs) { return hz; }
            @Override public boolean waitHealthy(long waitMs) { return wait; }
        };
    }

    @Test public void healthzUp_usesDirectly_noStartDaemon() {
        AtomicInteger starts = new AtomicInteger();
        boolean up = HeavyWorker.ensureServeUp(fake(true, true), starts::incrementAndGet);
        assertTrue(up);
        assertEquals("healthz 通不应拉起 daemon", 0, starts.get());
    }

    @Test public void healthzDown_startDaemon_waitHealthy_restores() {
        AtomicInteger starts = new AtomicInteger();
        boolean up = HeavyWorker.ensureServeUp(fake(false, true), starts::incrementAndGet);
        assertTrue("杀 daemon 后自动恢复", up);
        assertEquals("应拉起一次", 1, starts.get());
    }

    @Test public void healthzDown_startDaemon_waitFail_fallsBack() {
        AtomicInteger starts = new AtomicInteger();
        boolean up = HeavyWorker.ensureServeUp(fake(false, false), starts::incrementAndGet);
        assertFalse("拉起失败 → 调用方落回 exec", up);
        assertEquals(1, starts.get());
    }

    @Test public void healthzThrows_fallsBack_withoutStart() {
        AtomicInteger starts = new AtomicInteger();
        HermesClient throwing = new HermesClient("t") {
            @Override public boolean healthz(long timeoutMs) { throw new RuntimeException("连不上"); }
            @Override public boolean waitHealthy(long waitMs) { return true; }
        };
        assertFalse("healthz 异常 → 恢复失败(落回 exec)",
                HeavyWorker.ensureServeUp(throwing, starts::incrementAndGet));
        assertEquals("healthz 异常不应拉起 daemon", 0, starts.get());
    }
}
