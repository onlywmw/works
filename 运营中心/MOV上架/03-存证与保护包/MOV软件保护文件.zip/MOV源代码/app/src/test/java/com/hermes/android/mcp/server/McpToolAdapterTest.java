package com.hermes.android.mcp.server;

import com.hermes.android.agent.Journal;
import com.hermes.android.agent.ToolRegistry;

import io.modelcontextprotocol.server.McpSyncServerExchange;
import io.modelcontextprotocol.spec.McpSchema;

import org.junit.Test;

import java.io.File;
import java.nio.file.Files;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * McpToolAdapter 映射测试 — ToolRegistry.Tool ↔ McpSchema.Tool 契约。
 *
 * 每条断言回答：适配器把 MOV 工具翻译成主流 MCP client 认识的 schema/结果。
 */
public class McpToolAdapterTest {

    private static ToolRegistry.Tool tool(String name, String access, ToolRegistry.ParamDef[] params,
                                          ToolRegistry.Handler handler, int maxChars) {
        return new ToolRegistry.Tool(name, "desc-" + name, null, handler,
                "native", access, "none", true, 30,
                "test", params, "returns", null, null, maxChars,
                new ToolRegistry.Manifest("标题", "low", "描述", true, "io"), null);
    }

    private static String textOf(McpSchema.CallToolResult r) {
        return ((McpSchema.TextContent) r.content().get(0)).text();
    }

    @Test public void toSchema_mapsParamsToInputSchema() {
        ToolRegistry.ParamDef[] params = new ToolRegistry.ParamDef[]{
            new ToolRegistry.ParamDef("path", "string", true, "", "文件路径"),
            new ToolRegistry.ParamDef("offset", "int", false, "", "起始字符"),
        };
        McpSchema.Tool s = McpToolAdapter.toSchema(tool("file.read", "readonly", params, a -> null, 8000));

        assertEquals("file.read", s.name());
        assertEquals("desc-file.read", s.description());
        assertNotNull(s.inputSchema());
        assertEquals("object", s.inputSchema().type());
        // properties：string/int → string/integer（properties 值为 {type, description} Map）
        assertEquals("string", ((java.util.Map<?, ?>) s.inputSchema().properties().get("path")).get("type"));
        assertEquals("integer", ((java.util.Map<?, ?>) s.inputSchema().properties().get("offset")).get("type"));
        // description 透传
        assertEquals("文件路径", ((java.util.Map<?, ?>) s.inputSchema().properties().get("path")).get("description"));
        // required 只含必填
        assertEquals(List.of("path"), s.inputSchema().required());
    }

    @Test public void toSchema_noParams_emptyProperties() {
        McpSchema.Tool s = McpToolAdapter.toSchema(tool("model.list", "readonly", null, a -> null, 8000));
        assertTrue(s.inputSchema().properties().isEmpty());
        assertTrue(s.inputSchema().required().isEmpty());
    }

    @Test public void toSchema_booleanType_mapsToBoolean() {
        ToolRegistry.ParamDef[] params = new ToolRegistry.ParamDef[]{
            new ToolRegistry.ParamDef("enabled", "boolean", false, "", "开关"),
        };
        McpSchema.Tool s = McpToolAdapter.toSchema(tool("t", "readonly", params, a -> null, 8000));
        assertEquals("boolean", ((java.util.Map<?, ?>) s.inputSchema().properties().get("enabled")).get("type"));
    }

    @Test public void toSchema_nullDesc_fallsBackToName() {
        ToolRegistry.Tool t = new ToolRegistry.Tool("bare", null, null, a -> null);
        assertEquals("bare", McpToolAdapter.toSchema(t).description());
    }

    @Test public void handlerFor_okResult_returnsContent() {
        ToolRegistry.Tool t = tool("echo", "readonly", null,
                a -> new ToolRegistry.Result(true, "回显:" + a.optString("text")), 8000);
        McpSchema.CallToolResult r = McpToolAdapter.handlerFor(t).apply(null,
                new McpSchema.CallToolRequest("echo", java.util.Map.of("text", "你好")));
        assertFalse(Boolean.TRUE.equals(r.isError()));
        assertEquals("回显:你好", textOf(r));
    }

    @Test public void handlerFor_failure_setsIsError() {
        ToolRegistry.Tool t = tool("read", "readonly", null,
                a -> new ToolRegistry.Result(false, "文件不存在"), 8000);
        McpSchema.CallToolResult r = McpToolAdapter.handlerFor(t).apply(null,
                new McpSchema.CallToolRequest("read", java.util.Map.of()));
        assertEquals(Boolean.TRUE, r.isError());
        assertEquals("文件不存在", textOf(r));
    }

    @Test public void handlerFor_exception_setsIsError() {
        ToolRegistry.Tool t = tool("boom", "readonly", null,
                a -> { throw new RuntimeException("执行坏了"); }, 8000);
        McpSchema.CallToolResult r = McpToolAdapter.handlerFor(t).apply(null,
                new McpSchema.CallToolRequest("boom", java.util.Map.of()));
        assertEquals(Boolean.TRUE, r.isError());
        assertTrue(textOf(r).contains("执行坏了"));
    }

    @Test public void handlerFor_truncatesOverMaxChars() {
        String big = new String(new char[9000]).replace('\0', 'x');
        ToolRegistry.Tool t = tool("big", "readonly", null,
                a -> new ToolRegistry.Result(true, big), 100);
        McpSchema.CallToolResult r = McpToolAdapter.handlerFor(t).apply(null,
                new McpSchema.CallToolRequest("big", java.util.Map.of()));
        String text = textOf(r);
        assertTrue("应带截断标记", text.contains("截断"));
        assertTrue("截断后长度受限", text.length() < big.length());
    }

    @Test public void handlerFor_nullArgs_safe() {
        ToolRegistry.Tool t = tool("noarg", "readonly", null,
                a -> new ToolRegistry.Result(true, "ok"), 8000);
        McpSchema.CallToolResult r = McpToolAdapter.handlerFor(t).apply(null,
                new McpSchema.CallToolRequest("noarg", null));
        assertFalse(Boolean.TRUE.equals(r.isError()));
        assertEquals("ok", textOf(r));
    }

    @Test public void isReadonly_filtersByAccess() {
        assertTrue(McpToolAdapter.isReadonly(tool("file.read", "readonly", null, a -> null, 8000)));
        assertFalse(McpToolAdapter.isReadonly(tool("file.write", "write", null, a -> null, 8000)));
        assertFalse(McpToolAdapter.isReadonly(tool("shell.exec", "write", null, a -> null, 8000)));
        assertFalse(McpToolAdapter.isReadonly(tool("device.cmd", "write", null, a -> null, 8000)));
    }

    // ═══ 审批闸包装（工单 P5）═══

    private static ToolRegistry.Tool writeTool(String name, ToolRegistry.Handler handler) {
        return new ToolRegistry.Tool(name, "desc-" + name, null, handler,
                "native", "write", "plan", true, 30,
                "file", new ToolRegistry.ParamDef[]{
                    new ToolRegistry.ParamDef("path", "string", true, "", "路径"),
                    new ToolRegistry.ParamDef("content", "string", false, "", "内容"),
                }, "returns", null, null, 8000,
                new ToolRegistry.Manifest("标题", "medium", "描述", true, "io"), null);
    }

    @Test public void gatedHandler_unapproved_returnsPendingCode() {
        McpApprovalGate gate = new McpApprovalGate(null, "global");
        ToolRegistry.Tool w = writeTool("file.write",
                a -> new ToolRegistry.Result(true, "wrote:" + a.optString("path")));
        McpSchema.CallToolResult r = McpToolAdapter.gatedHandlerFor(w, gate).apply(null,
                new McpSchema.CallToolRequest("file.write",
                        java.util.Map.of("path", "index.html", "content", "x")));
        assertEquals("未批准 → isError", Boolean.TRUE, r.isError());
        String t = textOf(r);
        assertTrue("未批准返回明确 error code APPROVAL_PENDING: " + t, t.contains("APPROVAL_PENDING"));
        assertTrue("已发起房间审批请求: " + t, t.contains("mcp_ap_"));
    }

    @Test public void gatedHandler_approved_executesHandler() {
        McpApprovalGate gate = new McpApprovalGate(null, "global");
        String rid = gate.requestApproval("file.write", "index.html", new org.json.JSONObject());
        gate.respond(rid, true, "批");
        ToolRegistry.Tool w = writeTool("file.write",
                a -> new ToolRegistry.Result(true, "wrote:" + a.optString("path")));
        McpSchema.CallToolResult r = McpToolAdapter.gatedHandlerFor(w, gate).apply(null,
                new McpSchema.CallToolRequest("file.write", java.util.Map.of("path", "index.html")));
        assertFalse("批准后执行 handler", Boolean.TRUE.equals(r.isError()));
        assertEquals("wrote:index.html", textOf(r));
    }

    @Test public void gatedHandler_denied_returnsDeniedCode() {
        McpApprovalGate gate = new McpApprovalGate(null, "global");
        String rid = gate.requestApproval("file.write", "index.html", new org.json.JSONObject());
        gate.respond(rid, false, "驳");
        ToolRegistry.Tool w = writeTool("file.write",
                a -> new ToolRegistry.Result(true, "wrote:" + a.optString("path")));
        McpSchema.CallToolResult r = McpToolAdapter.gatedHandlerFor(w, gate).apply(null,
                new McpSchema.CallToolRequest("file.write", java.util.Map.of("path", "index.html")));
        assertEquals("驳回 → isError", Boolean.TRUE, r.isError());
        assertTrue("驳回返回明确 error code APPROVAL_DENIED: " + textOf(r),
                textOf(r).contains("APPROVAL_DENIED"));
    }

    @Test public void gatedHandler_noPathParam_toolLevelScope() {
        McpApprovalGate gate = new McpApprovalGate(null, "global");
        ToolRegistry.Tool w = new ToolRegistry.Tool("app.scaffold", "desc-app.scaffold", null,
                a -> new ToolRegistry.Result(true, "scaffold"), "native", "write", "plan", true, 30,
                "file", new ToolRegistry.ParamDef[]{
                    new ToolRegistry.ParamDef("name", "string", true, "", "名字"),
                }, "returns", null, null, 8000,
                new ToolRegistry.Manifest("标题", "low", "描述", true, "io"), null);
        McpSchema.CallToolResult r1 = McpToolAdapter.gatedHandlerFor(w, gate).apply(null,
                new McpSchema.CallToolRequest("app.scaffold", java.util.Map.of("name", "app")));
        assertEquals("无 path 未批准 → PENDING", Boolean.TRUE, r1.isError());
        assertTrue(textOf(r1).contains("APPROVAL_PENDING"));

        String rid = gate.requestApproval("app.scaffold", "*", new org.json.JSONObject());
        gate.respond(rid, true, "批");
        McpSchema.CallToolResult r2 = McpToolAdapter.gatedHandlerFor(w, gate).apply(null,
                new McpSchema.CallToolRequest("app.scaffold", java.util.Map.of("name", "app")));
        assertFalse("批准 * 后放行", Boolean.TRUE.equals(r2.isError()));
        assertEquals("scaffold", textOf(r2));
    }

    @Test public void gatedHandler_pending_repeatedCall_noDuplicateRequest() throws Exception {
        // 去重（G2 修复）：同 tool/path 重复 PENDING 调用 → 只写 1 条 _mcp_approval_request journal 事件
        File dir = Files.createTempDirectory("mcpgate_dedup").toFile();
        try {
            Journal j = new Journal(dir);
            McpApprovalGate gate = new McpApprovalGate(j, "global");
            ToolRegistry.Tool w = writeTool("file.write",
                    a -> new ToolRegistry.Result(true, "wrote:" + a.optString("path")));
            java.util.function.BiFunction<McpSyncServerExchange, McpSchema.CallToolRequest, McpSchema.CallToolResult> h =
                    McpToolAdapter.gatedHandlerFor(w, gate);
            h.apply(null, new McpSchema.CallToolRequest("file.write", java.util.Map.of("path", "index.html")));
            h.apply(null, new McpSchema.CallToolRequest("file.write", java.util.Map.of("path", "index.html")));
            org.json.JSONArray reqs = j.eventsOfType("global", McpApprovalGate.TYPE_REQUEST);
            assertEquals("重复 pending 调用不重复写请求事件（hasPending 去重）", 1, reqs.length());
        } finally {
            deleteRecursive(dir);
        }
    }

    @Test public void gatedHandler_pathParamMissing_repeatedCall_noDuplicateRequest() throws Exception {
        // 去重 normalize（工单任务2）：有 path 参数但缺省（pathOf 返回 "" → 归一化 "*"）。
        // 重复调用不重复写请求事件（raw "" vs pr.path("*") 需归一化比较，否则重复登记 pending）
        File dir = Files.createTempDirectory("mcpgate_dedup_np2").toFile();
        try {
            Journal j = new Journal(dir);
            McpApprovalGate gate = new McpApprovalGate(j, "global");
            ToolRegistry.Tool w = writeTool("file.write",
                    a -> new ToolRegistry.Result(true, "wrote:" + a.optString("path")));
            java.util.function.BiFunction<McpSyncServerExchange, McpSchema.CallToolRequest, McpSchema.CallToolResult> h =
                    McpToolAdapter.gatedHandlerFor(w, gate);
            h.apply(null, new McpSchema.CallToolRequest("file.write", java.util.Map.of("content", "x")));
            h.apply(null, new McpSchema.CallToolRequest("file.write", java.util.Map.of("content", "y")));
            org.json.JSONArray reqs = j.eventsOfType("global", McpApprovalGate.TYPE_REQUEST);
            assertEquals("有 path 参数但缺省：重复调用不重复写请求事件（normalize 去重）", 1, reqs.length());
            assertEquals("待审批路径归一化为 *", "*", gate.pendingRequests().get(0).path);
        } finally {
            deleteRecursive(dir);
        }
    }

    private static void deleteRecursive(File f) {
        File[] c = f.listFiles();
        if (c != null) for (File x : c) deleteRecursive(x);
        f.delete();
    }
}
