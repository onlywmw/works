package com.hermes.android;
import com.hermes.android.toolprovider.MemoryToolProvider;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.junit.Test;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import static org.junit.Assert.*;

/**
 * MemoryToolProvider 单元测试 — FUSION F3 记忆读写收编。
 *
 * 红线：零网络。只验证 discover() 元数据与注册表注册，不执行 handler（依赖 context）。
 */
public class MemoryToolProviderTest {

    private static AgentLoop.Tools emptyTools() {
        return new AgentLoop.Tools() {
            public String fileList(String roomId) { return ""; }
            public String fileRead(String roomId, String path) { return ""; }
            public String fileWrite(String roomId, String path, String content) { return ""; }
            public String capabilityOf(String text) { return ""; }
            public String deviceCmd(String text) { return ""; }
            public String packageApk(String roomId, String path, String appName) { return "{}"; }
            public String shellExec(String cmd, int timeoutSec) { return ""; }
            @Override public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":true,\"output\":\"x\"}"; }
            public String filePush(String roomId, String path) { return "{}"; }
            public String filePull(String roomId, String name) { return "{}"; }
        };
    }

    private ToolRegistry builtRegistry() {
        return ToolRegistry.build(emptyTools(), "room1", HashSet::new,
                new ToolRegistry.DevicePolicy(Collections.<String>emptySet()));
    }

    @Test public void discover_returns4MemoryTools() {
        MemoryToolProvider p = new MemoryToolProvider();
        List<ToolRegistry.Tool> tools = p.discover();
        assertEquals("记忆工具数量应为 7（含批2 memory curated + 幕二 memory.cover/search）", 7, tools.size());
        for (ToolRegistry.Tool t : tools) {
            assertNotNull("manifest 非空", t.manifest);
            assertEquals("level 应为 FAST: " + t.name, "FAST", t.manifest.level);
            assertEquals("toolset 应为 memory: " + t.name, "memory", t.toolset);
            assertFalse("本地记忆 sync 应为 false: " + t.name, t.manifest.sync);
        }
    }

    @Test public void discover_namesCorrect() {
        MemoryToolProvider p = new MemoryToolProvider();
        List<ToolRegistry.Tool> tools = p.discover();
        List<String> names = new java.util.ArrayList<>();
        for (ToolRegistry.Tool t : tools) names.add(t.name);
        assertTrue("含 face_history", names.contains("face_history"));
        assertTrue("含 drama_memory", names.contains("drama_memory"));
        assertTrue("含 watch_history", names.contains("watch_history"));
        assertTrue("含 face_mine", names.contains("face_mine"));
    }

    @Test public void drama_memoryIsWriteAccess() {
        MemoryToolProvider p = new MemoryToolProvider();
        for (ToolRegistry.Tool t : p.discover()) {
            if (t.name.equals("drama_memory")) {
                assertEquals("drama_memory 有写操作, access 应为 write", "write", t.access);
                assertNotNull("drama_memory params 非空", t.params);
            }
        }
    }

    @Test public void readOnlyMemoryToolsReadonly() {
        MemoryToolProvider p = new MemoryToolProvider();
        for (ToolRegistry.Tool t : p.discover()) {
            // 写操作工具：drama_memory（add/remove/clear）、watch_history（clear）、memory（批2 curated 写）
            if (t.name.equals("drama_memory") || t.name.equals("watch_history")
                    || t.name.equals("memory")) continue;
            assertEquals("只读记忆工具 access 应为 readonly: " + t.name, "readonly", t.access);
        }
    }

    @Test public void writeMemoryToolsMarkedWrite() {
        MemoryToolProvider p = new MemoryToolProvider();
        for (ToolRegistry.Tool t : p.discover()) {
            if (t.name.equals("drama_memory") || t.name.equals("watch_history")) {
                assertEquals("含写操作的工具 access 应为 write: " + t.name, "write", t.access);
            }
        }
    }

    @Test public void registryFindMemoryTools() {
        ToolRegistry r = builtRegistry();
        assertNotNull("face_history 应注册", r.find("face_history"));
        assertNotNull("drama_memory 应注册", r.find("drama_memory"));
        assertNotNull("watch_history 应注册", r.find("watch_history"));
        assertNotNull("face_mine 应注册", r.find("face_mine"));
    }

    @Test public void allTools_includesMemoryTools() {
        ToolRegistry r = builtRegistry();
        boolean watchSeen = false;
        for (ToolRegistry.Tool t : r.allTools()) {
            if (t.name.equals("watch_history")) watchSeen = true;
        }
        assertTrue("allTools() 应包含 watch_history", watchSeen);
    }

    @Test public void memory_coverSearch_existAndReadonly() {
        // 工单9 幕二 三件套 a: memory.cover/memory.search 只读查询(8389 只读集暴露给客居脑)
        MemoryToolProvider p = new MemoryToolProvider();
        boolean cover = false, search = false;
        for (ToolRegistry.Tool t : p.discover()) {
            if (t.name.equals("memory.cover")) {
                cover = true;
                assertEquals("memory.cover 应为只读", "readonly", t.access);
            }
            if (t.name.equals("memory.search")) {
                search = true;
                assertEquals("memory.search 应为只读", "readonly", t.access);
            }
        }
        assertTrue("memory.cover 应存在", cover);
        assertTrue("memory.search 应存在", search);
    }
}
