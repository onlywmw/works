package com.hermes.android.scene;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.List;
import com.hermes.android.scene.DramaSource;
import com.hermes.android.scene.DramaSource.DramaItem;

/**
 * DramaSource 降级链单元测试。
 * 验证：豆瓣解析 → DDG 降级 → 双源全挂 → 频率保护 → 平台推测。
 */
public class DramaSourceTest {

    /** 模拟豆瓣 subject_suggest 返回的 JSON */
    private static final String DOUBAN_OK = "[" +
        "{\"id\":\"35633644\",\"title\":\"漫长的季节\",\"year\":\"2023\"," +
        "\"sub_title\":\"The Long Season\",\"type\":\"tv\"," +
        "\"pic\":{\"normal\":\"https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2892332155.jpg\"}," +
        "\"url\":\"https://movie.douban.com/subject/35633644/\"}," +
        "{\"id\":\"34874432\",\"title\":\"繁花\",\"year\":\"2023\"," +
        "\"sub_title\":\"Blossoms Shanghai\",\"type\":\"tv\"," +
        "\"pic\":{\"normal\":\"https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2895983267.jpg\"}," +
        "\"url\":\"https://movie.douban.com/subject/34874432/\"}," +
        "{\"id\":\"36151168\",\"title\":\"我的阿勒泰\",\"year\":\"2024\"," +
        "\"sub_title\":\"To the Wonder\",\"type\":\"tv\"," +
        "\"pic\":{\"normal\":\"https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2906865921.jpg\"}," +
        "\"url\":\"https://movie.douban.com/subject/36151168/\"}" +
        "]";

    private static final String DOUBAN_EMPTY = "[]";

    /** 模拟 DDG API 返回 */
    private static final String DDG_OK = "{" +
        "\"Abstract\":\"漫长的季节是一部2023年中国悬疑电视剧，由辛爽执导，范伟、秦昊、陈明昊主演。\"," +
        "\"AbstractURL\":\"https://baike.baidu.com/item/漫长的季节\"," +
        "\"RelatedTopics\":[" +
        "{\"Text\":\"漫长的季节 — 百度百科\",\"FirstURL\":\"https://baike.baidu.com/item/漫长的季节\"}," +
        "{\"Text\":\"腾讯视频 — 漫长的季节\",\"FirstURL\":\"https://v.qq.com/x/cover/mzc00200y1ehh8w.html\"}" +
        "]}";

    // ═══════════════ 降级链顺序 ═══════════════

    @Test public void testDoubanSuccess_dontFallback() {
        TestDramaSource ds = new TestDramaSource(DOUBAN_OK, null);
        List<DramaItem> results = ds.search("漫长的季节");
        assertFalse("豆瓣成功应返回结果", results.isEmpty());
        assertEquals("来源应为豆瓣", "douban", results.get(0).source);
        assertEquals("应解析出 3 条", 3, results.size());
    }

    @Test public void testDoubanEmpty_fallbackToDDG() {
        TestDramaSource ds = new TestDramaSource(DOUBAN_EMPTY, DDG_OK);
        List<DramaItem> results = ds.search("漫长的季节");
        assertFalse("DDG 应返回结果", results.isEmpty());
        assertEquals("来源应为 ddg", "ddg", results.get(0).source);
    }

    @Test public void testBothFail_returnsEmpty() {
        TestDramaSource ds = new TestDramaSource(DOUBAN_EMPTY, null);
        List<DramaItem> results = ds.search("漫长的季节");
        assertTrue("双源全挂应返回空列表", results.isEmpty());
    }

    @Test public void testDoubanException_fallbackToDDG() {
        TestDramaSource ds = new TestDramaSource("INVALID_JSON_{{{", DDG_OK);
        List<DramaItem> results = ds.search("漫长的季节");
        assertFalse("豆瓣异常应降级 DDG", results.isEmpty());
        assertEquals("ddg", results.get(0).source);
    }

    @Test public void testBothException_returnsEmpty() {
        TestDramaSource ds = new TestDramaSource("INVALID_{{{", "INVALID_{{{");
        List<DramaItem> results = ds.search("漫长的季节");
        assertTrue("双源异常应返回空列表", results.isEmpty());
    }

    // ═══════════════ 豆瓣解析 ═══════════════

    @Test public void testDoubanParseFields() {
        TestDramaSource ds = new TestDramaSource(DOUBAN_OK, null);
        List<DramaItem> results = ds.search("test");
        DramaItem first = results.get(0);
        assertEquals("漫长的季节", first.title);
        assertEquals("2023", first.year);
        assertTrue(first.poster.contains("doubanio.com"));
        assertTrue(first.url.contains("douban.com"));
        assertEquals("tencent", first.platform); // inferPlatform("漫长的季节") → tencent
    }

    @Test public void testDoubanFilterNonTvMovie() {
        String jsonWithMovie = "[{\"id\":\"1\",\"title\":\"电影\",\"type\":\"movie\",\"year\":\"2024\"}]";
        TestDramaSource ds = new TestDramaSource(jsonWithMovie, null);
        List<DramaItem> results = ds.search("test");
        assertEquals(1, results.size());
        assertEquals("电影", results.get(0).title);
    }

    @Test public void testDoubanMaxFourItems() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 1; i <= 10; i++) {
            if (i > 1) sb.append(",");
            sb.append("{\"id\":\"").append(i).append("\",\"title\":\"剧")
              .append(i).append("\",\"type\":\"tv\",\"year\":\"2024\"}");
        }
        sb.append("]");
        TestDramaSource ds = new TestDramaSource(sb.toString(), null);
        List<DramaItem> results = ds.search("test");
        assertEquals("最多 4 条", 4, results.size());
    }

    // ═══════════════ 频率保护 ═══════════════

    @Test public void testDoubanRateLimit_enforced() {
        TestDramaSource ds = new TestDramaSource(DOUBAN_OK, null);
        long t0 = System.currentTimeMillis();
        ds.search("query1");
        ds.search("query2");
        long elapsed = System.currentTimeMillis() - t0;
        assertTrue("两次调用应间隔 ≥1s, 实际 " + elapsed + "ms", elapsed >= 900);
    }

    @Test public void testDoubanBackoffAfterFailures() {
        TestDramaSource ds = new TestDramaSource("INVALID_{{{", null);
        ds.search("query1"); // 失败 1 → backoff 2s
        ds.search("query2"); // 退避中，跳过
        ds.search("query3"); // 退避中，跳过
        // 至少第 2、3 次被跳过（退避期内）
        assertTrue("连续失败后应触发退避", ds.doubanSkippedCount >= 1);
    }

    // ═══════════════ DDG 解析 ═══════════════

    @Test public void testDDGParseAbstract() {
        TestDramaSource ds = new TestDramaSource(DOUBAN_EMPTY, DDG_OK);
        List<DramaItem> results = ds.search("test");
        assertFalse(results.isEmpty());
        // Abstract + 2 RelatedTopics = 3 条
        assertTrue("DDG 应 ≥2 条结果", results.size() >= 2);
    }

    // ═══════════════ 平台推测 ═══════════════

    @Test public void testPlatformInference() {
        assertEquals("tencent", new TestDramaSource(DOUBAN_EMPTY, null).inferPlatformPublic("漫长的季节"));
        assertEquals("tencent", new TestDramaSource(DOUBAN_EMPTY, null).inferPlatformPublic("繁花"));
        assertEquals("bilibili", new TestDramaSource(DOUBAN_EMPTY, null).inferPlatformPublic("我的阿勒泰"));
        assertEquals("iqiyi", new TestDramaSource(DOUBAN_EMPTY, null).inferPlatformPublic("狂飙"));
        assertEquals("", new TestDramaSource(DOUBAN_EMPTY, null).inferPlatformPublic("未知剧"));
    }

    @Test public void testPlatformToPackage() {
        assertEquals("tv.danmaku.bili", DramaSource.platformToPackage("bilibili"));
        assertEquals("com.tencent.qqlive", DramaSource.platformToPackage("tencent"));
        assertEquals("com.qiyi.video", DramaSource.platformToPackage("iqiyi"));
        assertNull(DramaSource.platformToPackage("unknown"));
    }

    // ═══════════════ JSON 序列化 ═══════════════

    @Test public void testToJSON() {
        DramaItem item = new DramaItem(
                "测试剧", "2024", "https://img.test/p.jpg",
                "https://test.com", "tencent", "douban");
        String json = item.toJSON().toString();
        assertTrue(json.contains("测试剧"));
        assertTrue(json.contains("tencent"));
        assertTrue(json.contains("douban"));
    }

    // ═══════════════ 辅助类 ═══════════════

    /**
     * 可注入模拟响应的 DramaSource 子类（用于单测）。
     * 不发起真实 HTTP 请求，直接用预置 JSON 字符串模拟。
     */
    static class TestDramaSource extends DramaSource {
        private final String doubanJson;
        private final String ddgJson;
        int doubanSkippedCount;

        TestDramaSource(String doubanJson, String ddgJson) {
            this.doubanJson = doubanJson;
            this.ddgJson = ddgJson;
        }

        @Override
        public List<DramaItem> search(String query) {
            if (query == null || query.trim().isEmpty()) return java.util.Collections.emptyList();
            List<DramaItem> results = tryDouban(query);
            if (!results.isEmpty()) { doubanConsecutiveFailures = 0; return results; }
            results = tryDDG(query);
            return results != null ? results : java.util.Collections.emptyList();
        }

        @Override
        List<DramaItem> tryDouban(String query) {
            long now = System.currentTimeMillis();
            if (now < doubanBackoffUntil) {
                doubanSkippedCount++;
                return java.util.Collections.emptyList();
            }
            long sinceLast = now - lastDoubanCall;
            if (sinceLast < DOUBAN_INTERVAL_MS) {
                try { Thread.sleep(DOUBAN_INTERVAL_MS - sinceLast); } catch (InterruptedException e) {}
            }
            lastDoubanCall = System.currentTimeMillis();

            if (doubanJson == null) {
                doubanConsecutiveFailures++;
                doubanBackoffUntil = System.currentTimeMillis() + 2000;
                return java.util.Collections.emptyList();
            }
            try {
                return parseDoubanResponse(doubanJson);
            } catch (Exception e) {
                doubanConsecutiveFailures++;
                doubanBackoffUntil = System.currentTimeMillis() + 2000;
                return java.util.Collections.emptyList();
            }
        }

        @Override
        List<DramaItem> tryDDG(String query) {
            if (ddgJson == null) return java.util.Collections.emptyList();
            try {
                return parseDDGResponse(ddgJson);
            } catch (Exception e) {
                return java.util.Collections.emptyList();
            }
        }

        // 暴露 package-private 方法供测试
        String inferPlatformPublic(String title) { return inferPlatform(title); }
    }
}
