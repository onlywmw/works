package com.hermes.android.toolprovider;

import static org.junit.Assert.*;

import com.hermes.android.agent.ToolRegistry;

import org.junit.Test;

import java.util.List;

/**
 * HermesToolProvider web.search / web.fetch HTML 解析零网络单测。
 * 直喂真实形态 DDG HTML fixture (result__a / result__snippet 结构) 与正文 fixture,
 * 全程不走网络 — 只测抽出的 package-private 静态纯函数。
 */
public class HermesWebParseTest {

    /* 真实形态: html.duckduckgo.com 结果页 — result results_links / result__title /
       result__a (href 为 DDG 跳转链接) / result__snippet (内嵌 <b>) */
    private static final String DDG_HTML =
            "<!DOCTYPE html><html><head><title>android 平板 at DuckDuckGo</title></head><body>"
            + "<form id=\"search_form\" action=\"/html/\"><input type=\"text\" name=\"q\" value=\"android 平板\"/></form>"
            + "<div class=\"results\">"
            + "<div class=\"result results_links results_links_deep web-result\">"
            + "<div class=\"links_main links_deep result__body\">"
            + "<h2 class=\"result__title\">"
            + "<a rel=\"nofollow\" class=\"result__a\" href=\"https://duckduckgo.com/l/?uddg=https%3A%2F%2Fdeveloper.android.com%2Ftablet&amp;rut=abc\">Android 平板开发指南</a>"
            + "</h2>"
            + "<div class=\"result__extras\"></div>"
            + "<a class=\"result__snippet\" href=\"https://duckduckgo.com/l/?uddg=https%3A%2F%2Fdeveloper.android.com%2Ftablet\">官方 <b>Android</b> 平板应用开发文档，含布局适配。</a>"
            + "</div></div>"
            + "<div class=\"result results_links results_links_deep web-result\">"
            + "<div class=\"links_main links_deep result__body\">"
            + "<h2 class=\"result__title\">"
            + "<a rel=\"nofollow\" class=\"result__a\" href=\"https://duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Freview&amp;rut=def\">2026 平板横评</a>"
            + "</h2>"
            + "<a class=\"result__snippet\" href=\"https://duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Freview\">十款 <b>平板</b> 实测对比。</a>"
            + "</div></div>"
            + "<div class=\"result results_links results_links_deep web-result\">"
            + "<div class=\"links_main links_deep result__body\">"
            + "<h2 class=\"result__title\">"
            + "<a rel=\"nofollow\" class=\"result__a\" href=\"https://duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fnosnippet&amp;rut=ghi\">无摘要条目</a>"
            + "</h2>"
            + "</div></div>"
            + "</div></body></html>";

    /* 真实形态: DDG 真空结果页 — 有搜索表单 + no-results 标记, 无 result__a */
    private static final String DDG_NO_RESULTS_HTML =
            "<!DOCTYPE html><html><body>"
            + "<form id=\"search_form\" action=\"/html/\"><input type=\"text\" name=\"q\" value=\"zzz不存在zzz\"/></form>"
            + "<div class=\"results\"><div class=\"no-results\">No results.</div></div>"
            + "</body></html>";

    /* 真实形态: 风控/拦截页 — DDG anomaly 验证码页, 无搜索表单无结果 */
    private static final String DDG_BLOCKED_HTML =
            "<!DOCTYPE html><html><head><title>DuckDuckGo</title></head><body>"
            + "<div id=\"anomaly-modal\"><p>Unfortunately, bots use DuckDuckGo too.</p>"
            + "<div class=\"challenge\"></div></div>"
            + "</body></html>";

    // ==================== parseDdgResults ====================

    @Test
    public void ddg_parsesTitleUrlSnippet() {
        List<HermesToolProvider.DdgResult> rs = HermesToolProvider.parseDdgResults(DDG_HTML, 5);
        assertEquals("应解析出 3 条结果", 3, rs.size());

        assertEquals("Android 平板开发指南", rs.get(0).title);
        assertTrue("链接取自 result__a href",
                rs.get(0).url.contains("uddg=https%3A%2F%2Fdeveloper.android.com%2Ftablet"));
        assertEquals("摘要剔除内嵌 <b> 标签", "官方 Android 平板应用开发文档，含布局适配。", rs.get(0).snippet);

        assertEquals("2026 平板横评", rs.get(1).title);
        assertEquals("十款 平板 实测对比。", rs.get(1).snippet);

        assertEquals("无摘要条目", rs.get(2).title);
        assertEquals("无 result__snippet 时摘要为空串", "", rs.get(2).snippet);
    }

    @Test
    public void ddg_respectsMax() {
        assertEquals(1, HermesToolProvider.parseDdgResults(DDG_HTML, 1).size());
        assertEquals(2, HermesToolProvider.parseDdgResults(DDG_HTML, 2).size());
        assertEquals("max 超过结果数时返回全部", 3,
                HermesToolProvider.parseDdgResults(DDG_HTML, 99).size());
    }

    @Test
    public void ddg_malformedInput_returnsEmptyNoThrow() {
        assertTrue(HermesToolProvider.parseDdgResults(null, 5).isEmpty());
        assertTrue(HermesToolProvider.parseDdgResults("", 5).isEmpty());
        assertTrue(HermesToolProvider.parseDdgResults("完全不是 HTML", 5).isEmpty());
        assertTrue(HermesToolProvider.parseDdgResults("<div class=\"result__a\">伪装的 div</div>", 5).isEmpty());
        assertTrue(HermesToolProvider.parseDdgResults("<a class=\"result__a\">缺 href</a>", 5).isEmpty());
        assertTrue("max<=0 返回空", HermesToolProvider.parseDdgResults(DDG_HTML, 0).isEmpty());
    }

    // ==================== ddgZeroResultReason (H1 归因) ====================

    @Test
    public void ddg_zeroResult_attribution() {
        /* 真空结果: DDG 正常页面但无结果 → null (调用方报 ok:true 无搜索结果) */
        assertNull("真空结果页应判 null (真空)",
                HermesToolProvider.ddgZeroResultReason(DDG_NO_RESULTS_HTML));
        /* 拦截/验证码页 → PARSE_DRIFT (与 FastSceneProvider/Ticket12306Provider 同惯例) */
        assertEquals("拦截页应归 PARSE_DRIFT", ToolRegistry.Result.REASON_PARSE_DRIFT,
                HermesToolProvider.ddgZeroResultReason(DDG_BLOCKED_HTML));
        assertEquals("null 输入应归 PARSE_DRIFT", ToolRegistry.Result.REASON_PARSE_DRIFT,
                HermesToolProvider.ddgZeroResultReason(null));
        assertEquals("畸形 HTML 应归 PARSE_DRIFT", ToolRegistry.Result.REASON_PARSE_DRIFT,
                HermesToolProvider.ddgZeroResultReason("<html>??</html>"));
    }

    // ==================== extractMainText (web.fetch) ====================

    @Test
    public void fetch_stripsScriptAndStyle() {
        String html = "<html><head><style>body{color:red}</style>"
                + "<script>var x = 1; track();</script></head>"
                + "<body><h1>标题</h1><p>正文 第一段</p>"
                + "<script>evil()</script>"
                + "<style>.a{}</style></body></html>";
        String text = HermesToolProvider.extractMainText(html);
        assertTrue(text.contains("标题"));
        assertTrue(text.contains("正文 第一段"));
        assertFalse("script 内容必须剔除", text.contains("track"));
        assertFalse("script 内容必须剔除", text.contains("evil"));
        assertFalse("style 内容必须剔除", text.contains("color:red"));
        assertFalse("标签不得残留", text.contains("<"));
    }

    @Test
    public void fetch_collapsesWhitespaceAndHandlesBadInput() {
        assertEquals("多空白折叠", "a b c",
                HermesToolProvider.extractMainText("<p>a</p>\n\n   <p>b</p>\t c"));
        assertEquals("", HermesToolProvider.extractMainText(null));
        assertEquals("", HermesToolProvider.extractMainText(""));
        assertEquals("纯标签页 → 空", "", HermesToolProvider.extractMainText("<div><span></span></div>"));
        assertEquals("畸形 HTML 不炸", "文字", HermesToolProvider.extractMainText("文字<div><p"));
    }
}
