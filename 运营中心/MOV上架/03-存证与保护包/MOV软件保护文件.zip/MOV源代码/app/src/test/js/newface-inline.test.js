/* ============================================================
   newface-inline 防回归测试（node）
   跑法: node app/src/test/js/newface-inline.test.js
   契约: docs/contracts/CARD_DOM_CONTRACT.md §五 —— newface.js 的
   `style="` 应仅剩动态计算（animation-delay/background:/border-color:/
   width:/color: 运行时值）。静态样式一律迁入 newface.css 类。
   ============================================================ */
'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const SRC = fs.readFileSync(path.join(__dirname, '../../main/assets/js/newface.js'), 'utf8');

// 允许在 style= 内保留的「动态计算」属性前缀（契约 §五）
const DYNAMIC = /(^|[;,]\s*)(animation-delay|background|border-color|width|color)\s*:\s*(['+]|var\(|#[0-9a-fA-F]{3,8}|rgba?\(|linear-gradient|dotted|pulse)/;

// 静态属性黑名单：任一出现在 style= 上下文即视为静态残留
const STATIC_BLACKLIST = /(font-size|padding|margin|display|flex\b|cursor|border-radius|border-style|position|z-index|text-align|letter-spacing|font-weight|line-height|font-family|white-space|gap|min-width|appearance|width:100%|border:1px)/;

function main() {
  const lines = SRC.split('\n');
  let total = 0, flagged = [];
  lines.forEach(function(line, i) {
    let idx = line.indexOf('style="');
    if (idx < 0) return;
    total++;
    const tail = line.slice(idx + 7); // style=" 之后到行尾（拼接可能未闭合）
    // 逐段校验：以分号/拼接符分隔的属性，静态属性必须为零
    if (STATIC_BLACKLIST.test(tail)) {
      // 排除恰好命中「动态属性值」内部的误报（如 color 值的 rgba/hex 不含静态词，可放心）
      flagged.push('L' + (i + 1) + ': ' + line.trim());
    }
  });
  assert.strictEqual(flagged.length, 0, '静态内联样式残留:\n' + flagged.join('\n'));
  console.log('style= 总数:', total, '— 全部为动态计算（animation-delay/background/width/color 运行时值），静态清零 ✓');
}

main();
