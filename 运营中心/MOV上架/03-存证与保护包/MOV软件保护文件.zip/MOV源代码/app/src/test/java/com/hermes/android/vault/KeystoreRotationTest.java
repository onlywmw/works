package com.hermes.android.vault;

import org.junit.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.security.KeyStore;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import static org.junit.Assert.*;

/**
 * v1.1 钥匙轮换/别名升级单测（真 JCEKS 白盒，零 mock）。
 *
 * 场景：升级前用旧 key 加密的条目，升级后（新别名 key + 旧 key 作 legacy）解锁
 * 必须走 decryptLegacy 解密成功 → 并重加密到当前 key（后续只用当前 key 也能解）。
 * 这正是「install -r 保留旧 spec 钥匙 → 加密修复对已装机不生效」的规避路径。
 */
public class KeystoreRotationTest {

    /** 单 key JCEKS（模拟升级前，只有旧 key） */
    private static class SingleJceksCrypto implements SecureVault.CryptoEngine {
        final SecretKey key;
        SingleJceksCrypto(File ksFile) throws Exception {
            this.key = loadOrCreate(ksFile);
        }
        public byte[] encrypt(byte[] p) throws Exception { return AesGcm.encrypt(key, p); }
        public byte[] decrypt(byte[] d) throws Exception { return AesGcm.decrypt(key, d); }
    }

    /** 双 key JCEKS（模拟升级后：当前 key + 旧 key 作 legacy 迁移回退） */
    private static class DualJceksCrypto implements SecureVault.CryptoEngine {
        final SecretKey current, legacy;
        DualJceksCrypto(File curFile, File legacyFile) throws Exception {
            this.current = loadOrCreate(curFile);
            this.legacy = loadOrCreate(legacyFile);
        }
        public byte[] encrypt(byte[] p) throws Exception { return AesGcm.encrypt(current, p); }
        public byte[] decrypt(byte[] d) throws Exception { return AesGcm.decrypt(current, d); }
        @Override public byte[] decryptLegacy(byte[] d) {
            try { return AesGcm.decrypt(legacy, d); }
            catch (Exception e) { return null; }
        }
    }

    private static SecretKey loadOrCreate(File f) throws Exception {
        char[] pw = "rot-test".toCharArray();
        KeyStore ks = KeyStore.getInstance("JCEKS");
        if (f.exists()) {
            try (FileInputStream in = new FileInputStream(f)) { ks.load(in, pw); }
        } else {
            ks.load(null, null);
        }
        SecretKey k = (SecretKey) ks.getKey("vault", pw);
        if (k == null) {
            KeyGenerator kg = KeyGenerator.getInstance("AES");
            kg.init(256);
            k = kg.generateKey();
            ks.setKeyEntry("vault", k, pw, null);
            try (FileOutputStream out = new FileOutputStream(f)) { ks.store(out, pw); }
        }
        return k;
    }

    private File tempDir() throws Exception {
        File d = new File(System.getProperty("java.io.tmpdir"),
                "rot_" + System.currentTimeMillis() + "_" + (int) (Math.random() * 100000));
        d.mkdirs();
        return d;
    }

    @Test public void legacyEntry_unlocksViaMigrationAndReencryptsToCurrent() throws Exception {
        File dir = tempDir();
        String secret = "升级前加密的机密内容-身份证11010519491231002X";

        // 1. 升级前：旧 key 加密落盘
        File legacyKs = new File(dir, "legacy.jks");
        SecureVault.CryptoEngine legacyOnly = new SingleJceksCrypto(legacyKs);
        String id = new SecureVault(new File(dir, "vault"), legacyOnly).lock("旧条目", secret);

        // 2. 升级后：当前 key + 旧 key legacy → 解锁走迁移
        File currentKs = new File(dir, "current.jks");
        SecureVault.CryptoEngine dual = new DualJceksCrypto(currentKs, legacyKs);
        SecureVault vault = new SecureVault(new File(dir, "vault"), dual);
        assertEquals("旧条目经 legacy 迁移解密成功", secret, vault.unlock(id));

        // 3. 重加密后：只用当前 key（无 legacy）也能解 → 迁移完成
        SecureVault.CryptoEngine currentOnly = new SingleJceksCrypto(currentKs);
        SecureVault v2 = new SecureVault(new File(dir, "vault"), currentOnly);
        assertEquals("条目已重加密到当前 key", secret, v2.unlock(id));
    }

    @Test public void currentKeyEntry_doesNotNeedLegacy() throws Exception {
        File dir = tempDir();
        File cur = new File(dir, "cur.jks");
        SecureVault.CryptoEngine curOnly = new SingleJceksCrypto(cur);
        String id = new SecureVault(new File(dir, "vault"), curOnly).lock("新条目", "当前 key 内容");

        // 升级后: 当前 key 条目直接用当前 key 解, decryptLegacy 不参与
        File legacy = new File(dir, "legacy.jks");
        SecureVault vault = new SecureVault(new File(dir, "vault"), new DualJceksCrypto(cur, legacy));
        assertEquals("当前 key 条目直接解", "当前 key 内容", vault.unlock(id));
        assertTrue("条目仍在(未被破坏)", new File(new File(dir, "vault"), id + ".enc").exists());
    }

    @Test public void aliasVersionScheme() {
        assertEquals("v1 别名", "mov_vault_key", KeystoreCrypto.aliasFor(1));
        assertEquals("v2 别名", "mov_vault_key_v2", KeystoreCrypto.aliasFor(2));
        assertEquals("v3 别名", "mov_vault_key_v3", KeystoreCrypto.aliasFor(3));
    }
}
