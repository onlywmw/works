package com.hermes.android.vault;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyStore;
import java.util.List;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import static org.junit.Assert.*;

/**
 * SecureVault 单测 — 真 Keystore 白盒（KeystoreFallback 三形态①防守）。
 *
 * 测试密钥放真 JCEKS KeyStore 文件（setKeyEntry/store/重载 getKey），
 * 加解密走与生产共用的 AesGcm 核心。断言的不是 mock 输入，而是落盘实物的真实性质：
 * round-trip、密文 grep 无明文、index 无内容泄漏、篡改 GCM 拒绝。
 * 若生产把加密改成返回明文（假加密），密文 grep 断言必红。
 */
public class SecureVaultTest {

    /** 真 JCEKS KeyStore 白盒：真密钥文件，真实 AES 加解密 */
    private static class JceksCrypto implements SecureVault.CryptoEngine {
        final SecretKey key;

        JceksCrypto(File ksFile) throws Exception {
            char[] pw = "vault-test".toCharArray();
            KeyStore ks = KeyStore.getInstance("JCEKS");
            if (ksFile.exists()) {
                try (FileInputStream in = new FileInputStream(ksFile)) { ks.load(in, pw); }
            } else {
                ks.load(null, null);
            }
            SecretKey k = (SecretKey) ks.getKey("vault", pw);
            if (k == null) {
                KeyGenerator kg = KeyGenerator.getInstance("AES");
                kg.init(256);
                k = kg.generateKey();
                ks.setKeyEntry("vault", k, pw, null);
                try (FileOutputStream out = new FileOutputStream(ksFile)) { ks.store(out, pw); }
            }
            this.key = k;
        }

        @Override public byte[] encrypt(byte[] p) throws Exception { return AesGcm.encrypt(key, p); }
        @Override public byte[] decrypt(byte[] d) throws Exception { return AesGcm.decrypt(key, d); }
    }

    private File tempDir() throws Exception {
        File d = new File(System.getProperty("java.io.tmpdir"),
                "vault_" + System.currentTimeMillis() + "_" + (int) (Math.random() * 100000));
        d.mkdirs();
        return d;
    }

    private SecureVault newVault(File dir) throws Exception {
        // 镜像生产布局: vaultDir = <root>/vault（filesDir/vault），密钥文件放 root 下
        return new SecureVault(new File(dir, "vault"), new JceksCrypto(new File(dir, "test-keystore.jks")));
    }

    private static boolean containsBytes(byte[] haystack, String needle) {
        byte[] n = needle.getBytes(StandardCharsets.UTF_8);
        if (n.length == 0) return true;
        outer:
        for (int i = 0; i + n.length <= haystack.length; i++) {
            for (int j = 0; j < n.length; j++) {
                if (haystack[i + j] != n[j]) continue outer;
            }
            return true;
        }
        return false;
    }

    // ==================== 核心行为 ====================

    @Test public void roundTrip_encryptThenDecryptRestoresOriginal() throws Exception {
        File dir = tempDir();
        SecureVault v = newVault(dir);
        String secret = "病历：张三 高血压 用药：拜新同 每日一次";
        String id = v.lock("病历", secret);
        assertNotNull("lock 返回 id", id);
        assertEquals("round-trip 还原", secret, v.unlock(id));
    }

    @Test public void cipherFileContainsNoPlaintextSubstring() throws Exception {
        File dir = tempDir();
        SecureVault v = newVault(dir);
        String secret = "机密病历PII-11010519491231002X-13812345678-6222020200112233445";
        String id = v.lock("病历", secret);
        File enc = new File(new File(dir, "vault"), id + ".enc");
        assertTrue("密文文件应存在", enc.exists());
        byte[] cipher = Files.readAllBytes(enc.toPath());
        // grep 断言: 密文不含明文任何片段（逐段字节搜索）
        assertFalse("密文含病历字串", containsBytes(cipher, "病历"));
        assertFalse("密文含身份证号", containsBytes(cipher, "11010519491231002X"));
        assertFalse("密文含手机号", containsBytes(cipher, "13812345678"));
        assertFalse("密文含卡号", containsBytes(cipher, "6222020200112233445"));
    }

    @Test public void samePlaintextTwiceProduceDifferentCiphertext() throws Exception {
        File dir = tempDir();
        SecureVault v = newVault(dir);
        String id1 = v.lock("病历", "同一份内容");
        String id2 = v.lock("病历", "同一份内容");
        byte[] c1 = Files.readAllBytes(new File(new File(dir, "vault"), id1 + ".enc").toPath());
        byte[] c2 = Files.readAllBytes(new File(new File(dir, "vault"), id2 + ".enc").toPath());
        assertFalse("随机 IV → 密文不重复", java.util.Arrays.equals(c1, c2));
    }

    @Test public void indexHasNoContentLeak() throws Exception {
        File dir = tempDir();
        SecureVault v = newVault(dir);
        String secret = "机密内容-身份证11010519491231002X";
        v.lock("病历", secret);
        File idx = new File(new File(dir, "vault"), "index.json");
        String index = new String(Files.readAllBytes(idx.toPath()), StandardCharsets.UTF_8);
        assertFalse("index 无明文内容", index.contains(secret));
        assertFalse("index 无身份证号", index.contains("11010519491231002X"));
        // 元信息字段齐全，且无 content 字段
        JSONObject o = new JSONObject(index);
        JSONArray entries = o.getJSONArray("entries");
        assertEquals(1, entries.length());
        JSONObject e = entries.getJSONObject(0);
        assertTrue("有 id", e.has("id"));
        assertTrue("有 name", e.has("name"));
        assertTrue("有 createdAtMs", e.has("createdAtMs"));
        assertTrue("有 sizeBytes", e.has("sizeBytes"));
        assertFalse("index 条目无 content 字段", e.has("content"));
    }

    @Test public void namePiiIsMaskedInIndex() throws Exception {
        File dir = tempDir();
        SecureVault v = newVault(dir);
        v.lock("李四-身份证11010519491231002X", "内容");
        String index = new String(Files.readAllBytes(
                new File(new File(dir, "vault"), "index.json").toPath()), StandardCharsets.UTF_8);
        assertFalse("name 里的身份证号被泛化", index.contains("11010519491231002X"));
        assertTrue("长数字串已泛化为 [数字]", index.contains("[数字]"));
    }

    // ==================== 生命周期 ====================

    @Test public void list_returnsMetadataWithoutContent() throws Exception {
        File dir = tempDir();
        SecureVault v = newVault(dir);
        String id = v.lock("扫描文档 2026-08-01", "原文内容XYZ123");
        List<SecureVault.VaultEntry> entries = v.list();
        assertEquals(1, entries.size());
        SecureVault.VaultEntry e = entries.get(0);
        assertEquals("id 一致", id, e.id);
        assertEquals("名称一致", "扫描文档 2026-08-01", e.name);
        assertTrue("sizeBytes 为密文长度(>0)", e.sizeBytes > 0);
    }

    @Test public void delete_removesFileAndIndexEntry() throws Exception {
        File dir = tempDir();
        SecureVault v = newVault(dir);
        String idA = v.lock("a", "secret1");
        v.lock("b", "secret2");
        assertTrue("delete 成功", v.delete(idA));
        List<SecureVault.VaultEntry> list = v.list();
        assertEquals("删后剩 1 条", 1, list.size());
        assertEquals("剩的是 b", "b", list.get(0).name);
        assertFalse("密文文件已删", new File(new File(dir, "vault"), idA + ".enc").exists());
        try {
            v.unlock(idA);
            fail("删除后 unlock 应抛 NOT_FOUND");
        } catch (VaultException e) {
            assertEquals("NOT_FOUND", e.code);
        }
    }

    @Test public void persistsAcrossInstances() throws Exception {
        File dir = tempDir();
        String secret = "跨实例持久化内容";
        String id = newVault(dir).lock("病历", secret);
        SecureVault v2 = newVault(dir);   // 新实例 + 同一 JCEKS 密钥文件 → 解密同一批密文
        assertEquals("新实例能解密", secret, v2.unlock(id));
        assertEquals(1, v2.list().size());
    }

    // ==================== 安全边界 ====================

    @Test public void tamperedCiphertextFailsGcmAuth() throws Exception {
        File dir = tempDir();
        SecureVault v = newVault(dir);
        String id = v.lock("病历", "这是不能被篡改的内容");
        File enc = new File(new File(dir, "vault"), id + ".enc");
        byte[] ct = Files.readAllBytes(enc.toPath());
        ct[ct.length - 1] ^= 0x01;   // 翻转 tag 区最后一字节
        Files.write(enc.toPath(), ct);
        try {
            v.unlock(id);
            fail("篡改后解密应失败");
        } catch (VaultException e) {
            assertEquals("DECRYPT_FAILED", e.code);
        }
    }

    @Test public void emptyContentRejected() throws Exception {
        SecureVault v = newVault(tempDir());
        try {
            v.lock("病历", "");
            fail("空内容应拒绝");
        } catch (VaultException e) {
            assertEquals("EMPTY", e.code);
        }
    }
}
