package com.hermes.android.llama;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * M2 语义召回：EmbeddingServerManager 纯 JVM 单测（decide/isIdleTimedOut/buildServerCommand 纯函数；
 * healthz 注入假探针，零网络）。验收见 docs/PLAN_SEMANTIC_RECALL_2026-08-09.md §七 M2。
 */
public class EmbeddingServerManagerTest {

    @Test
    public void decide_reuse_whenHealthy() {
        assertEquals(EmbeddingServerManager.Decision.REUSE,
                EmbeddingServerManager.decide(true, false, false));
    }

    @Test
    public void decide_wait_whenProcessAliveButUnhealthy() {
        assertEquals(EmbeddingServerManager.Decision.WAIT,
                EmbeddingServerManager.decide(false, true, false));
    }

    @Test
    public void decide_noInstall_whenNothingReady() {
        assertEquals(EmbeddingServerManager.Decision.NO_INSTALL,
                EmbeddingServerManager.decide(false, false, false));
    }

    @Test
    public void decide_start_whenInstallReadyNotHealthy() {
        assertEquals(EmbeddingServerManager.Decision.START,
                EmbeddingServerManager.decide(false, false, true));
    }

    @Test
    public void isIdleTimedOut_onlyWhenProcessAndPastTimeout() {
        long now = System.currentTimeMillis();
        long timeoutSec = EmbeddingServerManager.IDLE_TIMEOUT_SEC;
        // 有进程 + 超时 → true
        assertTrue(EmbeddingServerManager.isIdleTimedOut(true, now - (timeoutSec + 1) * 1000L, now));
        // 有进程 + 未超时 → false
        assertFalse(EmbeddingServerManager.isIdleTimedOut(true, now - 1000L, now));
        // 无进程 → false（即使 lastCall 很早）
        assertFalse(EmbeddingServerManager.isIdleTimedOut(false, now - (timeoutSec + 1) * 1000L, now));
        // lastCall 未初始化 → false
        assertFalse(EmbeddingServerManager.isIdleTimedOut(true, 0L, now));
    }

    @Test
    public void buildServerCommand_embeddingFlag_port8081_noMmproj() {
        String cmd = EmbeddingServerManager.buildServerCommand("bge-small-zh-v1.5-q8_0.gguf", "tok123");
        assertTrue(cmd.contains("llama-server -m /models/bge-small-zh-v1.5-q8_0.gguf"));
        assertTrue(cmd.contains("--embedding"));                 // 暴露 /v1/embeddings
        assertTrue(cmd.contains("--port " + EmbeddingServerManager.PORT));
        assertTrue(cmd.contains("--api-key tok123"));
        assertFalse(cmd.contains("--mmproj"));                   // 纯文本 embedding，无视觉投影
        assertFalse(cmd.contains("8080"));                       // 隔离 OCR 实例端口
    }

    @Test
    public void installReady_nullContext_returnsFalse() {
        assertFalse(EmbeddingServerManager.installReady(null));
    }

    @Test
    public void healthz_probeOverride_used() {
        EmbeddingServerManager.setProbeForTest(() -> true);
        try {
            assertTrue(EmbeddingServerManager.healthz(null));
        } finally {
            EmbeddingServerManager.setProbeForTest(null);
        }
        EmbeddingServerManager.setProbeForTest(() -> false);
        try {
            assertFalse(EmbeddingServerManager.healthz(null));
        } finally {
            EmbeddingServerManager.setProbeForTest(null);
        }
    }

    @Test
    public void urlSafeToken_lengthAndCharset() {
        String t = EmbeddingServerManager.urlSafeToken(24);
        assertNotNull(t);
        assertEquals(24, t.length());
        assertTrue(t.matches("[A-Za-z0-9_-]{24}"));
    }
}
