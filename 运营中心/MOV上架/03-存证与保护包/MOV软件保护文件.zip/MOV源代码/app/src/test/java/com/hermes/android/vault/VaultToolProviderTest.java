package com.hermes.android.vault;

import com.hermes.android.agent.ToolRegistry;

import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * VaultToolProvider 结构单测（纯 JVM，不跑 handler）：
 * 验证工具分级契约（DESIGN §六纪律 5）— vault_lock/vault_unlock = ACTION(审批闸)，
 * vault_list = READONLY(只列名不列内容)。分类错了拿真机验收前就被抓。
 */
public class VaultToolProviderTest {

    @Test public void registersThreeVaultToolsWithCorrectClassification() {
        List<ToolRegistry.Tool> tools = new VaultToolProvider().discover();
        assertEquals("应注册 3 个 vault 工具", 3, tools.size());

        ToolRegistry.Tool lock = find(tools, "vault_lock");
        ToolRegistry.Tool unlock = find(tools, "vault_unlock");
        ToolRegistry.Tool list = find(tools, "vault_list");
        assertNotNull("vault_lock 存在", lock);
        assertNotNull("vault_unlock 存在", unlock);
        assertNotNull("vault_list 存在", list);

        // vault_lock = ACTION（审批闸）
        assertEquals("vault_lock access=write(ACTION)", "write", lock.access);
        assertEquals("vault_lock approval=always(审批闸)", "always", lock.approval);
        // vault_unlock = ACTION（审批闸）
        assertEquals("vault_unlock access=write(ACTION)", "write", unlock.access);
        assertEquals("vault_unlock approval=always(审批闸)", "always", unlock.approval);
        // vault_list = READONLY
        assertEquals("vault_list access=readonly", "readonly", list.access);
        assertEquals("vault_list approval=none", "none", list.approval);
    }

    @Test public void vaultToolsCarryVaultCategory() {
        List<ToolRegistry.Tool> tools = new VaultToolProvider().discover();
        for (ToolRegistry.Tool t : tools) {
            assertNotNull("有 manifest: " + t.name, t.manifest);
            assertEquals("category=vault: " + t.name, "vault", t.manifest.category);
        }
    }

    @Test public void vaultLockParamsRequireNameAndText() {
        ToolRegistry.Tool lock = find(new VaultToolProvider().discover(), "vault_lock");
        assertNotNull(lock.params);
        boolean hasName = false, hasText = false;
        for (ToolRegistry.ParamDef p : lock.params) {
            if ("name".equals(p.name)) { hasName = true; assertTrue("name 必填", p.required); }
            if ("text".equals(p.name)) { hasText = true; assertTrue("text 必填", p.required); }
        }
        assertTrue("vault_lock 有 name 参数", hasName);
        assertTrue("vault_lock 有 text 参数", hasText);
    }

    private static ToolRegistry.Tool find(List<ToolRegistry.Tool> tools, String name) {
        for (ToolRegistry.Tool t : tools) if (name.equals(t.name)) return t;
        return null;
    }
}
