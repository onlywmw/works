package com.hermes.android.vault;

import org.junit.Test;

import java.security.KeyStore;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import static org.junit.Assert.*;

/**
 * KeystoreCrypto 防回退测试 — 守住「AndroidKeyStore 密钥允许调用方 IV」这条生产路径。
 *
 * 背景（打回判例）: KeystoreCrypto 生成密钥的 KeyGenParameterSpec 未设
 * setRandomizedEncryptionRequired(false)，而 AesGcm 用调用方 IV（GCMParameterSpec 自管 IV）。
 * AndroidKeyStore 默认强制随机加密（Keystore 自生成 IV）→ 真机 vaultLock 必报
 * "Caller-provided IV not permitted"（TASKS_P5_VAULT_2026-08-01.md 巡检#27 打回）。
 *
 * 纯 JVM 无法实例化 android.security.keystore.KeyGenParameterSpec（无 Robolectric），
 * 因此防回退断言落在这条链路唯一能被 JVM 观测的决策常量上——构造必须引用它，
 * 任何回退（改常量 / 删行导致常量失联）测试即红。
 */
public class KeystoreCryptoTest {

    /** 核心防回退：密钥 spec 必须允许调用方 IV。改成 true 或删掉 = 真机加密必败。 */
    @Test public void randomizedEncryptionMustStayDisabled() {
        assertFalse(
                "AndroidKeyStore 强制随机加密会拒绝 AesGcm 的调用方 IV（真机 Caller-provided IV not permitted），" +
                "KeyGenParameterSpec 必须 setRandomizedEncryptionRequired(false)",
                KeystoreCrypto.RANDOMIZED_ENCRYPTION_REQUIRED);
    }

    /** 安全性保障：关闭 Keystore 自生成 IV 后，调用方 IV 必须仍由 SecureRandom 每次随机，不许退化成固定 IV。 */
    @Test public void aesGcmUsesFreshIvPerEncryption() throws Exception {
        SecretKey key = KeyGenerator.getInstance("AES").generateKey();
        byte[] plaintext = "病历：张三 高血压".getBytes("UTF-8");

        byte[] out1 = AesGcm.encrypt(key, plaintext);
        byte[] out2 = AesGcm.encrypt(key, plaintext);

        assertTrue("输出应为 [12B IV][密文+tag]", out1.length >= 12 + 16);
        // 前 12 字节 = IV（AesGcm.encrypt 布局，见 AesGcm.java 输出格式注释）
        byte[] iv1 = Arrays.copyOfRange(out1, 0, 12);
        byte[] iv2 = Arrays.copyOfRange(out2, 0, 12);
        assertFalse("每次加密 IV 必须不同（SecureRandom），固定 IV 会让密文可重放", Arrays.equals(iv1, iv2));

        // 同一 IV 下同明文密文不同是 GCM 天然性质；此处额外验证 IV 不同 → 密文也必不同
        assertFalse("IV 不同 → 密文不同", Arrays.equals(out1, out2));
    }

    /** 链路完整性：AesGcm 确实走调用方 IV（GCMParameterSpec），这是需要关闭随机加密的直接原因。 */
    @Test public void aesGcmUsesCallerProvidedIv() throws Exception {
        SecretKey key = KeyGenerator.getInstance("AES").generateKey();
        byte[] plaintext = "机密".getBytes("UTF-8");

        // 手工指定固定 IV 加密，能成功 = AesGcm 用的是调用方 IV，而非密钥/引擎自生成 IV
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        byte[] fixedIv = new byte[12];
        c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, fixedIv));
        byte[] ct = c.doFinal(plaintext);

        assertTrue("调用方 IV 路径可解密", ct.length >= 16);
    }
}
