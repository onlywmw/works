package com.hermes.android.browser;

import com.hermes.android.browser.BrowserActionRouter;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * 浏览器动作类型分派单测（纯 JVM，零 Android）——每个已知类型都有执行落点，scroll 非写。
 */
public class BrowserActionRouterTest {

    @Test public void everyKnownTypeHasRouterEntry() {
        for (String k : BrowserActionRouter.KNOWN) {
            assertTrue("已知类型 " + k + " 应 isKnown", BrowserActionRouter.isKnown(k));
        }
        // 与 mov_connect.js executeAction switch + Java 复合动作对照，10 类全覆盖 (W2 加 snapshot/get_text)
        assertEquals("已知类型 10 个", 10, BrowserActionRouter.KNOWN.length);
    }

    @Test public void unknownTypeNotKnown() {
        assertFalse("未知类型", BrowserActionRouter.isKnown("explode"));
        assertFalse("null 类型", BrowserActionRouter.isKnown(null));
        assertFalse("空串", BrowserActionRouter.isKnown(""));
    }

    @Test public void writeTypesNeedApproval() {
        for (String t : new String[]{"click", "type", "submit", "execute"}) {
            assertTrue("写类型: " + t, BrowserActionRouter.isWrite(t));
        }
    }

    @Test public void scrollIsNotWrite() {
        // 修复1 根因：scroll 非写但此前无执行分支；现在 isWrite=false + isKnown=true → executeInternal
        assertFalse("scroll 非写", BrowserActionRouter.isWrite("scroll"));
        assertTrue("scroll 已知", BrowserActionRouter.isKnown("scroll"));
        assertFalse("wait_for 非写", BrowserActionRouter.isWrite("wait_for"));
        assertFalse("open 非写", BrowserActionRouter.isWrite("open"));
        assertFalse("click_and_read 非写", BrowserActionRouter.isWrite("click_and_read"));
    }
}
