package com.hermes.android.causal;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * PiiScrubber 单测（隐私审计 2026-08-05）——确定性脱敏：手机号/身份证/邮箱/银行卡/金额/URL 必须打码。
 * 零网络、零模型；每个用例同时断言「原文消失 + 占位符出现」（防假覆盖：断言真实替换发生）。
 */
public class PiiScrubberTest {

    @Test public void scrub_phone_masked() {
        String out = PiiScrubber.scrub("联系张三 13800138000 催款");
        assertFalse("手机号原文必须消失: " + out, out.contains("13800138000"));
        assertTrue("应含占位符: " + out, out.contains("[手机号]"));
    }

    @Test public void scrub_idCard18_masked() {
        String out = PiiScrubber.scrub("证件 11010119900307771X 已核验");
        assertFalse("身份证原文必须消失: " + out, out.contains("11010119900307771X"));
        assertTrue("应含占位符: " + out, out.contains("[证件号]"));
    }

    @Test public void scrub_idCard15_masked() {
        String out = PiiScrubber.scrub("老证件 110101900307771 登记");
        assertFalse("15位身份证原文必须消失: " + out, out.contains("110101900307771"));
        assertTrue("应含占位符: " + out, out.contains("[证件号]"));
    }

    @Test public void scrub_email_masked() {
        String out = PiiScrubber.scrub("发票寄到 zhangsan@example.com 谢谢");
        assertFalse("邮箱原文必须消失: " + out, out.contains("zhangsan@example.com"));
        assertTrue("应含占位符: " + out, out.contains("[邮箱]"));
    }

    @Test public void scrub_bankCard_masked() {
        String out = PiiScrubber.scrub("卡号 6222020200112233445 尾号检查");
        assertFalse("银行卡号原文必须消失: " + out, out.contains("6222020200112233445"));
        assertTrue("应含占位符: " + out, out.contains("[银行卡号]"));
    }

    @Test public void scrub_amount_masked() {
        String out = PiiScrubber.scrub("欠款 ¥5000 后又借 8000元 外加 3万元");
        assertFalse("金额原文必须消失: " + out,
                out.contains("¥5000") || out.contains("8000元") || out.contains("3万元"));
        assertTrue("应含占位符: " + out, out.contains("[金额]"));
    }

    @Test public void scrub_url_masked() {
        String out = PiiScrubber.scrub("详情见 https://bank.example.com/statement?id=12345 和 www.x.cn/pay");
        assertFalse("URL 原文必须消失: " + out,
                out.contains("bank.example.com") || out.contains("www.x.cn"));
        assertTrue("应含占位符: " + out, out.contains("[链接]"));
    }

    @Test public void scrub_mixedPii_allGone() {
        String in = "实体A 通过电话 13912345678 与实体B 约定转账 12000元，合同发 lisi@corp.net，"
                + "证件 310104197505124321，卡 6217003810026580";
        String out = PiiScrubber.scrub(in);
        assertFalse(out, out.contains("13912345678"));
        assertFalse(out, out.contains("12000元"));
        assertFalse(out, out.contains("lisi@corp.net"));
        assertFalse(out, out.contains("310104197505124321"));
        assertFalse(out, out.contains("6217003810026580"));
        assertTrue("实体抽象标签应保留: " + out, out.contains("实体A") && out.contains("实体B"));
    }

    @Test public void scrub_cleanText_unchanged() {
        // 无语义数字（强度/计数）不应误伤——脱敏叙事正文必须原样通过
        String clean = "（脱敏因果叙事）\n- 实体A 与 实体B 有往来关联（强度 60%）\n- 近期共 3 条因果事件";
        assertEquals("干净文本不应被改动", clean, PiiScrubber.scrub(clean));
    }

    @Test public void scrub_nullAndEmpty_safe() {
        assertEquals("", PiiScrubber.scrub(null));
        assertEquals("", PiiScrubber.scrub(""));
    }

    @Test public void containsPii_detectsAndPasses() {
        assertTrue(PiiScrubber.containsPii("电话 13800138000"));
        assertTrue(PiiScrubber.containsPii("金额 5000元"));
        assertFalse("脱敏后的文本不应再命中", PiiScrubber.containsPii(PiiScrubber.scrub("电话 13800138000 借 5000元")));
        assertFalse(PiiScrubber.containsPii("实体A 与 实体B 有往来关联"));
        assertFalse(PiiScrubber.containsPii(null));
    }
}
