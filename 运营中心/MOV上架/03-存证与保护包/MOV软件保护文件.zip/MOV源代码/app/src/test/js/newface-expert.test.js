/* ============================================================
   newface-expert 回归测试（node，专家模式第一幕）
   跑法: node app/src/test/js/newface-expert.test.js
   roomBadge/roomIcon/handoffText 从 newface.js 抽出的真代码，node 直接测。
   ============================================================ */
'use strict';
const assert = require('assert');
const ex = require('../../main/assets/js/newface-expert.js');

// ══ roomBadge: 运行态判定（诚实，不造假） ══
/* 工单13: 崩溃恢复状态如实——无活跃 loop 时执行中 phase 不再标「运行中」而标「已中断」 */
assert.deepStrictEqual(ex.roomBadge({phase:'执行中'}), {label:'已中断', cls:'idle'});
assert.deepStrictEqual(ex.roomBadge({phase:'讨论中'}), {label:'已中断', cls:'idle'});
assert.deepStrictEqual(ex.roomBadge({phase:'收敛中'}), {label:'已中断', cls:'idle'});
assert.deepStrictEqual(ex.roomBadge({phase:'待评审'}), {label:'已中断', cls:'idle'});
assert.deepStrictEqual(ex.roomBadge({phase:'待确认'}), {label:'已中断', cls:'idle'});
/* 进程内真有活跃 loop 且 roomId 匹配 → 运行中（agent_state 权威） */
global.B = { query: function(){ return JSON.stringify({ok:true, data:{active:true, roomId:'r1'}}); } };
assert.deepStrictEqual(ex.roomBadge({id:'r1', phase:'执行中'}), {label:'运行中', cls:'run'});
assert.deepStrictEqual(ex.roomBadge({id:'r1', phase:'讨论中'}), {label:'运行中', cls:'run'});
assert.deepStrictEqual(ex.roomBadge({id:'r1', phase:'待确认'}), {label:'运行中', cls:'run'});
/* 活跃 loop 但 roomId 不匹配 → 不是本房间在跑 → 已中断 */
assert.deepStrictEqual(ex.roomBadge({id:'r2', phase:'执行中'}), {label:'已中断', cls:'idle'});
/* 活跃 loop + 已交付 → 运行中（旧 _agentActive 兼容） */
assert.deepStrictEqual(ex.roomBadge({_agentActive:true, phase:'已交付'}), {label:'运行中', cls:'run'});
/* 无活跃 loop → 终态不标 */
global.B = { query: function(){ return JSON.stringify({ok:true, data:{active:false}}); } };
assert.strictEqual(ex.roomBadge({phase:'已交付'}), null);
assert.strictEqual(ex.roomBadge({phase:'已归档'}), null);
assert.strictEqual(ex.roomBadge({}), null);
assert.strictEqual(ex.roomBadge(null), null);
assert.strictEqual(ex.roomBadge(undefined), null);
/* B 查询异常 → 降级为已中断（不误报运行中） */
global.B = { query: function(){ throw new Error('boom'); } };
assert.deepStrictEqual(ex.roomBadge({phase:'执行中'}), {label:'已中断', cls:'idle'});
delete global.B;

// ══ roomIcon: 房名关键词 → emoji，缺省 📁 ══
assert.strictEqual(ex.roomIcon('三家超市比价'), '🛒');
assert.strictEqual(ex.roomIcon('周末采购房'), '🛒');
assert.strictEqual(ex.roomIcon('庆余年追剧房'), '🎬');
assert.strictEqual(ex.roomIcon('合同审查房'), '📄');
assert.strictEqual(ex.roomIcon('病历整理'), '📄');
assert.strictEqual(ex.roomIcon('做个贪吃蛇 App'), '📱');
assert.strictEqual(ex.roomIcon('设备控制'), '📱');
assert.strictEqual(ex.roomIcon('随便一个房'), '📁');
assert.strictEqual(ex.roomIcon(''), '📁');
assert.strictEqual(ex.roomIcon(null), '📁');

// ══ handoffText: 超长截断 + 省略号 ══
assert.strictEqual(ex.handoffText('帮我把病历整理成要点', 40), '帮我把病历整理成要点');
assert.strictEqual(ex.handoffText('短', 3), '短');
assert.strictEqual(ex.handoffText('12345', 3), '123…');
assert.strictEqual(ex.handoffText('', 40), '');
assert.strictEqual(ex.handoffText(null, 40), '');
assert.strictEqual(ex.handoffText(undefined, 40), '');
assert.strictEqual(ex.handoffText('abcdef', 4), 'abcd…');

// ══ agentPhaseLabel: 英文枚举 → 中文 ══
assert.strictEqual(ex.agentPhaseLabel('PLANNING'), '规划');
assert.strictEqual(ex.agentPhaseLabel('PLAN_GATE'), '等待确认');
assert.strictEqual(ex.agentPhaseLabel('EXECUTING'), '执行中');
assert.strictEqual(ex.agentPhaseLabel('PAUSED'), '已暂停');
assert.strictEqual(ex.agentPhaseLabel('RECOVERY'), '恢复中');
assert.strictEqual(ex.agentPhaseLabel('DONE'), '完成');
assert.strictEqual(ex.agentPhaseLabel('FAILED'), '失败');
assert.strictEqual(ex.agentPhaseLabel('STOPPED'), '已停止');
assert.strictEqual(ex.agentPhaseLabel('未知'), '未知');
assert.strictEqual(ex.agentPhaseLabel(''), '');

// ══ dayKey: epoch ms → 当日键 ══
assert.strictEqual(ex.dayKey(0), '1970-01-01');
assert.strictEqual(ex.dayKey(1753920000000), '2025-07-31');  // 精确 epoch → 2025-07-31 UTC? 用本地时区, 兼容
assert.strictEqual(ex.dayKey(null), '');
assert.strictEqual(ex.dayKey('abc'), '');

// ══ aggDaily: 按日聚合 deliver/fail，按 ts 降序 ══
const T0 = 1754000000000;  // 固定基准
const TODAY = ex.dayKey(T0);
const entries = [
  {roomId:'a', type:'deliver', ts: T0 + 2000, summary:'交付A'},
  {roomId:'b', type:'fail',    ts: T0 + 1000, summary:'失败B'},
  {roomId:'c', type:'deliver', ts: T0 + 3000, summary:'交付C'},
  {roomId:'d', type:'deliver', ts: T0 - 86400000 * 2, summary:'昨天交付'},  // 非当日
  {roomId:'e', type:'note',    ts: T0, summary:'思考'},                     // 非 deliver/fail
];
const r = ex.aggDaily(entries, TODAY);
assert.strictEqual(r.done.length, 2);
assert.strictEqual(r.failed.length, 1);
assert.strictEqual(r.done[0].summary, '交付C');   // ts 降序
assert.strictEqual(r.done[1].roomId, 'a');
assert.strictEqual(r.failed[0].roomId, 'b');
assert.strictEqual(r.done[0].roomId, 'c');

// ══ fileSize: 人类可读 ══
assert.strictEqual(ex.fileSize(500), '500B');
assert.strictEqual(ex.fileSize(2048), '2.0KB');
assert.strictEqual(ex.fileSize(3 * 1048576), '3.0MB');
assert.strictEqual(ex.fileSize(0), '0B');
assert.strictEqual(ex.fileSize('abc'), '0B');

// ══ tokFmt: TOKEN 人类可读 (与 runtime fmtTok 同构) ══
assert.strictEqual(ex.tokFmt(0), '0');
assert.strictEqual(ex.tokFmt(500), '500');
assert.strictEqual(ex.tokFmt(1234), '1.2K');
assert.strictEqual(ex.tokFmt(1500000), '1.50M');
assert.strictEqual(ex.tokFmt('2000'), '2.0K');
assert.strictEqual(ex.tokFmt('abc'), '0');

// ══ stepIsGoal: 计划步是否复述用户指令 (任务卡回显去重) ══
assert.strictEqual(ex.stepIsGoal('帮我把病历整理成要点', '帮我把病历整理成要点'), true);   // 相等
assert.strictEqual(ex.stepIsGoal('好的，帮我把病历整理成要点', '帮我把病历整理成要点'), true); // 带前缀复述 (步含 goal)
assert.strictEqual(ex.stepIsGoal('帮我把病历整理成要点，告诉我风险条款', '帮我把病历整理成要点'), true); // 步含 goal
assert.strictEqual(ex.stepIsGoal('整理病历要点', '帮我把病历整理成要点'), false);          // 缩写非复述 (字符级不足)
assert.strictEqual(ex.stepIsGoal('读取并解析 40 页合同内容', '帮我把病历整理成要点'), false); // 无关
assert.strictEqual(ex.stepIsGoal('', '帮我把病历整理成要点'), false);
assert.strictEqual(ex.stepIsGoal('帮我把病历整理成要点', ''), false);
assert.strictEqual(ex.stepIsGoal('整理要点', '帮我把病历整理成要点'), false);              // goal 太短? goal len≥4; 字符级
assert.strictEqual(ex.stepIsGoal('合同审查', '帮我把 40 页合同审查完'), true);              // 字符级高相似

// ══ thinkPanelMode: 思考面板展开态映射 (派单№6) ══
assert.strictEqual(ex.thinkPanelMode('idle'), 'collapsed');
assert.strictEqual(ex.thinkPanelMode('waiting'), 'collapsed');
assert.strictEqual(ex.thinkPanelMode(''), 'collapsed');
assert.strictEqual(ex.thinkPanelMode(null), 'collapsed');
assert.strictEqual(ex.thinkPanelMode(undefined), 'collapsed');
assert.strictEqual(ex.thinkPanelMode('THINKING'), 'expanded');
assert.strictEqual(ex.thinkPanelMode('PLANNING'), 'expanded');
assert.strictEqual(ex.thinkPanelMode('EXECUTING'), 'expanded');
assert.strictEqual(ex.thinkPanelMode('streaming'), 'expanded');

// ══ thinkLine/toolStatusText: 无感工作态一行文案 (派单№7) ══
assert.strictEqual(ex.thinkLine('running'), '思考中…');
assert.strictEqual(ex.thinkLine('RUNNING'), '思考中…');
assert.strictEqual(ex.thinkLine('done', '23.0'), '已思考 23 秒 ›');   // №8: 整数化
assert.strictEqual(ex.thinkLine('done', '250.0'), '已思考 250 秒 ›');
assert.strictEqual(ex.thinkLine('done', '250.6'), '已思考 251 秒 ›'); // 四舍五入
assert.strictEqual(ex.thinkLine('idle'), '');
assert.strictEqual(ex.thinkLine(''), '');
assert.strictEqual(ex.thinkLine(null), '');
assert.strictEqual(ex.toolStatusText(true), '完成');
assert.strictEqual(ex.toolStatusText(false), '失败');
assert.strictEqual(ex.toolStatusText(undefined), '调用中');
assert.strictEqual(ex.toolStatusText(null), '调用中');

// ══ extractConclusion: 答案提炼 (派单№8第六条) ══
assert.strictEqual(ex.extractConclusion('读取文件完成\n已运行命令\n【结论】今天是星期三'), '今天是星期三');
assert.strictEqual(ex.extractConclusion('已执行 date\n已读取文件\n最终结果：星期五'), '星期五');
assert.strictEqual(ex.extractConclusion('已创建文件\n已运行脚本\n星期三'), '星期三');   // 最后非过程句
assert.strictEqual(ex.extractConclusion('今天星期五'), '今天星期五');               // 单行原样
assert.strictEqual(ex.extractConclusion(''), '');
assert.strictEqual(ex.extractConclusion('已创建文件\n已运行脚本'), '已创建文件\n已运行脚本'); // 全程过程句 → 原文兜底
assert.strictEqual(ex.extractConclusion('总结：任务完成，牛奶已买'), '任务完成，牛奶已买');
assert.strictEqual(ex.extractConclusion('步骤1\n步骤2\n结论\n有结论标记'), '有结论标记');

console.log('✅ newface-expert 全部断言通过（专家一/二/三幕 + 派单№5/№6/№7/№8 纯逻辑）');
