package com.hermes.android.browser;

import com.hermes.android.agent.ToolRegistry;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * ToolRuntimeLimits 单测（DESIGN_BROWSER_PROTOCOL §3 双超时，W2 P2 侧）。
 * 零网络注入式：纯函数 expiredAt + 窗口生命周期 + checkWindow 窗尽回 task_timeout。
 */
public class ToolRuntimeLimitsTest {

    @Test public void windowTimeoutConstants() {
        assertEquals("窗口 5min", 5 * 60 * 1000L, ToolRuntimeLimits.WINDOW_TIMEOUT_MS);
        assertEquals("per-tool 30s", 30, ToolRuntimeLimits.PER_TOOL_HARD_TIMEOUT_S);
        assertEquals("错误码", "browser_task_timeout", ToolRuntimeLimits.ERROR_TASK_TIMEOUT);
    }

    @Test public void expiredAt_pureFunction() {
        long now = 1_000_000L;
        assertFalse("无窗口(deadline=0)永不过期", ToolRuntimeLimits.expiredAt(now, 0));
        assertFalse("未到截止不过期", ToolRuntimeLimits.expiredAt(now, now + 1000));
        assertTrue("超过截止过期", ToolRuntimeLimits.expiredAt(now, now - 1));
    }

    @Test public void windowLifecycle_openThenClose() {
        ToolRuntimeLimits.closeWindow();
        assertFalse("初始无窗口", ToolRuntimeLimits.windowOpen());
        ToolRuntimeLimits.openWindow();
        assertTrue("open 后开窗", ToolRuntimeLimits.windowOpen());
        assertFalse("刚开窗未过期", ToolRuntimeLimits.windowExpired());
        ToolRuntimeLimits.closeWindow();
        assertFalse("done 后关窗", ToolRuntimeLimits.windowOpen());
        assertFalse("关窗后不过期", ToolRuntimeLimits.windowExpired());
    }

    @Test public void checkWindow_returnsNullWhenNotExpired() {
        ToolRuntimeLimits.windowDeadlineMs = System.currentTimeMillis() + 60_000;
        assertNull("窗口内放行", ToolRuntimeLimits.checkWindow());
    }

    @Test public void checkWindow_returnsTaskTimeoutWhenExpired() {
        ToolRuntimeLimits.windowDeadlineMs = 1;   // 过去的截止 → 窗尽
        ToolRegistry.Result r = ToolRuntimeLimits.checkWindow();
        assertNotNull("窗尽回 task_timeout", r);
        assertFalse(r.ok);
        assertTrue("带 recovery 引导(browser.done)", r.text.contains("browser.done"));
        assertTrue("带 recovery 引导(browser.open)", r.text.contains("browser.open"));
    }

    @Test public void checkWindow_noWindow_notExpired() {
        ToolRuntimeLimits.windowDeadlineMs = 0;   // 无窗口
        assertNull("无窗口不拦(首个 browser.open 前)", ToolRuntimeLimits.checkWindow());
    }

    // ==================== P1: availabilityReason（browser_* checkFn 门控，纯 JVM） ====================

    @Test public void availabilityReason_freshWindow_returnsNull() {
        ToolRuntimeLimits.closeWindow();
        assertNull("无窗口 → 可用", ToolRuntimeLimits.availabilityReason());
        ToolRuntimeLimits.windowDeadlineMs = System.currentTimeMillis() + 60_000;
        assertNull("窗口内 → 可用", ToolRuntimeLimits.availabilityReason());
        ToolRuntimeLimits.closeWindow();
    }

    @Test public void availabilityReason_expiredWindow_returnsReason() {
        ToolRuntimeLimits.windowDeadlineMs = 1;   // 过去的截止 → 窗尽
        String reason = ToolRuntimeLimits.availabilityReason();
        assertNotNull("窗尽 → 不可用", reason);
        assertTrue("原因含 browser.open 引导", reason.contains("browser.open"));
        ToolRuntimeLimits.closeWindow();
    }

    @Test public void perToolClamp_usedByBrowserTools() {
        // runBrowser 用 min(timeoutSec, 30) — 验证常量能被钳制引用
        assertEquals("30s 硬超时", 30, ToolRuntimeLimits.PER_TOOL_HARD_TIMEOUT_S);
        assertTrue("15s 工具在 30s cap 内", 15 <= ToolRuntimeLimits.PER_TOOL_HARD_TIMEOUT_S);
    }
}
