package com.hermes.android.serve;

import static org.junit.Assert.*;

import org.junit.Test;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * 工单9 幕一 出网网关防回归：8388 出网网关（/v1/chat/completions）必须存在且出网前过 PiiScrubber 闸。
 * 扫描源码断言；变异（删 PII 闸 / 删端点）→ 必红。
 */
public class OpenaiGatewayConsistencyTest {

    private static File resolve() {
        String[][] candidates = {
                {"src/main/java/com/hermes/android/serve/MovInboundServer.java", null},
                {"app/src/main/java/com/hermes/android/serve/MovInboundServer.java", null},
        };
        for (String[] c : candidates) {
            File f = new File(c[0]);
            if (f.exists()) return f;
        }
        throw new AssertionError("MovInboundServer.java 未找到 (working dir=" + new File(".").getAbsolutePath() + ")");
    }

    private static String code() throws Exception {
        String src = new String(Files.readAllBytes(resolve().toPath()), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for (String line : src.split("\n")) {
            String t = line.trim();
            if (t.startsWith("//") || t.startsWith("*") || t.startsWith("/*") || t.isEmpty()) continue;
            sb.append(line).append('\n');
        }
        return sb.toString();
    }

    @Test
    public void gatewayEndpointExists() throws Exception {
        String c = code();
        assertTrue("8388 必须有 /v1/chat/completions 端点（出网网关）", c.contains("/v1/chat/completions"));
    }

    @Test
    public void gatewayScrubsPiiBeforeEgress() throws Exception {
        String c = code();
        assertTrue("出网网关必须出网前过 PiiScrubber.scrub（PII 闸点）",
                c.contains("PiiScrubber.scrub"));
    }
}
