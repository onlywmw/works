package com.hermes.android.browser;
import com.hermes.android.ConnectWebActivity;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import com.hermes.android.agent.ToolRegistry;

/**
 * W2: browser_* 分级收编 — ConnectWeb 浏览器动作进统一注册表（DESIGN_PAYMENT_GATE §三）。
 *
 * 分级：读（wait_for/scroll）= FAST READONLY 直放；写（click/type/submit/click_and_read）=
 * FAST ACTION 过审批闸（ConnectWeb 内部已做支付域检测 + Keyguard）；execute(eval_js)=
 * DANGEROUS 生物识别（支付域直接 blocked）。
 *
 * 执行桥接：AgentLoop 同步 handler ↔ executeBrowserAction 异步 cbId 回调——经
 * ConnectWebActivity.setJavaCallback + CountDownLatch 同步化，带超时。
 * checkFn：ConnectWeb 打开才可用（无浏览器 → 不放行）。
 *
 * 仅收编 executeBrowserAction 已实现的动作（不新增未实现 type，防假覆盖）。
 */
public class BrowserToolProvider implements ToolRegistry.ToolProvider {

    /** P1: browser_* 可用性——窗口超时才是硬不可用（未开浏览器由运行期自动拉起/引导兜底，checkFn 不再依赖 ConnectWeb） */
    private static String browserCheck() {
        return ToolRuntimeLimits.availabilityReason();
    }

    @Override public String id() { return "browser"; }

    // ==================== P1: 可测试接缝 + 自动拉起（W2） ====================

    /** runBrowser 仅依赖的最小执行面（ConnectWebActivity 天然实现） */
    public interface BrowserExecutor {
        void setJavaCallback(String cbId, java.util.function.Consumer<String> cb);
        void clearJavaCallback(String cbId);
        void executeBrowserAction(String actionJson, String cbId);
    }

    /** 取当前浏览器 / 拉起 —— 测试注入 fake，真机走 ConnectWebActivity 静态 */
    interface ConnectWebSource {
        BrowserExecutor current();
        boolean launch(String url, String platform, String keyword);
    }

    private static final ConnectWebSource DEFAULT_SOURCE = new ConnectWebSource() {
        @Override public BrowserExecutor current() { return ConnectWebActivity.getCurrent(); }
        @Override public boolean launch(String url, String platform, String keyword) {
            return launchConnectWeb(url, platform, keyword);
        }
    };

    private static volatile ConnectWebSource connectWebSource = DEFAULT_SOURCE;

    /** 测试钩子：同包测试注入 fake；传 null 恢复默认 */
    static void resetConnectWebSource() { connectWebSource = DEFAULT_SOURCE; }
    static void setConnectWebSource(ConnectWebSource s) { connectWebSource = s; }

    /** 自动拉起：app context + NEW_TASK，url 或 platform+keyword 由 onCreate 构造页面 */
    private static boolean launchConnectWeb(String url, String platform, String keyword) {
        final android.content.Context ctx = com.hermes.android.HermesApplication.getAppContext();
        if (ctx == null) return false;
        final android.content.Intent i = new android.content.Intent(ctx, ConnectWebActivity.class);
        i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
        if (url != null && !url.isEmpty()) i.putExtra("url", url);
        if (platform != null && !platform.isEmpty()) i.putExtra("platform", platform);
        if (keyword != null && !keyword.isEmpty()) i.putExtra("keyword", keyword);
        try {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> ctx.startActivity(i));
            return true;
        } catch (Exception e) {
            android.util.Log.w("BrowserToolProvider", "拉起 ConnectWeb 失败: " + e.getMessage());
            return false;
        }
    }

    /** 轮询等 currentInstance 出现（onCreate 先建 web 后置 currentInstance → 非空即就绪） */
    private static BrowserExecutor awaitExecutorReady(int timeoutSec) {
        long deadline = System.currentTimeMillis() + timeoutSec * 1000L;
        while (System.currentTimeMillis() < deadline) {
            BrowserExecutor ex = connectWebSource.current();
            if (ex != null) return ex;
            try { Thread.sleep(150); } catch (InterruptedException e) { return null; }
        }
        return null;
    }

    /** 桥接执行：取当前浏览器（未开自动拉起）→ executeBrowserAction，CountDownLatch 等回调（带超时） */
    private ToolRegistry.Result runBrowser(String type, JSONObject args, int timeoutSec) {
        BrowserExecutor ex = connectWebSource.current();
        if (ex == null) {
            if (!"open".equals(type)) {
                return new ToolRegistry.Result(false, "浏览器未打开，请先调用 browser.open（会自动拉起内置浏览器）");
            }
            String url = args.optString("url", "");
            String platform = args.optString("platform", "");
            String keyword = args.optString("keyword", "");
            if (url.isEmpty() && (platform.isEmpty() || keyword.isEmpty())) {
                return new ToolRegistry.Result(false, "browser.open 需要 url，或 platform+keyword（如 platform=douyin keyword=庆余年 评价）");
            }
            if (!connectWebSource.launch(url, platform, keyword)) {
                return new ToolRegistry.Result(false, "拉起 ConnectWeb 失败");
            }
            ex = awaitExecutorReady(timeoutSec);
            if (ex == null) return new ToolRegistry.Result(false, "ConnectWeb 拉起超时(" + timeoutSec + "s)");
        }
        // ToolRuntimeLimits: browser.open 开窗（5min 单任务窗口起点）
        if ("open".equals(type)) ToolRuntimeLimits.openWindow();
        // ToolRuntimeLimits: 窗尽回 task_timeout（runaway loop 成本封顶，不许无限循环）
        ToolRegistry.Result windowCheck = ToolRuntimeLimits.checkWindow();
        if (windowCheck != null) return windowCheck;
        // ToolRuntimeLimits: per-tool 硬超时 30s 钳制（DESIGN §3）
        int effectiveTimeout = Math.min(timeoutSec, ToolRuntimeLimits.PER_TOOL_HARD_TIMEOUT_S);
        JSONObject action = new JSONObject();
        try {
            action.put("type", type);
            java.util.Iterator<String> keys = args.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                action.put(k, args.get(k));
            }
        } catch (Exception e) {
            return new ToolRegistry.Result(false, "参数解析失败: " + e.getMessage());
        }
        String cbId = "agent_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 100000);
        CountDownLatch latch = new CountDownLatch(1);
        final String[] res = {null};
        ex.setJavaCallback(cbId, r -> { res[0] = r; latch.countDown(); });
        try {
            // P1: 不再包一层主线程 post —— ConnectWebActivity.executeBrowserAction 内部已按分支自 post
            //   （JavaBridge 线程调用设计），删 post 才解锁 JVM 可测。
            ex.executeBrowserAction(action.toString(), cbId);
            boolean done = latch.await(effectiveTimeout, TimeUnit.SECONDS);
            ex.clearJavaCallback(cbId);
            if (!done) return new ToolRegistry.Result(false, "浏览器操作超时(" + effectiveTimeout + "s)");
            String out = res[0] == null ? "done" : res[0];
            return new ToolRegistry.Result(true, out, out);
        } catch (Exception e) {
            ex.clearJavaCallback(cbId);
            return new ToolRegistry.Result(false, "浏览器操作失败: " + e.getMessage());
        }
    }

    @Override public List<ToolRegistry.Tool> discover() {
        List<ToolRegistry.Tool> list = new ArrayList<>();

        // ── 导航（ACTION：改变页面）──

        // browser.open: 导航到 URL 或按平台搜索（platform+keyword 自动构造搜索 URL，LLM 免构造 URL）
        list.add(new ToolRegistry.Tool("browser.open", "打开网页或按平台搜索（platform+keyword 自动构造搜索 URL）", null,
            a -> runBrowser("open", a, 15), "native", "write", "plan", true, 15, "browser",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("url", "string", false, "https://...", "目标 URL（与 platform+keyword 二选一）"),
                new ToolRegistry.ParamDef("platform", "string", false, "douyin/jd/tencent/12306", "平台（配合 keyword 用）"),
                new ToolRegistry.ParamDef("keyword", "string", false, "庆余年 评价", "搜索关键词（配合 platform 用）"),
            },
            "JSON: {\"opened\":true,\"url\":\"...\"}",
            new String[]{"在抖音搜庆余年"}, null, 15000,
            new ToolRegistry.Manifest("打开网页/平台搜索", "medium", "打开 URL 或按 platform+keyword 平台内搜索", false, "io", "FAST", true, 15000),
            BrowserToolProvider::browserCheck));

        // ── 读（READONLY 直放）──

        // browser.wait_for: 等待元素出现/消失（Java 轮询）
        list.add(new ToolRegistry.Tool("browser.wait_for", "等待页面元素出现/消失", null,
            a -> runBrowser("wait_for", a, 12), "native", "readonly", "none", true, 12, "browser",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("selector", "string", true, "CSS 选择器", "等待的目标元素"),
                new ToolRegistry.ParamDef("state", "string", false, "visible/hidden/attached/detached", "等待状态"),
                new ToolRegistry.ParamDef("containsText", "string", false, "文本", "元素内需含的文本"),
            },
            "JSON 回调结果",
            new String[]{"等待搜索结果出现"}, null, 12000,
            new ToolRegistry.Manifest("等待元素", "low", "等待页面元素出现/消失", false, "io", "FAST", true, 12000),
            BrowserToolProvider::browserCheck));

        // browser.scroll: 滚动页面（执行层豁免审批，无数据副作用）
        list.add(new ToolRegistry.Tool("browser.scroll", "滚动浏览器页面", null,
            a -> runBrowser("scroll", a, 8), "native", "readonly", "none", true, 8, "browser",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("amount", "int", false, "默认 600", "滚动像素（正下负上）"),
            },
            "JSON: {\"scroll_y\":N}",
            new String[]{"向下滚动"}, null, 8000,
            new ToolRegistry.Manifest("滚动页面", "low", "滚动浏览器页面", false, "io", "FAST", true, 8000),
            BrowserToolProvider::browserCheck));

        // ── 写（ACTION 过审批闸）──

        // browser.click
        list.add(new ToolRegistry.Tool("browser.click", "点击页面元素", null,
            a -> runBrowser("click", a, 10), "native", "write", "plan", true, 10, "browser",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("eid", "string", false, "MovConnect 元素ID", "优先用 eid"),
                new ToolRegistry.ParamDef("selector", "string", false, "CSS 选择器", "eid 缺失时用"),
            },
            "JSON diff 结果",
            new String[]{"点击搜索按钮"}, null, 10000,
            new ToolRegistry.Manifest("点击元素", "medium", "点击浏览器页面元素", false, "io", "FAST", true, 10000),
            BrowserToolProvider::browserCheck));

        // browser.type
        list.add(new ToolRegistry.Tool("browser.type", "向输入框键入文本", null,
            a -> runBrowser("type", a, 10), "native", "write", "plan", true, 10, "browser",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("eid", "string", false, "MovConnect 元素ID", "优先用 eid"),
                new ToolRegistry.ParamDef("selector", "string", false, "CSS 选择器", "eid 缺失时用"),
                new ToolRegistry.ParamDef("text", "string", true, "要键入的文本", "支持 React 受控组件"),
                new ToolRegistry.ParamDef("clear", "boolean", false, "true/false", "是否先清空"),
            },
            "JSON diff 结果",
            new String[]{"在搜索框输入关键词"}, null, 10000,
            new ToolRegistry.Manifest("键入文本", "medium", "向浏览器输入框键入文本", false, "io", "FAST", true, 10000),
            BrowserToolProvider::browserCheck));

        // browser.submit
        list.add(new ToolRegistry.Tool("browser.submit", "提交表单", null,
            a -> runBrowser("submit", a, 10), "native", "write", "plan", true, 10, "browser",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("eid", "string", false, "MovConnect 元素ID", "优先用 eid"),
                new ToolRegistry.ParamDef("selector", "string", false, "CSS 选择器", "eid 缺失时用"),
            },
            "JSON diff 结果",
            new String[]{"提交搜索表单"}, null, 10000,
            new ToolRegistry.Manifest("提交表单", "medium", "提交浏览器页面表单", false, "io", "FAST", true, 10000),
            BrowserToolProvider::browserCheck));

        // browser.click_and_read: 点击+等+读 复合（含写）
        list.add(new ToolRegistry.Tool("browser.click_and_read", "点击并读取页面变化", null,
            a -> runBrowser("click_and_read", a, 15), "native", "write", "plan", true, 15, "browser",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("eid", "string", false, "MovConnect 元素ID", "优先用 eid"),
                new ToolRegistry.ParamDef("selector", "string", false, "CSS 选择器", "eid 缺失时用"),
            },
            "JSON diff（前后文本对比）",
            new String[]{"点击并读取结果"}, null, 15000,
            new ToolRegistry.Manifest("点击读取", "medium", "点击元素并读取页面变化", false, "io", "FAST", true, 15000),
            BrowserToolProvider::browserCheck));

        // W2: browser.snapshot — 页面元素快照 (readonly, 打通 open→snapshot→定位 链路)
        list.add(new ToolRegistry.Tool("browser.snapshot", "获取页面元素快照", null,
            a -> runBrowser("snapshot", a, 8), "native", "readonly", "none", true, 8, "browser",
            new ToolRegistry.ParamDef[]{},
            "JSON 元素编号列表（eid，供点击/输入定位）",
            new String[]{"获取当前页面元素"}, null, 8000,
            new ToolRegistry.Manifest("页面快照", "low", "获取浏览器页面元素编号快照", false, "io", "FAST", true, 8000),
            BrowserToolProvider::browserCheck));

        // W2: browser.read — 读页面正文 (readonly, 独立 read 链路)
        list.add(new ToolRegistry.Tool("browser.read", "读取页面正文", null,
            a -> runBrowser("get_text", a, 8), "native", "readonly", "none", true, 8, "browser",
            new ToolRegistry.ParamDef[]{},
            "页面正文文本（最多 4000 字）",
            new String[]{"读取当前页面正文"}, null, 8000,
            new ToolRegistry.Manifest("读正文", "low", "读取浏览器页面正文", false, "io", "FAST", true, 8000),
            BrowserToolProvider::browserCheck));

        // ── 支付域高危（DANGEROUS 生物识别）──

        // browser.execute: eval_js（支付域直接 blocked，非支付域走 Keyguard）
        list.add(new ToolRegistry.Tool("browser.execute", "在页面执行 JS（高危）", null,
            a -> runBrowser("execute", a, 8), "native", "write", "always", true, 8, "browser",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("js", "string", true, "要执行的 JS", "eval_js；支付域直接拒绝"),
            },
            "执行结果",
            new String[]{"执行一段 JS"}, null, 8000,
            new ToolRegistry.Manifest("执行 JS", "high", "在浏览器页面执行任意 JS", false, "exec", "FAST", true, 8000),
            BrowserToolProvider::browserCheck));

        // ── 会话收尾（ToolRuntimeLimits: 关窗结束 5min 单任务窗口）──

        list.add(new ToolRegistry.Tool("browser.done", "关闭浏览器任务窗口，结束本次浏览会话（总结任务结果）", null,
            a -> {
                ToolRuntimeLimits.closeWindow();
                return new ToolRegistry.Result(true, "浏览器任务窗口已关闭，本次浏览会话结束");
            },
            "native", "write", "plan", true, 5, "browser",
            new ToolRegistry.ParamDef[]{},
            "窗口已关闭",
            new String[]{"总结并结束"}, null, 5000,
            new ToolRegistry.Manifest("结束浏览", "low", "关闭浏览器任务窗口并总结", false, "io", "FAST", true, 5000),
            BrowserToolProvider::browserCheck));

        return list;
    }
}
