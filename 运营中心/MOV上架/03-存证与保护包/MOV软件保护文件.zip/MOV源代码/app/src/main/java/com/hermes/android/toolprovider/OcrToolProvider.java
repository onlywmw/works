package com.hermes.android.toolprovider;

import android.app.ActivityManager;
import android.content.Context;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.hermes.android.agent.ToolRegistry;

/**
 * OCR 工具骨架（P1 集成面，DESIGN_OCR_MOBILE v2 §七）——模型本体/llama-server 归 P4。
 * checkFn：模型存在（filesDir/models/unlimited-ocr/）+ 可用内存 ≥4GB（不足诚实卡，不许 OOM）。
 * 工具本体接 llama-server 未就绪态：诚实卡「模型未下载/未启动」，不假识别一个字。
 */
public class OcrToolProvider implements ToolRegistry.ToolProvider {

    private static Context appContext;
    private static final long MIN_FREE_MEM = 4L * 1024 * 1024 * 1024;   // 4GB 硬顶
    private static final String MODEL_DIR = "models/unlimited-ocr";

    public static void init(Context ctx) {
        appContext = ctx.getApplicationContext();
    }

    /** 纯 JVM 可测：目录是否有模型文件 */
    static boolean hasModelFile(File modelsDir) {
        if (modelsDir == null || !modelsDir.isDirectory()) return false;
        File[] files = modelsDir.listFiles();
        return files != null && files.length > 0;
    }

    /** checkFn：模型存在 + 内存 ≥4GB；null=可用，字符串=不可用原因（诚实卡） */
    private static String check() {
        if (appContext == null) return "context 未初始化";
        File dir = new File(appContext.getFilesDir(), MODEL_DIR);
        if (!hasModelFile(dir)) return "模型未下载（设置页可下载，约 2GB）";
        ActivityManager am = (ActivityManager) appContext.getSystemService(Context.ACTIVITY_SERVICE);
        if (am != null) {
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            if (mi.availMem < MIN_FREE_MEM) {
                return "可用内存不足 4GB，先关掉视频等大应用（防止 OOM）";
            }
        }
        return null;
    }

    @Override public String id() { return "ocr"; }

    @Override public List<ToolRegistry.Tool> discover() {
        List<ToolRegistry.Tool> list = new ArrayList<>();
        list.add(new ToolRegistry.Tool("ocr", "识别图片/文档文字（本地 llama-server 视觉）", null,
            a -> {
                String c = check();
                if (c != null) return new ToolRegistry.Result(false, c);   // 诚实卡: 模型/内存不满足不识别
                String image = a.optString("image", "");
                if (image.isEmpty()) return new ToolRegistry.Result(false, "image 路径不能为空");
                try {
                    // 工单12 幕四: 懒启动 llama-server → 视觉识别 → 真文本(守不假识别红线: 失败/无结果诚实返回)
                    if (!com.hermes.android.llama.LlamaServerManager.ensureRunning(appContext)) {
                        return new ToolRegistry.Result(false, "OCR 服务启动失败（模型/llama-server 未就位）");
                    }
                    java.io.File f = new java.io.File(image);
                    if (!f.isFile()) return new ToolRegistry.Result(false, "图片不存在: " + image);
                    byte[] bytes = java.nio.file.Files.readAllBytes(f.toPath());
                    String b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP);
                    String payload = com.hermes.android.llama.LlamaClient.buildVisionPayload(
                            null, "识别图片中的文字, 原样输出", b64, 512);
                    String token = com.hermes.android.llama.LlamaServerManager.token(appContext);
                    okhttp3.OkHttpClient client = new okhttp3.OkHttpClient.Builder()
                            .readTimeout(300, java.util.concurrent.TimeUnit.SECONDS)
                            .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                            .build();
                    okhttp3.Request req = new okhttp3.Request.Builder()
                            .url(com.hermes.android.llama.LlamaClient.BASE_URL + "/v1/chat/completions")
                            .header("Authorization", "Bearer " + token)
                            .post(okhttp3.RequestBody.create(
                                    okhttp3.MediaType.get("application/json; charset=utf-8"), payload))
                            .build();
                    okhttp3.Response resp = client.newCall(req).execute();
                    String rbody = resp.body() != null ? resp.body().string() : "";
                    String text = com.hermes.android.llama.LlamaClient.parseResponse(rbody);
                    if (text == null || text.trim().isEmpty()) {
                        return new ToolRegistry.Result(false,
                                "OCR 识别无结果（服务异常或图片无文字）: " + rbody);
                    }
                    return new ToolRegistry.Result(true, "OCR 识别结果", text.trim());
                } catch (Exception e) {
                    return new ToolRegistry.Result(false, "OCR 识别失败: " + e.getMessage());
                }
            },
            "native", "readonly", "none", true, 30, "ocr",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("image", "string", true, "图片路径/URL", "要识别的图片"),
            },
            "识别文字结果",
            new String[]{"识别这张图"}, null, 30000,
            new ToolRegistry.Manifest("文字识别", "low", "识别图片/文档中的文字", false, "io", "FAST", false, 30000),
            OcrToolProvider::check));
        return list;
    }
}
