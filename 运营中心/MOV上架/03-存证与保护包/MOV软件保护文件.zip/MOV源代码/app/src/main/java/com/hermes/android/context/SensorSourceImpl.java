package com.hermes.android.context;

import android.Manifest;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.PowerManager;
import android.util.Log;

import androidx.core.content.ContextCompat;

/**
 * {@link SensorSource} 的生产实现 — 读取真实 Android 传感器。
 *
 * <p>每个 getter 都是随调随读，不做缓存。调用方（{@link ContextProvider}）
 * 负责决定何时采样和缓存。
 */
public class SensorSourceImpl implements SensorSource {

    private final Context appCtx;

    public SensorSourceImpl(Context context) {
        this.appCtx = context.getApplicationContext();
    }

    @Override
    public String getWifiSsid() {
        try {
            WifiManager wm = (WifiManager) appCtx.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return null;
            String ssid = wm.getConnectionInfo().getSSID();
            if (ssid == null || ssid.isEmpty() || "<unknown ssid>".equals(ssid)) return null;
            // strip 引号（WifiInfo 返回 "\"MyWiFi\"" 格式）
            if (ssid.startsWith("\"") && ssid.endsWith("\"") && ssid.length() >= 2) {
                ssid = ssid.substring(1, ssid.length() - 1);
            }
            return ssid;
        } catch (SecurityException e) {
            Log.w(TAG, "getWifiSsid: permission denied", e);
            return null;
        } catch (Exception e) {
            Log.w(TAG, "getWifiSsid: lookup failed", e);
            return null;
        }
    }

    @Override
    public Integer getBatteryLevel() {
        Intent intent = appCtx.registerReceiver(null,
                new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (intent == null) return null;
        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        if (level < 0 || scale <= 0) return null;
        return Math.min(100, level * 100 / scale);
    }

    @Override
    public boolean isCharging() {
        Intent intent = appCtx.registerReceiver(null,
                new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (intent == null) return false;
        int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS,
                BatteryManager.BATTERY_STATUS_UNKNOWN);
        int plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        // status=CHARGING/FULL 或 plugged≠0（dumpsys battery set 改 AC powered 时 status 可能滞后）
        return status == BatteryManager.BATTERY_STATUS_CHARGING
                || status == BatteryManager.BATTERY_STATUS_FULL
                || plugged != 0;
    }

    @Override
    public boolean isScreenOn() {
        PowerManager pm = (PowerManager) appCtx.getSystemService(Context.POWER_SERVICE);
        if (pm == null) return true; // 兜底：未知时假设亮屏
        return pm.isInteractive();
    }

    @Override
    public String getForegroundApp() {
        // UsageStats — 需要 PACKAGE_USAGE_STATS 权限（用户在 Settings 里手动开）。
        // 不做无障碍，不前置申请。无权限返回 null，调用方处理。
        try {
            if (ContextCompat.checkSelfPermission(appCtx,
                    Manifest.permission.PACKAGE_USAGE_STATS)
                    != PackageManager.PERMISSION_GRANTED) {
                return null;
            }
            UsageStatsManager usm = (UsageStatsManager) appCtx
                    .getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm == null) return null;
            long now = System.currentTimeMillis();
            long fiveSecAgo = now - 5000;
            // queryUsageStats 按 lastTimeUsed 降序返回
            // 取最近 5 秒内最活跃的包名
            java.util.List<android.app.usage.UsageStats> stats =
                    usm.queryUsageStats(
                            UsageStatsManager.INTERVAL_DAILY,
                            fiveSecAgo, now);
            if (stats == null || stats.isEmpty()) return null;
            // 找到最近使用的
            android.app.usage.UsageStats top = null;
            for (android.app.usage.UsageStats s : stats) {
                if (top == null || s.getLastTimeUsed() > top.getLastTimeUsed()) {
                    top = s;
                }
            }
            return top != null ? top.getPackageName() : null;
        } catch (SecurityException e) {
            return null;
        } catch (Exception e) {
            Log.w(TAG, "getForegroundApp: lookup failed", e);
            return null;
        }
    }

    private static final String TAG = "ContextSensor";
}
