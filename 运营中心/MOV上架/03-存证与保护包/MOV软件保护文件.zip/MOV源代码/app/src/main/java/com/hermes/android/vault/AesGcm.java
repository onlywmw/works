package com.hermes.android.vault;

import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * AES-256-GCM 加密核心（纯 JVM 可测，生产 KeystoreCrypto 与测试共用同一个核心）。
 *
 * 输出格式: [12B 随机 IV][GCM 密文 + 128bit tag]。
 * 每次加密随机 IV → 同一明文两次密文不同；tag 校验防篡改（decrypt 失败抛 AEADBadTagException）。
 * 这里就是「真加密」所在——测试的白盒如果把这层改成返回明文，密文 grep 断言必红
 * （KeystoreFallback 三形态①：mock 假装加密的防守对象）。
 */
public final class AesGcm {

    private static final String TRANSFORM = "AES/GCM/NoPadding";
    private static final int IV_LEN = 12;
    private static final int TAG_BITS = 128;
    private static final SecureRandom RNG = new SecureRandom();

    private AesGcm() {}

    /** 加密: [IV][ciphertext+tag] */
    public static byte[] encrypt(SecretKey key, byte[] plaintext) throws Exception {
        byte[] iv = new byte[IV_LEN];
        RNG.nextBytes(iv);
        Cipher c = Cipher.getInstance(TRANSFORM);
        c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(TAG_BITS, iv));
        byte[] ct = c.doFinal(plaintext);
        byte[] out = new byte[iv.length + ct.length];
        System.arraycopy(iv, 0, out, 0, iv.length);
        System.arraycopy(ct, 0, out, iv.length, ct.length);
        return out;
    }

    /** 解密: 解析 [IV][ciphertext+tag]，GCM tag 校验失败抛 AEADBadTagException（防篡改） */
    public static byte[] decrypt(SecretKey key, byte[] data) throws Exception {
        if (data == null || data.length < IV_LEN + 16) {
            throw new IllegalArgumentException("密文损坏: 长度不足");
        }
        byte[] iv = Arrays.copyOfRange(data, 0, IV_LEN);
        byte[] ct = Arrays.copyOfRange(data, IV_LEN, data.length);
        Cipher c = Cipher.getInstance(TRANSFORM);
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(TAG_BITS, iv));
        return c.doFinal(ct);
    }
}
