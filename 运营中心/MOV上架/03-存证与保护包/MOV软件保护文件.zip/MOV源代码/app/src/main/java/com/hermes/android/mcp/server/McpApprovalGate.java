package com.hermes.android.mcp.server;

import com.hermes.android.agent.Journal;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MCP write 工具审批闸（工单 P5：MCP P2 扩展）— 复用 AgentLoop 既有闸语义
 * （approval 级别 + 路径白名单 allowedPaths），MCP 侧独立状态机。
 *
 * 语义（write 工具调用必须过审批）：
 *  - 未批准 → {@link Decision#PENDING}：发起房间内审批请求（写 journal 事件），
 *    明确 error code = {@link #CODE_PENDING}（APPROVAL_PENDING）；
 *  - 已批准 → {@link Decision#ALLOWED}：路径进 {@link #getPathAllowSet()}，注入
 *    ToolRegistry.build 的 allowedPaths，file.write 既有白名单闸自然放行；
 *  - 驳回 → {@link Decision#DENIED}：明确 error code = {@link #CODE_DENIED}。
 *
 * 房间内确认闭环：UI/Bridge 读到 journal 的 _mcp_approval_request 事件 → 调
 * {@link #respond(requestId, approved, note)} → 批准/驳回落账 + 白名单更新。
 *
 * 纯 JVM，零 android 依赖，零网络，零模型调用。
 */
public class McpApprovalGate {

    public static final String CODE_PENDING = "APPROVAL_PENDING";
    public static final String CODE_DENIED = "APPROVAL_DENIED";
    public static final String TYPE_REQUEST = "_mcp_approval_request";
    public static final String TYPE_RESULT = "_mcp_approval_result";

    /** 审批判定：放行 / 待审批（已发起请求）/ 驳回。 */
    public enum Decision { ALLOWED, PENDING, DENIED }

    /** 待审批请求快照（房间展示 / 测试断言用）。 */
    public static class PendingRequest {
        public final String requestId;
        public final String tool;
        public final String path;      // 批准粒度（file.write=路径；无 path 工具="*"）
        public final String roomId;
        public final long ts;
        public final JSONObject args;

        PendingRequest(String requestId, String tool, String path, String roomId, long ts, JSONObject args) {
            this.requestId = requestId;
            this.tool = tool;
            this.path = path;
            this.roomId = roomId;
            this.ts = ts;
            this.args = args;
        }
    }

    private final Journal journal;     // 可 null（测试可不落 journal，仅内存状态）
    private final String roomId;       // 审批事件落哪个房间
    private final Set<String> pathAllowSet = ConcurrentHashMap.newKeySet();       // 注入 build 的 allowedPaths
    private final Map<String, Set<String>> approvedPaths = new ConcurrentHashMap<>();  // tool → 已批路径
    private final Map<String, Set<String>> rejectedPaths = new ConcurrentHashMap<>();  // tool → 驳回路径
    private final Map<String, PendingRequest> pending = new ConcurrentHashMap<>();
    private final AtomicInteger seq = new AtomicInteger();

    public McpApprovalGate(Journal journal, String roomId) {
        this.journal = journal;
        this.roomId = roomId;
    }

    /** 共享路径白名单：注入 ToolRegistry.build 的 allowedPaths supplier，file.write 既有闸读取。 */
    public Set<String> getPathAllowSet() { return pathAllowSet; }

    /** 判定：已批路径 → ALLOWED；被驳路径 → DENIED；否则 → PENDING。 */
    public Decision check(String tool, String path) {
        String key = normalize(path);
        Set<String> ap = approvedPaths.get(tool);
        if (ap != null && ap.contains(key)) return Decision.ALLOWED;
        Set<String> rj = rejectedPaths.get(tool);
        if (rj != null && rj.contains(key)) return Decision.DENIED;
        return Decision.PENDING;
    }

    /** 发起审批：登记 pending + 写房间 journal 事件（journal 非空时）。返回 requestId。
     *  技术债修复（工单5）：seq 是实例字段非持久化，重启后从 1 重计，journal 里可能撞号。
     *  前缀 UUID 短段（8 hex）保证跨实例/跨重启全局唯一，seq 保留作同实例顺序可读性。 */
    public String requestApproval(String tool, String path, JSONObject args) {
        String key = normalize(path);
        String requestId = "mcp_ap_" + java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 8)
                + "_" + seq.incrementAndGet();
        pending.put(requestId, new PendingRequest(requestId, tool, key, roomId,
                System.currentTimeMillis(), args != null ? args : new JSONObject()));
        if (journal != null) {
            try {
                JSONObject ev = new JSONObject()
                        .put("type", TYPE_REQUEST)
                        .put("actor", "mcp")
                        .put("payload", new JSONObject()
                                .put("requestId", requestId)
                                .put("tool", tool)
                                .put("path", key)
                                .put("args", args != null ? args : new JSONObject()));
                journal.append(roomId, ev);
            } catch (Exception ignored) {}
        }
        return requestId;
    }

    /** 房间确认闭环：批准 → 路径进白名单 + 落账；驳回 → 记拒绝 + 落账。返回是否命中请求。 */
    public boolean respond(String requestId, boolean approved, String note) {
        PendingRequest pr = pending.remove(requestId);
        if (pr == null) return false;
        if (approved) {
            approvedPaths.computeIfAbsent(pr.tool, k -> new HashSet<>()).add(pr.path);
            pathAllowSet.add(pr.path);
        } else {
            rejectedPaths.computeIfAbsent(pr.tool, k -> new HashSet<>()).add(pr.path);
        }
        if (journal != null) {
            try {
                journal.append(roomId, new JSONObject()
                        .put("type", TYPE_RESULT)
                        .put("actor", "mcp")
                        .put("payload", new JSONObject()
                                .put("requestId", requestId)
                                .put("tool", pr.tool)
                                .put("path", pr.path)
                                .put("approved", approved)
                                .put("note", note != null ? note : "")));
            } catch (Exception ignored) {}
        }
        return true;
    }

    public List<PendingRequest> pendingRequests() { return new ArrayList<>(pending.values()); }

    /** 该 (tool,path) 是否已有在途请求（避免重复发起）。 */
    public boolean hasPending(String tool, String path) {
        String key = normalize(path);
        for (PendingRequest pr : pending.values()) {
            if (pr.tool.equals(tool) && pr.path.equals(key)) return true;
        }
        return false;
    }

    /** 空/未给路径 → "*"（工具级）；否则原样（路径级）。 */
    private static String normalize(String path) {
        return path == null || path.isEmpty() ? "*" : path;
    }
}
