package com.hermes.android;

/**
 * 抖音 Web 容器（向后兼容，委托 ConnectWebActivity）。
 * @deprecated 新调用请直接用 ConnectWebActivity + platform=douyin。
 */
public class DouyinWebActivity extends ConnectWebActivity {
    // Intent extras "url"/"mode"/"keyword" 透传到 ConnectWebActivity.onCreate()
    // platform 默认为 "douyin"，由 ConnectWebActivity 处理
}
