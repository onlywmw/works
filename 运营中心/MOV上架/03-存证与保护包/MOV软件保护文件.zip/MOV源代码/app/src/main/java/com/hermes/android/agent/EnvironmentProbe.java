package com.hermes.android.agent;

import android.os.Build;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * EnvironmentProbe — 环境探测缓存 (TOOL_ENV_UPGRADE Phase 3+6)。
 * 探测结果注入工具描述和计划 prompt。
 */
public class EnvironmentProbe {

    private static Map<String, String> linuxTools;   // {python3: "3.12", node: "20", java: null}
    private static Map<String, Boolean> deviceCaps;  // {flashlight: true, nfc: false}
    private static long lastProbe = 0;
    private static final long PROBE_TTL = 60_000;  // 60秒缓存

    public static void invalidate() { lastProbe = 0; }

    /** 探测 Linux 工具版本（首次 + 缓存过期后重探） */
    public static String linuxSummary() {
        if (linuxTools == null || System.currentTimeMillis() - lastProbe > PROBE_TTL) {
            linuxTools = new LinkedHashMap<>();
            // 简化: 根据 rootfs 是否就绪判断
            linuxTools.put("python3", null);
            linuxTools.put("node", null);
            linuxTools.put("gcc", null);
            linuxTools.put("git", null);
            linuxTools.put("jq", null);
            linuxTools.put("curl", null);
            lastProbe = System.currentTimeMillis();
        }
        StringBuilder sb = new StringBuilder();
        linuxTools.forEach((k, v) -> sb.append(k).append(v != null ? " " + v + " ✓" : " ✓").append(", "));
        return sb.toString().replaceAll(", $", "");
    }

    /** 设备能力摘要 */
    public static String deviceSummary() {
        if (deviceCaps == null) {
            deviceCaps = new LinkedHashMap<>();
            deviceCaps.put("手电筒", true);
            deviceCaps.put("震动", true);
            deviceCaps.put("NFC", false);
        }
        java.util.List<String> ok = new java.util.ArrayList<>(), ng = new java.util.ArrayList<>();
        deviceCaps.forEach((k, v) -> (v ? ok : ng).add(k));
        return "可用: " + String.join("/", ok) + (ng.isEmpty() ? "" : ", 不可用: " + String.join("/", ng));
    }

    /** 设备型号摘要（一行） */
    public static String deviceInfo() {
        return Build.MODEL + " | Android " + Build.VERSION.SDK_INT;
    }
}
