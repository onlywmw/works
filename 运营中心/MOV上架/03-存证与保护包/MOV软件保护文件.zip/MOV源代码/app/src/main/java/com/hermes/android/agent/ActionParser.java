package com.hermes.android.agent;

import org.json.JSONObject;

/**
 * AgentLoop 动作解析器 — 从大脑( LLM )输出中容错提取一个 JSON 动作。
 *
 * 容错策略 (DESIGN_AGENT_LOOP 工具协议):
 * 1. 剥 markdown ```json / ``` 围栏
 * 2. 取首个 '{' 到末个 '}' 的子串
 * 3. 解析失败返回 err (供回灌重试, 不计为合法动作)
 */
public final class ActionParser {

    private ActionParser() {}

    /** 解析结果: ok 时持有 action JSONObject; 否则持有 err 信息 */
    public static class Result {
        public final boolean ok;
        public final JSONObject action;
        public final String err;

        private Result(boolean ok, JSONObject action, String err) {
            this.ok = ok;
            this.action = action;
            this.err = err;
        }
    }

    /**
     * 提取文本中的 JSON 对象子串 (栈式匹配 + 双起点回退)。
     *
     * 容错: LLM 可能在 JSON 前后加解释文字, JSON 内部可能嵌套对象。
     * 先用 LAST { 起点 (JSON 通常在最末尾), 失败回退 FIRST { 起点。
     * 找不到或括号不配对返回 null。
     */
    public static String extractJson(String text) {
        if (text == null) return null;
        String s = text.trim();

        // 1. 剥 markdown 围栏
        if (s.startsWith("```")) {
            int nl = s.indexOf('\n');
            if (nl > 0) s = s.substring(nl + 1);
            // 去末尾围栏 (可能后跟空白)
            int fenceEnd = s.lastIndexOf("```");
            if (fenceEnd >= 0) {
                String after = s.substring(fenceEnd + 3).trim();
                if (after.isEmpty()) s = s.substring(0, fenceEnd);
            }
            s = s.trim();
        }

        // 2. 双起点栈式匹配: FIRST 优先 (正确处理嵌套JSON), LAST 回退 (LLM 外套文字)
        String result = extractWithStack(s, true);  // 先 FIRST
        if (result == null) result = extractWithStack(s, false); // 回退 LAST
        return result;
    }

    /**
     * 栈式 JSON 提取: 从指定方向的 { 开始, 数深度直到归零。
     * @param fromStart true=首个{, false=末个{
     * @return 提取的 JSON 子串, 或 null
     */
    private static String extractWithStack(String s, boolean fromStart) {
        int start = fromStart ? s.indexOf('{') : s.lastIndexOf('{');
        if (start < 0) return null;

        int depth = 0;
        boolean inString = false;
        boolean escaped = false;

        for (int i = start; i < s.length(); i++) {
            char c = s.charAt(i);

            if (escaped) { escaped = false; continue; }
            if (c == '\\') { escaped = true; continue; }
            if (c == '"') { inString = !inString; continue; }
            if (inString) continue;

            if (c == '{') {
                depth++;
            } else if (c == '}') {
                depth--;
                if (depth == 0) {
                    return s.substring(start, i + 1);
                }
            }
        }
        return null; // 括号不配对
    }

    /** 诊断用: 数 { 和 } 数量, 供 makePlan 的精准 retry 反馈 */
    public static int countChar(String s, char c) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == c) n++;
        }
        return n;
    }

    public static Result parse(String text) {
        String json = extractJson(text);
        if (json == null) return new Result(false, null, "未找到 JSON 对象");
        try {
            JSONObject obj = new JSONObject(json);
            String action = obj.optString("action", "");
            if (action.isEmpty()) return new Result(false, null, "缺少 action 字段");
            return new Result(true, obj, null);
        } catch (Exception e) {
            return new Result(false, null, "JSON 解析失败: " + e.getMessage());
        }
    }
}
