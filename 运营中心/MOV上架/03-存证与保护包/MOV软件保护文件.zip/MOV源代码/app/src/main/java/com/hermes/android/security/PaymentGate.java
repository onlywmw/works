package com.hermes.android.security;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 支付闸 — domain_policies 匹配 + 锁屏确认 + 数据掩码。
 *
 * <p>冻结稿: docs/contracts/PAYMENT_GATE_SCHEMA.md v1.1
 *
 * <p>三关卡：
 * <ol>
 *   <li>domain 匹配 — host 命中 payment_domains → mark payment_sensitive</li>
 *   <li>审批升级 — payment_sensitive 写操作强制 BiometricPrompt（不可降级）</li>
 *   <li>数据掩码 — 金额/订单号掩码后再入 LLM 上下文</li>
 * </ol>
 */
public class PaymentGate {

    private static final String TAG = "PaymentGate";
    private static final String RULES_FILE = "domain_policies.json";

    private final Context ctx;
    private File auditDir;  // set by ConnectWebActivity; audit events written to auditDir/payment_audit.jsonl

    /** 支付域名列表 */
    private List<String> paymentDomains = Collections.emptyList();
    /** 金额嗅探关键字（URL query 参数名 + 通用符号） */
    private List<String> amountPatterns = Collections.emptyList();

    // 金额掩码: ¥ + 数字部分 → ¥*   (e.g. 128.50 → 1**.**)
    private static final Pattern AMOUNT_DIGITS = Pattern.compile("[¥￥]?\\s*(\\d+)([.,]\\d+)?");
    private static final Pattern ORDER_ID = Pattern.compile("(\\d{4})\\d*(\\d{4})");

    public PaymentGate(Context ctx) {
        this.ctx = ctx != null ? ctx.getApplicationContext() : null;
        if (this.ctx != null) loadConfig();
    }

    // ==================== 关卡 1: domain 匹配 ====================

    /**
     * 判断 URL 是否落在支付域。
     * 匹配规则：host 命中 payment_domains 任一（支持 *. 通配前缀，左锚定防后缀欺骗）。
     */
    public boolean isPaymentDomain(String url) {
        String host = extractHost(url);
        if (host == null || paymentDomains.isEmpty()) return false;
        for (String domain : paymentDomains) {
            if (matchesDomain(host, domain)) return true;
        }
        return false;
    }

    /** host 是否匹配 domain 模式（exact / *.xxx / 左锚定防后缀） */
    static boolean matchesDomain(String host, String pattern) {
        if (pattern.startsWith("*.")) {
            // *.alipay.com → 匹配 www.alipay.com、mobile.alipay.com，不匹配 alipay.com.evil.com
            String suffix = pattern.substring(1); // .alipay.com
            return host.endsWith(suffix) && !host.equals(suffix.substring(1)); // 至少有一级子域
        }
        return host.equals(pattern);
    }

    // ==================== 关卡 2: 锁屏确认（指纹/PIN/图案） ====================

    private static final int REQUEST_CODE_PAYMENT_CONFIRM = 9001;
    private Runnable pendingSuccess;
    private Runnable pendingRejected;
    private String lastRejectReason = "unknown";

    /**
     * 弹出系统锁屏确认（指纹/PIN/图案）验证支付域写操作。
     *
     * 走 KeyguardManager.createConfirmDeviceCredentialIntent——系统级锁屏验证，
     * 零额外依赖、全 API 兼容。设备有指纹/面部 → 走生物识别；否则走 PIN/图案。
     *
     * @param activity   ConnectWebActivity 实例
     * @param actionDesc 操作描述（如 "click 结算按钮"）
     * @param onSuccess  用户确认后回调
     * @param onRejected 用户拒绝/失败后回调
     */
    public void promptPaymentApproval(androidx.appcompat.app.AppCompatActivity activity,
                                       String actionDesc,
                                       Runnable onSuccess,
                                       Runnable onRejected) {
        KeyguardManager kgm = (KeyguardManager) ctx.getSystemService(Context.KEYGUARD_SERVICE);
        if (kgm == null) {
            Log.w(TAG, "Keyguard: service unavailable");
            lastRejectReason = "keyguard_unavailable";
            onRejected.run();
            return;
        }
        if (!kgm.isKeyguardSecure()) {
            Log.w(TAG, "Keyguard: no secure lockscreen — rejecting");
            lastRejectReason = "no_lockscreen_denied";
            onRejected.run();
            return;
        }
        // 有锁屏保护 → 走系统锁屏验证（指纹/面部/PIN/图案）
        pendingSuccess = onSuccess;
        pendingRejected = onRejected;
        lastRejectReason = "cancelled";
        Intent intent = kgm.createConfirmDeviceCredentialIntent("支付确认", actionDesc);
        if (intent == null) {
            Log.w(TAG, "Keyguard: createConfirmDeviceCredentialIntent returned null");
            lastRejectReason = "keyguard_intent_null";
            pendingSuccess = null;
            pendingRejected = null;
            onRejected.run();
            return;
        }
        activity.startActivityForResult(intent, REQUEST_CODE_PAYMENT_CONFIRM);
    }

    /** ConnectWebActivity.onActivityResult 调用此方法处理锁屏验证结果 */
    public boolean handleActivityResult(int requestCode, int resultCode) {
        if (requestCode != REQUEST_CODE_PAYMENT_CONFIRM) return false;
        if (resultCode == android.app.Activity.RESULT_OK && pendingSuccess != null) {
            Log.d(TAG, "Keyguard: success");
            lastRejectReason = null;
            pendingSuccess.run();
        } else if (pendingRejected != null) {
            Log.d(TAG, "Keyguard: rejected (reason=" + lastRejectReason + ")");
            pendingRejected.run();
        }
        pendingSuccess = null;
        pendingRejected = null;
        return true;
    }

    /** 最后一次拒绝原因：cancelled / no_lockscreen_denied / keyguard_unavailable / keyguard_intent_null / null=success */
    public String getLastRejectReason() { return lastRejectReason; }

    /** 设置 audit 落盘目录（ConnectWebActivity 在 onCreate 调用，指向 filesDir） */
    public void setAuditDir(File dir) { this.auditDir = dir; }

    // ==================== 关卡 3: 数据掩码 ====================

    /**
     * 从 URL 提取并掩码支付上下文。
     * 返回 JSON: {masked_amount?, masked_order_id?, domain, path}
     */
    public JSONObject extractPaymentContext(String url) {
        JSONObject ctx = new JSONObject();
        try {
            URI uri = new URI(url);
            ctx.put("domain", uri.getHost());
            ctx.put("path", uri.getPath());
            String query = uri.getQuery();
            if (query != null && !query.isEmpty()) {
                for (String pattern : amountPatterns) {
                    if (query.toLowerCase().contains(pattern.toLowerCase())) {
                        ctx.put("masked_amount", maskAmount(query));
                        break;
                    }
                }
                // 订单号掩码
                String maskedOrder = maskOrderId(query);
                if (maskedOrder != null) {
                    ctx.put("masked_order_id", maskedOrder);
                }
            }
        } catch (Exception ignored) {}
        return ctx;
    }

    /** 金额掩码: ¥128.50 → ¥1**.** */
    String maskAmount(String text) {
        if (text == null) return null;
        Matcher m = AMOUNT_DIGITS.matcher(text);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            String intPart = m.group(1);
            String decPart = m.group(2);
            String maskedInt = intPart.length() <= 1
                    ? "*"
                    : intPart.charAt(0) + "*".repeat(intPart.length() - 1);
            String maskedDec = decPart != null
                    ? "." + "*".repeat(decPart.length())
                    : "";
            m.appendReplacement(sb, "¥" + maskedInt + maskedDec);
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** 订单号掩码: 2026073012345678 → 2026****5678；不足 8 位全部掩码 */
    String maskOrderId(String text) {
        if (text == null) return null;
        Matcher m = ORDER_ID.matcher(text);
        if (m.find()) {
            String full = m.group(1) + m.group(2);
            if (full.length() < 8) return "****";
            return m.group(1) + "****" + m.group(2);
        }
        // 短数字串（< 8 位）或非标准格式 → 全部掩码
        Matcher anyDigits = Pattern.compile("\\d{4,}").matcher(text);
        if (anyDigits.find()) return "****";
        return null;
    }

    // ==================== journal audit ====================

    /** 生成支付闸审计事件 JSON 并落盘到 payment_audit.jsonl（与 Journal 同款 append-only JSONL） */
    public JSONObject auditEvent(String action, String url, String biometricResult) {
        JSONObject ev = new JSONObject();
        try {
            ev.put("type", "payment_gate");
            ev.put("audit", true);
            ev.put("action", action);
            ev.put("domain", extractHost(url));
            ev.put("biometric_result", biometricResult);
            ev.put("timestamp_ms", System.currentTimeMillis());
            JSONObject pc = extractPaymentContext(url);
            if (pc.has("masked_amount")) ev.put("masked_amount", pc.opt("masked_amount"));
        } catch (Exception ignored) {}

        // 落盘: append-only JSONL, 与 BridgeKernel Journal 同机制
        if (auditDir != null) {
            try {
                auditDir.mkdirs();
                File f = new File(auditDir, "payment_audit.jsonl");
                try (OutputStreamWriter w = new OutputStreamWriter(
                        new FileOutputStream(f, true), StandardCharsets.UTF_8)) {
                    w.write(ev.toString() + "\n");
                }
            } catch (Exception e) {
                Log.w(TAG, "audit write failed: " + e.getMessage());
            }
        }
        return ev;
    }

    // ==================== config loading ====================

    private void loadConfig() {
        String json = readFile(new File(ctx.getFilesDir(), RULES_FILE));
        if (json == null) json = readAssets(RULES_FILE);
        if (json == null) return;

        try {
            JSONObject root = new JSONObject(json);
            JSONObject dp = root.optJSONObject("domain_policies");
            if (dp == null) return;

            JSONArray domains = dp.optJSONArray("payment_domains");
            if (domains != null) {
                List<String> list = new ArrayList<>();
                for (int i = 0; i < domains.length(); i++) {
                    list.add(domains.optString(i, ""));
                }
                paymentDomains = list;
            }

            JSONArray patterns = dp.optJSONArray("amount_patterns");
            if (patterns != null) {
                List<String> list = new ArrayList<>();
                for (int i = 0; i < patterns.length(); i++) {
                    list.add(patterns.optString(i, ""));
                }
                amountPatterns = list;
            }
        } catch (Exception e) {
            Log.w(TAG, "Failed to parse domain_policies: " + e.getMessage());
        }
    }

    /** debug 构建：每次读 mtime 以支持热编辑 */
    private String readFile(File f) {
        if (!f.exists()) return null;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                new FileInputStream(f), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private String readAssets(String path) {
        try (InputStream is = ctx.getAssets().open(path)) {
            BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    // ==================== utils ====================

    static String extractHost(String url) {
        if (url == null) return null;
        try {
            return new URI(url).getHost();
        } catch (Exception ignored) {}
        int start = url.indexOf("://");
        if (start < 0) return null;
        int end = url.indexOf("/", start + 3);
        if (end < 0) end = url.length();
        return url.substring(start + 3, end);
    }
}
