package com.hermes.android.workflow;

import android.content.Context;
import android.util.Log;

import androidx.work.Worker;
import androidx.work.WorkerParameters;

/**
 * 第二幕 time_cron 周期任务：WorkManager 15min 周期 → source.tick（TICK 事件），
 * time_cron workflow 的 cron 匹配当前时间则 fire。
 */
public class CronWorker extends Worker {

    public CronWorker(Context context, WorkerParameters params) {
        super(context, params);
    }

    @Override
    public Result doWork() {
        try {
            Workflows w = Workflows.get();
            if (w != null) w.source().tick(System.currentTimeMillis());
        } catch (Exception e) {
            Log.e("Workflow", "cron worker error", e);
        }
        return Result.success();
    }
}
