package com.hermes.android.bridge;

import android.webkit.JavascriptInterface;

import com.hermes.android.HermesActivity;
import com.hermes.android.vault.KeyguardGate;
import com.hermes.android.vault.SecureVault;
import com.hermes.android.vault.VaultException;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/**
 * BridgeVault — 保险柜桥（P5，TASKS_P5_VAULT §四）。
 *
 * vaultList / vaultLock / vaultUnlock / vaultDelete（cbId 异步，回调走 window._hermesCb）。
 * vaultLock / vaultUnlock = ACTION（审批闸）：主线程弹 Keyguard（复用 PaymentGate 锁屏确认），
 * 过闸才执行；vaultList / vaultDelete 无需闸。
 *
 * 错误信封：{ok:true, data} / {ok:false, error:{code, msg}}（Contract: Envelope v1.0）。
 */
public class BridgeVault extends BaseBridge {

    public BridgeVault(HermesActivity activity) {
        super(activity);
    }

    /** 列保险柜条目（只元信息，无内容，不弹闸） */
    @JavascriptInterface
    public void vaultList(String cbId) {
        try {
            List<SecureVault.VaultEntry> entries = activity.getSecureVault().list();
            JSONArray arr = new JSONArray();
            for (SecureVault.VaultEntry e : entries) {
                arr.put(new JSONObject()
                        .put("id", e.id)
                        .put("name", e.name)
                        .put("createdAtMs", e.createdAtMs)
                        .put("sizeBytes", e.sizeBytes));
            }
            cb(cbId, ok(new JSONObject().put("entries", arr)));
        } catch (Exception e) {
            cb(cbId, err("VAULT_FAILED", "保险柜列表失败: " + e.getMessage()));
        }
    }

    /** 加密存入保险柜（弹 Keyguard 审批闸，过闸才落盘） */
    @JavascriptInterface
    public void vaultLock(String name, String text, String cbId) {
        if (name == null || name.isEmpty()) { cb(cbId, err("BAD_REQUEST", "name 不能为空")); return; }
        if (text == null || text.isEmpty()) { cb(cbId, err("BAD_REQUEST", "text 不能为空")); return; }
        runVaultGate("vault_lock", name, cbId, () -> {
            String id = activity.getSecureVault().lock(name, text);
            cb(cbId, ok(new JSONObject().put("id", id).put("name", SecureVault.sanitizeName(name))));
        });
    }

    /** 解锁查看保险柜条目（弹 Keyguard 审批闸，当次条目有效，过闸才出内容） */
    @JavascriptInterface
    public void vaultUnlock(String id, String cbId) {
        if (id == null || id.isEmpty()) { cb(cbId, err("BAD_REQUEST", "id 不能为空")); return; }
        runVaultGate("vault_unlock", id, cbId, () -> {
            String content = activity.getSecureVault().unlock(id);
            cb(cbId, ok(new JSONObject().put("content", content)));
        });
    }

    /** 删除保险柜条目（无闸；JS 侧二次确认） */
    @JavascriptInterface
    public void vaultDelete(String id, String cbId) {
        if (id == null || id.isEmpty()) { cb(cbId, err("BAD_REQUEST", "id 不能为空")); return; }
        try {
            boolean deleted = activity.getSecureVault().delete(id);
            cb(cbId, ok(new JSONObject().put("deleted", deleted)));
        } catch (Exception e) {
            cb(cbId, err("VAULT_FAILED", e.getMessage()));
        }
    }

    // ==================== Keyguard 审批闸（复用 PaymentGate 锁屏确认） ====================

    private interface VaultOp { void run() throws Exception; }

    /** 主线程弹 Keyguard → 过闸后执行 op 并回调；拒绝/无锁屏 → 诚实错误信封 */
    private void runVaultGate(String action, String entryId, String cbId, VaultOp op) {
        final HermesActivity act = activity;
        final KeyguardGate gate = act.getKeyguardGate();
        final KeyguardGate.Prompter prompter = act.getKeyguardPrompter();
        final String desc = "vault_lock".equals(action)
                ? "加密存入保险柜（需锁屏验证）"
                : "解锁查看保险柜条目（需锁屏验证，仅当次有效）";
        act.runOnUiThread(() -> {
            boolean requested = gate.request(prompter, entryId, desc,
                    new KeyguardGate.ResultHandler() {
                        @Override public void onApproved() {
                            gate.consume();   // 当次授权消费
                            try { op.run(); }
                            catch (VaultException ve) { cb(cbId, err(ve.code, ve.getMessage())); }
                            catch (Exception e) { cb(cbId, err("VAULT_FAILED", e.getMessage())); }
                        }
                        @Override public void onRejected(String reason) {
                            gate.consume();   // v1.1: 拒绝/取消/无锁屏也复位闸（GATE_BUSY 自愈，照 javaCbMap 清理思路）
                            cb(cbId, err("GATE_REJECTED", gateReason(reason)));
                        }
                    });
            if (!requested) cb(cbId, err("GATE_BUSY", "已有解锁操作进行中，稍后再试"));
        });
    }

    /** 诚实降级文案：无锁屏密码不许静默跳过 */
    private static String gateReason(String reason) {
        if ("no_lockscreen_denied".equals(reason)) {
            return "需先设置锁屏密码（指纹/PIN/图案）才能使用保险柜";
        }
        return "已取消或拒绝";
    }

    // ==================== 错误信封 ====================

    private void cb(String cbId, String json) {
        evalJs("window._hermesCb('" + cbId + "'," + json + ")");
    }

    private static String ok(JSONObject data) {
        try {
            return new JSONObject().put("ok", true).put("data", data).toString();
        } catch (Exception e) {
            return "{\"ok\":false,\"error\":{\"code\":\"INTERNAL\",\"msg\":\"信封构造失败\"}}";
        }
    }

    private static String err(String code, String msg) {
        try {
            return new JSONObject().put("ok", false)
                    .put("error", new JSONObject().put("code", code).put("msg", msg)).toString();
        } catch (Exception e) {
            return "{\"ok\":false,\"error\":{\"code\":\"INTERNAL\",\"msg\":\"信封构造失败\"}}";
        }
    }
}
