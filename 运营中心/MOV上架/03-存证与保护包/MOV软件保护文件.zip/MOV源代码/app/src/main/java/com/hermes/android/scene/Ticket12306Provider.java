package com.hermes.android.scene;

import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.agent.ToolRegistry.*;

import java.util.ArrayList;
import java.util.List;

/**
 * 12306 查票工具 Provider（对齐 12306-mcp 8 工具）。
 *
 * 全部 access=readonly（查询无副作用）→ 8389 MCP (MovMcpServer) 经 RegistryProvider.readonlyTools
 * 自动暴露，MCP 侧零改动。网络 IO 工具 sync=true（禁同步桥红线），纯内存查询 sync=false。
 *
 * 错误归因 H1：网络/风控→SOURCE_DOWN；站表/路径正则失败或 200 但零有效车次→PARSE_DRIFT；
 * 未知车站/日期早于今天→普通错误；成功零结果→"没有查询到相关车次信息"。
 */
public class Ticket12306Provider implements ToolProvider {

    @Override public String id() { return "ticket12306"; }

    @Override
    public List<Tool> discover() {
        List<Tool> list = new ArrayList<>();

        // ═══ get-tickets: 查余票（核心） ═══
        list.add(new Tool("get-tickets",
            "查询12306余票信息。返回车次/出发到达站/时间/历时/各席别票价与余票。支持车次类型过滤(G高铁/D动车/Z直达/T特快/K快速/O其他/F复兴号/S智能动车组)、发车时间窗过滤、排序与限量。",
            null, a -> {
                try {
                    Ticket12306Source src = new Ticket12306Source();
                    Ticket12306Source.QueryOptions o = opts(a);
                    o.date = a.optString("date", "");
                    o.fromStation = a.optString("fromStation", "");
                    o.toStation = a.optString("toStation", "");
                    o.trainFilterFlags = a.optString("trainFilterFlags", "");
                    o.earliestStartTime = a.optInt("earliestStartTime", 0);
                    o.latestStartTime = a.optInt("latestStartTime", 24);
                    o.sortFlag = a.optString("sortFlag", "");
                    o.sortReverse = a.optBoolean("sortReverse", false);
                    o.limitedNum = a.optInt("limitedNum", 0);
                    o.format = a.optString("format", "text");
                    return result(src.search(o));
                } catch (IllegalArgumentException e) {
                    return new Result(false, e.getMessage());
                } catch (Exception e) {
                    return new Result(false, "查票失败: " + e.getMessage(),
                            null, null, Result.REASON_SOURCE_DOWN);
                }
            },
            "native", "readonly", "none", true, 12, "travel",
            new ParamDef[]{
                new ParamDef("date", "string", true, "yyyy-MM-dd", "查询日期，如 2026-08-06；相对日期请先用 get-current-date 算"),
                new ParamDef("fromStation", "string", true, "", "出发地中文名或 station_code"),
                new ParamDef("toStation", "string", true, "", "到达地中文名或 station_code"),
                new ParamDef("trainFilterFlags", "string", false, "^[GDZTKOFS]*$", "车次筛选 G/D/Z/T/K/O/F/S，多个可组合，如 G 表示高铁"),
                new ParamDef("earliestStartTime", "int", false, "0-24", "最早出发时间(小时)，默认0"),
                new ParamDef("latestStartTime", "int", false, "0-24", "最迟出发时间(小时)，默认24"),
                new ParamDef("sortFlag", "string", false, "startTime|arriveTime|duration", "排序方式"),
                new ParamDef("sortReverse", "boolean", false, "true/false", "是否逆向排序"),
                new ParamDef("limitedNum", "int", false, ">=0", "返回条数限制，0=不限"),
                new ParamDef("format", "string", false, "text|csv|json", "返回格式，默认 text"),
            },
            "文本/CSV/JSON 车次列表（含席别票价与余票）",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"get-tickets\",\"args\":{\"date\":\"2026-08-06\",\"fromStation\":\"北京\",\"toStation\":\"上海\",\"trainFilterFlags\":\"G\"}}"},
            new String[]{
                "date 不能早于今天",
                "车站支持中文名或 telecode（北京→BJP），未知车站会报错",
                "高铁票用 trainFilterFlags=G；要全部车次留空",
            }, 8000,
            new Manifest("查12306余票", "low", "查询12306余票与票价", false, "io", "SLOW", true, 12000),
            null));

        // ═══ get-current-date: 上海时区当前日期 ═══
        list.add(new Tool("get-current-date",
            "获取当前日期（上海时区 Asia/Shanghai, UTC+8），返回 yyyy-MM-dd。用于解析用户的相对日期（明天/下周三）给出准确日期输入。",
            null, a -> new Result(true, Ticket12306Source.currentDateShanghai()),
            "native", "readonly", "none", true, 2, "travel",
            new ParamDef[]{},
            "yyyy-MM-dd",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"get-current-date\",\"args\":{}}"},
            null, 300,
            new Manifest("当前日期", "low", "获取上海时区当前日期", false, "io", "SLOW", false, 2000),
            null));

        // ═══ get-stations-code-in-city: 城市→该市所有车站 ═══
        list.add(new Tool("get-stations-code-in-city",
            "通过中文城市名查询该城市所有火车站的名称及其 station_code，返回车站列表。",
            null, a -> {
                try {
                    String city = a.optString("city", "");
                    if (city.isEmpty()) return new Result(false, "city 必填");
                    Ticket12306Stations st = Ticket12306Stations.get();
                    List<Ticket12306Stations.Station> stations = st.byCity().get(city);
                    if (stations == null || stations.isEmpty()) return new Result(false, "未找到城市: " + city);
                    org.json.JSONArray arr = new org.json.JSONArray();
                    for (Ticket12306Stations.Station s : stations) arr.put(s.toJson());
                    return new Result(true, "该城市车站列表", new org.json.JSONObject().put("stations", arr).toString());
                } catch (Exception e) {
                    return new Result(false, "车站查询失败: " + e.getMessage(),
                            null, null, Result.REASON_SOURCE_DOWN);
                }
            },
            "native", "readonly", "none", true, 3, "travel",
            new ParamDef[]{
                new ParamDef("city", "string", true, "", "中文城市名，如 北京、上海"),
            },
            "JSON: {\"stations\":[{station_code,station_name,...}]}",
            new String[]{"北京有哪些火车站"}, null, 3000,
            new Manifest("城市车站列表", "low", "查城市下所有火车站", false, "io", "SLOW", false, 3000),
            null));

        // ═══ get-station-code-of-citys: 城市→代表站 code ═══
        list.add(new Tool("get-station-code-of-citys",
            "通过中文城市名查询代表该城市的 station_code。多个城市用 | 分隔，如 \"北京|上海\"。",
            null, a -> {
                try {
                    String citys = a.optString("citys", "");
                    if (citys.isEmpty()) return new Result(false, "citys 必填");
                    Ticket12306Stations st = Ticket12306Stations.get();
                    org.json.JSONObject result = new org.json.JSONObject();
                    for (String city : citys.split("\\|")) {
                        Ticket12306Stations.Station rep = st.cityRep().get(city);
                        result.put(city, rep != null ? rep.toJson()
                            : new org.json.JSONObject().put("error", "未检索到城市"));
                    }
                    return new Result(true, "城市代表站", result.toString());
                } catch (Exception e) {
                    return new Result(false, "车站查询失败: " + e.getMessage(),
                            null, null, Result.REASON_SOURCE_DOWN);
                }
            },
            "native", "readonly", "none", true, 3, "travel",
            new ParamDef[]{
                new ParamDef("citys", "string", true, "北京|上海", "要查询的城市，多个用 | 分割"),
            },
            "JSON: {\"北京\":{station_code,...},\"上海\":{...}}",
            new String[]{"北京|上海"}, null, 3000,
            new Manifest("城市代表站", "low", "查城市代表车站 code", false, "io", "SLOW", false, 3000),
            null));

        // ═══ get-station-code-by-names: 站名→code ═══
        list.add(new Tool("get-station-code-by-names",
            "通过具体中文车站名查询其 station_code。多个站点用 | 分隔，如 \"北京南|上海虹桥\"。",
            null, a -> {
                try {
                    String names = a.optString("stationNames", "");
                    if (names.isEmpty()) return new Result(false, "stationNames 必填");
                    Ticket12306Stations st = Ticket12306Stations.get();
                    org.json.JSONObject result = new org.json.JSONObject();
                    for (String name : names.split("\\|")) {
                        String clean = name.endsWith("站") ? name.substring(0, name.length() - 1) : name;
                        Ticket12306Stations.Station s = st.byName().get(clean);
                        result.put(name, s != null ? s.toJson()
                            : new org.json.JSONObject().put("error", "未检索到车站"));
                    }
                    return new Result(true, "车站 code", result.toString());
                } catch (Exception e) {
                    return new Result(false, "车站查询失败: " + e.getMessage(),
                            null, null, Result.REASON_SOURCE_DOWN);
                }
            },
            "native", "readonly", "none", true, 3, "travel",
            new ParamDef[]{
                new ParamDef("stationNames", "string", true, "北京南|上海虹桥", "具体车站名，多个用 | 分割"),
            },
            "JSON: {\"北京南\":{station_code,...},\"上海虹桥\":{...}}",
            new String[]{"北京南|上海虹桥"}, null, 3000,
            new Manifest("车站名查code", "low", "按车站名查 station_code", false, "io", "SLOW", false, 3000),
            null));

        // ═══ get-station-by-telecode: telecode→车站详情 ═══
        list.add(new Tool("get-station-by-telecode",
            "通过车站 station_telecode (3位字母编码) 查询车站详细信息（名称/拼音/所属城市）。",
            null, a -> {
                try {
                    String code = a.optString("stationTelecode", "");
                    if (code.isEmpty()) return new Result(false, "stationTelecode 必填");
                    Ticket12306Stations st = Ticket12306Stations.get();
                    Ticket12306Stations.Station s = st.byTelecode(code);
                    return s != null ? new Result(true, "车站详情", s.toJson().toString())
                        : new Result(false, "未找到车站: " + code);
                } catch (Exception e) {
                    return new Result(false, "车站查询失败: " + e.getMessage(),
                            null, null, Result.REASON_SOURCE_DOWN);
                }
            },
            "native", "readonly", "none", true, 3, "travel",
            new ParamDef[]{
                new ParamDef("stationTelecode", "string", true, "3位字母", "车站 telecode，如 BJP"),
            },
            "JSON: {station_code,station_name,...}",
            new String[]{"BJP"}, null, 3000,
            new Manifest("车站详情", "low", "按 telecode 查车站详情", false, "io", "SLOW", false, 3000),
            null));

        // ═══ get-interline-tickets: 中转余票 ═══
        list.add(new Tool("get-interline-tickets",
            "查询12306中转余票信息（支持前十条）。从出发站经中转站到到达站的多段换乘方案，含每段车次余票与总历时。",
            null, a -> {
                try {
                    Ticket12306Source src = new Ticket12306Source();
                    Ticket12306Source.QueryOptions o = opts(a);
                    o.date = a.optString("date", "");
                    o.fromStation = a.optString("fromStation", "");
                    o.toStation = a.optString("toStation", "");
                    o.middleStation = a.optString("middleStation", "");
                    o.showWZ = a.optBoolean("showWZ", false);
                    o.trainFilterFlags = a.optString("trainFilterFlags", "");
                    o.earliestStartTime = a.optInt("earliestStartTime", 0);
                    o.latestStartTime = a.optInt("latestStartTime", 24);
                    o.sortFlag = a.optString("sortFlag", "");
                    o.sortReverse = a.optBoolean("sortReverse", false);
                    o.limitedNum = a.optInt("limitedNum", 10);
                    o.format = a.optString("format", "text");
                    return result(src.searchInterline(o));
                } catch (IllegalArgumentException e) {
                    return new Result(false, e.getMessage());
                } catch (Exception e) {
                    return new Result(false, "中转查询失败: " + e.getMessage(),
                            null, null, Result.REASON_SOURCE_DOWN);
                }
            },
            "native", "readonly", "none", true, 15, "travel",
            new ParamDef[]{
                new ParamDef("date", "string", true, "yyyy-MM-dd", "查询日期"),
                new ParamDef("fromStation", "string", true, "", "出发地"),
                new ParamDef("toStation", "string", true, "", "到达地"),
                new ParamDef("middleStation", "string", false, "", "中转地（可选，缺省自动搜索）"),
                new ParamDef("showWZ", "boolean", false, "true/false", "是否显示无座车，默认 false"),
                new ParamDef("trainFilterFlags", "string", false, "^[GDZTKOFS]*$", "车次筛选"),
                new ParamDef("earliestStartTime", "int", false, "0-24", "最早出发时间"),
                new ParamDef("latestStartTime", "int", false, "0-24", "最迟出发时间"),
                new ParamDef("sortFlag", "string", false, "startTime|arriveTime|duration", "排序"),
                new ParamDef("sortReverse", "boolean", false, "true/false", "逆向排序"),
                new ParamDef("limitedNum", "int", false, "默认10", "返回条数，默认10"),
                new ParamDef("format", "string", false, "text|json", "返回格式，默认 text"),
            },
            "文本/JSON 中转方案列表",
            new String[]{"明天北京到昆明怎么转车"},
            new String[]{"只支持前十条", "date 不能早于今天"}, 8000,
            new Manifest("查中转票", "low", "查询12306中转余票", false, "io", "SLOW", true, 12000),
            null));

        // ═══ get-train-route-stations: 车次经停站 ═══
        list.add(new Tool("get-train-route-stations",
            "查询特定列车车次在指定日期的途径车站、到站/出发时间及停留时间等经停信息。",
            null, a -> {
                try {
                    String trainCode = a.optString("trainCode", "");
                    String departDate = a.optString("departDate", "");
                    if (trainCode.isEmpty() || departDate.isEmpty())
                        return new Result(false, "trainCode 和 departDate 必填");
                    Ticket12306Source src = new Ticket12306Source();
                    return result(src.trainRoute(trainCode, departDate, a.optString("format", "text")));
                } catch (IllegalArgumentException e) {
                    return new Result(false, e.getMessage());
                } catch (Exception e) {
                    return new Result(false, "经停站查询失败: " + e.getMessage(),
                            null, null, Result.REASON_SOURCE_DOWN);
                }
            },
            "native", "readonly", "none", true, 12, "travel",
            new ParamDef[]{
                new ParamDef("trainCode", "string", true, "如 G1033", "车次 train_code"),
                new ParamDef("departDate", "string", true, "yyyy-MM-dd", "列车出发日期"),
                new ParamDef("format", "string", false, "text|json", "返回格式，默认 text"),
            },
            "文本/JSON 经停站列表",
            new String[]{"G1033 的经停站"},
            new String[]{"departDate 不能早于今天"}, 8000,
            new Manifest("查经停站", "low", "查车次途径车站", false, "io", "SLOW", true, 12000),
            null));

        return list;
    }

    private static Ticket12306Source.QueryOptions opts(org.json.JSONObject a) {
        return new Ticket12306Source.QueryOptions();
    }

    /** 统一结果包装：成功→ok=true；空结果→ok=true + "没有查询到相关车次信息"。 */
    private static Result result(Ticket12306Source.QueryResult r) {
        if (r.items.isEmpty()) return new Result(true, "没有查询到相关车次信息");
        return new Result(true, r.text, r.text);
    }
}
