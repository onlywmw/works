package com.hermes.android.agent;

import org.json.JSONObject;

/**
 * Worker — 大脑插件接口 (CONTRACT: Worker v1.0)。
 * AgentLoop 只编排，不关心谁在干活；路由在 PLANNING 阶段显性决定。
 * 新 Worker 只需实现接口 + 注册，AgentLoop 零改动。
 */
public interface Worker {

    /** 例: "fast:deepseek-flash" / "heavy:hermes" */
    String id();

    /** 同步、无副作用、廉价；false = 编排期就禁排 */
    boolean available();

    /** 统一入参/出参；阻塞式，内部自管超时 */
    WorkerResult run(WorkerTask task);

    /** 取消在途执行（先置标志再杀流，同 STREAMING 红线） */
    void cancel();

    // ==================== WorkerTask (入参, CONTRACT §2) ====================

    class WorkerTask {
        public final String taskId;
        public final int step;
        public final String instruction;
        public final JSONObject context;      // transcriptRef, files
        public final int timeoutSec;
        public final boolean network;
        public final int maxTokens;

        public WorkerTask(String taskId, int step, String instruction,
                          JSONObject context, int timeoutSec, boolean network, int maxTokens) {
            this.taskId = taskId;
            this.step = step;
            this.instruction = instruction;
            this.context = context != null ? context : new JSONObject();
            this.timeoutSec = timeoutSec > 0 ? timeoutSec : 600;
            this.network = network;
            this.maxTokens = maxTokens > 0 ? maxTokens : 8000;
        }
    }

    // ==================== WorkerResult (出参, CONTRACT §3) ====================

    class WorkerResult {
        public final boolean ok;
        public final String text;
        public final String[] files;
        public final int promptTokens;
        public final int completionTokens;
        public final String errorCode;    // null = 无错误
        public final String errorMsg;
        public final boolean retryable;

        private WorkerResult(boolean ok, String text, String[] files,
                             int promptTokens, int completionTokens,
                             String errorCode, String errorMsg, boolean retryable) {
            this.ok = ok;
            this.text = text;
            this.files = files;
            this.promptTokens = promptTokens;
            this.completionTokens = completionTokens;
            this.errorCode = errorCode;
            this.errorMsg = errorMsg;
            this.retryable = retryable;
        }

        public static WorkerResult success(String text, String[] files, int pt, int ct) {
            return new WorkerResult(true, text, files, pt, ct, null, null, false);
        }

        public static WorkerResult success(String text) {
            return new WorkerResult(true, text, null, 0, 0, null, null, false);
        }

        public static WorkerResult fail(String code, String msg, boolean retryable) {
            return new WorkerResult(false, null, null, 0, 0, code, msg, retryable);
        }

        /* 错误码常量 (CONTRACT §3, 与 STREAMING §2.4 对齐) */
        public static final String UNAVAILABLE = "UNAVAILABLE";
        public static final String TIMEOUT = "TIMEOUT";
        public static final String STALLED = "STALLED";
        public static final String OUTPUT_TOO_LARGE = "OUTPUT_TOO_LARGE";
        public static final String RATE_LIMIT = "RATE_LIMIT";
        public static final String AUTH = "AUTH";
        public static final String CANCELLED = "CANCELLED";
        public static final String INTERNAL = "INTERNAL";
    }
}
