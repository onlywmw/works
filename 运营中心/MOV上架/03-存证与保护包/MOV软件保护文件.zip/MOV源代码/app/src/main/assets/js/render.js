/* ============================================================
   render.js — DOM 渲染: 房间列表 / 消息 / 视图切换 / 阶段
   P0-3: XSS 修复 — sanitize + textContent 优先
   ============================================================ */

/* P0-3: HTML 消毒 — 白名单实现: DOMParser 解析后递归重建, 只放行安全标签与 class 属性 */
function sanitize(html){
  if(!html)return '';
  /* 标签白名单: 仅允许纯展示类标签 */
  var ALLOWED={b:1,i:1,em:1,strong:1,code:1,pre:1,span:1,div:1,br:1,p:1,ul:1,ol:1,li:1,small:1,sub:1,sup:1};
  /* 危险标签: 连同其内容整棵丢弃(不解包) */
  var DROP={script:1,style:1,iframe:1,object:1,embed:1,form:1,base:1,meta:1,link:1};
  /* DOMParser 以 text/html 解析, 解析出的文档不执行脚本 */
  var doc=new DOMParser().parseFromString(String(html),'text/html');
  var out=document.createElement('div');
  /* 递归遍历: 文本原样保留; 白名单标签重建; 其余标签解包(只保留子节点) */
  function walk(src,dst){
    var nodes=src.childNodes;
    for(var k=0;k<nodes.length;k++){
      var n=nodes[k];
      if(n.nodeType===3){dst.appendChild(document.createTextNode(n.nodeValue));}
      else if(n.nodeType===1){
        var tag=n.tagName.toLowerCase();
        if(DROP[tag])continue;
        if(ALLOWED[tag]){
          var el=document.createElement(tag);
          /* 属性白名单: 只放行 class, 且值只允许字母数字/空格/下划线/连字符 */
          var cls=n.getAttribute('class');
          if(cls&&/^[a-zA-Z0-9 _-]+$/.test(cls))el.setAttribute('class',cls);
          walk(n,el);
          dst.appendChild(el);
        }else{
          walk(n,dst);
        }
      }
    }
  }
  walk(doc.body,out);
  return out.innerHTML;
}
/* P0-3: 安全气泡 — 只保留 <code> 标签，其余走 textContent */
function safeBubble(html){
  var div=document.createElement('div');div.className='bubble';
  if(!html)return div;
  var parts=html.split(/(<code>[\s\S]*?<\/code>)/g);
  parts.forEach(function(part){
    if(/^<code>[\s\S]*?<\/code>$/i.test(part)){
      var code=document.createElement('code');
      code.textContent=part.replace(/^<code>/i,'').replace(/<\/code>$/i,'');
      div.appendChild(code);
    }else if(part){
      div.appendChild(document.createTextNode(part));
    }
  });
  return div;
}

/* ---------- 房间列表渲染 · Apple grouped ---------- */
function avstack(r){var s='<span class="avstack">';var ms=Array.isArray(r.members)?r.members:(r.members&&r.members.ai?r.members.ai:[]);if(ms.length===0){s+='<i style="background:var(--acc-live)">M</i>';}else{ms.forEach(function(m){var a=AV[m]||AV.mov;var col=safeColor(a[1]);s+='<i style="background:'+col+'">'+esc(a[0])+'</i>';});}return s+'</span>';}
/* P0: 颜色白名单 — 只允许 #hex 或字母数字命名色，否则回退默认色 (防 style 注入) */
function safeColor(c){c=String(c||'');return /^(#[0-9a-fA-F]{3,8}|[a-zA-Z0-9]+)$/.test(c)?c:'#f59e0b';}
function roomCard(r){
  /* M 波形状态: 从 room phase + journal 最后事件类型推断 */
  var mcls=''; if(r._agentActive) mcls='working'; else if(r.phase==='已交付'||r._lastEvent==='deliver') mcls='done'; else if(r.phase==='已归档') mcls='done';
  var msvg='<svg class="rm-m '+mcls+'" viewBox="0 0 28 18"><path class="mb" d="M2 3 L8 15 L14 3 L20 15 L26 3"/><path class="mp" d="M2 3 L8 15 L14 3 L20 15 L26 3"/></svg>';
  return '<div class="room" data-room="'+r.id+'">'
    +avstack(r)
    +'<div class="rm-main" style="flex:1;min-width:0">'
    +'<div class="rm-top" style="display:flex;align-items:center;justify-content:space-between"><span class="rm-name">'+esc(r.name)+'</span>'+msvg+'</div>'
    +'<div class="rm-last">'+esc(r.last||'')+'</div></div></div>';
}
function renderRooms(){
  /* 第三幕清场: 老 roomList/ndChat DOM 已删 → 判空防崩 (新脸专家列表用 renderExpertRooms) */
  var active=ROOMS.filter(function(r){return r.phase!=='已归档';});
  var archived=ROOMS.filter(function(r){return r.phase==='已归档';});
  var h='';
  active.forEach(function(r){h+=roomCard(r);});
  archived.forEach(function(r){h+=roomCard(r);});
  var rl=$('roomList'); if(rl)rl.innerHTML=h;
  document.querySelectorAll('#roomList .room').forEach(function(el){
    el.addEventListener('click',function(){
      if(lpSuppressClick())return;
      /* 多选模式: 点卡片 = 切换勾选, 不进房间 */
      if(window._roomSelOn&&window._roomSelOn()){window.toggleRoomSel(el.getAttribute('data-room'));return;}
      enterRoom(el.getAttribute('data-room'));
    });
  });
  if(typeof bindRoomListLongPress==='function')bindRoomListLongPress();
  var nd=$('ndChat'); if(nd)nd.classList.toggle('show',ROOMS.some(function(r){return r.unread;}));
}

/* ---------- 视图切换 ---------- */
function showView(id){if(window.hideMsgActions)hideMsgActions();document.querySelectorAll('.view').forEach(function(v){v.classList.toggle('act',v.id===id);});}
/* 第三幕清场: 老 tab 切换已删 (底导航已删; 系统&模型归新脸设置抽屉) */

/* ---------- 消息渲染 ---------- */
/* P1-8: 附件为 pickFile 文件对象; 旧持久化的字符串 key 直接显示原文 */
function attName(a){return typeof a==='string'?a:(a&&a.name?a.name:'文件');}
function formatBytes(b){if(b<1024)return b+'B';if(b<1048576)return (b/1024).toFixed(1)+'KB';return (b/1048576).toFixed(1)+'MB';}
function attHtml(a){
  var name=attName(a),size=a&&a.size?formatBytes(a.size):'';
  return '<div class="att"><span class="fic">F</span><div><div class="an">'+esc(name)+'</div><div class="am">'+esc(size)+'</div></div></div>';
}
/* P5: push 只做 DOM 追加 + 长按绑定; 持久化由 journal 负责 */
function push(roomId,node,data){
  var room=ROOMS.find(function(r){return r.id===roomId;});
  if(!room)return;
  room.msgs=room.msgs||[];room.msgs.push(node);
  /* 第三幕清场: chatBody 老 DOM 已删 → 判空 (MovRender 从 journal 投影到注入容器) */
  if(curRoomId===roomId){var b=$('chatBody');if(b)b.appendChild(node);var cp=document.getElementById('chatPane');if(cp)cp.scrollTop=cp.scrollHeight;}
  if(typeof bindMsgLongPress==='function')bindMsgLongPress(node,roomId);
  persistRooms();
}
function showTyping(roomId,node){
  if(curRoomId===roomId){var b=$('chatBody');if(b)b.appendChild(node);var cp=document.getElementById('chatPane');if(cp)cp.scrollTop=cp.scrollHeight;}
}
function killTyping(node){if(node&&node.parentNode)node.parentNode.removeChild(node);}
function mkMsg(m){
  var d=document.createElement('div');
  if(m.t==='sys'){d.className='sysline';d.innerHTML=sanitize(m.h);d._md=m;return d;}
  /* M-ARCH-ENV: 房间环境卡 (创建时真实实测的工具链清单, ✓绿/⚠️橙) */
  if(m.t==='env'){
    d.className='msg wide';
    var card=document.createElement('div');card.className='env-card';
    var hd=document.createElement('div');hd.className='env-hd';
    if(m.needInstall){
      hd.textContent='⚠ Linux 环境未就绪';
      card.appendChild(hd);
      var tip=document.createElement('div');tip.className='env-line demo';
      tip.textContent='请先到 设置 → Linux 环境 安装, 就绪后 shell.exec 才能使用';
      card.appendChild(tip);
    }else if(m.error){
      hd.textContent='⚠ 环境初始化未完成';
      card.appendChild(hd);
      var tip2=document.createElement('div');tip2.className='env-line demo';
      tip2.textContent=m.error;
      card.appendChild(tip2);
    }else{
      var e=m.env||{};
      var secs=m.durationMs?(m.durationMs/1000).toFixed(1)+'s':'';
      hd.textContent='⚡ 房间环境就绪'+(secs?' · '+secs:'');
      card.appendChild(hd);
      function line(ok,label,val){
        var l=document.createElement('div');
        l.className='env-line '+(ok?'ok':'demo');
        l.textContent=(ok?'✓ ':'⚠ ')+label+(val?' · '+val:'');
        card.appendChild(l);
      }
      line(true,'Ubuntu',e.ubuntu||'24.04');
      line(!!e.python,'Python',e.python);
      line(!!e.node,'Node',e.node);
      line(!!e.git,'Git',e.git);
      line(!!e.jq,'jq',e.jq);
      line(!!e.rg,'ripgrep',e.rg);
      line(!!e.hermes,'Hermes',e.hermes||(e.hermes===null?'未装 (设置页可装)':e.hermes));
    }
    d.appendChild(card);
    d._md=m;
    return d;
  }
  if(m.t==='tool'){
    d.className='msg wide';d.innerHTML=sanitize(m.h);
    var th=d.querySelector('.th');
    if(th){th.addEventListener('click',function(){d.querySelector('.toolcall').classList.toggle('open');});}
    d._md=m;return d;
  }
  var me=m.me,a=AV[m.who]||AV.mov;
  d.className='msg '+(me?'user':'agent');
  var role=m.role?' <span class="role">'+esc(m.role)+'</span>':'';
  /* P0-3: who 行用 esc，气泡用 safeBubble */
  var whoDiv=document.createElement('div');whoDiv.className='who';
  whoDiv.innerHTML='<i class="av" style="background:'+esc(a[1])+'">'+esc(a[0])+'</i>'+esc(m.who).toUpperCase()+role;
  d.appendChild(whoDiv);
  d.appendChild(safeBubble(m.h||''));
  if(m.att){var attDiv=document.createElement('div');attDiv.innerHTML=sanitize(attHtml(m.att));while(attDiv.firstChild)d.appendChild(attDiv.firstChild);}
  if(m.caret){var c=document.createElement('span');c.className='caret';d.appendChild(c);}
  d._md=m;
  return d;
}
function setPhase(roomId,p){
  var r=ROOMS.find(function(x){return x.id===roomId;});if(!r)return;r.phase=p;
  renderRooms();persistRooms();ev('['+r.name.split(' · ')[0]+'] 阶段 → '+p);
}
function phaseBadge(p){var bc=PHASE_BADGE[p]||'off';return '<span class="badge '+bc+'"><span class="dot"></span>'+esc(p)+'</span>';}

/* ---------- 工具调用卡片 ---------- */
function toolNode(toolName,args,dur,outHtml){
  var d=document.createElement('div');d.className='msg wide';
  d.innerHTML='<div class="toolcall"><div class="th"><span>▸</span><b>'+esc(toolName)+'</b><span>'+esc(args)+'</span><span class="dur">'+esc(dur)+'</span><span class="car">▶</span></div><div class="tb"><pre>'+outHtml+'</pre></div></div>';
  d.querySelector('.th').addEventListener('click',function(){d.querySelector('.toolcall').classList.toggle('open');});
  return d;
}
