package com.hermes.android.partner;

import android.content.Context;
import android.content.SharedPreferences;

import com.hermes.android.vault.SecureVault;

/**
 * partner-server 连接配置（DESIGN_WXPAY_APPLYMENT §五）。
 * 服务器地址：prefs 明文（非敏感）；Bearer token：经 SecureVault 加密存，prefs 只放 vault 条目 id。
 * 红线：token 禁入 journal/logcat/明文 prefs。
 */
public class PartnerConfig {

    private static final String PREFS = "partner_cfg";
    private static final String K_BASE_URL = "base_url";
    private static final String K_TOKEN_ID = "token_vault_id";

    private final SharedPreferences prefs;
    private final SecureVault vault;

    public PartnerConfig(Context ctx) {
        this.prefs = ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.vault = new SecureVault(ctx);
    }

    /** 测试注入 */
    PartnerConfig(SharedPreferences prefs, SecureVault vault) {
        this.prefs = prefs;
        this.vault = vault;
    }

    public String getBaseUrl() { return prefs.getString(K_BASE_URL, ""); }

    public void setBaseUrl(String url) {
        prefs.edit().putString(K_BASE_URL, url == null ? "" : url.trim()).apply();
    }

    /** 存 token（加密进保险柜，prefs 只记条目 id） */
    public void setToken(String token) throws Exception {
        if (token == null || token.trim().isEmpty()) {
            prefs.edit().remove(K_TOKEN_ID).apply();
            return;
        }
        String id = vault.lock("wxpay_partner_token", token.trim());
        prefs.edit().putString(K_TOKEN_ID, id).apply();
    }

    /** 取 token；未配置/保险柜异常 → 空串（调用方按未配置处理，fail-closed） */
    public String getToken() {
        String id = prefs.getString(K_TOKEN_ID, "");
        if (id.isEmpty()) return "";
        try {
            return vault.unlock(id);
        } catch (Exception e) {
            return "";
        }
    }

    /** 是否已配齐（地址 + token） */
    public boolean isConfigured() {
        return !getBaseUrl().isEmpty() && !getToken().isEmpty();
    }

    /** 造客户端（未配齐返回 null，调用方给 NOT_CONFIGURED） */
    public PartnerClient clientOrNull() {
        if (!isConfigured()) return null;
        return new PartnerClient(getBaseUrl(), getToken(), new PartnerClient.OkHttpTransport());
    }
}
