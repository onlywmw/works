package com.hermes.android.partner;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 微信支付服务商进件后端客户端（DESIGN_WXPAY_APPLYMENT §五）。
 * MOV 不持服务商私钥——只调自家 partner-server（Bearer token 鉴权），
 * 由后端完成微信支付公钥加密 + APIv3 签名后转发 api.mch.weixin.qq.com。
 *
 * 三个端点：
 *   POST /v1/applyment            提交申请单 → applyment_id
 *   GET  /v1/applyment/{code}     查询申请单状态
 *   POST /v1/media                图片上传 → media_id
 *
 * 单测零网络：HttpTransport 接口化，生产 = OkHttpTransport，测试 = 队列假回包。
 * 同步核心（工具 handler / 桥内线程调用），桥侧负责转 cbId 异步（网络 IO 禁同步桥）。
 */
public class PartnerClient {

    /** 传输抽象：生产 OkHttp、测试 fake 回包队列 */
    public interface HttpTransport {
        Reply exec(String method, String url, String bearerToken, String jsonBody) throws IOException;
        Reply upload(String url, String bearerToken, String fileName, byte[] data, String mime) throws IOException;
    }

    public static class Reply {
        public final int code;
        public final String body;
        public Reply(int code, String body) { this.code = code; this.body = body; }
    }

    /** 统一结果：ok + data / code+msg（与桥错误信封同构） */
    public static class Resp {
        public final boolean ok;
        public final JSONObject data;
        public final String code;
        public final String msg;
        private Resp(boolean ok, JSONObject data, String code, String msg) {
            this.ok = ok; this.data = data; this.code = code; this.msg = msg;
        }
        public static Resp ok(JSONObject d) { return new Resp(true, d, null, null); }
        public static Resp fail(String code, String msg) { return new Resp(false, null, code, msg); }
        /** 转桥错误信封 {ok, data?} / {ok, error:{code,msg}} */
        public JSONObject toEnvelope() {
            try {
                if (ok) return new JSONObject().put("ok", true).put("data", data == null ? new JSONObject() : data);
                return new JSONObject().put("ok", false)
                        .put("error", new JSONObject().put("code", code).put("msg", msg));
            } catch (Exception e) {
                try {
                    return new JSONObject().put("ok", false)
                            .put("error", new JSONObject().put("code", "INTERNAL").put("msg", "信封构造失败"));
                } catch (Exception e2) {
                    return new JSONObject();
                }
            }
        }
    }

    private final String baseUrl;     // 例 https://mow.kim:8390（去尾斜杠）
    private final String token;       // Bearer token（SecureVault 取出后传入，本类不持久化）
    private final HttpTransport http;

    /** 测试注入 fake transport */
    public PartnerClient(String baseUrl, String token, HttpTransport http) {
        String b = baseUrl == null ? "" : baseUrl.trim();
        this.baseUrl = b.endsWith("/") ? b.substring(0, b.length() - 1) : b;
        this.token = token == null ? "" : token;
        this.http = http;
    }

    /** 提交申请单（body = 微信文档六大块完整 JSON，敏感字段明文，由后端加密）→ applyment_id */
    public Resp submitApplyment(JSONObject applyment) {
        if (applyment == null) return Resp.fail("BAD_REQUEST", "申请单不能为空");
        return exec("POST", "/v1/applyment", applyment.toString());
    }

    /** 查询申请单状态 → 微信原样结果（applyment_state 等） */
    public Resp queryApplyment(String businessCode) {
        if (businessCode == null || businessCode.trim().isEmpty())
            return Resp.fail("BAD_REQUEST", "business_code 不能为空");
        return exec("GET", "/v1/applyment/" + businessCode.trim(), null);
    }

    /** 上传图片 → media_id */
    public Resp uploadMedia(File file) {
        if (file == null || !file.isFile()) return Resp.fail("BAD_REQUEST", "文件不存在");
        try {
            byte[] data = Files.readAllBytes(file.toPath());
            String mime = guessMime(file.getName());
            Reply r = http.upload(baseUrl + "/v1/media", token, file.getName(), data, mime);
            return parse(r);
        } catch (IOException e) {
            return Resp.fail("NET", e.getMessage() == null ? "网络异常" : e.getMessage());
        }
    }

    /** 创建 JSAPI 支付页订单（工单26 E-14：去支付改 JSAPI 链路）→ pay_url（微信内打开付款） */
    public Resp createPayOrder(String outTradeNo, String description, int fen) {
        if (outTradeNo == null || outTradeNo.trim().isEmpty())
            return Resp.fail("BAD_REQUEST", "out_trade_no 不能为空");
        if (fen <= 0) return Resp.fail("BAD_REQUEST", "金额必须为正整数（分）");
        String body;
        try {
            body = new JSONObject()
                    .put("out_trade_no", outTradeNo.trim())
                    .put("description", description == null ? "" : description)
                    .put("fen", fen)
                    .toString();
        } catch (Exception e) {
            return Resp.fail("INTERNAL", "报文构造失败");
        }
        return exec("POST", "/v1/pay/create", body);
    }

    private Resp exec(String method, String path, String body) {
        try {
            Reply r = http.exec(method, baseUrl + path, token, body);
            return parse(r);
        } catch (IOException e) {
            return Resp.fail("NET", e.getMessage() == null ? "网络异常" : e.getMessage());
        }
    }

    /** 应答解析：2xx → data；否则抽 error.code/msg（后端 {error:{code,msg}} 或微信 {code,message} 两种形态） */
    private Resp parse(Reply r) {
        JSONObject j;
        try {
            j = new JSONObject(r.body == null || r.body.isEmpty() ? "{}" : r.body);
        } catch (Exception e) {
            return Resp.fail("HTTP_" + r.code, "应答非 JSON");
        }
        if (r.code / 100 == 2) return Resp.ok(j);
        JSONObject err = j.optJSONObject("error");
        if (err != null) {
            return Resp.fail(err.optString("code", "HTTP_" + r.code),
                    err.optString("msg", "未知错误"));
        }
        return Resp.fail(j.optString("code", "HTTP_" + r.code),
                j.optString("message", j.optString("msg", "未知错误")));
    }

    static String guessMime(String name) {
        String n = name == null ? "" : name.toLowerCase();
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".bmp")) return "image/bmp";
        return "image/jpeg";   // 微信支持 JPG/BMP/PNG，默认按 JPG
    }

    /** 生产 transport：OkHttp 同步 execute（调用方自行保证不在 UI 线程） */
    public static class OkHttpTransport implements HttpTransport {
        private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
        private final OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();

        @Override public Reply exec(String method, String url, String bearerToken, String jsonBody) throws IOException {
            Request.Builder b = new Request.Builder().url(url)
                    .header("Authorization", "Bearer " + bearerToken)
                    .header("Accept", "application/json");
            if ("POST".equals(method)) {
                b.post(RequestBody.create(jsonBody == null ? "{}" : jsonBody, JSON));
            } else {
                b.get();
            }
            try (Response r = client.newCall(b.build()).execute()) {
                String rb = r.body() != null ? r.body().string() : "";
                return new Reply(r.code(), rb);
            }
        }

        @Override public Reply upload(String url, String bearerToken, String fileName, byte[] data, String mime) throws IOException {
            RequestBody fileBody = RequestBody.create(data, MediaType.get(mime));
            MultipartBody mp = new MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("file", fileName, fileBody)
                    .build();
            Request req = new Request.Builder().url(url)
                    .header("Authorization", "Bearer " + bearerToken)
                    .post(mp)
                    .build();
            try (Response r = client.newCall(req).execute()) {
                String rb = r.body() != null ? r.body().string() : "";
                return new Reply(r.code(), rb);
            }
        }
    }
}
