package com.hermes.android.toolprovider;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.provider.Telephony;
import android.widget.Toast;

import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.agent.ToolRegistry.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * HermesGapProvider — 补齐 Hermes Python 版有但 MOV 缺的工具。
 * 参考: termux/hermes-android/capabilities.py
 */
public class HermesGapProvider implements ToolProvider {

    private static Context appContext;
    public static void init(Context ctx) { appContext = ctx.getApplicationContext(); }

    @Override public String id() { return "hermes-gap"; }

    @Override
    public List<Tool> discover() {
        List<Tool> list = new ArrayList<>();
        if (appContext == null) return list;

        // ═══ screen.capture — 截屏 ═══
        list.add(new Tool("screen.capture",
            "截屏保存到 /sdcard/MOV/screenshots/（通过 screencap 命令）",
            null, a -> {
                try {
                    File dir = new File(Environment.getExternalStorageDirectory(), "MOV/screenshots");
                    dir.mkdirs();
                    String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                    File out = new File(dir, "screenshot_" + ts + ".png");
                    Process p = Runtime.getRuntime().exec(
                        new String[]{"screencap", "-p", out.getAbsolutePath()});
                    p.waitFor();
                    if (out.exists() && out.length() > 0)
                        return new Result(true, out.getAbsolutePath() + " (" + (out.length()/1024) + "KB)",
                            out.getAbsolutePath());
                    return new Result(false, "截屏失败，文件未生成。shell.exec 'screencap -p /sdcard/screenshot.png' 手动执行");
                } catch (Exception e) {
                    return new Result(false, "截屏失败: " + e.getMessage());
                }
            }, "native", "write", "none", true, 15, "media",
            new ParamDef[]{},
            "成功: 文件路径 (大小) | 失败: 错误原因",
            null,
            new String[]{"保存到 /sdcard/MOV/screenshots/", "需要 shell 执行权限"},
            2000,
            new ToolRegistry.Manifest("截屏", "medium", "截取当前屏幕", false, "media"),
            null));

        // ═══ wifi.status — WiFi 连接信息 ═══
        list.add(new Tool("wifi.status",
            "查看当前 WiFi 连接详情（SSID/BSSID/速度/频率/RSSI）",
            null, a -> {
                if (appContext.checkSelfPermission(Manifest.permission.ACCESS_WIFI_STATE) != PackageManager.PERMISSION_GRANTED)
                    return new Result(false, "无 Wi-Fi 权限");
                try {
                    WifiManager wm = (WifiManager) appContext.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    WifiInfo info = wm.getConnectionInfo();
                    JSONObject o = new JSONObject();
                    o.put("ssid", info.getSSID());
                    o.put("bssid", info.getBSSID());
                    o.put("rssi", info.getRssi());
                    o.put("speed", info.getLinkSpeed() + " Mbps");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
                        o.put("frequency", info.getFrequency() + " MHz");
                    o.put("ip", wm.getDhcpInfo() != null ? android.text.format.Formatter.formatIpAddress(wm.getDhcpInfo().ipAddress) : "N/A");
                    return new Result(true, o.toString(2));
                } catch (Exception e) {
                    return new Result(false, "获取 WiFi 信息失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 5, "device",
            new ParamDef[]{},
            "成功: JSON {ssid, bssid, rssi, speed, frequency, ip} | 失败: 错误原因",
            null,
            new String[]{"需要 ACCESS_WIFI_STATE 权限", "WiFi 未连接时 SSID 为 <unknown ssid>"},
            1000,
            new ToolRegistry.Manifest("WiFi 状态", "low", "查看当前连接详情", false, "device"),
            null));

        // ═══ wifi.toggle — 开关 WiFi ═══
        list.add(new Tool("wifi.toggle",
            "开关 WiFi（true=开, false=关）",
            null, a -> {
                String state = a.optString("state", "true");
                boolean enable = "true".equals(state) || "on".equals(state) || "1".equals(state);
                if (appContext.checkSelfPermission(Manifest.permission.CHANGE_WIFI_STATE) != PackageManager.PERMISSION_GRANTED)
                    return new Result(false, "无 CHANGE_WIFI_STATE 权限");
                try {
                    WifiManager wm = (WifiManager) appContext.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    boolean ok = wm.setWifiEnabled(enable);
                    return new Result(ok, ok ? "WiFi 已" + (enable ? "开启" : "关闭") : "操作失败（可能已被系统禁止）");
                } catch (Exception e) {
                    return new Result(false, "操作失败: " + e.getMessage());
                }
            }, "native", "write", "always", false, 10, "device",
            new ParamDef[]{
                new ParamDef("state", "string", true, "true/on/1", "true=开 / false=关"),
            },
            "成功: WiFi 已开启/关闭 | 失败: 错误原因",
            null,
            new String[]{"需要 CHANGE_WIFI_STATE 权限", "Android 10+ 部分厂商禁止应用控制 WiFi"},
            1000,
            new ToolRegistry.Manifest("WiFi 开关", "medium", "开关 WiFi", false, "device"),
            null));

        // ═══ toast — 弹出 Toast ═══
        list.add(new Tool("toast",
            "弹出短暂 Toast 提示（屏幕底部浮动文字，2 秒自动消失）",
            null, a -> {
                String msg = a.optString("message", "");
                if (msg.isEmpty()) return new Result(false, "消息为空");
                // Toast 必须在主线程创建
                final String[] result = {""};
                android.os.Handler mainHandler = new android.os.Handler(android.os.Looper.getMainLooper());
                mainHandler.post(() -> {
                    Toast.makeText(appContext, msg, Toast.LENGTH_SHORT).show();
                    result[0] = "ok";
                });
                try { Thread.sleep(200); } catch (Exception ignored) {}
                return new Result(true, "Toast 已弹出: " + msg);
            }, "native", "write", "none", true, 5, "system",
            new ParamDef[]{
                new ParamDef("message", "string", true, "", "要显示的文字"),
            },
            "成功: Toast 已弹出 | 失败: 错误原因",
            null,
            new String[]{"Toast 在主线程显示，约 2 秒自动消失", "消息过长会被截断（约 50 字）"},
            500,
            new ToolRegistry.Manifest("Toast", "low", "弹出浮动提示", false, "io"),
            null));

        // ═══ camera.info — 相机信息 ═══
        list.add(new Tool("camera.info",
            "列出设备摄像头信息（前后置/分辨率/闪光灯/光圈）",
            null, a -> {
                try {
                    CameraManager cm = (CameraManager) appContext.getSystemService(Context.CAMERA_SERVICE);
                    StringBuilder sb = new StringBuilder();
                    for (String id : cm.getCameraIdList()) {
                        CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                        int facing = cc.get(CameraCharacteristics.LENS_FACING);
                        String face = facing == CameraCharacteristics.LENS_FACING_FRONT ? "前置"
                            : facing == CameraCharacteristics.LENS_FACING_BACK ? "后置" : "外置";
                        Boolean flash = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                        float[] focal = cc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
                        android.util.SizeF sensorSize = cc.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
                        sb.append(face).append(" (").append(id).append(")");
                        if (focal != null && focal.length > 0) sb.append(" 焦距: ").append(String.format("%.1fmm", focal[0]));
                        if (sensorSize != null) sb.append(" 传感器: ").append(String.format("%.1f×%.1fmm", sensorSize.getWidth(), sensorSize.getHeight()));
                        if (flash != null && flash) sb.append(" 📸闪光灯");
                        sb.append("\n");
                    }
                    return new Result(true, sb.toString());
                } catch (Exception e) {
                    return new Result(false, "获取相机信息失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 5, "device",
            new ParamDef[]{},
            "成功: 前置/后置 + 焦距 + 传感器尺寸 | 失败: 错误原因",
            null,
            new String[]{"需要 CAMERA 权限", "部分低端设备信息不完整"},
            1000,
            new ToolRegistry.Manifest("相机信息", "low", "查看摄像头参数", false, "device"),
            null));

        // ═══ sensor.list — 传感器列表 ═══
        list.add(new Tool("sensor.list",
            "列出设备所有传感器（加速度/陀螺仪/光感/磁力/气压等）",
            null, a -> {
                try {
                    SensorManager sm = (SensorManager) appContext.getSystemService(Context.SENSOR_SERVICE);
                    List<Sensor> sensors = sm.getSensorList(Sensor.TYPE_ALL);
                    StringBuilder sb = new StringBuilder("传感器 (" + sensors.size() + "):\n");
                    for (Sensor s : sensors) {
                        sb.append("  ").append(s.getName())
                          .append(" (").append(s.getVendor()).append(")")
                          .append(" 功率:").append(String.format("%.1fmA", s.getPower()))
                          .append(" 分辨率:").append(String.format("%.4f", s.getResolution()))
                          .append("\n");
                    }
                    return new Result(true, sb.toString());
                } catch (Exception e) {
                    return new Result(false, "获取传感器失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 5, "device",
            new ParamDef[]{},
            "成功: 传感器名称 + 厂商 + 功耗 + 分辨率 | 失败: 错误原因",
            null,
            new String[]{"不需要额外权限", "包含硬件和软件传感器"},
            3000,
            new ToolRegistry.Manifest("传感器", "low", "列出所有传感器", false, "device"),
            null));

        // ═══ sms.recent — 最近短信 ═══
        list.add(new Tool("sms.recent",
            "查看最近收到的短信（需要 READ_SMS 权限）",
            null, a -> {
                if (appContext.checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED)
                    return new Result(false, "无 READ_SMS 权限");
                int limit = a.optInt("limit", 5);
                if (limit < 1 || limit > 50) limit = 5;
                try {
                    android.database.Cursor cur = appContext.getContentResolver().query(
                        Telephony.Sms.Inbox.CONTENT_URI,
                        new String[]{Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE},
                        null, null, Telephony.Sms.DATE + " DESC LIMIT " + limit);
                    if (cur == null) return new Result(true, "无短信");
                    SimpleDateFormat tf = new SimpleDateFormat("MM-dd HH:mm", Locale.US);
                    StringBuilder sb = new StringBuilder("最近 " + limit + " 条短信:\n");
                    int n = 0;
                    while (cur.moveToNext()) {
                        sb.append("[").append(tf.format(new Date(cur.getLong(2)))).append("] ")
                          .append(cur.getString(0)).append(": ").append(cur.getString(1)).append("\n");
                        n++;
                    }
                    cur.close();
                    if (n == 0) sb.append("  (空)\n");
                    return new Result(true, sb.toString());
                } catch (Exception e) {
                    return new Result(false, "读取短信失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 10, "message",
            new ParamDef[]{
                new ParamDef("limit", "int", false, "默认 5", "返回条数（1-50）"),
            },
            "成功: [时间] 发件人: 内容 | 失败: 无权限",
            null,
            new String[]{"需要 READ_SMS 权限", "只读不写", "仅读取收件箱"},
            2000,
            new ToolRegistry.Manifest("最近短信", "high", "读取收件箱短信", false, "io"),
            null));

        // ═══ media.play — 播放媒体 ═══
        list.add(new Tool("media.play",
            "播放音频/视频文件（通过系统播放器）",
            null, a -> {
                String path = a.optString("path", "");
                if (path.isEmpty()) return new Result(false, "路径为空");
                try {
                    File f = new File(path);
                    if (!f.exists()) return new Result(false, "文件不存在: " + path);
                    Intent play = new Intent(Intent.ACTION_VIEW);
                    play.setDataAndType(Uri.fromFile(f), "*/*");
                    play.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    appContext.startActivity(play);
                    return new Result(true, "播放器已启动 → " + f.getName());
                } catch (Exception e) {
                    return new Result(false, "播放失败: " + e.getMessage()
                        + "\n备用: shell.exec 'am start -a android.intent.action.VIEW -d file://" + path + " -t */*'");
                }
            }, "native", "write", "none", true, 10, "media",
            new ParamDef[]{
                new ParamDef("path", "string", true, "", "媒体文件绝对路径"),
            },
            "成功: 播放器已启动 | 失败: 错误原因",
            null,
            new String[]{"需要 FileProvider 支持", "支持常见音视频格式", "文件不存在会报错"},
            1000,
            new ToolRegistry.Manifest("播放媒体", "low", "播放音视频文件", false, "media"),
            null));

        // ═══ app.launch — 启动应用 ═══
        list.add(new Tool("app.launch",
            "启动指定应用（通过包名）",
            null, a -> {
                String pkg = a.optString("package", "");
                if (pkg.isEmpty()) return new Result(false, "包名为空");
                // 工单10: 红线黑名单拦截(支付/短信/通讯录/通话记录) — 模型不可绕过
                if (com.hermes.android.toolprovider.RootShell.isDenied(pkg, null)) {
                    return new Result(false, "PERMANENT_DENIED: 命中红线黑名单(支付/短信/通讯录/通话记录)");
                }
                try {
                    Intent launch = appContext.getPackageManager().getLaunchIntentForPackage(pkg);
                    if (launch == null) return new Result(false, "未找到应用: " + pkg + "（可能是系统应用或未安装）");
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    appContext.startActivity(launch);
                    return new Result(true, "已启动: " + pkg);
                } catch (Exception e) {
                    return new Result(false, "启动失败: " + e.getMessage());
                }
            }, "native", "write", "none", true, 10, "app",
            new ParamDef[]{
                new ParamDef("package", "string", true, "", "应用包名，如 com.android.settings"),
            },
            "成功: 已启动 + 包名 | 失败: 未找到/错误",
            null,
            new String[]{"仅支持有启动 Activity 的应用", "用 app.list 查找包名"},
            1000,
            new ToolRegistry.Manifest("启动应用", "medium", "打开指定应用", false, "io"),
            null));

        // ═══ app.stop — 强制停止应用 ═══
        list.add(new Tool("app.stop",
            "强制停止指定应用",
            null, a -> {
                String pkg = a.optString("package", "");
                if (pkg.isEmpty()) return new Result(false, "包名为空");
                try {
                    android.app.ActivityManager am = (android.app.ActivityManager)
                        appContext.getSystemService(Context.ACTIVITY_SERVICE);
                    // 通过 shell 执行 force-stop（Java API 需要系统权限）
                    Process p = Runtime.getRuntime().exec(new String[]{"am", "force-stop", pkg});
                    int exit = p.waitFor();
                    if (exit == 0) return new Result(true, "已停止: " + pkg);
                    return new Result(false, "停止失败 (exit=" + exit + ")，可能无权限或包名错误");
                } catch (Exception e) {
                    return new Result(false, "停止失败: " + e.getMessage());
                }
            }, "native", "write", "always", false, 10, "app",
            new ParamDef[]{
                new ParamDef("package", "string", true, "", "应用包名"),
            },
            "成功: 已停止 + 包名 | 失败: 错误原因",
            null,
            new String[]{"强制停止可能导致未保存数据丢失", "确认前需用户批准"},
            1000,
            new ToolRegistry.Manifest("停止应用", "high", "强制停止应用", false, "io"),
            null));

        // ═══ app.info — 应用详情 ═══
        list.add(new Tool("app.info",
            "查看应用详细信息（版本号/安装时间/更新/权限）",
            null, a -> {
                String pkg = a.optString("package", "");
                if (pkg.isEmpty()) return new Result(false, "包名为空");
                try {
                    PackageManager pm = appContext.getPackageManager();
                    android.content.pm.PackageInfo pi = pm.getPackageInfo(pkg,
                        PackageManager.GET_PERMISSIONS);
                    JSONObject o = new JSONObject();
                    o.put("package", pi.packageName);
                    o.put("versionName", pi.versionName);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
                        o.put("versionCode", pi.getLongVersionCode());
                    else o.put("versionCode", pi.versionCode);
                    o.put("firstInstall", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
                        .format(new Date(pi.firstInstallTime)));
                    o.put("lastUpdate", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
                        .format(new Date(pi.lastUpdateTime)));
                    if (pi.requestedPermissions != null) {
                        JSONArray perms = new JSONArray();
                        for (String p : pi.requestedPermissions) perms.put(p);
                        o.put("permissions", perms);
                    }
                    return new Result(true, o.toString(2));
                } catch (PackageManager.NameNotFoundException e) {
                    return new Result(false, "未找到应用: " + pkg);
                } catch (Exception e) {
                    return new Result(false, "获取失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 5, "app",
            new ParamDef[]{
                new ParamDef("package", "string", true, "", "应用包名"),
            },
            "成功: JSON 详情 | 失败: 未找到/错误",
            null,
            new String[]{"用 app.list 获取包名列表", "返回 versionName/versionCode/firstInstall/lastUpdate/permissions"},
            2000,
            new ToolRegistry.Manifest("应用详情", "low", "查看应用版本和权限", false, "io"),
            null));

        // ═══ settings.get — 读取系统设置 ═══
        list.add(new Tool("settings.get",
            "读取系统设置项（system/global/secure 命名空间）",
            null, a -> {
                String ns = a.optString("namespace", "system");
                String key = a.optString("key", "");
                if (key.isEmpty()) return new Result(false, "key 为空");
                if (!"system".equals(ns) && !"global".equals(ns) && !"secure".equals(ns))
                    return new Result(false, "namespace 必须是 system/global/secure");
                try {
                    String val;
                    switch (ns) {
                        case "global": val = Settings.Global.getString(appContext.getContentResolver(), key); break;
                        case "secure": val = Settings.Secure.getString(appContext.getContentResolver(), key); break;
                        default: val = Settings.System.getString(appContext.getContentResolver(), key); break;
                    }
                    if (val == null) return new Result(true, ns + "." + key + " = (未设置)");
                    return new Result(true, ns + "." + key + " = " + val);
                } catch (Exception e) {
                    return new Result(false, "读取失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 3, "system",
            new ParamDef[]{
                new ParamDef("namespace", "string", false, "默认 system", "system / global / secure"),
                new ParamDef("key", "string", true, "", "设置项 key，如 screen_brightness"),
            },
            "成功: namespace.key = value | 失败: 错误原因",
            null,
            new String[]{"不需要 WRITE_SETTINGS 权限（只读）", "常见 key: screen_brightness, sound_effects_enabled, airplane_mode_on"},
            500,
            new ToolRegistry.Manifest("系统设置", "low", "读取系统设置值", false, "io"),
            null));

        return list;
    }
}
