package com.hermes.android.pay;

import org.json.JSONObject;

import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 微信支付 API v3 客户端（工单26 M1-2）——只调两个接口：
 *   POST /v3/pay/transactions/native                      Native 下单 → code_url
 *   GET  /v3/pay/transactions/out-trade-no/{id}?mchid=…   查单 → trade_state
 *
 * 无资金池、不代收、不分账。notify_url 微信必填但不启回调（占位 https URL）。
 * 单测零网络：HttpTransport 接口化，生产 = OkHttpTransport，测试 = 队列假回包。
 */
public class WxPayClient {

    public static final String BASE = "https://api.mch.weixin.qq.com";

    /** 传输抽象：生产 OkHttp、测试 fake 回包队列 */
    public interface HttpTransport {
        Reply exec(String method, String url, String auth, String body) throws IOException;
    }

    public static class Reply {
        public final int code;
        public final String body;
        public Reply(int code, String body) { this.code = code; this.body = body; }
    }

    /** 回调（内部线程执行；桥侧再转 cbId 异步） */
    public interface Cb<T> {
        void ok(T v);
        void fail(String code, String msg);
    }

    private final MerchantCreds creds;
    private final HttpTransport http;

    /** 测试注入 fake transport */
    public WxPayClient(MerchantCreds c, HttpTransport h) { creds = c; http = h; }

    /** Native 下单 → code_url（回调在内部线程）。E-12：body 必须带 appid（缺省微信直接报错，PC 已实测） */
    public void nativeCreateOrder(String desc, String outTradeNo, int fen, String attach, Cb<String> cb) {
        String path = "/v3/pay/transactions/native";
        String body = "{\"mchid\":\"" + creds.mchid + "\",\"appid\":\"" + creds.appid + "\","
                + "\"description\":\"" + esc(desc) + "\","
                + "\"out_trade_no\":\"" + outTradeNo + "\","
                + "\"notify_url\":\"https://mow.kim/wxpay/notify\","
                + "\"attach\":\"" + esc(attach) + "\","
                + "\"amount\":{\"total\":" + fen + ",\"currency\":\"CNY\"}}";
        exec("POST", BASE + path, path, body, new Cb<JSONObject>() {
            @Override public void ok(JSONObject j) { cb.ok(j.optString("code_url")); }
            @Override public void fail(String c, String m) { cb.fail(c, m); }
        });
    }

    /** 查单 → trade_state ∈ SUCCESS/NOTPAY/USERPAYING/PAYERROR/CLOSED/REFUND… */
    public void queryByOutTradeNo(String outTradeNo, Cb<JSONObject> cb) {
        String path = "/v3/pay/transactions/out-trade-no/" + outTradeNo + "?mchid=" + creds.mchid;
        exec("GET", BASE + path, path, null, cb);
    }

    private void exec(String method, String url, String path, String body, Cb<JSONObject> cb) {
        new Thread(() -> {
            try {
                long ts = System.currentTimeMillis() / 1000;
                String nonce = UUID.randomUUID().toString().replace("-", "");
                String auth = WxPaySigner.authHeader(creds.mchid, creds.serialNo,
                        WxPaySigner.sign(creds.privateKey, method, path, ts, nonce, body), ts, nonce);
                Reply r = http.exec(method, url, auth, body);
                JSONObject j = new JSONObject(r.body);
                if (r.code / 100 == 2) {
                    cb.ok(j);
                } else {
                    cb.fail(j.optString("code", "HTTP_" + r.code), j.optString("message", "未知错误"));
                }
            } catch (Exception e) {
                cb.fail("NET", e.getMessage() == null ? "网络异常" : e.getMessage());
            }
        }, "wxpay-exec").start();
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    /** 生产 transport：OkHttp 同步 execute（A2aClient 同款依赖） */
    public static class OkHttpTransport implements HttpTransport {
        private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
        private final OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .build();

        @Override public Reply exec(String method, String url, String auth, String body) throws IOException {
            Request.Builder b = new Request.Builder().url(url).header("Authorization", auth)
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json");
            if ("POST".equals(method)) b.post(RequestBody.create(body == null ? "" : body, JSON));
            else b.get();
            try (Response r = client.newCall(b.build()).execute()) {
                String rb = r.body() != null ? r.body().string() : "";
                return new Reply(r.code(), rb);
            }
        }
    }
}
