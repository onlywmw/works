package com.hermes.android.workflow;

/**
 * Workflow 触发事件 — 页面事件注入引擎（纯 JVM，无 Android/WebView 依赖）。
 *
 * 事件源（ConnectWeb WebView 集成时）注入：
 * - PAGE_LOAD：页面加载完成（url）
 * - URL_CHANGE：地址变化（url）
 * - ELEMENT_APPEAR：元素出现（selector + url）
 * - TEXT_MATCH：页面文本变化（text + url）
 * - TICK：定时心跳（interval 触发器用，由调用方按节拍注入）
 */
public class WorkflowEvent {

    public enum Type {
        PAGE_LOAD, URL_CHANGE, ELEMENT_APPEAR, TEXT_MATCH, TICK,
        // 设备事件触发器族（第一幕：亮灭屏/电源/电池阈值/耳机/wifi/bt）
        SCREEN_ON, SCREEN_OFF, POWER_CONNECTED, POWER_DISCONNECTED,
        BATTERY_BELOW, BATTERY_ABOVE, HEADPHONES_PLUGGED, HEADPHONES_UNPLUGGED,
        WIFI_CONNECTED, WIFI_DISCONNECTED, BT_CONNECTED, BT_DISCONNECTED,
        // 第二幕：time_cron（WorkManager 周期触发检查）/ manual（Run now）/ boot
        MANUAL, BOOT_COMPLETED
    }

    public final Type type;
    public final String url;
    public final String text;
    public final String selector;
    public final long timestampMs;

    private WorkflowEvent(Type type, String url, String text, String selector, long timestampMs) {
        this.type = type;
        this.url = url;
        this.text = text;
        this.selector = selector;
        this.timestampMs = timestampMs;
    }

    public static WorkflowEvent of(Type type, long now) {
        return new WorkflowEvent(type, null, null, null, now);
    }
    public static WorkflowEvent urlChange(String url, long now) {
        return new WorkflowEvent(Type.URL_CHANGE, url, null, null, now);
    }
    public static WorkflowEvent pageLoad(String url, long now) {
        return new WorkflowEvent(Type.PAGE_LOAD, url, null, null, now);
    }
    public static WorkflowEvent elementAppear(String selector, String url, long now) {
        return new WorkflowEvent(Type.ELEMENT_APPEAR, url, null, selector, now);
    }
    public static WorkflowEvent textMatch(String text, String url, long now) {
        return new WorkflowEvent(Type.TEXT_MATCH, url, text, null, now);
    }
    public static WorkflowEvent device(Type type, long now) {
        return new WorkflowEvent(type, null, null, null, now);
    }
}
