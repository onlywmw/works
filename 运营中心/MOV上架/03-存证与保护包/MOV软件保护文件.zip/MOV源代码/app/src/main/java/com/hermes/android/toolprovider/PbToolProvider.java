package com.hermes.android.toolprovider;

import android.content.Context;
import android.content.SharedPreferences;

import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.agent.ToolRegistry.*;
import com.hermes.android.linux.ProotRunner;
import com.hermes.android.linux.RootfsManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * PbToolProvider — PocketBase 本地后端工具组（MCP 工厂首品种 REQ-20260807-001）。
 *
 * 五个工具：pb.start / pb.query / pb.create / pb.update / pb.auth。
 * PocketBase 单二进制跑在内嵌 Ubuntu（proot）里，绑 127.0.0.1:8090；
 * 数据目录 filesDir/linux/pb_data（升级不丢）。
 * 设计要点：
 *  - 零配置即用：pb.start 自动 upsert superuser；集合不存在时自动建（开放规则，仅本机）
 *  - 单测零网络：HTTP 走 Transport 接口，测试注入假传输（构造函数注入数据，解析 package-private）
 */
public class PbToolProvider implements ToolProvider {

    public static final int PB_PORT = 8090;

    private static Context appContext;
    public static void init(Context ctx) { appContext = ctx.getApplicationContext(); }

    @Override public String id() { return "pb"; }

    // ==================== HTTP 传输（可注入，单测零网络） ====================

    public interface Transport {
        /** @return JSON 信封字符串 {"ok":bool,"status":int,"body":"..."} */
        String request(String method, String path, String token, String jsonBody) throws Exception;
    }

    /** 真机传输：HttpURLConnection 打 127.0.0.1:8090 */
    static Transport httpTransport() {
        return (method, path, token, jsonBody) -> {
            java.net.HttpURLConnection c = (java.net.HttpURLConnection)
                    new java.net.URL("http://127.0.0.1:" + PB_PORT + path).openConnection();
            c.setConnectTimeout(5000);
            c.setReadTimeout(15000);
            c.setRequestMethod(method);
            c.setRequestProperty("Content-Type", "application/json");
            if (token != null) c.setRequestProperty("Authorization", token);
            if (jsonBody != null) {
                c.setDoOutput(true);
                c.getOutputStream().write(jsonBody.getBytes("UTF-8"));
            }
            int code = c.getResponseCode();
            java.io.InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
            StringBuilder sb = new StringBuilder();
            if (is != null) {
                java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(is, "UTF-8"));
                String line; while ((line = r.readLine()) != null) sb.append(line);
            }
            return new JSONObject().put("ok", code < 400).put("status", code)
                    .put("body", sb.toString()).toString();
        };
    }

    // ==================== PbClient（可测核心） ====================

    public static class PbClient {
        private final Transport transport;
        private final String identity;
        private final String password;
        private String token;   // superuser token（内存缓存）

        /** 生产用：凭据从私有 prefs 取 */
        public PbClient(Transport transport) { this(transport, null, null); }
        /** 测试用：构造函数注入凭据（单测零 Android 依赖） */
        public PbClient(Transport transport, String identity, String password) {
            this.transport = transport;
            this.identity = identity != null ? identity : adminIdentity();
            this.password = password != null ? password : adminPassword();
        }

        /** 健康检查：PB 是否在跑 */
        public boolean health() {
            try {
                JSONObject r = new JSONObject(transport.request("GET", "/api/health", null, null));
                return r.optBoolean("ok") && r.optString("body").contains("\"code\":200");
            } catch (Exception e) { return false; }
        }

        /** superuser 登录（缓存 token） */
        public synchronized String ensureToken(String identity, String password) {
            if (token != null) return token;
            try {
                JSONObject r = new JSONObject(transport.request("POST",
                        "/api/collections/_superusers/auth-with-password", null,
                        new JSONObject().put("identity", identity).put("password", password).toString()));
                if (r.optBoolean("ok")) {
                    JSONObject body = new JSONObject(r.optString("body"));
                    token = body.optString("token", null);
                    return token;
                }
            } catch (Exception ignored) {}
            return null;
        }

        /** 查询记录：返回 records JSON 数组文本 */
        public String query(String collection, String filter, String sort, int perPage) {
            try {
                StringBuilder path = new StringBuilder("/api/collections/")
                        .append(enc(collection)).append("/records?perPage=").append(Math.min(Math.max(perPage, 1), 100));
                if (filter != null && !filter.isEmpty()) path.append("&filter=").append(enc(filter));
                if (sort != null && !sort.isEmpty()) path.append("&sort=").append(enc(sort));
                JSONObject r = new JSONObject(transport.request("GET", path.toString(), null, null));
                if (!r.optBoolean("ok")) return errJson("PB_" + r.optInt("status"), r.optString("body"));
                JSONObject body = new JSONObject(r.optString("body"));
                JSONArray items = body.optJSONArray("items");
                return new JSONObject().put("ok", true)
                        .put("items", items != null ? items : new JSONArray())
                        .put("totalItems", body.optInt("totalItems", 0)).toString();
            } catch (Exception e) { return errJson("PB_IO", e.getMessage()); }
        }

        /** 创建记录；集合不存在 → 自动建（开放规则，仅本机服务） */
        public String create(String collection, String jsonData) {
            try {
                JSONObject r = new JSONObject(transport.request("POST",
                        "/api/collections/" + enc(collection) + "/records", null, jsonData));
                if (r.optBoolean("ok")) return okWrap(r.optString("body"));
                if (r.optInt("status") == 404 || r.optInt("status") == 400) {
                    String ns = autoCreateCollection(collection);
                    if (ns == null) return errJson("PB_AUTOCOL", "集合不存在且自动创建失败");
                    JSONObject r2 = new JSONObject(transport.request("POST",
                            "/api/collections/" + enc(collection) + "/records", null, jsonData));
                    if (r2.optBoolean("ok")) return okWrap(r2.optString("body"));
                    return errJson("PB_" + r2.optInt("status"), r2.optString("body"));
                }
                return errJson("PB_" + r.optInt("status"), r.optString("body"));
            } catch (Exception e) { return errJson("PB_IO", e.getMessage()); }
        }

        /** 更新记录 */
        public String update(String collection, String recordId, String jsonData) {
            try {
                JSONObject r = new JSONObject(transport.request("PATCH",
                        "/api/collections/" + enc(collection) + "/records/" + enc(recordId), null, jsonData));
                if (r.optBoolean("ok")) return okWrap(r.optString("body"));
                return errJson("PB_" + r.optInt("status"), r.optString("body"));
            } catch (Exception e) { return errJson("PB_IO", e.getMessage()); }
        }

        /** 认证：集合用户 auth-with-password（data: {identity, password}） */
        public String auth(String collection, String identity, String password) {
            try {
                JSONObject r = new JSONObject(transport.request("POST",
                        "/api/collections/" + enc(collection) + "/auth-with-password", null,
                        new JSONObject().put("identity", identity).put("password", password).toString()));
                if (r.optBoolean("ok")) return okWrap(r.optString("body"));
                return errJson("PB_AUTH", r.optString("body"));
            } catch (Exception e) { return errJson("PB_IO", e.getMessage()); }
        }

        /** 自动建集合（通用文本字段 data + 全开放规则——服务只绑 127.0.0.1） */
        private String autoCreateCollection(String name) {
            String token = ensureToken(identity, password);
            if (token == null) return null;
            try {
                JSONObject field = new JSONObject().put("name", "data").put("type", "text");
                JSONObject col = new JSONObject()
                        .put("name", name).put("type", "base")
                        .put("fields", new JSONArray().put(field))
                        .put("listRule", "").put("viewRule", "")
                        .put("createRule", "").put("updateRule", "").put("deleteRule", "");
                JSONObject r = new JSONObject(transport.request("POST", "/api/collections", token, col.toString()));
                return r.optBoolean("ok") ? name : null;
            } catch (Exception e) { return null; }
        }

        static String okWrap(String body) {
            try { return new JSONObject().put("ok", true).put("data", new JSONObject(body)).toString(); }
            catch (Exception e) { return errJson("PB_PARSE", body); }
        }
        static String errJson(String code, String msg) {
            try { return new JSONObject().put("ok", false)
                    .put("error", new JSONObject().put("code", code).put("msg", msg == null ? "" : msg)).toString(); }
            catch (Exception e) { return "{\"ok\":false}"; }
        }
        static String enc(String s) {
            try { return java.net.URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; }
        }
    }

    // ==================== superuser 凭据（本地生成，私有 prefs） ====================

    private static final String PREFS = "pb_local";
    static String adminIdentity() { return "mov@local.host"; }   /* PB 校验邮箱格式：必须有 TLD（真机实证 mov@local 被拒） */
    static String adminPassword() {
        if (appContext == null) return "test-only";   // 单测环境占位（生产必有 context）
        SharedPreferences sp = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String pwd = sp.getString("sup", null);
        if (pwd == null) {
            pwd = java.util.UUID.randomUUID().toString().replace("-", "");
            sp.edit().putString("sup", pwd).apply();
        }
        return pwd;
    }

    // ==================== 启动/部署 ====================
    /* proot 挂载纪律（真机实证）：proot 内看不到 Android 侧 filesDir 路径——
       二进制必须放 rootfs 内（usr/local/bin），数据目录同理（/root/pb_data，
       落盘即 filesDir/linux/rootfs/root/pb_data，升级不丢）。 */

    /** proot 内固定路径 */
    static final String PB_BIN_IN_PROOT = "/usr/local/bin/pocketbase";
    static final String PB_DATA_IN_PROOT = "/root/pb_data";

    static File rootfsDir() { return new RootfsManager(appContext).rootfsDir(); }
    static File pbBinaryHost() { return new File(rootfsDir(), "usr/local/bin/pocketbase"); }

    /** 部署状态检查（checkFn 用）：二进制在 rootfs + rootfs 就绪 */
    public static String deployStatus(Context ctx) {
        if (appContext == null) return "context 未初始化";
        if (!new RootfsManager(ctx).isReady()) return "内嵌 Linux 未就绪";
        if (!pbBinaryHost().exists()) return "PocketBase 未部署（rootfs/usr/local/bin/pocketbase 缺二进制）";
        return null;
    }

    /** 启动：healthz → 已在跑直接回；否则 startDaemon 拉起 + superuser upsert 幂等 */
    String start() {
        String notReady = deployStatus(appContext);
        if (notReady != null) return PbClient.errJson("NOT_READY", notReady);
        PbClient client = new PbClient(httpTransport());
        if (client.health()) {
            return okJson("already running", PB_PORT);
        }
        try {
            new File(rootfsDir(), "root/pb_data").mkdirs();
            String cmd = PB_BIN_IN_PROOT + " serve --http=127.0.0.1:" + PB_PORT
                    + " --dir=" + PB_DATA_IN_PROOT;
            ProotRunner.startDaemon(appContext, cmd, null);
            /* 等就绪（最多 10s） */
            for (int i = 0; i < 20; i++) {
                Thread.sleep(500);
                if (client.health()) {
                    /* superuser upsert 幂等（已存在则更新密码为 prefs 里的） */
                    ProotRunner.ExecResult up = ProotRunner.exec(appContext,
                            PB_BIN_IN_PROOT + " superuser upsert "
                                    + adminIdentity() + " " + adminPassword()
                                    + " --dir=" + PB_DATA_IN_PROOT, 30);
                    /* PB 的 upsert 打 Error 也 exit=0（真机实证）——必须看输出 */
                    if (up.stdout != null && up.stdout.contains("Error")) {
                        return PbClient.errJson("SUPERUSER_FAIL", up.stdout.trim());
                    }
                    return okJson("started (superuser 就绪)", PB_PORT);
                }
            }
            return PbClient.errJson("START_TIMEOUT", "PocketBase 启动 10s 未就绪");
        } catch (Exception e) {
            return PbClient.errJson("START_FAIL", e.getMessage());
        }
    }

    static String okJson(String msg, int port) {
        try {
            return new JSONObject().put("ok", true).put("data",
                    new JSONObject().put("msg", msg).put("port", port)
                            .put("adminUi", "http://127.0.0.1:" + port + "/_/")).toString();
        } catch (Exception e) { return "{\"ok\":false}"; }
    }

    // ==================== 工具注册 ====================

    @Override
    public List<Tool> discover() {
        List<Tool> list = new ArrayList<>();
        if (appContext == null) return list;

        list.add(new Tool("pb.start",
                "启动本地 PocketBase 后端（内嵌 Linux 里，绑 127.0.0.1:8090）。首次自动建管理员；数据升级不丢。用 pb.* 前先调它",
                null, a -> {
                    String r = start();
                    try {
                        org.json.JSONObject rj = new org.json.JSONObject(r);
                        boolean ok = rj.optBoolean("ok", false);
                        return new Result(ok, rj.has("data") ? rj.getString("data") : r,
                                null, ok ? null : "pb.start 失败",
                                ok ? null : (rj.has("error") ? rj.getJSONObject("error").optString("msg") : r));
                    } catch (Exception e) {
                        return new Result(false, "pb.start 回包解析失败: " + r);
                    }
                },
                "linux", "write", "plan", false, 60,
                "pb", new ParamDef[0],
                "成功: {ok, data:{msg, port, adminUi}} | 失败: {ok:false, error:{code,msg}}",
                new String[]{"{\"action\":\"tool.execute\",\"name\":\"pb.start\",\"args\":{}}"},
                new String[]{"NOT_READY=二进制未部署或 Linux 未就绪——先部署", "已启动时幂等返回 already running"},
                8000, new Manifest("启动本地数据库后端", "high", "在内嵌 Linux 启动常驻服务", false, "exec"),
                () -> deployStatus(appContext)));

        list.add(new Tool("pb.query",
                "查询本地数据库集合的记录（PocketBase）。支持 filter/sort/perPage",
                null, a -> {
                    String col = a.optString("collection");
                    if (col.isEmpty()) return new Result(false, "collection 为空");
                    return new Result(true, new PbClient(httpTransport()).query(col,
                            a.optString("filter", ""), a.optString("sort", ""), a.optInt("perPage", 30)));
                },
                "linux", "readonly", "none", true, 30,
                "pb", new ParamDef[]{
                        new ParamDef("collection", "string", true, "", "集合名（如 todos）"),
                        new ParamDef("filter", "string", false, "", "PB filter 语法，如 title~'牛奶'"),
                        new ParamDef("sort", "string", false, "", "排序，如 -created"),
                        new ParamDef("perPage", "int", false, "30", "每页条数（≤100）"),
                },
                "{ok, items:[...], totalItems} | 失败错误信封",
                new String[]{"{\"action\":\"tool.execute\",\"name\":\"pb.query\",\"args\":{\"collection\":\"todos\"}}"},
                new String[]{"用前确保 pb.start 已启动", "集合不存在返回空或 404 信封——先用 pb.create 建过才有"},
                8000, new Manifest("查询本地数据库", "low", "只读查询", false, "query"),
                () -> deployStatus(appContext)));

        list.add(new Tool("pb.create",
                "在本地数据库集合里创建一条记录（PocketBase）。集合不存在会自动创建（开放规则，仅本机服务）",
                null, a -> {
                    String col = a.optString("collection");
                    String data = a.optString("data");
                    if (col.isEmpty() || data.isEmpty()) return new Result(false, "collection/data 为空");
                    return new Result(true, new PbClient(httpTransport()).create(col, data));
                },
                "linux", "write", "plan", false, 30,
                "pb", new ParamDef[]{
                        new ParamDef("collection", "string", true, "", "集合名"),
                        new ParamDef("data", "string", true, "", "记录 JSON，如 {\"title\":\"买牛奶\"}"),
                },
                "{ok, data:{id,...}} | 失败错误信封",
                new String[]{"{\"action\":\"tool.execute\",\"name\":\"pb.create\",\"args\":{\"collection\":\"todos\",\"data\":\"{\\\"title\\\":\\\"买牛奶\\\"}\"}}"},
                new String[]{"集合不存在会自动建（通用 data 文本字段）", "用前确保 pb.start 已启动"},
                8000, new Manifest("写入本地数据库", "high", "创建数据库记录", false, "exec"),
                () -> deployStatus(appContext)));

        list.add(new Tool("pb.update",
                "更新本地数据库记录（PocketBase）。按集合+记录 id 更新字段",
                null, a -> {
                    String col = a.optString("collection");
                    String id = a.optString("id");
                    String data = a.optString("data");
                    if (col.isEmpty() || id.isEmpty() || data.isEmpty()) return new Result(false, "collection/id/data 为空");
                    return new Result(true, new PbClient(httpTransport()).update(col, id, data));
                },
                "linux", "write", "plan", false, 30,
                "pb", new ParamDef[]{
                        new ParamDef("collection", "string", true, "", "集合名"),
                        new ParamDef("id", "string", true, "", "记录 id（pb.query 可得）"),
                        new ParamDef("data", "string", true, "", "要更新的字段 JSON"),
                },
                "{ok, data:{id,...}} | 失败错误信封",
                new String[]{"{\"action\":\"tool.execute\",\"name\":\"pb.update\",\"args\":{\"collection\":\"todos\",\"id\":\"abc123\",\"data\":\"{\\\"done\\\":true}\"}}"},
                new String[]{"id 先用 pb.query 查", "用前确保 pb.start 已启动"},
                8000, new Manifest("更新本地数据库", "high", "修改数据库记录", false, "exec"),
                () -> deployStatus(appContext)));

        list.add(new Tool("pb.auth",
                "本地数据库用户认证（PocketBase auth-with-password）。identity+password 换 token",
                null, a -> {
                    String col = a.optString("collection", "users");
                    String identity = a.optString("identity");
                    String password = a.optString("password");
                    if (identity.isEmpty() || password.isEmpty()) return new Result(false, "identity/password 为空");
                    return new Result(true, new PbClient(httpTransport()).auth(col, identity, password));
                },
                "linux", "write", "plan", false, 30,
                "pb", new ParamDef[]{
                        new ParamDef("collection", "string", false, "users", "认证集合（默认 users）"),
                        new ParamDef("identity", "string", true, "", "用户名/邮箱"),
                        new ParamDef("password", "string", true, "", "密码"),
                },
                "{ok, data:{token, record}} | 失败错误信封",
                new String[]{"{\"action\":\"tool.execute\",\"name\":\"pb.auth\",\"args\":{\"identity\":\"me\",\"password\":\"xxx\"}}"},
                new String[]{"用前确保 pb.start 已启动", "密码参数走 PII 打码闸出网规则"},
                8000, new Manifest("本地数据库认证", "high", "用户登录换 token", false, "exec"),
                () -> deployStatus(appContext)));

        return list;
    }
}
