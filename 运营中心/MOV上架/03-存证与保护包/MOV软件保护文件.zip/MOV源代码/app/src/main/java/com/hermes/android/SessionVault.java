package com.hermes.android;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.webkit.CookieManager;

/**
 * 会话保险库（SessionVault）— CookieManager.flush 定时+生命周期持久化。
 * force-stop 后登录态不丢。
 */
public class SessionVault {

    private static final String TAG = "SessionVault";
    private static SessionVault instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable flushTask;
    private boolean running;

    public static synchronized SessionVault get() {
        if (instance == null) instance = new SessionVault();
        return instance;
    }

    /** 启动定时 flush（每 30s + 前台） */
    public void start() {
        if (running) return;
        running = true;
        CookieManager.getInstance().setAcceptCookie(true);
        flushTask = new Runnable() {
            @Override public void run() {
                try { CookieManager.getInstance().flush(); }
                catch (Exception e) { try { Log.w(TAG, "flush err"); } catch (Exception ignored) {} }
                if (running) handler.postDelayed(this, 30000);
            }
        };
        handler.post(flushTask);
    }

    /** onPause 立即 flush 一次 */
    public void onPause() {
        try { CookieManager.getInstance().flush(); } catch (Exception ignored) {}
    }

    public void stop() {
        running = false;
        if (flushTask != null) handler.removeCallbacks(flushTask);
    }
}
