package com.hermes.android.browser;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 站点规则引擎（Phase P1 R3-3a）。
 *
 * 从 assets/site_rules.json 加载 per-site 规则：
 * - UA 覆盖（桌面 UA 防移动端重定向）
 * - scheme 拦截（intent:// / tenvideo2:// 等强制跳 App 协议）
 * - afterLoad 脚本（搜索页自动切 tab 等，每脚本可限制 urlPattern）
 *
 * 规则热编辑：debug build 每次重读 mtime；release 缓存。
 * filesDir 优先（覆盖 assets 默认值，不重编译即可改规则）。
 */
public class SiteRuleEngine {

    private static final String TAG = "SiteRuleEngine";
    private static final String RULES_FILE = "site_rules.json";
    private static final String FALLBACK_JSON = "[]";

    private final Context ctx;
    private List<SiteRule> rules = Collections.emptyList();
    private long lastMtime;
    private boolean isDebug;

    public SiteRuleEngine(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        try {
            isDebug = (ctx.getApplicationInfo().flags
                    & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        } catch (Exception ignored) {}
    }

    /** 站点规则 */
    public static class SiteRule {
        public final String domain;
        public final String desc;
        public final String ua;                 // 空字符串 = 不覆盖
        public final List<String> blockSchemes;
        public final List<AfterLoadScript> afterLoad;

        public SiteRule(String domain, String desc, String ua,
                        List<String> blockSchemes, List<AfterLoadScript> afterLoad) {
            this.domain = domain;
            this.desc = desc;
            this.ua = ua != null ? ua : "";
            this.blockSchemes = blockSchemes != null ? blockSchemes : Collections.emptyList();
            this.afterLoad = afterLoad != null ? afterLoad : Collections.emptyList();
        }
    }

    /** afterLoad 脚本 */
    public static class AfterLoadScript {
        public final String desc;
        public final String urlPattern;  // 空 = 所有页都注入
        public final String script;

        public AfterLoadScript(String desc, String urlPattern, String script) {
            this.desc = desc;
            this.urlPattern = urlPattern != null ? urlPattern : "";
            this.script = script != null ? script : "";
        }
    }

    /** 加载规则（debug 每次检查 mtime，release 缓存） */
    public List<SiteRule> loadRules() {
        File filesDirFile = new File(ctx.getFilesDir(), RULES_FILE);
        long mtime = filesDirFile.exists() ? filesDirFile.lastModified() : 0;
        if (!isDebug && !rules.isEmpty() && mtime == lastMtime) return rules;

        String json = readFile(filesDirFile);
        if (json == null) {
            // filesDir 无 → 读 assets 默认
            json = readAssets(RULES_FILE);
        }
        if (json == null) json = FALLBACK_JSON;

        try {
            JSONArray arr = new JSONArray(json);
            List<SiteRule> parsed = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String domain = o.optString("domain", "");
                String desc = o.optString("desc", "");
                String ua = o.optString("ua", "");

                JSONArray schemes = o.optJSONArray("blockSchemes");
                List<String> blockSchemes = new ArrayList<>();
                if (schemes != null) {
                    for (int j = 0; j < schemes.length(); j++) {
                        blockSchemes.add(schemes.optString(j, ""));
                    }
                }

                JSONArray scripts = o.optJSONArray("afterLoad");
                List<AfterLoadScript> afterLoad = new ArrayList<>();
                if (scripts != null) {
                    for (int j = 0; j < scripts.length(); j++) {
                        JSONObject s = scripts.getJSONObject(j);
                        afterLoad.add(new AfterLoadScript(
                                s.optString("desc", ""),
                                s.optString("urlPattern", ""),
                                s.optString("script", "")));
                    }
                }
                parsed.add(new SiteRule(domain, desc, ua, blockSchemes, afterLoad));
            }
            rules = parsed;
            lastMtime = mtime;
            Log.d(TAG, "Loaded " + rules.size() + " site rules");
        } catch (Exception e) {
            Log.w(TAG, "Failed to parse site_rules.json: " + e.getMessage());
        }
        return rules;
    }

    /** 按 URL 匹配规则（最长 domain 匹配优先） */
    public SiteRule match(String url) {
        if (url == null || url.isEmpty()) return null;
        String host = extractHost(url);
        if (host == null) return null;

        loadRules();
        SiteRule best = null;
        int bestLen = 0;
        for (SiteRule r : rules) {
            if (host.equals(r.domain) || host.endsWith("." + r.domain)) {
                if (r.domain.length() > bestLen) {
                    best = r;
                    bestLen = r.domain.length();
                }
            }
        }
        return best;
    }

    /** 检查 URL scheme 是否应被拦截（仅检查当前页面匹配的站点规则，非全局扫描） */
    public boolean shouldBlockScheme(String requestUrl, String currentPageUrl) {
        if (requestUrl == null) return false;
        String scheme = extractScheme(requestUrl);
        if (scheme == null) return false;

        SiteRule rule = match(currentPageUrl);
        if (rule == null) return false;
        for (String bs : rule.blockSchemes) {
            if (scheme.equals(bs) || scheme.equals(bs.replace("://", ""))) {
                return true;
            }
        }
        return false;
    }

    /** 获取 UA 覆盖（null = 不覆盖） */
    public String getUAOverride(String url) {
        SiteRule r = match(url);
        if (r != null && !r.ua.isEmpty()) return r.ua;
        return null;
    }

    /** 获取 afterLoad 脚本（匹配 urlPattern 的） */
    public List<AfterLoadScript> getAfterLoadScripts(String url) {
        SiteRule r = match(url);
        if (r == null || r.afterLoad.isEmpty()) return Collections.emptyList();

        List<AfterLoadScript> matched = new ArrayList<>();
        for (AfterLoadScript s : r.afterLoad) {
            if (s.urlPattern.isEmpty() || url.contains(s.urlPattern)) {
                matched.add(s);
            }
        }
        return matched;
    }

    // ==================== utils ====================

    private static String extractHost(String url) {
        try {
            URI uri = new URI(url);
            String host = uri.getHost();
            if (host != null) return host;
        } catch (Exception ignored) {}
        // 简单正则兜底
        int start = url.indexOf("://");
        if (start < 0) return null;
        int end = url.indexOf("/", start + 3);
        if (end < 0) end = url.length();
        return url.substring(start + 3, end);
    }

    private static String extractScheme(String url) {
        int colon = url.indexOf(':');
        if (colon < 0) return null;
        return url.substring(0, colon);
    }

    private String readFile(File f) {
        if (!f.exists()) return null;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                new FileInputStream(f), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private String readAssets(String path) {
        try (InputStream is = ctx.getAssets().open(path)) {
            BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
}
