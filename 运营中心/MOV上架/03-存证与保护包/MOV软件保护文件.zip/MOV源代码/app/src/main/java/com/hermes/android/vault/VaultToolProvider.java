package com.hermes.android.vault;

import com.hermes.android.HermesActivity;
import com.hermes.android.agent.ToolRegistry;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * vault 工具提供者（DESIGN_OCR_MOBILE v2 §六纪律 5）：
 *   vault_lock   = ACTION（审批闸）— 加密落盘前弹 Keyguard
 *   vault_unlock = ACTION（审批闸）— 解锁查看前弹 Keyguard，仅当次条目有效（件2）
 *   vault_list   = READONLY — 只列 id/名称/大小，不列内容
 *
 * 慢脑隔离：锁定内容进 prompt 需当次授权 = 本 handler 内的 KeyguardGate 闸
 * （approval=always 工具审批路径，同 device.cmd 模式，不新造权限机制）。
 * 云端精修链对 vault 条目默认拒绝：本机密文只在本机 filesDir/vault，AES-GCM 不出端。
 */
public class VaultToolProvider implements ToolRegistry.ToolProvider {

    private static final long GATE_WAIT_MS = 120_000;

    @Override public String id() { return "vault"; }

    @Override public List<ToolRegistry.Tool> discover() {
        List<ToolRegistry.Tool> list = new ArrayList<>();

        // ═══ vault_lock = ACTION(审批闸): 加密落盘前弹 Keyguard ═══
        list.add(new ToolRegistry.Tool("vault_lock",
                "把敏感文本加密存入保险柜（需锁屏验证）。存后原文只在本机 filesDir/vault（AES-GCM），不可出端。",
                null, a -> {
                    String name = a.optString("name", "");
                    String text = a.optString("text", "");
                    if (name.isEmpty()) return new ToolRegistry.Result(false, "name 不能为空");
                    if (text.isEmpty()) return new ToolRegistry.Result(false, "text 不能为空");
                    return runWithGate("vault_lock", name, () -> {
                        String id = HermesActivity.getCurrent().getSecureVault().lock(name, text);
                        return new ToolRegistry.Result(true,
                                "已加密存入保险柜: " + name + "（id=" + shortId(id) + "）");
                    });
                }, "native", "write", "always", false, 120,
                "vault",
                new ToolRegistry.ParamDef[]{
                    new ToolRegistry.ParamDef("name", "string", true, "脱敏名称", "条目名（如 扫描文档 2026-08-01，长数字自动泛化）"),
                    new ToolRegistry.ParamDef("text", "string", true, "不能为空", "要加密保存的敏感文本"),
                },
                "成功: 已加密存入保险柜 | 失败: 被拒绝/需先设锁屏密码",
                new String[]{"{\"action\":\"tool.execute\",\"name\":\"vault_lock\",\"args\":{\"name\":\"病历\",\"text\":\"张三 高血压 拜新同\"}}"},
                new String[]{"需锁屏验证，无锁屏密码设备会提示先设置", "存储原文后慢脑默认不可见，取回需再次过闸"},
                4000,
                new ToolRegistry.Manifest("存入保险柜", "high", "把敏感内容加密存进本机保险柜", false, "vault"),
                null));

        // ═══ vault_unlock = ACTION(审批闸): 解锁弹 Keyguard, 当次条目有效 ═══
        list.add(new ToolRegistry.Tool("vault_unlock",
                "解锁保险柜条目查看内容（需锁屏验证，仅当次该条目有效，不搞全场解锁）。返回内容会进入本次任务上下文。",
                null, a -> {
                    String id = a.optString("id", "");
                    if (id.isEmpty()) return new ToolRegistry.Result(false, "id 不能为空");
                    return runWithGate("vault_unlock", id, () -> {
                        String content = HermesActivity.getCurrent().getSecureVault().unlock(id);
                        return new ToolRegistry.Result(true, content);
                    });
                }, "native", "write", "always", false, 120,
                "vault",
                new ToolRegistry.ParamDef[]{
                    new ToolRegistry.ParamDef("id", "string", true, "保险柜条目 id", "要解锁查看的条目 id（vault_list 可得）"),
                },
                "成功: 条目内容 | 失败: 被拒绝/需先设锁屏密码/条目不存在",
                new String[]{"{\"action\":\"tool.execute\",\"name\":\"vault_unlock\",\"args\":{\"id\":\"<vault_list 得到的 id>\"}}"},
                new String[]{"解锁一次只对当次该条目有效", "需锁屏验证，无锁屏密码设备会提示先设置", "解锁内容进入本任务上下文，用后即消费授权"},
                8000,
                new ToolRegistry.Manifest("查看保险柜条目", "high", "锁屏验证后查看保险柜里的敏感内容", false, "vault"),
                null));

        // ═══ vault_list = READONLY(只列名不列内容) ═══
        list.add(new ToolRegistry.Tool("vault_list",
                "列保险柜条目（只列 id/名称/大小，不列内容，无需解锁）。",
                null, a -> {
                    HermesActivity act = HermesActivity.getCurrent();
                    if (act == null) return new ToolRegistry.Result(false, "保险柜不可用");
                    List<SecureVault.VaultEntry> entries = act.getSecureVault().list();
                    if (entries.isEmpty()) return new ToolRegistry.Result(true, "保险柜为空");
                    StringBuilder sb = new StringBuilder("保险柜条目（共 ").append(entries.size())
                            .append(" 条，只列元信息）:\n");
                    for (SecureVault.VaultEntry e : entries) {
                        sb.append("- ").append(e.name)
                          .append(" | ").append(humanSize(e.sizeBytes))
                          .append(" | id=").append(shortId(e.id)).append("\n");
                    }
                    return new ToolRegistry.Result(true, sb.toString());
                }, "native", "readonly", "none", true, 10,
                "vault",
                new ToolRegistry.ParamDef[]{},
                "条目列表(名称/大小/id，无内容)",
                new String[]{"{\"action\":\"tool.execute\",\"name\":\"vault_list\",\"args\":{}}"},
                new String[]{"只列元信息，内容需 vault_unlock 解锁"},
                2000,
                new ToolRegistry.Manifest("保险柜列表", "low", "查看保险柜条目元信息", true, "vault"),
                null));

        return list;
    }

    /**
     * 审批闸：主线程弹 Keyguard，等当次结果（120s 超时兜底）。过闸才执行 action，无论过/拒都消费复位。
     */
    private static ToolRegistry.Result runWithGate(String action, String entryId, GateAction act) {
        HermesActivity activity = HermesActivity.getCurrent();
        if (activity == null) return new ToolRegistry.Result(false, "保险柜不可用（无活动窗口）");
        KeyguardGate gate = activity.getKeyguardGate();
        CountDownLatch latch = new CountDownLatch(1);
        boolean[] approved = {false};
        String[] reason = {null};
        String desc = "vault_lock".equals(action)
                ? "加密存入保险柜（需锁屏验证）"
                : "解锁查看保险柜条目（需锁屏验证，仅当次有效）";
        activity.runOnUiThread(() -> {
            boolean requested = gate.request(activity.getKeyguardPrompter(), entryId, desc,
                    new KeyguardGate.ResultHandler() {
                        @Override public void onApproved() { approved[0] = true; latch.countDown(); }
                        @Override public void onRejected(String r) { reason[0] = r; latch.countDown(); }
                    });
            if (!requested) { reason[0] = "busy"; latch.countDown(); }
        });
        try {
            if (!latch.await(GATE_WAIT_MS, TimeUnit.MILLISECONDS)) {
                gate.consume();
                return new ToolRegistry.Result(false, "等待锁屏验证超时");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            gate.consume();
            return new ToolRegistry.Result(false, "等待锁屏验证被中断");
        }
        gate.consume();   // 当次授权消费（一次有效），无论过/拒都复位闸
        if (!approved[0]) {
            String r = reason[0];
            if ("no_lockscreen_denied".equals(r)) {
                return new ToolRegistry.Result(false, "需先设置锁屏密码（指纹/PIN/图案）才能使用保险柜");
            }
            if ("busy".equals(r)) return new ToolRegistry.Result(false, "已有解锁操作进行中，稍后再试");
            return new ToolRegistry.Result(false, "已取消或拒绝");
        }
        try {
            return act.run();
        } catch (VaultException e) {
            return new ToolRegistry.Result(false, e.getMessage());
        } catch (Exception e) {
            return new ToolRegistry.Result(false, "保险柜操作失败: " + e.getMessage());
        }
    }

    private interface GateAction {
        ToolRegistry.Result run() throws Exception;
    }

    private static String shortId(String id) {
        return id != null && id.length() > 8 ? id.substring(0, 8) : id;
    }

    private static String humanSize(long bytes) {
        if (bytes < 1024) return bytes + "B";
        if (bytes < 1024 * 1024) return (bytes / 1024) + "KB";
        return (bytes / (1024 * 1024)) + "MB";
    }
}
