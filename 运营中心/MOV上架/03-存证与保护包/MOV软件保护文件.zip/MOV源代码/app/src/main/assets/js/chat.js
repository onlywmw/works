/* ============================================================
   chat.js — 房间进入 / 消息路由 / 设备指令执行 / AI 对话
   ============================================================ */

/* ---------- 进入房间 ---------- */
function enterRoom(id, opts){
  /* 专家新脸化: opts 注入渲染目标 (cardId/parentId/scrollId/titleId/subId/pathId), noView 不切老视图 */
  opts=opts||{};
  genCounter++;
  curRoomId=id;
  try{if(window.HermesBridge)HermesBridge.setRoomOpen(id);}catch(e){}
  var r=ROOMS.find(function(x){return x.id===id;});
  if(!r){ev('enterRoom: 房间不存在 '+id);return;}
  r.unread=0;
  var tEl=$(opts.titleId||'roomTitle'); if(tEl)tEl.textContent=r.name;
  var sEl=$(opts.subId||'roomSub'); if(sEl)sEl.textContent=roomSubtitle(r);
  var rp=$(opts.pathId||'roomPath'); if(rp)rp.textContent='/data/data/com.hermes.android/files/rooms/'+id;
  if(window.MovThinking) window.MovThinking.reset();
  var cardId=opts.cardId||'cardPane';
  var b=$(opts.parentId||'chatBody');
  if(b)b.innerHTML='';
  var cp=document.createElement('div'); cp.className='card-pane'; cp.id=cardId;
  if(b)b.appendChild(cp);
  /* P5: 全房间 journal 回放 (真理源统一) */
  MovRender.setRoom(id);
  MovRender.reset();
  // MovRender 渲染到卡片区 (专家新脸化: 容器/滚动可注入)
  MovRender.init(cardId, opts.scrollId);
  var replay=B.query({q:'journal_replay',roomId:id});
  var hasJournal=replay.ok&&replay.data&&replay.data.events&&replay.data.events.length>0;
  if(hasJournal){
    MovRender.replayEvents(replay.data.events);
  }else if(!r.seeded&&(r.seed&&r.seed.length>0)){
    /* 首次进入: seed 迁移到 journal (silent 防双重渲染) */
    r.seeded=true;
    r.seed.forEach(function(m){
      /* 派单№6: agent 种子按 AI 样式(note/brain → 白卡), YOU 种子才走 user_input(user → 墨泡) */
      var type=(m.t==='sys'||m.t==='agent')?'note':'user_input';
      var actor=(m.who==='YOU'||m.me)?'user':(m.t==='sys'?'kernel':'brain');
      B.postCmd({cmd:'append_event',roomId:id,type:type,actor:actor,silent:true,payload:{text:m.h||''}});
    });
    var replay2=B.query({q:'journal_replay',roomId:id});
    if(replay2.ok&&replay2.data&&replay2.data.events){
      MovRender.reset();
      MovRender.replayEvents(replay2.data.events);
    }
  }
  /* P5: 从 chatBody 收集 MovRender 渲染的节点, 供长按删除使用 */
  r.msgs=[]; if(b){Array.prototype.forEach.call(b.children,function(n){r.msgs.push(n);});}
  bindAllMsgLongPress(id);
  var sc=$(opts.scrollId||'chatPane'); if(sc)sc.scrollTop=sc.scrollHeight;
  /* 持久化当前房间 ID, 进程被杀后自动恢复 */
  try{localStorage.setItem('mov_last_room',id);}catch(e){}
  /* 专家新脸化: noView 时不切老视图, 老 DOM 操作(子 tab/附件条)全跳过 (新脸专家会话挂 own 容器) */
  if(!opts.noView){
    if(typeof setSubtab==='function')setSubtab('chat');
    pending=[];renderPend();closeTray();
    /* 第三幕清场: 老会话视图切换已删 (无老视图可切) */
  }
  renderRooms();persistRooms();
  ev('进入房间 '+r.name);
}

/* ---------- 设备指令执行 (真后端) ---------- */
async function runDeviceCommand(id,text){
  var gen=genCounter;
  var alive=function(){return genCounter===gen&&curRoomId===id;};
  var t0=Date.now();
  var typing=mkMsg({t:'agent',who:'mov',caret:true});
  showTyping(id,typing);
  var out=B.cmd(text);
  killTyping(typing);
  if(!alive())return;
  var dur=((Date.now()-t0)/1000).toFixed(2)+'s';
  var ok=out.indexOf('❌')!==0&&out.indexOf('⚠')!==0;
  var toolN=toolNode('device',text,dur,esc(out)+'\n<span class="'+(ok?'ok-line':'err-line')+'">'+(ok?'exit 0':'exit 1')+'</span>');
  var replyN=mkMsg({t:'agent',who:'mov',h:out});
  push(id,toolN);
  push(id,replyN);
  /* P5: 设备指令结果写 journal + data-seq */
  {var jr=B.postCmd({cmd:'append_event',roomId:id,type:'tool_result',actor:'worker',silent:true,payload:{ok:ok,durMs:Date.now()-t0,summary:out.slice(0,200)}});if(jr.ok&&jr.data){if(toolN)toolN.setAttribute('data-seq',jr.data.seq);if(replyN)replyN.setAttribute('data-seq',jr.data.seq);}}
  var room=ROOMS.find(function(r){return r.id===id;});
  if(room){room.last=out.length>32?out.slice(0,32)+'…':out;room.time='现在';renderRooms();persistRooms();}
  ev('执行设备指令: '+text+' → '+(ok?'OK':'FAIL'));
}

/* 房间副标题 (enterRoom / 成员编辑共用, DESIGN_NEW_ROOM v2) */
function roomSubtitle(r){
  /* 房间恒为 agent 房: 副标题 = agent + AI 成员 (可无) */
  var aiNames=roomAiNames(r);
  return 'mov agent'+(aiNames.length?' · '+aiNames.join(' / '):'');
}

/* ---------- AI 对话 (P0-1: 异步, 不阻塞 UI) ---------- */
/* modelId 可选: DESIGN_NEW_ROOM v2 单聊房按绑定模型路由 */
function runAiChat(id,text,modelId){
  var gen=genCounter;
  var alive=function(){return genCounter===gen&&curRoomId===id;};
  var typing=mkMsg({t:'agent',who:'mov',caret:true});
  showTyping(id,typing);
  var onResp=function(resp){
    killTyping(typing);
    /* Fix: 去掉 esc 双重转义 (safeBubble 已 textNode 防护); 失败时 content 即错误信息 */
    var content=resp.content||(resp.ok?'':'AI 调用失败');
    if(!alive()){
      /* 切房不丢回复: 写入对应房间并置 unread, 不渲染 */
      var nr=ROOMS.find(function(r){return r.id===id;});
      if(nr){
        var n1=mkMsg({t:'agent',who:'mov',h:content});
        push(id,n1);
        /* P2: desk 房 AI 回复写 journal + data-seq (切房也落盘) */
        {var jr=B.postCmd({cmd:'append_event',roomId:id,type:'note',actor:'brain',silent:true,payload:{text:content}});if(jr.ok&&jr.data&&n1)n1.setAttribute('data-seq',jr.data.seq);}
        if(curRoomId!==id)nr.unread=(nr.unread||0)+1;
        nr.last=(content||'').replace(/\n/g,' ').slice(0,32);nr.time='现在';
        renderRooms();persistRooms();
      }
      return;
    }
    var n2=mkMsg({t:'agent',who:'mov',h:content});
    push(id,n2);
    /* P2: desk 房 AI 回复写 journal + data-seq */
    {var jr2=B.postCmd({cmd:'append_event',roomId:id,type:'note',actor:'brain',silent:true,payload:{text:content}});if(jr2.ok&&jr2.data&&n2)n2.setAttribute('data-seq',jr2.data.seq);}
    var room=ROOMS.find(function(r){return r.id===id;});
    if(room){room.last=(content||'').replace(/\n/g,' ').slice(0,32);room.time='现在';renderRooms();persistRooms();}
  };
  if(modelId){B.aiChatWithModel(text,modelId,onResp);}
  else{B.aiAsync(text,onResp);}
}

function routeMessage(id,text){
  var parsed=B.parse(text);
  if(parsed.cmd){
    runDeviceCommand(id,text);
    return;
  }
  /* DESIGN_NEW_ROOM v2: 非 desk 且绑定了模型的房间 → 按房间模型对话 */
  var room=ROOMS.find(function(r){return r.id===id;});
  var mids=room?roomAiMembers(room):[];
  if(room&&id!=='desk'&&mids.length>0){
    runAiChat(id,text,mids[0]);
    return;
  }
  /* desk 单聊: 优先注册表默认模型 (ModelRegistry; toJson 无 isConfigured 字段,
     用 apiKey 非空判断已配置), 兜底旧版单模型配置 */
  var dm=null;
  try{dm=(B.listModels()||[]).find(function(m){return m.isDefault&&m.apiKey&&m.apiKey.length>0;})||null;}catch(e){}
  if(dm){runAiChat(id,text,dm.id);return;}
  var info=B.aiInfo();
  if(info.enabled&&info.configured){
    runAiChat(id,text);
  }else if(!info.enabled){
    push(id,mkMsg({t:'agent',who:'mov',h:'「'+text+'」不是设备指令, 且 AI 已关闭。点右上角 <code>≡</code> 可启用并配置 API。'}));
  }else{
    push(id,mkMsg({t:'agent',who:'mov',h:'「'+text+'」不是设备指令。AI 尚未配置 API Key —— 点右上角 <code>≡</code> 设置后即可畅聊。输入 <code>帮助</code> 查看全部设备指令。'}));
  }
}

/* ---------- 附件系统 (P1-8: 真实文件选择器) ---------- */
function renderPend(){
  var h='';pending.forEach(function(a,i){h+='<span class="pend">'+esc(attName(a))+'<span class="x" data-i="'+i+'">✕</span></span>';});
  /* 第三幕清场: pendRow 老 DOM 已删 → 判空 */
  var pr=$('pendRow'); if(!pr)return;
  pr.innerHTML=h;
  document.querySelectorAll('#pendRow .x').forEach(function(x){x.addEventListener('click',function(){pending.splice(+x.getAttribute('data-i'),1);renderPend();ev('移除待发附件');});});
}
function closeTray(){trayOpen=false;var at=$('attTray');if(at)at.classList.remove('open');var pb=$('plusBtn');if(pb)pb.classList.remove('open');}

/* ---------- 发送 ---------- */
function sendMsg(){
  if(!curRoomId)return;
  /* agent 执行中 (非挂起): 发送键是 ■ 停止 */
  if(_agentExecuting&&_agentLoop&&_agentLoop.roomId===curRoomId&&!_agentLoop.awaiting){
    B.postCmd({cmd:'stop_task',taskId:_agentLoop.loopId,roomId:curRoomId});ev('喊停 agent');return;
  }
  var v=$('msgInput').value.trim();
  if(!v&&pending.length===0)return;
  var room=ROOMS.find(function(r){return r.id===curRoomId;});
  if(!room){ev('sendMsg: 房间不存在 '+curRoomId);return;}
  var gen=genCounter,id=curRoomId;
  var userNode=mkMsg({t:'agent',who:'YOU',me:true,h:v,att:pending.length?pending[pending.length-1]:null});
  push(id,userNode);
  /* P5: 全房间用户输入写 journal + data-seq */
  if(v){var jr=B.postCmd({cmd:'append_event',roomId:id,type:'user_input',actor:'user',silent:true,payload:{text:v}});if(jr.ok&&jr.data&&userNode)userNode.setAttribute('data-seq',jr.data.seq);}
  room.last=v||('[附件] '+(pending[0]?attName(pending[0]):'文件'));room.time='现在';renderRooms();persistRooms();
  $('msgInput').value='';pending=[];renderPend();
  ev('发送消息'+(v?'':'(纯附件)'));
  if(!v)return;
  if(id==='desk'){
    routeMessage(id,v); /* desk 房: 设备指令 + 全局问答, 不走 agent 循环 */
    return;
  }
  /* 非 desk 房恒为 agent 房 (agent 必选): ask_user 答案 / 计划闸意见优先回灌 */
  if(_agentLoop&&_agentLoop.roomId===id&&_agentLoop.awaiting){
    var aw=_agentLoop.awaiting;
    _agentLoop.awaiting=null;restoreAgentInput();
    if(aw==='ask'){B.postCmd({cmd:'gate_respond',taskId:_agentLoop.loopId,roomId:id,gate:'ask',approved:true,note:v});}
    else{B.postCmd({cmd:'gate_respond',taskId:_agentLoop.loopId,roomId:id,gate:'plan',approved:false,note:v});push(id,mkMsg({t:'sys',h:'已驳回并补充, 重新规划中'}));}
  }else{
    runAgentTask(id,v,gen);
  }
}

/* 专家新脸化: 新脸专家会话发消息 — 复用 journal + agent 链路, 不 push/showTyping
   (MovRender 从 journal 事件投影渲染, 避免与 chatBody push 重复渲染) */
function sendExpertMsg(roomId, text){
  text=(text||'').trim();
  var room=ROOMS.find(function(r){return r.id===roomId;});
  if(!room||!text)return;
  var jr=B.postCmd({cmd:'append_event',roomId:roomId,type:'user_input',actor:'user',silent:true,payload:{text:text}});
  /* 轻打回修法(巡检#22): 乐观渲染——按 event id(seq) 分发 journal 事件, MovRender 立即渲染并
     记录 seq 去重 (防后续原生回流同 seq 重复); 无 _movEvent 或 seq 缺失时降级 (重进可见) */
  try{
    if(window._movEvent&&jr&&jr.ok&&jr.data&&jr.data.seq!==undefined){
      window._movEvent({roomId:roomId, channel:'journal',
        event:{seq:jr.data.seq, type:'user_input', actor:'user', payload:{text:text}}});
    }
  }catch(e){}
  room.last=text;room.time='现在';renderRooms();persistRooms();
  if(roomId==='desk'){routeMessage(roomId,text);return;}
  /* 非 desk 房恒为 agent 房: ask_user 答案 / 计划闸意见优先回灌 */
  if(_agentLoop&&_agentLoop.roomId===roomId&&_agentLoop.awaiting){
    var aw=_agentLoop.awaiting;
    _agentLoop.awaiting=null;
    if(aw==='ask'){B.postCmd({cmd:'gate_respond',taskId:_agentLoop.loopId,roomId:roomId,gate:'ask',approved:true,note:text});}
    else{B.postCmd({cmd:'gate_respond',taskId:_agentLoop.loopId,roomId:roomId,gate:'plan',approved:false,note:text});}
  }else{
    runAgentTask(roomId,text,genCounter);
  }
}

/* ---------- Agentic 任务 (DESIGN_AGENT_LOOP v1: 1 驱动 + 工作日志) ---------- */
var _agentLoop=null;   /* {loopId, roomId, gen, goal, planSteps, awaiting: null|'plan'|'ask'} */
var _agentExecuting=false;
var _agentLogBuf=[];   /* 竞态缓冲: 原生循环启动即吐日志, 回调还没拿到 loopId 时先存后放 */

function runAgentTask(id,goal,gen){
  var room=ROOMS.find(function(r){return r.id===id;});
  var modelIds=room?roomAiMembers(room):[];
  setPhase(id,'讨论中');
  var typing=mkMsg({t:'agent',who:'mov',caret:true});
  showTyping(id,typing);
  B.agentStart(goal,id,modelIds,function(resp){
    killTyping(typing);
    if(curRoomId!==id)return;
    if(!resp.ok){push(id,mkMsg({t:'agent',who:'mov',h:resp.error||'任务启动失败'}));return;}
    if(resp.queued){push(id,mkMsg({t:'sys',h:'mov 还在执行上一个任务, 此任务已排队'}));}
    _agentLoop={loopId:resp.loopId,roomId:id,gen:gen,goal:goal,planSteps:0,awaiting:null};
    /* 回放启动竞态期缓冲的日志 (phase/plan 可能早于回调到达) */
    var buf=_agentLogBuf;_agentLogBuf=[];
    buf.forEach(function(d){window._agentLog(d);});
  });
}

/* 工作日志入口 (原生 BridgeAi → window._agentLog) */
window._agentLog=function(data){
  try{if(typeof data==='string')data=JSON.parse(data);}catch(e){return;}
  if(!_agentLoop){
    /* 启动竞态: 回调未回, 先缓冲 (上限防无限堆积); 非竞态的游离日志自然被后续 loopId 校验丢弃 */
    if(_agentLogBuf.length<50)_agentLogBuf.push(data);
    return;
  }
  if(data.loopId!==_agentLoop.loopId)return;
  var id=_agentLoop.roomId;
  if(data.type==='phase'){setPhase(id,data.phase);return;}
  /* 切房守卫: 不渲染 UI, 但终态事件仍要清理状态, plan/filePreview/shellPreview 自动驳回防原生挂起 */
  if(curRoomId!==id||genCounter!==_agentLoop.gen){
    if(data.type==='plan'&&_agentLoop){B.postCmd({cmd:'gate_respond',taskId:_agentLoop.loopId,roomId:id,gate:'plan',approved:false,note:'房间已切换, 计划自动驳回'});}
    else if(data.type==='filePreview'&&_agentLoop){B.postCmd({cmd:'gate_respond',taskId:_agentLoop.loopId,roomId:id,gate:'fileWrite',approved:false});}
    else if(data.type==='shellPreview'&&_agentLoop){B.postCmd({cmd:'gate_respond',taskId:_agentLoop.loopId,roomId:id,gate:'shell',approved:false});}
    else if(data.type==='deliver'||data.type==='fail'||data.type==='stopped'){endStream(data.loopId);endAgentTask(id);}
    return;
  }
  /* P5: 状态管理 (渲染全部由 MovRender 负责, BridgeAi.writeToJournal → _movEvent) */
  switch(data.type){
    case 'plan':
      _agentLoop.awaiting='plan';
      _agentLoop.planSteps=(data.steps||[]).length;
      if(window.MovThinking) window.MovThinking.agentPhase(1, null);
      break;
    case 'filePreview':
      _agentLoop.awaiting='fileWrite';
      break;
    case 'shellPreview':
      _agentLoop.awaiting='shell';
      break;
    case 'step':
      setAgentStatus(id,data);
      if(window.MovThinking) window.MovThinking.agentPhase(2, null);
      break;
    case 'ask':
      _agentLoop.awaiting='ask';
      if(!(data.options&&data.options.length))setAgentInputHint('回答问题后发送…');
      break;
    case 'note':
    case 'review':
      break;
    case 'deliver':
      endStream(data.loopId);
      endAgentTask(id);
      if(window.MovThinking){ window.MovThinking.agentPhase(4, 100); window.MovThinking.finish(true); }
      break;
    case 'fail':
      endStream(data.loopId);
      endAgentTask(id);
      if(window.MovThinking){ window.MovThinking.agentPhase(4, 100); window.MovThinking.finish(false); }
      break;
    case 'stopped':
      endStream(data.loopId);
      endAgentTask(id);
      if(window.MovThinking) window.MovThinking.finish(true);
      break;
    case 'paused':
      _agentLoop.awaiting='paused';
      break;
  }
};

/* ═══ 流式活性 (CONTRACT_STREAMING): 打字机 + TPS + M 流光 + 暂停卡 ═══ */

var _movEndedLoops={}; // 已终结 loop (终态冲底的迟到 token 不再复活, 防定时器泄漏)

/* M 流光 (合同 3.2 审定参数: w 起笔路径, dasharray 34 166, dashoffset 200→0, 1.6s) */
function mflowSvg(){
  var d='M2 3 L10 15 L18 3 L26 15 L34 3 L42 15 L50 3 L58 15 L66 3 L74 15 L82 3 L90 15 L98 3';
  return '<svg class="mflow" viewBox="0 0 100 18" width="30" height="8" aria-hidden="true">'
    +'<path class="mflow-base" d="'+d+'"/>'
    +'<path class="mflow-pulse" d="'+d+'"/>'
    +'</svg>';
}

var _movSeq = {}; var _movLastLoop = null;
window._movToken=function(loopId,token){
  if(_movEndedLoops[loopId])return;
  // ARCH_DEBT #4: 轻量流式校验
  if(token == null){ console.warn('[mov] null token for loop '+loopId); return; }
  var seq = _movSeq[loopId] || (_movSeq[loopId] = {total:0, count:0});
  if(seq.count === 0) console.log('[mov] loop='+loopId+' stream START');
  if(_movLastLoop && _movLastLoop !== loopId && seq.count > 0) console.warn('[mov] interleaved: '+_movLastLoop+' → '+loopId);
  _movLastLoop = loopId;
  seq.total += token.length; seq.count++;
  if(seq.count % 50 === 0) console.log('[mov] loop='+loopId+' chunks='+seq.count+' chars='+seq.total);
  /* Phase 2: 思考区接管 token 渲染 */
  if(window.MovThinking){
    window.MovThinking.feed(loopId, token);
    return;
  }
};

/* 思考动效气泡 — M 流光动效 */
function createThinkingBubble(loopId){
  var body=$('chatBody'); if(!body)return null;
  var el=document.createElement('div'); el.className='msg wide thinking-bubble';
  el.setAttribute('data-loop',loopId);
  el.innerHTML=mflowSvg()+' <span style=font-size:13px;color:var(--ink-3)>思考中</span>';
  body.appendChild(el);
  var cp=document.getElementById('chatPane'); if(cp)cp.scrollTop=cp.scrollHeight;
  return el;
}
function removeThinkingBubble(s){
  if(s.thinkEl&&s.thinkEl.parentNode) s.thinkEl.parentNode.removeChild(s.thinkEl);
  s.thinkEl=null;
}

/* 断网/恢复状态条 (HermesActivity 网络监听推入) */
window._movNet=function(online){
  if(curRoomId){
    push(curRoomId,mkMsg({t:'sys',h:online?t('stream.netOn'):t('stream.netOff')}));
  }
};

/* 流终止: 标记终态 + 打 END 日志 (MovThinking 自行管理内部状态) */
function endStream(loopId){
  _movEndedLoops[loopId]=true;   // 先标记终结, 迟到的冲底 token 不再复活 (防竞态)
  var sq = _movSeq[loopId]; if(sq) console.log('[mov] loop='+loopId+' stream END chunks='+sq.count+' chars='+sq.total);
  delete _movSeq[loopId];
}

/* ---------- Agent 状态管理 (活函数, 不可删) ---------- */
function setAgentStatus(id,data){
  _agentExecuting=true;
  var bs=$('btnSend'); if(bs)bs.textContent='■';
  var rs=$('roomSub'); if(rs)rs.textContent='执行中 · 已用 '+(((data.promptTokens+data.completionTokens)||0)/1000).toFixed(1)+'k tokens · '+fmtSec(data.elapsedSec)+' · 点 ■ 停止';
}
function endAgentTask(id){
  _agentExecuting=false;
  var bs=$('btnSend'); if(bs)bs.textContent=t('room.send');
  restoreAgentInput(); /* 否则 ask/驳回 的 placeholder 残留到下一个任务 */
  var r=ROOMS.find(function(x){return x.id===id;});
  if(r&&curRoomId===id){var rs=$('roomSub'); if(rs)rs.textContent=roomSubtitle(r);}
  _agentLoop=null;
}
function setAgentInputHint(h){var mi=$('msgInput'); if(mi)mi.placeholder=h;}
function restoreAgentInput(){var mi=$('msgInput'); if(mi)mi.placeholder=t('room.input');}
function fmtSec(s){s=Math.round(s||0);return s>=60?Math.floor(s/60)+'分'+(s%60)+'秒':s+'秒';}

/* ============ 长按基础设施 (消息 + 技能共用) ============ */
var _lpTimer=null,_lpNode=null,_lpStartX=0,_lpStartY=0,_lpAction=null;

function bindLongPress(node,action){
  /* P1.5: 去重 — 节点跨 enterRoom 复用时避免重复绑监听 */
  if(node._lpBound)return;
  node._lpBound=true;
  node.addEventListener('touchstart',function(e){
    _lpStartX=e.touches[0].clientX;_lpStartY=e.touches[0].clientY;
    _lpNode=node;_lpAction=action;
    _lpTimer=setTimeout(function(){triggerLongPress();},500);
  },{passive:true});
  node.addEventListener('touchmove',function(e){
    /* P1.5: 修复 &&/|| 优先级 — dy 判断也必须在 _lpTimer 守卫内 */
    if(_lpTimer&&(Math.abs(e.touches[0].clientX-_lpStartX)>10||Math.abs(e.touches[0].clientY-_lpStartY)>10)){cancelLongPress();}
  },{passive:true});
  node.addEventListener('touchend',cancelLongPress,{passive:true});
  node.addEventListener('mousedown',function(e){
    _lpStartX=e.clientX;_lpStartY=e.clientY;
    _lpNode=node;_lpAction=action;
    _lpTimer=setTimeout(function(){triggerLongPress();},500);
  });
  node.addEventListener('mouseup',cancelLongPress);
  node.addEventListener('mouseleave',cancelLongPress);
}
function cancelLongPress(){if(_lpTimer){clearTimeout(_lpTimer);_lpTimer=null;}}
function triggerLongPress(){
  _lpTimer=null;
  if(!_lpNode||!_lpAction)return;
  /* P1.5: 记录长按时间戳, click handler 300ms 内抑制, 防长按/click 双触发 */
  window._lpFired=Date.now();
  _lpNode.classList.add('longpress-hl');
  /* 空 text = 非危险操作 (如房间卡片长按): 不弹 msgActions 确认条直接执行,
     避免无字空白条残留"上膛"劫持后续点击; 高亮反馈保留 */
  if(!_lpAction.text){
    var node=_lpNode;
    setTimeout(function(){node.classList.remove('longpress-hl');},350);
    _lpAction.exec();
    return;
  }
  showMsgActions(_lpAction.text,function(){
    _lpNode.classList.remove('longpress-hl');
    hideMsgActions();
    _lpAction.exec();
  });
}
/* P1.5: click handler 首行调用, 长按后 300ms 内返回 true 应直接 return */
function lpSuppressClick(){return window._lpFired&&(Date.now()-window._lpFired)<300;}
function showMsgActions(text,onConfirm){
  var el=$('msgActions');
  $('msgActionText').textContent=text;
  el.classList.add('show');
  el._onConfirm=onConfirm;
}
function hideMsgActions(){
  var el=$('msgActions');
  el.classList.remove('show');
  el._onConfirm=null;
  if(_lpNode){_lpNode.classList.remove('longpress-hl');_lpNode=null;}
}
$('msgActions').addEventListener('click',function(){
  if(this._onConfirm)this._onConfirm();
});
/* 兜底: 点确认条以外任意处自动解除"上膛"状态 (捕获阶段, 防内层 stopPropagation) */
document.addEventListener('touchstart',function(e){
  var el=$('msgActions');
  if(el.classList.contains('show')&&!el.contains(e.target))hideMsgActions();
},true);

/* ---------- 消息长按删除 ---------- */
/* P1.5: 不再闭包捕获 idx — 删除一条后剩余节点 idx 过期会删错消息;
   长按触发时按节点在 room.msgs 中的实时位置定位 */
function bindMsgLongPress(node,roomId){
  var targetSeq=node.getAttribute('data-seq');
  bindLongPress(node,{
    text:t('msg.delete'),
    exec:function(){
      var room=ROOMS.find(function(r){return r.id===roomId;});
      var idx=(room&&room.msgs)?room.msgs.indexOf(node):-1;
      if(idx>=0)deleteMessage(roomId,idx);
    }
  });
  /* P7: 长按菜单加 👍 reaction 按钮 */
  if(targetSeq){
    var rxnBtn=$('msgRxnBtn');
    rxnBtn.style.display=''; /* 可见 */
    rxnBtn.onclick=function(){
      B.react(roomId,parseInt(targetSeq),'👍');
      B.toast('👍');
      hideMsgActions();
    };
    /* 原 hideMsgActions 不清 rxnBtn, 在此处补 */
    var origHide=hideMsgActions;
    hideMsgActions=function(){
      rxnBtn.style.display='none'; rxnBtn.onclick=null;
      origHide();
    };
  }
}
/* P2: 删除消息 — 写 tombstone 到 journal, 按 data-seq 移除 DOM */
function deleteMessage(roomId,idx){
  var room=ROOMS.find(function(r){return r.id===roomId;});
  if(!room)return;
  room.msgs=room.msgs||[];
  /* 找到目标节点的 data-seq */
  var targetNode=room.msgs[idx];
  var targetSeq=targetNode?targetNode.getAttribute('data-seq'):null;
  if(idx>=0&&idx<room.msgs.length){
    room.msgs.splice(idx,1);
  }
  /* 写 tombstone 到 journal (不修改历史, 只追加删除标记) */
  if(targetSeq){
    B.postCmd({cmd:'append_event',roomId:roomId,type:'tombstone',actor:'kernel',payload:{targetSeq:parseInt(targetSeq)}});
  }
  persistRooms();
  /* 重渲染聊天区 (第三幕清场: chatBody 判空) */
  var b=$('chatBody');if(!b)return;
  b.innerHTML='';
  (room.msgs||[]).forEach(function(n){b.appendChild(n);});
  var cp=document.getElementById('chatPane');if(cp)cp.scrollTop=cp.scrollHeight;
  B.toast(t('msg.deleted'));
  ev('删除消息 idx='+idx+(targetSeq?' seq='+targetSeq:''));
}

/* P2: 清空聊天记录 — 清 DOM + 清 msgs, journal 不动 (只追加不修改) */
function clearRoomHistory(roomId){
  var room=ROOMS.find(function(r){return r.id===roomId;});
  if(!room)return;
  room.msgs=[];
  room.seeded=false; /* 重置: 下次 enterRoom 重新迁移 seed 到 journal */
  persistRooms();
  var b=$('chatBody');if(b)b.innerHTML='';
  if(window.MovRender)MovRender.reset();
  B.toast(t('ops.cleared'));
  ev('清空聊天记录 '+room.name);
}

/* Phase 1: 房间路径点击复制 */
document.addEventListener('DOMContentLoaded',function(){
  var rp=$('roomPath'); if(!rp)return;
  rp.addEventListener('click',function(){
    var txt=rp.textContent;
    if(!txt||txt==='—')return;
    if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(txt).then(function(){showCopyTip();});}
    else{var ta=document.createElement('textarea');ta.value=txt;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);showCopyTip();}
  });
});
function showCopyTip(){
  var el=$('copyTip'); if(!el)return;
  el.classList.add('show');
  setTimeout(function(){el.classList.remove('show');},1400);
}

/* 进入房间后给每条消息绑定长按 */
function bindAllMsgLongPress(roomId){
  var room=ROOMS.find(function(r){return r.id===roomId;});
  if(!room||!room.msgs)return;
  room.msgs.forEach(function(node){
    bindMsgLongPress(node,roomId);
  });
}
