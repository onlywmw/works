package com.hermes.android.mcp;

import android.util.Log;

import com.hermes.android.bridge.BridgeFactory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MCP JSON-RPC 服务端 — 把 BridgeFactory 的 75 个方法暴露为 MCP 工具。
 *
 * 启动: McpServer.start(bridgeFactory)
 * 停止: McpServer.stop()
 *
 * 端点: POST http://127.0.0.1:{port}/mcp
 *   请求: {"method":"tools/list", "id":1}
 *   请求: {"method":"tools/call", "params":{"name":"file_read","args":{"roomId":"r","path":"/x"}}, "id":2}
 */
public class McpServer {

    private static final String TAG = "McpServer";
    private static final int PORT_MIN = 10000;
    private static final int PORT_MAX = 20000;

    private ServerSocket serverSocket;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean running;
    private int port;

    private BridgeFactory bridge;
    /** 测试注入 token：socket 级 401 集成测试用（非 null 时优先于 bridge.getActivity()，避免 bridge null NPE） */
    private String testToken;

    /** 测试构造：注入 token，起真 socket 测 handle 鉴权（不依赖 BridgeFactory/activity） */
    McpServer(String token) {
        this.testToken = token;
    }

    /** 默认构造（生产：HermesActivity 启动用，bridge 由 start() 注入） */
    public McpServer() {
    }
    private final Map<String, ToolDescriptor> tools = new LinkedHashMap<>();

    /** 启动 MCP 服务。返回端口号。 */
    public synchronized int start(BridgeFactory bridgeFactory) {
        if (running) return port;
        this.bridge = bridgeFactory;
        buildToolRegistry();

        for (int p = PORT_MIN; p <= PORT_MAX; p++) {
            try {
                serverSocket = new ServerSocket();
                serverSocket.setReuseAddress(true);
                serverSocket.bind(new InetSocketAddress("127.0.0.1", p));
                port = p;
                running = true;
                Log.i(TAG, "MCP 服务启动 127.0.0.1:" + port + " (" + tools.size() + " 工具)");
                pool.submit(this::acceptLoop);
                return port;
            } catch (Exception e) {
                // 端口被占用，继续
            }
        }
        Log.e(TAG, "无可用端口");
        return -1;
    }

    public synchronized void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception e) {}
        pool.shutdownNow();
        Log.i(TAG, "MCP 服务已停止");
    }

    public int getPort() { return port; }
    public boolean isRunning() { return running; }

    // ── 工具注册表 ──

    private void buildToolRegistry() {
        tools.clear();
        // 扫描 BridgeFactory 的 @JavascriptInterface 方法——allowlist（R7 存量安全整治）：
        // 只有 @McpExpose 标注的只读安全方法才注册成 MCP 工具（默认不上网，根治「新增桥方法自动上网」）；
        // denylist 双保险兜底敏感方法。写/执行/敏感方法一律不标 @McpExpose。
        java.util.Set<String> sensitiveBridge = java.util.Set.of(
                "getServeToken",      // 返回 serve token，暴露 = 8389 Bearer 鉴权被架空
                "setMcpWriteEnabled"  // MCP 写工具开关，暴露 = 绕过安全默认
        );
        for (Method m : BridgeFactory.class.getDeclaredMethods()) {
            if (!m.isAnnotationPresent(android.webkit.JavascriptInterface.class)) continue;
            if (!m.isAnnotationPresent(com.hermes.android.bridge.McpExpose.class)) continue;  // allowlist
            if (sensitiveBridge.contains(m.getName())) continue;   // denylist 兜底
            ToolDescriptor td = ToolDescriptor.from(m);
            tools.put(td.name, td);
        }
        // 注册 MCP 模型管理工具
        registerModelTools();
    }

    /** MCP 模型管理工具 — 外部 AI 可通过 MCP 协议管理 MOV 模型 */
    private void registerModelTools() {
        // R7 存量安全整治：只保留脱敏只读的 list/get/export；mov.models.add（含 apiKey 写入）与
        // set_default（改默认大脑）危险，移除不出现在旧 MCP 工具表（即使有 token 也不给匿名面）。
        tools.put("mov.models.list", new ToolDescriptor("mov.models.list", null, new String[]{})
            .withDesc("列出所有已配置的 AI 模型（API Key 已脱敏）"));
        tools.put("mov.models.get", new ToolDescriptor("mov.models.get", null, new String[]{"id"})
            .withDesc("获取指定模型的详细配置（Key 已脱敏）"));
        tools.put("mov.models.export", new ToolDescriptor("mov.models.export", null, new String[]{})
            .withDesc("导出所有模型配置（API Key 已脱敏）"));
    }

    // ── HTTP 循环 ──

    private void acceptLoop() {
        while (running) {
            try {
                Socket client = serverSocket.accept();
                pool.submit(() -> handle(client));
            } catch (Exception e) {
                if (running) Log.w(TAG, "accept 异常: " + e.getMessage());
            }
        }
    }

    private void handle(Socket client) {
        try {
            /* P4 真机验收 2026-08-05: Content-Length 是字节数, 按字符读多字节 UTF-8 体
               会阻塞到超时 (同 MovInboundServer 实踩); 一律按字节解析。 */
            java.io.BufferedInputStream in =
                    new java.io.BufferedInputStream(client.getInputStream());
            OutputStream out = client.getOutputStream();

            // 读请求行 + headers (头 ASCII, 扫到 \r\n\r\n)
            String head = readHead(in);
            if (head == null) { client.close(); return; }
            int contentLength = 0;
            for (String line : head.split("\r\n")) {
                if (line.toLowerCase().startsWith("content-length:")) {
                    contentLength = Integer.parseInt(line.substring(15).trim());
                }
            }

            // 读 body (精确 contentLength 字节)
            byte[] body = readFully(in, contentLength);

            // R7 存量安全整治：token 鉴权（fail-closed，与 MovMcpServer 同源 HermesServeConfig.token）。
            // 旧 McpServer 此前 dispatch 全程无校验，任意本机 App 可匿名调用。
            String authErr = authError(head);
            if (authErr != null) {
                byte[] errBytes = ("{\"jsonrpc\":\"2.0\",\"error\":{\"code\":\"UNAUTHORIZED\",\"message\":\"token 无效\"},\"id\":null}")
                        .getBytes("UTF-8");
                out.write(responseHeader(401, "401 Unauthorized", errBytes).getBytes("UTF-8"));
                out.write(errBytes);
                out.flush();
                client.close();
                return;
            }

            String response = dispatch(new String(body, 0, body.length, "UTF-8"));

            // 写响应（R7: 去掉 Access-Control-Allow-Origin: *，CORS 收紧——不向任意来源开放）
            byte[] respBytes = response.getBytes("UTF-8");
            out.write(responseHeader(200, "200 OK", respBytes).getBytes("UTF-8"));
            out.write(respBytes);
            out.flush();
            client.close();
        } catch (Exception e) {
            Log.w(TAG, "处理请求异常: " + e.getMessage());
        }
    }

    /** R7 token 鉴权：Authorization: Bearer / X-Mov-Token 头，与 MovMcpServer 同源（HermesServeConfig.token）。
     *  fail-closed：服务端未配置 token / 请求无 token / token 不匹配 → 非 null（401）。 */
    private String authError(String head) {
        String expected = testToken != null ? testToken
                : com.hermes.android.agent.HermesServeConfig.token(bridge.getActivity());
        return authError(head, expected);
    }

    /** 包级重载：供单测注入 expected token，零网络测 fail-closed。 */
    static String authError(String head, String expected) {
        if (expected == null || expected.isEmpty()) return "UNAUTHORIZED";
        String given = null;
        for (String line : head.split("\r\n")) {
            String lower = line.toLowerCase();
            if (lower.startsWith("authorization: bearer ")) given = line.substring(21).trim();
            else if (lower.startsWith("x-mov-token:")) given = line.substring(12).trim();
        }
        return (given != null && given.equals(expected)) ? null : "UNAUTHORIZED";
    }

    /** R7：apiKey 掩码（保留前后 4 位，短 key 全掩）——mov.models.export 不再吐明文 Key。 */
    static String maskKey(String k) {
        return k != null && k.length() > 8
                ? k.substring(0, 4) + "****" + k.substring(k.length() - 4) : "****";
    }

    /** 响应头（R7：不含 Access-Control-Allow-Origin，CORS 收紧——不向任意来源开放） */
    static String responseHeader(int status, String statusText, byte[] body) {
        return "HTTP/1.1 " + statusText + "\r\nContent-Type: application/json;charset=UTF-8\r\n"
                + "Content-Length: " + body.length + "\r\n\r\n";
    }

    /** 读请求头字节块 (到 \r\n\r\n, 上限 16KB) */
    private static String readHead(java.io.InputStream in) throws java.io.IOException {
        java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
        int b, matched = 0;
        int[] end = {'\r', '\n', '\r', '\n'};
        while ((b = in.read()) != -1) {
            buf.write(b);
            matched = (b == end[matched]) ? matched + 1 : (b == '\r' ? 1 : 0);
            if (matched == 4) {
                byte[] raw = buf.toByteArray();
                return new String(raw, 0, raw.length - 4, "UTF-8");
            }
            if (buf.size() > 16384) return null;
        }
        return null;
    }

    /** 精确读 n 字节 (EOF 提前结束返回已读部分; n<=0 返回空数组) */
    private static byte[] readFully(java.io.InputStream in, int n) throws java.io.IOException {
        if (n <= 0) return new byte[0];
        java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream(n);
        byte[] tmp = new byte[Math.min(n, 8192)];
        int off = 0;
        while (off < n) {
            int r = in.read(tmp, 0, Math.min(tmp.length, n - off));
            if (r < 0) break;
            buf.write(tmp, 0, r);
            off += r;
        }
        return buf.toByteArray();
    }

    // ── JSON-RPC 分发 ──

    private String dispatch(String json) {
        try {
            JSONObject req = new JSONObject(json);
            String method = req.optString("method", "");
            Object id = req.opt("id");

            switch (method) {
                case "tools/list":
                    return rpcOk(id, listTools());
                case "tools/call":
                    return callTool(req.optJSONObject("params"), id);
                default:
                    return rpcErr(id, -32601, "未知方法: " + method);
            }
        } catch (Exception e) {
            return rpcErr(null, -32700, "JSON 解析失败: " + e.getMessage());
        }
    }

    // ── tools/list ──

    private JSONObject listTools() throws Exception {
        JSONArray arr = new JSONArray();
        for (ToolDescriptor t : tools.values()) {
            arr.put(t.toJson());
        }
        return new JSONObject().put("tools", arr);
    }

    // ── tools/call ──

    private String callTool(JSONObject params, Object id) {
        if (params == null) return rpcErr(id, -32602, "缺少 params");
        String name = params.optString("name", "");
        JSONObject args = params.optJSONObject("args");
        if (args == null) args = params.optJSONObject("arguments");  // BUG-2: 兼容 MCP 标准键

        ToolDescriptor td = tools.get(name);
        if (td == null) return rpcErr(id, -32602, "未知工具: " + name);

        try {
            // 模型管理工具：直接处理，不需要反射
            if (name.startsWith("mov.models.")) {
                return handleModelTool(name, args, id);
            }
            // 构建参数数组
            Object[] argValues = new Object[td.paramNames.length];
            for (int i = 0; i < td.paramNames.length; i++) {
                String pn = td.paramNames[i];
                if (args != null && args.has(pn)) {
                    argValues[i] = args.get(pn);
                } else {
                    argValues[i] = null;
                }
            }
            // BUG-13b: 必填参数缺参→拒绝，防止 null 传入 UI 方法导致主线程崩溃
            for (int i = 0; i < td.paramNames.length; i++) {
                if (argValues[i] == null) {
                    return rpcErr(id, -32602, "缺少必填参数: " + td.paramNames[i]);
                }
            }
            // 所有参数统一转 String（Bridge 方法都是 String 参数）
            for (int i = 0; i < argValues.length; i++) {
                if (!(argValues[i] instanceof String)) {
                    argValues[i] = String.valueOf(argValues[i]);
                }
            }

            Object result = td.method.invoke(bridge, argValues);
            String content = result instanceof String ? (String) result : String.valueOf(result);
            return rpcOk(id, new JSONObject().put("content", content != null ? content : ""));
        } catch (Exception e) {
            return rpcErr(id, -32000, "工具执行失败: " + e.getMessage());
        }
    }

    // ── 模型管理工具处理 ──

    private String handleModelTool(String name, JSONObject args, Object id) {
        try {
            com.hermes.android.model.ModelRegistry reg =
                com.hermes.android.model.ModelRegistry.getInstance(bridge.getActivity());
            switch (name) {
                case "mov.models.list": {
                    JSONArray arr = new JSONArray();
                    for (com.hermes.android.model.ModelConfig c : reg.list()) {
                        JSONObject o = new JSONObject();
                        o.put("id", c.id);
                        o.put("provider", c.provider);
                        o.put("name", c.name);
                        o.put("model", c.model);
                        o.put("baseUrl", c.baseUrl != null ? c.baseUrl : "");
                        o.put("hasKey", c.apiKey != null && !c.apiKey.isEmpty());
                        o.put("isDefault", c.isDefault);
                        o.put("enabled", c.enabled);
                        o.put("role", c.role != null ? c.role : "通用");
                        arr.put(o);
                    }
                    return rpcOk(id, new JSONObject().put("content", arr.toString(2)).put("models", arr).put("count", arr.length()));
                }
                case "mov.models.get": {
                    String mid = args != null ? args.optString("id", "") : "";
                    com.hermes.android.model.ModelConfig mc = mid.isEmpty() ? reg.getDefault() : reg.get(mid);
                    if (mc == null) return rpcErr(id, -32602, "模型不存在: " + mid);
                    JSONObject o = new JSONObject();
                    o.put("id", mc.id);
                    o.put("provider", mc.provider);
                    o.put("name", mc.name);
                    o.put("model", mc.model);
                    o.put("baseUrl", mc.baseUrl != null ? mc.baseUrl : "");
                    o.put("hasKey", mc.apiKey != null && !mc.apiKey.isEmpty());
                    o.put("isDefault", mc.isDefault);
                    o.put("role", mc.role != null ? mc.role : "通用");
                    return rpcOk(id, new JSONObject().put("content", o.toString(2)).put("model", o));
                }
                case "mov.models.export": {
                    /* R7 脱敏：exportModels 吐明文 apiKey，掩码后返回（保留前后 4 位） */
                    JSONArray raw = new JSONArray(
                        ((com.hermes.android.HermesApplication) bridge.getActivity().getApplicationContext())
                            .exportModels());
                    for (int i = 0; i < raw.length(); i++) {
                        JSONObject o = raw.optJSONObject(i);
                        if (o != null && o.has("apiKey")) {
                            o.put("apiKey", maskKey(o.optString("apiKey", "")));
                        }
                    }
                    return rpcOk(id, new JSONObject().put("content", raw.toString(2))
                            .put("models", raw).put("count", raw.length()));
                }
                default:
                    return rpcErr(id, -32601, "未知模型工具: " + name);
            }
        } catch (Exception e) {
            return rpcErr(id, -32000, "模型工具执行失败: " + e.getMessage());
        }
    }

    // ── JSON-RPC 响应格式 ──

    private String rpcOk(Object id, JSONObject result) {
        try {
            JSONObject r = new JSONObject().put("jsonrpc", "2.0").put("id", id).put("result", result);
            return r.toString();
        } catch (Exception e) { return "{}"; }
    }

    private String rpcErr(Object id, int code, String msg) {
        try {
            JSONObject err = new JSONObject().put("code", code).put("message", msg);
            JSONObject r = new JSONObject().put("jsonrpc", "2.0").put("id", id).put("error", err);
            return r.toString();
        } catch (Exception e) { return "{}"; }
    }

    // ── 工具描述符 ──

    static class ToolDescriptor {
        final String name;
        final Method method;
        final String[] paramNames;
        String desc;

        ToolDescriptor(String name, Method method, String[] paramNames) {
            this.name = name;
            this.method = method;
            this.paramNames = paramNames;
            this.desc = name;
        }

        ToolDescriptor withDesc(String d) { this.desc = d; return this; }

        static ToolDescriptor from(Method m) {
            String name = m.getName();
            java.lang.reflect.Parameter[] params = m.getParameters();
            String[] pn = new String[params.length];
            for (int i = 0; i < params.length; i++) {
                pn[i] = params[i].getName();
                // 反射可能拿不到参数名（编译未开 -parameters），用位置名兜底
                if (pn[i] == null || pn[i].startsWith("arg")) {
                    pn[i] = "arg" + i;
                }
            }
            return new ToolDescriptor(name, m, pn);
        }

        JSONObject toJson() throws Exception {
            JSONObject j = new JSONObject();
            j.put("name", name);
            j.put("description", desc != null ? desc : name);
            JSONObject inputSchema = new JSONObject();
            inputSchema.put("type", "object");
            JSONObject props = new JSONObject();
            for (String p : paramNames) {
                props.put(p, new JSONObject().put("type", "string"));
            }
            inputSchema.put("properties", props);
            j.put("inputSchema", inputSchema);
            return j;
        }
    }
}
