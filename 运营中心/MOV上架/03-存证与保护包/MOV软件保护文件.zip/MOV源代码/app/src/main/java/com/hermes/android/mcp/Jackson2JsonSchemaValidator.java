package com.hermes.android.mcp;

import io.modelcontextprotocol.json.schema.JsonSchemaValidator;

import java.util.Map;

/**
 * MCP Java SDK 的 JsonSchemaValidator 最小实现（Jackson 2）。
 * P1 spike 先最小校验（type=object 需 Map）；P2 可强化（properties/required 逐字段）。
 */
public class Jackson2JsonSchemaValidator implements JsonSchemaValidator {

    @Override
    public ValidationResponse validate(Map<String, Object> schema, Object instance) {
        Object t = schema != null ? schema.get("type") : null;
        if ("object".equals(t) && !(instance instanceof Map)) {
            return ValidationResponse.asInvalid("expected object but got " + instance.getClass().getSimpleName());
        }
        return ValidationResponse.asValid("ok");
    }
}
