package com.hermes.android;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.hermes.android.bridge.BridgeValidator;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;

/**
 * HtmlViewerActivity — 房间产出物全屏查看器 + 全屏 HTML 交互微调（feat/fullscreen-html 核心）。
 *
 * 原有（发送到桌面 §CONTRACT_STORAGE）：
 * - 桌面快捷方式/显式 Intent 拉起, extras 带 roomId + 文件相对路径, 从 StorageManager 磁盘加载全屏展示。
 * - 安全: roomId/path 过 BridgeValidator; canonical 限 work 目录; URL 白名单; 不注册桥。
 *
 * 核心新增（编辑模式，借鉴 htmltool2 contenteditable）：
 * - 顶栏「✎ 微调」→ 开 contenteditable（点文字直接编辑）+ 工具条（背景色/文字色/保存/完成）。
 * - 「保存」→ document.documentElement.outerHTML 写回房间产出文件（HTML 内容更新，物理文件不变）。
 * - 「完成」→ 关闭返回。
 */
public class HtmlViewerActivity extends AppCompatActivity {

    public static final String EXTRA_ROOM_ID = "roomId";
    public static final String EXTRA_PATH = "path";

    private static final int BG = Color.parseColor("#0F172A");
    private static final int INK = Color.parseColor("#E2E8F0");
    private static final int INK_DIM = Color.parseColor("#94A3B8");
    private static final int ACCENT = Color.parseColor("#1783FF");

    private WebView web;
    private File workDir;
    private File target;          /* 产出文件（保存写回用） */
    private LinearLayout toolbar; /* 编辑工具条 */
    private boolean editing = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /* 全屏沉浸 (系统栏手势划出) */
        WindowInsetsControllerCompat ctrl =
                new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView());
        ctrl.hide(WindowInsetsCompat.Type.systemBars());
        ctrl.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        /* 解析 + 校验参数 */
        String roomId = getIntent().getStringExtra(EXTRA_ROOM_ID);
        String path = getIntent().getStringExtra(EXTRA_PATH);
        target = null;
        String errMsg = null;
        if (roomId == null || BridgeValidator.checkRoomId(roomId) != null) {
            errMsg = "非法的房间标识";
        } else if (path == null || BridgeValidator.checkPath(path) != null) {
            errMsg = "非法的文件路径";
        } else {
            StorageManager sm = new StorageManager(this);
            workDir = new File(sm.getBaseDir(), "rooms/" + roomId + "/files/work");
            target = sm.resolveWorkFile(roomId, path);
            if (target == null) errMsg = "文件不存在或已被删除";
        }

        /* UI: 顶栏（返回+标题+微调）+ 编辑工具条 + 全屏 WebView */
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int padH = dp(12);
        bar.setPadding(padH, dp(6), padH, dp(6));
        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(INK);
        back.setTextSize(26);
        back.setPadding(dp(4), 0, dp(12), 0);
        back.setOnClickListener(v -> finish());
        TextView title = new TextView(this);
        title.setText(path != null ? new File(path).getName() : "");
        title.setTextColor(INK);
        title.setTextSize(13);
        title.setMaxLines(1);
        title.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        bar.addView(back, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        bar.addView(title, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        /* 核心: 「✎ 微调」→ 开 contenteditable 编辑模式 */
        TextView edit = new TextView(this);
        edit.setText("✎ 微调");
        edit.setTextColor(ACCENT);
        edit.setTextSize(13);
        edit.setPadding(dp(4), dp(2), dp(6), dp(2));
        edit.setOnClickListener(v -> toggleEdit());
        bar.addView(edit, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(bar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        /* 编辑工具条（编辑模式显示） */
        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(padH, dp(2), padH, dp(2));
        toolbar.setVisibility(View.GONE);
        toolbar.addView(toolBtn("🎨 背景", () -> setPageColor(true)));
        toolbar.addView(toolBtn("🎨 文字", () -> setPageColor(false)));
        toolbar.addView(toolBtn("💾 保存", () -> saveHtml()));
        toolbar.addView(toolBtn("✓ 完成", () -> finish()));
        root.addView(toolbar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        web = new WebView(this);
        web.setBackgroundColor(BG);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);      /* 游戏逻辑需要 */
        s.setDomStorageEnabled(true);      /* 游戏 localStorage (存档/最高分) */
        s.setAllowFileAccess(true);        /* 加载 file:// 目标文件必需 */
        s.setAllowContentAccess(false);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                /* URL 白名单: 仅放行 work 目录内 file:// 导航 (与 HermesActivity 同思路) */
                return !isAllowedUrl(url);
            }
        });
        /* 必须显式设置 WebChromeClient — 否则 WebView 静默吞掉 alert()
           (游戏"游戏结束"提示依赖它); 默认实现即可, 纯展示不注册桥 */
        web.setWebChromeClient(new android.webkit.WebChromeClient());
        root.addView(web, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        if (errMsg != null) {
            showError(errMsg);
        } else {
            /* 多文件 HTML 项目支持: 经 RoomStaticServer (127.0.0.1:8787) http 加载,
               file:// 页面无法执行 file:// JS 子资源 (Chromium 硬限制), http 无此限制 */
            String url = "http://127.0.0.1:" + com.hermes.android.serve.RoomStaticServer.PORT
                    + "/rooms/" + roomId + "/files/work/"
                    + android.net.Uri.encode(path, "/");
            web.loadUrl(url);
        }
    }

    /** 工具条按钮（小字文本按钮） */
    private TextView toolBtn(String label, Runnable action) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setTextColor(INK);
        b.setTextSize(12);
        b.setPadding(dp(8), dp(4), dp(8), dp(4));
        b.setOnClickListener(v -> action.run());
        return b;
    }

    /* ============ 核心: 编辑模式（全屏 HTML 交互微调） ============ */

    /** 切换 contenteditable 编辑模式 + 显隐工具条 */
    private void toggleEdit() {
        editing = !editing;
        toolbar.setVisibility(editing ? View.VISIBLE : View.GONE);
        web.evaluateJavascript(
                "document.body.setAttribute('contenteditable','" + (editing ? "true" : "false") + "');"
                        + "(document.body.style.outline = '" + (editing ? "1px dashed #1783FF" : "none") + "');",
                null);
        Toast.makeText(this, editing ? "编辑模式：点文字直接修改" : "已退出编辑", Toast.LENGTH_SHORT).show();
    }

    /** 调色：背景/文字色轮换（预设深/浅色，借鉴 htmltool2 调色） */
    private void setPageColor(boolean bg) {
        // 轮换：按当前颜色 → 下个预设色
        web.evaluateJavascript(
                "(function(){var cur=getComputedStyle(document.body)['"
                        + (bg ? "background-color" : "color") + "'];"
                        + "var cols=['#1E293B','#FFFFFF','#F1F5F9','#0F172A'];"
                        + "var i=cols.findIndex(c=>c.toLowerCase()===cur);"
                        + "document.body.style['" + (bg ? "background" : "color") + "']=cols[(i+1)%cols.length];})()",
                null);
    }

    /** 保存：取 document.documentElement.outerHTML 写回产出文件 */
    private void saveHtml() {
        web.evaluateJavascript("document.documentElement.outerHTML", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                String html = com.hermes.android.browser.JsStringCodec.unescapeJsString(value);
                if (html == null || html.isEmpty() || target == null) {
                    Toast.makeText(HtmlViewerActivity.this, "保存失败：取不到内容", Toast.LENGTH_SHORT).show();
                    return;
                }
                try (FileOutputStream fos = new FileOutputStream(target)) {
                    fos.write(html.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(HtmlViewerActivity.this, "已保存 ✓（内容已更新，物理文件不变）",
                            Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(HtmlViewerActivity.this, "保存失败: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    /**
     * URL 白名单: 放行本机房间静态服务 (http://127.0.0.1:8787, 多文件项目内链接/子资源导航)
     * + work 目录内 file:// (兼容路径); 其余 http/https/外网/其他 file 一律拦截。
     */
    private boolean isAllowedUrl(String url) {
        if (url == null) return false;
        if (url.startsWith("http://127.0.0.1:" + com.hermes.android.serve.RoomStaticServer.PORT + "/")) {
            return true;
        }
        if (!url.startsWith("file://") || workDir == null) return false;
        try {
            File req = new File(new URI(url)).getCanonicalFile();
            String base = workDir.getCanonicalFile().getPath();
            return req.getPath().equals(base) || req.getPath().startsWith(base + File.separator);
        } catch (Exception e) {
            return false;
        }
    }

    private void showError(String msg) {
        String html = "<!DOCTYPE html><html><head><meta charset='utf-8'>"
                + "<meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                + "<body style='margin:0;background:#0F172A;color:#94A3B8;display:flex;"
                + "flex-direction:column;align-items:center;justify-content:center;height:100vh;"
                + "font-family:sans-serif;text-align:center;padding:24px'>"
                + "<div style='font-size:40px;margin-bottom:16px'>⚠</div>"
                + "<div style='font-size:15px;line-height:1.8'>" + escapeHtml(msg) + "</div>"
                + "<div style='font-size:12px;margin-top:12px;color:#64748B'>回房间重新生成或重新发送到桌面</div>"
                + "</body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    private static String escapeHtml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            if (web.getParent() instanceof android.view.ViewGroup) {
                ((android.view.ViewGroup) web.getParent()).removeView(web);
            }
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
