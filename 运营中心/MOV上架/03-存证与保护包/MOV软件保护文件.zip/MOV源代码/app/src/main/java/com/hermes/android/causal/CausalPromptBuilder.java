package com.hermes.android.causal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 因果记忆提示词注入段（DESIGN_MEMORY_LAYERS 律②"稳定前缀 + 冻结注入"的因果实现）。
 *
 * 输出 ≤maxLines 行 markdown：活性逻辑钩子（freshness≥0.3）+ 高强度关联对（strength≥0.5）
 * + 到期提醒（dateAfter checkDue）。空/异常返回空串（注入方 null-safe 拼接）。
 * 纯 Java，零 android 依赖。
 */
public final class CausalPromptBuilder {

    private CausalPromptBuilder() {}

    public static String build(CausalEngine engine, String roomId, int maxLines) {
        if (engine == null) return "";
        try {
            JSONObject q = engine.query(roomId, 20);
            List<String> lines = new ArrayList<>();

            // 工单22 幕一: 最近具体因果事实（优先注入——模型被问「张三欠我钱吗」需看到事实本体
            // 「我借给张三 500」，只注入规则/关联抽象层答不上来）。取最近 5 条，按时间倒序。
            try {
                org.json.JSONArray events = engine.journal().eventsOfType(
                        roomId, com.hermes.android.agent.Journal.TYPE_CAUSAL_EVENT);
                int shown = 0;
                for (int i = events.length() - 1; i >= 0 && shown < 5 && lines.size() < maxLines; i--) {
                    org.json.JSONObject ev = events.optJSONObject(i);
                    if (ev == null) continue;
                    org.json.JSONObject p = ev.optJSONObject("payload");
                    if (p == null) continue;
                    String subj = p.optString("subject", "");
                    String pred = p.optString("predicate", "");
                    String obj = p.optString("object", "");
                    if (subj.isEmpty() || pred.isEmpty()) continue;
                    String t = p.optString("t", "");
                    String line = "- 事实:" + subj + " " + pred + " " + obj
                            + (t.isEmpty() ? "" : "（" + t + "）");
                    org.json.JSONObject meta = p.optJSONObject("meta");
                    if (meta != null) {
                        if (meta.has("amount")) line += " 金额 " + meta.optString("amount");
                        if (meta.has("dueDate")) line += " 到期 " + meta.optString("dueDate");
                    }
                    lines.add(line);
                    shown++;
                }
            } catch (Exception ignored) {}

            // 活性逻辑钩子
            JSONArray rules = q.optJSONArray("rules");
            if (rules != null) {
                for (int i = 0; i < rules.length() && lines.size() < maxLines; i++) {
                    JSONObject rule = rules.optJSONObject(i);
                    double freshness = rule.optDouble("freshness", 0);
                    if (freshness >= 0.3) {
                        lines.add("- 规则:" + rule.optString("label", rule.optString("ruleId", ""))
                                + "（活跃度 " + Math.round(freshness * 100) + "%）");
                    }
                }
            }

            // 高强度关联
            JSONArray links = q.optJSONArray("links");
            if (links != null) {
                for (int i = 0; i < links.length() && lines.size() < maxLines; i++) {
                    JSONObject l = links.optJSONObject(i);
                    double strength = l.optDouble("strength", 0);
                    if (strength >= 0.5) {
                        lines.add("- 关联:" + l.optString("a") + " ↔ " + l.optString("b")
                                + "（强度 " + Math.round(strength * 100) + "%）");
                    }
                }
            }

            // 到期提醒（只读 checkDue，无副作用）
            JSONArray due = engine.checkDue(roomId);
            if (due != null) {
                for (int i = 0; i < due.length() && lines.size() < maxLines; i++) {
                    JSONObject a = due.optJSONObject(i);
                    lines.add("- ⏰提醒:" + a.optString("alert", a.optString("label", "")));
                }
            }

            if (lines.isEmpty()) return "";
            StringBuilder sb = new StringBuilder("【因果记忆】\n");
            for (String line : lines) sb.append(line).append('\n');
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }
}
