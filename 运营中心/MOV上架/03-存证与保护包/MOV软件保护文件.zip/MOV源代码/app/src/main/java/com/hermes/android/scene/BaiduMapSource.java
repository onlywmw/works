package com.hermes.android.scene;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * 百度地图数据源（对齐官方 mcp-server-baidu-maps map.py）。
 *
 * HTTP 走 MOV 本体 Java HttpURLConnection（国内服务 api.map.baidu.com，国内网络直连），
 * 响应透传原始 JSON（官方实现即返回 response.text）。AK 从 SharedPreferences("baidu_map_prefs")
 * 读取（BAIDU_MAPS_API_KEY），未配置时构造抛异常 → 工具 checkFn 拦截，不注入。
 *
 * 单测零网络：url/params 组装走纯函数，不真发请求。
 */
public class BaiduMapSource {

    private static final String API_URL = "https://api.map.baidu.com";
    private static final String PREFS = "baidu_map_prefs";
    private static final String KEY_AK = "ak";

    private final String ak;

    public BaiduMapSource(Context ctx) throws Exception {
        String k = loadAk(ctx);
        if (k == null || k.isEmpty()) throw new Exception("百度地图 AK 未配置");
        this.ak = k;
    }

    /** 测试注入 AK。 */
    public BaiduMapSource(String ak) {
        this.ak = ak == null ? "" : ak;
    }

    /** 读取已配置 AK。 */
    public static String loadAk(Context ctx) {
        try {
            SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            return p.getString(KEY_AK, "");
        } catch (Exception e) { return ""; }
    }

    /** 保存 AK（设置页用）。 */
    public static void saveAk(Context ctx, String ak) {
        try {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_AK, ak == null ? "" : ak).apply();
        } catch (Exception ignored) {}
    }

    public boolean hasAk() { return ak != null && !ak.isEmpty(); }

    // ══════════ 请求层 ══════════

    /** 统一 GET：path + params → 百度 JSON。status!=0 抛异常（mask AK）。 */
    public JSONObject get(String path, java.util.Map<String, String> params) throws Exception {
        StringBuilder url = new StringBuilder(API_URL).append(path).append("?ak=").append(enc(ak))
            .append("&output=json&from=mcp");
        if (params != null) {
            for (java.util.Map.Entry<String, String> e : params.entrySet()) {
                if (e.getValue() != null && !e.getValue().isEmpty()) {
                    url.append("&").append(e.getKey()).append("=").append(enc(e.getValue()));
                }
            }
        }
        String body = httpGet(url.toString());
        if (body == null) throw new Exception("HTTP request failed");
        JSONObject result = new JSONObject(body);
        if (result.optInt("status", -1) != 0) {
            String msg = result.optString("message", "unknown error");
            throw new Exception("API error: " + maskAk(msg));
        }
        return result;
    }

    /** 统一 POST（form-encoded）。poi_extract 双段提交用。 */
    public JSONObject post(String path, java.util.Map<String, String> params) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(API_URL + path).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(10000);
        c.setRequestMethod("POST");
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        c.setDoOutput(true);
        StringBuilder body = new StringBuilder();
        body.append("ak=").append(enc(ak)).append("&from=mcp");
        if (params != null) {
            for (java.util.Map.Entry<String, String> e : params.entrySet()) {
                if (e.getValue() != null && !e.getValue().isEmpty()) {
                    body.append("&").append(e.getKey()).append("=").append(enc(e.getValue()));
                }
            }
        }
        OutputStream os = c.getOutputStream();
        os.write(body.toString().getBytes("UTF-8"));
        os.close();
        int code = c.getResponseCode();
        if (code != 200) { c.disconnect(); throw new Exception("HTTP " + code); }
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close(); c.disconnect();
        JSONObject result = new JSONObject(sb.toString());
        if (result.optInt("status", -1) != 0) {
            String msg = result.optString("message", "unknown error");
            throw new Exception("API error: " + maskAk(msg));
        }
        return result;
    }

    static String httpGet(String urlStr) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
            c.setConnectTimeout(8000); c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            int code = c.getResponseCode();
            if (code != 200) return null;
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close(); c.disconnect();
            return sb.toString();
        } catch (Exception e) {
            // 不调 Log：单测零网络环境 Log 未 mock；失败路径返回 null，由调用方归因
            return null;
        }
    }

    static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; }
    }

    /** 响应中出现的 AK 打码（官方 mask_api_key）。 */
    String maskAk(String text) {
        if (text == null || text.isEmpty() || ak.isEmpty()) return text;
        if (!text.contains(ak)) return text;
        String masked;
        if (ak.length() <= 8) {
            masked = ak.substring(0, 2) + "****" + ak.substring(ak.length() - 2);
        } else {
            masked = ak.substring(0, 4) + "****" + ak.substring(ak.length() - 4);
        }
        return text.replace(ak, masked);
    }

    // ══════════ 工具（透传百度 JSON，浅参数校验） ══════════

    public JSONObject geocode(String address, String isChina) throws Exception {
        return get(isChina != null && !"true".equals(isChina) ? "/api_geocoding_abroad/v1/" : "/geocoding/v3/",
            map("address", address));
    }

    public JSONObject reverseGeocode(String lat, String lng) throws Exception {
        return get("/reverse_geocoding/v3/",
            map("location", lat + "," + lng, "extensions_road", "true", "extensions_poi", "1"));
    }

    public JSONObject searchPlaces(String query, String tag, String region, String location, String radius, String isChina) throws Exception {
        boolean china = isChina == null || "true".equals(isChina);
        java.util.Map<String, String> params = new java.util.HashMap<>();
        params.put("query", query);
        params.put("type", tag);
        params.put("region_limit", "true");
        params.put("scope", "2");
        if (location != null && !location.isEmpty()) { params.put("location", location); params.put("radius", radius); }
        else if (region != null && !region.isEmpty()) params.put("region", region);
        else params.put("region", "全国");
        if (china) {
            return get((location != null && !location.isEmpty()) ? "/place/v3/around" : "/place/v3/region", params);
        }
        String path = "/place_abroad/v1/search";
        return get(path, params);
    }

    public JSONObject placeDetails(String uid, String isChina) throws Exception {
        boolean china = isChina == null || "true".equals(isChina);
        return get(china ? "/place/v2/detail" : "/place_abroad/v1/detail", map("uid", uid));
    }

    public JSONObject directionsMatrix(String origins, String destinations, String model) throws Exception {
        String m = (model == null || model.isEmpty()) ? "driving" : model;
        return get("/routematrix/v2/" + m, map("origins", origins, "destinations", destinations));
    }

    public JSONObject directions(String model, String origin, String destination, String isChina) throws Exception {
        String m = (model == null || model.isEmpty()) ? "driving" : model;
        boolean china = isChina == null || "true".equals(isChina);
        return get(china ? "/directionlite/v1/" + m : "/direction_abroad/v1/" + m,
            map("origin", origin, "destination", destination));
    }

    public JSONObject weather(String location, String districtId, String isChina) throws Exception {
        boolean china = isChina == null || "true".equals(isChina);
        java.util.Map<String, String> params = new java.util.HashMap<>();
        params.put("data_type", "all");
        if (location != null && !location.isEmpty()) params.put("location", location);
        else params.put("district_id", districtId);
        return get(china ? "/weather/v1/?" : "/weather_abroad/v1/?", params);
    }

    public JSONObject ipLocation(String ip) throws Exception {
        return get("/location/ip", map("ip", ip));
    }

    public JSONObject roadTraffic(String model, String roadName, String city, String bounds, String vertexes, String center, String radius) throws Exception {
        java.util.Map<String, String> params = new java.util.HashMap<>();
        String m = model == null ? "" : model;
        if ("bound".equals(m)) params.put("bounds", bounds);
        else if ("polygon".equals(m)) params.put("vertexes", vertexes);
        else if ("around".equals(m)) { params.put("center", center); params.put("radius", radius); }
        else if ("road".equals(m)) { params.put("road_name", roadName); params.put("city", city); }
        return get("/traffic/v1/" + m + "?", params);
    }

    /** POI 智能提取：submit + 轮询 result（最多 5 次，间隔 2s）。 */
    public JSONObject poiExtract(String textContent) throws Exception {
        JSONObject submit = post("/api_mark/v1/submit",
            map("id", "0", "msg_type", "text", "text_content", textContent));
        String mapId = submit.optJSONObject("result") != null
            ? submit.optJSONObject("result").optString("map_id") : "";
        if (mapId.isEmpty()) throw new Exception("未找到 map_id");
        Exception last = null;
        for (int attempt = 0; attempt < 5; attempt++) {
            try {
                JSONObject result = post("/api_mark/v1/result",
                    map("id", "0", "map_id", mapId));
                if (result.optInt("status", -1) == 0 && !result.isNull("result")
                        && result.optJSONObject("result") != null) {
                    return result;
                }
            } catch (Exception e) { last = e; }
            try { Thread.sleep(2000); } catch (Exception ignored) {}
        }
        throw new Exception(last != null ? "POI 提取超时: " + last.getMessage() : "POI 提取超时");
    }

    static java.util.Map<String, String> map(String... kv) {
        java.util.Map<String, String> m = new java.util.HashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            if (kv[i + 1] != null) m.put(kv[i], kv[i + 1]);
        }
        return m;
    }
}
