/* ============================================================
   mov-render.js — MOV Kernel 投影渲染器 (P2: 切真数据)
   journal 事件 → DOM 投影; transient → 打字机。
   seq 去重; 终态清瞬态; 切房清瞬态; 非当前房间不渲染。
   P2: replayEvents 批量回放 + 交互按钮 (计划闸/ask/写入/shell/暂停)。
   ============================================================ */
var MovRender = (function(){
  var _renderedSeqs = {};
  var _activeRoom = null;
  var _transient = {};
  var _endedTasks = {};
  var _container = null;   // 渲染目标 (chatBody)
  var _scrollEl  = null;   // 滚动目标 (chatPane, 真正的 overflow-y:auto 容器)
  var _replayMode = false;
  var _startupBuf = [];     // 启动期缓冲: 容器就绪前暂存事件, init() 后 flush

  /* ---------- 生命周期 ---------- */
  function init(containerId, scrollElId) {
    /* 找不到新元素时保留旧容器——防止 init('cardPane') 在元素未创建时把 chatBody 容器清掉 */
    _container = document.getElementById(containerId) || _container;
    if (!_container) return;
    /* 专家新脸化: 滚动容器可注入 (缺省 chatPane, 老行为不变) */
    _scrollEl = (scrollElId && document.getElementById(scrollElId)) || document.getElementById('chatPane');
    if (window._movOn) { window._movOn('journal', onJournal); window._movOn('transient', onTransient); }
    // 启动期缓冲 flush: 容器就绪后回放已缓冲事件
    if (_startupBuf.length > 0) {
      console.warn('MovRender: flushing ' + _startupBuf.length + ' buffered startup events');
      var buf = _startupBuf;
      _startupBuf = [];
      buf.forEach(function(ev) { renderJournalEvent(ev); });
    }
  }
  function scrollToBottom() {
    if (!_scrollEl) return;
    var atBottom = _scrollEl.scrollHeight - _scrollEl.scrollTop - _scrollEl.clientHeight < 80;
    if (atBottom || _replayMode) _scrollEl.scrollTop = _scrollEl.scrollHeight;
  }
  function destroy() {
    window._movOff('journal', onJournal);
    window._movOff('transient', onTransient);
    clearAllTransient();
    _renderedSeqs = {};
    _startupBuf = [];
    _flushRetries = _flushMaxRetries; // 禁止后续 flush
    _activeRoom = null;
  }
  function setRoom(roomId) {
    _activeRoom = roomId;
    clearAllTransient();
  }
  function reset() {
    _renderedSeqs = {};
    clearAllTransient();
    _startupBuf = [];
    if (_container) _container.innerHTML = '';
  }

  /* ---------- P2: 批量回放 (enterRoom 用) ---------- */
  var _flushRetries = 0;
  var _flushMaxRetries = 30; // ~3s (30 × 100ms)

  function flushStartupBuf() {
    if (_startupBuf.length === 0) return;
    if (!_container) return;
    var buf = _startupBuf;
    _startupBuf = [];
    console.warn('MovRender: flushing ' + buf.length + ' buffered startup events');
    _replayMode = true;
    var rendered = 0;
    for (var i = 0; i < buf.length; i++) {
      var ev = buf[i];
      var seq = ev.seq;
      if (seq !== undefined && seq !== null) {
        if (_renderedSeqs[seq]) continue;
        _renderedSeqs[seq] = true;
      }
      renderJournalEvent(ev);
      rendered++;
    }
    _replayMode = false;
    console.warn('MovRender: flushed ' + rendered + '/' + buf.length + ' events');
    scrollToBottom();
  }

  function scheduleFlush() {
    if (_startupBuf.length === 0) return;
    _flushRetries = 0;
    var timer = setInterval(function() {
      _flushRetries++;
      /* 每 tick 重查 DOM: cardPane 可能稍后才创建, chatBody 兜底 */
      _container = document.getElementById('cardPane') || document.getElementById('chatBody') || _container;
      if (_container) {
        clearInterval(timer);
        flushStartupBuf();
      } else if (_flushRetries >= _flushMaxRetries) {
        clearInterval(timer);
        console.warn('MovRender: flush retries exhausted, dropping ' + _startupBuf.length + ' buffered events');
        _startupBuf = [];
      }
    }, 100);
  }

  function replayEvents(events) {
    _replayMode = true;
    // 启动期竞态: 容器未就绪 → 缓冲 + 轮询重试 flush
    if (!_container) {
      console.warn('MovRender: buffering ' + events.length + ' events (container not ready), scheduling retry');
      _startupBuf = _startupBuf.concat(events);
      scheduleFlush();
      return;
    }
    for (var i = 0; i < events.length; i++) {
      var ev = events[i];
      var seq = ev.seq;
      if (seq !== undefined && seq !== null) {
        if (_renderedSeqs[seq]) continue;
        _renderedSeqs[seq] = true;
      }
      renderJournalEvent(ev);
    }
    _replayMode = false;
    if (_container) scrollToBottom();
  }

  /* ---------- 实时事件 ---------- */
  function onJournal(roomId, event, envelope) {
    if (!_container || roomId !== _activeRoom) return;
    var seq = event.seq;
    if (seq !== undefined && seq !== null) {
      if (_renderedSeqs[seq]) return;
      _renderedSeqs[seq] = true;
    }
    renderJournalEvent(event);
    scrollToBottom();
  }

  function onTransient(roomId, event, envelope) {
    if (!_container || roomId !== _activeRoom) return;
    var taskId = event.taskId || '_default';
    if (_endedTasks[taskId]) return;
    var type = event.type || '';
    if (type === 'token') {
      var s = _transient[taskId];
      if (!s) { s = {text:'', chunks:[], thinking:false}; _transient[taskId] = s; }
      s.text += (event.text || event.delta || '');
      s.chunks.push(Date.now()); s.lastTs = Date.now();
      // 懒检测: 思考文本不进 DOM。不限长度——token 批次可能一次到 100+ 字
      if (!s.thinking && !s.notThinking) {
        var t = s.text.trim();
        if (/^(我们|需要|根据|注意|当前|因此|所以|但是|可以|应该|首先|现在|这里|这个|如果|因为|虽然|然而|于是|接着|然后|最后|最终|综上|总结|以上|以下|按照|对于|关于)/.test(t)) {
          s.thinking = true;
        } else if (t.length >= 20) {
          s.notThinking = true;  // 20字还不匹配→确认不是思考
        }
      }
      if (s.thinking) return;
      if (!s.el) { createTransientBubble(taskId, s); }
      renderTransient(s);
    } else if (type === 'typing') {
      var s2 = _transient[taskId];
      if (!s2) { s2 = {text:'', thinking:false}; _transient[taskId] = s2; }
      if (!s2.el) { createTransientBubble(taskId, s2); }
      s2.phase = 'typing';
      renderTransient(s2);
    }
  }

  /* ---------- 事件分发 ---------- */
  function renderJournalEvent(event) {
    var type = event.type || '';
    /* MCP 写入审批请求（P2 房间内确认闭环）：不走 _ 丢弃，渲染审批卡（批准/驳回） */
    if (type === '_mcp_approval_request') return renderMcpApprovalCard(event);
    /* P6: 忽略内部元事件 (_telemetry 等), 不进 UI */
    if (type.charAt(0) === '_') return;
    var p = event.payload || {};
    var actor = event.actor || 'kernel';
    var taskId = event.taskId;
    var seq = event.seq;
    var node = null;
    switch (type) {
      case 'user_input':
        /* 巡检#36 轻打回: 存量种子(actor=kernel 的 user_input) → AI 白卡, 剥 [type:] 前缀 */
        if (actor !== 'user') {
          node = appendMsg('agent', 'MOV', (p.text || '').replace(/^\s*\[[^\]]*\]\s*/, ''));
        } else {
          node = appendMsg('user', 'YOU', p.text || '');
        }
        break;
      // 成功静默，失败喧哗
      case 'phase': return null;
      case 'plan': node = renderPlan(p, taskId); break;
      case 'gate':
        if (p.state === 'approved' || p.state === 'rejected') return null;
        node = renderGate(p, taskId); break;
      /* 无感工作态: 工具调用可见 — tool_call 技能卡「调用中」, tool_result(带 name) 更新完成 */
      case 'tool_call': node = renderSkillCard(p, 'calling'); break;
      case 'step':
      case 'tool_result':
        /* Phase 3: 成功的步骤给计划卡打✓ */
        if (p.ok !== false && p.name && taskId) markStepDone(taskId, p.name);
        if (p.name) { node = updateSkillCard(p); break; }
        if (p.ok !== false) { node = renderStepLine(p); break; }
        node = renderToolResult(p); break;
      case 'note':
        // AI 内部思考过滤：不论 actor 是谁，内容像推理的就拦
        if (p.text && /^(我们|需要|根据|注意|当前|因此|所以|但是|可以|应该|首先|现在|这里|这个|如果|因为|虽然|然而|于是|接着|然后|最后|最终|综上|总结|以上|以下|按照|对于|关于)/.test(p.text.trim())) return null;
        if (p.text && p.text.indexOf('⏳') === 0) return null; // shell开始气泡
        node = renderNote(p, actor); break;
      case 'status': return null;
      case 'review': return null;
      case 'deliver': clearTransientForTask(taskId); node = renderDeliver(p); break;
      case 'fail': clearTransientForTask(taskId); node = renderFail(p); break;
      case 'stopped': clearTransientForTask(taskId); node = renderFail(p); break;
      case 'paused': node = renderPaused(p, taskId); break;
      case 'resumed': return null;
      case 'summary': return null;
      case 'understand': return null;
      case 'tombstone': removeBySeq(p.targetSeq); return;
      case 'reaction': renderReaction(p); return; /* 反应: 挂到目标消息上, 自身不占 DOM */
      default: node = appendSys('[' + type + ']'); break;
    }
    /* P2: data-seq 标记 (tombstone 删除用) */
    if (node && seq !== undefined && seq !== null) {
      node.setAttribute('data-seq', seq);
    }
  }

  /* ---------- DOM 构造 ---------- */
  function appendMsg(cls, who, text) {
    if (!_container) { return null; }  // 启动期竞态守卫（容器未就绪时静默丢弃，不抛异常）
    var d = document.createElement('div');
    d.className = 'msg ' + (cls === 'user' ? 'user' : 'agent');
    var w = document.createElement('div'); w.className = 'who'; w.textContent = who;
    var b = document.createElement('div'); b.className = 'bubble'; b.textContent = text;
    d.appendChild(w); d.appendChild(b);
    _container.appendChild(d);
    return d;
  }
  function appendSys(text) {
    if (!_container) { return null; }  // 启动期竞态守卫
    var d = document.createElement('div'); d.className = 'sysline'; d.textContent = text;
    _container.appendChild(d);
    return d;
  }

  /* 无感工作态: 技能调用卡 — 「⚡ 技能名 · 调用中→完成」一行小卡, 点开看详情 (数据真实) */
  function renderSkillCard(p, state) {
    if (!_container) return null;
    var d = document.createElement('div'); d.className = 'msg wide';
    var card = document.createElement('div'); card.className = 'skill-card';
    card.setAttribute('data-state', state === 'calling' ? 'calling' : (p.ok === false ? 'fail' : 'done'));
    if (p.name) card.setAttribute('data-tool', p.name);
    var line = document.createElement('div'); line.className = 'sline';
    var ic = document.createElement('span'); ic.className = 'sic'; ic.textContent = '⚡';
    var nm = document.createElement('span'); nm.className = 'sname'; nm.textContent = p.name || '工具';
    var st = document.createElement('span'); st.className = 'sst ' + (state === 'calling' ? 'calling' : (p.ok === false ? 'fail' : 'done'));
    st.textContent = state === 'calling' ? '调用中' : (p.ok === false ? '失败' : '完成');
    line.appendChild(ic); line.appendChild(nm); line.appendChild(st);
    card.appendChild(line);
    if (p.arg) { var ar = document.createElement('div'); ar.className = 'sarg'; ar.textContent = p.arg; card.appendChild(ar); }
    if (state !== 'calling' && p.summary) { var sm = document.createElement('div'); sm.className = 'ssum'; sm.textContent = p.summary; card.appendChild(sm); }
    d.appendChild(card);
    _container.appendChild(d);
    return d;
  }
  /* 更新最近同名「调用中」技能卡为完成/失败; 无 calling 卡(历史回放)直接渲染完成卡 */
  function updateSkillCard(p) {
    if (!_container) return null;
    var cards = _container.querySelectorAll('.skill-card[data-state="calling"]');
    var target = null;
    for (var i = cards.length - 1; i >= 0; i--) {
      if (!p.name || cards[i].getAttribute('data-tool') === p.name) { target = cards[i]; break; }
    }
    if (target) {
      target.setAttribute('data-state', p.ok === false ? 'fail' : 'done');
      var st = target.querySelector('.sst');
      if (st) { st.className = 'sst ' + (p.ok === false ? 'fail' : 'done'); st.textContent = p.ok === false ? '失败' : '完成'; }
      if (p.summary) { var sm = document.createElement('div'); sm.className = 'ssum'; sm.textContent = p.summary; target.appendChild(sm); }
      return null;
    }
    return renderSkillCard(p, 'done');
  }

  /* P2: tombstone 删除 — 按 data-seq 移除所有同 seq DOM 节点 */
  function removeBySeq(targetSeq) {
    if (!_container || targetSeq === undefined || targetSeq === null) return;
    var els = _container.querySelectorAll('[data-seq="' + targetSeq + '"]');
    for (var i = 0; i < els.length; i++) {
      if (els[i].parentNode) els[i].parentNode.removeChild(els[i]);
    }
  }

  /* P7: 消息反应 — 找到目标消息, 在下方追加/更新 emoji 行 */
  function renderReaction(p) {
    if (!_container) return;
    var target = _container.querySelector('[data-seq="' + (p.targetSeq || '') + '"]');
    if (!target) return; /* 目标消息不存在 (可能已被删除或尚未渲染) */
    var emoji = p.emoji || '👍';
    /* 查找或创建 reactions 行 */
    var row = target.querySelector('.rxns');
    if (!row) { row = document.createElement('div'); row.className = 'rxns'; target.appendChild(row); }
    /* 查找现有同 emoji 的 reaction */
    var existing = row.querySelector('[data-emoji="' + emoji + '"]');
    if (existing) {
      var count = parseInt(existing.getAttribute('data-count') || '1') + 1;
      existing.setAttribute('data-count', count);
      existing.textContent = emoji + ' ' + count;
    } else {
      var rxn = document.createElement('span');
      rxn.className = 'rxn';
      rxn.setAttribute('data-emoji', emoji);
      rxn.setAttribute('data-count', '1');
      rxn.textContent = emoji + ' 1';
      row.appendChild(rxn);
    }
  }

  /* note: actor 感知 — brain→agent 气泡, kernel→sysline */
  function renderNote(p, actor) {
    if (actor === 'brain') { return appendMsg('agent', 'MOV', p.text || ''); }
    else { return appendSys(p.text || ''); }
  }

  /* 结构化状态: running=开始, waiting=心跳, finished=完成(替换running行) */
  var _statusLines = {};
  function renderStatus(p) {
    var key = p.tool || "_";
    if (p.state === "running") {
      var el = appendSys("执行中: " + p.tool + (p.label || ""));
      _statusLines[key] = el; return el;
    }
    if (p.state === "waiting") {
      var old = _statusLines[key];
      var text = "等待中: " + p.tool + " · " + (p.elapsed || "?") + "s";
      if (old) { old.textContent = text; return old; }
      return appendSys(text);
    }
    if (p.state === "finished") {
      var prev = _statusLines[key];
      var text = (p.ok ? "✅" : "❌") + " " + p.tool
        + " (" + Math.round((p.durMs||0)/1000) + "s)" + (p.label||"");
      if (prev) { prev.textContent = text; _statusLines[key] = null; return prev; }
      return appendSys(text);
    }
    return null;
  }

  /* ---------- 计划卡 + 批准/驳回按钮 ---------- */
  /* Phase 3: 计划步骤跟踪 — taskId → [{name, done}] */
  var _planSteps = {};

  function markStepDone(taskId, toolName) {
    var steps = _planSteps[taskId]; if (!steps) return;
    for (var i = 0; i < steps.length; i++) {
      if (steps[i].done) continue;
      if (steps[i].name && toolName && steps[i].name.indexOf(toolName) >= 0) { steps[i].done = true; steps[i].li.innerHTML = '✓ ' + steps[i].li.textContent; steps[i].li.style.color = 'var(--ok)'; return; }
    }
  }

  function renderPlan(p, taskId) {
    var d = document.createElement('div'); d.className = 'msg wide';
    var card = document.createElement('div'); card.className = 'plan-card';
    var hd = document.createElement('div'); hd.className = 'ph';
    var steps = p.steps || [];
    var stepCount = steps.length || 0;
    hd.textContent = '执行计划' + (p.revised ? ' (修订)' : '') + ' · ' + stepCount + ' 步';
    var isRevised = p.revised === true;
    var tog = document.createElement('span');
    var startOpen = !isRevised;
    tog.textContent = startOpen ? ' ▾ 收起' : ' ▸ 展开';
    tog.className = 'pb-tog';
    hd.appendChild(tog);
    card.appendChild(hd);
    var body = document.createElement('div'); body.className = 'plan-body';
    if (!startOpen) body.style.display = 'none';
    body.style.maxHeight = '300px'; body.style.overflowY = 'auto';
    /* Phase 3: 步骤带 data-step-index, 支持逐条打✓ */
    var planTrack = [];
    if (steps.length) {
      var ol = document.createElement('ol'); ol.className = 'pb';
      steps.forEach(function(s, idx) {
        var li = document.createElement('li');
        li.setAttribute('data-step-index', idx);
        var text = s.desc || s.summary || s.text || '';
        if (!text && s.name && s.name !== 'tool.execute') text = s.name;
        if (!text && s.action && s.action !== 'tool.execute') text = s.action;
        /* №8: 命令原文折叠 — 主文本只留人话 desc/name, 命令存 dataset + 折叠子元素 */
        var cmdRaw = '';
        if (typeof s.args === 'string') cmdRaw = s.args;
        else if (s.args && s.args.cmd) cmdRaw = s.args.cmd;
        else if (s.path) cmdRaw = s.path;
        if (!text) text = JSON.stringify(s).substring(0, 80);
        /* 派单№5: 任务卡回显去重 — 计划步复述用户指令则弱化为「📌 目标」(样式区分, 不丢计划信息) */
        var goal = (window._agentLoop && window._agentLoop.goal) || '';
        if (goal && window.NewFaceExpert && NewFaceExpert.stepIsGoal(text, goal)) {
          li.className = 'step-goal';
          li.textContent = '📌 目标 · ' + text;
        } else {
          li.textContent = text;
        }
        if (cmdRaw) {
          li.setAttribute('data-cmd', cmdRaw);
          var cmdEl = document.createElement('span'); cmdEl.className = 'step-cmd';
          cmdEl.textContent = ' 命令 ▸';
          cmdEl.addEventListener('click', function(ev) {
            ev.stopPropagation();
            var b = cmdEl.querySelector('.cmd-body');
            if (b) { b.style.display = b.style.display === 'none' ? 'block' : 'none'; }
            else { var nb = document.createElement('div'); nb.className = 'cmd-body'; nb.textContent = cmdRaw; cmdEl.appendChild(nb); }
          });
          li.appendChild(cmdEl);
        }
        planTrack.push({name: s.name || s.action || '', done: false, li: li});
        ol.appendChild(li);
      });
      body.appendChild(ol);
      if (taskId) _planSteps[taskId] = planTrack;
    }
    /* №8: 「预估 ~Xk tokens · Ys」下掉 (机器内部信息不显示) */
    card.appendChild(body);
    tog.addEventListener('click', function(){
      if (body.style.display === 'none') { body.style.display = 'block'; tog.textContent = ' ▾ 收起'; }
      else { body.style.display = 'none'; tog.textContent = ' ▸ 展开'; }
    });
    /* Phase 3: 批准后按钮淡出, 内容保持展开 */
    if (!_replayMode && taskId) {
      var pf = document.createElement('div'); pf.className = 'pf';
      var bAp = document.createElement('button'); bAp.className = 'btn btn-acc'; bAp.textContent = '批准';
      var bRj = document.createElement('button'); bRj.className = 'btn btn-ghost'; bRj.textContent = '驳回';
      bAp.addEventListener('click', function() {
        bAp.disabled = true; bRj.disabled = true; bAp.textContent = '已批准';
        bAp.style.opacity = '0.5';
        if (window._agentLoop) _agentLoop.awaiting = null;
        if (window.restoreAgentInput) restoreAgentInput();
        B.postCmd({cmd:'gate_respond', taskId:taskId, roomId:_activeRoom, gate:'plan', approved:true});
        setTimeout(function(){ pf.style.opacity = '0'; setTimeout(function(){ pf.style.display = 'none'; }, 400); }, 600);
      });
      bRj.addEventListener('click', function() {
        bRj.disabled = true; bRj.style.opacity = '0.4';
        if (window.setAgentInputHint) setAgentInputHint('输入驳回意见后发送…');
      });
      pf.appendChild(bAp); pf.appendChild(bRj); card.appendChild(pf);
    }
    d.appendChild(card); _container.appendChild(d);
    return d;
  }

  /* ---------- 闸事件 (ask/fileWrite/shell/plan 响应) ---------- */
  /* MCP 写入审批卡（P2 房间内确认闭环）：读 _mcp_approval_request 渲染 tool/path + 批准/驳回，
     按钮 → B.query mcp.approvalRespond（BridgeKernel → McpApprovalGate.respond → 白名单更新 + _mcp_approval_result） */
  function renderMcpApprovalCard(event) {
    var p = event.payload || {};
    var rid = p.requestId || '';
    var tool = p.tool || '';
    var path = p.path || '*';
    if (!rid) return null;
    var d = document.createElement('div'); d.className = 'msg wide';
    var card = document.createElement('div'); card.className = 'plan-card';
    var hd = document.createElement('div'); hd.className = 'ph'; hd.textContent = 'MCP 写入审批';
    card.appendChild(hd);
    var q = document.createElement('div'); q.className = 'reason';
    q.textContent = '工具 ' + tool + ' · 路径 ' + path + ' 请求写权限（批准后客户端重试该调用）';
    card.appendChild(q);
    if (!_replayMode) {
      var pf = document.createElement('div'); pf.className = 'pf';
      var bOk = document.createElement('button'); bOk.className = 'btn btn-acc'; bOk.textContent = '批准';
      var bRj = document.createElement('button'); bRj.className = 'btn btn-ghost'; bRj.textContent = '驳回';
      bOk.addEventListener('click', function() {
        bOk.disabled = true; bRj.disabled = true; bOk.textContent = '已批准 ✓';
        B.query({q:'mcp.approvalRespond', requestId:rid, approved:true, note:'房间内批准'});
      });
      bRj.addEventListener('click', function() {
        bOk.disabled = true; bRj.disabled = true; bRj.textContent = '已驳回';
        B.query({q:'mcp.approvalRespond', requestId:rid, approved:false, note:'房间内驳回'});
      });
      pf.appendChild(bOk); pf.appendChild(bRj); card.appendChild(pf);
    }
    d.appendChild(card); _container.appendChild(d);
    return d;
  }

  function renderGate(p, taskId) {
    var gate = p.gate || '';
    var state = p.state || 'open';
    /* ask 开闸: 渲染提问卡 + 选项按钮 */
    if (gate === 'ask' && state === 'open') { return renderAskCard(p, taskId); }
    /* fileWrite 开闸: 渲染写入预览 + 确认/驳回 */
    if (gate === 'fileWrite' && state === 'open') { return renderFilePreview(p, taskId); }
    /* shell 开闸: 渲染命令预览 + 允许/拒绝 */
    if (gate === 'shell' && state === 'open') { return renderShellPreview(p, taskId); }
    /* 响应事件: 只显示状态 */
    var label = {understand:'理解确认',plan:'计划确认',fileWrite:'写入确认',shell:'Shell 确认',ask:'提问'}[gate] || gate;
    var stateLabel = {open:'等待中',approved:'已批准',rejected:'已驳回',timeout:'超时'}[state] || state;
    return appendSys(label + ' · ' + stateLabel + (p.note ? ' · ' + p.note : ''));
  }

  function renderAskCard(p, taskId) {
    /* №8: 提问卡内容修复 — 空/占位符问题不出卡 (防空内容「…」/「若有歧义则问」当内容) */
    var note = (p.note || '').trim();
    var placeholders = ['若有歧义则问', '一句话确认问题'];
    var isPh = false;
    for (var pi = 0; pi < placeholders.length; pi++) {
      if (note.indexOf(placeholders[pi]) >= 0) { isPh = true; break; }
    }
    if (!note || isPh) return null;
    var d = document.createElement('div'); d.className = 'msg wide';
    var card = document.createElement('div'); card.className = 'plan-card';
    var hd = document.createElement('div'); hd.className = 'ph'; hd.textContent = 'MOV 提问';
    card.appendChild(hd);
    var q = document.createElement('div'); q.className = 'reason'; q.textContent = note;
    card.appendChild(q);
    var opts = p.options || [];
    if (opts.length && !_replayMode && taskId) {
      var pf = document.createElement('div'); pf.className = 'pf';
      opts.forEach(function(o) {
        var b = document.createElement('button'); b.className = 'btn btn-ghost'; b.textContent = o;
        b.addEventListener('click', function() {
          pf.querySelectorAll('button').forEach(function(x){x.disabled=true;});
          b.textContent = o + ' ✓';
          if (window._agentLoop) _agentLoop.awaiting = null;
          if (window.restoreAgentInput) restoreAgentInput();
          B.postCmd({cmd:'gate_respond', taskId:taskId, roomId:_activeRoom, gate:'ask', approved:true, note:o});
        });
        pf.appendChild(b);
      });
      card.appendChild(pf);
    } else if (!_replayMode) {
      /* 无选项时提示用户在输入框手答 */
      var hint = document.createElement('div');
      hint.className = 'reason ask-hint';
      hint.textContent = '直接在下方输入框回答后发送';
      card.appendChild(hint);
      if (window.setAgentInputHint) setAgentInputHint('输入回答后发送…');
    }
    d.appendChild(card); _container.appendChild(d);
    return d;
  }

  function renderFilePreview(p, taskId) {
    var d = document.createElement('div'); d.className = 'msg wide';
    var card = document.createElement('div'); card.className = 'plan-card';
    var hd = document.createElement('div'); hd.className = 'ph';
    hd.textContent = '写入预览 · ' + (p.note || '');
    card.appendChild(hd);
    if (!_replayMode && taskId) {
      var pf = document.createElement('div'); pf.className = 'pf';
      var bOk = document.createElement('button'); bOk.className = 'btn btn-acc'; bOk.textContent = '确认写入';
      var bRj = document.createElement('button'); bRj.className = 'btn btn-ghost'; bRj.textContent = '驳回';
      bOk.addEventListener('click', function() {
        bOk.disabled = true; bRj.disabled = true; bOk.textContent = '已确认 ✓';
        if (window._agentLoop) _agentLoop.awaiting = null;
        B.postCmd({cmd:'gate_respond', taskId:taskId, roomId:_activeRoom, gate:'fileWrite', approved:true});
      });
      bRj.addEventListener('click', function() {
        bOk.disabled = true; bRj.disabled = true; bRj.textContent = '已驳回';
        if (window._agentLoop) _agentLoop.awaiting = null;
        B.postCmd({cmd:'gate_respond', taskId:taskId, roomId:_activeRoom, gate:'fileWrite', approved:false});
      });
      pf.appendChild(bOk); pf.appendChild(bRj); card.appendChild(pf);
    }
    d.appendChild(card); _container.appendChild(d);
    return d;
  }

  function renderShellPreview(p, taskId) {
    var d = document.createElement('div'); d.className = 'msg wide';
    var card = document.createElement('div'); card.className = 'plan-card';
    var hd = document.createElement('div'); hd.className = 'ph';
    hd.textContent = '计划外 shell 命令';
    card.appendChild(hd);
    var pre = document.createElement('pre'); pre.className = 'pvw'; pre.textContent = p.note || '';
    card.appendChild(pre);
    if (!_replayMode && taskId) {
      var pf = document.createElement('div'); pf.className = 'pf';
      var bOk = document.createElement('button'); bOk.className = 'btn btn-acc'; bOk.textContent = '允许 (本任务不再询问)';
      var bRj = document.createElement('button'); bRj.className = 'btn btn-ghost'; bRj.textContent = '拒绝';
      bOk.addEventListener('click', function() {
        bOk.disabled = true; bRj.disabled = true; bOk.textContent = '已允许 ✓';
        if (window._agentLoop) _agentLoop.awaiting = null;
        B.postCmd({cmd:'gate_respond', taskId:taskId, roomId:_activeRoom, gate:'shell', approved:true});
      });
      bRj.addEventListener('click', function() {
        bOk.disabled = true; bRj.disabled = true; bRj.textContent = '已拒绝';
        if (window._agentLoop) _agentLoop.awaiting = null;
        B.postCmd({cmd:'gate_respond', taskId:taskId, roomId:_activeRoom, gate:'shell', approved:false});
      });
      pf.appendChild(bOk); pf.appendChild(bRj); card.appendChild(pf);
    }
    d.appendChild(card); _container.appendChild(d);
    return d;
  }

  /* ---------- 暂停卡 + 续跑/放弃 ---------- */
  function renderPaused(p, taskId) {
    var d = document.createElement('div'); d.className = 'msg wide';
    var card = document.createElement('div'); card.className = 'plan-card paused-card';
    var hd = document.createElement('div'); hd.className = 'ph'; hd.textContent = '已暂停 · 可续跑';
    card.appendChild(hd);
    var reason = document.createElement('div'); reason.className = 'reason';
    reason.textContent = '原因: ' + (p.reason || '网络异常') + ' · 已完成 ' + (p.stepsDone || 0) + ' 步';
    card.appendChild(reason);
    if (!_replayMode && taskId) {
      var pf = document.createElement('div'); pf.className = 'pf';
      var bGo = document.createElement('button'); bGo.className = 'btn btn-acc'; bGo.textContent = '立即续跑';
      var bNo = document.createElement('button'); bNo.className = 'btn btn-ghost'; bNo.textContent = '放弃';
      bGo.addEventListener('click', function() {
        bGo.disabled = true; bNo.disabled = true; bGo.textContent = '续跑中…';
        B.postCmd({cmd:'resume_task', taskId:taskId});
      });
      bNo.addEventListener('click', function() {
        bGo.disabled = true; bNo.disabled = true; bNo.textContent = '已放弃';
        B.postCmd({cmd:'stop_task', taskId:taskId});
      });
      pf.appendChild(bGo); pf.appendChild(bNo); card.appendChild(pf);
    }
    d.appendChild(card); _container.appendChild(d);
    return d;
  }

  /* M3: 执行步骤轻量行 — 成功✓+工具名+耗时 / 失败✗+诊断 */
  function renderStepLine(p) {
    var line = document.createElement('div');
    line.className = 'step-line' + (p.ok === false ? ' step-fail' : '');
    var icon = document.createElement('span');
    icon.className = 'step-icon'; icon.textContent = p.ok === false ? '✗' : '✓';
    line.appendChild(icon);
    var desc = document.createElement('span');
    desc.className = 'step-desc'; desc.textContent = p.name + (p.arg ? ' ' + p.arg.substring(0, 30) : '');
    line.appendChild(desc);
    var meta = document.createElement('span');
    meta.className = 'step-meta';
    if (p.ok !== false) { meta.textContent = ((p.durMs||0)/1000).toFixed(1)+'s'; }
    else { meta.textContent = failReason(p.result||p.text||''); meta.classList.add('step-err'); }
    line.appendChild(meta);
    return line;
  }
  function failReason(text) {
    var ps=[/permission denied/i,/command not found/i,/no such file/i,/disk full|no space left/i,
      /connection refused|network unreachable/i,/out of memory|cannot allocate/i,/timeout|timed out/i,/exit=(\d+)/];
    var ls=['权限不足','命令不存在','文件不存在','磁盘满','网络不通','内存不足','超时','退出码 $1'];
    for(var i=0;i<ps.length;i++){var m=text.match(ps[i]);if(m)return ls[i].replace('$1',m[1]||'');}
    return text.length > 40 ? text.substring(0,40) : text;
  }

  /* 工具结果: 自适应分级 (兼容 step/tool_result 两种类型) */
  function renderToolResult(p) {
    var name = p.name || p.tool || '';
    var output = (p.result || p.text || '').trim();
    var dur = ((p.durMs || 0) / 1000);
    var ok = p.ok !== false;

    // 失败 → 永远红色展开 (不用 innerHTML, 防注入)
    if (!ok) {
      var d = document.createElement('div'); d.className = 'msg wide';
      var tc = document.createElement('div'); tc.className = 'toolcall err open';
      var th = document.createElement('div'); th.className = 'th';
      var errSpan = document.createElement('span'); errSpan.className = 'err-line'; errSpan.textContent = '✗';
      th.appendChild(errSpan);
      th.appendChild(document.createTextNode(name + (dur > 0 ? ' · ' + dur.toFixed(1) + 's' : '')));
      tc.appendChild(th);
      if (output) {
        var tb = document.createElement('div'); tb.className = 'tb';
        var pre = document.createElement('pre'); pre.textContent = output;
        tb.appendChild(pre); tc.appendChild(tb);
      }
      d.appendChild(tc); _container.appendChild(d); return d;
    }

    // 成功 + 短输出 (<200字) → 紧凑一行
    if (output.length < 200) {
      return appendSys('📄 ' + name + (output ? ': ' + output : '') + (dur > 0 ? ' · ' + dur.toFixed(1) + 's' : ''));
    }

    // 成功 + 长输出 → 摘要 + 展开 (安全创建, 不用 innerHTML)
    var dd = document.createElement('div'); dd.className = 'msg wide';
    var tc2 = document.createElement('div'); tc2.className = 'toolcall';
    var th2 = document.createElement('div'); th2.className = 'th';
    th2.style.cursor = 'pointer';
    var ok2 = document.createElement('span'); ok2.className = 'ok-line'; ok2.textContent = '✓';
    th2.appendChild(ok2);
    var preview = output.substring(0, 100);
    th2.appendChild(document.createTextNode(name + (dur > 0 ? ' · ' + dur.toFixed(1) + 's' : '') + ' · ' + preview));
    var toggle = document.createElement('span'); toggle.className = 'car'; toggle.textContent = '▸';
    th2.appendChild(toggle);
    var tb2 = document.createElement('div'); tb2.className = 'tb';
    var pre2 = document.createElement('pre'); pre2.textContent = output;
    tb2.appendChild(pre2); tb2.style.maxHeight = '30vh'; tb2.style.overflowY = 'auto';
    tc2.appendChild(th2); tc2.appendChild(tb2);
    th2.addEventListener('click', function() {
      var isOpen = tc2.classList.toggle('open');
      toggle.textContent = isOpen ? '▾' : '▸';
    });
    dd.appendChild(tc2); _container.appendChild(dd); return dd;
  }

  /* 交付卡: 三级——简单pill/中等卡片/复杂卡片 */
  function renderDeliver(p) {
    // AgentLoop.deliver() 字段: planSteps/elapsedSec/promptTokens/completionTokens
    var steps = p.planSteps || p.stepsDone || 0;
    var dur = p.elapsedSec || Math.round((p.durMs || 0) / 1000);
    var tokens = (p.promptTokens||0) + (p.completionTokens||0);
    var summary = (p.summary || '').trim();
    var files = p.files || [];
    var m = p.metrics || {};
    // 摘要太短不显示
    if (summary.length < 10) summary = '';

    // 简单任务 → pill (№8: 答案卡干净 — 无「✨机器标题」/无·N步·Ns 混排; summary 提炼结论, 元数据下沿小灰字)
    if (steps <= 3 && dur <= 30 && files.length === 0) {
      var pill = document.createElement('div'); pill.className = 'deliver-line';
      var conclusion = window.NewFaceExpert ? NewFaceExpert.extractConclusion(summary) : summary;
      var txt = document.createElement('span'); txt.className = 'answer-txt'; txt.textContent = conclusion || '完成';
      pill.appendChild(txt);
      if (summary && (steps || dur)) {
        var meta = document.createElement('div'); meta.className = 'deliver-meta';
        meta.textContent = (steps ? steps + ' 步' : '') + (steps && dur ? ' · ' : '') + (dur ? dur + 's' : '');
        pill.appendChild(meta);
      }
      _container.appendChild(pill); return pill;
    }

    // 中等/复杂任务 → 卡片
    var d = document.createElement('div'); d.className = 'msg wide';
    var card = document.createElement('div'); card.className = 'deliver-card';

    // 标题 = 提炼结论 (№8: 无「✨机器标题」, 答案 prose 优先)
    var hd = document.createElement('div'); hd.className = 'title';
    hd.textContent = window.NewFaceExpert ? (NewFaceExpert.extractConclusion(summary) || '完成') : (summary || '完成');
    card.appendChild(hd);

    // 摘要（№8: 完整摘要与标题结论不同才显示, 防重复）
    var conclTitle = window.NewFaceExpert ? (NewFaceExpert.extractConclusion(summary) || '') : summary;
    if (summary && summary !== conclTitle) {
      var ss = document.createElement('div'); ss.className = 'summary';
      ss.textContent = summary; card.appendChild(ss);
    }

    // 产物按钮（可交互）
    if (files.length) {
      var fb = document.createElement('div'); fb.className = 'prod';
      var fh = document.createElement('div'); fh.className = 'prod-title';
      fh.textContent = '📦 产物';
      fb.appendChild(fh);
      files.forEach(function(f) {
        var btn = document.createElement('button'); btn.className = 'action-btn';
        var isApk = f.toLowerCase().endsWith('.apk');
        btn.textContent = isApk ? '📲 安装 ' + f : '📄 打开 ' + f;
        btn.addEventListener('click', function() {
          if (!window.HermesBridge) return;
          if (isApk) {
            HermesBridge.installApk(_activeRoom, f);
          } else {
            var content = HermesBridge.readFile(_activeRoom, f);
            if (content) alert(content.substring(0, 2000));
          }
        });
        fb.appendChild(btn);
      });
      card.appendChild(fb);
    }

    // Compliance (保留旧逻辑)
    var comp = p.compliance;
    if (comp) {
      var cr = document.createElement('div');
      cr.className = 'compliance-row ' + (comp.verdict === 'PASSED' ? 'comp-pass' : (comp.verdict === 'NEEDS_FIX' ? 'comp-fix' : 'comp-warn'));
      var v = {PASSED:'上线级 ✓', NEEDS_FIX:'需修复 ⚠', DELIVER_WITH_ISSUES:'带瑕疵交付 ⚡'}[comp.verdict]||comp.verdict;
      cr.textContent = 'Compliance: ' + v + (comp.summary ? ' · ' + comp.summary : '');
      card.appendChild(cr);
    }

    // 指标条 + 详情入口
    var stats = document.createElement('div'); stats.className = 'stats';
    stats.textContent = steps + '步';
    if (dur > 0) stats.textContent += ' · ' + dur + 's';
    var detail = document.createElement('span'); detail.className = 'detail-link';
    detail.textContent = '详情 ▸';
    var detailExpanded = false;
    var detailDiv = document.createElement('div'); detailDiv.className = 'deliver-detail'; detailDiv.style.display = 'none';
    detailDiv.textContent = 'tokens: ' + tokens;
    card.appendChild(detailDiv);
    detail.addEventListener('click', function() {
      detailExpanded = !detailExpanded;
      detailDiv.style.display = detailExpanded ? 'block' : 'none';
      detail.textContent = detailExpanded ? '收起 ▾' : '详情 ▸';
    });
    stats.appendChild(detail);
    card.appendChild(stats);

    d.appendChild(card); _container.appendChild(d);
    return d;
  }

  /* ---------- 失败卡 ---------- */
  function renderFail(p) {
    var d = document.createElement('div'); d.className = 'msg wide';
    var card = document.createElement('div'); card.className = 'plan-card fail-card';
    var hd = document.createElement('div'); hd.className = 'ph'; hd.textContent = '任务失败';
    card.appendChild(hd);
    var reason = document.createElement('div'); reason.className = 'reason';
    reason.textContent = p.reason || '失败了，点看重试';   /* №8: 「未知原因」永禁 */
    card.appendChild(reason);
    if (p.stepsDone) {
      var prog = document.createElement('div'); prog.className = 'progress';
      prog.textContent = '已完成 ' + p.stepsDone + ' 步';
      card.appendChild(prog);
    }
    var produced = p.produced || [];
    if (produced.length) {
      var pl = document.createElement('div'); pl.className = 'progress';
      pl.textContent = '部分产物: ' + produced.join(' · ');
      card.appendChild(pl);
    }
    d.appendChild(card); _container.appendChild(d);
    return d;
  }

  /* ---------- 理解 ---------- */
  function renderUnderstand(p) {
    var d = document.createElement('div'); d.className = 'msg wide';
    var card = document.createElement('div'); card.className = 'plan-card';
    var hd = document.createElement('div'); hd.className = 'ph'; hd.textContent = '需求理解';
    card.appendChild(hd);
    if (p.summary) { var s = document.createElement('div'); s.textContent = p.summary; card.appendChild(s); }
    d.appendChild(card); _container.appendChild(d);
    return d;
  }

  /* ---------- 瞬态 ---------- */
  function createTransientBubble(taskId, s) {
    var el = document.createElement('div');
    el.className = 'msg agent mov-transient';
    el.setAttribute('data-task', taskId);
    var who = document.createElement('div'); who.className = 'who'; who.textContent = 'MOV';
    var text = document.createElement('div'); text.className = 'bubble mov-stream-text';
    el.appendChild(who); el.appendChild(text);
    _container.appendChild(el);
    scrollToBottom();
    if (s) { s.el = el; s.textEl = text; s.phase = s.phase || 'generating'; s.taskId = taskId; s.timer = null; }
    return { el:el, textEl:text, text:'', chunks:[], lastTs:Date.now(), phase:'generating', taskId:taskId, timer:null };
  }
  function renderTransient(s) {
    s.textEl.textContent = s.text;
    var cur = document.createElement('span'); cur.className = 'stream-cursor'; cur.textContent = '▍';
    s.textEl.appendChild(cur);
    scrollToBottom();
  }
  function clearTransientForTask(taskId) {
    if (!taskId) return;
    _endedTasks[taskId] = true;
    var s = _transient[taskId];
    if (!s) return;
    if (s.timer) clearInterval(s.timer);
    if (s.thinking) {
      if (s.el && s.el.parentNode) s.el.parentNode.removeChild(s.el);
    } else {
      var cur = s.textEl.querySelector('.stream-cursor');
      if (cur) cur.remove();
      s.el.classList.remove('mov-transient');
    }
    delete _transient[taskId];
  }
  function clearAllTransient() {
    Object.keys(_transient).forEach(function(k) {
      var s = _transient[k];
      if (s.timer) clearInterval(s.timer);
      if (s.el && s.el.parentNode) s.el.parentNode.removeChild(s.el);
    });
    _transient = {};
  }

  /* 页面从后台回来时强制刷新全部活跃瞬态流 (修复: 切后台 WebView 冻结导致 token 堆积不渲染) */
  document.addEventListener('visibilitychange',function(){
    if (document.hidden) return;
    Object.keys(_transient).forEach(function(k){
      var s = _transient[k];
      if (!s || _endedTasks[k]) return;
      if (s.thinking) return;
      if (!s.el) { createTransientBubble(k, s); }
      renderTransient(s);
    });
  });


  /* ---------- 调试/验收 ---------- */
  function getRenderedSeqs() { return Object.keys(_renderedSeqs).map(Number).sort(function(a,b){return a-b;}); }
  function getTransientCount() { return Object.keys(_transient).length; }
  function getContainer() { return _container; }

  return {
    init:init, destroy:destroy, setRoom:setRoom, reset:reset,
    replayEvents:replayEvents,
    getRenderedSeqs:getRenderedSeqs, getTransientCount:getTransientCount, getContainer:getContainer,
    /* 测试出口 (ARCH_DEBT #3) */
    renderPlanTest: renderPlan, renderDeliverTest: renderDeliver
  };
})();
