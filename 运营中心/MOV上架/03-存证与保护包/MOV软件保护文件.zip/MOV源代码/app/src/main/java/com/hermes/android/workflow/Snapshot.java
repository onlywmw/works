package com.hermes.android.workflow;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * 条件评估上下文（纯数据 + 注入的元素存在性检查，纯 JVM）。
 * 页面状态快照：时间/URL/文本/元素存在性/级联触发计数。
 * 第三幕扩展：电量/充电/屏幕/网络/前台 App/上次运行/变量/元素数量。
 * 快照缺数据的条件 = FAIL（诚实，不许猜）。
 */
public class Snapshot {

    public final long now;
    public final String url;
    public final String text;
    /** 级联触发计数：workflow 条件引用另一 workflow 的 fire 次数 */
    public final int count;
    /** 元素存在性检查（注入；null 时 elementExists 返回 false） */
    private final Predicate<String> elementCheck;
    // ══ 第三幕扩展 ══
    public final int batteryLevel;                  // -1 未知
    public final boolean charging;
    public final boolean screenOn;
    public final String networkType;                // "wifi"/"mobile"/null 未知
    public final String foregroundApp;              // 前台 App 包名 / null
    public final long lastRunAt;                    // 上次触发 0 未知
    public final Map<String, String> variables;     // 变量表
    private final Function<String, Integer> elementCount;   // selector → 数量；null 未知

    /** 现有构造（委托新构造，扩展字段用默认缺省值） */
    public Snapshot(long now, String url, String text, int count, Predicate<String> elementCheck) {
        this(now, url, text, count, elementCheck, -1, false, false, null, null, 0,
                new HashMap<>(), null);
    }

    /** 完整构造（第三幕） */
    public Snapshot(long now, String url, String text, int count, Predicate<String> elementCheck,
                    int batteryLevel, boolean charging, boolean screenOn, String networkType,
                    String foregroundApp, long lastRunAt, Map<String, String> variables,
                    Function<String, Integer> elementCount) {
        this.now = now;
        this.url = url;
        this.text = text;
        this.count = count;
        this.elementCheck = elementCheck;
        this.batteryLevel = batteryLevel;
        this.charging = charging;
        this.screenOn = screenOn;
        this.networkType = networkType;
        this.foregroundApp = foregroundApp;
        this.lastRunAt = lastRunAt;
        this.variables = variables != null ? variables : new HashMap<>();
        this.elementCount = elementCount;
    }

    public boolean elementExists(String selector) {
        return elementCheck != null && selector != null && elementCheck.test(selector);
    }

    /** 打回修复：last_run_ago 条件用 per-workflow lastFireAt（复制本快照仅改 lastRunAt） */
    public Snapshot withLastRunAt(long lastRunAt) {
        return new Snapshot(now, url, text, count, elementCheck, batteryLevel, charging, screenOn,
                networkType, foregroundApp, lastRunAt, variables, elementCount);
    }

    /** 元素数量；未知（快照未提供）返回 -1（条件 FAIL） */
    public int elementCountFor(String selector) {
        return elementCount != null && selector != null ? elementCount.apply(selector) : -1;
    }
}
