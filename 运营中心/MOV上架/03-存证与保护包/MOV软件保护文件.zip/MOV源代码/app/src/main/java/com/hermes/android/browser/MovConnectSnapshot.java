package com.hermes.android.browser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 元素编号快照解析器（协议 §4）。
 * 解析 MovConnect.snapshot() 返回的 [{eid,tag,text,role}] JSON。
 */
public class MovConnectSnapshot {

    public static class Element {
        public final int eid;
        public final String tag;
        public final String text;
        public final String role;

        public Element(int eid, String tag, String text, String role) {
            this.eid = eid;
            this.tag = tag;
            this.text = text;
            this.role = role;
        }

        public JSONObject toJSON() throws JSONException {
            return new JSONObject()
                    .put("eid", eid)
                    .put("tag", tag)
                    .put("text", text)
                    .put("role", role);
        }
    }

    /** 解析快照 JSON */
    public static List<Element> parse(String snapshotJson) {
        List<Element> list = new ArrayList<>();
        if (snapshotJson == null || snapshotJson.isEmpty()) return list;
        try {
            JSONArray arr = new JSONArray(snapshotJson);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                list.add(new Element(
                        o.optInt("eid", -1),
                        o.optString("tag", ""),
                        o.optString("text", ""),
                        o.optString("role", "")));
            }
        } catch (JSONException ignored) {}
        return list;
    }

    /** 找元素（eid 优先，selector 次之） */
    public static Element find(List<Element> elements, String target) {
        if (target == null) return null;
        if (target.startsWith("eid:")) {
            try {
                int eid = Integer.parseInt(target.substring(4));
                for (Element e : elements) {
                    if (e.eid == eid) return e;
                }
            } catch (NumberFormatException ignored) {}
        }
        // selector 匹配（text 部分匹配）
        for (Element e : elements) {
            if (e.text.contains(target) || e.tag.equals(target)) return e;
        }
        return null;
    }
}
