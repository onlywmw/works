package com.hermes.android.pay;

import com.hermes.android.agent.Journal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 订单状态机（工单26 M1-3）：CREATED→PAYING→PAID→DELIVERED→INSTALLED，
 * 旁路 EXPIRED / MANUAL。全部迁移 append 进 journal（真理源纪律），
 * 内存态 = journal 投影重建（重启不丢）。
 *
 * 订单事件 type='mkt.order'，payload {orderId, to, extra} 落固定房间 'mkt'。
 */
public class OrderStore {

    public enum State { CREATED, PAYING, PAID, DELIVERED, INSTALLED, EXPIRED, MANUAL }

    /** 合法迁移表（跳态拒、终态拒） */
    static final Map<State, Set<State>> NEXT = new LinkedHashMap<>();
    static {
        NEXT.put(State.CREATED,   EnumSet.of(State.PAYING, State.EXPIRED, State.MANUAL));  // E-13：merchant_missing/wx_create_fail/order_send_fail 错误出口：merchant_missing/wx_create_fail/order_send_fail 错误出口
        NEXT.put(State.PAYING,    EnumSet.of(State.PAID, State.EXPIRED, State.MANUAL));
        NEXT.put(State.PAID,      EnumSet.of(State.DELIVERED, State.MANUAL));
        NEXT.put(State.DELIVERED, EnumSet.of(State.INSTALLED));
        NEXT.put(State.INSTALLED, EnumSet.noneOf(State.class));
        NEXT.put(State.EXPIRED,   EnumSet.noneOf(State.class));
        NEXT.put(State.MANUAL,    EnumSet.noneOf(State.class));
    }

    /** 订单投影（内存态） */
    public static class Order {
        public final String orderId;
        public final String productId;
        public final String buyerId;
        public final int fen;
        public String codeUrl = "";
        public State state = State.CREATED;
        public long createdAtMs = System.currentTimeMillis();

        Order(String orderId, String productId, String buyerId, int fen) {
            this.orderId = orderId;
            this.productId = productId;
            this.buyerId = buyerId;
            this.fen = fen;
        }

        public JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("orderId", orderId).put("productId", productId).put("buyerId", buyerId)
                        .put("fen", fen).put("state", state.name()).put("codeUrl", codeUrl)
                        .put("createdAtMs", createdAtMs);
            } catch (Exception ignored) {}
            return o;
        }
    }

    public static final String ROOM = "mkt";
    public static final String EVENT_TYPE = "mkt.order";
    /** 全量订单快照事件（工单26 挂账⑧：journal 滚动截旧后重建防丢）。
     *  每写 _SNAPSHOT_EVERY 条订单事件追加一条 {payload:{orders:{...}}} 检查点，
     *  rebuild 遇快照重置订单集再叠加增量，滚动截尾后仍可精确还原。 */
    public static final String SNAPSHOT_EVENT_TYPE = "mkt.order_snapshot";
    static final int _SNAPSHOT_EVERY = 100;

    private final Journal journal;
    private final Map<String, Order> orders = new LinkedHashMap<>();
    private int eventCounter = 0;   // 订单事件计数（快照检查点触发）

    public OrderStore(Journal journal) { this.journal = journal; }

    /** 新建订单（CREATED 落 journal）。productId/buyerId 空拒。 */
    public synchronized Order create(String productId, String buyerId, int fen) {
        if (productId == null || productId.isEmpty() || buyerId == null || buyerId.isEmpty())
            throw new IllegalArgumentException("productId/buyerId 不能为空");
        String orderId = newOrderId();
        Order o = new Order(orderId, productId, buyerId, fen);
        orders.put(orderId, o);
        journal.append(ROOM, event(orderId, State.CREATED, o.toJson()));
        maybeSnapshot();   // create 也是事件，计入快照检查点
        return o;
    }

    /** 迁移；非法跳态/未知订单 → false（不落 journal） */
    public synchronized boolean transit(String orderId, State to, JSONObject extra) {
        Order o = orders.get(orderId);
        if (o == null || !NEXT.get(o.state).contains(to)) return false;
        o.state = to;
        journal.append(ROOM, event(orderId, to, extra == null ? new JSONObject() : extra));
        maybeSnapshot();   // 定期写全量快照检查点（滚动截尾后重建兜底）
        return true;
    }

    /** 每 _SNAPSHOT_EVERY 条订单事件写一次全量快照（检查点语义，防滚动截旧丢单）。 */
    private void maybeSnapshot() {
        if (++eventCounter % _SNAPSHOT_EVERY != 0) return;
        JSONObject snap = new JSONObject();
        try {
            for (Map.Entry<String, Order> e : orders.entrySet()) {
                snap.put(e.getKey(), e.getValue().toJson());
            }
        } catch (Exception ignored) {}
        journal.append(ROOM, snapshotEvent(snap));
    }

    /** 订单投影（无 → null） */
    public synchronized Order get(String orderId) {
        return orders.get(orderId);
    }

    /** 全部订单（E-1：onResume 遍历用） */
    public synchronized java.util.List<Order> all() {
        return new java.util.ArrayList<>(orders.values());
    }

    /** PAYING 态订单（E-1：回前台需重挂查单轮询的订单） */
    public synchronized java.util.List<Order> paying() {
        java.util.List<Order> out = new java.util.ArrayList<>();
        for (Order o : orders.values()) {
            if (o.state == State.PAYING) out.add(o);
        }
        return out;
    }

    /** 从 journal 重放重建内存态（重启恢复；事件按序应用，非法迁移跳过） */
    public static OrderStore rebuild(Journal journal) {
        OrderStore s = new OrderStore(journal);
        JSONObject replay = journal.replay(ROOM);
        // replay 返回错误信封 {ok, data:{events}}（2026-08-09 实测：非裸 events）
        JSONObject data = replay != null ? replay.optJSONObject("data") : null;
        JSONArray evs = data != null ? data.optJSONArray("events") : null;
        if (evs == null) return s;
        for (int i = 0; i < evs.length(); i++) {
            JSONObject ev = evs.optJSONObject(i);
            if (ev == null) continue;
            try {
                JSONObject p = ev.optJSONObject("payload");
                if (p == null) continue;
                // 快照检查点：重置订单集为快照全量，后续事件按增量叠加
                if (SNAPSHOT_EVENT_TYPE.equals(ev.optString("type"))) {
                    JSONObject ordersSnap = p.optJSONObject("orders");
                    if (ordersSnap != null) {
                        s.orders.clear();
                        java.util.Iterator<String> it = ordersSnap.keys();
                        while (it.hasNext()) {
                            String oid = it.next();
                            JSONObject oj = ordersSnap.optJSONObject(oid);
                            if (oj == null) continue;
                            Order o = new Order(oj.optString("orderId", oid),
                                    oj.optString("productId", ""),
                                    oj.optString("buyerId", ""), oj.optInt("fen", 0));
                            o.codeUrl = oj.optString("codeUrl", "");
                            o.createdAtMs = oj.optLong("createdAtMs", System.currentTimeMillis());
                            try { o.state = State.valueOf(oj.optString("state", State.CREATED.name())); }
                            catch (Exception ignored) {}
                            s.orders.put(oid, o);
                        }
                    }
                    continue;
                }
                String orderId = p.optString("orderId", "");
                String to = p.optString("to", "");
                if (orderId.isEmpty() || to.isEmpty()) continue;
                if (State.CREATED.name().equals(to)) {
                    // 重建订单骨架（create 事件 payload 里带订单快照）
                    JSONObject snap = p.optJSONObject("extra");
                    if (snap != null && snap.has("productId")) {
                        Order o = new Order(snap.optString("orderId", orderId),
                                snap.optString("productId", ""),
                                snap.optString("buyerId", ""), snap.optInt("fen", 0));
                        o.codeUrl = snap.optString("codeUrl", "");
                        o.createdAtMs = snap.optLong("createdAtMs", System.currentTimeMillis());
                        s.orders.put(orderId, o);
                    }
                } else {
                    State st = null;
                    try { st = State.valueOf(to); } catch (Exception ignored) {}
                    if (st != null && s.orders.containsKey(orderId)) {
                        Order o = s.orders.get(orderId);
                        if (NEXT.get(o.state).contains(st)) o.state = st;
                        // 迁移事件附带的订单数据（如 PAYING 的 codeUrl）随重放恢复
                        JSONObject extra = p.optJSONObject("extra");
                        if (extra != null && extra.has("codeUrl")) {
                            o.codeUrl = extra.optString("codeUrl", "");
                        }
                    }
                }
            } catch (Exception ignored) { /* 单条事件损坏跳过，不阻断重放 */ }
        }
        return s;
    }

    /** 订单号 = MOV + yyyyMMddHHmmss + 4 位随机（≤32 字符，微信限制） */
    static String newOrderId() {
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.US);
        return "MOV" + f.format(new java.util.Date())
                + String.format("%04d", ThreadLocalRandom.current().nextInt(10000));
    }

    private static JSONObject event(String orderId, State to, JSONObject extra) {
        JSONObject ev = new JSONObject();
        try {
            ev.put("type", EVENT_TYPE);
            ev.put("actor", "mkt");
            JSONObject p = new JSONObject();
            p.put("orderId", orderId);
            p.put("to", to.name());
            p.put("extra", extra);
            ev.put("payload", p);
        } catch (Exception ignored) {}
        return ev;
    }

    /** 全量快照事件：payload.orders = {orderId: orderJson, ...}。rebuild 遇它重置订单集。 */
    private static JSONObject snapshotEvent(JSONObject ordersSnap) {
        JSONObject ev = new JSONObject();
        try {
            ev.put("type", SNAPSHOT_EVENT_TYPE);
            ev.put("actor", "mkt");
            JSONObject p = new JSONObject();
            p.put("orders", ordersSnap);
            ev.put("payload", p);
        } catch (Exception ignored) {}
        return ev;
    }
}
