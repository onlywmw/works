package com.hermes.android.ai;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * SseParser — OpenAI SSE 流式解析 (纯逻辑, 可单测)。
 *
 * 增量喂字节, 处理: 粘包 (多行一包) / 半行 (一行跨包) / `data: [DONE]` 终止 /
 * 注释与 ping 帧 (冒号开头, 不算活性) / tool_calls 累积
 * (name 赋值不拼接, arguments 拼接, 末段 JSON 校验+修复)。
 */
public class SseParser {

    /** 一个增量事件: 真实内容 token, 或 done 终态 */
    public static class Event {
        public final String token;      // 内容增量 (ping/注释/tool 增量不产出)
        public final boolean done;
        public final String toolName;   // tool_calls name (赋值制)
        public final String toolArgs;   // tool_calls arguments (拼接制)

        Event(String token, boolean done, String toolName, String toolArgs) {
            this.token = token;
            this.done = done;
            this.toolName = toolName;
            this.toolArgs = toolArgs;
        }
    }

    private String pending = "";        // 半行缓冲
    private boolean seenDone = false;
    private final StringBuilder toolName = new StringBuilder();
    private final StringBuilder toolArgs = new StringBuilder();
    /* anthropic: tool_use 块 (name + partial_json) — v1 记录不执行 */
    private final StringBuilder anthToolName = new StringBuilder();
    private final StringBuilder anthToolArgs = new StringBuilder();

    public boolean isDone() { return seenDone; }

    /** 喂一段字节, 返回本段产出的事件 (token/done; ping/注释被吞) */
    public List<Event> feed(String chunk) {
        List<Event> out = new ArrayList<>();
        if (chunk == null || chunk.isEmpty()) return out;
        pending += chunk;
        int nl;
        while ((nl = pending.indexOf('\n')) >= 0) {
            String line = pending.substring(0, nl);
            pending = pending.substring(nl + 1);
            handleLine(line, out);
        }
        return out;
    }

    /** 流末冲刷: 把半行残存按一行处理 (provider 末行无 \n 的场景) */
    public List<Event> flush() {
        List<Event> out = new ArrayList<>();
        if (!pending.isEmpty()) {
            String line = pending;
            pending = "";
            handleLine(line, out);
        }
        return out;
    }

    private void handleLine(String line, List<Event> out) {
        String t = line.trim();
        if (t.isEmpty()) return;
        if (t.startsWith(":")) return;                 // 注释/ping 帧 — 不算活性 (红线)
        if (!t.startsWith("data:")) return;
        String data = t.substring(5).trim();
        if ("[DONE]".equals(data)) {
            seenDone = true;
            out.add(new Event(null, true, null, null));
            return;
        }
        try {
            JSONObject json = new JSONObject(data);
            JSONArray choices = json.optJSONArray("choices");
            if (choices == null || choices.length() == 0) {
                handleAnthropicEvent(json, out);   // anthropic SSE 事件（无 choices）
                return;
            }
            JSONObject delta = choices.optJSONObject(0).optJSONObject("delta");
            if (delta == null) return;
            /* tool_calls: name 赋值制, arguments 拼接制 */
            JSONArray tcs = delta.optJSONArray("tool_calls");
            if (tcs != null && tcs.length() > 0) {
                JSONObject fn = tcs.optJSONObject(0).optJSONObject("function");
                if (fn != null) {
                    String name = fn.optString("name", null);
                    if (name != null && !name.isEmpty()) {
                        toolName.setLength(0);
                        toolName.append(name);
                    }
                    String args = fn.optString("arguments", null);
                    if (args != null) toolArgs.append(args);
                }
                return;                                 // tool 增量不产出内容 token
            }
            String token = delta.optString("content", null);
            /* Android org.json 把 JSON null 值转为字符串 "null", 需显式过滤 */
            if (token == null || token.isEmpty() || "null".equals(token)) {
                token = delta.optString("reasoning_content", null);
            }
            if (token != null && !token.isEmpty() && !"null".equals(token)) {
                out.add(new Event(token, false, null, null));
            }
        } catch (Exception ignored) {
            /* 非 JSON 行 (网关夹带文本等) 静默丢弃, 不打断流 */
        }
    }

    /** anthropic SSE 事件: text_delta→token / tool_use 块累积 / message_stop→done */
    private void handleAnthropicEvent(JSONObject json, List<Event> out) {
        String type = json.optString("type", "");
        if ("content_block_delta".equals(type)) {
            JSONObject delta = json.optJSONObject("delta");
            if (delta == null) return;
            String dt = delta.optString("type", "");
            if ("text_delta".equals(dt)) {
                String text = delta.optString("text", null);
                if (text != null && !text.isEmpty() && !"null".equals(text)) {
                    out.add(new Event(text, false, null, null));
                }
            } else if ("input_json_delta".equals(dt)) {
                String pj = delta.optString("partial_json", null);
                if (pj != null) anthToolArgs.append(pj);
            }
        } else if ("content_block_start".equals(type)) {
            JSONObject cb = json.optJSONObject("content_block");
            if (cb != null && "tool_use".equals(cb.optString("type"))) {
                anthToolName.setLength(0);
                anthToolArgs.setLength(0);
                anthToolName.append(cb.optString("name", ""));
            }
        } else if ("message_stop".equals(type)) {
            seenDone = true;
            out.add(new Event(null, true, null, null));
        }
    }

    /** 累积的 tool_calls (name + arguments JSON 修复后文本); 无 tool 调用返回 null */
    public String toolCallJson() {
        if (toolName.length() == 0) return null;
        return "{\"name\":\"" + toolName + "\",\"arguments\":" + repairJson(toolArgs.toString()) + "}";
    }

    /** 流末 JSON 修复: 补括号 + 去尾逗号 (截断的 arguments 可救则救) */
    public static String repairJson(String s) {
        if (s == null) return "{}";
        String t = s.trim();
        if (t.isEmpty()) return "{}";
        t = t.replaceAll(",\\s*$", "");                 // 去尾逗号
        int open = 0;
        boolean inStr = false, esc = false;
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (esc) { esc = false; continue; }
            if (c == '\\') { esc = true; continue; }
            if (c == '"') { inStr = !inStr; continue; }
            if (inStr) continue;
            if (c == '{' || c == '[') open++;
            if (c == '}' || c == ']') open--;
        }
        StringBuilder r = new StringBuilder(t);
        for (int i = 0; i < open; i++) r.append('}');
        return r.toString();
    }
}
