package com.hermes.android;
import com.hermes.android.browser.SiteRuleEngine;
import com.hermes.android.browser.BrowserDiffHelper;
import com.hermes.android.browser.BrowserToolProvider;

import android.annotation.SuppressLint;
import com.hermes.android.security.PaymentGate;
import com.hermes.android.workflow.WorkflowEventSource;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * 通用连接 Web 容器（视频平台登录 / 搜索播放两用）。
 *
 * 平台配置化：通过 Intent extra "platform" 选择平台配置，
 * mode=login 打开登录页，mode=search 直进搜索结果。
 *
 * 平台配置（硬编码，video_sources.json 留档）：
 *   douyin  — www.douyin.com / sessionid,sid_tt / 需"视频"tab自动切换
 *   tencent — m.v.qq.com / vqq_access_token,vqq_vuserid / 无tab切换
 */
public class ConnectWebActivity extends androidx.appcompat.app.AppCompatActivity
        implements BrowserToolProvider.BrowserExecutor {

    /** 平台配置 */
    private static final Map<String, PlatformConfig> PLATFORMS = new HashMap<>();
    static {
        PLATFORMS.put("douyin", new PlatformConfig(
                "https://www.douyin.com/",
                "https://www.douyin.com/search/{keyword}?type=video",
                "抖音", new String[]{"sessionid", "sid_tt"},
                "#0e0f11", true));
        PLATFORMS.put("tencent", new PlatformConfig(
                "https://m.v.qq.com/",
                "https://m.v.qq.com/search.html?keyword={keyword}",
                "腾讯视频", new String[]{"vqq_access_token", "vqq_vuserid"},
                "#0e0f11", false));
        /* W3: 京东购物 + 12306 订票 (site_rules 已配 UA/拦 App; 登录态 cookie 待真机沉淀) */
        PLATFORMS.put("jd", new PlatformConfig(
                "https://m.jd.com/",
                "https://so.m.jd.com/ware/search.action?keyword={keyword}",
                "京东", new String[]{}, "#c81623", false));
        PLATFORMS.put("12306", new PlatformConfig(
                "https://kyfw.12306.cn/otn/leftTicket/init",
                "https://kyfw.12306.cn/otn/leftTicket/init",
                "12306", new String[]{"_jc_save_wfdc_flag", "JSESSIONID"}, "#3b7ac4", false));
    }

    static class PlatformConfig {
        final String loginUrl, searchTemplate, title, barColor;
        final String[] cookieKeys;
        final boolean needTabSwitch;
        PlatformConfig(String loginUrl, String searchTemplate, String title,
                       String[] cookieKeys, String barColor, boolean needTabSwitch) {
            this.loginUrl = loginUrl;
            this.searchTemplate = searchTemplate;
            this.title = title;
            this.cookieKeys = cookieKeys;
            this.barColor = barColor;
            this.needTabSwitch = needTabSwitch;
        }
    }

    private WebView web;
    private SiteRuleEngine ruleEngine;
    private PaymentGate paymentGate;
    private static volatile ConnectWebActivity currentInstance;  // P1: agent 线程读/主线程写，加 volatile 保证可见性
    private static WebView shellView;  // hermes-shell 页 WebView（cbId 回调投递目标）
    private boolean sessionApproved;
    private boolean immersive;
    /** W2: Java 回调监听（AgentLoop browser_* 工具桥接用；cbId → 消费方） */
    private final java.util.concurrent.ConcurrentHashMap<String, java.util.function.Consumer<String>> javaCbMap =
            new java.util.concurrent.ConcurrentHashMap<>();
    /** WebView 当前 URL（主线程 onPageFinished 缓存；report/snapshot 在 JavaBridge 线程用，防 WebView API 跨线程） */
    private volatile String lastPageUrl;
    /** Workflows: 事件 fire 单线程执行器——fire 跑后台线程，executeBrowserActionSync 的 latch.await
     *  不阻塞 mainLooper（否则 onPageFinished/tick 触发 fire 时 await 死锁，动作白等 10s） */
    private final java.util.concurrent.ExecutorService wfExec =
            java.util.concurrent.Executors.newSingleThreadExecutor();
    /** Workflows: interval 触发器心跳（10s 节拍，onCreate 启动 / onDestroy 停止） */
    private android.os.Handler wfTickHandler;
    private final Runnable wfTickRunnable = new Runnable() {
        @Override public void run() {
            try {
                com.hermes.android.workflow.Workflows w = com.hermes.android.workflow.Workflows.get();
                if (w != null) {
                    final com.hermes.android.workflow.Workflows fw = w;
                    wfExec.submit(() -> fw.source().tick(System.currentTimeMillis()));   // fire 后台线程
                }
            } catch (Exception e) { android.util.Log.e("Workflow", "tick dispatch error", e); }
            if (wfTickHandler != null) wfTickHandler.postDelayed(this, 10000);
        }
    };

    public static void setShellView(WebView w) { shellView = w; }
    public static ConnectWebActivity getCurrent() { return currentInstance; }

    /** W2: 注册 Java 回调（BrowserToolProvider 桥接）；evalJsCb 时会同时通知 */
    public void setJavaCallback(String cbId, java.util.function.Consumer<String> cb) {
        if (cbId != null) javaCbMap.put(cbId, cb);
    }
    public void clearJavaCallback(String cbId) {
        if (cbId != null) javaCbMap.remove(cbId);
    }

    /** open 导航：主线程 loadUrl（URL 白名单 http/https，非 http 拒） */
    private void executeOpen(JSONObject req, String cbId) {
        String url = req.optString("url", "");
        // P1 A: platform+keyword → searchTemplate 构造搜索 URL（LLM 免构造 URL，与 openConnectSearch 同源）
        if (url.isEmpty()) {
            String platform = req.optString("platform", "");
            String keyword = req.optString("keyword", "");
            if (!platform.isEmpty() && !keyword.isEmpty()) {
                PlatformConfig cfg = PLATFORMS.get(platform);
                if (cfg == null) cfg = PLATFORMS.get("douyin");
                try {
                    url = cfg.searchTemplate.replace("{keyword}",
                            java.net.URLEncoder.encode(keyword.trim(), "UTF-8"));
                } catch (Exception e) {
                    evalJsCb(cbId, "{\"error\":\"encode_failed\",\"recovery\":\"keyword 编码失败\"}");
                    return;
                }
            }
        }
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            evalJsCb(cbId, "{\"error\":\"scheme_blocked\",\"recovery\":\"open 需 url，或 platform+keyword（如 platform=douyin keyword=庆余年 评价）\"}");
            return;
        }
        final String finalUrl = url;
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
            if (web == null) { evalJsCb(cbId, "{\"error\":\"browser_not_open\"}"); return; }
            web.loadUrl(finalUrl);
            evalJsCb(cbId, "{\"opened\":true,\"url\":\"" + finalUrl.replace("\"", "") + "\"}");
        });
    }

    /* W2: snapshot — 页面元素快照 (readonly, 免审批) */
    private void executeSnapshot(JSONObject req, String cbId) {
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
            if (web == null) { evalJsCb(cbId, "{\"error\":\"browser_not_open\"}"); return; }
            web.evaluateJavascript("MovConnect.snapshot()", raw ->
                evalJsCb(cbId, "{\"ok\":true,\"snapshot\":" + String.valueOf(raw) + "}"));
        });
    }
    /* W2: get_text — 读页面正文 (readonly, 免审批) */
    private void executeGetText(JSONObject req, String cbId) {
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
            if (web == null) { evalJsCb(cbId, "{\"error\":\"browser_not_open\"}"); return; }
            web.evaluateJavascript("MovConnect.getText(4000)", raw ->
                evalJsCb(cbId, "{\"ok\":true,\"text\":" + String.valueOf(raw) + "}"));
        });
    }

    /** 浏览器动作同步执行（workflow BrowserActionExecutor 用；javaCbMap 桥 + CountDownLatch，10s 超时） */
    public String executeBrowserActionSync(JSONObject action) {
        String cbId = "wf_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 100000);
        java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(1);
        final String[] res = {null};
        setJavaCallback(cbId, r -> { res[0] = r; latch.countDown(); });
        try {
            new android.os.Handler(android.os.Looper.getMainLooper())
                    .post(() -> executeBrowserAction(action.toString(), cbId));
            latch.await(10, java.util.concurrent.TimeUnit.SECONDS);
            clearJavaCallback(cbId);
        } catch (Exception e) {
            clearJavaCallback(cbId);
        }
        return res[0];
    }

    /** 异步执行浏览器动作（cbId 回调，协议 §1/§8） */
    public void executeBrowserAction(String actionJson, String cbId) {
        if (web == null) {
            evalJsCb(cbId, "{\"error\":\"browser_not_open\",\"recovery\":\"No ConnectWeb activity active.\"}");
            return;
        }
        try {
            JSONObject req = new JSONObject(actionJson);
            String type = req.optString("type", "");
            // click_and_read 复合工具：点→等→读 一次往返
            if ("click_and_read".equals(type)) {
                executeClickAndRead(req, cbId);
                return;
            }
            // wait_for：Java 轮询，不经过审批
            if ("wait_for".equals(type)) {
                executeWaitFor(req, cbId);
                return;
            }
            // open：导航到 URL（主线程 loadUrl）
            if ("open".equals(type)) {
                executeOpen(req, cbId);
                return;
            }
            // W2: snapshot/get_text 页面快照/正文（readonly, 免审批）——evaluateJavascript MovConnect.* 回传 JSON
            if ("snapshot".equals(type)) { executeSnapshot(req, cbId); return; }
            if ("get_text".equals(type)) { executeGetText(req, cbId); return; }
            // 写动作需要审批（scroll/wait_for 豁免）；类型分派抽纯 JVM（BrowserActionRouter）
            boolean isWrite = com.hermes.android.browser.BrowserActionRouter.isWrite(type);
            if (isWrite) {
                // ★ 支付域检测 + Keyguard 必须在主线程（WebView API 纪律）
                //    executeBrowserAction 在 JavaBridge 线程被调——post 到主线程执行
                final String fType = type;
                final JSONObject fReq = req;
                final String fCbId = cbId;
                new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                    if (web == null) {
                        evalJsCb(fCbId, "{\"error\":\"browser_not_open\"}");
                        return;
                    }
                    String currentUrl = web.getUrl();
                    if (paymentGate != null && paymentGate.isPaymentDomain(currentUrl)) {
                        if ("execute".equals(fType)) {
                            JSONObject audit = paymentGate.auditEvent(fType, currentUrl, "blocked_eval_js");
                            android.util.Log.w("ConnectWeb", "PaymentGate blocked eval_js: " + audit);
                            evalJsCb(fCbId, "{\"error\":\"payment_eval_js_blocked\",\"recovery\":\"eval_js is not allowed on payment pages.\"}");
                            return;
                        }
                        String desc = fType + " "
                                + (fReq.has("eid") ? "eid:" + fReq.optInt("eid")
                                   : fReq.optString("selector", "?"));
                        JSONObject audit = paymentGate.auditEvent(fType, currentUrl, "prompting");
                        android.util.Log.i("ConnectWeb", "PaymentGate audit: " + audit);
                        paymentGate.promptPaymentApproval(ConnectWebActivity.this, desc,
                            () -> {
                                JSONObject ok = paymentGate.auditEvent(fType, currentUrl, "success");
                                android.util.Log.i("ConnectWeb", "PaymentGate audit: " + ok);
                                executeInternalWithMask(fReq, fCbId, currentUrl);
                            },
                            () -> {
                                String reason = paymentGate.getLastRejectReason();
                                JSONObject no = paymentGate.auditEvent(fType, currentUrl,
                                        reason != null ? reason : "cancelled");
                                android.util.Log.i("ConnectWeb", "PaymentGate audit: " + no);
                                evalJsCb(fCbId, "{\"error\":\"gate_rejected\",\"recovery\":\"Payment requires biometric confirmation.\"}");
                            });
                        return;
                    }
                    // 非支付域：原有审批流
                    if (!sessionApproved) {
                        ConnectWebActivity.this.showApprovalDialog(fReq, fCbId);
                        return;
                    }
                    ConnectWebActivity.this.executeInternal(fReq, fCbId);
                });
                return;  // 已 post，外层不再 executeInternal
            }
            // 修复1：非写已知类型（scroll 等）→ executeInternal（此前 fall-through 静默丢弃）
            if (!com.hermes.android.browser.BrowserActionRouter.isKnown(type)) {
                evalJsCb(cbId, "{\"error\":\"unknown_type\",\"recovery\":\"类型 " + type + " 未定义执行落点\"}");
                return;
            }
            executeInternal(req, cbId);
        } catch (Exception e) {
            evalJsCb(cbId, "{\"error\":\"js_failed\",\"recovery\":\"" + e.getMessage() + "\"}");
        }
    }

    /** 支付域写操作: executeInternal + envelope 掩码注入 */
    private void executeInternalWithMask(JSONObject req, String cbId, String currentUrl) {
        // 掩码支付上下文注入 cbId 回调——先执行，结果经 mask 包装后回传
        // 简化: 在 evalJsCb 层做掩码（见 maskResponse）
        executeInternal(req, cbId);
    }

    private void executeInternal(JSONObject req, String cbId) {
        String type = req.optString("type", "");
        // click 走原生触摸（SPA 只认 MotionEvent, JS 合成 pointer 时灵时不灵）
        if ("click".equals(type)) {
            executeClickNative(req, cbId);
            return;
        }
        final String jsResult = "MovConnect.executeAction(" + req.toString() + ")";
        // 修复1: submit 乐观回执——form.submit 触发导航会丢 WebView 挂起的 JS 回调，先回执不等 after 快照
        if ("submit".equals(type)) {
            evalJsCb(cbId, "{\"submitted\":true}");
        }
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
            if (web == null) {
                evalJsCb(cbId, "{\"error\":\"browser_not_open\"}");
                return;
            }
            web.evaluateJavascript(jsResult, raw -> {
                String result = raw != null ? raw : "";
                if (result.startsWith("\"")) result = result.substring(1, result.length() - 1).replace("\\\"", "\"");
                try {
                    JSONObject jsr = new JSONObject(result);
                    if (jsr.has("error")) {
                        evalJsCb(cbId, jsr.toString());
                    } else if (jsr.has("scroll_y")) {
                        evalJsCb(cbId, jsr.toString());
                    } else if (jsr.optBoolean("_async")) {
                        // paint settle：等 settleMs 后取 after 快照
                        int settleMs = jsr.optInt("settleMs", 600);
                        String before = jsr.optString("before", "");
                        new android.os.Handler().postDelayed(() -> {
                            if (web == null) { evalJsCb(cbId, "{\"error\":\"browser_not_open\"}"); return; }
                            web.evaluateJavascript(
                                "var after=(document.body||document.documentElement).innerText||'';"
                                + "JSON.stringify({before:'" + before.replace("'", "\\'") + "',after:after});",
                                raw2 -> {
                                    String r2 = raw2 != null ? raw2 : "";
                                    if (r2.startsWith("\"")) r2 = r2.substring(1, r2.length() - 1).replace("\\\"", "\"");
                                    try {
                                        JSONObject snap = new JSONObject(r2);
                                        JSONObject diff = BrowserDiffHelper.diff(
                                                snap.optString("before"), snap.optString("after"));
                                        evalJsCb(cbId, diff.toString());
                                    } catch (Exception e) {
                                        evalJsCb(cbId, "{\"error\":\"js_failed\"}");
                                    }
                                });
                        }, settleMs);
                    } else if (jsr.has("before") && jsr.has("after")) {
                        JSONObject diff = BrowserDiffHelper.diff(jsr.optString("before"), jsr.optString("after"));
                        evalJsCb(cbId, diff.toString());
                    } else {
                        evalJsCb(cbId, "{\"unchanged\":true}");
                    }
                } catch (Exception e) {
                    evalJsCb(cbId, "{\"error\":\"js_failed\",\"recovery\":\"Diff parse failed\"}");
                }
            });
        });
    }

    /** click 原生触摸：JS 取坐标 → dispatchNativeTap → diff */
    private void executeClickNative(JSONObject req, String cbId) {
        String targetJs;
        if (req.has("eid")) {
            targetJs = "document.querySelector('[data-mov-eid=\"" + req.optInt("eid") + "\"]')";
        } else if (req.has("selector")) {
            targetJs = "document.querySelector('" + req.optString("selector") + "')";
        } else {
            evalJsCb(cbId, "{\"error\":\"selector_not_found\",\"recovery\":\"Need eid or selector for click.\"}");
            return;
        }
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
            if (web == null) { evalJsCb(cbId, "{\"error\":\"browser_not_open\"}"); return; }
            // 1. 取坐标 + before 快照
            web.evaluateJavascript(
                "(function(){var el=" + targetJs + ";if(!el)return'{\"error\":\"selector_not_found\"}';"
                + "var r=el.getBoundingClientRect();"
                + "var before=(document.body||document.documentElement).innerText||'';"
                + "return JSON.stringify({x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2),"
                + "before:before});})()",
                raw -> {
                    String r = raw != null ? raw : "";
                    if (r.startsWith("\"")) r = r.substring(1, r.length() - 1).replace("\\\"", "\"");
                    try {
                        JSONObject pos = new JSONObject(r);
                        if (pos.has("error")) { evalJsCb(cbId, pos.toString()); return; }
                        int x = pos.optInt("x"), y = pos.optInt("y");
                        String before = pos.optString("before", "");
                        // 2. 原生触摸
                        float scale = web.getScale();
                        dispatchNativeTap(web, Math.round(x * scale), Math.round(y * scale));
                        // 3. eid 失效 + after 快照
                        web.evaluateJavascript(
                            "var els=document.querySelectorAll('[data-mov-eid]');"
                            + "for(var i=0;i<els.length;i++)els[i].removeAttribute('data-mov-eid');"
                            + "var after=(document.body||document.documentElement).innerText||'';"
                            + "JSON.stringify({before:'" + before.replace("'", "\\'") + "',after:after});",
                            raw2 -> {
                                String r2 = raw2 != null ? raw2 : "";
                                if (r2.startsWith("\"")) r2 = r2.substring(1, r2.length() - 1).replace("\\\"", "\"");
                                try {
                                    JSONObject snap = new JSONObject(r2);
                                    JSONObject diff = BrowserDiffHelper.diff(
                                            snap.optString("before"), snap.optString("after"));
                                    evalJsCb(cbId, diff.toString());
                                } catch (Exception e) {
                                    evalJsCb(cbId, "{\"error\":\"js_failed\"}");
                                }
                            });
                    } catch (Exception e) {
                        evalJsCb(cbId, "{\"error\":\"js_failed\",\"recovery\":\"" + e.getMessage() + "\"}");
                    }
                });
        });
    }

    private void showApprovalDialog(JSONObject action, String cbId) {
        String desc = action.optString("type", "") + " "
                + (action.has("eid") ? "eid:" + action.optInt("eid")
                   : action.optString("selector", "?"));
        new android.app.AlertDialog.Builder(this)
                .setTitle("浏览器动作确认")
                .setMessage(desc + "\n\n允许本次操作？")
                .setPositiveButton("允许", (d, w) -> {
                    sessionApproved = true;  // 本会话后续免确认
                    executeInternal(action, cbId);
                })
                .setNeutralButton("仅本次", (d, w) -> {
                    executeInternal(action, cbId);
                })
                .setNegativeButton("拒绝", (d, w) -> {
                    evalJsCb(cbId, "{\"error\":\"gate_rejected\",\"recovery\":\"User rejected the action.\"}");
                })
                .show();
    }

    /** click_and_read：原生触摸→等 paint settle→Readability 正文 一次 cbId 往返 */
    private void executeClickAndRead(JSONObject req, String cbId) {
        // 先用 click 的原生触摸路径
        String targetJs;
        if (req.has("eid")) {
            targetJs = "document.querySelector('[data-mov-eid=\"" + req.optInt("eid") + "\"]')";
        } else if (req.has("selector")) {
            targetJs = "document.querySelector('" + req.optString("selector") + "')";
        } else {
            evalJsCb(cbId, "{\"error\":\"selector_not_found\"}"); return;
        }
        int settleMs = req.optInt("_settleMs", 600);
        int maxChars = req.optInt("max_chars", 4000);
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
            if (web == null) { evalJsCb(cbId, "{\"error\":\"browser_not_open\"}"); return; }
            web.evaluateJavascript(
                "(function(){var el=" + targetJs + ";if(!el)return'{\"error\":\"selector_not_found\"}';"
                + "var r=el.getBoundingClientRect();"
                + "return JSON.stringify({x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2)});})()",
                raw -> {
                    String rr = raw != null ? raw : "";
                    if (rr.startsWith("\"")) rr = rr.substring(1, rr.length() - 1).replace("\\\"", "\"");
                    try {
                        JSONObject pos = new JSONObject(rr);
                        if (pos.has("error")) { evalJsCb(cbId, pos.toString()); return; }
                        float scale = web.getScale();
                        dispatchNativeTap(web, Math.round(pos.optInt("x") * scale), Math.round(pos.optInt("y") * scale));
                        // 等 paint settle 后读正文
                        new android.os.Handler().postDelayed(() -> {
                            web.evaluateJavascript(
                                "JSON.stringify({text:MovConnect.getText(" + maxChars + "),"
                                + "readabilityReady:MovConnect._readabilityReady()})",
                                raw2 -> {
                                    String r2 = raw2 != null ? raw2 : "";
                                    if (r2.startsWith("\"")) r2 = r2.substring(1, r2.length() - 1).replace("\\\"", "\"");
                                    try {
                                        JSONObject text = new JSONObject(r2);
                                        evalJsCb(cbId, text.toString());
                                    } catch (Exception e) {
                                        evalJsCb(cbId, "{\"error\":\"js_failed\"}");
                                    }
                                });
                        }, settleMs);
                    } catch (Exception e) {
                        evalJsCb(cbId, "{\"error\":\"js_failed\",\"recovery\":\"" + e.getMessage() + "\"}");
                    }
                });
        });
    }

    /** wait_for：Java 轮询 MovConnect.waitFor(selector, state, containsText, timeout) */
    private void executeWaitFor(JSONObject req, String cbId) {
        String selector = req.optString("selector", "");
        if (selector.isEmpty()) {
            evalJsCb(cbId, "{\"error\":\"selector_not_found\",\"recovery\":\"wait_for requires a selector.\"}"); return;
        }
        String state = req.optString("state", "visible");
        String containsText = req.optString("contains_text", "");
        int timeoutMs = req.optInt("timeout_ms", 10000);
        String js = "MovConnect.waitFor('" + selector.replace("'", "\\'") + "','" + state + "','"
                + containsText.replace("'", "\\'") + "'," + timeoutMs + ")";
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
            if (web == null) { evalJsCb(cbId, "{\"error\":\"browser_not_open\"}"); return; }
            web.evaluateJavascript(js + ".then(function(r){window._movWaitResult=r;})", null);
            // 轮询等 Promise resolve（Promise 在 JS 侧完成，_movWaitResult 标记）
            new android.os.Handler().postDelayed(new Runnable() {
                int elapsed;
                public void run() {
                    if (web == null) { evalJsCb(cbId, "{\"error\":\"browser_not_open\"}"); return; }
                    elapsed += 300;
                    web.evaluateJavascript("window._movWaitResult||''", raw -> {
                        String r = raw != null ? raw : "";
                        if (r.startsWith("\"")) r = r.substring(1, r.length() - 1).replace("\\\"", "\"");
                        if (r != null && !r.isEmpty() && !"null".equals(r) && !"undefined".equals(r)) {
                            evalJsCb(cbId, r);
                        } else if (elapsed >= timeoutMs + 2000) {
                            evalJsCb(cbId, "{\"found\":false,\"timeout\":true,\"elapsed_ms\":" + elapsed + "}");
                        } else {
                            new android.os.Handler().postDelayed(this, 300);
                        }
                    });
                }
            }, 300);
        });
    }

    private void evalJsCb(String cbId, String json) {
        // cbId 回调投递到 hermes-shell 页（非当前平台页；_hermesCb 只活在 shell）
        if (shellView != null) {
            shellView.post(() -> shellView.evaluateJavascript(
                    "window._hermesCb('" + cbId + "'," + json + ")", null));
        }
        // W2: 同时通知 Java 监听（AgentLoop browser_* 工具桥接）
        java.util.function.Consumer<String> cb = javaCbMap.remove(cbId);
        if (cb != null) cb.accept(json);
    }

    private void dispatchNativeTap(WebView view, int x, int y) {
        long t = android.os.SystemClock.uptimeMillis();
        android.view.MotionEvent down = android.view.MotionEvent.obtain(
                t, t, android.view.MotionEvent.ACTION_DOWN, x, y, 0);
        android.view.MotionEvent up = android.view.MotionEvent.obtain(
                t, t + 60, android.view.MotionEvent.ACTION_UP, x, y, 0);
        view.dispatchTouchEvent(down);
        view.dispatchTouchEvent(up);
        down.recycle();
        up.recycle();
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 调试包开 WebView 远程调试（验收诊断沉浸隐藏 JS / 自杀用）
        android.webkit.WebView.setWebContentsDebuggingEnabled(com.hermes.android.BuildConfig.DEBUG);

        Intent intent = getIntent();
        String platform = intent.getStringExtra("platform");
        if (platform == null) platform = "douyin";
        PlatformConfig cfg = PLATFORMS.get(platform);
        if (cfg == null) cfg = PLATFORMS.get("douyin");

        boolean isLogin = "login".equals(intent.getStringExtra("mode"));
        String keyword = intent.getStringExtra("keyword");
        String url = intent.getStringExtra("url"); // override

        if (url == null || url.isEmpty()) {
            if (isLogin) {
                url = cfg.loginUrl;
            } else if (keyword != null && !keyword.isEmpty()) {
                url = cfg.searchTemplate.replace("{keyword}", keyword);
            } else {
                url = cfg.loginUrl;
            }
        }

        // 顶栏
        final boolean loginMode = isLogin;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor(cfg.barColor));

        FrameLayout bar = new FrameLayout(this);
        bar.setPadding(dp(12), statusBarHeight() + dp(4), dp(12), dp(10));
        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextColor(Color.WHITE);
        close.setTextSize(18);
        close.setPadding(dp(6), 0, dp(6), 0);
        close.setOnClickListener(v -> finish());
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(-2, -2);
        clp.gravity = android.view.Gravity.START | android.view.Gravity.CENTER_VERTICAL;
        bar.addView(close, clp);

        TextView title = new TextView(this);
        // 标题：url override 时用域名，否则用平台名
        String titleText = cfg.title;
        if (intent.getStringExtra("url") != null && !intent.getStringExtra("url").isEmpty()) {
            try {
                java.net.URI u = new java.net.URI(url);
                String host = u.getHost();
                if (host != null) titleText = host.replace("www.", "").replace("m.", "");
            } catch (Exception ignored) {}
        }
        title.setText(isLogin ? "连接" + titleText + " · 扫码登录一次" : titleText);
        title.setTextColor(Color.parseColor("#9a938a"));
        title.setTextSize(13);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(-2, -2);
        tlp.gravity = android.view.Gravity.CENTER;
        bar.addView(title, tlp);

        if (isLogin) {
            Button done = new Button(this);
            done.setText("完成");
            done.setTextSize(13);
            FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(-2, -2);
            dlp.gravity = android.view.Gravity.END | android.view.Gravity.CENTER_VERTICAL;
            bar.addView(done, dlp);
            done.setOnClickListener(v -> finish());
        }
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        ruleEngine = new SiteRuleEngine(this);
        paymentGate = new PaymentGate(this);
        paymentGate.setAuditDir(getFilesDir());

        web = new WebView(this);
        web.addJavascriptInterface(new com.hermes.android.scene.WatchBridge(getFilesDir()), "WatchBridge");
        web.addJavascriptInterface(new QRBridge(), "MOVQR");
        // Workflows: element_appear / text_match 检测报告桥（JS 轮询 → 引擎事件）
        web.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface
            public void report(String type, String selector, String text) {
                try {
                    android.util.Log.i("Workflow", "report type=" + type
                            + " sel=" + (selector != null ? selector : "") + " text=" + (text != null ? text : ""));
                    com.hermes.android.workflow.Workflows w = com.hermes.android.workflow.Workflows.get();
                    android.util.Log.i("Workflow", "dispatch w=" + (w != null)
                            + " src=" + (w != null && w.source() != null));
                    if (w == null) return;
                    // fire 切后台线程（JavaBridge/mainLooper 上 await 会死锁或阻塞）
                    wfExec.submit(() -> {
                        long now = System.currentTimeMillis();
                        if ("element_appear".equals(type)) w.source().onElementAppear(selector, lastPageUrl, now);
                        else if ("text_match".equals(type)) w.source().onTextMatch(text, lastPageUrl, now);
                    });
                } catch (Exception e) {
                    android.util.Log.e("Workflow", "report dispatch error", e);
                }
            }
            @android.webkit.JavascriptInterface
            public void snapshot(String text, String presentJson) {
                // 条件快照 v2：页面 innerText + 存在的条件 selector → source 回填（element/text 条件据此评估）
                try {
                    java.util.List<String> present = new java.util.ArrayList<>();
                    if (presentJson != null && !presentJson.isEmpty()) {
                        org.json.JSONArray arr = new org.json.JSONArray(presentJson);
                        for (int i = 0; i < arr.length(); i++) present.add(arr.optString(i));
                    }
                    android.util.Log.i("Workflow", "snapshot textLen=" + (text != null ? text.length() : 0)
                            + " present=" + present.size());
                    com.hermes.android.workflow.Workflows w = com.hermes.android.workflow.Workflows.get();
                    if (w == null) return;
                    w.source().setPageSnapshot(text, present);
                } catch (Exception e) {
                    android.util.Log.e("Workflow", "snapshot dispatch error", e);
                }
            }
        }, "MovWfReport");
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);   // 防外部跳转：禁用多窗口，target=_blank 不弹新窗/系统浏览器，追剧播放必须留 app 内
        // 桌面 UA：减少移动端重定向
        String baseUA = s.getUserAgentString().replace(" Mobile ", " ").replace(" Android ", " ");
        String ruleUA = ruleEngine.getUAOverride(url);
        s.setUserAgentString(ruleUA != null ? ruleUA : baseUA);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        final String loadUrl = url;
        final String readabilityJs = readAssetString("readability/Readability.js");
        final String movConnectJs = readAssetString("mov_connect.js");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String requestUrl) {
                if (ruleEngine.shouldBlockScheme(requestUrl, view.getUrl())) {
                    android.util.Log.d("ConnectWeb", "Blocked scheme: " + requestUrl);
                    return true;
                }
                // 防外部跳转：http/https 一律当前 WebView 加载（target=_blank/新窗 URL 也被拦回当前页，不跳系统浏览器）
                if (requestUrl.startsWith("http://") || requestUrl.startsWith("https://")) {
                    view.loadUrl(requestUrl);
                    return true;
                }
                return super.shouldOverrideUrlLoading(view, requestUrl);
            }

            @Override
            public void onPageFinished(WebView view, String pageUrl) {
                lastPageUrl = pageUrl;   // 主线程缓存 URL（report JavaBridge 线程用）
                // Workflows: 页面加载/URL 变化事件注入触发器引擎（fire 切后台线程，防 mainLooper await 死锁）
                try {
                    com.hermes.android.workflow.Workflows w = com.hermes.android.workflow.Workflows.get();
                    if (w != null) {
                        WorkflowEventSource src = w.source();
                        wfExec.submit(() -> src.onPageFinished(pageUrl, System.currentTimeMillis()));
                        w.resyncDeviceTriggers();   // 设备触发器按 workflow 变更 resync（零启用零常驻）
                    }
                } catch (Exception e) { android.util.Log.e("Workflow", "pageFinished dispatch error", e); }
                // Workflows: element_appear / text_match 检测轮询注入（读启用的 selector/pattern）
                try {
                    com.hermes.android.workflow.Workflows w = com.hermes.android.workflow.Workflows.get();
                    if (w != null) {
                        java.util.List<String> sels = w.elementSelectors();
                        java.util.List<String> pats = w.textPatterns();
                        android.util.Log.i("Workflow", "inject detect sels=" + sels.size() + " pats=" + pats.size());
                        if (!sels.isEmpty() || !pats.isEmpty()) {
                            String selsJson = new org.json.JSONArray(sels).toString();
                            String patsJson = new org.json.JSONArray(pats).toString();
                            view.evaluateJavascript(
                                "(function(){var sels=" + selsJson + ",pats=" + patsJson + ";"
                                + "var doneS={},doneT={};"
                                + "setInterval(function(){"
                                + "for(var i=0;i<sels.length;i++){if(!doneS[sels[i]]&&document.querySelector(sels[i])){doneS[sels[i]]=1;"
                                + "if(window.MovWfReport)MovWfReport.report('element_appear',sels[i],'');}}"
                                + "var txt=(document.body||{}).innerText||'';"
                                + "for(var j=0;j<pats.length;j++){if(!doneT[pats[j]]&&txt.indexOf(pats[j])>=0){doneT[pats[j]]=1;"
                                + "if(window.MovWfReport)MovWfReport.report('text_match','',pats[j]);}}"
                                + "},2000);})();", null);
                        }
                    }
                } catch (Exception e) { android.util.Log.e("Workflow", "detect inject error", e); }
                // Workflows: 条件快照 v2 — 查询页面 innerText + 条件 element selectors 存在性（5s 周期回填）
                try {
                    com.hermes.android.workflow.Workflows w = com.hermes.android.workflow.Workflows.get();
                    if (w != null) {
                        java.util.List<String> condSels = w.conditionElementSelectors();
                        android.util.Log.i("Workflow", "inject snapshot condSels=" + condSels.size());
                        String condSelsJson = new org.json.JSONArray(condSels).toString();
                        view.evaluateJavascript(
                            "(function(){var sels=" + condSelsJson + ";"
                            + "setInterval(function(){"
                            + "var text=(document.body||{}).innerText||'';"
                            + "var present=[];"
                            + "for(var i=0;i<sels.length;i++){if(document.querySelector(sels[i]))present.push(sels[i]);}"
                            + "if(window.MovWfReport)MovWfReport.snapshot(text, JSON.stringify(present));"
                            + "},5000);})();", null);
                    }
                } catch (Exception e) { android.util.Log.e("Workflow", "snapshot inject error", e); }
                // afterLoad 站点脚本注入（site_rules.json）
                java.util.List<SiteRuleEngine.AfterLoadScript> scripts = ruleEngine.getAfterLoadScripts(pageUrl);
                for (SiteRuleEngine.AfterLoadScript script : scripts) {
                    android.util.Log.d("ConnectWeb", "Injecting afterLoad: " + script.desc);
                    view.evaluateJavascript(script.script, null);
                }
                // 任务R·支付二维码检测：注入 detector + poll MovQRFound
                if (pageUrl != null && (pageUrl.contains("pay") || pageUrl.contains("order") || pageUrl.contains("qr"))) {
                    view.evaluateJavascript(com.hermes.android.security.PayQRRelay.getDetectionScript(), null);
                    new android.os.Handler().postDelayed(() -> {
                        view.evaluateJavascript("window.MovQRFound", raw -> {
                            if ("true".equals(raw != null ? raw.replace("\"","") : "")) {
                                // QR found → capture + wechat launch
                                com.hermes.android.security.PayQRRelay.captureAndSave(view);
                                com.hermes.android.security.PayQRRelay.launchWechatScan(ConnectWebActivity.this);
                                if (bar != null) bar.setVisibility(View.VISIBLE);
                                android.widget.Toast.makeText(ConnectWebActivity.this,
                                    com.hermes.android.security.PayQRRelay.getGuideText(), android.widget.Toast.LENGTH_LONG).show();
                            }
                        });
                    }, 3000);
                }

                // 任务I'·播放页沉浸：藏页眉/广告/选集 + 等播放器 → 点播放 → 全屏
                if (immersive && pageUrl != null && pageUrl.contains("vodplay")) {
                    // 先藏干扰元素（属性前缀选择器覆盖 BEM；延迟重试应对异步 DOM）
                    applyImmersiveHide(view);
                    new android.os.Handler().postDelayed(() -> applyImmersiveHide(view), 800);
                }
                if (immersive && pageUrl != null && pageUrl.contains("vodplay")) {
                    view.evaluateJavascript(
                        "(function(){var tries=0;function tryClickPlay(){"
                        + "var btns=document.querySelectorAll('.dplayer-play,.stui-player__play,.plyr__control--overlaid,button[title*=\"播放\"],.play-btn,.btn-play');"
                        + "for(var i=0;i<btns.length;i++){var b=btns[i];if(b.offsetWidth>0){b.click();var v=document.querySelector('video');"
                        + "if(v){v.muted=true;v.play().catch(function(){});"
                        + "var fs=v.requestFullscreen||v.webkitRequestFullscreen;"
                        + "if(fs)setTimeout(function(){fs.call(v).catch(function(){});},500);}"
                        + "return;}}"
                        + "if(++tries<15)setTimeout(tryClickPlay,600);}tryClickPlay();})();", null);
                }
                // Readability + MovConnect 每页注入（mov_connect.js 自带幂等守卫）
                if (readabilityJs != null && !readabilityJs.isEmpty()) {
                    view.evaluateJavascript(readabilityJs, null);
                }
                if (movConnectJs != null && !movConnectJs.isEmpty()) {
                    view.evaluateJavascript(movConnectJs, null);
                }
            }
        });
        final FrameLayout fullscreenHolder = new FrameLayout(this);
        fullscreenHolder.setBackgroundColor(Color.parseColor("#0e0f11"));
        fullscreenHolder.setVisibility(View.GONE);
        root.addView(fullscreenHolder, new LinearLayout.LayoutParams(-1, 0, 1f));

        // 沉浸模式：点画面切换顶栏
        if (immersive) {
            root.setOnClickListener(v -> {
                if (bar.getVisibility() == View.GONE) {
                    bar.setVisibility(View.VISIBLE);
                    new android.os.Handler().postDelayed(() -> bar.setVisibility(View.GONE), 3000);
                }
            });
        }

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
                // 拦截新窗（target=_blank 弹窗）：防跳系统浏览器，追剧播放必须留在 app 内
                return false;
            }
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                // 视频全屏：隐藏顶栏+锁横屏+holder铺满
                bar.setVisibility(View.GONE);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                fullscreenHolder.addView(view);
                fullscreenHolder.setVisibility(View.VISIBLE);
                web.setVisibility(View.GONE);
                super.onShowCustomView(view, callback);
            }
            @Override
            public void onHideCustomView() {
                bar.setVisibility(View.VISIBLE);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                fullscreenHolder.removeAllViews();
                fullscreenHolder.setVisibility(View.GONE);
                web.setVisibility(View.VISIBLE);
                super.onHideCustomView();
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1f));

        // 任务I'·沉浸模式：vodplay 页 → 藏顶栏 + 黑底 + 自动播放
        immersive = url != null && url.contains("vodplay");
        if (immersive) {
            root.setBackgroundColor(Color.parseColor("#0e0f11"));
            // 3s 后沉浸：顶栏渐隐（点画面可恢复）
            new android.os.Handler().postDelayed(() -> {
                if (bar != null) bar.setVisibility(View.GONE);
            }, 3000);
        }

        setContentView(root);
        web.loadUrl(url);
        currentInstance = this;
        // Workflows: interval 触发器心跳（10s 节拍，页面操作期间有效）
        wfTickHandler = new android.os.Handler(android.os.Looper.getMainLooper());
        wfTickHandler.postDelayed(wfTickRunnable, 10000);
        com.hermes.android.SessionVault.get().start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        com.hermes.android.SessionVault.get().onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (paymentGate != null && paymentGate.handleActivityResult(requestCode, resultCode)) return;
    }

    private String readAssetString(String path) {
        try (java.io.InputStream is = getAssets().open(path)) {
            java.io.BufferedReader r = new java.io.BufferedReader(
                    new java.io.InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        } catch (Exception e) {
            android.util.Log.w("ConnectWeb", "Failed to read asset: " + path);
            return null;
        }
    }

    /** 任务I'·播放页沉浸：藏页眉/广告/选集。
     *  属性前缀选择器覆盖 BEM（如 stui-header__top）+ DV-2 白名单兜底：
     *  body 直接子节点中非 player（含评论区 stui-comment/残留 panel）一律 display:none，播放器白名单豁免。
     *  evaluateJavascript 回调返回隐藏计数（可观测，不再静默）。 */
    private void applyImmersiveHide(android.webkit.WebView view) {
        if (view == null) return;
        view.evaluateJavascript(
            "(function(){"
            + "var sels=['[class^=\"stui-header\"],[class*=\" stui-header\"]','[class^=\"stui-foot\"],[class*=\" stui-foot\"]',"
            + "'[class^=\"stui-vodlist\"],[class*=\" stui-vodlist\"]','.navbar','.header','.footer','.ad','.ads',"
            + "'[class^=\"stui-player__detail\"],[class*=\" stui-player__detail\"]','[class^=\"stui-player__info\"],[class*=\" stui-player__info\"]',"
            + "'[class^=\"stui-page__title\"],[class*=\" stui-page__title\"]','[class^=\"stui-content__playlist\"],[class*=\" stui-content__playlist\"]',"
            + "'[class^=\"mac_comment\"],[class*=\" mac_comment\"]','.mac_comment',"
            + "'.playlist','.episode-list','.vodlist'];"
            + "function hideAll(){var h=0;"
            + "for(var i=0;i<sels.length;i++){var els=document.querySelectorAll(sels[i]);for(var j=0;j<els.length;j++){els[j].style.display='none';h++;}}"
            + "var kids=document.body.children;"
            + "for(var i=0;i<kids.length;i++){var c=kids[i];"
            + "if(c.tagName==='SCRIPT'||c.tagName==='STYLE')continue;"
            + "if(player&&(c===player||c.contains(player)))continue;"
            + "c.style.display='none';h++;}"
            + "return h;}"
            + "document.body.style.margin='0';document.body.style.padding='0';document.body.style.background='#0e0f11';"
            + "var player=document.querySelector('[class^=\"stui-player__video\"],[class*=\" stui-player__video\"],.dplayer,.plyr');"
            + "if(player){player.style.position='fixed';player.style.inset='0';player.style.zIndex='999';}"
            + "var hidden=hideAll();"
            + "/* DV-2: MutationObserver 监听异步新增（评论区延迟渲染），命中规则即藏，30s 自动断开 */"
            + "var mo=new MutationObserver(function(muts){"
            + "for(var i=0;i<muts.length;i++){var added=muts[i].addedNodes;"
            + "for(var j=0;j<added.length;j++){var n=added[j];"
            + "if(n.nodeType!==1)continue;"
            + "var hit=false;"
            + "for(var k=0;k<sels.length;k++){"
            + "if(n.matches&&n.matches(sels[k])){n.style.display='none';hit=true;}"
            + "if(n.querySelectorAll){var sub=n.querySelectorAll(sels[k]);for(var s=0;s<sub.length;s++)sub[s].style.display='none';}}"
            + "if(!hit&&n.parentNode===document.body&&!(player&&(n===player||n.contains(player)))){n.style.display='none';}}"
            + "}});"
            + "mo.observe(document.body,{childList:true,subtree:true});"
            + "setTimeout(function(){mo.disconnect();},30000);"
            + "return JSON.stringify({hidden:hidden,selCount:sels.length});"
            + "})();",
            r -> { try { android.util.Log.i("ConnectWeb", "immersive hide result: " + (r != null ? r : "null")); } catch (Exception ignored) {} });
    }

    @Override
    public void onBackPressed() {
        android.util.Log.w("ConnectWeb", "onBackPressed called. stack=" + android.util.Log.getStackTraceString(new Throwable()));
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        // 自杀诊断埋点：抓自动关闭调用栈（无用户操作时）
        android.util.Log.w("ConnectWeb", "onDestroy called. stack=" + android.util.Log.getStackTraceString(new Throwable()));
        if (wfTickHandler != null) { wfTickHandler.removeCallbacks(wfTickRunnable); wfTickHandler = null; }
        if (currentInstance == this) currentInstance = null;
        if (web != null) {
            web.loadUrl("about:blank");
            web.destroy();
        }
        super.onDestroy();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    /** 支付二维码桥（任务R，JS可调 MOVQR.relay() 触发截屏+微信扫一扫） */
    public class QRBridge {
        @android.webkit.JavascriptInterface
        public void relay(String json) {
            runOnUiThread(() -> {
                com.hermes.android.security.PayQRRelay.captureAndSave(web);
                com.hermes.android.security.PayQRRelay.launchWechatScan(ConnectWebActivity.this);
            });
        }
    }

    /** 检测指定平台会话是否已建立 */
    public static boolean hasSession(String platform) {
        PlatformConfig cfg = PLATFORMS.get(platform);
        if (cfg == null) return false;
        String c = CookieManager.getInstance().getCookie(cfg.loginUrl);
        if (c == null) return false;
        for (String key : cfg.cookieKeys) {
            if (c.contains(key)) return true;
        }
        return false;
    }
}
