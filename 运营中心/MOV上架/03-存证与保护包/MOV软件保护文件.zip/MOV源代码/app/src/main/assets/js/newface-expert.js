/* ============================================================
   newface-expert.js — 专家模式新脸化纯逻辑（无 DOM，node 可单测）
   房间卡 badge/图标/交接上下文 从 newface.js 抽出真代码。
   浏览器: window.NewFaceExpert / Node: module.exports
   ============================================================ */
(function(root, factory) {
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    root.NewFaceExpert = api;
  }
})(typeof window !== 'undefined' ? window : this, function() {

  /* badge: 只用真实运行状态 (诚实, 不造假进度/记忆); 无运行态返回 null
     工单13 崩溃恢复状态如实: phase 只是 journal 回放的最后已知态, 进程强杀后停在
     「执行中」会永久误标「运行中」; 必须叠加进程内活跃 loop(agent_state)且 roomId
     匹配才算运行中, 否则标「已中断」(进程不在, 任务没完成也没在跑) */
  function roomBadge(r) {
    var runPhases = {'执行中':1,'讨论中':1,'收敛中':1,'待评审':1,'待确认':1};
    if (!r) return null;
    var activeLoop = false;
    try {
      if (typeof B !== 'undefined' && B.query) {
        var q = JSON.parse(B.query({q:'agent_state'}));
        if (q && q.ok && q.data && q.data.active) activeLoop = (q.data.roomId === r.id);
      }
    } catch(e) {}
    if (r._agentActive || activeLoop) return {label:'运行中', cls:'run'};
    if (runPhases[r.phase]) return {label:'已中断', cls:'idle'};
    return null;
  }

  /* 房间图标: 按房名关键词给 emoji (纯视觉, 不造假数据), 缺省 📁 */
  function roomIcon(name) {
    var n = String(name || '');
    if (/购物|买|采购|超市|比价/.test(n)) return '🛒';
    if (/剧|追|看|影视/.test(n)) return '🎬';
    if (/合同|文档|审查|整理|病历/.test(n)) return '📄';
    if (/app|应用|代码|游戏|开发|贪吃蛇/i.test(n)) return '📱';
    if (/设备|控制|电量|音量/.test(n)) return '📱';
    return '📁';
  }

  /* 交接上下文显示文本: 超长截断 + 省略号 (纯文本) */
  function handoffText(t, maxLen) {
    var s = String(t || '');
    var m = maxLen || 40;
    return s.length > m ? s.slice(0, m) + '…' : s;
  }

  /* ══ 第二幕: 运行/文件页纯逻辑 ══ */

  /* agent 阶段英文枚举 → 中文 (AgentLoop State.name(); 缺省原样) */
  function agentPhaseLabel(phaseEn) {
    var m = {'PLANNING':'规划','PLAN_GATE':'等待确认','EXECUTING':'执行中','PAUSED':'已暂停',
             'RECOVERY':'恢复中','DONE':'完成','FAILED':'失败','STOPPED':'已停止'};
    return m[phaseEn] || phaseEn || '';
  }

  function _pad2(n) { return n < 10 ? '0' + n : '' + n; }
  /* epoch ms → 当日键 'YYYY-MM-DD' (null/undefined/无效返回 '') */
  function dayKey(ts) {
    if (ts === undefined || ts === null || ts === '') return '';
    var d = new Date(ts);
    if (isNaN(d.getTime())) return '';
    return d.getFullYear() + '-' + _pad2(d.getMonth() + 1) + '-' + _pad2(d.getDate());
  }

  /* 聚合 journal 事件: entries=[{roomId,type,ts,summary}], 只取当日的 deliver/fail
     @return {done:[{roomId,ts,summary}], failed:[...]} 按 ts 降序 */
  function aggDaily(entries, todayKey) {
    var done = [], failed = [];
    (entries || []).forEach(function(e) {
      if (dayKey(e.ts) !== todayKey) return;
      var item = {roomId: e.roomId, ts: e.ts, summary: e.summary || ''};
      if (e.type === 'deliver') done.push(item);
      else if (e.type === 'fail') failed.push(item);
    });
    function desc(a, b) { return (b.ts || 0) - (a.ts || 0); }
    done.sort(desc); failed.sort(desc);
    return {done: done, failed: failed};
  }

  /* 文件大小人类可读: B <1KB / KB / MB */
  function fileSize(bytes) {
    var b = Number(bytes) || 0;
    if (b < 1024) return b + 'B';
    if (b < 1048576) return (b / 1024).toFixed(1) + 'KB';
    return (b / 1048576).toFixed(1) + 'MB';
  }

  /* ══ 派单№5: 设置迁移 + 两小任务 纯逻辑 ══ */

  /* TOKEN 数人类可读 (与 runtime.js fmtTok 同构): <1k 原样 / K / M */
  function tokFmt(n) {
    n = Number(n) || 0;
    if (n >= 1e6) return (n / 1e6).toFixed(2) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return String(Math.round(n));
  }

  /* 计划步文本是否复述 goal (任务卡回显去重): 归一化后相等/包含/字符级 ≥80% 视为复述 */
  function stepIsGoal(stepText, goal) {
    var s = String(stepText || '').toLowerCase().replace(/\s+/g, '');
    var g = String(goal || '').toLowerCase().replace(/\s+/g, '');
    if (!s || !g || g.length < 4) return false;
    if (s === g) return true;
    if (s.indexOf(g) >= 0 || g.indexOf(s) >= 0) return true;
    var common = 0;
    for (var i = 0; i < g.length; i++) if (s.indexOf(g.charAt(i)) >= 0) common++;
    return common / g.length >= 0.8;
  }

  /* ══ 派单№6: 思考面板展开态映射 ══ */

  /* idle/waiting → 折叠单行 bar; THINKING/PLANNING 等运行态 → 展开 (空/null → 折叠) */
  function thinkPanelMode(status) {
    var s = String(status || '').toUpperCase();
    return (s === 'IDLE' || s === 'WAITING' || s === '') ? 'collapsed' : 'expanded';
  }

  /* ══ 派单№7: 无感工作态 纯逻辑 ══ */

  /* 思考一行文案映射: running→「思考中…」; done→「已思考 N 秒 ›」(秒数整数化, 250.0→250); idle→无输出 */
  function thinkLine(state, secs) {
    var s = String(state || '').toUpperCase();
    if (s === 'RUNNING') return '思考中…';
    if (s === 'DONE') {
      var n = Math.round(Number(secs) || 0);
      return '已思考 ' + n + ' 秒 ›';
    }
    return '';
  }
  /* 技能卡状态文案: true→完成 / false→失败 / 未定→调用中 */
  function toolStatusText(ok) {
    if (ok === false) return '失败';
    if (ok === true) return '完成';
    return '调用中';
  }

  /* 派单№8: 答案提炼 — 长过程文本 → 结论段 (结论标记截取 / 最后非过程句), 只截原文不生成 */
  var _CONCL_MARKS = ['【结论】','结论：','结论:','总结：','总结:','答案：','答案:','最终结果','综上所述'];
  var _PROCESS_RE = /^(已|正在|执行|运行|调用|读取|创建|写入|下载|上传|完成|等待|使用了|命令|shell|>|\$)/;
  function extractConclusion(text) {
    var t = String(text || '').trim();
    if (!t) return '';
    var lines = t.split('\n').map(function(x){ return x.trim(); }).filter(Boolean);
    /* 1. 结论标记截取 (含单行: 「总结：xxx」) */
    for (var i = 0; i < lines.length; i++) {
      for (var m = 0; m < _CONCL_MARKS.length; m++) {
        var idx = lines[i].indexOf(_CONCL_MARKS[m]);
        if (idx >= 0) {
          var after = lines[i].substring(idx + _CONCL_MARKS[m].length).replace(/^[:：\s]+/, '').trim();
          if (after) return after;
          return lines.slice(i + 1).join(' ').trim() || t;
        }
      }
    }
    if (lines.length <= 1) return t;
    /* 2. 最后一段非过程句 */
    for (var j = lines.length - 1; j >= 0; j--) {
      if (!_PROCESS_RE.test(lines[j])) return lines[j];
    }
    return t;   /* 全为过程句 → 返回原文 (不造假提炼) */
  }

  return { roomBadge: roomBadge, roomIcon: roomIcon, handoffText: handoffText,
           agentPhaseLabel: agentPhaseLabel, dayKey: dayKey, aggDaily: aggDaily, fileSize: fileSize,
           tokFmt: tokFmt, stepIsGoal: stepIsGoal, thinkPanelMode: thinkPanelMode,
           thinkLine: thinkLine, toolStatusText: toolStatusText, extractConclusion: extractConclusion };
});
