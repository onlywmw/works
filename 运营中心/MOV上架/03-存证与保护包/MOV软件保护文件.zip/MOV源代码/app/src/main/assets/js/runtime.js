/* ============================================================
   runtime.js — 模型/TOKEN 工具函数
   派单№5: 老运行页已迁新脸设置抽屉并删除;
   本文件瘦身为 newface 抽屉复用的纯工具 (数据/桥/展示辅助)。
   老 modelSheet/modelOpsSheet/refreshRuntime/renderTokenStats 已随老运行页删除。
   ============================================================ */

/* TOKEN 人类可读: <1k 原样 / K / M */
function fmtTok(n){
  n=n||0;
  if(n>=1e6)return (n/1e6).toFixed(2)+'M';
  if(n>=1e3)return (n/1e3).toFixed(1)+'K';
  return String(Math.round(n));
}

/* 状态点: on=已配置可用 / off=未配置 / disabled=已停用 */
function modelStatusDot(m){
  if(!m.enabled)return '<span class="st off"></span>';
  var ready=(m.apiKey&&m.apiKey.length>0)||(m.provider==='ollama');
  return '<span class="st '+(ready?'on':'off')+'"></span>';
}
/* 跨文件函数兜底: store.js 版本错位(旧缓存)时降级不炸页 */
function _pvColor(p){return (typeof providerColor==='function')?providerColor(p):'#D97706';}
function _pvName(p){return (typeof providerDisplayName==='function')?providerDisplayName(p):p;}
/* P7: 厂商 logo URL 缓存 */
var _pvAvatars={};
function _pvAvatarUrl(p){
  if(_pvAvatars[p])return _pvAvatars[p];
  var presets=(typeof B!=='undefined'&&B.providerPresets)?B.providerPresets():[];
  for(var i=0;i<presets.length;i++){_pvAvatars[presets[i].key]=presets[i].avatarUrl||'';}
  return _pvAvatars[p]||'';
}
function modelStatusText(m){
  if(!m.enabled)return t('model.disabled');
  var ready=(m.apiKey&&m.apiKey.length>0)||(m.provider==='ollama');
  return ready?(m.model||_pvName(m.provider)):t('model.noKey');
}
