package com.hermes.android.workflow;

import org.json.JSONArray;

import java.util.Map;

/**
 * 动作执行接口 — 副作用由调用方注入（v1 ConnectWeb 集成前 = 记录日志/可断言 fake）。
 * 纯 JVM：引擎不直接执行浏览器动作，经此接口解耦。
 * F2：返回执行回执——WorkflowEngine 只在 SUCCESS（真实执行）时落 lastFireAt/配额。
 */
public interface ActionExecutor {

    /** 动作执行回执 */
    enum ActionReceipt {
        SUCCESS,    // 动作真实执行（有副作用发生）
        REJECTED,   // 被闸拒绝（审批驳回/支付拒）
        TIMEOUT,    // 执行超时（副作用不确定）
        NO_EFFECT   // 无动作/无副作用（空序列等）
    }

    /**
     * 执行动作序列，返回回执。
     *
     * @param actions Workflow.actions JSONArray（[{type, params...}]）
     * @param context 执行上下文（如 {workflowId, url, now}），供动作参数引用
     * @return 全动作中"最差"回执（任一失败 → 非 SUCCESS）；空序列 = NO_EFFECT
     */
    ActionReceipt execute(JSONArray actions, Map<String, Object> context);
}
