package com.hermes.android;

import android.annotation.SuppressLint;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

import java.io.File;

/**
 * 本地视频播放器（内嵌 VideoView，不跳三方播放器）。
 * Intent: path, title
 * 功能: MediaController / 横屏铺满+center-inside / 方向三态 / 锁定防误触
 */
public class LocalPlayerActivity extends androidx.appcompat.app.AppCompatActivity {

    private VideoView video;
    private FrameLayout holder;
    private FrameLayout bar;
    private MediaController controller;
    private FrameLayout lockOverlay;
    private TextView orientBtn, lockBtn;
    private boolean locked;
    private int orientState; // 0=system, 1=landscape, 2=portrait
    private int videoW, videoH;
    private Handler hideHandler = new Handler();

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String path = getIntent().getStringExtra("path");
        String title = getIntent().getStringExtra("title");
        if (path == null || path.isEmpty()) { finish(); return; }
        File file = new File(path);
        if (!file.exists()) { finish(); return; }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0e0f11"));

        // 顶栏（3s 后自动隐藏）
        bar = new FrameLayout(this);
        bar.setPadding(dp(12), statusBarHeight() + dp(4), dp(12), dp(10));
        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextColor(Color.WHITE);
        close.setTextSize(18);
        close.setPadding(dp(6), 0, dp(6), 0);
        close.setOnClickListener(v -> finish());
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(-2, -2);
        clp.gravity = Gravity.START | Gravity.CENTER_VERTICAL;
        bar.addView(close, clp);

        TextView titleView = new TextView(this);
        titleView.setText(title != null ? title : file.getName());
        titleView.setTextColor(Color.parseColor("#9a938a"));
        titleView.setTextSize(13);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(-2, -2);
        tlp.gravity = Gravity.CENTER;
        bar.addView(titleView, tlp);

        // 方向按钮（右侧）
        orientBtn = new TextView(this);
        orientBtn.setText("⟳");
        orientBtn.setTextColor(Color.WHITE);
        orientBtn.setTextSize(18);
        orientBtn.setPadding(dp(6), 0, dp(6), 0);
        orientBtn.setOnClickListener(v -> cycleOrientation());
        FrameLayout.LayoutParams olp = new FrameLayout.LayoutParams(-2, -2);
        olp.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        olp.setMarginEnd(dp(40));
        bar.addView(orientBtn, olp);

        // 锁定按钮
        lockBtn = new TextView(this);
        lockBtn.setText("🔓");
        lockBtn.setTextSize(16);
        lockBtn.setPadding(dp(6), 0, 0, 0);
        lockBtn.setOnClickListener(v -> toggleLock());
        FrameLayout.LayoutParams llp = new FrameLayout.LayoutParams(-2, -2);
        llp.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        bar.addView(lockBtn, llp);

        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        // 全屏 holder
        holder = new FrameLayout(this) {
            @Override
            protected void onSizeChanged(int w, int h, int oldw, int oldh) {
                super.onSizeChanged(w, h, oldw, oldh);
                if (videoW > 0 && videoH > 0) applyCenterInside(w, h);
            }
        };
        holder.setBackgroundColor(Color.parseColor("#0e0f11"));

        // VideoView
        video = new VideoView(this);
        video.setVideoURI(Uri.fromFile(file));
        video.setOnPreparedListener(mp -> {
            videoW = mp.getVideoWidth();
            videoH = mp.getVideoHeight();
            int pw = holder.getWidth(), ph = holder.getHeight();
            if (pw > 0 && ph > 0) applyCenterInside(pw, ph);
            mp.start();
        });
        video.setOnErrorListener((mp, what, extra) -> false);
        video.setOnCompletionListener(mp -> showUI());
        holder.addView(video, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));

        // 锁定遮罩（拦截触摸）
        lockOverlay = new FrameLayout(this);
        lockOverlay.setVisibility(View.GONE);
        lockOverlay.setClickable(true);
        lockOverlay.setOnTouchListener((v, e) -> true);
        holder.addView(lockOverlay, new FrameLayout.LayoutParams(-1, -1));

        root.addView(holder, new LinearLayout.LayoutParams(-1, 0, 1f));

        // MediaController（进度条+拖动+暂停，点画面呼出）
        controller = new MediaController(this);
        controller.setMediaPlayer(video);
        controller.setAnchorView(holder);
        video.setMediaController(controller);

        // 点画面切换 UI 可见性
        holder.setOnClickListener(v -> toggleUI());

        setContentView(root);
        hideUIDelayed();
    }

    private void applyCenterInside(int pw, int ph) {
        float sx = (float) pw / videoW;
        float sy = (float) ph / videoH;
        float s = Math.min(sx, sy);
        int w = (int) (videoW * s);
        int h = (int) (videoH * s);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, h);
        lp.gravity = Gravity.CENTER;
        video.setLayoutParams(lp);
    }

    private void cycleOrientation() {
        orientState = (orientState + 1) % 3;
        switch (orientState) {
            case 0: setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED); orientBtn.setText("⟳"); break;
            case 1: setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE); orientBtn.setText("▭"); break;
            case 2: setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); orientBtn.setText("▯"); break;
        }
    }

    private void toggleLock() {
        locked = !locked;
        lockBtn.setText(locked ? "🔒" : "🔓");
        lockOverlay.setVisibility(locked ? View.VISIBLE : View.GONE);
        if (locked) {
            int current = getRequestedOrientation();
            if (current == ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED) {
                int rot = getResources().getConfiguration().orientation;
                setRequestedOrientation(rot == Configuration.ORIENTATION_LANDSCAPE
                        ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                        : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
        } else {
            cycleOrientation(); cycleOrientation(); // reset to system 后保持
            orientState = 0;
            orientBtn.setText("⟳");
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        }
    }

    private void toggleUI() {
        if (locked) return;
        if (bar.getVisibility() == View.VISIBLE) {
            hideUI();
        } else {
            showUI();
        }
    }

    private void showUI() {
        bar.setVisibility(View.VISIBLE);
        controller.show(3000);
        hideUIDelayed();
    }

    private void hideUI() {
        bar.setVisibility(View.GONE);
        controller.hide();
        hideHandler.removeCallbacksAndMessages(null);
    }

    private void hideUIDelayed() {
        hideHandler.removeCallbacksAndMessages(null);
        hideHandler.postDelayed(() -> {
            bar.setVisibility(View.GONE);
            controller.hide();
        }, 3000);
    }

    @Override
    protected void onDestroy() {
        hideHandler.removeCallbacksAndMessages(null);
        if (video != null) { video.stopPlayback(); }
        super.onDestroy();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }
}
