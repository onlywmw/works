package com.hermes.android.ai;

/**
 * StreamWatchdog — 流式停滞看门狗与重试策略 (纯逻辑, 可单测)。
 *
 * 合同 2.2/2.3:
 * - 阈值: STREAM 180s / REASONING 300s / LOCAL 600s / NON_STREAM 90s
 * - 连续 5 次停滞熔断
 * - 快退避 300ms→5s 封顶 ×3 (+50% jitter); 429 尊重 Retry-After(≤600s), 无头 30→60→120s ×3
 * - readTimeout = 停滞阈值 + 30s (看门狗永远先于 socket 开火, 禁反转)
 */
public class StreamWatchdog {

    public enum Mode { STREAM, REASONING, LOCAL, NON_STREAM }

    public enum ErrorClass { PROVIDER_API, PROVIDER_AUTH, PROVIDER_CONNECTION, RATE_LIMIT, MODEL_CONFIG, RUNTIME }

    public static long stallThresholdMs(Mode m) {
        switch (m) {
            case REASONING: return 300_000;
            case LOCAL: return 600_000;
            case NON_STREAM: return 90_000;
            default: return 180_000;
        }
    }

    /** socket readTimeout = 阈值 + 30s 余量 (红线: 看门狗先开火) */
    public static int readTimeoutMs(Mode m) {
        return (int) (stallThresholdMs(m) + 30_000);
    }

    public static final int MAX_STALLS = 5;
    public static final int MAX_FAST_RETRIES = 3;
    public static final int MAX_RATE_RETRIES = 3;
    private static final long RETRY_AFTER_CAP_MS = 600_000;

    private final Mode mode;
    private long lastChunkMs = -1;
    private int stallCount = 0;

    public StreamWatchdog(Mode mode) {
        this.mode = mode;
        reset();
    }

    public void reset() {
        lastChunkMs = System.currentTimeMillis();
    }

    /** 真实内容 chunk 才重置 (ping/注释不算活性, 红线) */
    public void recordChunk() {
        lastChunkMs = System.currentTimeMillis();
    }

    public void recordChunk(long nowMs) {
        lastChunkMs = nowMs;
    }

    public boolean isStalled() {
        return isStalled(System.currentTimeMillis());
    }

    public boolean isStalled(long nowMs) {
        return nowMs - lastChunkMs > stallThresholdMs(mode);
    }

    /** 停滞确认 (call.cancel 后调用): 计数 +1 */
    public int noteStall() {
        stallCount++;
        return stallCount;
    }

    public int getStallCount() { return stallCount; }

    /** 连续 5 次停滞 → 熔断 (防烧钱) */
    public boolean isCircuitBroken() {
        return stallCount >= MAX_STALLS;
    }

    // ==================== 退避策略 (静态纯函数) ====================

    /**
     * 快退避 (网络抖动/5xx 无 Retry-After): 300→600→1200→2400→5000ms 封顶, +50% jitter。
     * attempt 从 0 起; 超出 MAX_FAST_RETRIES 返回 -1 (耗尽)。
     */
    public static long fastBackoffMs(int attempt, double jitterFactor) {
        if (attempt >= MAX_FAST_RETRIES) return -1;
        long base = Math.min(300L << attempt, 5000L);
        double jitter = 1.0 + jitterFactor * 0.5;
        return (long) (base * jitter);
    }

    /**
     * 限流退避: 尊重 Retry-After(秒, 上限 600s); 无头 30→60→120s。
     * attempt 从 0 起; 超出 MAX_RATE_RETRIES 返回 -1。
     */
    public static long rateLimitBackoffMs(int attempt, int retryAfterSec) {
        if (attempt >= MAX_RATE_RETRIES) return -1;
        if (retryAfterSec > 0) {
            return Math.min(retryAfterSec * 1000L, RETRY_AFTER_CAP_MS);
        }
        return Math.min(30_000L << attempt, 120_000L);
    }

    // ==================== 错误分类 (静态纯函数) ====================

    /** 按 HTTP 码分类: 401/403→AUTH, 429→RATE_LIMIT, 4xx 参数→MODEL_CONFIG, 5xx→PROVIDER_API */
    public static ErrorClass classifyHttp(int code) {
        if (code == 401 || code == 403) return ErrorClass.PROVIDER_AUTH;
        if (code == 429) return ErrorClass.RATE_LIMIT;
        if (code == 400 || code == 404 || code == 422) return ErrorClass.MODEL_CONFIG;
        if (code >= 500) return ErrorClass.PROVIDER_API;
        return ErrorClass.RUNTIME;
    }

    /** 按异常分类: 连接类→CONNECTION, 其余→RUNTIME */
    public static ErrorClass classifyError(Throwable t) {
        if (t == null) return ErrorClass.RUNTIME;
        String n = t.getClass().getSimpleName().toLowerCase();
        String m = t.getMessage() != null ? t.getMessage().toLowerCase() : "";
        if (n.contains("socket") || n.contains("connect") || n.contains("timeout")
                || m.contains("connection") || m.contains("timed out") || m.contains("socket")) {
            return ErrorClass.PROVIDER_CONNECTION;
        }
        return ErrorClass.RUNTIME;
    }

    /** 网络类错误 (CONNECTION/RATE_LIMIT) → 可暂停续跑; 其余直达 fail */
    public static boolean isRecoverable(ErrorClass c) {
        return c == ErrorClass.PROVIDER_CONNECTION || c == ErrorClass.RATE_LIMIT;
    }
}
