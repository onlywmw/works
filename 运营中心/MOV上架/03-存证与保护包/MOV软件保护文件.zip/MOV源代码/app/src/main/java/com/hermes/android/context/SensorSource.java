package com.hermes.android.context;

/**
 * 设备传感器抽象接口 — 隔离 Android Context 依赖，纯函数可测。
 *
 * <p>生产实现：{@link SensorSourceImpl}（需要 android.content.Context）。
 * 单测注入：fake 实现，预设返回值，不准碰真 Context 服务。
 */
public interface SensorSource {
    /** 当前 WiFi SSID（strip 引号），未连/无权限返回 null */
    String getWifiSsid();
    /** 电池电量 0..100，未知返回 null */
    Integer getBatteryLevel();
    /** 是否正在充电（含 BATTERY_STATUS_FULL） */
    boolean isCharging();
    /** 屏幕是否交互态 */
    boolean isScreenOn();
    /**
     * 前台应用包名。
     * 生产实现用 UsageStatsManager 尝试（需 PACKAGE_USAGE_STATS），
     * 无权限返回 null——不为此前置申请无障碍。
     */
    String getForegroundApp();
}
