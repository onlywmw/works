package com.hermes.android.scene;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * 追剧记忆库（任务O，统一数据层，100%端侧）。
 * 收纳书架/历史/屏蔽/signals → filesDir/drama_memory.json。
 */
public class DramaMemory {

    private static final String TAG = "DramaMemory";
    private final File file;

    public DramaMemory(File filesDir) {
        this.file = new File(filesDir, "drama_memory.json");
    }

    private JSONObject read() {
        if (!file.exists()) return emptyRoot();
        try (BufferedReader r = new BufferedReader(new FileReader(file))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            return new JSONObject(sb.toString());
        } catch (Exception e) {
            return emptyRoot();
        }
    }

    private void write(JSONObject root) {
        try {
            file.getParentFile().mkdirs();
            try (OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(file), "UTF-8")) {
                w.write(root.toString());
            }
        } catch (Exception e) {
            Log.w(TAG, "write failed: " + e.getMessage());
        }
    }

    private JSONObject emptyRoot() {
        JSONObject o = new JSONObject();
        try {
            o.put("favs", new JSONArray());
            o.put("history", new JSONObject());
            o.put("blocks", new JSONArray());
            o.put("signals", new JSONObject());
        } catch (Exception ignored) {}
        return o;
    }

    // ══════ 书架 ══════

    public void addFav(String title, String url, String poster) {
        JSONObject root = read();
        JSONArray favs = root.optJSONArray("favs");
        if (favs == null) favs = new JSONArray();
        // 去重
        for (int i = 0; i < favs.length(); i++) {
            JSONObject f = favs.optJSONObject(i);
            if (f != null && title.equals(f.optString("title"))) return;
        }
        JSONObject item = new JSONObject();
        try {
            item.put("title", title);
            item.put("url", url != null ? url : "");
            item.put("poster", poster != null ? poster : "");
            item.put("ts", System.currentTimeMillis());
            favs.put(item);
            root.put("favs", favs);
            write(root);
        } catch (Exception ignored) {}
    }

    public void removeFav(String title) {
        JSONObject root = read();
        JSONArray favs = root.optJSONArray("favs");
        JSONArray filtered = new JSONArray();
        for (int i = 0; i < favs.length(); i++) {
            JSONObject f = favs.optJSONObject(i);
            if (f != null && !title.equals(f.optString("title"))) filtered.put(f);
        }
        try { root.put("favs", filtered); write(root); } catch (Exception ignored) {}
    }

    public JSONArray getFavs() {
        return read().optJSONArray("favs");
    }

    // ══════ 屏蔽 ══════

    public void addBlock(String title, String source) {
        JSONObject root = read();
        JSONArray blocks = root.optJSONArray("blocks");
        if (blocks == null) blocks = new JSONArray();
        for (int i = 0; i < blocks.length(); i++) {
            JSONObject b = blocks.optJSONObject(i);
            if (b != null && title.equals(b.optString("title")) && source.equals(b.optString("source"))) return;
        }
        JSONObject item = new JSONObject();
        try {
            item.put("title", title);
            item.put("source", source != null ? source : "");
            item.put("ts", System.currentTimeMillis());
            blocks.put(item);
            root.put("blocks", blocks);
            write(root);
        } catch (Exception ignored) {}
    }

    public void removeBlock(String title) {
        JSONObject root = read();
        JSONArray blocks = root.optJSONArray("blocks");
        JSONArray filtered = new JSONArray();
        for (int i = 0; i < blocks.length(); i++) {
            JSONObject b = blocks.optJSONObject(i);
            if (b != null && !title.equals(b.optString("title"))) filtered.put(b);
        }
        try { root.put("blocks", filtered); write(root); } catch (Exception ignored) {}
    }

    public JSONArray getBlocks() {
        return read().optJSONArray("blocks");
    }

    /** 清空全部追剧记忆（favs/blocks/signals）— 设置页隐私区块用 */
    public void clearAll() {
        try { write(new JSONObject()); } catch (Exception ignored) {}
    }

    /** 检查是否被屏蔽（标题+源粒度） */
    public boolean isBlocked(String title, String source) {
        JSONArray blocks = getBlocks();
        for (int i = 0; i < blocks.length(); i++) {
            JSONObject b = blocks.optJSONObject(i);
            if (b != null && title.equals(b.optString("title"))
                    && (source == null || source.equals(b.optString("source")))) return true;
        }
        return false;
    }

    // ══════ signals（隐式源偏好） ══════

    public void recordSignal(String source) {
        if (source == null) return;
        JSONObject root = read();
        JSONObject signals = root.optJSONObject("signals");
        if (signals == null) signals = new JSONObject();
        JSONObject s = signals.optJSONObject(source);
        if (s == null) s = new JSONObject();
        try {
            s.put("click", s.optInt("click", 0) + 1);
            signals.put(source, s);
            root.put("signals", signals);
            write(root);
        } catch (Exception ignored) {}
    }

    public JSONObject getSignals() {
        return read().optJSONObject("signals");
    }
}
