package com.hermes.android.bridge;

import android.webkit.JavascriptInterface;

import com.hermes.android.HermesActivity;
import com.hermes.android.a2a.A2aClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;

/**
 * A2A Bridge — 暴露 A2aClient 给 JS 商家页面。
 * 全部消息落 journal (audit:true, type 前缀 a2a_)。
 */
public class BridgeA2a extends BaseBridge {
    private final A2aClient client;
    private final File dataDir; // filesDir/a2a/

    public BridgeA2a(HermesActivity activity) {
        super(activity);
        this.client = new A2aClient(activity);
        this.dataDir = new File(activity.getFilesDir(), "a2a");
        this.dataDir.mkdirs();
    }

    @JavascriptInterface public String getDeviceId() { return client.getDeviceId(); }
    @JavascriptInterface public boolean isRegistered() { return client.isRegistered(); }

    /* ── Relay 服务器地址（设置页 A2A 区块编辑） ── */
    @JavascriptInterface public String getRelayUrl() { return client.baseUrl(); }
    @JavascriptInterface public void setRelayUrl(String url) { client.setBaseUrl(url); }

    @JavascriptInterface
    public void a2aOpenMerchant() {
        activity.loadUrlPublic("file:///android_asset/a2a/merchant.html");
    }

    @JavascriptInterface
    public void a2aRegister(String deviceId, String name, String cbId) {
        a2aRegister(deviceId, name, null, null, cbId);   // 缺省兼容：role=buyer
    }

    /** 职业注册表注册：role（buyer|pro）+ professions（工种数组 JSON），缺省兼容 */
    @JavascriptInterface
    public void a2aRegister(String deviceId, String name, String role, String professionsJson, String cbId) {
        org.json.JSONArray professions = null;
        if (professionsJson != null && !professionsJson.isEmpty()) {
            try { professions = new org.json.JSONArray(professionsJson); } catch (Exception ignored) {}
        }
        client.register(deviceId, name, role, professions, new A2aClient.Callback<String>() {
            @Override public void onSuccess(String token) {
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":true,\"token\":\"" + token + "\"})");
            }
            @Override public void onFailure(java.io.IOException e) {
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":\"" + esc(e.getMessage()) + "\"})");
            }
        });
    }

    /** 附近职业人发现（relay query_pro）：按 craft + radiusKm + online，cbId 异步 */
    @JavascriptInterface
    public void a2aQueryPro(String craft, int radiusKm, boolean online, String cbId) {
        client.queryPro(craft, radiusKm, online, new A2aClient.Callback<java.util.List<A2aClient.Peer>>() {
            @Override public void onSuccess(java.util.List<A2aClient.Peer> peers) {
                org.json.JSONArray arr = new org.json.JSONArray();
                try {
                    for (A2aClient.Peer p : peers) {
                        arr.put(new org.json.JSONObject().put("deviceId", p.deviceId).put("name", p.name));
                    }
                } catch (org.json.JSONException e) {
                    evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":\"serialize\"})");
                    return;
                }
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":true,\"devices\":" + arr + "})");
            }
            @Override public void onFailure(java.io.IOException e) {
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":\"" + esc(e.getMessage()) + "\"})");
            }
        });
    }

    @JavascriptInterface
    public void a2aPairRequest(String cbId) {
        client.pairRequest(new A2aClient.Callback<String>() {
            @Override public void onSuccess(String code) {
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":true,\"code\":\"" + code + "\"})");
            }
            @Override public void onFailure(java.io.IOException e) {
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":\"" + esc(e.getMessage()) + "\"})");
            }
        });
    }

    @JavascriptInterface
    public void a2aPairAccept(String code, String cbId) {
        client.pairAccept(code, new A2aClient.Callback<A2aClient.Peer>() {
            @Override public void onSuccess(A2aClient.Peer p) {
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":true,\"peer\":{\"deviceId\":\""
                        + esc(p.deviceId) + "\",\"name\":\"" + esc(p.name) + "\"}})");
            }
            @Override public void onFailure(java.io.IOException e) {
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":\"" + esc(e.getMessage()) + "\"})");
            }
        });
    }

    @JavascriptInterface
    public void a2aPeers(String cbId) {
        client.peers(new A2aClient.Callback<List<A2aClient.Peer>>() {
            @Override public void onSuccess(List<A2aClient.Peer> peers) {
                JSONArray arr = new JSONArray();
                for (A2aClient.Peer p : peers) {
                    JSONObject o = new JSONObject();
                    try { o.put("deviceId", p.deviceId); o.put("name", p.name); } catch (Exception ignored) {}
                    arr.put(o);
                }
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":true,\"peers\":" + arr.toString() + "})");
            }
            @Override public void onFailure(java.io.IOException e) {
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":\"" + esc(e.getMessage()) + "\"})");
            }
        });
    }

    @JavascriptInterface
    public void a2aSend(String toId, String type, String payloadJson, String cbId) {
        try {
            JSONObject payload = new JSONObject(payloadJson);
            client.send(toId, type, payload, new A2aClient.Callback<Long>() {
                @Override public void onSuccess(Long msgId) {
                    auditJournal("a2a_send", new JSONObject(), toId, type, payload);
                    evalJs("window._hermesCb('" + cbId + "',{\"ok\":true,\"msgId\":" + msgId + "})");
                }
                @Override public void onFailure(java.io.IOException e) {
                    evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":\"" + esc(e.getMessage()) + "\"})");
                }
            });
        } catch (Exception e) {
            evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":\"" + esc(e.getMessage()) + "\"})");
        }
    }

    @JavascriptInterface
    public void a2aStartPolling() {
        client.startPolling(msgs -> {
            for (A2aClient.Msg m : msgs) {
                auditJournal("a2a_recv", m.payload, m.fromId, m.type, m.payload);
                JSONObject ev = new JSONObject();
                try {
                    ev.put("type", "a2a_msg");
                    ev.put("fromId", m.fromId);
                    ev.put("msgType", m.type);
                    ev.put("payload", m.payload != null ? m.payload : new JSONObject());
                } catch (Exception ignored) {}
                activity.evalJsPublic("window._a2aMsg && _a2aMsg(" + ev.toString() + ")");
            }
        });
    }

    @JavascriptInterface
    public void a2aStopPolling() {
        client.stopPolling();
    }

    /* ── 商家数据: 菜单 JSON ── */
    @JavascriptInterface
    public String a2aLoadMenu() {
        try {
            File f = new File(dataDir, "menu.json");
            if (!f.exists()) return "[]";
            byte[] b = Files.readAllBytes(f.toPath());
            return new String(b, StandardCharsets.UTF_8);
        } catch (Exception e) { return "[]"; }
    }

    @JavascriptInterface
    public String a2aSaveMenu(String menuJson) {
        try {
            File f = new File(dataDir, "menu.json");
            try (FileWriter w = new FileWriter(f)) { w.write(menuJson); }
            return "{\"ok\":true}";
        } catch (Exception e) { return "{\"ok\":false,\"error\":\"" + esc(e.getMessage()) + "\"}"; }
    }

    /* ── journal 审计 ── */
    private void auditJournal(String type, JSONObject payload, String peerId, String msgType, JSONObject msgPayload) {
        try {
            JSONObject event = new JSONObject();
            event.put("type", type);
            event.put("actor", "a2a");
            event.put("taskId", JSONObject.NULL);
            JSONObject p = new JSONObject();
            p.put("peerId", peerId != null ? peerId : "");
            p.put("msgType", msgType != null ? msgType : "");
            p.put("audit", true);
            if (msgPayload != null) p.put("msgPayload", msgPayload);
            event.put("payload", p);
            // 写 journal (走默认房间 'a2a')
            com.hermes.android.agent.Journal j = new com.hermes.android.agent.Journal(
                    activity.getStorageManager().getRoomsDir());
            j.append("a2a", event);
        } catch (Exception e) {
            android.util.Log.w("BridgeA2a", "audit journal: " + e.getMessage());
        }
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }
}
