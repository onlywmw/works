package com.hermes.android.context;

import org.json.JSONObject;

import java.util.Objects;

/**
 * 设备情境快照 — 瞬时状态的不可变值对象。
 *
 * <p>由 {@link SensorSource} 采集，经 {@link ContextProvider#snapshot()}
 * 返回。所有字段均为只读；修改通过 {@link #copy()} builder 创建新实例。
 *
 * <p>隐私铁律：本对象及其 JSON 序列化 100% 端侧，永不出设备。
 */
public final class ContextSnapshot {

    /** WiFi SSID（已 strip 引号）；无权限/未连接/null 表示不可用 */
    public final String wifiSsid;
    /** 电量 0..100；null 表示未知（BATTERY_CHANGED 广播尚未到达） */
    public final Integer batteryLevel;
    /** 是否正在充电（含 BATTERY_STATUS_FULL） */
    public final boolean isCharging;
    /** 屏幕是否交互态（PowerManager#isInteractive） */
    public final boolean screenOn;
    /** 前台应用包名；null 表示无法获取（UsageStats 权限未授） */
    public final String foregroundApp;
    /** 快照采集时间戳 ms */
    public final long capturedAtMs;

    private ContextSnapshot(Builder b) {
        this.wifiSsid = b.wifiSsid;
        this.batteryLevel = b.batteryLevel;
        this.isCharging = b.isCharging;
        this.screenOn = b.screenOn;
        this.foregroundApp = b.foregroundApp;
        this.capturedAtMs = b.capturedAtMs;
    }

    /** 从当前时间创建 builder */
    public static Builder copy() {
        return new Builder();
    }

    /** 以本快照为模板创建 builder（保留所有字段，可选择性覆盖） */
    public Builder derive() {
        return new Builder()
                .wifiSsid(this.wifiSsid)
                .batteryLevel(this.batteryLevel)
                .isCharging(this.isCharging)
                .screenOn(this.screenOn)
                .foregroundApp(this.foregroundApp);
    }

    /** 序列化为 JSON。wifiSsid 只在非 null 时写入（隐私最小化）。 */
    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("captured_at_ms", capturedAtMs);
            o.put("battery_level", batteryLevel != null ? batteryLevel : JSONObject.NULL);
            o.put("is_charging", isCharging);
            o.put("screen_on", screenOn);
            if (wifiSsid != null) o.put("wifi_ssid", wifiSsid);
            if (foregroundApp != null) o.put("foreground_app", foregroundApp);
        } catch (org.json.JSONException ignored) {
            // keys are literal strings — cannot throw
        }
        return o;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ContextSnapshot)) return false;
        ContextSnapshot that = (ContextSnapshot) o;
        return isCharging == that.isCharging
                && screenOn == that.screenOn
                && Objects.equals(wifiSsid, that.wifiSsid)
                && Objects.equals(batteryLevel, that.batteryLevel)
                && Objects.equals(foregroundApp, that.foregroundApp);
    }

    @Override
    public int hashCode() {
        return Objects.hash(wifiSsid, batteryLevel, isCharging, screenOn, foregroundApp);
    }

    @Override
    public String toString() {
        return "ContextSnapshot{wifi=" + wifiSsid
                + ", battery=" + batteryLevel + "%"
                + ", charging=" + isCharging
                + ", screen=" + (screenOn ? "on" : "off")
                + ", fg=" + foregroundApp + "}";
    }

    // -- builder ----------------------------------------------------------------

    public static final class Builder {
        String wifiSsid;
        Integer batteryLevel;
        boolean isCharging;
        boolean screenOn;
        String foregroundApp;
        long capturedAtMs = System.currentTimeMillis();

        public Builder wifiSsid(String v) { this.wifiSsid = v; return this; }
        public Builder batteryLevel(Integer v) { this.batteryLevel = v; return this; }
        public Builder isCharging(boolean v) { this.isCharging = v; return this; }
        public Builder screenOn(boolean v) { this.screenOn = v; return this; }
        public Builder foregroundApp(String v) { this.foregroundApp = v; return this; }
        public Builder capturedAtMs(long v) { this.capturedAtMs = v; return this; }

        public ContextSnapshot build() {
            return new ContextSnapshot(this);
        }
    }
}
