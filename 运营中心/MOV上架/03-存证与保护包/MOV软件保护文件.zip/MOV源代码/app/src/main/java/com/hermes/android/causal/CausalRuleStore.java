package com.hermes.android.causal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 因果规则状态：从 journal _causal_rule 事件重建 + 内存活性集。
 *
 * 事件流即规则版本历史（同一 ruleId 后写覆盖前写）；op=remove 为墓碑。
 * 纯 Java，零 android 依赖。
 */
public class CausalRuleStore {

    private final Map<String, CausalRule> rules = new LinkedHashMap<>();

    /** 从 journal 事件重建（seq 升序应用）。 */
    public void load(List<JSONObject> ruleEvents) {
        rules.clear();
        for (JSONObject ev : ruleEvents) {
            JSONObject p = ev.optJSONObject("payload");
            if (p == null) continue;
            String ruleId = p.optString("ruleId", "");
            if (ruleId.isEmpty()) continue;
            if ("remove".equals(p.optString("op", ""))) {
                rules.remove(ruleId);
            } else {
                CausalRule r = CausalRule.fromJSON(p);
                r.lastFiredTs = p.optLong("lastFiredTs", ev.optLong("ts", 0));
                rules.put(ruleId, r);
            }
        }
    }

    public CausalRule get(String ruleId) {
        return ruleId == null ? null : rules.get(ruleId);
    }

    /** 活性规则集：enabled 且未硬到期。 */
    public List<CausalRule> active(long nowMs) {
        List<CausalRule> out = new ArrayList<>();
        for (CausalRule r : rules.values()) {
            if (r.enabled && !r.expired(nowMs)) out.add(r);
        }
        return out;
    }

    public void upsert(CausalRule r) {
        // 首次注册/无触发历史 → 以创建时间为衰减基数（freshness 从此刻开始衰减；touch 命中则刷新）
        if (r.lastFiredTs <= 0) r.lastFiredTs = System.currentTimeMillis();
        rules.put(r.ruleId, r);
    }

    public void remove(String ruleId) {
        rules.remove(ruleId);
    }

    /** 命中复位触发时间（供衰减判断）。 */
    public void touch(String ruleId, long nowMs) {
        CausalRule r = rules.get(ruleId);
        if (r != null) r.lastFiredTs = nowMs;
    }

    /** 过期规则移除（sweep 用），返回移除的 ruleId 列表。 */
    public List<String> removeExpired(long nowMs) {
        List<String> out = new ArrayList<>();
        java.util.Iterator<Map.Entry<String, CausalRule>> it = rules.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, CausalRule> e = it.next();
            if (e.getValue().expired(nowMs)) {
                out.add(e.getKey());
                it.remove();
            }
        }
        return out;
    }

    public int size() { return rules.size(); }
}
