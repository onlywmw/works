package com.hermes.android.workflow;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.view.Display;
import android.hardware.display.DisplayManager;


/**
 * 设备状态拉取式读取器——snapshot() 时刻现查系统，与 receiver 触发家族解耦。
 * 电池/充电：registerReceiver(null, ACTION_BATTERY_CHANGED) 粘性广播（免注册官方读法，真机实测正确）；
 * 屏幕：DisplayManager 遍历显示屏 getState()!=STATE_OFF（三次打回：PowerManager.isInteractive()
 *      在这台 MIUI 屏灭仍返回 true，AOSP 语义是 awake 不是亮屏）；
 * 网络：ConnectivityManager.getActiveNetwork()+capabilities（真机实测正确）。
 * foregroundApp 无数据源 → 保持缺省 FAIL（纪律不变）。
 */
public class DeviceStateReader implements DeviceStateProvider {

    private final Context ctx;

    public DeviceStateReader(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    @Override
    public DeviceState read() {
        Intent batt = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        return new DeviceState(batteryLevel(batt), charging(batt), screenOn(), networkType());
    }

    private static int batteryLevel(Intent batt) {
        if (batt == null) return -1;
        int level = batt.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batt.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        return level >= 0 ? level * 100 / scale : -1;
    }

    private static boolean charging(Intent batt) {
        if (batt == null) return false;
        int st = batt.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        if (st != BatteryManager.BATTERY_STATUS_CHARGING
                && st != BatteryManager.BATTERY_STATUS_FULL) return false;
        // 巡检#21 随行修正：本机伪拔电时 status 仍残留 CHARGING（dumpsys 全字段实证），
        // 加 EXTRA_PLUGGED != 0 合取——只有真插电才判充电。
        return batt.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
    }

    private boolean screenOn() {
        // 三次打回实证：isInteractive() 在这台 MIUI 屏灭仍 true（mWakefulness=Asleep 时 so=true）。
        // 改 DisplayManager 遍历显示屏：任一 getState()!=STATE_OFF 即亮屏（灭屏 OFF/亮屏 ON 实测与 wakefulness 一致）。
        DisplayManager dm = (DisplayManager) ctx.getSystemService(Context.DISPLAY_SERVICE);
        if (dm == null) return false;
        for (Display d : dm.getDisplays()) {
            if (d.getState() != Display.STATE_OFF) return true;
        }
        return false;
    }

    private String networkType() {
        ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return null;
        Network n = cm.getActiveNetwork();
        if (n == null) return null;
        NetworkCapabilities caps = cm.getNetworkCapabilities(n);
        if (caps == null) return null;
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "wifi";
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "mobile";
        return null;
    }
}
