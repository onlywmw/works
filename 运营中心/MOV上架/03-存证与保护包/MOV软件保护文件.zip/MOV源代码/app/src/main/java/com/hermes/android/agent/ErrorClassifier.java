package com.hermes.android.agent;

import android.util.Log;

import java.io.FileNotFoundException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

/**
 * 错误分类器 — 3 类错误，替代 catch(Exception ignored)。
 *
 * USER_ERROR    = 用户自己能修的（文件不存在、参数错误）
 * EXTERNAL_ERROR = 外部环境导致、可重试的（网络超时、AI 异常）
 * INTERNAL_ERROR = 代码缺陷或系统崩溃（NPE、OOM）
 *
 * 原则：
 * - 硬错误（USER/INTERNAL）不喂 LLM —— 直接返回中文提示
 * - 软错误（EXTERNAL）可喂 LLM 做诊断和重试
 */
public final class ErrorClassifier {

    private static final String TAG = "ErrorClassifier";

    public enum Category {
        /** 用户能修复的错误：文件不存在、参数格式不对、权限不足 */
        USER_ERROR,
        /** 外部环境导致的、可重试：网络超时、DNS 失败、AI 返回异常 */
        EXTERNAL_ERROR,
        /** 代码缺陷或系统崩溃：NPE、OOM、IllegalState */
        INTERNAL_ERROR
    }

    private ErrorClassifier() {}

    /** 分类 + 生成用户可读的中文消息 */
    public static Result classify(Throwable e) {
        if (e == null) return new Result(Category.INTERNAL_ERROR, "未知错误");

        // ── USER_ERROR ──
        if (e instanceof SecurityException) {
            return new Result(Category.USER_ERROR, "权限不足：" + e.getMessage());
        }
        if (e instanceof FileNotFoundException) {
            return new Result(Category.USER_ERROR, "文件不存在：" + e.getMessage());
        }
        if (e instanceof IllegalArgumentException) {
            return new Result(Category.USER_ERROR, "参数无效：" + e.getMessage());
        }

        // ── EXTERNAL_ERROR ──
        if (e instanceof SocketTimeoutException) {
            return new Result(Category.EXTERNAL_ERROR, "操作超时，请检查网络后重试");
        }
        if (e instanceof UnknownHostException) {
            return new Result(Category.EXTERNAL_ERROR, "网络不可用，无法连接服务器");
        }
        if (e instanceof java.net.ConnectException) {
            return new Result(Category.EXTERNAL_ERROR, "网络连接失败，请检查网络");
        }
        if (e instanceof java.io.IOException) {
            // IO 异常通常是外部原因（磁盘满、网络断）
            return new Result(Category.EXTERNAL_ERROR, "IO 异常：" + e.getMessage());
        }

        // ── INTERNAL_ERROR ──
        if (e instanceof OutOfMemoryError) {
            return new Result(Category.INTERNAL_ERROR, "内存不足，请关闭其他应用后重试");
        }
        if (e instanceof NullPointerException) {
            Log.e(TAG, "内部 NPE", e);
            return new Result(Category.INTERNAL_ERROR, "内部错误，请重试");
        }
        if (e instanceof IllegalStateException) {
            Log.e(TAG, "非法状态", e);
            return new Result(Category.INTERNAL_ERROR, "内部状态错误：" + e.getMessage());
        }

        // 兜底
        Log.w(TAG, "未分类异常", e);
        return new Result(Category.INTERNAL_ERROR,
                "未知错误：" + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName()));
    }

    // ================================================================

    public static class Result {
        public final Category category;
        public final String userMessage;

        Result(Category category, String userMessage) {
            this.category = category;
            this.userMessage = userMessage;
        }

        /** 是否可以喂给 LLM 做诊断和重试 */
        public boolean canFeedToLLM() {
            return category == Category.EXTERNAL_ERROR;
        }

        /** 是否可以直接告诉用户而不需要 LLM 介入 */
        public boolean isHardError() {
            return category == Category.USER_ERROR || category == Category.INTERNAL_ERROR;
        }
    }
}
