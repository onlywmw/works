package com.hermes.android.causal;

import com.hermes.android.agent.Journal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 本地因果记忆编译器 — 门面（蓝图 §1-§5 的全部机制协调者）。
 *
 * 每房间维护 {CausalIndex 哈希索引 + CausalRuleStore 规则活性集 + CausalRuleEngine 匹配}，
 * 长在 journal（新事件类型 _causal_event/_causal_rule/_causal_rule_block/_causal_forget/_causal_link），
 * 铁律③不另起平行库。哈希派生缓存 causal.index.json 可丢弃重建。
 *
 * 纯 Java，零 android 依赖；唯一磁盘依赖是 {@link Journal}（本身纯 Java 可测）。
 */
public class CausalEngine {

    private final Journal journal;
    private final File roomsDir;
    private final Map<String, RoomState> rooms = new ConcurrentHashMap<>();
    private final CausalChain chain = new CausalChain();

    public CausalEngine(File roomsDir) {
        this.roomsDir = roomsDir;
        this.journal = new Journal(roomsDir);
    }

    /** 暴露 journal（测试/注入器用）。 */
    public Journal journal() { return journal; }

    // ── 每房间状态 ──

    private static class RoomState {
        CausalIndex index = new CausalIndex();
        CausalRuleStore ruleStore = new CausalRuleStore();
        CausalRuleEngine ruleEngine = new CausalRuleEngine();
    }

    private synchronized RoomState stateFor(String roomId) {
        RoomState st = rooms.get(roomId);
        if (st == null) {
            st = new RoomState();
            rebuild(roomId, st);
            rooms.put(roomId, st);
        }
        return st;
    }

    /** 从 journal 全量重建房间因果状态（启动/首次用；索引可再生）。 */
    public synchronized void rebuild(String roomId) {
        rebuild(roomId, stateForInner(roomId));
    }

    private RoomState stateForInner(String roomId) {
        RoomState st = rooms.get(roomId);
        if (st == null) {
            st = new RoomState();
            rooms.put(roomId, st);
        }
        return st;
    }

    private void rebuild(String roomId, RoomState st) {
        st.index = new CausalIndex();
        st.index.setRoom(roomId);
        JSONArray events = journal.eventsOfType(roomId, Journal.TYPE_CAUSAL_EVENT);
        for (int i = 0; i < events.length(); i++) {
            JSONObject ev = events.optJSONObject(i);
            if (ev == null) continue;
            CausalEvent ce = CausalEvent.fromPayload(ev.optJSONObject("payload"));
            st.index.applyEvent(ce, ev.optLong("ts", 0));
        }
        // 关联强度（delta 累加，恢复）
        JSONArray links = journal.eventsOfType(roomId, Journal.TYPE_CAUSAL_LINK);
        for (int i = 0; i < links.length(); i++) {
            JSONObject ev = links.optJSONObject(i);
            JSONObject p = ev != null ? ev.optJSONObject("payload") : null;
            if (p == null) continue;
            st.index.addStrength(p.optString("a", ""), p.optString("b", ""),
                    p.optDouble("delta", 0), ev.optLong("ts", 0));
        }
        // 规则（事件流即版本历史）
        st.ruleStore.load(toList(journal.eventsOfType(roomId, Journal.TYPE_CAUSAL_RULE)));
    }

    private static List<JSONObject> toList(JSONArray arr) {
        List<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) out.add(arr.optJSONObject(i));
        return out;
    }

    private void persistIndex(String roomId, RoomState st) {
        try {
            File dir = new File(roomsDir, roomId);
            dir.mkdirs();
            File f = new File(dir, "causal.index.json");
            Files.write(f.toPath(), st.index.toJson().toString(2).getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {}
    }

    // ── 写路径 ──

    /** 记录四元组事件 → 索引 → 规则匹配 → 命中落库（_causal_link + 账本区块）。 */
    public JSONObject record(String roomId, CausalEvent ev) {
        JSONObject result = new JSONObject();
        try {
            JSONObject event = new JSONObject()
                    .put("actor", "agent")
                    .put("type", Journal.TYPE_CAUSAL_EVENT)
                    .put("payload", ev.toPayload());
            int seq = journal.append(roomId, event);
            if (seq < 0) return err("写入失败");

            long now = System.currentTimeMillis();
            RoomState st = stateForInner(roomId);
            rebuild(roomId, st);  // 简化：小房间全量重建，规避内存/事件流不一致
            st.index.applyEvent(ev, now);

            CausalRuleEngine.CausalMatchResult mr = st.ruleEngine.match(st.ruleStore, ev, st.index, now);
            JSONArray fired = new JSONArray();
            JSONArray alerts = new JSONArray();
            for (String r : mr.firedRules) fired.put(r);
            for (JSONObject a : mr.alerts) alerts.put(a);

            // 落库：_causal_link 事件（delta 累加）
            boolean hadAlert = false;
            for (JSONObject l : mr.links) {
                JSONObject lp = new JSONObject();
                lp.put("a", l.optString("a"));
                lp.put("b", l.optString("b"));
                lp.put("delta", l.optDouble("delta", 0));
                lp.put("strength", l.optDouble("strength", 0));
                lp.put("reason", "rule_fire");
                journal.append(roomId, new JSONObject()
                        .put("actor", "causal").put("type", Journal.TYPE_CAUSAL_LINK).put("payload", lp));
            }
            // 命中且产出 alert → 账本区块（审计：哪天基于哪条事件）
            if (!mr.alerts.isEmpty()) {
                JSONObject evidence = new JSONObject();
                evidence.put("eventSeq", seq);
                evidence.put("event", ev.canonicalString());
                evidence.put("firedRules", fired);
                evidence.put("alert", mr.alerts.get(0).optString("alert", ""));
                chain.append(journal, roomId, CausalHash.dataHash(ev.canonicalString()),
                        "rule fire", evidence);
                hadAlert = true;
            }
            persistIndex(roomId, st);

            result.put("seq", seq);
            result.put("fired", fired);
            result.put("alerts", alerts);
            result.put("links", mr.links.size());
            result.put("ok", true);
        } catch (Exception e) {
            return err("记录失败: " + e.getMessage());
        }
        return result;
    }

    /** 手动调整关联强度（causal.link 工具）。 */
    public JSONObject link(String roomId, String a, String b, double delta, String reason) {
        try {
            RoomState st = stateForInner(roomId);
            rebuild(roomId, st);
            double strength = st.index.addStrength(a, b, delta, System.currentTimeMillis());
            JSONObject lp = new JSONObject();
            lp.put("a", a);
            lp.put("b", b);
            lp.put("delta", delta);
            lp.put("strength", Math.round(strength * 1000) / 1000.0);
            lp.put("reason", reason == null ? "manual" : reason);
            journal.append(roomId, new JSONObject()
                    .put("actor", "causal").put("type", Journal.TYPE_CAUSAL_LINK).put("payload", lp));
            persistIndex(roomId, st);
            JSONObject r = new JSONObject();
            r.put("a", a); r.put("b", b);
            r.put("strength", Math.round(strength * 1000) / 1000.0);
            r.put("ok", true);
            return r;
        } catch (Exception e) {
            return err("调整关联失败: " + e.getMessage());
        }
    }

    /** 遗忘（causal.forget 工具）：写墓碑 + 从活性索引/规则集移除（原文长在 journal）。 */
    public JSONObject forget(String roomId, String target, String reason) {
        try {
            JSONObject p = new JSONObject();
            p.put("target", target);
            p.put("reason", reason == null ? "user_request" : reason);
            journal.append(roomId, new JSONObject()
                    .put("actor", "causal").put("type", Journal.TYPE_CAUSAL_FORGET).put("payload", p));
            RoomState st = stateForInner(roomId);
            rebuild(roomId, st);
            // target 优先当 ruleId 移除规则；否则当原子标签移除索引
            if (st.ruleStore.get(target) != null) {
                st.ruleStore.remove(target);
            } else {
                st.index.removeAtomByLabel(target);
            }
            persistIndex(roomId, st);
            JSONObject r = new JSONObject();
            r.put("forgotten", target);
            r.put("ok", true);
            return r;
        } catch (Exception e) {
            return err("遗忘失败: " + e.getMessage());
        }
    }

    /** 注册/更新逻辑钩子（causal.rule 工具）。写规则事件 + 账本区块。 */
    public JSONObject upsertRule(String roomId, JSONObject ruleJson) {
        try {
            CausalRule rule = CausalRule.fromJSON(ruleJson);
            JSONObject p = rule.toJSON();
            p.put("op", "upsert");
            journal.append(roomId, new JSONObject()
                    .put("actor", "causal").put("type", Journal.TYPE_CAUSAL_RULE).put("payload", p));
            RoomState st = stateForInner(roomId);
            st.ruleStore.upsert(rule);
            String blockHash = chain.append(journal, roomId,
                    CausalHash.dataHash(p.toString()), "rule upsert " + rule.ruleId, null);
            JSONObject r = new JSONObject();
            r.put("ruleId", rule.ruleId);
            r.put("blockHash", blockHash);
            r.put("chainLen", chain.size(journal, roomId));
            r.put("ok", true);
            return r;
        } catch (Exception e) {
            return err("注册规则失败: " + e.getMessage());
        }
    }

    /** 移除逻辑钩子（causal.rule op=remove）。 */
    public JSONObject removeRule(String roomId, String ruleId) {
        try {
            JSONObject p = new JSONObject();
            p.put("ruleId", ruleId);
            p.put("op", "remove");
            journal.append(roomId, new JSONObject()
                    .put("actor", "causal").put("type", Journal.TYPE_CAUSAL_RULE).put("payload", p));
            RoomState st = stateForInner(roomId);
            st.ruleStore.remove(ruleId);
            chain.append(journal, roomId, CausalHash.dataHash(p.toString()), "rule remove " + ruleId, null);
            JSONObject r = new JSONObject();
            r.put("ruleId", ruleId);
            r.put("removed", true);
            r.put("ok", true);
            return r;
        } catch (Exception e) {
            return err("移除规则失败: " + e.getMessage());
        }
    }

    // ── 读路径 ──

    /** 查询因果记忆概览（causal.query）。 */
    public JSONObject query(String roomId, int limit) {
        try {
            RoomState st = stateFor(roomId);
            long now = System.currentTimeMillis();
            JSONObject r = new JSONObject();
            // 活性规则
            JSONArray rules = new JSONArray();
            for (CausalRule rule : st.ruleStore.active(now)) {
                JSONObject ro = rule.toJSON();
                ro.put("freshness", Math.round(ruleFreshness(rule, now) * 1000) / 1000.0);
                rules.put(ro);
            }
            r.put("rules", rules);
            // 原子数 / 关联强度 top-N
            r.put("atomCount", st.index.atoms().size());
            JSONArray links = new JSONArray();
            List<CausalIndex.LinkEntry> sorted = new ArrayList<>(st.index.links().values());
            sorted.sort(Comparator.comparingDouble((CausalIndex.LinkEntry l) -> l.strength).reversed());
            for (int i = 0; i < Math.min(limit, sorted.size()); i++) {
                CausalIndex.LinkEntry l = sorted.get(i);
                JSONObject lo = new JSONObject();
                lo.put("a", st.index.getByHash(l.a) != null ? st.index.getByHash(l.a).label : l.a);
                lo.put("b", st.index.getByHash(l.b) != null ? st.index.getByHash(l.b).label : l.b);
                lo.put("strength", Math.round(l.strength * 1000) / 1000.0);
                links.put(lo);
            }
            r.put("links", links);
            // 最近事件数
            r.put("eventCount", journal.eventsOfType(roomId, Journal.TYPE_CAUSAL_EVENT).length());
            r.put("ok", true);
            return r;
        } catch (Exception e) {
            return err("查询失败: " + e.getMessage());
        }
    }

    private double ruleFreshness(CausalRule rule, long nowMs) {
        long base = rule.lastFiredTs > 0 ? rule.lastFiredTs : nowMs;
        return Math.exp(-CausalIndex.LAMBDA * (nowMs - base) / 86400000.0);
    }

    /** 预览匹配（不落库；causal.match 预览用）。 */
    public JSONObject match(String roomId, CausalEvent ev) {
        try {
            RoomState st = stateFor(roomId);
            CausalRuleEngine.CausalMatchResult mr = st.ruleEngine.match(st.ruleStore, ev, new CausalIndex(), System.currentTimeMillis());
            JSONObject r = new JSONObject();
            r.put("fired", new JSONArray(mr.firedRules));
            r.put("alerts", new JSONArray(mr.alerts));
            r.put("links", new JSONArray(mr.links));
            r.put("ok", true);
            return r;
        } catch (Exception e) {
            return err("预览失败: " + e.getMessage());
        }
    }

    /** 索引快照（causal.index）。 */
    public JSONObject index(String roomId) {
        try {
            RoomState st = stateFor(roomId);
            JSONObject r = st.index.toJson();
            r.put("ok", true);
            return r;
        } catch (Exception e) {
            return err("索引读取失败: " + e.getMessage());
        }
    }

    /** 认知账本（causal.chain）。 */
    public JSONObject chain(String roomId) {
        try {
            JSONObject r = chain.replay(journal, roomId);
            r.put("ok", true);
            return r;
        } catch (org.json.JSONException e) {
            return err("账本读取失败: " + e.getMessage());
        }
    }

    /** 只读到期提醒（dateAfter 钩子，无副作用；提示词注入用）。 */
    public JSONArray checkDue(String roomId) {
        try {
            RoomState st = stateFor(roomId);
            return new JSONArray(st.ruleEngine.checkDue(st.ruleStore, System.currentTimeMillis(),
                    journal.eventsOfType(roomId, Journal.TYPE_CAUSAL_EVENT)));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    // ── 维护 ──

    /** 衰减清理：stale 原子 + 过期规则 → 写墓碑 + 移除；dateAfter 补触发到期提醒。 */
    public JSONObject sweep(String roomId, long nowMs) {
        try {
            RoomState st = stateFor(roomId);
            JSONArray forgotEvents = new JSONArray();
            int swept = 0;
            for (String h : st.index.staleAtoms(nowMs)) {
                CausalIndex.AtomEntry e = st.index.getByHash(h);
                if (e == null) continue;
                JSONObject p = new JSONObject();
                p.put("target", e.label);
                p.put("reason", "decay");
                forgotEvents.put(p);
                st.index.removeAtom(h);
                swept++;
            }
            List<String> removedRules = st.ruleStore.removeExpired(nowMs);
            for (String rid : removedRules) {
                JSONObject p = new JSONObject();
                p.put("target", rid);
                p.put("reason", "expired");
                forgotEvents.put(p);
            }
            // 墓碑事件
            for (int i = 0; i < forgotEvents.length(); i++) {
                JSONObject p = forgotEvents.optJSONObject(i);
                journal.append(roomId, new JSONObject()
                        .put("actor", "causal").put("type", Journal.TYPE_CAUSAL_FORGET).put("payload", p));
            }
            // dateAfter 补触发（最近 100 条事件）
            List<JSONObject> dueAlerts = st.ruleEngine.checkDue(st.ruleStore, nowMs,
                    journal.eventsOfType(roomId, Journal.TYPE_CAUSAL_EVENT));
            JSONArray dueArr = new JSONArray();
            for (JSONObject a : dueAlerts) dueArr.put(a);
            persistIndex(roomId, st);
            JSONObject r = new JSONObject();
            r.put("swept", swept);
            r.put("forgotten", forgotEvents.length());
            r.put("removedRules", removedRules.size());
            r.put("dueAlerts", dueArr);
            r.put("ok", true);
            return r;
        } catch (Exception e) {
            return err("衰减清理失败: " + e.getMessage());
        }
    }

    private static JSONObject err(String msg) {
        JSONObject r = new JSONObject();
        try { r.put("ok", false); r.put("error", msg); } catch (org.json.JSONException ignored) {}
        return r;
    }
}
