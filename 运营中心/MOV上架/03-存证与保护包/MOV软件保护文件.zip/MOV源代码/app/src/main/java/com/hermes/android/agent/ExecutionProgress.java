package com.hermes.android.agent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * ExecutionProgress — 执行进度管理 (TOOL_ENV_UPGRADE Phase 7)。
 *
 * 替代原始 transcript 堆砌: AI 每轮看到结构化进度 ✓/→/○。
 * 续跑断点: progress 对象不重置, AI 不从已完成步骤重来。
 */
public class ExecutionProgress {

    public final List<StepRecord> steps = new ArrayList<>();
    public JSONArray plan;              // 已批准的计划步骤
    public int currentPlanStep = 0;     // 当前在计划的第几步(0-indexed)

    public static class StepRecord {
        public final int planStepIndex;
        public final String toolName;
        public final String desc;
        public final boolean ok;
        public final String result;       // 结构化结果摘要(Phase 4 aiFeedback)
        public final String producedFile;
        public final long elapsedMs;

        public StepRecord(int psi, String tn, String d, boolean ok, String r, String pf, long ems) {
            this.planStepIndex = psi; this.toolName = tn; this.desc = d; this.ok = ok;
            this.result = r; this.producedFile = pf; this.elapsedMs = ems;
        }

        public JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("planStepIndex", planStepIndex).put("toolName", toolName)
                 .put("desc", desc).put("ok", ok).put("elapsedMs", elapsedMs);
                if (result != null) o.put("result", result);
                if (producedFile != null) o.put("producedFile", producedFile);
            } catch (Exception ignored) {}
            return o;
        }
    }

    /** AI 每轮看到的结构化进度(替代 "第 4/12 步") */
    public String toPromptText() {
        StringBuilder sb = new StringBuilder("═══ 执行进度 ═══\n");
        if (plan == null || plan.length() == 0) {
            sb.append("(无计划步骤)\n");
        } else {
            for (int i = 0; i < plan.length(); i++) {
                JSONObject p = plan.optJSONObject(i);
                String desc = p != null ? p.optString("desc", p.optString("name", "步骤" + (i+1))) : "步骤" + (i+1);
                if (i < currentPlanStep) sb.append("  ✓ ").append(desc).append("\n");
                else if (i == currentPlanStep) sb.append("  → ").append(desc).append(" ← 当前\n");
                else sb.append("  ○ ").append(desc).append("\n");
            }
        }
        // 最近 3 步
        sb.append("\n最近执行:\n");
        int from = Math.max(0, steps.size() - 3);
        for (int i = from; i < steps.size(); i++) {
            StepRecord sr = steps.get(i);
            sb.append("  [计划步骤").append(sr.planStepIndex + 1).append("] ")
              .append(sr.toolName).append(": ")
              .append(sr.ok ? "✓" : "✗").append(" ")
              .append(sr.result != null ? sr.result : sr.desc)
              .append(sr.producedFile != null ? " → " + sr.producedFile : "")
              .append(" (").append(sr.elapsedMs).append("ms)\n");
        }
        sb.append("═══ 进度结束 ═══");
        return sb.toString();
    }

    /** 系统匹配计划步骤(不盲信 AI 声明) */
    public int matchPlanStep(String actionDesc, String toolName) {
        if (plan == null || currentPlanStep >= plan.length()) return -1;
        // 从 currentPlanStep 开始找第一个未完成的匹配步骤
        for (int i = currentPlanStep; i < plan.length(); i++) {
            JSONObject p = plan.optJSONObject(i);
            if (p == null) continue;
            String pDesc = p.optString("desc", "");
            String pName = p.optString("name", p.optString("action", ""));
            // 匹配: desc 包含关键词, 或工具名匹配
            if ((actionDesc != null && !actionDesc.isEmpty() && pDesc.contains(actionDesc))
                    || (toolName != null && pName.contains(toolName))) {
                return i;
            }
        }
        return -1;
    }

    /** 添加执行记录, 推进 currentPlanStep */
    public void addStep(int planIdx, String toolName, String desc, boolean ok, String result, String producedFile, long elapsedMs) {
        steps.add(new StepRecord(planIdx >= 0 ? planIdx : currentPlanStep, toolName, desc, ok, result, producedFile, elapsedMs));
        if (planIdx >= currentPlanStep && planIdx < (plan != null ? plan.length() : 0)) {
            currentPlanStep = planIdx + 1;
        }
    }

    public JSONArray stepsToJson() {
        JSONArray a = new JSONArray();
        for (StepRecord sr : steps) a.put(sr.toJson());
        return a;
    }
}
