package com.hermes.android.agent;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.util.concurrent.ConcurrentHashMap;

/**
 * PromptLoader — prompt 文件缓存层。
 *
 * 文件存 filesDir/prompts/ (首次从 assets 复制, 可编辑无需重编译)。
 * debug build 每次检查 mtime, 文件变自动重载; release 缓存不失效。
 * 文件不存在或损坏 → 返回 fallback (硬编码默认值兜底)。
 */
public class PromptLoader {

    private static final String TAG = "PromptLoader";
    private static final ConcurrentHashMap<String, CachedPrompt> cache = new ConcurrentHashMap<>();
    private static File promptsDir;
    private static boolean isDebug;

    public static void init(Context ctx) {
        File dir = new File(ctx.getApplicationContext().getFilesDir(), "prompts");
        dir.mkdirs();
        promptsDir = dir;
        try {
            isDebug = (ctx.getApplicationContext().getApplicationInfo().flags
                    & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        } catch (Exception ignored) {}
    }

    public static String load(String fileName, String fallback) {
        if (promptsDir == null) return fallback;
        try {
            File f = new File(promptsDir, fileName);
            long mtime = f.exists() ? f.lastModified() : 0;
            CachedPrompt cp = cache.get(fileName);
            // release: 缓存命中直接返回; debug: mtime 变了才重读
            if (cp != null && (!isDebug || cp.mtime == mtime) && mtime > 0) return cp.content;
            if (cp == null && !f.exists() && fallback != null) {
                // 首次: 尝试从 assets 复制默认值到 filesDir
                try {
                    java.io.InputStream is = PromptLoader.class.getClassLoader()
                            .getResourceAsStream("assets/prompts/" + fileName);
                    if (is != null) {
                        java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
                        byte[] buf = new byte[4096]; int n;
                        while ((n = is.read(buf)) != -1) fos.write(buf, 0, n);
                        is.close(); fos.close();
                        mtime = f.lastModified();
                    }
                } catch (Exception ignored) {}
            }
            if (!f.exists()) return fallback;
            String content = new String(java.nio.file.Files.readAllBytes(f.toPath()), "UTF-8");
            if (content.startsWith("@version:")) {
                int nl = content.indexOf('\n');
                if (nl > 0) {
                    String ver = content.substring(9, nl).trim();
                    Log.i(TAG, "loaded " + fileName + " @version " + ver + (isDebug ? " (debug)" : ""));
                    content = content.substring(nl + 1);
                }
            }
            if (!content.trim().isEmpty()) {
                cache.put(fileName, new CachedPrompt(content, mtime));
                return content;
            }
        } catch (Exception e) {
            Log.w(TAG, "load " + fileName + " failed: " + e.getMessage());
        }
        return fallback;
    }

    private static class CachedPrompt {
        final String content; final long mtime;
        CachedPrompt(String c, long m) { content = c; mtime = m; }
    }
}
