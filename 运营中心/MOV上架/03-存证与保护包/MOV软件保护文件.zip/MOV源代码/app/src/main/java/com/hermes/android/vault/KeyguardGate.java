package com.hermes.android.vault;

import androidx.appcompat.app.AppCompatActivity;

import com.hermes.android.security.PaymentGate;

/**
 * KeyguardGate — 保险柜解锁闸（DESIGN_OCR_MOBILE v2 §六纪律 5: vault_unlock = ACTION 审批闸）。
 *
 * 复用 PaymentGate 系统锁屏确认（REQUEST_CODE_PAYMENT_CONFIRM，指纹/PIN/图案）：
 * 解锁前必须过闸；一次只对当次该条目有效（不搞「解锁全场」「解锁 5 分钟」）；
 * 无锁屏密码设备诚实降级（reason=no_lockscreen_denied → 提示需先设锁屏密码），不许静默跳过。
 *
 * 状态机: IDLE → PENDING → APPROVED / REJECTED / CANCELLED / NO_LOCKSCREEN
 * 纯 JVM 可测：Prompter/ResultHandler 为纯接口，测试用 FakePrompter 驱动四路径。
 * 生产接线: HermesActivity.onActivityResult(REQUEST_CODE_PAYMENT_CONFIRM) → paymentGate.handleActivityResult
 * → 触发 PaymentGatePrompter 的 onSuccess/onRejected → 本闸 deliver*（主线程回调）。
 */
public class KeyguardGate {

    public enum State { IDLE, PENDING, APPROVED, REJECTED, CANCELLED, NO_LOCKSCREEN }

    /** 闸结果回调（approve / reject(reason)） */
    public interface ResultHandler {
        void onApproved();
        void onRejected(String reason);   // cancelled / no_lockscreen_denied / ...
    }

    /** 锁屏确认抽象：真实现走 PaymentGate（系统锁屏），测试用 Fake */
    public interface Prompter {
        /** 发起系统锁屏确认。结果经 handler 回调；无锁屏/不可用时直接 onRejected(reason) */
        void prompt(String actionDesc, ResultHandler handler);
    }

    /** 生产 Prompter — 复用 PaymentGate 锁屏确认（支付闸本体 P3 不动） */
    public static class PaymentGatePrompter implements Prompter {
        private final AppCompatActivity activity;
        private final PaymentGate paymentGate;

        public PaymentGatePrompter(AppCompatActivity activity, PaymentGate paymentGate) {
            this.activity = activity;
            this.paymentGate = paymentGate;
        }

        @Override public void prompt(String actionDesc, ResultHandler handler) {
            paymentGate.promptPaymentApproval(activity, actionDesc,
                    handler::onApproved,
                    () -> handler.onRejected(paymentGate.getLastRejectReason()));
        }
    }

    private State state = State.IDLE;
    private String pendingEntryId;   // 本次闸对应的条目（当次有效）
    private ResultHandler handler;

    /** 单例 resultCallback 复用：路由到当前 pending handler（跨线程安全由 synchronized 保证） */
    private final ResultHandler resultCallback = new ResultHandler() {
        @Override public void onApproved() { deliverApproved(); }
        @Override public void onRejected(String reason) { deliverRejected(reason); }
    };

    public synchronized State state() { return state; }
    public synchronized String pendingEntryId() { return pendingEntryId; }

    /**
     * 发起解锁请求（仅 IDLE 可发；PENDING/APPROVED/终端态再次发起 → false，防并发闸与状态劫持）。
     * @return true=闸已进入 PENDING（等待系统锁屏结果）; false=busy
     */
    public synchronized boolean request(Prompter prompter, String entryId, String actionDesc, ResultHandler h) {
        if (state != State.IDLE) return false;
        state = State.PENDING;
        pendingEntryId = entryId;
        handler = h;
        prompter.prompt(actionDesc, resultCallback);
        return true;
    }

    /** 当次授权查询：只对请求时的那个条目有效，一次之后 consume() 复位 */
    public synchronized boolean isApprovedFor(String entryId) {
        return state == State.APPROVED && entryId != null && entryId.equals(pendingEntryId);
    }

    /** 消费授权/复位：批准已被使用或闸已关闭 */
    public synchronized void consume() {
        state = State.IDLE;
        pendingEntryId = null;
        handler = null;
    }

    private synchronized void deliverApproved() {
        if (state != State.PENDING) return;   // 迟到结果（consume 后）忽略
        state = State.APPROVED;
        ResultHandler h = handler;
        handler = null;
        if (h != null) h.onApproved();
    }

    private synchronized void deliverRejected(String reason) {
        if (state != State.PENDING) return;   // 迟到结果（consume 后）忽略
        if ("no_lockscreen_denied".equals(reason)) state = State.NO_LOCKSCREEN;
        else if ("cancelled".equals(reason)) state = State.CANCELLED;
        else state = State.REJECTED;
        ResultHandler h = handler;
        handler = null;
        if (h != null) h.onRejected(reason);
    }
}
