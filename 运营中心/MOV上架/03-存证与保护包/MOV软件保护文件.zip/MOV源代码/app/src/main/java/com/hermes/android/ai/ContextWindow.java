package com.hermes.android.ai;

import java.util.ArrayList;
import java.util.List;

/**
 * 上下文窗口 — 滑动窗口截断 + Token 估算。
 *
 * 热路径（trim）：纯内存，无 IO，< 5ms。
 * 冷路径（summarize）：后台异步，调快模型做摘要。
 *
 * Token 估算用字符数启发式，不引入 tiktoken：
 *   中文 ≈ 1.5 字符/token
 *   英文 ≈ 4 字符/token
 *   误差 ±20%，不影响截断正确性。
 */
public final class ContextWindow {

    private ContextWindow() {}

    /** 默认 token 上限 */
    public static final int DEFAULT_MAX_TOKENS = 50_000;

    /** 保留最近 N 轮完整内容 */
    public static final int KEEP_FULL_ROUNDS = 10;

    /** 中等轮次每条截断到 N 字符 */
    public static final int TRUNCATE_CHARS = 500;

    /** 早于 N 轮直接丢弃 */
    public static final int KEEP_ROUNDS = 20;

    // ============================================================
    // Token 估算
    // ============================================================

    /**
     * 估算消息列表的总 token 数。
     * 使用字符数启发式，不依赖 tiktoken。
     */
    public static int estimateTokens(List<AiClient.Message> messages) {
        int total = 0;
        for (AiClient.Message m : messages) {
            total += estimateTokens(m.content);
        }
        return total;
    }

    /** 单条文本 token 估算 */
    public static int estimateTokens(String text) {
        if (text == null || text.isEmpty()) return 0;
        int chinese = 0, other = 0;
        for (int i = 0; i < text.length(); i++) {
            if (isCJK(text.charAt(i))) {
                chinese++;
            } else {
                other++;
            }
        }
        return (int) (chinese / 1.5 + other / 4.0);
    }

    private static boolean isCJK(char c) {
        Character.UnicodeBlock block = Character.UnicodeBlock.of(c);
        return block == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
            || block == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
            || block == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B
            || block == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS;
    }

    // ============================================================
    // 滑动窗口截断
    // ============================================================

    /**
     * 滑动窗口截断。纯内存操作，无 IO。
     *
     * 策略：
     *   1. 计算总 token，未超限直接返回原列表
     *   2. system prompt 不截（调用方负责保留）
     *   3. 最近 KEEP_FULL_ROUNDS 轮 → 保留原文
     *   4. KEEP_FULL_ROUNDS ~ KEEP_ROUNDS 轮 → 截断到 TRUNCATE_CHARS 字符
     *   5. KEEP_ROUNDS 轮以上 → 丢弃
     *
     * @param history   消息历史（user/assistant 交替）
     * @param maxTokens token 上限
     * @return 截断后的消息列表
     */
    public static List<AiClient.Message> trim(List<AiClient.Message> history, int maxTokens) {
        if (history == null || history.isEmpty()) return history;

        int total = estimateTokens(history);
        if (total <= maxTokens) return new ArrayList<>(history);

        // 从尾部往前保留（最近的消息在尾部）
        List<AiClient.Message> result = new ArrayList<>();
        int kept = 0;
        int round = 0; // 轮次计数（user+assistant 算一轮）

        for (int i = history.size() - 1; i >= 0; i--) {
            AiClient.Message m = history.get(i);
            boolean isUser = "user".equals(m.role);

            if (round < KEEP_FULL_ROUNDS) {
                // 最近 N 轮保留原文
                result.add(0, m);
                kept += estimateTokens(m.content);
                if (isUser) round++;
            } else if (round < KEEP_ROUNDS) {
                // 中等轮次截断
                if (m.content != null && m.content.length() > TRUNCATE_CHARS) {
                    String truncated = m.content.substring(0, TRUNCATE_CHARS) + "...";
                    result.add(0, new AiClient.Message(m.role, truncated));
                    kept += estimateTokens(truncated);
                } else {
                    result.add(0, m);
                    kept += estimateTokens(m.content);
                }
                if (isUser) round++;
            } else {
                // 旧消息直接丢弃
                if (isUser) round++;
                continue;
            }

            if (kept >= maxTokens) break;
        }

        return result;
    }

    /**
     * 使用默认上限的 trim。
     */
    public static List<AiClient.Message> trim(List<AiClient.Message> history) {
        return trim(history, DEFAULT_MAX_TOKENS);
    }

    // ============================================================
    // 后台摘要（冷路径，异步）
    // ============================================================

    /**
     * 摘要回调：调用方实现以注入 LLM 客户端。
     */
    public interface SummaryCallback {
        void onSummaryReady(String summary);
        void onSummaryError(String error);
    }

    /**
     * 对丢弃的旧消息做摘要。
     * 在后台线程中调用，不阻塞 UI。
     *
     * @param dropped  被 trim 丢弃的消息
     * @param callback 摘要完成后回调（可在任意线程）
     */
    /** 实体保留摘要 prompt */
    public static final String SUMMARY_PROMPT = "你是一个摘要生成器。"
        + "将以下对话压缩为不超过 200 字的摘要。"
        + "必须保留: ①文件路径和文件名 ②工具名称(如shell.exec/app.package)"
        + "③关键参数值 ④用户原始目标。省略闲聊和格式错误。只输出摘要。";

    public static void summarizeAsync(List<AiClient.Message> dropped, SummaryCallback callback) {
        if (dropped == null || dropped.isEmpty()) {
            if (callback != null) callback.onSummaryReady("");
            return;
        }
        new Thread(() -> {
            try {
                StringBuilder sb = new StringBuilder();
                for (AiClient.Message m : dropped) {
                    if (m.content == null) continue;
                    String role = "user".equals(m.role) ? "用户" : "AI";
                    sb.append("[").append(role).append("] ");
                    // 每条消息取前 150 字符做摘要素材
                    String snippet = m.content.length() > 150
                            ? m.content.substring(0, 150) + "..."
                            : m.content;
                    sb.append(snippet).append("\n");
                }
                // Phase 2: 将 SUMMARY_PROMPT + sb 发给快模型生成结构化摘要
                // 当前阶段: 返回 SUMMARY_PROMPT 限制的实体保留素材
                String summary = "【摘要素材】\n"
                    + sb.toString()
                    + "\n---\n(Phase 2 将用 SUMMARY_PROMPT 经 LLM 压缩为 200 字实体保留摘要)";
                if (callback != null) callback.onSummaryReady(summary);
            } catch (Exception e) {
                if (callback != null) callback.onSummaryError(e.getMessage());
            }
        }, "context-summary").start();
    }
}
