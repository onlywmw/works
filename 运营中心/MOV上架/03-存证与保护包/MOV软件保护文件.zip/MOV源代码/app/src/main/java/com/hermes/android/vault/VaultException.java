package com.hermes.android.vault;

/**
 * 保险柜异常 — 带机器可读 code（桥错误信封 {ok, error:{code,msg}} 直接映射）。
 */
public class VaultException extends RuntimeException {

    public final String code;

    public VaultException(String code, String msg) {
        super(msg);
        this.code = code;
    }
}
