package com.hermes.android.pay;

import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.Base64;

/**
 * 微信支付 API v3 签名器（工单26 M1-1）。
 *
 * 签名串 = method\n + urlPath\n + timestamp\n + nonce\n + body\n （五段，每段含末尾换行），
 * SHA256withRSA；HTTP 头 Authorization: WECHATPAY2-SHA256-RSA2048 mchid=…,serial_no=…,nonce_str=…,timestamp=…,signature=…
 *
 * 纯函数可单测：固定 nonce/timestamp + 测试 RSA 密钥对 → 公钥 verify 回环。
 */
public final class WxPaySigner {

    private WxPaySigner() {}

    /** API v3 签名（Base64 NO_WRAP）。body 可为 null（GET 无报文 → 空串段） */
    public static String sign(PrivateKey key, String method, String urlPath,
                              long timestamp, String nonce, String body) throws Exception {
        String msg = method + "\n" + urlPath + "\n" + timestamp + "\n" + nonce + "\n"
                + (body == null ? "" : body) + "\n";
        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initSign(key);
        sig.update(msg.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(sig.sign());
    }

    /** 拼 Authorization 头（微信字段顺序固定，别乱） */
    public static String authHeader(String mchid, String serialNo, String signature,
                                    long ts, String nonce) {
        return "WECHATPAY2-SHA256-RSA2048 mchid=\"" + mchid
                + "\",nonce_str=\"" + nonce
                + "\",signature=\"" + signature
                + "\",timestamp=\"" + ts
                + "\",serial_no=\"" + serialNo + "\"";
    }
}
