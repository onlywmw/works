package com.hermes.android.linux;

import android.content.Context;
import android.util.Log;

import org.json.JSONObject;

/**
 * RoomEnv — 创建房间时真实初始化 Linux 环境并产出环境清单 (M-ARCH-ENV)。
 *
 * 流程: rootfs READY 检查 → 确认房间 work 目录 → proot 预热 → 一条 exec 实测
 * 工具链版本 (python3/node/git/jq/rg/hermes) → 写入房间 room.json 的 env 段。
 * 不装样子: 任何一步失败都如实体现在结果里 (needInstall / partial)。
 */
public class RoomEnv {

    private static final String TAG = "RoomEnv";

    /** 工具链实测命令 (一条 exec 完成; hermes 不存在不致命) */
    static final String PROBE_CMD =
            "echo PY:$(python3 --version 2>&1);"
            + "echo NODE:$(node --version 2>&1);"
            + "echo GIT:$(git --version 2>&1);"
            + "echo JQ:$(jq --version 2>&1);"
            + "echo RG:$(rg --version 2>&1 | head -1);"
            + "echo HERMES:$(~/.hermes-venv/bin/hermes --version 2>&1 | head -1)";

    public static class Result {
        public boolean ok;
        public boolean needInstall;
        public String error = "";
        public JSONObject env = new JSONObject();
        public long durationMs;
    }

    public static Result prepare(Context ctx, String roomId) {
        long t0 = System.currentTimeMillis();
        Result r = new Result();
        /* ① rootfs 未 READY: 诚实回报, 不装死 */
        if (!RootfsManager.isReady(ctx)) {
            r.needInstall = true;
            r.error = "Linux 环境未就绪";
            r.durationMs = System.currentTimeMillis() - t0;
            return r;
        }
        RootfsManager rm = new RootfsManager(ctx);
        /* ② 确认房间 work 目录 (shell.exec 的 /room bind 目标) */
        java.io.File roomDir = new com.hermes.android.StorageManager(ctx).roomWorkDir(roomId);
        /* ③ proot 预热 (冷启动分摊: 第一次 exec 要起 proot 进程) */
        ProotRunner.ExecResult warm = ProotRunner.exec(ctx, "true", 60, roomDir);
        Log.i(TAG, "预热 exit=" + warm.exitCode + " (" + (System.currentTimeMillis() - t0) + "ms)");
        /* ④ 工具链实测 */
        ProotRunner.ExecResult probe = ProotRunner.exec(ctx, PROBE_CMD, 120, roomDir);
        if (probe.exitCode != 0 && probe.stdout.isEmpty()) {
            r.error = "工具链实测失败 exit=" + probe.exitCode + " " + probe.stderr.trim();
            r.durationMs = System.currentTimeMillis() - t0;
            return r;
        }
        r.env = parseToolVersions(probe.stdout);
        r.ok = true;
        r.durationMs = System.currentTimeMillis() - t0;
        /* ⑤ 环境清单落房间元数据 */
        try {
            r.env.put("preparedAt", System.currentTimeMillis());
            r.env.put("durationMs", r.durationMs);
            new com.hermes.android.StorageManager(ctx).writeRoomEnv(roomId, r.env);
        } catch (Exception e) {
            Log.w(TAG, "writeRoomEnv: " + e.getMessage());
        }
        return r;
    }

    /** 解析 PROBE_CMD 输出 → 环境清单 (纯函数, 单测用)。
     *  每项取首个版本号; hermes 取整行首条; 缺项为 null。 */
    public static JSONObject parseToolVersions(String out) {
        JSONObject env = new JSONObject();
        try {
            env.put("ubuntu", "24.04");
            env.put("python", firstVersion(lineVal(out, "PY:")));
            env.put("node", firstVersion(lineVal(out, "NODE:")));
            env.put("git", firstVersion(lineVal(out, "GIT:")));
            env.put("jq", firstVersion(lineVal(out, "JQ:")));
            env.put("rg", firstVersion(lineVal(out, "RG:")));
            String hermes = lineVal(out, "HERMES:");
            env.put("hermes", hermes.contains("Hermes Agent")
                    ? hermes.replace("Hermes Agent", "").trim() : JSONObject.NULL);
        } catch (Exception ignored) {}
        return env;
    }

    /** 取 "KEY:值" 行的值 (纯函数) */
    static String lineVal(String out, String key) {
        if (out == null) return "";
        for (String line : out.split("\n")) {
            String t = line.trim();
            if (t.startsWith(key)) return t.substring(key.length()).trim();
        }
        return "";
    }

    /** 取第一个形如 x.y(.z) 的版本号; 没有则取整行; 空行返回 null 串 (纯函数) */
    static String firstVersion(String s) {
        if (s == null || s.isEmpty()) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(\\d+\\.\\d+(?:\\.\\d+)?)").matcher(s);
        if (m.find()) return m.group(1);
        return s.split("\n")[0].trim();
    }
}
