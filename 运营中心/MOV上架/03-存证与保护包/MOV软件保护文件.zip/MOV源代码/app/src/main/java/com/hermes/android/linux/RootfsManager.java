package com.hermes.android.linux;

import android.content.Context;
import android.util.Log;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.Arrays;

/**
 * RootfsManager — 内嵌 Ubuntu 24.04 rootfs 的安装/状态/卸载。
 *
 * 目录布局 (getFilesDir()):
 *   linux/rootfs/             Ubuntu rootfs (proot -r 的目标)
 *   linux/ubuntu-base.tar.gz  下载暂存包
 *   linux/state.json          持久化状态 {"state":"READY","msg":""}
 *   linux-exchange/           guest /exchange 挂载点 (房间 ⇆ Linux 文件交换)
 *
 * 状态机: NOT_INSTALLED → DOWNLOADING(进度%) → EXTRACTING → BOOTSTRAPPING → READY
 *         任意一步失败 → ERROR(msg)
 */
public class RootfsManager {

    public enum State { NOT_INSTALLED, DOWNLOADING, EXTRACTING, BOOTSTRAPPING, READY, ERROR }

    private static final String TAG = "RootfsManager";

    public interface Listener {
        void onState(State state, int progress, String msg);
    }

    /** APK 预置 rootfs 种子包（M5 定制，app/seed/ → assets/ubuntu-rootfs.tgz，安装即解压就绪） */
    private static final String ASSET_SEED = "ubuntu-rootfs.tgz";

    private final Context ctx;
    private final File linuxDir;
    private volatile State state = State.NOT_INSTALLED;
    private volatile int progress = 0;
    private volatile String errorMsg = "";
    private volatile Listener listener;

    /** 缓存 diskUsage, 首次返回 0 并异步计算, 避免 UI 线程卡死。
     *  真机验收 2026-08-05 (P4): 必须进程级 static —— RootfsManager 被各处 new
     *  (ProotRunner.exec/isReady/HeavyWorker.available...), 实例级守卫会让每次 new
     *  都起一条 dirSize 全树遍历线程; 1.5GB rootfs 上 10 条并发遍历的 listFiles
     *  分配风暴把 app 打进 GC 死循环直至进程被杀 (trace_03 实证 10 条 disk-usage 线程) */
    private static volatile long cachedDiskUsage = -1;
    private static volatile boolean diskUsageRunning = false;

    public RootfsManager(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.linuxDir = new File(ctx.getFilesDir(), "linux");
        loadState();
        // 异步预计算磁盘占用，避免第一次 renderLinuxSection 卡死 UI 线程
        refreshDiskUsageAsync(this);
    }

    /** 异步刷新磁盘占用, 完成后回调 listener 更新 UI (进程级单飞: 类锁 + static 守卫) */
    public static void refreshDiskUsageAsync(RootfsManager self) {
        startDiskUsageIfIdle(() -> {
            long usage = dirSize(self.linuxDir) + dirSize(self.exchangeDir());
            cachedDiskUsage = usage;
            Listener l = self.listener;
            if (l != null) l.onState(self.state, self.progress, "");
        });
    }

    /** 单测观察口 (包可见): 单飞守卫是否空闲 */
    static boolean diskUsageIdleForTest() { return !diskUsageRunning; }

    /** 单飞守卫 (包可见, 单测直调): 已有计算在跑 → false; 否则起线程跑 compute。
     *  R4 打回修复: try/finally 复位 —— compute 抛未受检异常时守卫也必须放开,
     *  否则单飞永久卡死 (磁盘占用永远不刷新) */
    static synchronized boolean startDiskUsageIfIdle(Runnable compute) {
        if (diskUsageRunning) return false;
        diskUsageRunning = true;
        new Thread(() -> {
            try {
                compute.run();
            } finally {
                diskUsageRunning = false;
            }
        }, "disk-usage").start();
        return true;
    }

    public File rootfsDir() { return new File(linuxDir, "rootfs"); }
    public File exchangeDir() { return new File(ctx.getFilesDir(), "linux-exchange"); }
    private File stagingPkg() { return new File(linuxDir, "ubuntu-base.tar.gz"); }
    private File stateFile() { return new File(linuxDir, "state.json"); }

    public State getState() { return state; }
    public int getProgress() { return progress; }
    public String getErrorMsg() { return errorMsg; }
    public void setListener(Listener l) { listener = l; }

    /** READY 判定: 持久化状态 + rootfs 关键文件仍在 (防用户清数据后状态撒谎) */
    public boolean isReady() {
        boolean ready = state == State.READY && new File(rootfsDir(), "usr/bin/env").isFile();
        if (ready && cachedDiskUsage < 0) refreshDiskUsageAsync(this);
        return ready;
    }

    public static boolean isReady(Context ctx) {
        return new RootfsManager(ctx).isReady();
    }

    /** 磁盘占用 (linux + linux-exchange, 字节) — 返回缓存值, 不阻塞 */
    public long diskUsage() {
        if (cachedDiskUsage >= 0) return cachedDiskUsage;
        refreshDiskUsageAsync(this);
        return 0;  // 首次返回 0, 异步算完后 listener 触发 renderLinuxSection 更新
    }

    /**
     * E-11（P0，2026-08-09 验收打回）：dirSize 全树遍历防符号链接环。
     * rootfs 内 bin/X11、node doc 等存在循环符号链接——旧实现递归 listFiles()
     * 无限递归 → 分配风暴 → GC 死锁（App CPU 100% / 459 条 GC 日志实测）。
     * 修法：Files.walkFileTree + 不跟随链接（NOFOLLOW）+ 目录遇 symlink SKIP_SUBTREE。
     * 历史呼应：2026-08-05 P4 修过多线程并发（diskUsageRunning 单飞守卫），本修补「单线程遍历本身撞环」。
     */
    static long dirSize(File f) {
        if (f == null || !f.exists()) return 0;
        final long[] sum = {0};
        try {
            Files.walkFileTree(f.toPath(),
                    java.util.EnumSet.noneOf(java.nio.file.FileVisitOption.class),  // NOFOLLOW_LINKS
                    Integer.MAX_VALUE,
                    new java.nio.file.SimpleFileVisitor<java.nio.file.Path>() {
                        @Override
                        public java.nio.file.FileVisitResult preVisitDirectory(
                                java.nio.file.Path dir, java.nio.file.attribute.BasicFileAttributes attrs) {
                            // 双保险：符号链接目录不递归（NOFOLLOW 下本分支通常不触发，防御性保留）
                            if (Files.isSymbolicLink(dir)) {
                                return java.nio.file.FileVisitResult.SKIP_SUBTREE;
                            }
                            return java.nio.file.FileVisitResult.CONTINUE;
                        }

                        @Override
                        public java.nio.file.FileVisitResult visitFile(
                                java.nio.file.Path p, java.nio.file.attribute.BasicFileAttributes attrs) {
                            sum[0] += attrs.size();
                            return java.nio.file.FileVisitResult.CONTINUE;
                        }

                        @Override
                        public java.nio.file.FileVisitResult visitFileFailed(
                                java.nio.file.Path p, java.io.IOException exc) {
                            // 单个文件失败不阻断整树（权限/损坏链接等）
                            return java.nio.file.FileVisitResult.CONTINUE;
                        }
                    });
        } catch (Exception e) {
            Log.w(TAG, "dirSize 遍历中断: " + e.getMessage());
        }
        return sum[0];
    }

    // ==================== 安装 ====================

    /** 后台线程跑完整安装流程; 重入安全 (进行中再调直接忽略) */
    public synchronized void install() {
        if (state == State.DOWNLOADING || state == State.EXTRACTING
                || state == State.BOOTSTRAPPING) return;
        new Thread(this::doInstall, "rootfs-install").start();
    }

    private void doInstall() {
        try {
            exchangeDir().mkdirs();
            if (!Proot.present(ctx)) {
                setState(State.ERROR, 0, "proot 未随包安装 (非 arm64 设备?)");
                return;
            }
            /* ① 取包: APK 预置种子 */
            File pkg = stagingPkg();
            if (!obtainPackage(pkg)) return; // 内部已置 ERROR
            /* ①b 空间预检: 暂存包 + 解压后 rootfs 双份峰值（大种子 ~1.5GB 解压） */
            if (!ensureSpace(pkg.length())) return;
            /* ② 解压前必须彻底清空 rootfs: 带残渣解压 GNU tar 会报
               "Cannot open: File exists" (旧 rootfs 可能来自手动装包/上次失败的安装) */
            setState(State.EXTRACTING, 0, "");
            File rootfs = rootfsDir();
            String clearErr = clearDirectory(rootfs);
            if (clearErr != null) {
                setState(State.ERROR, 0, "清空旧 rootfs 失败: " + clearErr);
                return;
            }
            /* rootfs 重建 = hermes venv 随之消亡 → 同步清状态, 防脏 READY
               (设置页才能正确显示「安装 Hermes」而不是「重装」) */
            new File(ctx.getFilesDir(), "linux/hermes-state.json").delete();
            rootfs.mkdirs();
            /* 直接 exec 随包 GNU tar（无 proot ptrace 开销——解压 1.5GB 大种子 68s → ~20s） */
            if (!untarDirect(rootfs, pkg)) return;
            pkg.delete(); // 暂存种子不留
            /* ③ 初始化: DNS + apt sandbox 绕行 (proot 下 apt 签名验证必败的固定药方) */
            writeFile(new File(rootfs, "etc/resolv.conf"),
                    "nameserver 8.8.8.8\nnameserver 223.5.5.5\n");
            writeFile(new File(rootfs, "etc/apt/apt.conf.d/99mov-proot"),
                    "APT::Sandbox::User \"root\";\n");
            /* ③.5 预装包检测: 预置 rootfs (重打包时 --hard-dereference 消除硬链接,
               shell 域已装好 python3/git) 直接 READY, 跳过 in-app apt —
               app 域 dpkg 的 status-old 硬链接无法被静态 proot 模拟, 装包必败 */
            ProotRunner.ExecResult pre = ProotRunner.exec(ctx, "python3 --version", 60);
            Log.i(TAG, "预装检测 exit=" + pre.exitCode + " out=" + tail(pre.stdout));
            if (pre.exitCode == 0 && pre.stdout.contains("Python")) {
                setState(State.READY, 100, "");
                return;
            }
            /* ④ 首启装包 (vanilla Ubuntu Base 包的兜底路径); 个别 postinst dpkg error
               属正常, 以 python3 --version 判成功;
               update 与 install 分开跑 (proot ptrace 下 dpkg 很慢, 合并跑 600s 不够) */
            setState(State.BOOTSTRAPPING, 0, "");
            ProotRunner.ExecResult upd = ProotRunner.exec(ctx, "apt-get update", 300);
            if (upd.timeout) {
                setState(State.ERROR, 0, "apt-get update 超时, 检查网络后重装");
                return;
            }
            Log.i(TAG, "apt-get update exit=" + upd.exitCode + " tail=" + tail(upd.stderr));
            ProotRunner.ExecResult boot = ProotRunner.exec(ctx,
                    "apt-get install -y python3 python3-venv git", 600);
            Log.i(TAG, "apt-get install exit=" + boot.exitCode + " timeout=" + boot.timeout
                    + " tail=" + tail(boot.stdout + boot.stderr));
            if (boot.timeout) {
                /* proot ptrace 下 dpkg 很慢, 平板首次装 ~100 个包可能超 10 分钟;
                   dpkg 可断点续跑: 先 configure -a 收拾残局再重试一轮 */
                Log.i(TAG, "bootstrap 首轮超时, 续跑第二轮");
                ProotRunner.ExecResult resume = ProotRunner.exec(ctx,
                        "dpkg --configure -a && apt-get install -y python3 python3-venv git", 600);
                Log.i(TAG, "bootstrap 二轮 exit=" + resume.exitCode + " timeout=" + resume.timeout);
                if (resume.timeout) {
                    setState(State.ERROR, 0, "装包超时 (>20 分钟), 检查网络后重装");
                    return;
                }
            }
            ProotRunner.ExecResult check = ProotRunner.exec(ctx, "python3 --version", 30);
            if (check.exitCode == 0 && check.stdout.contains("Python")) {
                setState(State.READY, 100, "");
            } else {
                setState(State.ERROR, 0, "python3 校验失败: " + tail(boot.stdout + boot.stderr));
            }
        } catch (Exception e) {
            setState(State.ERROR, 0, e.getMessage() != null ? e.getMessage() : "安装异常");
        }
    }

    /** APK 预置种子（assets/ubuntu-base.tar.gz）→ staging; 成功 true, 失败置 ERROR 返回 false */
    private boolean obtainPackage(File pkg) {
        setState(State.DOWNLOADING, 0, "");
        try (InputStream in = ctx.getAssets().open(ASSET_SEED);
             FileOutputStream out = new FileOutputStream(pkg)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return true;
        } catch (Exception e) {
            pkg.delete();
            setState(State.ERROR, 0, "种子包缺失: "
                    + (e.getMessage() != null ? e.getMessage() : "assets 未预置"));
            return false;
        }
    }

    /** 空间预检：filesDir 剩余 ≥ 2.5× 种子（暂存包 + 解压后 rootfs 双份峰值）。不足置 ERROR 返回 false。 */
    private boolean ensureSpace(long seedBytes) {
        try {
            android.os.StatFs sf = new android.os.StatFs(ctx.getFilesDir().getPath());
            long avail = (long) sf.getAvailableBlocksLong() * sf.getBlockSizeLong();
            long need = seedBytes * 2L + (1L << 30);  // 暂存 + 解压(~2×) + 余量 1GB
            if (avail < need) {
                setState(State.ERROR, 0, "存储空间不足（需约 " + ((need >> 30) + 1) + "GB，可用 " + (avail >> 30) + "GB）");
                return false;
            }
            return true;
        } catch (Exception e) {
            return true;  // 预检失败不阻塞（保守放行）
        }
    }

    /** 直接 exec 随包 GNU tar（libtar.so + LD_LIBRARY_PATH），无 proot ptrace 开销——大种子解压提速关键。 */
    private boolean untarDirect(File rootfs, File pkg) {
        try {
            ProcessBuilder pb = new ProcessBuilder(
                    Proot.tarBinary(ctx).getAbsolutePath(),
                    "-I", Proot.gzipBinary(ctx).getAbsolutePath(),
                    "-xf", pkg.getAbsolutePath(),
                    "-C", rootfs.getAbsolutePath());
            pb.environment().put("LD_LIBRARY_PATH", Proot.libDir(ctx));
            pb.redirectErrorStream(true);
            Process p = pb.start();
            Thread out = new Thread(() -> {
                try (java.io.InputStream is = p.getInputStream()) {
                    byte[] b = new byte[8192];
                    while (is.read(b) != -1) { /* 读空防管道阻塞 */ }
                } catch (Exception ignored) {}
            });
            out.start();
            boolean finished = p.waitFor(600, java.util.concurrent.TimeUnit.SECONDS);
            if (!finished) {
                p.destroyForcibly();
                setState(State.ERROR, 0, "解压超时");
                return false;
            }
            if (p.exitValue() != 0) {
                setState(State.ERROR, 0, "解压失败 exit=" + p.exitValue());
                return false;
            }
            return true;
        } catch (Exception e) {
            setState(State.ERROR, 0, "解压异常: " + e.getMessage());
            return false;
        }
    }

    // ==================== 卸载 ====================

    public synchronized void uninstall() {
        deleteRecursive(rootfsDir());
        File pkg = stagingPkg();
        if (pkg.exists()) pkg.delete();
        File ex = exchangeDir();
        File[] kids = ex.listFiles();
        if (kids != null) for (File k : kids) deleteRecursive(k);
        setState(State.NOT_INSTALLED, 0, "");
    }

    private static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursive(k);
        }
        f.delete();
    }

    /** 严格清空目录 (整个删掉再重建): 任何删除失败返回描述, 全清成功返回 null */
    static String clearDirectory(File dir) {
        if (dir == null || !dir.exists()) return null;
        String err = clearRecursive(dir);
        if (err != null) return err;
        if (!dir.mkdirs() && !dir.isDirectory()) return "重建失败: " + dir.getAbsolutePath();
        /* 复核: 目录必须已空 (listFiles 为 null 也视为失败, 防带残渣解压) */
        String[] left = dir.list();
        if (left == null) return "无法读取 " + dir.getAbsolutePath();
        if (left.length > 0) return "残留 " + left.length + " 项 (如 " + left[0] + ")";
        return null;
    }

    private static String clearRecursive(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) {
                    String err = clearRecursive(k);
                    if (err != null) return err;
                }
            }
        }
        if (!f.delete()) return "删除失败: " + f.getAbsolutePath();
        return null;
    }

    // ==================== 状态持久化 ====================

    private void setState(State s, int prog, String msg) {
        state = s;
        progress = prog;
        errorMsg = msg != null ? msg : "";
        Log.i(TAG, "state=" + s + " progress=" + prog
                + (errorMsg.isEmpty() ? "" : " msg=" + errorMsg));
        /* 下载进度刷得太勤, 只有非 DOWNLOADING 或整十进度才落盘 */
        if (s != State.DOWNLOADING || prog % 10 == 0) saveState();
        Listener l = listener;
        if (l != null) {
            try { l.onState(s, progress, errorMsg); } catch (Exception ignored) {}
        }
    }

    private void saveState() {
        try {
            linuxDir.mkdirs();
            JSONObject o = new JSONObject()
                    .put("state", state.name())
                    .put("msg", errorMsg);
            try (FileWriter fw = new FileWriter(stateFile())) {
                fw.write(o.toString());
            }
        } catch (Exception ignored) {}
    }

    private void loadState() {
        try {
            File f = stateFile();
            if (!f.isFile()) return;
            String text = new String(Files.readAllBytes(f.toPath()));
            JSONObject o = new JSONObject(text);
            State s = State.valueOf(o.optString("state", "NOT_INSTALLED"));
            state = normalizeRestored(s);
            errorMsg = o.optString("msg", "");
        } catch (Exception ignored) {}
    }

    /** 进程死在中途的 DOWNLOADING/EXTRACTING/BOOTSTRAPPING 一律回落 NOT_INSTALLED (纯函数, 单测用) */
    static State normalizeRestored(State s) {
        if (s == State.DOWNLOADING || s == State.EXTRACTING || s == State.BOOTSTRAPPING) {
            return State.NOT_INSTALLED;
        }
        return s;
    }

    private static void writeFile(File f, String content) throws Exception {
        f.getParentFile().mkdirs();
        try (FileWriter fw = new FileWriter(f)) {
            fw.write(content);
        }
    }

    private static String tail(String s) {
        if (s == null) return "";
        String t = s.trim();
        return t.length() > 200 ? "…" + t.substring(t.length() - 200) : t;
    }
}
