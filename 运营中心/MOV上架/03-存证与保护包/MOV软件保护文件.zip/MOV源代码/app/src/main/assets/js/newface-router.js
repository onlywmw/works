/* ============================================================
   newface-router.js — 新脸意图路由决策（纯逻辑，无 DOM 依赖）
   FUSION F2/F4: 正则快速通道 → LLM intent 权威判 → domain 兼容兜底。
   抽成独立模块便于 node 单测（app/src/test/js/newface-router.test.js）。
   浏览器: window.NewFaceRouter / Node: module.exports
   ============================================================ */
(function(root, factory) {
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    root.NewFaceRouter = api;
  }
})(typeof window !== 'undefined' ? window : this, function() {

  function isMusic(text) {
    return /我要听|播放.*歌|来一首|我想听|听.*的歌|放.*歌|唱.*歌/.test(text);
  }
  function isTrain(text) {
    // P1-3: 排除机票——「订去北京的机票」不得命中。「的」后必须紧邻票/或火车/高铁/动车+票
    return /火车票|高铁|动车|去.*的.*火车|订.*去.*的(火车|高铁|动车)?票/.test(text);
  }
  function isA2A(text) {
    return /来一份|来碗|来份|我要吃|我想吃|想吃|盖浇饭|点餐|点单|下单.*吃|叫.*外卖|来.*个.*菜|买.*菜|下.*单.*菜|点.*个.*菜/.test(text);
  }
  /** P1 B: 网页搜索/查资料类指令（搜评价/资讯/价格/攻略/资料/信息，或用浏览器打开）——区别于 drama/music */
  function isBrowserSearch(text) {
    return /搜.*(评价|资讯|价格|攻略|资料|信息|内容)|查.*(价格|资料|信息|攻略)|找.*(攻略|资料|评价)|用浏览器打开|打开.*网页/.test(text);
  }

  /**
   * 意图路由决策 → 动作标识：
   *   'music' | 'train' | 'drama' | 'a2a' | 'handoff' | 'chat' | 'none'
   *
   * 判定顺序：
   *   1. 正则快速通道（高置信直通，省 LLM）
   *   2. LLM intent 权威判（正则未命中时）
   *   3. domain 兼容兜底——仅限「无 intent 字段」的旧响应；
   *      有 intent（哪怕 unknown）时绝不猜，宁走诚实卡/静态 Flow
   *   4. creation/低置信 → handoff；chat → chat；其余 → none
   *
   * 回归向量：订机票（LLM 返回 intent=unknown + domain=travel）必须 'none'，
   * 绝不能进 train（火车票）。
   */
  function resolve(text, data, mode) {
    if (isMusic(text)) return 'music';
    if (isTrain(text)) return 'train';
    if (isA2A(text)) return 'a2a';
    if (isBrowserSearch(text)) return 'browser';   // P1 B: 网页搜索 → 浏览器链路（agent），正则优先防误归 drama
    if (mode === 'regex') return 'none'; // 省 token 模式：正则未命中即不猜，不读 LLM intent/domain
    if (!data) return 'none';
    var intent = data.intent;
    if (intent === 'music') return 'music';
    if (intent === 'train') return 'train';
    if (intent === 'drama') return 'drama';
    if (intent === 'a2a') return 'a2a';
    if (intent === 'browser') return 'browser';    // P1 B: LLM 判网页搜索
    // domain 补位仅限无 intent 字段的旧响应
    if (!intent) {
      if ((data.domain === 'music' || data.domain === 'entertainment') && /歌|唱|音乐|听|播放/.test(text)) return 'music';
      if (data.domain === 'travel') return 'train';
    }
    if (data.type === 'creation' || data.confidence < 0.6) return 'handoff';
    if (data.type === 'chat') return 'chat';
    return 'none';
  }

  return { resolve: resolve, isMusic: isMusic, isTrain: isTrain, isA2A: isA2A, isBrowserSearch: isBrowserSearch };
});
