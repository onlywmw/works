package com.hermes.android.toolprovider;

import android.content.Context;

import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.agent.ToolRegistry.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * ChatMemoryProvider — 对话记忆 + 日志 + 代码搜索 (Dyad 对标: search_chats / read_chat / read_logs / code_search)。
 */
public class ChatMemoryProvider implements ToolProvider {

    private static Context appContext;
    public static void init(Context ctx) { appContext = ctx.getApplicationContext(); }

    @Override public String id() { return "chat-memory"; }

    /** 获取房间 journal 文件 */
    private static File journalFile(String roomId) {
        return new File(appContext.getFilesDir(), "rooms/" + roomId + "/journal.jsonl");
    }

    @Override
    public List<Tool> discover() {
        List<Tool> list = new ArrayList<>();
        if (appContext == null) return list;

        // ═══ search.chats — 搜索对话历史 ═══
        list.add(new Tool("search.chats",
            "搜索当前房间的对话历史（journal.jsonl 全文搜索）。返回匹配行及其上下文",
            null, a -> {
                String query = a.optString("query", "");
                String roomId = a.optString("roomId", "work");
                if (query.isEmpty()) return new Result(false, "搜索词为空");
                int context = a.optInt("context", 1);
                if (context < 0 || context > 5) context = 1;
                int limit = a.optInt("limit", 10);
                if (limit < 1 || limit > 30) limit = 10;
                try {
                    File jf = journalFile(roomId);
                    if (!jf.exists()) return new Result(true, "该房间暂无对话记录");
                    List<String> lines = new ArrayList<>();
                    try (BufferedReader br = new BufferedReader(
                            new InputStreamReader(new FileInputStream(jf), "UTF-8"))) {
                        String line;
                        while ((line = br.readLine()) != null) lines.add(line);
                    }
                    if (lines.isEmpty()) return new Result(true, "对话记录为空");
                    // 简单全文搜索（后续可升级 FTS5）
                    String qLower = query.toLowerCase();
                    List<int[]> hits = new ArrayList<>();
                    for (int i = 0; i < lines.size(); i++) {
                        if (lines.get(i).toLowerCase().contains(qLower)) hits.add(new int[]{i, 0});
                    }
                    if (hits.isEmpty()) return new Result(true, "未找到匹配 '" + query + "'");
                    // 合并相邻命中
                    List<int[]> merged = new ArrayList<>();
                    for (int[] h : hits) {
                        if (!merged.isEmpty() && h[0] <= merged.get(merged.size()-1)[0] + context * 2 + 1) {
                            merged.get(merged.size()-1)[1] = h[0];
                        } else {
                            merged.add(new int[]{Math.max(0, h[0] - context), h[0] + context});
                        }
                    }
                    StringBuilder sb = new StringBuilder("搜索 '" + query + "' (" + hits.size() + " 条匹配):\n");
                    for (int i = 0; i < Math.min(merged.size(), limit); i++) {
                        int[] m = merged.get(i);
                        sb.append("── 匹配 ").append(i + 1).append(" (行 ").append(m[0] + 1).append("-").append(m[1] + 1).append(") ──\n");
                        for (int j = m[0]; j <= m[1] && j < lines.size(); j++) {
                            String l = lines.get(j);
                            if (l.length() > 200) l = l.substring(0, 200) + "…";
                            sb.append(l).append("\n");
                        }
                    }
                    if (merged.size() > limit) sb.append("…(仅显示前 " + limit + " 组，共 " + merged.size() + " 组)\n");
                    return new Result(true, sb.toString());
                } catch (Exception e) {
                    return new Result(false, "搜索失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 10, "system",
            new ParamDef[]{
                new ParamDef("query", "string", true, "", "搜索关键词（大小写不敏感）"),
                new ParamDef("roomId", "string", false, "默认 work", "房间 ID"),
                new ParamDef("context", "int", false, "默认 1", "匹配行前后各显示几行"),
                new ParamDef("limit", "int", false, "默认 10", "最多返回几组"),
            },
            "成功: 匹配行 + 上下文 | 失败: 错误原因",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"search.chats\",\"args\":{\"query\":\"python\",\"context\":2}}"},
            new String[]{"搜索当前房间的 journal.jsonl", "不支持正则（用 shell.exec grep -E）", "每行 >200 字符会被截断"},
            3000,
            new ToolRegistry.Manifest("搜索对话", "low", "搜索对话历史", false, "io"),
            null));

        // ═══ read.chat — 读取对话片段 ═══
        list.add(new Tool("read.chat",
            "按行号范围读取对话记录。先用 search.chats 找到行号，再用本工具读详情",
            null, a -> {
                int from = a.optInt("from", 0);
                int count = a.optInt("count", 20);
                String roomId = a.optString("roomId", "work");
                if (from < 1) return new Result(false, "from 必须 >= 1（行号从 1 开始）");
                if (count < 1 || count > 100) count = 20;
                try {
                    File jf = journalFile(roomId);
                    if (!jf.exists()) return new Result(true, "该房间暂无对话记录");
                    List<String> lines = new ArrayList<>();
                    try (BufferedReader br = new BufferedReader(
                            new InputStreamReader(new FileInputStream(jf), "UTF-8"))) {
                        String line;
                        while ((line = br.readLine()) != null) lines.add(line);
                    }
                    int end = Math.min(from + count - 1, lines.size());
                    StringBuilder sb = new StringBuilder("对话记录 " + from + "-" + end + "/" + lines.size() + ":\n");
                    for (int i = from - 1; i < end; i++) {
                        String l = lines.get(i);
                        if (l.length() > 300) l = l.substring(0, 300) + "…(截断)";
                        sb.append("[").append(i + 1).append("] ").append(l).append("\n");
                    }
                    if (end < from + count - 1) sb.append("—(已到末尾)—\n");
                    else if (end < lines.size()) sb.append("…(用 from=" + (end + 1) + " 继续读)\n");
                    return new Result(true, sb.toString());
                } catch (Exception e) {
                    return new Result(false, "读取失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 5, "system",
            new ParamDef[]{
                new ParamDef("from", "int", true, "", "起始行号（从 1 开始）"),
                new ParamDef("count", "int", false, "默认 20", "读取行数（1-100）"),
                new ParamDef("roomId", "string", false, "默认 work", "房间 ID"),
            },
            "成功: [行号] 内容 | 失败: 错误原因",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"read.chat\",\"args\":{\"from\":42,\"count\":15}}"},
            new String[]{"先用 search.chats 定位行号", "每行 >300 字符会被截断"},
            2000,
            new ToolRegistry.Manifest("读对话", "low", "读取对话片段", false, "io"),
            null));

        // ═══ read.logs — 读取应用日志 ═══
        list.add(new Tool("read.logs",
            "读取 Android logcat 日志（最近 N 行）。用于调试崩溃/报错",
            null, a -> {
                int lines = a.optInt("lines", 100);
                if (lines < 10 || lines > 500) lines = 100;
                String tag = a.optString("tag", "");
                try {
                    List<String> cmd = new ArrayList<>();
                    cmd.add("logcat");
                    cmd.add("-d");
                    cmd.add("-t");
                    cmd.add(String.valueOf(lines));
                    if (!tag.isEmpty()) {
                        // 用 grep 过滤 tag
                        ProcessBuilder pb = new ProcessBuilder("logcat", "-d", "-t", String.valueOf(lines));
                        Process p = pb.start();
                        String out = new String(p.getInputStream().readAllBytes(), "UTF-8");
                        p.waitFor();
                        String[] allLines = out.split("\n");
                        StringBuilder sb = new StringBuilder("logcat (最近 " + lines + " 行, tag=" + tag + "):\n");
                        int n = 0;
                        for (String l : allLines) {
                            if (l.contains(tag)) { sb.append(l).append("\n"); n++; }
                        }
                        if (n == 0) sb.append("(无匹配)\n");
                        return new Result(true, sb.toString());
                    }
                    ProcessBuilder pb = new ProcessBuilder("logcat", "-d", "-t", String.valueOf(lines));
                    Process p = pb.start();
                    String out = new String(p.getInputStream().readAllBytes(), "UTF-8");
                    p.waitFor();
                    if (out.length() > 10000) out = out.substring(out.length() - 10000);
                    return new Result(true, "logcat (最近 " + lines + " 行):\n" + out);
                } catch (Exception e) {
                    return new Result(false, "读取 logcat 失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 10, "system",
            new ParamDef[]{
                new ParamDef("lines", "int", false, "默认 100", "读取行数（10-500）"),
                new ParamDef("tag", "string", false, "", "按 tag 过滤，如 hermes / MOV / AndroidRuntime"),
            },
            "成功: logcat 输出 | 失败: 错误原因",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"read.logs\",\"args\":{\"lines\":200,\"tag\":\"hermes\"}}"},
            new String[]{"需要 shell 执行权限", "输出最多 10KB（截断旧内容）", "用 tag 过滤减少噪音"},
            5000,
            new ToolRegistry.Manifest("读日志", "medium", "读取 logcat 日志", false, "exec"),
            null));

        // ═══ code.search — 代码搜索 ═══
        list.add(new Tool("code.search",
            "在房间文件中搜索代码片段（基于 grep，支持简单正则）",
            null, a -> {
                String query = a.optString("query", "");
                String pattern = a.optString("pattern", "");
                String glob = a.optString("glob", "*.{html,js,css,py,java,kt,ts,json,md,txt}");
                if (query.isEmpty() && pattern.isEmpty()) return new Result(false, "query 或 pattern 至少填一项");
                // 用 shell.exec 执行 grep
                String cmd = "cd /data/data/com.hermes.android/files/rooms/work && grep -rn --include='" + glob + "' "
                    + (pattern.isEmpty() ? "'" + query.replace("'", "'\\''") + "'" : "'" + pattern.replace("'", "'\\''") + "'")
                    + " . 2>/dev/null | head -50";
                // 这个工具在 Java 层实现简单版本
                try {
                    File roomDir = new File(appContext.getFilesDir(), "rooms/work");
                    if (!roomDir.exists()) return new Result(true, "房间目录不存在");
                    StringBuilder sb = new StringBuilder();
                    int n = 0, limit = a.optInt("limit", 30);
                    if (limit < 1 || limit > 100) limit = 30;
                    searchFiles(roomDir, query, pattern, glob, sb, new int[]{n}, limit);
                    if (sb.length() == 0) return new Result(true, "未找到匹配");
                    return new Result(true, sb.toString());
                } catch (Exception e) {
                    return new Result(false, "搜索失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 10, "system",
            new ParamDef[]{
                new ParamDef("query", "string", false, "", "搜索关键词（纯文本匹配，大小写敏感）"),
                new ParamDef("pattern", "string", false, "", "正则表达式（Java 语法）"),
                new ParamDef("glob", "string", false, "默认 *.html,...", "文件过滤，逗号分隔，如 *.java,*.py"),
                new ParamDef("limit", "int", false, "默认 30", "最大返回条数"),
            },
            "成功: 文件:行号: 内容 | 失败: 未找到/错误",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"code.search\",\"args\":{\"query\":\"TODO\",\"glob\":\"*.java\"}}"},
            new String[]{"搜索房间 work 目录", "简单实现（非索引，大项目慢）", "大项目用 shell.exec grep -rn"},
            3000,
            new ToolRegistry.Manifest("代码搜索", "low", "grep 搜索代码", false, "io"),
            null));

        // ═══ generate.image — AI 生图 ═══
        list.add(new Tool("generate.image",
            "AI 生成图片（需配置 AI 服务商 API）。当前引导用 shell.exec + Python",
            null, a -> {
                String prompt = a.optString("prompt", "");
                if (prompt.isEmpty()) return new Result(false, "提示词为空");
                String size = a.optString("size", "1024x1024");
                // 引导 AI 用 shell.exec + curl 调用各种 AI 图片 API
                return new Result(true, "AI 生图方案（选一个）:\n\n"
                    + "1. OpenAI DALL-E:\n"
                    + "   shell.exec 'curl https://api.openai.com/v1/images/generations -H \"Authorization: Bearer $OPENAI_KEY\""
                    + " -H \"Content-Type: application/json\" -d \"{\\\"prompt\\\":\\\"" + prompt.replace("\"", "\\\"") + "\\\",\\\"size\\\":\\\"" + size + "\\\"}\" -o /room/image_response.json'\n\n"
                    + "2. Stable Diffusion (本地):\n"
                    + "   shell.exec 'python3 -c \"from diffusers import StableDiffusionPipeline;"
                    + " pipe = StableDiffusionPipeline.from_pretrained(\\\"runwayml/stable-diffusion-v1-5\\\");"
                    + " pipe(\\\"" + prompt.replace("\"", "\\\"") + "\\\").images[0].save(\\\"/room/generated.png\\\")\"'\n\n"
                    + "3. 免费替代 (Pollinations.ai):\n"
                    + "   shell.exec 'curl \"https://image.pollinations.ai/prompt/" + prompt.replace(" ", "%20") + "?width=1024&height=1024\" -o /room/generated.png'");
            }, "native", "readonly", "none", true, 5, "image",
            new ParamDef[]{
                new ParamDef("prompt", "string", true, "", "图片描述（英文效果更好）"),
                new ParamDef("size", "string", false, "默认 1024x1024", "尺寸，如 512x512 / 1024x1024 / 1792x1024"),
            },
            "引导说明 + shell.exec 命令",
            null,
            new String[]{"需要 API Key（OpenAI）或本地 GPU（SD）", "Pollinations.ai 免费但质量一般", "生成图片 2-30 秒"},
            1000,
            new ToolRegistry.Manifest("AI 生图", "medium", "AI 生成图片", false, "media"),
            null));

        return list;
    }

    /** 递归搜索文件 */
    private static void searchFiles(File dir, String query, String pattern, String glob,
                                     StringBuilder sb, int[] count, int limit) {
        File[] files = dir.listFiles();
        if (files == null) return;
        Pattern p = null;
        if (query != null && !query.isEmpty()) p = Pattern.compile(Pattern.quote(query));
        else if (pattern != null && !pattern.isEmpty()) {
            try { p = Pattern.compile(pattern); } catch (Exception e) { return; }
        }
        if (p == null) return;
        for (File f : files) {
            if (count[0] >= limit) return;
            if (f.isDirectory()) {
                if (f.getName().startsWith(".")) continue; // 跳过隐藏目录
                searchFiles(f, null, null, glob, sb, count, limit, p);
            } else if (matchesGlob(f.getName(), glob)) {
                try {
                    List<String> lines = java.nio.file.Files.readAllLines(f.toPath());
                    for (int i = 0; i < lines.size() && count[0] < limit; i++) {
                        if (p.matcher(lines.get(i)).find()) {
                            String rel = roomRelative(f);
                            sb.append(rel).append(":").append(i + 1).append(": ");
                            String l = lines.get(i).trim();
                            if (l.length() > 150) l = l.substring(0, 150) + "…";
                            sb.append(l).append("\n");
                            count[0]++;
                        }
                    }
                } catch (Exception ignored) {}
            }
        }
    }

    private static void searchFiles(File dir, String query, String pattern, String glob,
                                     StringBuilder sb, int[] count, int limit, Pattern p) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (count[0] >= limit) return;
            if (f.isDirectory()) {
                if (f.getName().startsWith(".")) continue;
                searchFiles(f, null, null, glob, sb, count, limit, p);
            } else if (matchesGlob(f.getName(), glob)) {
                try {
                    List<String> lines = java.nio.file.Files.readAllLines(f.toPath());
                    for (int i = 0; i < lines.size() && count[0] < limit; i++) {
                        if (p.matcher(lines.get(i)).find()) {
                            String rel = roomRelative(f);
                            sb.append(rel).append(":").append(i + 1).append(": ");
                            String l = lines.get(i).trim();
                            if (l.length() > 150) l = l.substring(0, 150) + "…";
                            sb.append(l).append("\n");
                            count[0]++;
                        }
                    }
                } catch (Exception ignored) {}
            }
        }
    }

    private static boolean matchesGlob(String name, String glob) {
        if (glob == null || glob.isEmpty() || "*".equals(glob)) return true;
        for (String g : glob.split(",")) {
            g = g.trim();
            if (g.startsWith("*.")) {
                if (name.endsWith(g.substring(1))) return true;
            } else if (g.startsWith("*")) {
                if (name.contains(g.substring(1))) return true;
            } else if (name.equals(g)) return true;
        }
        return false;
    }

    private static String roomRelative(File f) {
        String abs = f.getAbsolutePath();
        int idx = abs.indexOf("rooms/work");
        return idx >= 0 ? abs.substring(idx) : f.getName();
    }
}
