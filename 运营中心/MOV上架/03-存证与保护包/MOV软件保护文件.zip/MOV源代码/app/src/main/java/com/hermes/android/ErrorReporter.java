package com.hermes.android;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 错误上报 —— 写 errors.jsonl + 导出诊断日志。
 */
public class ErrorReporter {

    private static final String TAG = "MOV-ERR";
    private static final int MAX_LINES = 500;
    private static Context appContext;

    /** Application.onCreate 调用一次, 保存 Context 供静态方法使用 */
    public static void init(Context ctx) { appContext = ctx.getApplicationContext(); }

    public enum Category {
        USER_ERROR, PERMISSION_ERROR, NETWORK_ERROR, AI_ERROR, INTERNAL_ERROR, UNKNOWN
    }

    // ── 采样去重 (ARCH_DEBT #1) ──
    private static String lastExternalCode = null;
    private static int lastExternalCount = 0;

    /** 带采样上报: INTERNAL全报, EXTERNAL按code去重, USER只计数 */
    public static void reportSampled(Category cat, String location, String msg) {
        if (cat == Category.USER_ERROR || cat == Category.PERMISSION_ERROR) {
            Log.w(TAG, cat.name() + "(counted)|" + location + "|" + msg);
            return; // USER 只计数，不写磁盘
        }
        if (cat == Category.NETWORK_ERROR || cat == Category.AI_ERROR) {
            if (msg != null && msg.equals(lastExternalCode)) {
                lastExternalCount++;
                return; // 同 code 去重，只记第一条
            }
            if (lastExternalCode != null && lastExternalCount > 0) {
                // 上一个外部错误收尾：追加一行计数
                appendLine(appContext, "{\"ts\":" + System.currentTimeMillis()
                    + ",\"cat\":\"" + cat.name() + "\",\"loc\":\"DEDUP\",\"msg\":\"x" + lastExternalCount + "\"}");
            }
            lastExternalCode = msg;
            lastExternalCount = 0;
            // fall through to write this first occurrence
        } else {
            // INTERNAL / UNKNOWN: 全量上报
        }
        report(appContext, cat, location, msg);
    }

    /** 同 code 收尾（任务结束时调，把最后一个 EXTERNAL 的去重计数落盘） */
    public static void flushDedup(Context ctx) {
        if (lastExternalCode != null && lastExternalCount > 0) {
            appendLine(ctx, "{\"ts\":" + System.currentTimeMillis()
                + ",\"cat\":\"AI_ERROR\",\"loc\":\"DEDUP\",\"msg\":\"x" + lastExternalCount + "\"}");
            lastExternalCode = null;
            lastExternalCount = 0;
        }
    }

    private static void appendLine(Context ctx, String line) {
        try {
            File f = new File(appContext.getFilesDir(), "errors.jsonl");
            FileWriter fw = new FileWriter(f, true);
            fw.write(line + "\n");
            fw.close();
            trimFile(f, MAX_LINES);
        } catch (Exception e) { Log.w(TAG, "appendLine failed", e); }
    }

    /** 记录错误 */
    public static void report(Context ctx, Category cat, String location, String msg) {
        Log.e(TAG, cat.name() + "|" + location + "|" + msg);
        try {
            File f = new File(appContext.getFilesDir(), "errors.jsonl");
            StringBuilder sb = new StringBuilder();
            sb.append("{\"ts\":").append(System.currentTimeMillis())
              .append(",\"cat\":\"").append(cat.name())
              .append("\",\"loc\":\"").append(location.replace("\"", "'"))
              .append("\",\"msg\":\"").append(msg.replace("\"", "'").replace("\n", " "))
              .append("\"}\n");
            FileWriter fw = new FileWriter(f, true);
            fw.write(sb.toString());
            fw.close();
            // 保留最近 500 行
            trimFile(f, MAX_LINES);
        } catch (Exception e) { Log.w(TAG, "write failed", e); }
    }

    private static void trimFile(File f, int max) {
        try {
            RandomAccessFile raf = new RandomAccessFile(f, "r");
            long len = raf.length();
            if (len == 0) { raf.close(); return; }
            int lines = 0;
            for (long i = len - 1; i >= 0; i--) {
                raf.seek(i);
                if (raf.readByte() == '\n') lines++;
                if (lines >= max) {
                    byte[] tail = new byte[(int)(len - i)];
                    raf.seek(i + 1);
                    raf.readFully(tail);
                    raf.close();
                    FileWriter fw = new FileWriter(f);
                    fw.write(new String(tail, "UTF-8"));
                    fw.close();
                    return;
                }
            }
            raf.close();
        } catch (Exception e) { Log.w(TAG, "write failed", e); }
    }

    /** 清空错误日志 */
    public static void clear(Context ctx) {
        try {
            File f = new File(appContext.getFilesDir(), "errors.jsonl");
            if (f.exists()) f.delete();
        } catch (Exception e) { Log.w(TAG, "clear failed", e); }
    }

    /** 导出诊断日志（调用方在 Activity 中调用） */
    public static void export(Context ctx) {
        try {
            File f = new File(appContext.getFilesDir(), "errors.jsonl");
            StringBuilder sb = new StringBuilder();
            sb.append("MOV v3.3.0\n");
            sb.append("Android ").append(Build.VERSION.SDK_INT).append("\n");
            sb.append(Build.MODEL).append("\n\n");

            // ── 错误日志 (最后 100 行) ──
            int errCount = 0;
            if (f.exists()) {
                String content = new String(java.nio.file.Files.readAllBytes(f.toPath()));
                String[] lines = content.split("\n");
                int start = Math.max(0, lines.length - 100);
                for (int i = start; i < lines.length; i++) { sb.append(lines[i]).append("\n"); errCount++; }
            }

            // ── 决策审计 (journal 中 audit:true 的行, 取最后 200 条) ──
            // 根治单: journal 真理源在 StorageManager 外部目录, 与 AgentLoop/serve 一致
            File roomsDir = new com.hermes.android.StorageManager(appContext).getRoomsDir();
            StringBuilder audit = new StringBuilder();
            int auditCount = 0;
            if (roomsDir.isDirectory()) {
                File[] rooms = roomsDir.listFiles(File::isDirectory);
                if (rooms != null) {
                    // 按房间名排序, 取最近 3 个房间
                    java.util.Arrays.sort(rooms, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                    int roomsScanned = 0;
                    for (File roomDir : rooms) {
                        if (roomsScanned >= 3) break;
                        File jf = new File(roomDir, "journal.jsonl");
                        if (!jf.exists()) continue;
                        roomsScanned++;
                        audit.append("\n── ").append(roomDir.getName()).append(" ──\n");
                        try (java.io.BufferedReader r = new java.io.BufferedReader(
                                new java.io.InputStreamReader(new java.io.FileInputStream(jf), "UTF-8"))) {
                            String line;
                            while ((line = r.readLine()) != null) {
                                if (line.contains("\"audit\":true")) {
                                    // 截断过长的行, 保留前 200 字符
                                    String trimmed = line.length() > 200 ? line.substring(0, 200) + "…" : line;
                                    audit.append(trimmed).append("\n");
                                    auditCount++;
                                }
                            }
                        }
                    }
                }
            }

            // ── 组装 ──
            sb.append("\n────────\n");
            sb.append("错误日志: ").append(errCount).append(" 条 (最近 100)\n");
            sb.append("决策审计: ").append(auditCount).append(" 条 (最近 3 个房间, audit 事件)\n");
            sb.append("────────\n");
            if (auditCount > 0) sb.append(audit);
            else sb.append("\n(无 audit 事件)\n");

            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, sb.toString());
            ctx.startActivity(Intent.createChooser(share, "发送诊断日志"));
        } catch (Exception e) {
            Log.w(TAG, "export failed", e);
        }
    }
}
