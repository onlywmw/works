package com.hermes.android.bridge;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.hermes.android.capability.CapabilityExecutor;
import com.hermes.android.capability.CommandResult;
import com.hermes.android.HermesActivity;
import com.hermes.android.capability.IntentParser;
import com.hermes.android.capability.ParsedCommand;

import org.json.JSONObject;

/**
 * 设备能力 Bridge — 指令执行 + 设备信息 + 权限 + 小组件
 */
public class BridgeDevice extends BaseBridge {

    private final IntentParser parser = new IntentParser();
    private volatile String deviceInfoCache;
    private volatile long deviceInfoCacheTime;
    private static final long DEVICE_CACHE_TTL = 5000;

    public BridgeDevice(HermesActivity activity) {
        super(activity);
    }

    public String parseIntent(String text) {
        try {
            ParsedCommand cmd = parser.parse(text);
            if (cmd != null && !cmd.isError()) {
                return new JSONObject().put("cmd", cmd.getCapability()).toString();
            }
        } catch (Exception ignored) {}
        return "{}";
    }

    public String execCommand(String text) {
        if (text == null || text.trim().isEmpty()) return "{\"ok\":false,\"error\":\"指令为空\"}";
        if (text.length() > 500) return "{\"ok\":false,\"error\":\"指令过长\"}";
        long t0 = System.currentTimeMillis();
        try {
            ParsedCommand cmd = parser.parse(text);
            if (cmd == null) return "无法识别指令: " + text;
            if (cmd.isError()) return cmd.getError();
            CommandResult result = activity.getCapabilityExecutor().execute(activity, cmd);
            android.util.Log.i("MOV", "cmd [" + text + "] " + (result.isSuccess() ? "OK" : "FAIL")
                    + " in " + (System.currentTimeMillis() - t0) + "ms");
            return result.getMessage();
        } catch (SecurityException e) {
            return "权限不足: " + e.getMessage();
        } catch (Exception e) {
            return "执行异常: " + e.getMessage();
        }
    }

    public String getDeviceInfo() {
        long now = System.currentTimeMillis();
        if (deviceInfoCache != null && (now - deviceInfoCacheTime) < DEVICE_CACHE_TTL) {
            return deviceInfoCache;
        }
        try {
            JSONObject o = new JSONObject();
            o.put("pid", android.os.Process.myPid());
            try {
                Intent batt = activity.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (batt != null) {
                    int level = batt.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = batt.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                    if (scale > 0) o.put("batteryLevel", level * 100 / scale);
                    int st = batt.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                    o.put("batteryCharging",
                            st == BatteryManager.BATTERY_STATUS_CHARGING
                                    || st == BatteryManager.BATTERY_STATUS_FULL);
                }
            } catch (Exception ignored) {}
            try {
                WifiManager wm = (WifiManager) activity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                o.put("wifiEnabled", wm.isWifiEnabled());
                WifiInfo info = wm.getConnectionInfo();
                if (info != null && info.getSSID() != null) {
                    o.put("wifiSsid", info.getSSID().replace("\"", ""));
                }
            } catch (Exception ignored) {}
            try {
                o.put("brightness", Settings.System.getInt(
                        activity.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS));
            } catch (Exception ignored) {}
            String result = o.toString();
            deviceInfoCache = result;
            deviceInfoCacheTime = now;
            return result;
        } catch (Exception e) {
            return "{}";
        }
    }

    public String getRuntimeStats() {
        try {
            Runtime rt = Runtime.getRuntime();
            JSONObject o = new JSONObject();
            o.put("pid", android.os.Process.myPid());
            o.put("uptimeMs", android.os.SystemClock.elapsedRealtime()
                    - android.os.Process.getStartElapsedRealtime());
            o.put("memUsedMb", (rt.totalMemory() - rt.freeMemory()) / 1024 / 1024);
            o.put("memMaxMb", rt.maxMemory() / 1024 / 1024);
            o.put("cmdCount", CapabilityExecutor.getCmdCount());
            o.put("lastCmdMs", CapabilityExecutor.getLastCmdMs());
            o.put("lastCmdName", CapabilityExecutor.getLastCmdName());
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public String getPermissionState() {
        try {
            JSONObject o = new JSONObject();
            String[][] perms = {
                {"CAMERA", Manifest.permission.CAMERA},
                {"LOCATION", Manifest.permission.ACCESS_FINE_LOCATION},
                {"CONTACTS", Manifest.permission.READ_CONTACTS},
                {"SMS", Manifest.permission.READ_SMS},
                {"CALL", Manifest.permission.CALL_PHONE},
                {"NOTIFY", Build.VERSION.SDK_INT >= 33
                        ? Manifest.permission.POST_NOTIFICATIONS : null},
            };
            for (String[] p : perms) {
                if (p[1] == null) { o.put(p[0], true); continue; }
                o.put(p[0], ContextCompat.checkSelfPermission(
                        activity, p[1]) == PackageManager.PERMISSION_GRANTED);
            }
            o.put("SETTINGS", Settings.System.canWrite(activity));
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public String getWidgetInfo() {
        try {
            android.appwidget.AppWidgetManager mgr =
                    android.appwidget.AppWidgetManager.getInstance(activity);
            int[] ids = mgr.getAppWidgetIds(new android.content.ComponentName(
                    activity, com.hermes.android.widget.HermesWidgetProvider.class));
            return new JSONObject().put("count", ids != null ? ids.length : 0).toString();
        } catch (Exception e) {
            return "{\"count\":0}";
        }
    }

    public void openAppSettings() {
        activity.runOnUiThread(() -> {
            try {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(Uri.parse("package:" + activity.getPackageName()));
                activity.startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(activity, "无法打开设置页", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** TC-M09: 系统浏览器打开 URL (如"获取 API Key"控制台页) — 仅 http/https, 其余 scheme 拒绝 */
    public void openUrl(String url) {
        activity.runOnUiThread(() -> {
            try {
                if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) {
                    Toast.makeText(activity, "链接无效", Toast.LENGTH_SHORT).show();
                    return;
                }
                activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception e) {
                Toast.makeText(activity, "无法打开链接", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** 视频平台 deep link 允许的 scheme 白名单（不可外部扩展） */
    private static final java.util.Set<String> DEEP_LINK_SCHEMES = new java.util.HashSet<>(
            java.util.Arrays.asList("tenvideo2", "bilibili", "iqiyi"));

    /**
     * 打开平台 deep link（如 tenvideo2://search?keyword=X）。
     * scheme 必须命中白名单；intent 能被解析才启动，返回 {"ok":true/false} 供 JS 降级。
     */
    public String openDeepLink(String url, String pkg) {
        try {
            if (url == null) return errJson("链接为空");
            String scheme = Uri.parse(url).getScheme();
            if (scheme == null || !DEEP_LINK_SCHEMES.contains(scheme)) {
                return errJson("scheme 不允许: " + scheme);
            }
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            if (pkg != null && !pkg.isEmpty()) intent.setPackage(pkg);
            /* 不用 resolveActivity 预检: Android 11+ 包可见性会误报 null;
               显式 setPackage 的 startActivity 不受可见性限制, 直接试, 失败走降级 */
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                activity.startActivity(intent);
                return "{\"ok\":true}";
            } catch (android.content.ActivityNotFoundException nf) {
                return errJson("无可处理的应用");
            }
        } catch (Exception e) {
            return errJson(e.getMessage());
        }
    }

    private String errJson(String msg) {
        try {
            return new org.json.JSONObject().put("ok", false).put("error", msg == null ? "失败" : msg).toString();
        } catch (org.json.JSONException e) {
            return "{\"ok\":false}";
        }
    }

    /** 抖音会话是否已连接（sessionid 系 cookie 存在） */
    public String douyinStatus() {
        try {
            return new org.json.JSONObject().put("ok", true)
                    .put("connected", com.hermes.android.ConnectWebActivity.hasSession("douyin")).toString();
        } catch (org.json.JSONException e) {
            return "{\"ok\":false}";
        }
    }

    /** 打开抖音登录容器（扫码一次，长期免登录） */
    public void openDouyinLogin() {
        activity.runOnUiThread(() -> {
            try {
                android.content.Intent i = new android.content.Intent(activity, com.hermes.android.DouyinWebActivity.class);
                i.putExtra("mode", "login");
                i.putExtra("url", "https://www.douyin.com/");
                activity.startActivity(i);
            } catch (Exception ignored) {}
        });
    }

    /** 打开抖音搜索页（向后兼容，委托 connectSearch） */
    public void openDouyinSearch(String keyword) { openConnectSearch("douyin", keyword); }

    // ==================== 通用连接（Phase P1 Round2） ====================

    // ══════ STT/TTS（三合一） ══════

    public String startSTT(String cbId) {
        activity.runOnUiThread(() -> {
            try {
                android.content.Intent i = new android.content.Intent(
                    android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "说一句话…");
                /* W4: 9002 避开 PaymentGate 9001; 结果走 HermesActivity.onActivityResult 回 _hermesCb */
                ((android.app.Activity)activity).startActivityForResult(i, 9002);
            } catch (Exception e) {
                activity.evalJsPublic("window._hermesCb('" + cbId + "',{ok:false,error:'no_speech_engine'})");
            }
        });
        return "{\"ok\":true}";
    }

    public void speakText(String text) {
        if (text == null || text.isEmpty()) return;
        final String t = text;
        activity.runOnUiThread(() -> {
            try {
                final android.speech.tts.TextToSpeech[] holder = new android.speech.tts.TextToSpeech[1];
                holder[0] = new android.speech.tts.TextToSpeech(
                    activity, status -> {
                        if (status == android.speech.tts.TextToSpeech.SUCCESS && holder[0] != null) {
                            holder[0].setLanguage(java.util.Locale.CHINESE);
                            holder[0].speak(t, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "mov_tts");
                        }
                    });
            } catch (Exception ignored) {}
        });
    }

    /** 检测平台会话状态 */
    public String connectStatus(String platform) {
        try {
            return new org.json.JSONObject().put("ok", true)
                    .put("connected", com.hermes.android.ConnectWebActivity.hasSession(platform)).toString();
        } catch (org.json.JSONException e) {
            return "{\"ok\":false}";
        }
    }

    /** 启动 ConnectWeb：优先 app context + NEW_TASK（防 activity.runOnUiThread 失效 → 兜底系统浏览器），失败回退 activity 路径 */
    private void launchConnect(android.content.Intent i) {
        android.content.Context ctx = com.hermes.android.HermesApplication.getAppContext();
        if (ctx != null) {
            try {
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(i);
                return;
            } catch (Exception ignored) {}
        }
        try {
            final android.content.Intent fi = i;
            activity.runOnUiThread(() -> {
                try { activity.startActivity(fi); } catch (Exception ignored) {}
            });
        } catch (Exception ignored) {}
    }

    public void openConnectLogin(String platform) {
        android.content.Intent i = new android.content.Intent(activity, com.hermes.android.ConnectWebActivity.class);
        i.putExtra("platform", platform);
        i.putExtra("mode", "login");
        launchConnect(i);
    }

    /** 直接用 ConnectWeb 打开指定 URL（蚂蚁影视等详情页）——追剧一键观看 app 内（防跳转生效前提） */
    public void openConnectUrl(String url, String title) {
        android.content.Intent i = new android.content.Intent(activity, com.hermes.android.ConnectWebActivity.class);
        i.putExtra("platform", "tencent");
        i.putExtra("url", url);
        i.putExtra("title", title != null ? title : "");
        launchConnect(i);
    }

    public void openConnectSearch(String platform, String keyword) {
        android.content.Intent i = new android.content.Intent(activity, com.hermes.android.ConnectWebActivity.class);
        i.putExtra("platform", platform);
        i.putExtra("mode", "search");
        i.putExtra("keyword", keyword != null ? keyword : "");
        launchConnect(i);
    }

    /** 清除指定平台登录态（过期关键 cookie 键，使 ConnectWebActivity.hasSession 归 false） */
    public String removeCookies(String platform) {
        try {
            android.webkit.CookieManager cm = android.webkit.CookieManager.getInstance();
            if ("douyin".equals(platform)) {
                cm.setCookie("www.douyin.com", "sessionid=; Max-Age=0; expires=Thu, 01 Jan 1970 00:00:00 GMT");
                cm.setCookie("www.douyin.com", "sid_tt=; Max-Age=0; expires=Thu, 01 Jan 1970 00:00:00 GMT");
            } else if ("tencent".equals(platform)) {
                cm.setCookie("m.v.qq.com", "vqq_access_token=; Max-Age=0; expires=Thu, 01 Jan 1970 00:00:00 GMT");
                cm.setCookie("m.v.qq.com", "vqq_vuserid=; Max-Age=0; expires=Thu, 01 Jan 1970 00:00:00 GMT");
            } else {
                return "{\"ok\":false,\"error\":\"未知平台\"}";
            }
            cm.flush();
            return "{\"ok\":true}";
        } catch (Exception e) {
            return "{\"ok\":false,\"error\":\"" + e.getMessage() + "\"}";
        }
    }

    /** 内嵌打开任意 URL（ConnectWeb，不跳系统浏览器） */
    public void openConnectUrl(String url) {
        activity.runOnUiThread(() -> {
            try {
                android.content.Intent i = new android.content.Intent(activity, com.hermes.android.ConnectWebActivity.class);
                i.putExtra("url", url);
                activity.startActivity(i);
            } catch (Exception ignored) {}
        });
    }

    public void openLocalPlayer(String path, String title) {
        activity.runOnUiThread(() -> {
            try {
                android.content.Intent i = new android.content.Intent(activity, com.hermes.android.LocalPlayerActivity.class);
                i.putExtra("path", path);
                i.putExtra("title", title);
                activity.startActivity(i);
            } catch (Exception ignored) {}
        });
    }
}
