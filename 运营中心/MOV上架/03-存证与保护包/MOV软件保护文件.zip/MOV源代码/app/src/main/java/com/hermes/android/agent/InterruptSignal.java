package com.hermes.android.agent;

import android.util.Log;

/**
 * InterruptSignal — 工具级中断信号 (TOOL_ENV_UPGRADE Phase 8)。
 *
 * 工具执行时注册进程/ApiCall, 用户停止或超时时 kill 进程组 + 取消 API 调用。
 */
public class InterruptSignal {

    private volatile boolean interrupted = false;
    private Process activeProcess;      // shell.exec 的进程引用

    public void interrupt() {
        interrupted = true;
        if (activeProcess != null) killProcessGroup(activeProcess);
    }

    public boolean isInterrupted() { return interrupted; }

    public void registerProcess(Process p) { activeProcess = p; }
    public void unregisterProcess() { activeProcess = null; }

    /** setsid 起进程组后，kill -TERM -pgid 绞杀整个进程组，防子进程变孤儿 */
    private static void killProcessGroup(Process p) {
        try {
            // Android Process 没有 pid(), 反射取
            java.lang.reflect.Field f = p.getClass().getDeclaredField("pid");
            f.setAccessible(true);
            int pid = f.getInt(p);
            Runtime.getRuntime().exec(new String[]{"kill", "-TERM", "-" + pid});
            if (!p.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)) {
                Runtime.getRuntime().exec(new String[]{"kill", "-KILL", "-" + pid});
                p.destroyForcibly();
            }
        } catch (Exception e) {
            p.destroyForcibly();
        }
    }
}
