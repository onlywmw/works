package com.hermes.android.mcp;

import io.modelcontextprotocol.json.McpJsonMapper;
import io.modelcontextprotocol.json.McpJsonMapperSupplier;

/** MCP Java SDK 的 JSON 提供者 Supplier（Jackson 2），经 META-INF/services 注册。 */
public class Jackson2McpJsonMapperSupplier implements McpJsonMapperSupplier {
    @Override public McpJsonMapper get() { return new Jackson2McpJsonMapper(); }
}
