/* ============================================================
   bridge.js — 原生桥 + 全局错误边界
   ============================================================ */

/* P0-1: 异步回调注册表 */
var _cbId=0,_cbMap={};
window._hermesCb=function(id,data){var fn=_cbMap[id];if(fn){delete _cbMap[id];fn(data);}};
function nextCbId(){return 'cb'+(++_cbId)+'_'+Date.now();}

var B=(function(){
  var b=window.HermesBridge||null;
  return {
    present:b||null,
    cmd:function(c){try{return b?b.execCommand(c):'';}catch(e){return '';}},
    /* 本地视频内嵌播放（LocalPlayerActivity） */
    openLocalPlayer:function(path,title){try{if(b&&b.openLocalPlayer)b.openLocalPlayer(path,title||'');}catch(e){}},
    openConnectUrl:function(url,title){try{if(b&&b.openConnectUrl)b.openConnectUrl(url,title||'');}catch(e){if(b&&b.openUrl)b.openUrl(url);}},
    parse:function(t){try{return b?JSON.parse(b.parseIntent(t)):{};}catch(e){return {};}},
    ai:function(t){try{return b?b.aiChat(t):'';}catch(e){return '';}},
    /* P0-1: 异步 AI */
    aiAsync:function(t,cb){if(!b){cb({ok:false,content:'浏览器演示模式'});return;}var id=nextCbId();_cbMap[id]=cb;b.aiChatAsync(t,id,(typeof curRoomId!=='undefined'?curRoomId:''));},
    /* Phase 2A.2: 异步意图分类（照 aiAsync cbId 模式） */
    intentClassifyAsync:function(t,cb){if(!b||!b.intentClassifyAsync){cb({ok:false,error:{code:'BRIDGE_UNAVAILABLE',msg:'桥不可用'}});return;}var id=nextCbId();_cbMap[id]=cb;b.intentClassifyAsync(t,id);},
    /* Phase 2C.2: 异步追剧搜索（照 intentClassifyAsync cbId 模式） */
    faceSearchDramaAsync:function(q,cb){if(!b||!b.faceSearchDramaAsync){cb({ok:false,error:{code:'BRIDGE_UNAVAILABLE',msg:'桥不可用'}});return;}var id=nextCbId();_cbMap[id]=cb;b.faceSearchDramaAsync(q,id);},
    /* DESIGN_NEW_ROOM v2: 单聊房按房间绑定模型对话 */
    aiChatWithModel:function(t,modelId,cb){if(!b){cb({ok:false,content:'浏览器演示模式'});return;}var id=nextCbId();_cbMap[id]=cb;b.aiChatWithModel(t,modelId||'',id,(typeof curRoomId!=='undefined'?curRoomId:''));},
    /* DESIGN_AGENT_LOOP: agentic 循环 (modelIds = 房间 AI 成员) */
    agentStart:function(goal,roomId,modelIds,cb){if(!b){cb({ok:false,error:'浏览器演示模式'});return;}var id=nextCbId();_cbMap[id]=cb;b.agentStart(goal,roomId,JSON.stringify(modelIds||[]),id);},
    agentStop:function(loopId){try{if(b)b.agentStop(loopId);}catch(e){}},
    agentAnswer:function(loopId,text){try{if(b)b.agentAnswer(loopId,text);}catch(e){}},
    agentPlanRespond:function(loopId,approved,note){try{if(b)b.agentPlanRespond(loopId,approved,note||'');}catch(e){}},
    /* P1: 写盘前预览确认/驳回 */
    agentFileWriteRespond:function(loopId,approved){try{if(b)b.agentFileWriteRespond(loopId,approved);}catch(e){}},
    /* 计划外 shell.exec 确认/驳回 */
    agentShellRespond:function(loopId,approved){try{if(b)b.agentShellRespond(loopId,approved);}catch(e){}},
    /* 暂停卡续跑/放弃 */
    agentResume:function(loopId,approved){try{if(b)b.agentResume(loopId,approved);}catch(e){}},
    aiInfo:function(){try{return b?JSON.parse(b.getAiInfo()):{enabled:false,configured:false};}catch(e){return {enabled:false,configured:false};}},
    device:function(){try{return b?JSON.parse(b.getDeviceInfo()):{};}catch(e){return {};}},
    toast:function(m){try{if(b)b.toast(m);}catch(e){}},
    /* 派单№9: openSettings 已删 (原生设置页退役, 系统级设置迁新脸抽屉技术区块) */
    /* W4: 语音输入 — 触发系统 RecognizerIntent, 结果走 window._movStt (HermesActivity 9002) */
    startSTT:function(){try{if(b)b.startSTT('stt');}catch(e){}},
    /* M3: 交互式终端 */
    openTerminal:function(){try{if(b)b.openTerminal();}catch(e){}},
    /* 内嵌 Hermes: 安装/重装 + 状态 */
    hermesInstall:function(){try{return b?JSON.parse(b.hermesInstall()):{ok:false};}catch(e){return {ok:false};}},
    hermesStatus:function(){try{return b?JSON.parse(b.hermesStatus()):{ready:false};}catch(e){return {ready:false};}},
    /* M4: 部署服务器配置 */
    getDeployConfig:function(){try{return b?JSON.parse(b.getDeployConfig()):{configured:false};}catch(e){return {configured:false};}},
    saveDeployConfig:function(o){try{return b?JSON.parse(b.saveDeployConfig(JSON.stringify(o))):{ok:false};}catch(e){return {ok:false};}},
    testDeployConnection:function(cb){if(!b){cb({ok:false,content:'浏览器演示模式'});return;}var id=nextCbId();_cbMap[id]=cb;b.testDeployConnection(id);},
    /* M-ARCH-ENV: 房间环境初始化/读取 */
    prepareRoomEnv:function(roomId,cb){if(!b){cb({ok:false,error:'浏览器演示模式'});return;}var id=nextCbId();_cbMap[id]=cb;b.prepareRoomEnv(roomId,id);},
    getRoomEnv:function(roomId){try{return b?JSON.parse(b.getRoomEnv(roomId)):{ok:false};}catch(e){return {ok:false};}},
    /* P1-7: 技能 */
    listSkills:function(){try{return b?JSON.parse(b.listSkills()):[];}catch(e){return [];}},
    addSkill:function(skillJson){try{return b?JSON.parse(b.addSkill(skillJson)):{ok:false,error:'桥不可用'};}catch(e){return {ok:false,error:String(e)};}},
    promoteReadySkills:function(){try{return b?JSON.parse(b.promoteReadySkills()):[];}catch(e){return [];}},
    recordSkill:function(id){try{if(b)b.recordSkillUse(id);}catch(e){}},
    deleteSkill:function(id){try{return b?JSON.parse(b.deleteSkill(id)):{ok:false};}catch(e){return {ok:false};}},
    /* 房间文件操作 */
    writeFile:function(rid,path,content){try{return b?JSON.parse(b.writeFile(rid,path,content)):{ok:false};}catch(e){return {ok:false};}},
    readFile:function(rid,path){try{return b?JSON.parse(b.readFile(rid,path)):{ok:false};}catch(e){return {ok:false};}},
    deleteFile:function(rid,path){try{return b?JSON.parse(b.deleteFile(rid,path)):{ok:false};}catch(e){return {ok:false};}},
    listRoomFiles:function(rid,sub){try{return b?JSON.parse(b.listRoomFiles(rid,sub||'')):{ok:false,files:[]};}catch(e){return {ok:false,files:[]};}},
    initRoom:function(rid,name,desc,members){try{return b?JSON.parse(b.initRoom(rid,name,desc,JSON.stringify(members))):{ok:false};}catch(e){return {ok:false};}},
    /* 存储系统 */
    listWorkFiles:function(rid){try{return b?JSON.parse(b.listWorkFiles(rid)):{ok:false,files:[]};}catch(e){return {ok:false,files:[]};}},
    saveWorkFile:function(rid,path,content,author){try{return b?JSON.parse(b.saveWorkFile(rid,path,content,author||'you')):{ok:false};}catch(e){return {ok:false};}},
    listVersions:function(rid,path){try{return b?JSON.parse(b.listVersions(rid,path)):{ok:false,versions:[]};}catch(e){return {ok:false,versions:[]};}},
    restoreVersion:function(rid,path,snap){try{return b?JSON.parse(b.restoreVersion(rid,path,snap)):{ok:false};}catch(e){return {ok:false};}},
    listInboxFiles:function(rid){try{return b?JSON.parse(b.listInboxFiles(rid)):{ok:false,files:[]};}catch(e){return {ok:false,files:[]};}},
    listArchiveFiles:function(rid){try{return b?JSON.parse(b.listArchiveFiles(rid)):{ok:false,sources:[]};}catch(e){return {ok:false,sources:[]};}},
    writeArchive:function(rid,source,content){try{return b?JSON.parse(b.writeArchive(rid,source,content)):{ok:false};}catch(e){return {ok:false};}},
    listNotes:function(){try{return b?JSON.parse(b.listNotes()):{ok:false,files:[]};}catch(e){return {ok:false,files:[]};}},
    saveNote:function(name,content){try{return b?JSON.parse(b.saveNote(name,content)):{ok:false};}catch(e){return {ok:false};}},
    readNote:function(name){try{return b?JSON.parse(b.readNote(name)):{ok:false};}catch(e){return {ok:false};}},
    deleteNote:function(name){try{return b?JSON.parse(b.deleteNote(name)):{ok:false};}catch(e){return {ok:false};}},
    initRoomStorage:function(rid){try{if(b)b.initRoomStorage(rid);}catch(e){}},
    getRoomMeta:function(rid){try{return b?JSON.parse(b.getRoomMeta(rid)):{ok:true,files:[]};}catch(e){return {ok:true,files:[]};}},
    deleteWorkFile:function(rid,path){try{return b?JSON.parse(b.deleteWorkFile(rid,path)):{ok:false};}catch(e){return {ok:false};}},
    deleteInboxFile:function(rid,path){try{return b?JSON.parse(b.deleteInboxFile(rid,path)):{ok:false};}catch(e){return {ok:false};}},
    deleteArchiveFile:function(rid,path){try{return b?JSON.parse(b.deleteArchiveFile(rid,path)):{ok:false};}catch(e){return {ok:false};}},
    /* P5 契约对齐 (TASKS_P5_VAULT §四): 保险柜 — cbId 异步, 桥未就绪时诚实降级, 不假装能开 */
    vaultList:function(cb){if(!b||!b.vaultList){cb({ok:false,error:{code:'BRIDGE_UNAVAILABLE',msg:'保险柜桥未就绪'}});return;}var id=nextCbId();_cbMap[id]=cb;b.vaultList(id);},
    vaultLock:function(name,text,cb){if(!b||!b.vaultLock){cb({ok:false,error:{code:'BRIDGE_UNAVAILABLE',msg:'保险柜桥未就绪'}});return;}var id=nextCbId();_cbMap[id]=cb;b.vaultLock(name||'',text||'',id);},
    vaultUnlock:function(id,cb){if(!b||!b.vaultUnlock){cb({ok:false,error:{code:'BRIDGE_UNAVAILABLE',msg:'保险柜桥未就绪'}});return;}var cid=nextCbId();_cbMap[cid]=cb;b.vaultUnlock(id||'',cid);},
    vaultDelete:function(id,cb){if(!b||!b.vaultDelete){cb({ok:false,error:{code:'BRIDGE_UNAVAILABLE',msg:'保险柜桥未就绪'}});return;}var cid=nextCbId();_cbMap[cid]=cb;b.vaultDelete(id||'',cid);},
    appendChat:function(rid,msg){try{if(b)b.appendChatMessage(rid,JSON.stringify(msg));}catch(e){}},
    loadChat:function(rid,date){try{return b?JSON.parse(b.loadChatMessages(rid,date)):{ok:true,messages:[]};}catch(e){return {ok:true,messages:[]};}},
    /* P1-8: 文件选择 */
    pickFile:function(cb,roomId){if(!b){cb(null);return;}var id=nextCbId();_cbMap[id]=cb;b.pickFile(id,roomId||'');},
    /* 发送到桌面: 产出文件固定桌面快捷方式 (CONTRACT_STORAGE 发送到桌面 §) */
    pinFileShortcut:function(rid,path,label){try{return b&&b.pinFileShortcut?JSON.parse(b.pinFileShortcut(rid,path,label||'')):{ok:false,error:'桥不可用'};}catch(e){return {ok:false,error:String(e)};}},
    /* 打包成应用: HTML → 签名 APK 并调起系统安装器 (CONTRACT_STORAGE 打包成应用 §); 异步回调 */
    buildApk:function(rid,path,appName,cb){if(!b||!b.buildApk){cb({ok:false,error:'桥不可用'});return;}var id=nextCbId();_cbMap[id]=cb;b.buildApk(rid,path,appName||'',id);},
    /* 一键安装: 房间产出 APK → 系统安装器 */
    installApk:function(rid,path){try{return b?JSON.parse(b.installApk(rid,path)):{ok:false};}catch(e){return {ok:false};}},
    /* RUNTIME 真数据 */
    runtimeStats:function(){try{return b?JSON.parse(b.getRuntimeStats()):{};}catch(e){return {};}},
    permState:function(){try{return b?JSON.parse(b.getPermissionState()):{};}catch(e){return {};}},
    widgetInfo:function(){try{return b?JSON.parse(b.getWidgetInfo()):{count:0};}catch(e){return {count:0};}},
    openAppSettings:function(){try{if(b)b.openAppSettings();}catch(e){}},
    /* TC-M09: 系统浏览器打开 URL (如"获取 API Key"控制台页); 原生侧 http/https 白名单 */
    openUrl:function(u){try{if(b&&b.openUrl)b.openUrl(u);}catch(e){}},
    openDeepLink:function(u,p){try{return b&&b.openDeepLink?JSON.parse(b.openDeepLink(u,p||'')):{ok:false};}catch(e){return {ok:false};}},
    douyinStatus:function(){try{return b&&b.douyinStatus?JSON.parse(b.douyinStatus()):{ok:false,connected:false};}catch(e){return {ok:false,connected:false};}},
    openDouyinLogin:function(){try{if(b&&b.openDouyinLogin)b.openDouyinLogin();}catch(e){}},
    openDouyinSearch:function(k){try{if(b&&b.openDouyinSearch)b.openDouyinSearch(k);}catch(e){}},
    /* Phase P1 Round2: 通用连接桥 */
    connectStatus:function(p){try{return b&&b.connectStatus?JSON.parse(b.connectStatus(p)):{ok:false,connected:false};}catch(e){return {ok:false,connected:false};}},
    openConnectLogin:function(p){try{if(b&&b.openConnectLogin)b.openConnectLogin(p);}catch(e){}},
    openConnectSearch:function(p,k){try{if(b&&b.openConnectSearch)b.openConnectSearch(p,k);}catch(e){}},
    removeCookies:function(p){try{return b&&b.removeCookies?JSON.parse(b.removeCookies(p)):{ok:false};}catch(e){return {ok:false};}},
    openConnectUrl:function(url,title){try{if(b&&b.openConnectUrl)b.openConnectUrl(url,title||'');}catch(e){}},
    /* R3-3c: 浏览器动作（cbId 异步） */
    browserAction:function(action,cb){if(!b||!b.browserAction){cb({error:'browser_not_open'});return;}var id=nextCbId();_cbMap[id]=cb;b.browserAction(JSON.stringify(action),id);},
    /* A2A 买家侧真桥（BridgeA2a，cbId 异步）。window.__A2A_MOCK=1 回退 mock */
    a2aPeers:function(cb){
      if(window.__A2A_MOCK){cb([{deviceId:'shop_wang',name:'老王盖浇饭'},{deviceId:'shop_li',name:'李记小炒'}]);return;}
      var id=nextCbId();_cbMap[id]=function(r){cb((r&&r.ok&&r.peers)?r.peers:[]);};
      if(b&&b.a2aPeers)b.a2aPeers(id);else cb([]);},
    a2aGetMenu:function(peerId,cb){
      if(window.__A2A_MOCK){cb({items:[{id:'1',name:'红烧肉盖浇饭',price:18,stock:10},{id:'2',name:'宫保鸡丁盖浇饭',price:16,stock:5},{id:'3',name:'紫菜蛋花汤',price:5,stock:20}]});return;}
      // 真世界: 发 get_menu → poll 等 menu 回复
      var id=nextCbId();_cbMap[id]=function(r){cb(r&&r.ok?null:{error:'send_failed'});};
      if(b&&b.a2aSend)b.a2aSend(peerId,'get_menu','{}',id);
      // 菜单回复通过 _a2aMsg 回调（非此 cb）
    },
    a2aOrder:function(peerId,items,note,cb){
      if(window.__A2A_MOCK){cb({orderId:'ord_'+Date.now(),total:items.reduce(function(s,i){return s+(i.qty||1)*(i.price||0);},0),status:'ordered'});return;}
      var id=nextCbId();_cbMap[id]=function(r){cb(r&&r.ok?{orderId:'ord_'+Date.now(),status:'ordered'}:{error:'send_failed'});};
      var payload={items:items,note:note||''};
      if(b&&b.a2aSend)b.a2aSend(peerId,'order',JSON.stringify(payload),id);else cb({error:'bridge_unavailable'});
    },
    a2aPairRequest:function(cb){
      if(window.__A2A_MOCK){cb({pairCode:String(Math.floor(100000+Math.random()*900000))});return;}
      var id=nextCbId();_cbMap[id]=function(r){cb(r&&r.ok?{pairCode:r.code}:{error:r&&r.error});};
      if(b&&b.a2aPairRequest)b.a2aPairRequest(id);else cb({error:'bridge_unavailable'});
    },
    a2aPairAccept:function(code,cb){
      if(window.__A2A_MOCK){cb({peer:{deviceId:'shop_wang',name:'老王盖浇饭'}});return;}
      var id=nextCbId();_cbMap[id]=function(r){cb(r&&r.ok?{peer:r.peer}:{error:r&&r.error});};
      if(b&&b.a2aPairAccept)b.a2aPairAccept(code,id);else cb({error:'bridge_unavailable'});
    },
    a2aGetRelay:function(){try{return b&&b.a2aGetRelay?b.a2aGetRelay():'https://mow.kim';}catch(e){return 'https://mow.kim';}},
    a2aSetRelay:function(url){try{if(b&&b.a2aSetRelay)b.a2aSetRelay(url||'');}catch(e){}},
    a2aStartPolling:function(){if(!window.__A2A_MOCK&&b&&b.a2aStartPolling)b.a2aStartPolling();},
    a2aStopPolling:function(){if(!window.__A2A_MOCK&&b&&b.a2aStopPolling)b.a2aStopPolling();},
    a2aRegistered:function(){return window.__A2A_MOCK?true:!!(b&&b.a2aRegistered&&b.a2aRegistered());},
    a2aRegister:function(deviceId,name,cb,role,professions){
      if(window.__A2A_MOCK){cb({ok:true});return;}
      var id=nextCbId();_cbMap[id]=function(r){cb(r&&r.ok?{ok:true}:{error:r&&r.error});};
      if(b&&b.a2aRegister){
        if(role||professions)b.a2aRegisterPro(deviceId,name,role||'',professions?JSON.stringify(professions):'',id);
        else b.a2aRegister(deviceId,name,id);
      } else cb({error:'bridge_unavailable'});
    },
    wfRunManual:function(workflowId){try{if(b&&b.wfRunManual)b.wfRunManual(workflowId);}catch(e){}},
    ocrChat:function(text,cb){
      var id=nextCbId();_cbMap[id]=function(r){cb(r&&r.ok?{content:r.content}:{error:r&&r.error});};
      if(b&&b.ocrChat)b.ocrChat(text||'',id);else cb({error:'bridge_unavailable'});
    },
    listLocalModels:function(){try{return b&&b.listLocalModels?JSON.parse(b.listLocalModels()):{ok:true,models:[]};}catch(e){return {ok:true,models:[]};}},
    deleteLocalModel:function(name){try{return b&&b.deleteLocalModel?JSON.parse(b.deleteLocalModel(name)):{ok:false};}catch(e){return {ok:false};}},
    a2aQueryPro:function(craft,radiusKm,online,cb){
      if(window.__A2A_MOCK){cb({devices:[{deviceId:'shop_wang',name:'老王盖浇饭'}]});return;}
      var id=nextCbId();_cbMap[id]=function(r){cb(r&&r.ok?{devices:r.devices}:{error:r&&r.error});};
      if(b&&b.a2aQueryPro)b.a2aQueryPro(craft||'',radiusKm||0,!!online,id);else cb({error:'bridge_unavailable'});
    },
    /* 保存 base64 图片到相册（收款码用） */
    saveImageBase64:function(b64){try{if(b&&b.saveImageBase64)b.saveImageBase64(b64);}catch(e){}},
    /* 观看历史（任务H：WatchBridge → filesDir/watch_history.json） */
    watchHistory:function(){try{var r=B.query({q:'watch_history'});return(r&&r.ok&&r.data)?r.data:{};}catch(e){return {};}},
    /* 兜底 sync 方法（兼容旧调用，仅 mock 用） */
    a2aPoll:function(peerId){return window.__A2A_MOCK?[{id:1,type:'confirm',payload:{orderId:'ord_123',status:'confirmed',pay_link:'wxp://f2f0...盖浇饭¥18',total:18,payee:'老王盖浇饭'}}]:[];},
    a2aSend:function(toId,type,payload,cb){
      if(window.__A2A_MOCK){cb({ok:true});return;}
      var id=nextCbId();_cbMap[id]=function(r){cb(r&&r.ok?{ok:true}:{error:r&&r.error});};
      var pj=typeof payload==='string'?payload:JSON.stringify(payload||{});
      if(b&&b.a2aSend)b.a2aSend(toId,type,pj,id);else cb({error:'bridge_unavailable'});
    },
    /* 多模型管理 (DESIGN_MULTI_MODEL 第1层) */
    listModels:function(){try{return b?JSON.parse(b.listModels()):[];}catch(e){return [];}},
    /* 厂商预设 (ModelPresets · "添加模型只填 API Key"): key/displayName/baseUrl/defaultModel/models/keyConsoleUrl/note */
    providerPresets:function(){try{return b&&b.getProviderPresets?JSON.parse(b.getProviderPresets()):[];}catch(e){return [];}},
    addModel:function(json){try{return b?JSON.parse(b.addModel(typeof json==='string'?json:JSON.stringify(json))):{ok:false};}catch(e){return {ok:false};}},
    updateModel:function(json){try{return b?JSON.parse(b.updateModel(typeof json==='string'?json:JSON.stringify(json))):{ok:false};}catch(e){return {ok:false};}},
    deleteModel:function(id){try{return b?JSON.parse(b.deleteModel(id)):{ok:false};}catch(e){return {ok:false};}},
    testModel:function(json,cb){if(!b){cb({ok:false,error:'浏览器演示模式'});return;}var id=nextCbId();_cbMap[id]=cb;b.testModel(typeof json==='string'?json:JSON.stringify(json),id);},
    setDefaultModel:function(id){try{return b?JSON.parse(b.setDefaultModel(id)):{ok:false};}catch(e){return {ok:false};}},
    /* V5: Token 仪表盘 */
    tokenStats:function(){try{return b?JSON.parse(b.getTokenStats()):{today:0,month:0,quota:5000000};}catch(e){return {today:0,month:0,quota:5000000};}},
    /* 加密状态检查 */
    encStatus:function(){try{return b?JSON.parse(b.getEncStatus()):{ok:true};}catch(e){return {ok:true};}},
    /* ==================== P0: MOV Kernel 新桥 ==================== */
    /* postCmd: JS→Java 命令信号 (CONTRACT: Envelope §2.1) */
    postCmd:function(cmdObj){try{return b&&b.postCmd?JSON.parse(b.postCmd(JSON.stringify(cmdObj))):{ok:false,error:{code:'BRIDGE_UNAVAILABLE',msg:'桥不可用'}};}catch(e){return {ok:false,error:{code:'INTERNAL',msg:String(e)}};}},
    /* query: JS→Java 只读查询 (CONTRACT: Envelope §2.2) */
    query:function(qObj){try{return b&&b.query?JSON.parse(b.query(JSON.stringify(qObj))):{ok:false,error:{code:'BRIDGE_UNAVAILABLE',msg:'桥不可用'}};}catch(e){return {ok:false,error:{code:'INTERNAL',msg:String(e)}};}},
    /* P1: 房间销毁信号 (KI-001: 停 loop 再清, 防死锁) */
    roomDestroy:function(roomId){try{return b&&b.postCmd?JSON.parse(b.postCmd(JSON.stringify({cmd:'room_destroy',roomId:roomId}))):{ok:false,error:{code:'BRIDGE_UNAVAILABLE',msg:'桥不可用'}};}catch(e){return {ok:false,error:{code:'INTERNAL',msg:String(e)}};}},
    /* P7: 消息反应 (emoji reaction) */
    react:function(roomId,targetSeq,emoji){try{return b&&b.postCmd?JSON.parse(b.postCmd(JSON.stringify({cmd:'append_event',roomId:roomId,type:'reaction',actor:'user',payload:{targetSeq:targetSeq,emoji:emoji}}))):{ok:false,error:{code:'BRIDGE_UNAVAILABLE',msg:'桥不可用'}};}catch(e){return {ok:false,error:{code:'INTERNAL',msg:String(e)}};}}
  };
})();

/* ==================== P0: _movEvent 全局事件分发 ==================== */
/* Java→JS 单一事件通道 (CONTRACT: Envelope §2.3)
   {"roomId":"r17...", "channel":"journal|transient", "event":{...}}
   channel:"journal"   已落盘事实, 可持久渲染
   channel:"transient" 瞬态 (token/stream_state/typing), 只渲染当前房间, 不落数组/存储 */
window._movEvent=function(envelope){
  try{
    if(!envelope||typeof envelope!=='object')return;
    var roomId=envelope.roomId||'';
    var channel=envelope.channel||'journal';
    var event=envelope.event||{};
    /* 分发给已注册的监听器 */
    var listeners=_movEventListeners[channel]||[];
    for(var i=0;i<listeners.length;i++){
      try{listeners[i](roomId,event,envelope);}catch(e){console.error('_movEvent listener error',channel,e);}
    }
    /* 通配监听器 */
    var all=_movEventListeners['*']||[];
    for(var j=0;j<all.length;j++){
      try{all[j](roomId,event,envelope);}catch(e){console.error('_movEvent wildcard error',channel,e);}
    }
  }catch(e){console.error('_movEvent dispatch error',e);}
};
var _movEventListeners={};
/* 注册 _movEvent 监听: channel='journal'|'transient'|'*' */
window._movOn=function(channel,fn){
  if(!_movEventListeners[channel])_movEventListeners[channel]=[];
  _movEventListeners[channel].push(fn);
};
window._movOff=function(channel,fn){
  var arr=_movEventListeners[channel];
  if(!arr)return;
  for(var i=arr.length-1;i>=0;i--){if(arr[i]===fn)arr.splice(i,1);}
};

/* Shell 命令开始时立即创建气泡 (防"死机"错觉) */
window._movShellStart=function(cmd){
  try{
    _movEvent({channel:'journal', roomId:curRoomId||'',
      event:{type:'note', text:'⏳ shell.exec '+cmd, ts:Date.now()}});
  }catch(e){}
};

/* Shell 流式输出: 降噪版 — 先审Error, 再拦噪音, 普通行缓冲 */
var _shellBuf=[], _shellLineCount=0, MAX_SHELL_LINES=1000;
window._movShellLine=function(line){
  try{
    // 1. 关键信息优先 (绝不过滤)
    if(/error|fail|warn|fatal|exception|timeout|denied|not found/i.test(line)){
      _movEvent({channel:'journal', roomId:curRoomId||'',
        event:{type:'note', text:'[stderr] '+line.substring(0,200), ts:Date.now()}});
      return;
    }
    // 2. 拦截噪音
    if(/^\s*(\d+%|\[.*\]|Get:|Hit:|Fetched|Reading|Building|Selecting|Preparing|Unpacking|Setting up)/.test(line)) return;
    // 3. 缓冲(上限1000行, 超出截断)
    if(_shellLineCount>=MAX_SHELL_LINES){
      if(_shellLineCount===MAX_SHELL_LINES) _shellBuf.push('...(输出过长,前段已截断)');
      _shellBuf=_shellBuf.slice(-500); _shellLineCount=500;
    }
    _shellBuf.push(line); _shellLineCount++;
  }catch(e){}
};

/* Shell 命令结束: 刷出缓冲 + 摘要 */
window._movShellEnd=function(exitCode, durMs){
  try{
    var label = exitCode===0 ? '✅' : '❌';
    var dur = durMs ? ' · '+(durMs/1000).toFixed(1)+'s' : '';
    var summary = label + ' shell.exec' + dur + ' · 完成';
    _movEvent({channel:'journal', roomId:curRoomId||'',
      event:{type:'note', text:summary, ts:Date.now()}});
    // 刷出缓冲内容
    if(_shellBuf.length>0){
      var content = _shellBuf.join('\n');
      _movEvent({channel:'journal', roomId:curRoomId||'',
        event:{type:'note', text:content.substring(0,5000), ts:Date.now()}});
    }
    _shellBuf=[]; _shellLineCount=0;
  }catch(e){}
};

/* 测试辅助 API: 坐标标注 + 模拟操作 (仅 Debug 包生效, BridgeKernel 有 BuildConfig 闸) */
window.movTest={
  list:function(){
    var els=document.querySelectorAll('button, input, textarea, [onclick], .clickable, .btn, .tab, .fab');
    var r=[]; els.forEach(function(el,i){
      var rect=el.getBoundingClientRect();
      if(rect.width>0&&rect.height>0) r.push({
        id:el.id||el.className.split(' ')[0]||('el'+i),
        tag:el.tagName, text:(el.textContent||el.value||'').substring(0,40),
        x:Math.round(rect.left+rect.width/2), y:Math.round(rect.top+rect.height/2),
        w:Math.round(rect.width), h:Math.round(rect.height)
      });
    }); return JSON.stringify(r);
  },
  tap:function(sel){ var el=document.querySelector(sel)||document.getElementById(sel);
    if(el){el.click();return'ok'} return'not found: '+sel; },
  type:function(sel,text){ var el=document.querySelector(sel)||document.getElementById(sel);
    if(!el)return'not found'; el.focus(); el.value=text;
    el.dispatchEvent(new Event('input',{bubbles:true})); return'ok'; },
  lastMessages:function(n){ n=n||5; var msgs=document.querySelectorAll('.msg');
    var r=[]; for(var i=Math.max(0,msgs.length-n);i<msgs.length;i++)r.push(msgs[i].textContent.substring(0,200));
    return JSON.stringify(r); },
  agentState:function(){ return HermesBridge?HermesBridge.query(JSON.stringify({q:'agent_state'})):'no bridge'; },
  /* 终端联动: 提取错误关键片段发送到 Agent 输入框 (仅 Error: 后10行) */
  sendToAgent:function(terminalOutput, exitCode){
    if(exitCode===0)return'no error';
    var lines=terminalOutput.split('\n');
    var errStart=-1; for(var i=0;i<lines.length;i++){if(/^(Error|error|ERROR|FATAL|FAIL)/.test(lines[i])){errStart=i;break;}}
    if(errStart<0)errStart=Math.max(0,lines.length-15);
    var snippet=lines.slice(errStart,errStart+10).join('\n');
    var msg='终端报告了一个错误 (exit='+exitCode+'):\n=== 终端输出 ===\n'+snippet+'\n=== 结束 ===\n请看看是什么问题。';
    var input=document.getElementById('msgInput')||document.querySelector('textarea,input[type=text]');
    if(input){input.value=msg;input.focus();return'ok'} return'no input';
  }
};

/* P7: 事件类型注册表 (加新功能 = 加新常量, 不改现有逻辑) */
var EVENT={
  USER_INPUT:'user_input', PHASE:'phase', PLAN:'plan', GATE:'gate',
  NOTE:'note', REVIEW:'review', DELIVER:'deliver', FAIL:'fail',
  STOPPED:'stopped', PAUSED:'paused', RESUMED:'resumed', SUMMARY:'summary',
  UNDERSTAND:'understand', TOOL_CALL:'tool_call', TOOL_RESULT:'tool_result',
  TOMBSTONE:'tombstone', REACTION:'reaction',
  /* 内部元事件 (_ 前缀不进 UI) */
  TELEMETRY:'_telemetry', HEADER:'_header',
  /* 判断是否内部元事件 */
  isInternal:function(t){return t&&t.charAt(0)==='_';}
};

/* ============ 全局错误边界 ============ */
window.onerror=function(msg,url,line,col,err){
  var info='SHELL ERROR: '+msg+' @ '+(url||'?')+':'+line+':'+col;
  if(err&&err.stack)info+='\n'+err.stack;
  // CDP 可抓（Runtime.exceptionThrown）
  console.error(info);
  try{if(window.HermesBridge)HermesBridge.log(info);}catch(e){}
  // "Script error." 是浏览器跨源脱敏噪声——不入 chatBody，但保留日志供诊断
  if (String(msg).indexOf('Script error.') === 0 && line === 0) return true;
  try{
    var b=document.getElementById('chatBody');
    if(b){
      var lineDiv=document.createElement('div');
      lineDiv.className='sysline';
      lineDiv.style.color='var(--err)';
      lineDiv.style.borderColor='var(--err-dot)';
      lineDiv.textContent=String(msg).slice(0,200)+' (行 '+line+')';
      b.appendChild(lineDiv);
      var cp=document.getElementById('chatPane');if(cp)cp.scrollTop=cp.scrollHeight;
    }
  }catch(e2){}
  return true;
};
