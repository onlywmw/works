package com.hermes.android.causal;

import com.hermes.android.security.PiiPatterns;

import java.util.regex.Pattern;

/**
 * 确定性 PII 脱敏器（隐私审计 2026-08-05）：纯 JVM 正则/词典，零模型调用、零网络。
 * 职责：文本离开设备前的最后关口——手机号/身份证/邮箱/银行卡/金额/URL 一律打码泛化。
 * 人名/地名由 NarrativeBuilder 的实体抽象（实体A/B/C）处理，本类不做人名猜测（词典不可靠，误伤大于收益）。
 * 应用顺序保证长串优先：URL → 邮箱 → 身份证 → 银行卡 → 手机号 → 金额。
 */
public final class PiiScrubber {

    private PiiScrubber() {}

    /** URL（http/https/www 开头，到空白或中文标点为止）。 */
    private static final Pattern URL =
            Pattern.compile("(?:https?://|www\\.)[^\\s，。；、\"'）)]+");
    /** 邮箱。 */
    private static final Pattern EMAIL =
            Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}");
    /* 技术债治理（工单5）：身份证/银行卡/手机号识别收敛到 PiiPatterns 单一来源（与 PiiMasker 共用），
       出网前哨在此叠加更宽的边界策略（15 位身份证 / 13-15 卡 / 手机号数字边界），宁打码多不漏。 */
    /** 身份证：18 位（共享 PiiPatterns）+ 15 位（出网前哨更宽）。 */
    private static final Pattern ID_CARD =
            Pattern.compile(PiiPatterns.ID_CARD_18.pattern() + "|(?<!\\d)\\d{15}(?!\\d)");
    /** 银行卡号：共享 16-19 识别 + 13-15 位扩展（身份证已先打码，剩余长数字串按银行卡处理）。 */
    private static final Pattern BANK_CARD =
            Pattern.compile("(?<!\\d)\\d{13,15}(?!\\d)|" + PiiPatterns.BANK_CARD_16_19.pattern());
    /** 手机号：共享核心 + 数字边界（防短串部分命中）。 */
    private static final Pattern PHONE =
            Pattern.compile("(?<!\\d)" + PiiPatterns.PHONE_CORE.pattern() + "(?!\\d)");
    /** 金额：¥前缀 或 数字+元/块/万。 */
    private static final Pattern AMOUNT =
            Pattern.compile("[¥￥]\\s?\\d+(?:\\.\\d{1,2})?|\\d+(?:\\.\\d{1,2})?\\s?(?:万元|块钱|元|块|万)");

    /**
     * 打码：命中 PII 模式的片段替换为泛化占位符。null → ""，空 → ""。
     * 顺序：URL → 邮箱 → 身份证 → 银行卡 → 手机号 → 金额（长串优先，防止短模式啃掉长串一部分）。
     */
    public static String scrub(String text) {
        if (text == null || text.isEmpty()) return text == null ? "" : text;
        String s = text;
        s = URL.matcher(s).replaceAll("[链接]");
        s = EMAIL.matcher(s).replaceAll("[邮箱]");
        s = ID_CARD.matcher(s).replaceAll("[证件号]");
        s = BANK_CARD.matcher(s).replaceAll("[银行卡号]");
        s = PHONE.matcher(s).replaceAll("[手机号]");
        s = AMOUNT.matcher(s).replaceAll("[金额]");
        return s;
    }

    /** 检测：文本是否仍含 PII 模式（PatchCompiler 拒绝含原文写回的补丁用）。 */
    public static boolean containsPii(String text) {
        if (text == null || text.isEmpty()) return false;
        return URL.matcher(text).find()
                || EMAIL.matcher(text).find()
                || ID_CARD.matcher(text).find()
                || BANK_CARD.matcher(text).find()
                || PHONE.matcher(text).find()
                || AMOUNT.matcher(text).find();
    }
}
