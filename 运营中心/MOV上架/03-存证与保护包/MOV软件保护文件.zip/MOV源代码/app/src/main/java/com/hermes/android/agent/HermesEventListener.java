package com.hermes.android.agent;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * HermesEventListener — serve /events SSE 客户端（P2 M3，DESIGN_HERMES_SERVE §六 M3）。
 *
 * OkHttp 长连订阅 SSE：progress 事件转发（→ BridgeAi → 房间进度卡），终态退订；
 * 断线自动重连 3 次，之后降级轮询（调用方 HeavyWorker 落回 M2 getTask 兜底）。
 *
 * 纯 JVM 可测（零网络）：parseDataEvent（SSE data 行解析）+ isTerminal + runLoop
 * （重连循环，StreamSource 注入式）——照 LlamaClient/HermesClient 模式。
 */
public class HermesEventListener {

    public static final String KIND_PROGRESS = "progress";
    public static final String KIND_DONE = "done";
    public static final String KIND_FAILED = "failed";
    public static final String KIND_CANCELLED = "cancelled";
    public static final int MAX_RECONNECT = 3;
    public static final long RECONNECT_DELAY_MS = 500;

    /** 事件回调（进度/终态）+ 降级通知 */
    public interface Listener {
        void onEvent(String taskId, String kind, String data);
        void onDegraded();   // 3 次重连失败 → 调用方降级轮询
    }

    /** 一次 SSE 流读取（注入式，测试用 Fake）；true=终态自然结束，false=断线 */
    public interface StreamSource {
        boolean streamOnce();
    }

    // ==================== 纯 JVM 核心（可单测） ====================

    /** SSE `data: {json}` 行 → 事件 JSON；非 data 行/解析失败返回 null */
    public static JSONObject parseDataEvent(String sseLine) {
        if (sseLine == null || !sseLine.startsWith("data: ")) return null;
        String json = sseLine.substring("data: ".length()).trim();
        if (json.isEmpty()) return null;
        try {
            return new JSONObject(json);
        } catch (Exception e) {
            return null;
        }
    }

    public static boolean isTerminal(String kind) {
        return KIND_DONE.equals(kind) || KIND_FAILED.equals(kind) || KIND_CANCELLED.equals(kind);
    }

    // ==================== Android（OkHttp SSE 长连） ====================

    private final OkHttpClient http;
    private final String baseUrl;
    private final String token;
    private final String taskId;
    private final Listener listener;
    private final StreamSource source;
    private volatile boolean stopped = false;
    private Thread thread;

    public HermesEventListener(String baseUrl, String token, String taskId, Listener listener) {
        this(baseUrl, token, taskId, listener, null);
    }

    /** 测试注入 source（纯 JVM 测重连/降级）；null → OkHttp 长连 */
    HermesEventListener(String baseUrl, String token, String taskId,
                        Listener listener, StreamSource source) {
        this.baseUrl = baseUrl;
        this.token = token;
        this.taskId = taskId;
        this.listener = listener;
        this.source = source != null ? source : this::httpStreamOnce;
        // SSE 长连: 无 callTimeout（会杀长连）, readTimeout 60s（keepalive 30s 重置）
        this.http = new OkHttpClient.Builder()
                .connectTimeout(3, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build();
    }

    public void start() {
        thread = new Thread(() -> {
            boolean ok = runLoop(source);
            if (!ok && !stopped) {
                listener.onDegraded();
            }
        }, "hermes-sse");
        thread.setDaemon(true);
        thread.start();
    }

    public void stop() {
        stopped = true;
        if (thread != null) thread.interrupt();
    }

    /**
     * 重连循环：true = 终态/主动停（正常退订）；false = 3 次重连失败（降级轮询）。
     * 纯逻辑，StreamSource 注入可测。
     */
    public boolean runLoop(StreamSource src) {
        int reconnects = 0;
        while (!stopped && reconnects <= MAX_RECONNECT) {
            boolean terminal;
            try {
                terminal = src.streamOnce();
            } catch (Exception e) {
                terminal = false;
            }
            if (stopped || terminal) return true;
            reconnects++;
            try {
                Thread.sleep(RECONNECT_DELAY_MS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return true;
            }
        }
        return false;
    }

    /** OkHttp SSE 长连读一次：读 data 行 → 解析 → 转发；终态返回 true；断线/异常返回 false */
    private boolean httpStreamOnce() {
        Request req = new Request.Builder()
                .url(baseUrl + "/events")
                .header(HermesClient.HEADER_AUTH, token)
                .header("Accept", "text/event-stream")
                .get().build();
        try (Response resp = http.newCall(req).execute()) {
            if (resp.code() != 200 || resp.body() == null) return false;
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(resp.body().byteStream(), StandardCharsets.UTF_8))) {
                String line;
                while (!stopped && (line = r.readLine()) != null) {
                    JSONObject ev = parseDataEvent(line);
                    if (ev == null) continue;
                    String kind = ev.optString("kind", "");
                    listener.onEvent(ev.optString("task_id", taskId), kind,
                            ev.optString("data", ""));
                    if (isTerminal(kind)) return true;
                }
            }
            return false;   // EOF → 断线
        } catch (IOException e) {
            return false;
        }
    }
}
