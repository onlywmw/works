package com.hermes.android.workflow;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Workflow 单 JSON 文件存储（纯 java.io，照 DramaMemory 读改写模式）。
 * 文件结构：{"workflows":[Workflow.toJson()...]}
 * 真理源 = 每个 workflow 的 canonical JSON；CRUD 全量读改写。
 */
public class WorkflowRepository {

    private final File file;

    public WorkflowRepository(File dir) {
        this.file = new File(dir, "workflows.json");
    }

    /** 全部 workflow（含禁用）；文件缺失/损坏 → 空列表 */
    public List<Workflow> list() {
        JSONArray arr = root().optJSONArray("workflows");
        List<Workflow> out = new ArrayList<>();
        if (arr == null) return out;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null) out.add(Workflow.fromJson(o));
        }
        return out;
    }

    public Workflow get(String id) {
        for (Workflow w : list()) if (w.id.equals(id)) return w;
        return null;
    }

    /** upsert：已存在替换，不存在追加 */
    public void save(Workflow wf) {
        try {
            JSONObject root = root();
            JSONArray arr = root.optJSONArray("workflows");
            if (arr == null) { arr = new JSONArray(); root.put("workflows", arr); }
            int idx = -1;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null && wf.id.equals(o.optString("id"))) { idx = i; break; }
            }
            if (idx >= 0) arr.put(idx, wf.toJson());
            else arr.put(wf.toJson());
            write(root);
        } catch (org.json.JSONException e) {
            throw new RuntimeException("WorkflowRepository save failed", e);
        }
    }

    public void delete(String id) {
        try {
            JSONObject root = root();
            JSONArray arr = root.optJSONArray("workflows");
            if (arr == null) return;
            JSONArray next = new JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null || !id.equals(o.optString("id"))) next.put(o);
            }
            root.put("workflows", next);
            write(root);
        } catch (org.json.JSONException e) {
            throw new RuntimeException("WorkflowRepository delete failed", e);
        }
    }

    private JSONObject root() {
        if (!file.exists()) return new JSONObject();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                new FileInputStream(file), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            if (sb.length() == 0) return new JSONObject();
            return new JSONObject(sb.toString());
        } catch (Exception e) {
            return new JSONObject();   // 损坏文件回退空（保留原文件）
        }
    }

    private void write(JSONObject root) {
        try {
            File parent = file.getParentFile();
            if (parent != null) parent.mkdirs();
            try (OutputStreamWriter w = new OutputStreamWriter(
                    new FileOutputStream(file), "UTF-8")) {
                w.write(root.toString());
            }
        } catch (Exception e) {
            throw new RuntimeException("WorkflowRepository write failed", e);
        }
    }
}
