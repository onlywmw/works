package com.hermes.android.mcp;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.modelcontextprotocol.json.McpJsonMapper;
import io.modelcontextprotocol.json.TypeRef;

/**
 * MCP Java SDK 的 JSON 提供者（McpJsonMapper）Jackson 2 实现。
 * mcp-core 用 ServiceLoader 找 McpJsonMapperSupplier——Android app classloader 含本实现（main + services 注册）。
 */
public class Jackson2McpJsonMapper implements McpJsonMapper {

    private final ObjectMapper om = new ObjectMapper();

    public <T> T readValue(String s, Class<T> c) throws java.io.IOException { return om.readValue(s, c); }
    public <T> T readValue(byte[] b, Class<T> c) throws java.io.IOException { return om.readValue(b, c); }
    public <T> T readValue(String s, TypeRef<T> t) throws java.io.IOException { return om.readValue(s, om.getTypeFactory().constructType(t.getType())); }
    public <T> T readValue(byte[] b, TypeRef<T> t) throws java.io.IOException { return om.readValue(b, om.getTypeFactory().constructType(t.getType())); }
    public <T> T convertValue(Object o, Class<T> c) { return om.convertValue(o, c); }
    public <T> T convertValue(Object o, TypeRef<T> t) { return om.convertValue(o, om.getTypeFactory().constructType(t.getType())); }
    public String writeValueAsString(Object o) throws java.io.IOException { return om.writeValueAsString(o); }
    public byte[] writeValueAsBytes(Object o) throws java.io.IOException { return om.writeValueAsBytes(o); }
}
