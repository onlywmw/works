package com.hermes.android.agent;

/**
 * AgentContext — AgentLoop 状态容器 (ARCH_DEBT #6)。
 *
 * 纯数据容器，不持业务逻辑。transition() 是唯一状态变更入口。
 * 不持久化: Journal 是单一真相源，Crash 后重新初始化为 PLANNING。
 */
public class AgentContext {

    private AgentLoop.State state = AgentLoop.State.PLANNING;
    public String loopId;
    public int step;
    public long startMs;
    public String roomId;

    public AgentLoop.State getState() { return state; }

    /** 唯一状态变更入口 — 校验。非法转换抛 IllegalStateException */
    public void transition(AgentLoop.State next) {
        if (!state.canTransitionTo(next)) {
            throw new IllegalStateException(state + " → " + next + " 非法转换");
        }
        state = next;
    }

    /** 只允许终态调用。活跃态抛异常，调用方必须先 killProcess() */
    public void reset() {
        if (state.isActive()) {
            throw new IllegalStateException("不能 reset 活跃态 " + state + "，先 killProcess()");
        }
        state = AgentLoop.State.PLANNING;
        loopId = null;
        step = 0;
        startMs = 0;
    }

}
