package com.hermes.android.linux;

import android.content.Context;

import org.json.JSONObject;

import java.util.List;

/**
 * ProotDiag — proot execve EPERM 诊断（P4 agent-14，on-demand 触发）。
 *
 * 背景：2026-08-02 晚 app 用户 proot 失效（execve EPERM，KSU/SELinux 侧变化嫌疑）。
 * 本类通过 diagnostics.proot 桥命令按需触发（不挂 onCreate——打回先例 CausalSpikeCheck），
 * 产结构化诊断：probe（proot 本体能否 exec）+ exec battery（guest 内命令能否跑）+ classify（根因分类）。
 *
 * classify() 为纯函数（单测 + 变异亲杀）；diagnose() 走真机 exec（on-demand）。
 */
public class ProotDiag {

    // ══════════ 分类常量 ══════════

    /** proot 本体 + guest 命令全部正常 */
    public static final String OK = "OK";
    /** SELinux 拦截 execve（avc denied execute / errno EPERM） */
    public static final String SELINUX_BLOCK = "SELINUX_BLOCK";
    /** loader 陈旧/缺失（PROOT_LOADER 指向旧 nativeLibraryDir） */
    public static final String LOADER_STALE = "LOADER_STALE";
    /** rootfs 半残（proot OK 但 guest env/bash 缺失） */
    public static final String ROOTFS_BROKEN = "ROOTFS_BROKEN";
    /** proot 进程僵死/超时 */
    public static final String TIMEOUT = "TIMEOUT";
    /** 无法区分（无 avc 日志且 errno 非明确） */
    public static final String UNKNOWN = "UNKNOWN";

    /** 纯函数：根据 probe/exec 结果 + avc 线索判定根因分类。单测 + 变异入口。 */
    public static String classify(int probeExit, String probeOut,
                                  int execExit, String execOut, String execErr,
                                  boolean timeout, List<String> avcLines) {
        if (timeout) return TIMEOUT;

        // 1) proot 本体是否 OK（--version 首行是 ASCII art banner "_____ _____ ___"，
        //    不能锁死 "proot version" 字样；exit=0 且输出非空即本体 exec 成功）
        boolean probeOk = probeExit == 0 && probeOut != null
                && !probeOut.isEmpty()
                && !probeOut.startsWith("ERROR:");
        if (!probeOk) {
            // 本体 exec 失败 → 看 errno/avc
            String combined = (probeOut == null ? "" : probeOut)
                    + "\n" + (execErr == null ? "" : execErr);
            boolean permDenied = combined.contains("Operation not permitted")
                    || combined.contains("Permission denied");
            boolean avcDeniedExec = hasAvcDeniedExec(avcLines);
            if (permDenied || avcDeniedExec) return SELINUX_BLOCK;
            // loader 路径问题（NOENT）
            if (combined.contains("No such file") || combined.contains("not found")
                    || combined.contains("inaccessible")) return LOADER_STALE;
            return UNKNOWN;
        }

        // 2) proot OK → 看 guest 命令
        if (execExit != 0) {
            String combined = (execOut == null ? "" : execOut)
                    + "\n" + (execErr == null ? "" : execErr);
            if (combined.contains("No such file") || combined.contains("not found")
                    || combined.contains("command not found")) return ROOTFS_BROKEN;
            boolean permDenied = combined.contains("Operation not permitted")
                    || combined.contains("Permission denied");
            if (permDenied || hasAvcDeniedExec(avcLines)) return SELINUX_BLOCK;
            return UNKNOWN;
        }

        // 3) 全 OK
        return OK;
    }

    /** 检查 avc 线索里是否有 denied execute/execute_no_trans/execmod（untrusted_app）。 */
    public static boolean hasAvcDeniedExec(List<String> avcLines) {
        if (avcLines == null) return false;
        for (String line : avcLines) {
            if (line == null) continue;
            boolean deniedExec = line.contains("avc:  denied  { execute")
                    || line.contains("avc: denied { execute")
                    || line.contains("avc:  denied  { execute_no_trans")
                    || line.contains("avc: denied { execute_no_trans")
                    || line.contains("avc:  denied  { execmod")
                    || line.contains("avc: denied { execmod");
            if (deniedExec && line.contains("untrusted_app")) return true;
        }
        return false;
    }

    // ══════════ 真机诊断（on-demand） ══════════

    /** 汇总诊断：probe + exec battery + classify。返回 JSON。 */
    public static JSONObject diagnose(Context ctx) {
        JSONObject out = new JSONObject();
        try {
            // probe: proot 本体 exec --version
            String probeOut = Proot.probe(ctx);
            int probeExit = probeOut != null && probeOut.startsWith("ERROR:")
                    ? -1 : 0;
            out.put("probeExit", probeExit);
            out.put("probeOut", probeOut);

            // exec battery: guest 内跑命令（rootfs + venv 一起验）
            String battery = "echo UNAME:$(uname -a);"
                    + " echo PY:$(python3 --version 2>&1);"
                    + " echo GIT:$(git --version 2>&1);"
                    + " echo BASH:$BASH_VERSION;"
                    + " echo ENV_OK:$(test -x /usr/bin/env && echo yes || echo no);"
                    + " test -x ~/.hermes-venv/bin/hermes && ~/.hermes-venv/bin/hermes --version || echo NO_VENV";
            ProotRunner.ExecResult r = ProotRunner.exec(ctx, battery, 60);
            out.put("execExit", r.exitCode);
            out.put("execOut", r.stdout);
            out.put("execErr", r.stderr);
            out.put("timeout", r.timeout);

            // classify（无 avc 输入时传空——真机归因靠 errno；avc 由调用方 logcat 抓取补录）
            String cls = classify(probeExit, probeOut, r.exitCode,
                    r.stdout, r.stderr, r.timeout, null);
            out.put("classify", cls);

            // 环境信息
            out.put("uid", android.os.Process.myUid());
            out.put("nativeLibDir", ctx.getApplicationInfo().nativeLibraryDir);
            out.put("rootfsReady", RootfsManager.isReady(ctx));
            out.put("probePath", Proot.binary(ctx).getAbsolutePath());
            out.put("rootfsDir", new RootfsManager(ctx).rootfsDir().getAbsolutePath());
        } catch (Exception e) {
            try {
                out.put("error", e.getMessage() != null ? e.getMessage()
                        : e.getClass().getSimpleName());
            } catch (Exception ignored) {}
        }
        return out;
    }
}
