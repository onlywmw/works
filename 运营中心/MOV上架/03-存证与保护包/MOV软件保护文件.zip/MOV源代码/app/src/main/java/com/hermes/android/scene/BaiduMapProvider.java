package com.hermes.android.scene;

import android.content.Context;

import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.agent.ToolRegistry.*;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 百度地图工具 Provider（对齐官方 mcp-server-baidu-maps 10 工具）。
 *
 * 需要百度地图开放平台 AK（SharedPreferences "baidu_map_prefs" / "ak"），未配置时 checkFn
 * 返回「未配置」→ 工具不注入（对齐 REASON_NOT_CONFIGURED 语义）。配置后全部 access=readonly →
 * 8389 MCP 自动暴露。网络 IO 工具 sync=true（禁同步桥红线）。
 *
 * 错误归因 H1：AK 未配置→NOT_CONFIGURED；HTTP/网络→SOURCE_DOWN；status!=0→普通错误带百度 message。
 */
public class BaiduMapProvider implements ToolProvider {

    private static Context appContext;

    public static void init(Context ctx) { appContext = ctx.getApplicationContext(); }

    @Override public String id() { return "baidu-map"; }

    private BaiduMapSource source() {
        if (appContext == null) return new BaiduMapSource("");
        return new BaiduMapSource(BaiduMapSource.loadAk(appContext));
    }

    /** AK 可用性检查：未配置返回原因，配置返回 null（可用）。 */
    private String akCheck() {
        return source().hasAk() ? null : "百度地图 AK 未配置（设置里填 BAIDU_MAPS_API_KEY）";
    }

    @Override
    public List<Tool> discover() {
        List<Tool> list = new ArrayList<>();

        list.add(new Tool("map_geocode",
            "地理编码：将地址解析为对应的位置坐标。地址结构越完整，坐标精度越高。",
            null, a -> run(() -> source().geocode(a.optString("address", ""), a.optString("is_china", "true"))),
            "native", "readonly", "none", true, 10, "geo",
            new ParamDef[]{
                new ParamDef("address", "string", true, "最多84字节", "待解析地址，如 北京市海淀区上地十街十号"),
                new ParamDef("is_china", "string", false, "true/false", "是否中国大陆，默认 true"),
            },
            "百度 JSON（经纬度坐标）",
            new String[]{"北京市海淀区上地十街十号在哪"}, null, 4000,
            new Manifest("地理编码", "low", "地址转坐标", false, "network", "SLOW", true, 8000),
            this::akCheck));

        list.add(new Tool("map_reverse_geocode",
            "逆地理编码：根据纬经度坐标获取地址描述、行政区划、道路及POI信息。",
            null, a -> run(() -> source().reverseGeocode(a.optString("latitude", ""), a.optString("longitude", ""))),
            "native", "readonly", "none", true, 10, "geo",
            new ParamDef[]{
                new ParamDef("latitude", "string", true, "bd09ll", "纬度"),
                new ParamDef("longitude", "string", true, "bd09ll", "经度"),
            },
            "百度 JSON（地址描述）",
            new String[]{"39.915,116.404 是什么地方"}, null, 4000,
            new Manifest("逆地理编码", "low", "坐标转地址", false, "network", "SLOW", true, 8000),
            this::akCheck));

        list.add(new Tool("map_search_places",
            "地点检索：按关键词/分类检索城市内或圆形区域内的POI（餐饮/景点/购物等）。",
            null, a -> run(() -> source().searchPlaces(
                a.optString("query", ""), a.optString("tag", ""),
                a.optString("region", ""), a.optString("location", ""),
                a.optString("radius", ""), a.optString("is_china", "true"))),
            "native", "readonly", "none", true, 10, "geo",
            new ParamDef[]{
                new ParamDef("query", "string", true, "", "检索关键字，如 天安门；多个用英文逗号隔开"),
                new ParamDef("tag", "string", false, "", "检索分类，如 美食、购物"),
                new ParamDef("region", "string", false, "", "检索城市，如 北京市；默认全国"),
                new ParamDef("location", "string", false, "lat,lng", "圆形区域中心点坐标"),
                new ParamDef("radius", "string", false, "米", "圆形区域半径"),
                new ParamDef("is_china", "string", false, "true/false", "是否中国大陆，默认 true"),
            },
            "百度 JSON（POI 列表）",
            new String[]{"北京的美食"}, null, 4000,
            new Manifest("地点检索", "low", "搜索POI地点", false, "network", "SLOW", true, 8000),
            this::akCheck));

        list.add(new Tool("map_place_details",
            "地点详情：按 POI 的 uid 获取评分、营业时间等详情。",
            null, a -> run(() -> source().placeDetails(a.optString("uid", ""), a.optString("is_china", "true"))),
            "native", "readonly", "none", true, 10, "geo",
            new ParamDef[]{
                new ParamDef("uid", "string", true, "", "POI 唯一标识（地点检索获得）"),
                new ParamDef("is_china", "string", false, "true/false", "是否中国大陆，默认 true"),
            },
            "百度 JSON（POI 详情）",
            new String[]{"查这个地点的评分"}, null, 4000,
            new Manifest("地点详情", "low", "查POI详情", false, "network", "SLOW", true, 8000),
            this::akCheck));

        list.add(new Tool("map_directions_matrix",
            "批量算路：按起终点坐标计算驾车/骑行/步行的距离与时间。步行起终点≤200KM，驾车一次最多100条。",
            null, a -> run(() -> source().directionsMatrix(
                a.optString("origins", ""), a.optString("destinations", ""), a.optString("model", ""))),
            "native", "readonly", "none", true, 12, "geo",
            new ParamDef[]{
                new ParamDef("origins", "string", true, "lat,lng|lat,lng", "多个起点坐标，|分隔"),
                new ParamDef("destinations", "string", true, "lat,lng|lat,lng", "多个终点坐标，|分隔"),
                new ParamDef("model", "string", false, "driving|riding|walking", "算路类型，默认 driving"),
            },
            "百度 JSON（距离/时间矩阵）",
            new String[]{"批量算路线"}, null, 4000,
            new Manifest("批量算路", "low", "批量路线距离时间", false, "network", "SLOW", true, 8000),
            this::akCheck));

        list.add(new Tool("map_directions",
            "路线规划：按起终点名称或坐标规划驾车/骑行/步行/公交出行路线。",
            null, a -> run(() -> source().directions(
                a.optString("model", ""), a.optString("origin", ""),
                a.optString("destination", ""), a.optString("is_china", "true"))),
            "native", "readonly", "none", true, 12, "geo",
            new ParamDef[]{
                new ParamDef("origin", "string", true, "名称或坐标", "起点"),
                new ParamDef("destination", "string", true, "名称或坐标", "终点"),
                new ParamDef("model", "string", false, "driving|riding|walking|transit", "路线类型，默认 driving"),
                new ParamDef("is_china", "string", false, "true/false", "是否中国大陆，默认 true"),
            },
            "百度 JSON（路线方案）",
            new String[]{"从北京到上海怎么走"}, null, 4000,
            new Manifest("路线规划", "low", "规划出行路线", false, "network", "SLOW", true, 8000),
            this::akCheck));

        list.add(new Tool("map_weather",
            "天气查询：按行政区划或坐标查询实时天气及未来5天预报。",
            null, a -> run(() -> source().weather(
                a.optString("location", ""), a.optString("district_id", ""), a.optString("is_china", "true"))),
            "native", "readonly", "none", true, 10, "geo",
            new ParamDef[]{
                new ParamDef("location", "string", false, "lng,lat", "经纬度坐标（经度在前）"),
                new ParamDef("district_id", "string", false, "6位", "行政区划代码"),
                new ParamDef("is_china", "string", false, "true/false", "是否中国大陆，默认 true"),
            },
            "百度 JSON（实时天气+5天预报）",
            new String[]{"今天北京天气"}, null, 4000,
            new Manifest("天气查询", "low", "查实时天气与预报", false, "network", "SLOW", true, 8000),
            this::akCheck));

        list.add(new Tool("map_ip_location",
            "IP定位：通过IP获取位置信息和城市名称。IP为空则定位当前IP。",
            null, a -> run(() -> source().ipLocation(a.optString("ip", ""))),
            "native", "readonly", "none", true, 8, "geo",
            new ParamDef[]{
                new ParamDef("ip", "string", false, "IPv4/IPv6", "要定位的IP，空=当前IP"),
            },
            "百度 JSON（IP 定位）",
            new String[]{"我当前在哪"}, null, 4000,
            new Manifest("IP定位", "low", "IP定位城市", false, "network", "SLOW", true, 8000),
            this::akCheck));

        list.add(new Tool("map_road_traffic",
            "实时路况：按道路名或区域形状（矩形/多边形/圆形）查询实时拥堵情况。",
            null, a -> run(() -> source().roadTraffic(
                a.optString("model", ""), a.optString("road_name", ""), a.optString("city", ""),
                a.optString("bounds", ""), a.optString("vertexes", ""),
                a.optString("center", ""), a.optString("radius", ""))),
            "native", "readonly", "none", true, 12, "geo",
            new ParamDef[]{
                new ParamDef("model", "string", true, "road|bound|polygon|around", "路况查询类型"),
                new ParamDef("road_name", "string", false, "", "道路名+方向，model=road 必传"),
                new ParamDef("city", "string", false, "", "城市名，model=road 必传"),
                new ParamDef("bounds", "string", false, "", "矩形区域坐标，model=bound 必传"),
                new ParamDef("vertexes", "string", false, "", "多边形顶点坐标，model=polygon 必传"),
                new ParamDef("center", "string", false, "", "圆形中心坐标，model=around 必传"),
                new ParamDef("radius", "string", false, "1-1000", "圆形半径米，model=around 必传"),
            },
            "百度 JSON（实时路况）",
            new String[]{"朝阳路实时路况"}, null, 4000,
            new Manifest("实时路况", "low", "查交通拥堵", false, "network", "SLOW", true, 8000),
            this::akCheck));

        list.add(new Tool("map_poi_extract",
            "POI智能提取：从用户提供的文本描述中智能提取POI信息。需要 AK 高级权限，否则报错。",
            null, a -> run(() -> source().poiExtract(a.optString("text_content", ""))),
            "native", "readonly", "none", true, 20, "geo",
            new ParamDef[]{
                new ParamDef("text_content", "string", true, "", "包含POI的文本描述"),
            },
            "百度 JSON（提取的 POI）",
            new String[]{"从这段话里提取地点"}, null, 4000,
            new Manifest("POI提取", "low", "从文本提取POI", false, "network", "SLOW", true, 15000),
            this::akCheck));

        return list;
    }

    /** 执行百度请求 → Result。错误归因 H1。 */
    private static ToolRegistry.Result run(java.util.concurrent.Callable<JSONObject> call) {
        try {
            JSONObject r = call.call();
            return new Result(true, r.toString(), r.toString());
        } catch (Exception e) {
            String msg = e.getMessage() == null ? "未知错误" : e.getMessage();
            if (msg.contains("AK 未配置")) {
                return new Result(false, msg, null, null, Result.REASON_NOT_CONFIGURED);
            }
            if (msg.startsWith("HTTP") || msg.startsWith("httpGet") || msg.contains("Connect") || msg.contains("connect")) {
                return new Result(false, "百度地图请求失败: " + msg, null, null, Result.REASON_SOURCE_DOWN);
            }
            return new Result(false, "百度地图查询失败: " + msg, null, null, Result.REASON_SOURCE_DOWN);
        }
    }
}
