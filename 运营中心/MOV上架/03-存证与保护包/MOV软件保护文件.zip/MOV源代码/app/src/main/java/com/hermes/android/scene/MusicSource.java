package com.hermes.android.scene;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * 网易云音乐搜索（v1，SPIKE 实测 API）。
 * 镜像 TrainSource 结构：search → parseSongs → Song 列表。
 */
public class MusicSource {

    private static final String TAG = "MusicSource";
    private static final String SEARCH_URL = "https://music.163.com/api/search/get/web?s=%s&type=1&limit=6";

    public static class Song {
        public final long id;
        public final String name, artist, album;
        public final int fee;          // 0/8=可播, 1=VIP
        public final long durationMs;
        public final boolean playable;

        Song(long id, String name, String artist, String album, int fee, long durationMs) {
            this.id = id; this.name = name; this.artist = artist; this.album = album;
            this.fee = fee; this.durationMs = durationMs;
            this.playable = (fee == 0 || fee == 8);
        }

        public JSONObject toJSON() {
            JSONObject o = new JSONObject();
            try {
                o.put("id", id); o.put("name", name); o.put("artist", artist);
                o.put("album", album); o.put("fee", fee); o.put("durationMs", durationMs);
                o.put("playable", playable);
            } catch (Exception ignored) {}
            return o;
        }

        public String playUrl() {
            return "https://music.163.com/song/media/outer/url?id=" + id + ".mp3";
        }

        public static String formatDuration(long ms) {
            long s = ms / 1000;
            return (s / 60) + ":" + String.format("%02d", s % 60);
        }
    }

    /** 搜索 */
    public List<Song> search(String keyword) throws Exception {
        String encoded = URLEncoder.encode(keyword, "UTF-8");
        URL url = new URL(SEARCH_URL.replace("%s", encoded));
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(5000); conn.setReadTimeout(5000);
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36");
        conn.setRequestProperty("Referer", "https://music.163.com/");
        int code = conn.getResponseCode();
        if (code != 200) throw new Exception("music search returned " + code);
        String ct = conn.getContentType();
        if (ct != null && ct.contains("html")) throw new Exception("music search returned HTML (link failure)");
        BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close(); conn.disconnect();
        return parseSongs(new JSONObject(sb.toString()));
    }

    /** 解析搜索结果（package-private for test） */
    List<Song> parseSongs(JSONObject resp) throws Exception {
        List<Song> songs = new ArrayList<>();
        JSONObject result = resp.optJSONObject("result");
        if (result == null) return songs;
        JSONArray arr = result.optJSONArray("songs");
        if (arr == null) return songs;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject s = arr.getJSONObject(i);
            long id = s.optLong("id");
            String name = s.optString("name", "");
            JSONArray artists = s.optJSONArray("artists");
            String artist = "";
            if (artists != null && artists.length() > 0) {
                artist = artists.getJSONObject(0).optString("name", "");
            }
            String album = s.optJSONObject("album") != null
                    ? s.optJSONObject("album").optString("name", "") : "";
            int fee = s.optInt("fee", 0);
            long dur = s.optLong("duration", 0);
            songs.add(new Song(id, name, artist, album, fee, dur));
        }
        return songs;
    }
}
