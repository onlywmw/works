package com.hermes.android.pay;

import android.content.Context;

import com.hermes.android.vault.SecureVault;

import org.json.JSONObject;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

/**
 * 商户凭证读取器（工单26 M0-1）。
 *
 * 存储布局：prefs「mkt_merchant」只存 vault 引用 + 非敏感的 mchid；
 * pem 私钥 / 证书序列号 / APIv3 密钥 / 卖家 RSA 私钥 全部经 SecureVault.lock 加密存。
 * 红线：私钥禁入 journal / logcat / 明文 prefs。
 */
public class MerchantCreds {

    public static final String PREFS_FILE = "mkt_merchant";
    public static final String KEY_JSON = "json";

    public final String mchid;
    public final String serialNo;
    public final String apiv3Key;
    public final String appid;           // 公众号/应用 AppID（非机密，明文存 prefs；E-12）
    public final PrivateKey privateKey;  // 微信 API 证书私钥
    public final PrivateKey sellerKey;   // 卖家发货签名私钥（可为 null = 未配置）

    public MerchantCreds(String mchid, String serialNo, String apiv3Key, String appid,
                         PrivateKey privateKey, PrivateKey sellerKey) {
        this.mchid = mchid == null ? "" : mchid;
        this.serialNo = serialNo == null ? "" : serialNo;
        this.apiv3Key = apiv3Key == null ? "" : apiv3Key;
        this.appid = appid == null ? "" : appid;
        this.privateKey = privateKey;
        this.sellerKey = sellerKey;
    }

    /** 从 prefs + SecureVault 加载；未配置抛 IllegalStateException（带可读原因） */
    public static MerchantCreds load(Context ctx) throws Exception {
        String raw = ctx.getSharedPreferences(PREFS_FILE, 0).getString(KEY_JSON, "{}");
        JSONObject j = new JSONObject(raw);
        String mchid = j.optString("mchid", "");
        if (mchid.isEmpty()) throw new IllegalStateException("商户号未配置");
        SecureVault v = new SecureVault(ctx);
        String pemId = j.optString("pemVaultId", "");
        String serialId = j.optString("serialVaultId", "");
        String apiv3Id = j.optString("apiv3VaultId", "");
        String sellerId = j.optString("sellerVaultId", "");
        if (pemId.isEmpty() || serialId.isEmpty() || apiv3Id.isEmpty())
            throw new IllegalStateException("商户四证未配置完整");
        PrivateKey seller = sellerId.isEmpty() ? null : loadPem(v.unlock(sellerId));
        return new MerchantCreds(mchid, v.unlock(serialId), v.unlock(apiv3Id),
                j.optString("appid", ""), loadPem(v.unlock(pemId)), seller);
    }

    /** PEM → PrivateKey（PKCS#8）；破折号行与空白剥离后 Base64 解码 */
    static PrivateKey loadPem(String pem) throws Exception {
        String b64 = pem.replaceAll("-----[^-]+-----", "").replaceAll("\\s", "");
        return KeyFactory.getInstance("RSA")
                .generatePrivate(new PKCS8EncodedKeySpec(Base64.getDecoder().decode(b64)));
    }

    /** 微信下单所需四证是否齐备 */
    public boolean wxComplete() {
        return !mchid.isEmpty() && !serialNo.isEmpty() && !apiv3Key.isEmpty() && privateKey != null;
    }

    /** 卖家发货签名私钥是否就绪 */
    public boolean sellerReady() { return sellerKey != null; }
}
