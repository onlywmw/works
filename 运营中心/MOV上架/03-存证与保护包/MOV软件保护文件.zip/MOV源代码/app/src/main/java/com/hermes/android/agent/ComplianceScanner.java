package com.hermes.android.agent;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * ComplianceScanner — 交付基线扫描器 (CONTRACT: DeliveryGate v1.0)。
 *
 * 纯逻辑，无 Android 依赖，可直接单测。
 * 三规则 + 三级判定。
 */
public class ComplianceScanner {

    /** 缺陷标记模式 (不区分大小写) */
    private static final Pattern DEFECT_PATTERN = Pattern.compile(
            "TODO|FIXME|XXX|占位|placeholder|lorem\\s+ipsum",
            Pattern.CASE_INSENSITIVE);

    /** 单文件"大文件"阈值 (字符数) */
    private static final int LARGE_FILE_THRESHOLD = 500;

    /** Compliance Check 注释块标记 */
    private static final String COMPLIANCE_MARKER = "Compliance Check";

    /** 判定结果 */
    public enum Verdict {
        /** 上线级 — 零缺陷 */
        PASSED,
        /** 需修复 — 有缺陷，给一次自我修复机会 */
        NEEDS_FIX,
        /** 带瑕疵交付 — 修复后仍有缺陷，不抹杀产物 */
        DELIVER_WITH_ISSUES
    }

    /** 单条缺陷 */
    public static class Defect {
        public final String file;
        public final String rule;    // "TODO_OR_PLACEHOLDER" | "MISSING_COMPLIANCE_BLOCK"
        public final String detail;

        public Defect(String file, String rule, String detail) {
            this.file = file;
            this.rule = rule;
            this.detail = detail;
        }
    }

    /** 扫描结果 */
    public static class Report {
        public final Verdict verdict;
        public final List<Defect> defects;
        public final int totalFiles;
        public final int passedFiles;

        public Report(Verdict verdict, List<Defect> defects, int totalFiles, int passedFiles) {
            this.verdict = verdict;
            this.defects = defects;
            this.totalFiles = totalFiles;
            this.passedFiles = passedFiles;
        }

        public String summary() {
            if (defects.isEmpty()) return passedFiles + "/" + totalFiles + " 文件通过";
            return passedFiles + "/" + totalFiles + " 文件通过, " + defects.size() + " 项缺陷";
        }
    }

    // ==================== 扫描入口 ====================

    /**
     * 扫描产物文件列表。
     * @param files 产物文件名列表
     * @param contentProvider 按文件名取内容 (可能返回 null = 文件不存在)
     * @param isRetry 是否已经是自我修复后重扫 (重扫 → 不再给 NEEDS_FIX, 直接 PASSED 或 DELIVER_WITH_ISSUES)
     */
    public Report scan(String[] files, ContentProvider contentProvider, boolean isRetry) {
        List<Defect> allDefects = new ArrayList<>();
        int passed = 0;

        for (String file : files) {
            String content = contentProvider.getContent(file);
            if (content == null) {
                allDefects.add(new Defect(file, "FILE_NOT_FOUND", "文件不存在或不可读"));
                continue;
            }
            List<Defect> fileDefects = scanFile(file, content);
            if (fileDefects.isEmpty()) {
                passed++;
            } else {
                allDefects.addAll(fileDefects);
            }
        }

        Verdict verdict;
        if (allDefects.isEmpty()) {
            verdict = Verdict.PASSED;
        } else if (isRetry) {
            verdict = Verdict.DELIVER_WITH_ISSUES;  // 修复后仍有缺陷 → 带瑕疵交付
        } else {
            verdict = Verdict.NEEDS_FIX;             // 首次 → 给修复机会
        }

        return new Report(verdict, allDefects, files.length, passed);
    }

    // ==================== 单文件扫描 ====================

    private List<Defect> scanFile(String fileName, String content) {
        List<Defect> defects = new ArrayList<>();

        // 规则 1: 全文扫描 TODO/FIXME/占位/placeholder
        var matcher = DEFECT_PATTERN.matcher(content);
        while (matcher.find()) {
            int pos = matcher.start();
            int ctxStart = Math.max(0, pos - 20);
            int ctxEnd = Math.min(content.length(), pos + 30);
            String ctx = content.substring(ctxStart, ctxEnd).replace("\n", " ").trim();
            defects.add(new Defect(fileName, "TODO_OR_PLACEHOLDER",
                    "第 " + pos + " 字符: …" + ctx + "…"));
            if (defects.size() >= 5) break; // 上限，不刷屏
        }

        // 规则 2: >500 行文件缺 Compliance Check 注释块
        int lineCount = content.split("\n").length;
        if (lineCount > LARGE_FILE_THRESHOLD && !content.contains(COMPLIANCE_MARKER)) {
            defects.add(new Defect(fileName, "MISSING_COMPLIANCE_BLOCK",
                    lineCount + " 行文件缺少 Compliance Check 注释块"));
        }

        return defects;
    }

    // ==================== 内容提供接口 ====================

    /** 内容提供者 (生产环境走 StorageManager, 单测可 mock) */
    public interface ContentProvider {
        String getContent(String fileName);
    }
}
