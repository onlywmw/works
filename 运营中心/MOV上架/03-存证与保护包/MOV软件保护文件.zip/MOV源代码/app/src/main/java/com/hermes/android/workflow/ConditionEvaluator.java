package com.hermes.android.workflow;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.TimeZone;

/**
 * 5 条件评估（纯 JVM，AND 组合 + 每条件 invert）：
 * time / element / text / url / count。
 */
public class ConditionEvaluator {

    /** 全部条件 AND 通过才为真；空条件 = 通过 */
    public static boolean evaluateAll(JSONArray conditions, Snapshot snap) {
        if (conditions == null || conditions.length() == 0) return true;
        for (int i = 0; i < conditions.length(); i++) {
            JSONObject c = conditions.optJSONObject(i);
            if (c == null) continue;
            if (!evaluate(c, snap)) return false;
        }
        return true;
    }

    public static boolean evaluate(JSONObject cond, Snapshot snap) {
        if (cond == null) return true;
        boolean invert = cond.optBoolean("invert", false);
        boolean raw = evaluateRaw(cond, snap);
        return invert ? !raw : raw;
    }

    private static boolean evaluateRaw(JSONObject cond, Snapshot snap) {
        String type = cond.optString("type", "");
        switch (type) {
            case "time":
                return inTimeRange(cond.optString("start", "00:00"),
                        cond.optString("end", "23:59"), snap.now, cond.optString("timezone", ""));
            case "element":
                return snap.elementExists(cond.optString("selector", ""));
            case "text":
                return TriggerEvaluator.matchPattern(cond.optString("pattern", ""), snap.text,
                        cond.optString("match", "contains"));
            case "url":
                return TriggerEvaluator.matchPattern(cond.optString("pattern", ""), snap.url,
                        cond.optString("match", "contains"));
            case "count":
                return snap.count >= cond.optInt("min", 1);
            // ══ 第三幕：条件扩展 9 个（快照缺数据 = FAIL，诚实） ══
            case "battery_range": {
                int lv = snap.batteryLevel;
                return lv >= 0 && lv >= cond.optInt("min", 0) && lv <= cond.optInt("max", 100);
            }
            case "network_type": {
                String t = cond.optString("net", "");
                return !t.isEmpty() && t.equals(snap.networkType);
            }
            case "app_foreground": {
                String p = cond.optString("package", "");
                return !p.isEmpty() && p.equals(snap.foregroundApp);
            }
            case "last_run_ago": {
                long within = cond.optLong("withinMinutes", 60) * 60000L;
                return snap.lastRunAt > 0 && snap.now - snap.lastRunAt <= within;
            }
            case "day_of_week_in": {
                org.json.JSONArray days = cond.optJSONArray("days");
                if (days == null) return false;
                java.util.Calendar c = java.util.Calendar.getInstance();
                c.setTimeInMillis(snap.now);
                int isoDow = (c.get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7 + 1;   // Calendar 1=Sun → ISO 1=Mon
                for (int i = 0; i < days.length(); i++) {
                    if (days.optInt(i, 0) == isoDow) return true;
                }
                return false;
            }
            case "is_charging":
                return snap.charging;
            case "screen_is_on":
                return snap.screenOn;
            case "element_count": {
                int n = cond.optInt("min", 1);
                return snap.elementCountFor(cond.optString("selector", "")) >= n;
            }
            case "variable_equal": {
                String k = cond.optString("key", "");
                String v = cond.optString("value", "");
                return !k.isEmpty() && v.equals(snap.variables.get(k));
            }
            default:
                return false;
        }
    }

    /** HH:mm 区间判定（支持跨午夜；timezone 空 = 设备本地时区） */
    static boolean inTimeRange(String start, String end, long nowMs, String timezone) {
        int nowMin = minutesOfDay(nowMs, timezone);
        int s = parseMin(start);
        int e = parseMin(end);
        if (s <= e) return nowMin >= s && nowMin <= e;
        return nowMin >= s || nowMin <= e;   // 跨午夜：如 22:00-06:00
    }

    static int minutesOfDay(long nowMs, String timezone) {
        Calendar cal = Calendar.getInstance();
        if (timezone != null && !timezone.isEmpty()) {
            try { cal.setTimeZone(TimeZone.getTimeZone(timezone)); } catch (Exception ignored) {}
        }
        cal.setTimeInMillis(nowMs);
        return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
    }

    static int parseMin(String hhmm) {
        try {
            String[] p = hhmm.split(":");
            return Integer.parseInt(p[0]) * 60 + Integer.parseInt(p[1]);
        } catch (Exception e) {
            return 0;
        }
    }
}
