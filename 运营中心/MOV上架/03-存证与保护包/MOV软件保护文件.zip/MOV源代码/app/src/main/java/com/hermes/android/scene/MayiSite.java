package com.hermes.android.scene;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 蚂蚁影视站点模型（maccms 架构，任务Q·第一层）。
 * 一处建模全局复用：DramaSource/雷达/续播/指名集数全走这里。
 * 站点变更哨兵：连续失败标记结构变更，降级报警。
 */
public class MayiSite {

    private static final String TAG = "MayiSite";
    private static final String BASE = "https://91mayitv.com";
    private int consecutiveFailures;
    private boolean structureChanged;

    // ══════ 领域对象 ══════

    public static class Show {
        public final String id;     // voddetail/210509/
        public final String title;
        public final String poster;
        public final String info;   // 年份/地区/状态

        Show(String id, String title, String poster, String info) {
            this.id = id; this.title = title; this.poster = poster; this.info = info;
        }
        public JSONObject toJSON() {
            JSONObject o = new JSONObject();
            try { o.put("id",id); o.put("title",title); o.put("poster",poster); o.put("info",info); } catch (Exception e) {}
            return o;
        }
    }

    public static class ShowDetail {
        public final String id, title, poster, info;
        public final List<SourceLine> sources;
        public final List<Episode> episodes;

        ShowDetail(String id, String title, String poster, String info,
                   List<SourceLine> sources, List<Episode> episodes) {
            this.id = id; this.title = title; this.poster = poster; this.info = info;
            this.sources = sources; this.episodes = episodes;
        }
        public int latestEpisode() { return episodes.isEmpty() ? 0 : episodes.get(episodes.size()-1).nid; }
    }

    public static class SourceLine {
        public final int sid;
        public final String name;
        SourceLine(int sid, String name) { this.sid = sid; this.name = name; }
    }

    public static class Episode {
        public final int nid;
        public final String text, playUrl;
        Episode(int nid, String text, String playUrl) {
            this.nid = nid; this.text = text; this.playUrl = playUrl;
        }
    }

    public static class PlayResult {
        public final String playUrl;
        public final boolean isDirect;  // 直达播放页（非详情页）
        PlayResult(String playUrl, boolean isDirect) { this.playUrl = playUrl; this.isDirect = isDirect; }
    }

    // ══════ 搜索 ══════

    public List<Show> search(String query) {
        List<Show> results = new ArrayList<>();
        try {
            String encoded = URLEncoder.encode(query, "UTF-8");
            String html = get(BASE + "/vodsearch/" + encoded + "-------------.html");
            if (html == null) { onFail(); return results; }

            Pattern p = Pattern.compile("<a[^>]*href=\"(/voddetail/\\d+/)\"[^>]*>\\s*"
                    + "(?:<img[^>]*src=\"([^\"]+)\"[^>]*>\\s*)?"
                    + "<span[^>]*>([^<]+)</span>", Pattern.DOTALL);
            Matcher m = p.matcher(html);
            while (m.find() && results.size() < 20) {
                results.add(new Show(m.group(1), cleanTitle(m.group(3)),
                    m.group(2) != null ? m.group(2) : "", ""));
            }
            if (results.isEmpty()) {
                Pattern alt = Pattern.compile("<a[^>]*href=\"(/voddetail/\\d+/)\"[^>]*>(?:\\s*<[^>]*>)*\\s*([^<]+)\\s*(?:</[^>]*>\\s*)*</a>");
                Matcher ma = alt.matcher(html);
                while (ma.find() && results.size() < 10)
                    results.add(new Show(ma.group(1), cleanTitle(ma.group(2)), "", ""));
            }
            onSuccess();
        } catch (Exception e) { onFail(); }
        return results;
    }

    // ══════ 详情 ══════

    public ShowDetail detail(String vodId) {
        try {
            String html = get(BASE + "/voddetail/" + vodId + "/");
            if (html == null) { onFail(); return null; }
            // 元数据
            String title = "", poster = "", info = "";
            Matcher tm = Pattern.compile("<h1[^>]*>([^<]+)</h1>").matcher(html);
            if (tm.find()) title = cleanTitle(tm.group(1));
            Matcher pm = Pattern.compile("<img[^>]*src=\"([^\"]+)\"[^>]*>").matcher(html);
            if (pm.find()) poster = pm.group(1);
            Matcher im = Pattern.compile("<span[^>]*class=\"[^\"]*info[^\"]*\"[^>]*>([^<]*)").matcher(html);
            if (im.find()) info = im.group(1).trim();

            // 资源线
            List<SourceLine> sources = new ArrayList<>();
            Matcher sm = Pattern.compile("sid=\"(\\d+)\"[^>]*>([^<]+)<").matcher(html);
            while (sm.find()) sources.add(new SourceLine(Integer.parseInt(sm.group(1)), sm.group(2).trim()));

            // 选集
            List<Episode> episodes = new ArrayList<>();
            Matcher em = Pattern.compile("<a[^>]*href=\"(/vodplay/" + vodId + "-(\\d+)-(\\d+)\\.html)\"[^>]*>([^<]*)</a>").matcher(html);
            while (em.find()) {
                int nid = Integer.parseInt(em.group(3));
                String text = em.group(4).trim();
                if (text.isEmpty()) text = "第" + nid + "话";
                episodes.add(new Episode(nid, text, em.group(1)));
            }
            onSuccess();
            return new ShowDetail(vodId, title, poster, info, sources, episodes);
        } catch (Exception e) { onFail(); return null; }
    }

    // ══════ 派生查询 ══════

    public int latestEpisode(String vodId) {
        ShowDetail d = detail(vodId);
        return d != null ? d.latestEpisode() : 0;
    }

    public PlayResult playUrl(String vodId, int nid) {
        ShowDetail d = detail(vodId);
        if (d == null) return new PlayResult(BASE + "/voddetail/" + vodId + "/", false);
        if (d.sources.isEmpty()) return new PlayResult(BASE + "/vodplay/" + vodId + "-1-" + nid + ".html", true);
        int sid = d.sources.get(0).sid; // 第一条资源线
        return new PlayResult(BASE + "/vodplay/" + vodId + "-" + sid + "-" + nid + ".html", true);
    }

    // ══════ 变更哨兵 ══════

    public boolean isStructureChanged() { return structureChanged; }
    public int getConsecutiveFailures() { return consecutiveFailures; }

    private void onFail() {
        consecutiveFailures++;
        if (consecutiveFailures >= 5) structureChanged = true;
    }
    private void onSuccess() { consecutiveFailures = 0; }

    private String cleanTitle(String t) {
        if (t == null) return "";
        return t.replaceAll("<[^>]*>", "").trim();
    }

    // ══════ HTTP ══════

    private String get(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36");
            int code = conn.getResponseCode();
            if (code != 200) return null;
            BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            r.close();
            return sb.toString();
        } catch (Exception e) { return null; }
        finally { if (conn != null) conn.disconnect(); }
    }
}
