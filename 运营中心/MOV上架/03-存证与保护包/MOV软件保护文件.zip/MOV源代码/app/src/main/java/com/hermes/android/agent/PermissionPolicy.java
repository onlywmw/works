package com.hermes.android.agent;

import java.util.Set;

/**
 * PermissionPolicy — 统一权限入口 (TOOL_ENV_UPGRADE Phase 9)。
 *
 * 替代散落的 4 处权限检查(Tool.approval/RulesManager/DevicePolicy/allowedPaths)。
 * Manifest.category 路由, 新工具注册不用自己写权限逻辑。
 */
public class PermissionPolicy {

    public static CheckResult check(ToolRegistry.Tool tool, org.json.JSONObject args, Set<String> allowedPaths) {
        ToolRegistry.Manifest m = tool.manifest;
        String cat = m != null ? m.category : "unknown";
        switch (cat) {
            case "io": {
                String path = args.optString("path");
                if (!allowedPaths.contains(path)) return CheckResult.deny("此文件不在批准计划内");
                if (com.hermes.android.RulesManager.get().isFilePathProtected(path))
                    return CheckResult.deny("受保护路径: " + path);
                return CheckResult.allow();
            }
            case "exec": {
                String cmd = args.optString("cmd");
                if (com.hermes.android.RulesManager.isRedline(cmd)) return CheckResult.deny("红线命令，禁止执行");
                if (com.hermes.android.RulesManager.get().isShellConfirmRequired(cmd))
                    return CheckResult.confirm("需确认: " + cmd);
                return CheckResult.allow();
            }
            case "device": {
                String cap = ToolRegistry.DevicePolicy.capabilityOf(args.optString("text"));
                String deny = null;
                try {
                    deny = new ToolRegistry.DevicePolicy(java.util.Collections.emptySet()).check(cap);
                } catch (Exception e) { deny = "无法解析指令"; }
                if (deny != null) return CheckResult.deny(deny);
                return CheckResult.allow();
            }
            default: return CheckResult.allow();
        }
    }

    public static class CheckResult {
        public enum Action { ALLOW, DENY, CONFIRM }
        public final Action action; public final String reason;
        private CheckResult(Action a, String r) { action = a; reason = r; }
        public static CheckResult allow() { return new CheckResult(Action.ALLOW, null); }
        public static CheckResult deny(String r) { return new CheckResult(Action.DENY, r); }
        public static CheckResult confirm(String r) { return new CheckResult(Action.CONFIRM, r); }
    }
}
