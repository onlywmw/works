/* ── MOV · 我的能力（职业体系 G1a 前端，G0 relay 已就绪）
   入口：设置 › 账户管理 › 我的能力（renderAbility 三级页）
   桥契约（BridgeFactory，已就绪）：
     HermesBridge.a2aRegisterPro(deviceId, name, role, professionsJson, cbId)
       —— 上报 role=pro + professions（职业注册表，relay 侧 G0 已扩展）
     HermesBridge.a2aRegistered() / a2aDeviceId()
     HermesBridge.a2aQueryPro(craft, radiusKm, online, cbId)（G1b 用）
   状态：localStorage 'mv:gig:profs'（非敏感：craft/form/radiusKm/online 列表）
         localStorage 'mv:gig:declared'（本地声明降级，G1 认证闸降级口径）
   工种 11 枚举（DESIGN_GIG_REGISTRY §二分类表）：form 按工种自动推导，半径默认 2km
   buyer 无新入口：消费走对话 gig.*（G5）——本页只管 pro 自管理。 */
window.MovGig = (function() {

  /* ═══ 工种枚举（11 项，对齐 relay CRAFTS + DESIGN 分类表） ═══ */

  var CRAFTS = [
    { craft:'shop',     name:'卖货',   icon:'🏪', form:'instant',     cat:'卖货型' },
    { craft:'food',     name:'餐饮',   icon:'🍜', form:'instant',     cat:'卖货型' },
    { craft:'delivery', name:'外卖跑腿', icon:'🛵', form:'instant',   cat:'运力型' },
    { craft:'express',  name:'快递',   icon:'📦', form:'instant',     cat:'运力型' },
    { craft:'taxi',     name:'出租车', icon:'🚕', form:'instant',     cat:'运力型' },
    { craft:'barber',   name:'理发师', icon:'💈', form:'appointment', cat:'手艺·到店' },
    { craft:'nail',     name:'美甲师', icon:'💅', form:'appointment', cat:'手艺·到店' },
    { craft:'massage',  name:'按摩',   icon:'💆', form:'appointment', cat:'手艺·到店' },
    { craft:'tutor',    name:'家教',   icon:'📚', form:'appointment', cat:'手艺·上门' },
    { craft:'repair',   name:'维修',   icon:'🔧', form:'appointment', cat:'手艺·上门' },
    { craft:'cleaning', name:'保洁',   icon:'🧹', form:'appointment', cat:'手艺·上门' }
  ];

  /* ═══ 状态（非敏感，localStorage 可存） ═══ */

  var KEY_PROFS = 'mv:gig:profs';
  var KEY_DECLARED = 'mv:gig:declared';
  var KEY_PENDING = 'mv:gig:pending';   // 开通页未提交的多选草稿

  var profs = [];        // [{craft, form, radiusKm, online}]
  var declared = false;  // 本地声明（个人认证降级）
  var pending = [];      // 开通页多选草稿
  var adding = false;    // 添加工种模式（已开通者重进开通页）
  var registered = false;

  function load() {
    try {
      profs = JSON.parse(localStorage.getItem(KEY_PROFS) || '[]');
      declared = localStorage.getItem(KEY_DECLARED) === '1';
      pending = JSON.parse(localStorage.getItem(KEY_PENDING) || '[]');
    } catch(e) { profs = []; declared = false; pending = []; }
    try { registered = !!(window.HermesBridge && HermesBridge.a2aRegistered && HermesBridge.a2aRegistered()); } catch(e) { registered = false; }
  }
  function saveProfs() {
    try { localStorage.setItem(KEY_PROFS, JSON.stringify(profs)); } catch(e) {}
  }
  function savePending() {
    try { localStorage.setItem(KEY_PENDING, JSON.stringify(pending)); } catch(e) {}
  }

  /* ═══ 工具 ═══ */

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }
  function toast(m) { try { if (typeof B !== 'undefined' && B.toast) B.toast(m); } catch(e) {} }
  function refresh() { try { NewFace.redrawSettings(); } catch(e) {} }
  function craftInfo(craft) {
    for (var i = 0; i < CRAFTS.length; i++) if (CRAFTS[i].craft === craft) return CRAFTS[i];
    return null;
  }

  /* ═══ 摘要（账户管理行右侧） ═══ */

  function summary() {
    if (!profs.length) return '未开通';
    var on = 0;
    profs.forEach(function(p) { if (p.online) on++; });
    var names = profs.slice(0, 2).map(function(p) {
      var c = craftInfo(p.craft);
      return c ? c.name : p.craft;
    }).join('·');
    if (profs.length > 2) names += '…';
    return names + (on > 0 ? '·接单中' : '·休息中');
  }

  /* ═══ 渲染：我的能力三级页 ═══ */

  function renderAbility() {
    var html = '<div class="set-topbar"><span class="set-back" onclick="NewFace.settingsBack()">‹</span>'
      + '<span class="set-ttl">我的能力</span></div>';

    if (!profs.length || adding) {
      html += renderOpenPage();       // 未开通 → 开通页（只选工种）；添加工种 → 同页预选
    } else {
      html += renderListPage();       // 已开通 → 工种列表 + 添加工种 + 日对账占位
    }
    return html;
  }

  /* 开通页：11 工种宫格多选 + 一键开通（服务形态自动推导，半径默认 2km） */
  function renderOpenPage() {
    var html = '<div class="set-sub" style="padding-top:12px">选择你的职业能力（可多选）</div>'
      + '<div class="set-group">';
    html += '<div class="mk-hint" style="padding:0 12px 8px;font-size:11px;color:var(--ink-3,#888)">服务形态按工种自动推导（运力/卖货=即时单，手艺=预约单）；服务半径默认 2km，开通后在工种详情可改。</div>';
    html += '<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px;padding:0 12px 12px">';
    CRAFTS.forEach(function(c) {
      var on = pending.indexOf(c.craft) >= 0;
      html += '<div class="gig-craft' + (on ? ' on' : '') + '" style="border:1px solid ' + (on ? 'var(--accent,#3b82f6)' : 'rgba(0,0,0,.12)') + ';border-radius:12px;padding:12px;cursor:pointer;text-align:center;background:' + (on ? 'rgba(59,130,246,.06)' : 'var(--card,#fff)') + '"'
        + ' onclick="MovGig.togglePending(\'' + c.craft + '\')">'
        + '<div style="font-size:22px">' + c.icon + '</div>'
        + '<div style="font-weight:600;margin-top:4px">' + c.name + '</div>'
        + '<div style="font-size:11px;color:var(--ink-3,#888)">' + c.cat + ' · ' + (c.form === 'instant' ? '即时单' : '预约单') + '</div>'
        + (on ? '<div style="font-size:12px;color:var(--accent,#3b82f6);margin-top:4px">✓ 已选</div>' : '')
        + '</div>';
    });
    html += '</div></div>';

    /* 前置闸：个人认证（v1 本地声明降级） */
    var gate = declared;
    html += '<div class="set-group">'
      + '<div class="set-row static"><div class="t">个人认证</div><div class="v">' + (declared ? '✓ 已声明' : '未完成') + '</div></div>'
      + (declared
          ? '<div class="note">已本地声明，开通后职业能力即时生效（短信实名通道接入后自动升级）。</div>'
          : '<div class="note">未认证：v1 以本地声明降级（认证徽章不点亮）。</div>')
      + '</div>';

    html += '<div class="mk-buybar" style="margin-top:10px;display:flex;gap:8px">'
      + '<span class="bb ghost" style="flex:1;text-align:center;padding:10px 0;border-radius:10px;border:1px solid rgba(0,0,0,.15)" onclick="MovGig.declare()">本地声明</span>'
      + '<span id="gigOpenBtn" class="bb solid" style="flex:2;text-align:center;padding:10px 0;border-radius:10px;' + (gate ? 'background:var(--accent,#3b82f6);color:#fff;font-weight:600' : 'background:#bbb;color:#fff') + '" onclick="MovGig.open()">开通</span>'
      + '</div>';
    if (!gate) html += '<div class="note">请先完成「本地声明」解锁开通。</div>';
    return html;
  }

  /* 已开通：工种列表（行=图标+名+开关）+ 添加工种 + 日对账占位 */
  function renderListPage() {
    var html = '<div class="set-group">';
    profs.forEach(function(p) {
      var c = craftInfo(p.craft) || { name:p.craft, icon:'🛠' };
      html += '<div class="set-row static"><div class="t">' + c.icon + ' ' + c.name
        + '<div class="sub">' + (c.form === 'instant' ? '即时单' : '预约单') + ' · 半径 ' + (p.radiusKm || 2) + 'km</div></div>'
        + '<div class="v"><span class="switch' + (p.online ? ' on' : '') + '" onclick="MovGig.toggleOnline(\'' + p.craft + '\')"></span></div></div>';
    });
    html += '</div>'
      + '<div class="mk-buybar" style="margin-top:10px">'
      + '<span class="dact" onclick="MovGig.addCraft()">＋ 添加工种</span></div>'
      + '<div class="set-group" style="margin-top:10px">'
      + '<div class="set-row static"><div class="t">日对账</div><div class="v">G4 落地后开通</div></div>'
      + '</div>'
      + '<div class="note">开关即接单状态（不设总开关）：任一工种开 = 接单中；状态实时上报职业注册表。</div>';
    return html;
  }

  /* ═══ 动作 ═══ */

  function togglePending(craft) {
    var i = pending.indexOf(craft);
    if (i >= 0) pending.splice(i, 1); else pending.push(craft);
    savePending();
    refresh();
  }

  function declare() {
    try { localStorage.setItem(KEY_DECLARED, '1'); declared = true; } catch(e) {}
    toast('已本地声明');
    refresh();
  }

  /** 一键开通：a2aRegisterPro 上报 role=pro + professions → 本地落盘 */
  function open() {
    if (!declared) { toast('请先完成本地声明'); return; }
    if (!pending.length) { toast('请至少选择一个工种'); return; }
    if (!window.HermesBridge || !window.HermesBridge.a2aRegisterPro) { toast('注册桥不可用'); return; }
    var list = [];
    pending.forEach(function(craft) {
      var c = craftInfo(craft);
      list.push({ craft: craft, form: c ? c.form : 'instant', radiusKm: 2, online: true });
    });
    var btn = document.getElementById('gigOpenBtn');
    if (btn) btn.textContent = '开通中…';
    var id = (typeof nextCbId === 'function') ? nextCbId() : ('cb' + Date.now());
    if (typeof _cbMap !== 'undefined') _cbMap[id] = function(r) {
      if (btn) btn.textContent = '开通';
      if (r && r.ok) {
        profs = list;
        saveProfs();
        pending = [];
        savePending();
        adding = false;
        toast('已开通，开始接单');
        refresh();
      } else {
        toast((r && r.error && r.error.msg) ? ('开通失败：' + r.error.msg) : '开通失败');
      }
    };
    var deviceId = '';
    try { deviceId = HermesBridge.a2aDeviceId ? HermesBridge.a2aDeviceId() : ''; } catch(e) {}
    HermesBridge.a2aRegisterPro(deviceId || 'mov-pro', '本地职业人', 'pro', JSON.stringify(list), id);
  }

  /** 工种开关（接单状态）→ 更新本地 + 重上报 */
  function toggleOnline(craft) {
    var found = null;
    profs.forEach(function(p) { if (p.craft === craft) found = p; });
    if (!found) return;
    found.online = !found.online;
    saveProfs();
    if (window.HermesBridge && HermesBridge.a2aRegisterPro) {
      var id = (typeof nextCbId === 'function') ? nextCbId() : ('cb' + Date.now());
      if (typeof _cbMap !== 'undefined') _cbMap[id] = function(r) {
        if (r && r.ok) toast(found.online ? '已开始接单' : '已暂停接单');
        else { found.online = !found.online; saveProfs(); toast('状态上报失败，已回滚'); }
        refresh();
      };
      var deviceId = '';
      try { deviceId = HermesBridge.a2aDeviceId ? HermesBridge.a2aDeviceId() : ''; } catch(e) {}
      HermesBridge.a2aRegisterPro(deviceId || 'mov-pro', '本地职业人', 'pro', JSON.stringify(profs), id);
    }
    refresh();
  }

  /** 添加工种：进开通页（预选已开通的，新增可叠加；开通按钮全量上报） */
  function addCraft() {
    adding = true;
    pending = [];
    profs.forEach(function(p) { pending.push(p.craft); });
    savePending();
    refresh();
  }

  /* ═══ after：载入状态 ═══ */

  function after() {
    load();
    /* 已开通但 relay 侧可能未同步（重启后）→ 补一次上报（幂等） */
    if (profs.length && window.HermesBridge && HermesBridge.a2aRegisterPro) {
      var id = (typeof nextCbId === 'function') ? nextCbId() : ('cb' + Date.now());
      if (typeof _cbMap !== 'undefined') _cbMap[id] = function() {};
      var deviceId = '';
      try { deviceId = HermesBridge.a2aDeviceId ? HermesBridge.a2aDeviceId() : ''; } catch(e) {}
      HermesBridge.a2aRegisterPro(deviceId || 'mov-pro', '本地职业人', 'pro', JSON.stringify(profs), id);
    }
  }

  /* ═══ 导出 ═══ */

  return {
    renderAbility: renderAbility, after: after, summary: summary,
    togglePending: togglePending, declare: declare, open: open,
    toggleOnline: toggleOnline, addCraft: addCraft
  };
})();
