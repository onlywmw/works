package com.hermes.android.toolprovider;

import android.Manifest;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.CalendarContract;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;

import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.agent.ToolRegistry.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * ExtraToolProvider — 补充工具 (相机/定位/日历/联系人/应用管理/分享/蓝牙/WiFi)。
 * 需要 SystemToolProvider.init(ctx) 和 HermesToolProvider.init(ctx) 已调用。
 */
public class ExtraToolProvider implements ToolProvider {

    private static final String TAG = "ExtraTools";
    private static Context appContext;

    public static void init(Context ctx) { appContext = ctx.getApplicationContext(); }

    @Override public String id() { return "extra"; }

    @Override
    public List<Tool> discover() {
        List<Tool> list = new ArrayList<>();
        if (appContext == null) return list;

        // ═══ camera.capture — 拍照 ═══
        list.add(new Tool("camera.capture",
            "调用系统相机拍照，返回照片保存路径。需要 CAMERA 权限",
            null, a -> {
                if (appContext.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                    return new Result(false, "无 CAMERA 权限，请在设置中授权");
                try {
                    File dir = new File(appContext.getExternalFilesDir(null), "photos");
                    dir.mkdirs();
                    String name = "MOV_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg";
                    File photo = new File(dir, name);
                    Intent take = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    take.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photo));
                    take.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    appContext.startActivity(take);
                    return new Result(true, "相机已启动，照片将保存到 " + photo.getAbsolutePath(),
                        photo.getAbsolutePath());
                } catch (Exception e) {
                    return new Result(false, "启动相机失败: " + e.getMessage());
                }
            }, "native", "write", "always", false, 30, "media",
            new ParamDef[]{
                new ParamDef("note", "string", false, "", "照片备注（写入 EXIF 需要额外库，暂仅用于日志）"),
            },
            "成功: 相机已启动 + 文件路径 | 失败: 错误原因",
            null,
            new String[]{"拍照会切到相机 App，拍完后返回 MOV", "照片保存到外部存储 photos/ 目录"},
            2000,
            new ToolRegistry.Manifest("拍照", "low", "打开系统相机拍照", false, "media"),
            null));

        // ═══ qr.scan — 扫码 ═══
        list.add(new Tool("qr.scan",
            "扫描二维码/条形码（需相机权限 + Google Play Services 或 ML Kit）",
            null, a -> {
                if (appContext.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                    return new Result(false, "无 CAMERA 权限");
                // QR 扫描需要 ML Kit 或 ZXing 库；暂无独立实现，引导用 shell.exec + zbar
                return new Result(false,
                    "QR 扫描暂未集成原生 ML Kit。替代方案: shell.exec 'zbarcam --raw /dev/video0' 或用 camera.capture 拍照后 shell.exec 'zbarimg photo.jpg'");
            }, "native", "write", "always", false, 30, "media",
            new ParamDef[]{
                new ParamDef("format", "string", false, "auto", "auto / qr / barcode"),
            },
            "扫码结果文本 | 失败原因",
            null,
            new String[]{"需要 Google Play Services (ML Kit) 或安装 zbar-tools (apt install zbar-tools)"},
            1000,
            new ToolRegistry.Manifest("扫码", "low", "扫描二维码/条形码", false, "media"),
            null));

        // ═══ location.get — 获取定位 ═══
        list.add(new Tool("location.get",
            "获取当前 GPS 定位（经纬度+精度）。需要位置权限，首次调用可能耗时 5-30 秒",
            null, a -> {
                if (appContext.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && appContext.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                    return new Result(false, "无位置权限");
                try {
                    LocationManager lm = (LocationManager) appContext.getSystemService(Context.LOCATION_SERVICE);
                    if (lm == null) return new Result(false, "LocationManager 不可用");
                    // 先取缓存的
                    Location best = null;
                    for (String prov : lm.getProviders(false)) {
                        Location l = lm.getLastKnownLocation(prov);
                        if (l != null && (best == null || l.getAccuracy() < best.getAccuracy())) best = l;
                    }
                    if (best != null && System.currentTimeMillis() - best.getTime() < 120_000) {
                        JSONObject o = new JSONObject();
                        o.put("lat", best.getLatitude());
                        o.put("lng", best.getLongitude());
                        o.put("accuracy", best.getAccuracy());
                        o.put("provider", best.getProvider());
                        o.put("ageSec", (System.currentTimeMillis() - best.getTime()) / 1000);
                        return new Result(true, o.toString(2));
                    }
                    // 缓存过期 → 单次请求
                    final CountDownLatch latch = new CountDownLatch(1);
                    final Location[] result = new Location[1];
                    LocationListener listener = new LocationListener() {
                        @Override public void onLocationChanged(Location loc) { result[0] = loc; latch.countDown(); }
                        @Override public void onProviderDisabled(String p) {}
                        @Override public void onProviderEnabled(String p) {}
                    };
                    try {
                        lm.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, listener, new Handler(Looper.getMainLooper()).getLooper());
                    } catch (Exception e) {
                        try { lm.requestSingleUpdate(LocationManager.GPS_PROVIDER, listener, new Handler(Looper.getMainLooper()).getLooper()); }
                        catch (Exception e2) { return new Result(false, "无法请求定位: " + e2.getMessage()); }
                    }
                    if (latch.await(25, TimeUnit.SECONDS) && result[0] != null) {
                        JSONObject o = new JSONObject();
                        o.put("lat", result[0].getLatitude());
                        o.put("lng", result[0].getLongitude());
                        o.put("accuracy", result[0].getAccuracy());
                        o.put("provider", result[0].getProvider());
                        return new Result(true, o.toString(2));
                    }
                    return best != null ? new Result(true, "使用过期缓存(" + (System.currentTimeMillis() - best.getTime())/1000 + "s 前): "
                        + best.getLatitude() + "," + best.getLongitude())
                        : new Result(false, "定位超时 (25s)，请确保 GPS 已开启且在室外");
                } catch (Exception e) {
                    return new Result(false, "定位失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 30, "device",
            new ParamDef[]{},
            "成功: {\"lat\":..., \"lng\":..., \"accuracy\":..., \"provider\":..., \"ageSec\":...} | 失败: 错误原因",
            null,
            new String[]{"室内或无 GPS 信号时无法定位", "首次定位可能耗时 10-30 秒", "会先尝试 2 分钟内的缓存定位"},
            1000,
            new ToolRegistry.Manifest("获取定位", "medium", "读取 GPS 坐标", false, "device"),
            null));

        // ═══ calendar.add — 添加日历事件 ═══
        list.add(new Tool("calendar.add",
            "添加日历事件（通过系统日历 Intent，用户确认后写入）",
            null, a -> {
                String title = a.optString("title", "");
                if (title.isEmpty()) return new Result(false, "标题为空");
                try {
                    Intent intent = new Intent(Intent.ACTION_INSERT);
                    intent.setData(CalendarContract.Events.CONTENT_URI);
                    intent.putExtra(CalendarContract.Events.TITLE, title);
                    String desc = a.optString("desc", "");
                    if (!desc.isEmpty()) intent.putExtra(CalendarContract.Events.DESCRIPTION, desc);
                    String location = a.optString("location", "");
                    if (!location.isEmpty()) intent.putExtra(CalendarContract.Events.EVENT_LOCATION, location);
                    long startMs = a.optLong("startMs", System.currentTimeMillis() + 3600_000);
                    intent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMs);
                    long endMs = a.optLong("endMs", startMs + 3600_000);
                    intent.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMs);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    appContext.startActivity(intent);
                    return new Result(true, "日历已打开: " + title + " (" + new SimpleDateFormat("MM-dd HH:mm", Locale.US).format(new Date(startMs)) + ")");
                } catch (Exception e) {
                    return new Result(false, "打开日历失败: " + e.getMessage());
                }
            }, "native", "write", "none", true, 10, "system",
            new ParamDef[]{
                new ParamDef("title", "string", true, "", "事件标题"),
                new ParamDef("desc", "string", false, "", "事件描述"),
                new ParamDef("location", "string", false, "", "地点"),
                new ParamDef("startMs", "int", false, "默认 1 小时后", "开始时间戳(毫秒)"),
                new ParamDef("endMs", "int", false, "默认 startMs+1h", "结束时间戳(毫秒)"),
            },
            "成功: 日历已打开 | 失败: 错误原因",
            null,
            new String[]{"需要用户手动确认保存", "startMs/endMs 为 Unix 毫秒时间戳"},
            1000,
            new ToolRegistry.Manifest("添加日历", "low", "打开日历添加事件", false, "io"),
            null));

        // ═══ calendar.today — 查看今日日历 ═══
        list.add(new Tool("calendar.today",
            "查看今日/本周日历事件。需要 READ_CALENDAR 权限",
            null, a -> {
                if (appContext.checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED)
                    return new Result(false, "无 READ_CALENDAR 权限，请在设置中授权");
                try {
                    int days = a.optInt("days", 1);
                    if (days < 1 || days > 7) days = 1;
                    long now = System.currentTimeMillis();
                    long end = now + days * 86400_000L;
                    Uri uri = CalendarContract.Events.CONTENT_URI;
                    String[] proj = {CalendarContract.Events.TITLE, CalendarContract.Events.DTSTART,
                        CalendarContract.Events.DTEND, CalendarContract.Events.EVENT_LOCATION};
                    String sel = CalendarContract.Events.DTSTART + " >= ? AND " + CalendarContract.Events.DTSTART + " < ?";
                    String[] args = {String.valueOf(now), String.valueOf(end)};
                    Cursor cur = appContext.getContentResolver().query(uri, proj, sel, args,
                        CalendarContract.Events.DTSTART + " ASC");
                    if (cur == null) return new Result(true, "无日历事件");
                    StringBuilder sb = new StringBuilder("近 " + days + " 天日历:\n");
                    int n = 0;
                    SimpleDateFormat tf = new SimpleDateFormat("MM-dd HH:mm", Locale.US);
                    while (cur.moveToNext()) {
                        String t = cur.getString(0);
                        long s = cur.getLong(1), e = cur.getLong(2);
                        String loc = cur.getString(3);
                        sb.append("  ").append(tf.format(new Date(s)));
                        if (s != e) sb.append("-").append(tf.format(new Date(e)));
                        sb.append("  ").append(t != null ? t : "(无标题)");
                        if (loc != null && !loc.isEmpty()) sb.append(" @").append(loc);
                        sb.append("\n");
                        if (++n >= 50) { sb.append("  …(仅显示前 50 条)\n"); break; }
                    }
                    cur.close();
                    if (n == 0) sb.append("  (空)\n");
                    return new Result(true, sb.toString());
                } catch (Exception e) {
                    return new Result(false, "读取日历失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 10, "system",
            new ParamDef[]{
                new ParamDef("days", "int", false, "默认 1", "查询天数(1-7)"),
            },
            "成功: 日历事件列表 | 失败: 无权限/错误",
            null,
            new String[]{"需要 READ_CALENDAR 权限", "最多返回 50 条", "days 超过 7 会被钳制为 1"},
            2000,
            new ToolRegistry.Manifest("今日日历", "low", "查看日历事件", false, "io"),
            null));

        // ═══ contacts.search — 搜索联系人 ═══
        list.add(new Tool("contacts.search",
            "搜索联系人（姓名/电话模糊匹配）。需要 READ_CONTACTS 权限",
            null, a -> {
                if (appContext.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
                    return new Result(false, "无 READ_CONTACTS 权限");
                String query = a.optString("query", "");
                try {
                    ContentResolver cr = appContext.getContentResolver();
                    Uri uri = ContactsContract.Contacts.CONTENT_URI;
                    String sel = ContactsContract.Contacts.DISPLAY_NAME_PRIMARY + " LIKE ?";
                    String[] args = {"%" + query + "%"};
                    String[] proj = {ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
                        ContactsContract.Contacts.HAS_PHONE_NUMBER};
                    String sort = ContactsContract.Contacts.DISPLAY_NAME_PRIMARY + " ASC";
                    Cursor cur = cr.query(uri, proj, query.isEmpty() ? null : sel, query.isEmpty() ? null : args, sort);
                    if (cur == null) return new Result(true, "无联系人");
                    StringBuilder sb = new StringBuilder();
                    int n = 0, limit = a.optInt("limit", 20);
                    while (cur.moveToNext() && n < limit) {
                        String name = cur.getString(1);
                        sb.append(name != null ? name : "(无名)");
                        if (cur.getInt(2) > 0) {
                            Cursor phones = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                                new String[]{cur.getString(0)}, null);
                            if (phones != null) {
                                List<String> nums = new ArrayList<>();
                                while (phones.moveToNext()) nums.add(phones.getString(0));
                                phones.close();
                                if (!nums.isEmpty()) sb.append(" — ").append(String.join(" / ", nums));
                            }
                        }
                        sb.append("\n");
                        n++;
                    }
                    cur.close();
                    if (n == 0) return new Result(true, "未找到匹配联系人");
                    if (n >= limit) sb.append("…(仅显示前 " + limit + " 条)");
                    return new Result(true, sb.toString());
                } catch (Exception e) {
                    return new Result(false, "搜索联系人失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 10, "message",
            new ParamDef[]{
                new ParamDef("query", "string", false, "空=全部", "搜索关键词(姓名模糊匹配)"),
                new ParamDef("limit", "int", false, "默认 20", "最大返回条数"),
            },
            "成功: 姓名 — 号码 列表 | 失败: 无权限",
            null,
            new String[]{"需要 READ_CONTACTS 权限", "只读不写", "空查询返回全部联系人(受 limit 限制)"},
            2000,
            new ToolRegistry.Manifest("搜索联系人", "medium", "搜索通讯录", false, "io"),
            null));

        // ═══ app.list — 列出已安装应用 ═══
        list.add(new Tool("app.list",
            "列出已安装的应用（可按关键词过滤）",
            null, a -> {
                String filter = a.optString("filter", "").toLowerCase(Locale.US);
                try {
                    PackageManager pm = appContext.getPackageManager();
                    List<ApplicationInfo> apps = pm.getInstalledApplications(0);
                    StringBuilder sb = new StringBuilder();
                    int n = 0, limit = a.optInt("limit", 30);
                    for (ApplicationInfo ai : apps) {
                        String label = pm.getApplicationLabel(ai).toString();
                        if (!filter.isEmpty() && !label.toLowerCase(Locale.US).contains(filter)
                            && !ai.packageName.toLowerCase(Locale.US).contains(filter)) continue;
                        boolean sys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                        sb.append(sys ? "[S] " : "[U] ").append(label).append("  (").append(ai.packageName).append(")\n");
                        if (++n >= limit) { sb.append("…(仅显示前 " + limit + " 条)\n"); break; }
                    }
                    if (n == 0) sb.append("无匹配应用");
                    return new Result(true, sb.toString());
                } catch (Exception e) {
                    return new Result(false, "获取应用列表失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 5, "app",
            new ParamDef[]{
                new ParamDef("filter", "string", false, "空=全部", "过滤关键词(匹配应用名或包名)"),
                new ParamDef("limit", "int", false, "默认 30", "最大返回条数"),
            },
            "成功: [S]=系统/[U]=用户 应用名 (包名) 列表",
            null,
            new String[]{"[S] = 系统应用, [U] = 用户安装", "filter 为空时可能返回数百条(受 limit 限制)"},
            2000,
            new ToolRegistry.Manifest("应用列表", "low", "列出已安装应用", false, "io"),
            null));

        // ═══ share.text — 分享文本 ═══
        list.add(new Tool("share.text",
            "通过系统分享面板发送文本到其他 App（微信/邮件/便签等）",
            null, a -> {
                String text = a.optString("text", "");
                if (text.isEmpty()) return new Result(false, "内容为空");
                try {
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("text/plain");
                    share.putExtra(Intent.EXTRA_TEXT, text);
                    String subject = a.optString("subject", "");
                    if (!subject.isEmpty()) share.putExtra(Intent.EXTRA_SUBJECT, subject);
                    share.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    appContext.startActivity(Intent.createChooser(share, "分享到…"));
                    return new Result(true, "分享面板已打开");
                } catch (Exception e) {
                    return new Result(false, "分享失败: " + e.getMessage());
                }
            }, "native", "write", "none", true, 10, "share",
            new ParamDef[]{
                new ParamDef("text", "string", true, "", "要分享的文本内容"),
                new ParamDef("subject", "string", false, "", "分享标题（部分 App 支持）"),
            },
            "成功: 分享面板已打开 | 失败: 错误原因",
            null,
            new String[]{"会弹出系统分享面板，需用户手动选择目标 App"},
            1000,
            new ToolRegistry.Manifest("分享文本", "low", "分享文本到其他 App", false, "io"),
            null));

        // ═══ wifi.scan — 扫描 Wi-Fi ═══
        list.add(new Tool("wifi.scan",
            "扫描附近 Wi-Fi 网络。需要 ACCESS_WIFI_STATE 权限",
            null, a -> {
                if (appContext.checkSelfPermission(Manifest.permission.ACCESS_WIFI_STATE) != PackageManager.PERMISSION_GRANTED)
                    return new Result(false, "无 Wi-Fi 权限");
                try {
                    WifiManager wm = (WifiManager) appContext.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    if (wm == null) return new Result(false, "WifiManager 不可用");
                    if (!wm.isWifiEnabled()) return new Result(false, "Wi-Fi 未开启");
                    List<ScanResult> results = wm.getScanResults();
                    StringBuilder sb = new StringBuilder("附近 Wi-Fi:\n");
                    java.util.Collections.sort(results, (a1, a2) -> Integer.compare(a2.level, a1.level));
                    int limit = Math.min(results.size(), a.optInt("limit", 15));
                    for (int i = 0; i < limit; i++) {
                        ScanResult r = results.get(i);
                        sb.append("  ").append(r.SSID).append("  ").append(r.level).append("dBm");
                        if (!r.BSSID.equals("00:00:00:00:00:00")) sb.append("  (").append(r.BSSID).append(")");
                        sb.append("\n");
                    }
                    return new Result(true, sb.toString());
                } catch (Exception e) {
                    return new Result(false, "Wi-Fi 扫描失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 10, "device",
            new ParamDef[]{
                new ParamDef("limit", "int", false, "默认 15", "最大返回条数"),
            },
            "成功: SSID + 信号强度(dBm) + MAC 列表 | 失败: 未开启/无权限",
            null,
            new String[]{"需要 Wi-Fi 已开启", "Android 10+ 需位置权限才能获取 SSID", "按信号强度降序排列"},
            2000,
            new ToolRegistry.Manifest("Wi-Fi 扫描", "low", "扫描附近网络", false, "device"),
            null));

        // ═══ bluetooth.list — 列出已配对蓝牙设备 ═══
        list.add(new Tool("bluetooth.list",
            "列出已配对的蓝牙设备",
            null, a -> {
                try {
                    android.bluetooth.BluetoothAdapter ba = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
                    if (ba == null) return new Result(false, "此设备无蓝牙");
                    if (!ba.isEnabled()) return new Result(false, "蓝牙未开启");
                    java.util.Set<android.bluetooth.BluetoothDevice> devices = ba.getBondedDevices();
                    if (devices.isEmpty()) return new Result(true, "无已配对设备");
                    StringBuilder sb = new StringBuilder("已配对蓝牙设备 (" + devices.size() + "):\n");
                    for (android.bluetooth.BluetoothDevice d : devices) {
                        sb.append("  ").append(d.getName() != null ? d.getName() : "(无名)");
                        sb.append("  (").append(d.getAddress()).append(")\n");
                    }
                    return new Result(true, sb.toString());
                } catch (Exception e) {
                    return new Result(false, "蓝牙列表失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 5, "device",
            new ParamDef[]{},
            "成功: 设备名 + MAC 地址列表 | 失败: 错误原因",
            null,
            new String[]{"只列出已配对设备", "需蓝牙已开启", "Android 12+ 可能需要 BLUETOOTH_CONNECT 权限"},
            500,
            new ToolRegistry.Manifest("蓝牙列表", "low", "列出已配对蓝牙", false, "device"),
            null));

        // 注: Log 调用在单测中会抛异常,已省略
        return list;
    }
}
