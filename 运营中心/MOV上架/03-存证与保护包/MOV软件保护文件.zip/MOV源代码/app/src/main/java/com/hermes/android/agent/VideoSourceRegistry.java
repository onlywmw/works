package com.hermes.android.agent;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * VideoSourceRegistry — 视频源注册中心。
 *
 * 数据源: filesDir/video_sources.json（可热编辑、可被抽屉开关回写），
 * 首启从 assets/video_sources.json 复制。
 * 规则: status=blocked 或 enabled=false 的源不参与搜索。
 */
public class VideoSourceRegistry {

    private static final String TAG = "VideoSourceRegistry";
    private static final String FILE = "video_sources.json";

    public static class Source {
        public String id, name, type, status, scope, note, searchUrl, embedUrl;
        public boolean enabled;

        public boolean isUsable() {
            return enabled && !"blocked".equals(status);
        }
    }

    private final Context ctx;

    public VideoSourceRegistry(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    private File file() { return new File(ctx.getFilesDir(), FILE); }

    /** 版本迁移：assets 更新 → 按 id 合并（保留用户 enabled 偏好） → filesDir */
    private void ensureSeed() {
        File f = file();
        try {
            // 读 assets 版本
            JSONObject assetsJson = readJson(ctx.getAssets().open(FILE));
            // @version: "1.1" → 取 minor 作为迁移版本号
            int assetsVersion = parseVersion(assetsJson.optString("@version", "0"));

            if (f.exists()) {
                JSONObject diskJson = readJson(new FileInputStream(f));
                int diskVersion = parseVersion(diskJson.optString("@version", "0"));
                if (assetsVersion <= diskVersion) return; // 无需迁移
                // 迁移：按 id 合并，保留 enabled 偏好，更新字段
                Log.w(TAG, "迁移注册表: v" + diskVersion + " → v" + assetsVersion);
                JSONArray assetsSources = assetsJson.getJSONArray("sources");
                JSONArray diskSources = diskJson.getJSONArray("sources");
                for (int i = 0; i < assetsSources.length(); i++) {
                    JSONObject as = assetsSources.getJSONObject(i);
                    String aid = as.optString("id");
                    // 找旧条目
                    for (int j = 0; j < diskSources.length(); j++) {
                        JSONObject ds = diskSources.getJSONObject(j);
                        if (aid.equals(ds.optString("id"))) {
                            // 保留用户 enabled + 上次写回的操作字段
                            boolean userEnabled = ds.optBoolean("enabled", true);
                            // 更新 status/note/scope 等字段（不覆盖用户 enabled 偏好）
                            as.put("enabled", userEnabled);
                            // 旧条目可能被错误写回成 enabled=false → 强制拉回
                            if ("blocked".equals(as.optString("status"))) {
                                as.put("enabled", false); // blocked 源强制关
                            }
                            break;
                        }
                    }
                }
            }
            // 写回 filesDir
            String json = assetsJson.toString();
            try (FileOutputStream out = new FileOutputStream(f)) {
                out.write(json.getBytes("UTF-8"));
            }
        } catch (Exception e) {
            Log.w(TAG, "ensureSeed 失败: " + e.getMessage());
        }
    }

    private int parseVersion(String v) {
        try {
            String[] parts = v.split("\\.");
            return parts.length >= 2 ? Integer.parseInt(parts[1]) : (int)(Float.parseFloat(v) * 10);
        } catch (Exception e) { return 0; }
    }

    private JSONObject readJson(java.io.InputStream in) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        return new JSONObject(sb.toString());
    }

    public List<Source> list() {
        ensureSeed();
        List<Source> out = new ArrayList<>();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file()), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            JSONArray arr = new JSONObject(sb.toString()).getJSONArray("sources");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Source s = new Source();
                s.id = o.optString("id");
                s.name = o.optString("name");
                s.type = o.optString("type");
                s.status = o.optString("status", "limited");
                s.scope = o.optString("scope", "");
                s.note = o.optString("note", "");
                s.searchUrl = o.optString("searchUrl", "");
                s.embedUrl = o.optString("embedUrl", "");
                s.enabled = o.optBoolean("enabled", true);
                out.add(s);
            }
        } catch (Exception e) {
            Log.w(TAG, "读取失败: " + e.getMessage());
        }
        return out;
    }

    /** 某源是否可用（搜索时过滤） */
    public boolean isUsable(String id) {
        for (Source s : list()) if (s.id.equals(id)) return s.isUsable();
        return false;
    }

    /** 抽屉开关回写 enabled 字段 */
    public boolean setEnabled(String id, boolean enabled) {
        ensureSeed();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file()), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            JSONObject root = new JSONObject(sb.toString());
            JSONArray arr = root.getJSONArray("sources");
            boolean hit = false;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (id.equals(o.optString("id"))) {
                    o.put("enabled", enabled);
                    hit = true;
                }
            }
            if (!hit) return false;
            try (FileOutputStream out = new FileOutputStream(file())) {
                out.write(root.toString(2).getBytes("UTF-8"));
            }
            return true;
        } catch (Exception e) {
            Log.w(TAG, "回写失败: " + e.getMessage());
            return false;
        }
    }

    /** 列表 JSON（抽屉 UI 用） */
    public String listJson() {
        try {
            JSONArray out = new JSONArray();
            for (Source s : list()) {
                out.put(new JSONObject()
                        .put("id", s.id).put("name", s.name).put("type", s.type)
                        .put("status", s.status).put("scope", s.scope)
                        .put("note", s.note).put("enabled", s.enabled));
            }
            return new JSONObject().put("ok", true).put("sources", out).toString();
        } catch (Exception e) {
            return "{\"ok\":false}";
        }
    }
}
