package com.hermes.android.causal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * 因果哈希索引（蓝图 §3.1 数据指纹链）— 内存 HashMap + `causal.index.json` 落盘。
 *
 * 只存派生数据：`{哈希 → 原子条目}` 与 `{哈希对 → 关联强度}`，**不存原文**（原文长在 journal）。
 * 匹配 O(1)（HashMap.get），可随时从 journal 全量重建（可丢弃缓存）。
 *
 * 衰减：freshness = exp(-LAMBDA * Δ天)，LAMBDA=0.1/天（约 7 天 → 0.5）；idle 超 MAX_IDLE_DAYS 判 stale。
 * 纯 Java，零 android 依赖。
 */
public class CausalIndex {

    /** 原子 idle 超 N 天判 stale（sweep 移除写墓碑） */
    public static final int MAX_IDLE_DAYS = 7;
    /** 衰减系数（每天） */
    public static final double LAMBDA = 0.1;
    private static final long DAY_MS = 86400000L;

    /** 原子条目：hash 是键，label 是规范化原文，其余全派生。 */
    public static class AtomEntry {
        public final String hash;
        public final String label;
        public long firstTs;
        public long lastTs;
        public int count;
        public final Set<String> rules = new HashSet<>();

        AtomEntry(String hash, String label, long ts) {
            this.hash = hash;
            this.label = label;
            this.firstTs = ts;
            this.lastTs = ts;
            this.count = 1;
        }

        /** 现算新鲜度（惰性，不落字段）。 */
        public double freshness(long nowMs) {
            double days = (nowMs - lastTs) / (double) DAY_MS;
            return Math.exp(-LAMBDA * days);
        }

        public boolean isStale(long nowMs) {
            return nowMs - lastTs > MAX_IDLE_DAYS * DAY_MS;
        }
    }

    /** 关联强度对（a/b 为原子哈希，键规范化保 a<b）。 */
    public static class LinkEntry {
        public final String a;
        public final String b;
        public double strength;
        public long lastTs;

        LinkEntry(String a, String b, double strength, long ts) {
            this.a = a;
            this.b = b;
            this.strength = Math.max(0, Math.min(1, strength));
            this.lastTs = ts;
        }
    }

    private final Map<String, AtomEntry> atoms = new LinkedHashMap<>();
    private final Map<String, LinkEntry> links = new TreeMap<>();  // 键 "a<b"
    private String room;

    public void setRoom(String room) { this.room = room; }

    public Map<String, AtomEntry> atoms() { return atoms; }
    public Map<String, LinkEntry> links() { return links; }

    /** 原子哈希 → 条目（O(1)）。 */
    public AtomEntry getByHash(String hash) {
        return hash == null || hash.isEmpty() ? null : atoms.get(hash);
    }

    /** 标签 → 条目（内部现算哈希）。 */
    public AtomEntry getByAtom(String atom) {
        return getByHash(CausalHash.atomHash(atom));
    }

    /** 应用一条因果事件：三原子入索引（count++ / lastTs / 首见）。重建与增量共用。 */
    public void applyEvent(CausalEvent ev, long ts) {
        for (String atom : ev.atoms()) {
            if (atom == null || atom.isEmpty()) continue;
            String h = CausalHash.atomHash(atom);
            AtomEntry e = atoms.get(h);
            if (e == null) {
                e = new AtomEntry(h, atom, ts);
                atoms.put(h, e);
            } else {
                e.count++;
                e.lastTs = Math.max(e.lastTs, ts);
            }
        }
    }

    /** 给原子对强度增量（钳制 [0,1]）。返回新强度。 */
    public double addStrength(String a, String b, double delta, long ts) {
        String ah = CausalHash.atomHash(a);
        String bh = CausalHash.atomHash(b);
        if (ah.isEmpty() || bh.isEmpty() || ah.equals(bh)) return 0;
        // 原子须先入索引（仅被关联引用也算已见；count=0 表示未在事件中出现）
        ensureAtom(ah, CausalHash.normalize(a), ts);
        ensureAtom(bh, CausalHash.normalize(b), ts);
        String key = ah.compareTo(bh) < 0 ? ah + "<" + bh : bh + "<" + ah;
        LinkEntry l = links.get(key);
        if (l == null) {
            l = new LinkEntry(ah, bh, Math.max(0, delta), ts);
            links.put(key, l);
        } else {
            l.strength = Math.max(0, Math.min(1, l.strength + delta));
            l.lastTs = Math.max(l.lastTs, ts);
        }
        return l.strength;
    }

    /** 原子入索引（不存在才建；count=0 = 仅关联引用未在事件出现）。 */
    private void ensureAtom(String hash, String label, long ts) {
        if (!atoms.containsKey(hash)) {
            atoms.put(hash, new AtomEntry(hash, label, ts));
        }
    }

    /** 标记原子挂了某条规则（cooccur 规则命中时登记）。 */
    public void tagRule(String atom, String ruleId) {
        AtomEntry e = getByAtom(atom);
        if (e != null) e.rules.add(ruleId);
    }

    /** 惰性衰减：重算所有条目的 freshness（供输出），不主动移除（移除归 sweep）。 */
    public void decay(long nowMs) {
        // AtomEntry.freshness 现算，无需落字段；此方法保留为显式刷新点。
    }

    /** 当前 stale 原子哈希集（sweep 用）。 */
    public List<String> staleAtoms(long nowMs) {
        List<String> out = new ArrayList<>();
        for (AtomEntry e : atoms.values()) {
            if (e.isStale(nowMs)) out.add(e.hash);
        }
        return out;
    }

    /** 从索引移除原子（sweep 写墓碑后调用）。 */
    public void removeAtom(String hash) {
        atoms.remove(hash);
    }

    /** 从索引移除原子（按标签）。 */
    public void removeAtomByLabel(String label) {
        removeAtom(CausalHash.atomHash(label));
    }

    public void removeRuleFromAtoms(String ruleId) {
        for (AtomEntry e : atoms.values()) e.rules.remove(ruleId);
    }

    /** 序列化 → causal.index.json（派生缓存，可丢弃重建）。 */
    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("version", 1);
            if (room != null) o.put("room", room);
            JSONArray arr = new JSONArray();
            for (AtomEntry e : atoms.values()) {
                JSONObject a = new JSONObject();
                a.put("h", e.hash);
                a.put("label", e.label);
                a.put("firstTs", e.firstTs);
                a.put("lastTs", e.lastTs);
                a.put("count", e.count);
                if (!e.rules.isEmpty()) {
                    JSONArray rs = new JSONArray();
                    for (String r : e.rules) rs.put(r);
                    a.put("rules", rs);
                }
                arr.put(a);
            }
            o.put("atoms", arr);
            JSONArray la = new JSONArray();
            for (LinkEntry l : links.values()) {
                JSONObject lo = new JSONObject();
                lo.put("a", l.a);
                lo.put("b", l.b);
                lo.put("strength", Math.round(l.strength * 1000) / 1000.0);
                lo.put("lastTs", l.lastTs);
                la.put(lo);
            }
            o.put("links", la);
        } catch (org.json.JSONException ignored) {}
        return o;
    }

    /** 从 causal.index.json 加载（供快路径）。 */
    public void load(JSONObject o) {
        atoms.clear();
        links.clear();
        if (o == null) return;
        JSONArray arr = o.optJSONArray("atoms");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject a = arr.optJSONObject(i);
                if (a == null) continue;
                AtomEntry e = new AtomEntry(a.optString("h", ""),
                        a.optString("label", ""), a.optLong("lastTs", 0));
                e.firstTs = a.optLong("firstTs", e.firstTs);
                e.count = a.optInt("count", e.count);
                JSONArray rs = a.optJSONArray("rules");
                if (rs != null) for (int j = 0; j < rs.length(); j++) e.rules.add(rs.optString(j));
                atoms.put(e.hash, e);
            }
        }
        JSONArray la = o.optJSONArray("links");
        if (la != null) {
            for (int i = 0; i < la.length(); i++) {
                JSONObject lo = la.optJSONObject(i);
                if (lo == null) continue;
                LinkEntry l = new LinkEntry(lo.optString("a", ""), lo.optString("b", ""),
                        lo.optDouble("strength", 0), lo.optLong("lastTs", 0));
                String key = l.a.compareTo(l.b) < 0 ? l.a + "<" + l.b : l.b + "<" + l.a;
                links.put(key, l);
            }
        }
    }
}
