package com.hermes.android.bridge;

import android.webkit.JavascriptInterface;

import com.hermes.android.HermesActivity;
import com.hermes.android.ErrorReporter;
import com.hermes.android.agent.AgentLoop;
import com.hermes.android.scene.DramaSource;
import com.hermes.android.agent.EnvMap;
import com.hermes.android.agent.IntentEngine;
import com.hermes.android.agent.Journal;
import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.llama.LlamaClient;
import com.hermes.android.llama.LlamaServerManager;
import com.hermes.android.linux.HermesInstaller;
import com.hermes.android.linux.RootfsManager;
import com.hermes.android.mcp.McpClient;
import com.hermes.android.mcp.McpServerStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * BridgeKernel — MOV Kernel 新桥 (CONTRACT: Envelope v1.0 §2)。
 *
 * 两个统一入口:
 *   postCmd(json)  JS→Java 命令信号 (user_input/stop_task/resume_task/gate_respond/room_destroy/subscribe_history)
 *   query(json)    JS→Java 只读查询 (journal_tail)
 *
 * Java→JS 单一事件通道: window._movEvent(envelopeJson)
 *   channel:"journal"   已落盘事实事件
 *   channel:"transient" 瞬态事件 (token/stream_state/typing, 不落盘)
 *
 * 错误信封: 所有返回统一 {ok, data?, error?:{code, msg}}; catch 禁止返回 ok:true。
 * 老桥 70 接口自 P0 起冻结, 新功能只走本桥。
 */
public class BridgeKernel extends BaseBridge {

    private final BridgeAi ai;
    private final Journal journal;
    /** FUSION F2: 快脑查表转发的注册表（懒初始化，优先复用慢脑同一张表） */
    private ToolRegistry fastRegistry;
    /** PERF: tool_manifest 响应缓存（registry 实例重建时失效；build 后表不可变，实例引用即版本） */
    private String manifestCache;
    private ToolRegistry manifestCacheRegistry;

    /** ocr.chat HTTP 客户端（照 OcrApiBridge：connect 3s / read 60s，OCR 生成可能久） */
    private static final OkHttpClient OCR_HTTP = new OkHttpClient.Builder()
            .connectTimeout(3, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build();

    public BridgeKernel(HermesActivity activity, BridgeAi ai) {
        super(activity);
        this.ai = ai;
        this.journal = new Journal(activity.getStorageManager().getRoomsDir());
    }

    public Journal getJournal() { return journal; }

    /** FUSION F2: 快脑查表转发 — 每次优先取慢脑最新一张 ToolRegistry；
     *  agentStart 未跑过（ai.registry 为 null）时才自建兜底表，避免缓存的旧表缺慢脑工具。 */
    private ToolRegistry fastRegistry() {
        ToolRegistry r = ai != null ? ai.getRegistry() : null;
        if (r != null) return fastRegistry = r;
        if (fastRegistry == null) {
            /* 工单20: 快脑注册表也按 Linux 可用性注册 shell.exec/hermes.task（/tools 清单可见性） */
            boolean linuxOk = com.hermes.android.linux.RootfsManager.isReady(activity);
            fastRegistry = ToolRegistry.build(minimalTools(), "", () -> new java.util.HashSet<>(),
                    ToolRegistry.DevicePolicy.probe(activity), linuxOk);
        }
        return fastRegistry;
    }

    /** 快脑自建注册表用的最小 Tools（场景卡工具不依赖文件/设备/打包能力） */
    private static AgentLoop.Tools minimalTools() {
        return new AgentLoop.Tools() {
            public String fileList(String roomId) { return ""; }
            public String fileRead(String roomId, String path) { return "ERROR: 快脑查询环境无文件工具"; }
            public String fileWrite(String roomId, String path, String content) { return "ERROR: 快脑查询环境无文件工具"; }
            public String capabilityOf(String text) { return ""; }
            public String deviceCmd(String text) { return "ERROR: 快脑查询环境无设备工具"; }
            public String packageApk(String roomId, String path, String appName) { return "{\"ok\":false,\"error\":\"快脑查询环境无打包工具\"}"; }
            public String shellExec(String cmd, int timeoutSec) { return "ERROR: 快脑查询环境无 shell"; }
            public String hermesTask(String goal, int timeoutSec) { return "{\"ok\":false,\"error\":\"快脑查询环境无 hermes.task\"}"; }
            public String filePush(String roomId, String path) { return "{\"ok\":false}"; }
            public String filePull(String roomId, String name) { return "{\"ok\":false}"; }
        };
    }

    // ==================== JS→Java 命令信号 ====================

    /**
     * 命令信号入口 (契约 §2.1)。
     * 请求: {"cmd":"<命令名>", "taskId"?, "roomId"?, ...命令参数}
     * 响应: {"ok":true,"data":{...}} 或 {"ok":false,"error":{"code":"<CODE>","msg":"人话"}}
     */
    @JavascriptInterface
    public String postCmd(String json) {
        try {
            JSONObject req = new JSONObject(json);
            String cmd = req.optString("cmd", "");
            String roomId = req.optString("roomId", "");
            String taskId = req.optString("taskId", "");

            switch (cmd) {
                case "user_input": {
                    // P0: 落 journal, 后续 P1 接入 AgentLoop 信号化
                    String text = req.optString("text", "");
                    if (text.isEmpty()) return err("BAD_REQUEST", "text 不能为空");
                    if (roomId.isEmpty()) return err("BAD_REQUEST", "roomId 不能为空");
                    JSONObject event = new JSONObject()
                            .put("actor", "user")
                            .put("type", "user_input")
                            .put("taskId", taskId.isEmpty() ? JSONObject.NULL : taskId)
                            .put("payload", new JSONObject().put("text", text));
                    int seq = journal.append(roomId, event);
                    if (seq < 0) return err("INTERNAL", "journal 写入失败");
                    pushMovEvent(roomId, "journal", event);
                    /* 工单22 幕三: 文本→四元组自动抽取（异步旁路，失败静默，不阻塞对话） */
                    if (!text.trim().isEmpty() && ai != null) {
                        final String fText = text;
                        new Thread(() -> {
                            try {
                                AgentLoop.Brain eb = ai.brainForExtract();
                                com.hermes.android.causal.CausalExtractor.extractAndRecord(eb, fText);
                            } catch (Exception ignored) {}
                        }, "causal-extractor").start();
                    }
                    return ok(new JSONObject().put("seq", seq));
                }

                case "stop_task": {
                    AgentLoop loop = AgentLoop.current();
                    if (loop == null) return err("TASK_NOT_FOUND", "没有活跃任务");
                    if (!taskId.isEmpty() && !loop.getLoopId().equals(taskId)) {
                        return err("TASK_NOT_FOUND", "任务ID不匹配");
                    }
                    loop.requestStop();
                    return ok(new JSONObject().put("stopped", true));
                }

                case "resume_task": {
                    AgentLoop loop = AgentLoop.current();
                    if (loop == null) return err("TASK_NOT_FOUND", "没有活跃任务");
                    if (!taskId.isEmpty() && !loop.getLoopId().equals(taskId)) {
                        return err("TASK_NOT_FOUND", "任务ID不匹配");
                    }
                    loop.respondResume(true);
                    return ok(new JSONObject().put("resumed", true));
                }

                case "gate_respond": {
                    AgentLoop loop = AgentLoop.current();
                    if (loop == null) return err("TASK_NOT_FOUND", "没有活跃任务");
                    if (!taskId.isEmpty() && !loop.getLoopId().equals(taskId)) {
                        return err("TASK_NOT_FOUND", "任务ID不匹配");
                    }
                    String gate = req.optString("gate", "");
                    boolean approved = req.optBoolean("approved", false);
                    String note = req.optString("note", "");
                    switch (gate) {
                        case "understand":
                            loop.respondUnderstand(approved, note);
                            break;
                        case "plan":
                            loop.respondPlan(approved, note);
                            break;
                        case "fileWrite":
                            loop.respondFileWrite(approved);
                            break;
                        case "shell":
                            loop.respondShell(approved);
                            break;
                        case "ask":
                            if (approved) loop.answer(note);
                            break;
                        default:
                            return err("BAD_REQUEST", "未知闸: " + gate);
                    }
                    // 闸事件落 journal
                    if (!roomId.isEmpty()) {
                        JSONObject gateEvent = new JSONObject()
                                .put("actor", "user")
                                .put("type", "gate")
                                .put("taskId", taskId.isEmpty() ? JSONObject.NULL : taskId)
                                .put("payload", new JSONObject()
                                        .put("gate", gate)
                                        .put("state", approved ? "approved" : "rejected")
                                        .put("note", note));
                        journal.append(roomId, gateEvent);
                        pushMovEvent(roomId, "journal", gateEvent);
                    }
                    return ok(new JSONObject().put("gate", gate).put("approved", approved));
                }

                case "room_destroy": {
                    // P1 完整实现 (停 loop + 终态); P0 只落 journal 标记
                    if (roomId.isEmpty()) return err("BAD_REQUEST", "roomId 不能为空");
                    AgentLoop loop = AgentLoop.current();
                    if (loop != null && loop.getRoomId().equals(roomId)) {
                        loop.requestStop();
                        /* 顺手①: room_destroy 竞态——loop 临终 append 会重建已删目录。
                           限时等 loop 终态（最多 3s），终态后再删目录；Journal 层另有
                           已删房间防御（append 拒绝重建）双保险。 */
                        for (int i = 0; i < 30 && loop.isActive(); i++) {
                            try { Thread.sleep(100); } catch (InterruptedException ie) {
                                Thread.currentThread().interrupt(); break;
                            }
                        }
                    }
                    JSONObject event = new JSONObject()
                            .put("actor", "kernel")
                            .put("type", "stopped")
                            .put("taskId", JSONObject.NULL)
                            .put("payload", new JSONObject().put("reason", "room_destroy"));
                    journal.append(roomId, event);
                    pushMovEvent(roomId, "journal", event);
                    /* 真删磁盘房间目录（2026-08-07 用户报障「点了删除列表没少」：
                       原实现只落 journal 标记，face_history 扫磁盘仍列出） */
                    boolean deleted = journal.deleteRoom(roomId);
                    return ok(new JSONObject().put("destroyed", true).put("deleted", deleted));
                }

                case "rooms.orphan": {
                    // 工单15: 孤儿房间目录对账(磁盘有目录无有效 journal 的历史残留)
                    return ok(new JSONObject().put("orphans", journal.orphanRooms()));
                }

                case "rooms.cleanup": {
                    // 工单15: 清理孤儿房间目录(deleteRoom 连目录删, 设置技术区入口用)
                    java.util.List<String> orphans = journal.orphanRooms();
                    int cleaned = 0;
                    for (String id : orphans) if (journal.deleteRoom(id)) cleaned++;
                    return ok(new JSONObject().put("orphans", orphans.size()).put("cleaned", cleaned));
                }

                case "subscribe_history": {
                    if (roomId.isEmpty()) return err("BAD_REQUEST", "roomId 不能为空");
                    int beforeSeq = req.optInt("beforeSeq", Integer.MAX_VALUE);
                    int count = req.optInt("count", 50);
                    count = Math.min(count, 50);
                    JSONObject page = journal.historyPage(roomId, beforeSeq, count);
                    if (!page.optBoolean("ok")) return page.toString();
                    // 经 _movEvent 分批推送 (契约 §2.1)
                    JSONObject data = page.optJSONObject("data");
                    if (data != null) {
                        org.json.JSONArray events = data.optJSONArray("events");
                        if (events != null) {
                            for (int i = 0; i < events.length(); i++) {
                                pushMovEvent(roomId, "journal", events.optJSONObject(i));
                            }
                        }
                    }
                    return page.toString();
                }

                /* P2: 通用事件追加 (非 agent 消息写 journal: AI 回复/设备指令/系统通知)
                   silent:true 跳过 pushMovEvent (seed 迁移用, 防双重渲染) */
                case "append_event": {
                    if (roomId.isEmpty()) return err("BAD_REQUEST", "roomId 不能为空");
                    String type = req.optString("type", "note");
                    String actor = req.optString("actor", "kernel");
                    boolean silent = req.optBoolean("silent", false);
                    JSONObject payload = req.optJSONObject("payload");
                    if (payload == null) payload = new JSONObject();
                    JSONObject event = new JSONObject()
                            .put("actor", actor)
                            .put("type", type)
                            .put("taskId", taskId.isEmpty() ? JSONObject.NULL : taskId)
                            .put("payload", payload);
                    int seq = journal.append(roomId, event);
                    if (seq < 0) return err("INTERNAL", "journal 写入失败");
                    if (!silent) pushMovEvent(roomId, "journal", event);
                    return ok(new JSONObject().put("seq", seq));
                }

                /* 工单24 手动通道: skill.distill —— 用户「把这个做成技能」→ 读房间 journal → 提炼候选 */
                case "skill.distill": {
                    if (roomId.isEmpty()) return err("BAD_REQUEST", "roomId 不能为空");
                    try {
                        JSONObject page = journal.replay(roomId, 200);
                        JSONObject d = page.optJSONObject("data");
                        JSONArray events = (d != null) ? d.optJSONArray("events") : null;
                        if (events == null) return err("NO_JOURNAL", "房间无 journal");
                        /* 既有技能（库收敛） */
                        JSONArray existing = new JSONArray();
                        try {
                            com.hermes.android.skill.SkillStore ss =
                                    new com.hermes.android.skill.SkillStore(activity);
                            existing = new JSONArray(ss.listSkillsJson());
                        } catch (Exception ignored) {}
                        AgentLoop.Brain eb = (ai != null) ? ai.brainForExtract() : null;
                        JSONObject r = com.hermes.android.skill.SkillDistiller.distill(eb, events, existing);
                        return ok(r);
                    } catch (Exception e) {
                        return err("DISTILL_FAILED", e.getMessage());
                    }
                }

                /* 派单№9: 系统级设置 — Linux/Hermes/MCP/诊断/重置 (桥门禁: 只走本桥) */
                case "installLinux": {
                    new RootfsManager(activity).install();
                    return ok(new JSONObject().put("started", true));
                }
                case "installHermes": {
                    new HermesInstaller(activity).install();
                    return ok(new JSONObject().put("started", true));
                }
                case "uninstallLinux": {
                    new RootfsManager(activity).uninstall();
                    return ok(new JSONObject().put("ok", true));
                }
                case "mcp.set": {
                    // 多 server 地基（工单25 幕一 D）：兼容旧行为，写默认第一条（无则新建 manual 条目）
                    McpServerStore.create(activity).setFirst(
                            req.optString("server_url", ""), req.optString("server_token", ""));
                    return ok(new JSONObject());
                }
                case "mcp.add": {
                    // 参数 url/token/origin(manual|market，默认 manual) + name/desc/cat/paid（工单25 本地页定稿）
                    try {
                        McpServerStore.Entry e = McpServerStore.create(activity).add(
                                req.optString("url", ""), req.optString("token", ""),
                                req.optString("origin", McpServerStore.ORIGIN_MANUAL),
                                req.optString("name", ""), req.optString("desc", ""),
                                req.optString("cat", McpServerStore.CAT_OTHER),
                                req.optBoolean("paid", false));
                        return ok(e.toJson());
                    } catch (IllegalArgumentException ex) {
                        return err("BAD_REQUEST", ex.getMessage());
                    }
                }
                case "mcp.reorder": {
                    // 组内排序（分类内顺序即默认）：{id, to} = 移到组内第 to 位
                    String id = req.optString("id", "");
                    if (id.isEmpty()) return err("BAD_REQUEST", "id 不能为空");
                    if (!McpServerStore.create(activity).moveWithinCat(id, req.optInt("to", 0)))
                        return err("NOT_FOUND", "server 不存在: " + id);
                    return ok(new JSONObject().put("id", id));
                }
                case "mcp.remove": {
                    String id = req.optString("id", "");
                    if (id.isEmpty()) return err("BAD_REQUEST", "id 不能为空");
                    if (!McpServerStore.create(activity).remove(id))
                        return err("NOT_FOUND", "server 不存在: " + id);
                    return ok(new JSONObject().put("id", id));
                }
                case "mcp.enable": {
                    String id = req.optString("id", "");
                    if (id.isEmpty()) return err("BAD_REQUEST", "id 不能为空");
                    boolean enabled = req.optBoolean("enabled", true);
                    if (!McpServerStore.create(activity).setEnabled(id, enabled))
                        return err("NOT_FOUND", "server 不存在: " + id);
                    return ok(new JSONObject().put("id", id).put("enabled", enabled));
                }
                case "mcp.test": {
                    // 验收打回 P1：JS 本地页 srvTest 只传 id——按 id 查 store 取 url/token（server_url/server_token 为旧契约兜底）
                    String url = req.optString("server_url", "");
                    String token = req.optString("server_token", "");
                    String testId = req.optString("id", "");
                    if (!testId.isEmpty()) {
                        McpServerStore.Entry e = null;
                        for (McpServerStore.Entry it : McpServerStore.create(activity).list()) {
                            if (it.id.equals(testId)) { e = it; break; }
                        }
                        if (e == null) return err("NOT_FOUND", "server 不存在: " + testId);
                        url = e.url;
                        token = e.token;
                    }
                    if (url.isEmpty()) return err("BAD_REQUEST", "url 不能为空（传 id 或 server_url）");
                    boolean ok = new McpClient().healthCheck(url, token);
                    return ok(new JSONObject().put("ok", ok));
                }
                case "diagnostics.export": {
                    ErrorReporter.export(activity);
                    return ok(new JSONObject());
                }
                case "diagnostics.clear": {
                    ErrorReporter.clear(activity);
                    return ok(new JSONObject());
                }
                case "clipboard.write": {
                    /* 工单25 增补：JS 长按复制直写系统剪贴板（配合 scrcpy 剪贴板同步到桌面） */
                    String text = req.optString("text", "");
                    if (text.isEmpty()) return err("BAD_REQUEST", "内容为空");
                    android.content.ClipboardManager cm = (android.content.ClipboardManager)
                            activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("MOV", text));
                    android.util.Log.i("MOV", "clipboard.write len=" + text.length());
                    return ok(new JSONObject().put("len", text.length()));
                }
                case "diagnostics.proot": {
                    // P4 agent-14: proot execve EPERM 诊断（on-demand，不挂 onCreate）
                    JSONObject d = com.hermes.android.linux.ProotDiag.diagnose(activity);
                    return ok(d);
                }
                case "resetSystem": {
                    new RootfsManager(activity).uninstall();
                    new java.io.File(activity.getFilesDir(), "linux/hermes-state.json").delete();
                    return ok(new JSONObject().put("ok", true));
                }

                // ═══ feat/wxpay-applyment: 微信支付服务商进件（网络 IO 走 cbId 异步，禁同步桥）═══
                case "partner.config.set": {
                    com.hermes.android.partner.PartnerConfig cfg =
                            new com.hermes.android.partner.PartnerConfig(activity);
                    if (req.has("baseUrl")) cfg.setBaseUrl(req.optString("baseUrl", ""));
                    if (req.has("token")) cfg.setToken(req.optString("token", ""));
                    return ok(new JSONObject().put("configured", cfg.isConfigured()));
                }
                case "partner.applyment.submit":
                case "partner.applyment.query":
                case "partner.applyment.uploadMedia": {
                    String cbId = req.optString("cbId", "").replaceAll("[^A-Za-z0-9_\\-]", "");
                    if (cbId.isEmpty()) return err("BAD_REQUEST", "cbId 不能为空");
                    final String fCmd = cmd;
                    final JSONObject fReq = req;
                    new Thread(() -> {
                        com.hermes.android.partner.PartnerClient.Resp r;
                        com.hermes.android.partner.PartnerClient client =
                                new com.hermes.android.partner.PartnerConfig(activity).clientOrNull();
                        if (client == null) {
                            r = com.hermes.android.partner.PartnerClient.Resp.fail(
                                    "NOT_CONFIGURED", "进件后端未配置：请先填服务器地址和访问令牌");
                        } else if ("partner.applyment.submit".equals(fCmd)) {
                            r = client.submitApplyment(fReq.optJSONObject("applyment"));
                        } else if ("partner.applyment.query".equals(fCmd)) {
                            r = client.queryApplyment(fReq.optString("business_code", ""));
                        } else {
                            r = client.uploadMedia(new java.io.File(fReq.optString("path", "")));
                        }
                        activity.evalJsPublic("window._hermesCb('" + cbId + "'," + r.toEnvelope() + ")");
                    }, "partner-api").start();
                    return ok(new JSONObject().put("accepted", true));
                }

                default:
                    return err("BAD_REQUEST", "未知命令: " + cmd);
            }
        } catch (Exception e) {
            return err("INTERNAL", "postCmd 异常: " + e.getMessage());
        }
    }

    // ==================== JS→Java 查询 ====================

    /**
     * 只读查询入口 (契约 §2.2)。
     * 请求: {"q":"journal_tail", "roomId":"..", "afterSeq":41, "count":100}
     * 响应: {"ok":true,"data":{"events":[...],"latestSeq":42}}
     */
    @JavascriptInterface
    public String query(String json) {
        try {
            JSONObject req = new JSONObject(json);
            String q = req.optString("q", "");
            String roomId = req.optString("roomId", "");

            switch (q) {
                case "journal_tail": {
                    if (roomId.isEmpty()) return err("BAD_REQUEST", "roomId 不能为空");
                    int afterSeq = req.optInt("afterSeq", 0);
                    int count = req.optInt("count", 100);
                    return journal.tail(roomId, afterSeq, count).toString();
                }

                case "journal_index": {
                    if (roomId.isEmpty()) return err("BAD_REQUEST", "roomId 不能为空");
                    return journal.readIndex(roomId).toString();
                }

                case "journal_replay": {
                    if (roomId.isEmpty()) return err("BAD_REQUEST", "roomId 不能为空");
                    return journal.replay(roomId).toString();
                }

                case "agent_state": {
                    AgentLoop al = AgentLoop.current();
                    if (al == null) {
                        return new JSONObject().put("ok", true)
                                .put("data", new JSONObject().put("active", false)).toString();
                    }
                    JSONObject data = al.getStateJson();
                    return new JSONObject().put("ok", true).put("data", data).toString();
                }

                case "intent_classify": {
                    String text = req.optString("text", "");
                    if (text.isEmpty()) return err("BAD_REQUEST", "text 不能为空");
                    IntentEngine engine = new IntentEngine(activity);
                    IntentEngine.IntentResult r = engine.classify(text);
                    JSONObject data = new JSONObject()
                            .put("type", r.type)
                            .put("domain", r.domain)
                            .put("slots", new JSONObject(r.slots))
                            .put("confidence", r.confidence);
                    return new JSONObject().put("ok", true).put("data", data).toString();
                }

                case "face_history": {
                    // FUSION F3: 查表转发 — MemoryToolProvider 注册的记忆工具
                    ToolRegistry.Tool tool = fastRegistry().find("face_history");
                    if (tool == null) return err("MEMORY_FAILED", "face_history 未注册");
                    try {
                        ToolRegistry.Result r = tool.handler.run(new JSONObject());
                        if (r.ok && r.produced != null) return ok(new JSONObject(r.produced));
                        return err("MEMORY_FAILED", r.text);
                    } catch (Exception e) {
                        return err("MEMORY_FAILED", e.getMessage());
                    }
                }

                case "face_search_drama": {
                    String query = req.optString("query", "");
                    if (query.isEmpty()) return err("BAD_REQUEST", "query 不能为空");
                    DramaSource ds = new DramaSource();
                    ds.setRegistry(new com.hermes.android.agent.VideoSourceRegistry(activity));
                    java.util.List<DramaSource.DramaItem> items = ds.search(query);
                    JSONArray arr = new JSONArray();
                    for (DramaSource.DramaItem item : items) arr.put(item.toJSON());
                    return new JSONObject().put("ok", true)
                            .put("data", new JSONObject().put("items", arr)).toString();
                }

                case "video_sources": {
                    // 视频源注册表: 列表 / 开关回写 (抽屉「我的·视频源」用)
                    com.hermes.android.agent.VideoSourceRegistry reg =
                            new com.hermes.android.agent.VideoSourceRegistry(activity);
                    String act = req.optString("action", "list");
                    if ("toggle".equals(act)) {
                        String id = req.optString("id", "");
                        boolean en = req.optBoolean("enabled", true);
                        boolean done = reg.setEnabled(id, en);
                        return new JSONObject().put("ok", done).toString();
                    }
                    return reg.listJson();
                }

                case "tool_manifest": {
                    // FUSION F2: 注册表即工具清单（FAST 场景卡 + SLOW 慢脑工具同表）
                    // PERF: 缓存响应，registry 实例重建（agentStart 再跑）时失效
                    ToolRegistry reg = fastRegistry();
                    if (manifestCache == null || manifestCacheRegistry != reg) {
                        JSONArray arr = new JSONArray();
                        for (ToolRegistry.Tool t : reg.allTools()) {
                            JSONObject o = new JSONObject();
                            ToolRegistry.Manifest m = t.manifest;
                            o.put("name", t.name);
                            o.put("level", m != null ? m.level : "SLOW");
                            o.put("toolset", t.toolset != null ? t.toolset : "");
                            o.put("sync", m != null && m.sync);
                            o.put("timeoutMs", m != null ? m.timeoutMs : t.timeoutSec * 1000L);
                            JSONArray pa = new JSONArray();
                            if (t.params != null) for (ToolRegistry.ParamDef p : t.params) pa.put(p.name);
                            o.put("params", pa);
                            JSONArray ex = new JSONArray();
                            if (t.examples != null) for (String e : t.examples) ex.put(e);
                            o.put("examples", ex);
                            // DESIGN_SETTINGS ⑤: 硬件/权限可用性探测（null=可用，字符串=不可用原因）
                            String check = reg.checkAvailability(t);
                            o.put("check", check == null ? JSONObject.NULL : check);
                            arr.put(o);
                        }
                        manifestCache = ok(new JSONObject().put("tools", arr)
                                .put("promptText", reg.promptText())).toString();
                        manifestCacheRegistry = reg;
                    }
                    return manifestCache;
                }

                case "tool_stats": {
                    // FUSION F6: 晋升统计 — journal 工具调用频次（SLOW→FAST 固化决策数据）
                    try {
                        JSONArray arr = com.hermes.android.ToolStats.collect(
                                activity.getStorageManager().getRoomsDir());
                        return ok(new JSONObject().put("tools", arr).put("total", arr.length()));
                    } catch (Exception e) {
                        return err("STATS_FAILED", e.getMessage());
                    }
                }

                case "web_sites": {
                    // 返回已接入站点列表（当前一张手工卡+filesDir中AI生成的卡）
                    JSONArray arr = new JSONArray();
                    arr.put(com.hermes.android.scene.SiteCard.fromMayiSite().toJSON());
                    // TODO: 从 filesDir 加载 AI 生成的 SiteCard
                    return ok(new JSONObject().put("sites", arr));
                }

                case "web_adapt": {
                    String adaptUrl = req.optString("url", "");
                    if (adaptUrl.isEmpty()) return err("BAD_REQUEST", "url required");
                    String domain = adaptUrl.replace("https://","").replace("www.","").split("/")[0];
                    // 四段法（OpenCLI adapter-author 吸收）：site-recon → api-discovery → field-decode → verify
                    JSONObject result = new JSONObject()
                        .put("status", "C")  // v1 全部引导
                        .put("site", domain)
                        .put("stage", "site-recon")  // 第一步：站点侦察+反爬检测
                        .put("antiCrawl", new JSONObject()
                            .put("check_signals", new JSONArray()
                                .put("acw_sc__v2").put("__cf_bm").put("_abck").put("geetest"))
                            .put("strategy", "浏览器上下文优先验证→确认fetch可行性→定后续路线"))
                        .put("next_stages", new JSONArray()
                            .put("api-discovery").put("field-decode").put("verify"))
                        .put("guidance", "四段法：①site-recon(反爬指纹检测)→②api-discovery(找数据endpoint)→③field-decode(字段解码)→④verify(实跑验证)");
                    return ok(result);
                }

                case "music_search": {
                    // FUSION F2: 查表转发 — FastSceneProvider 注册的同一张 ToolRegistry
                    String keyword = req.optString("keyword", "");
                    if (keyword.isEmpty()) return err("BAD_REQUEST", "keyword required");
                    ToolRegistry.Tool tool = fastRegistry().find("music_search");
                    if (tool == null) return err("MUSIC_SEARCH_FAILED", "music_search 未注册");
                    try {
                        ToolRegistry.Result r = tool.handler.run(new JSONObject().put("keyword", keyword));
                        if (r.ok && r.produced != null) return ok(new JSONObject(r.produced));
                        return err("MUSIC_SEARCH_FAILED", r.text);
                    } catch (Exception e) {
                        return err("MUSIC_SEARCH_FAILED", e.getMessage());
                    }
                }

                case "train_search": {
                    // FUSION F2: 查表转发 — FastSceneProvider 注册的同一张 ToolRegistry
                    String from = req.optString("from", "");
                    String to = req.optString("to", "");
                    String date = req.optString("date", "");
                    if (from.isEmpty() || to.isEmpty()) return err("BAD_REQUEST", "from/to required");
                    ToolRegistry.Tool tool = fastRegistry().find("train_search");
                    if (tool == null) return err("TRAIN_SEARCH_FAILED", "train_search 未注册");
                    try {
                        JSONObject args = new JSONObject().put("from", from).put("to", to).put("date", date);
                        ToolRegistry.Result r = tool.handler.run(args);
                        if (r.ok && r.produced != null) return ok(new JSONObject(r.produced));
                        return err("TRAIN_SEARCH_FAILED", r.text);
                    } catch (Exception e) {
                        return err("TRAIN_SEARCH_FAILED", e.getMessage());
                    }
                }

                case "shop_search": {
                    /* W3: 京东购物搜索 (FastSceneProvider 查表转发) */
                    String kw = req.optString("keyword", "");
                    if (kw.isEmpty()) return err("BAD_REQUEST", "keyword required");
                    ToolRegistry.Tool tool = fastRegistry().find("shop_search");
                    if (tool == null) return err("SHOP_SEARCH_FAILED", "shop_search 未注册");
                    try {
                        JSONObject args = new JSONObject().put("keyword", kw);
                        ToolRegistry.Result r = tool.handler.run(args);
                        if (r.ok && r.produced != null) return ok(new JSONObject(r.produced));
                        return err("SHOP_SEARCH_FAILED", r.text);
                    } catch (Exception e) {
                        return err("SHOP_SEARCH_FAILED", e.getMessage());
                    }
                }

                case "mayi_latest": {
                    String title = req.optString("title", "");
                    if (title.isEmpty()) return err("BAD_REQUEST", "title required");
                    com.hermes.android.scene.MayiSite site = new com.hermes.android.scene.MayiSite();
                    java.util.List<com.hermes.android.scene.MayiSite.Show> shows = site.search(title);
                    if (!shows.isEmpty()) {
                        com.hermes.android.scene.MayiSite.Show s = shows.get(0);
                        int lep = site.latestEpisode(s.id);
                        com.hermes.android.scene.MayiSite.PlayResult pr = site.playUrl(s.id, lep);
                        JSONObject data = new JSONObject()
                                .put("latestEp", lep)
                                .put("playUrl", pr.playUrl)
                                .put("showId", s.id)
                                .put("title", s.title);
                        return ok(data);
                    }
                    return ok(new JSONObject().put("latestEp", 0));
                }

                case "drama_memory": {
                    // FUSION F3: 查表转发 — MemoryToolProvider 注册的记忆工具
                    ToolRegistry.Tool tool = fastRegistry().find("drama_memory");
                    if (tool == null) return err("MEMORY_FAILED", "drama_memory 未注册");
                    try {
                        ToolRegistry.Result r = tool.handler.run(req);
                        if (r.ok && r.produced != null) return ok(new JSONObject(r.produced));
                        return err("MEMORY_FAILED", r.text);
                    } catch (Exception e) {
                        return err("MEMORY_FAILED", e.getMessage());
                    }
                }

                case "check_drama_updates": {
                    // 任务L·更新雷达：返回在追列表（有进度记录+URL的剧）
                    File wh = new File(activity.getFilesDir(), "watch_history.json");
                    JSONArray arr = new JSONArray();
                    if (wh.exists()) {
                        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                                new FileInputStream(wh), "UTF-8"))) {
                            StringBuilder sb = new StringBuilder();
                            String line;
                            while ((line = r.readLine()) != null) sb.append(line);
                            JSONObject root = new JSONObject(sb.toString());
                            java.util.Iterator<String> keys = root.keys();
                            while (keys.hasNext()) {
                                JSONObject entry = root.getJSONObject(keys.next());
                                if (entry.optInt("episode", 0) > 0 && entry.has("url")) {
                                    arr.put(new JSONObject()
                                            .put("title", entry.optString("title"))
                                            .put("episode", entry.optInt("episode"))
                                            .put("url", entry.optString("url", ""))
                                            .put("ts", entry.optLong("ts", 0)));
                                }
                            }
                        } catch (Exception ignored) {}
                    }
                    return new JSONObject().put("ok", true).put("data", new JSONObject().put("watching", arr)).toString();
                }

                case "health": {
                    // H2: 工具/源周期探测器健康态（设置页能力区块数据源；op=retest 手动重测）
                    com.hermes.android.agent.HealthMonitor hm = activity.getHealthMonitor();
                    if (hm == null) return err("HEALTH_UNAVAILABLE", "探测器未初始化");
                    String op = req.optString("op", "list");
                    if ("retest".equals(op)) {
                        hm.retest(req.optString("id", ""));
                        return ok(new JSONObject().put("retested", req.optString("id", "")));
                    }
                    return ok(new JSONObject().put("items", hm.healthJson()));
                }

                case "watch_history": {
                    // FUSION F3: 查表转发 — MemoryToolProvider 注册的记忆工具（req 透传支持 op=clear）
                    ToolRegistry.Tool tool = fastRegistry().find("watch_history");
                    if (tool == null) return err("MEMORY_FAILED", "watch_history 未注册");
                    try {
                        ToolRegistry.Result r = tool.handler.run(req);
                        if (r.ok && r.produced != null) return ok(new JSONObject(r.produced));
                        return err("MEMORY_FAILED", r.text);
                    } catch (Exception e) {
                        return err("MEMORY_FAILED", e.getMessage());
                    }
                }

                case "face_mine": {
                    // FUSION F3: 查表转发 — MemoryToolProvider 注册的记忆工具
                    ToolRegistry.Tool tool = fastRegistry().find("face_mine");
                    if (tool == null) return err("MEMORY_FAILED", "face_mine 未注册");
                    try {
                        ToolRegistry.Result r = tool.handler.run(new JSONObject());
                        if (r.ok && r.produced != null) return ok(new JSONObject(r.produced));
                        return err("MEMORY_FAILED", r.text);
                    } catch (Exception e) {
                        return err("MEMORY_FAILED", e.getMessage());
                    }
                }

                /* ==================== P6 №4: OCR 本地 llama-server（桥门禁首单，全走 Kernel 信封） ==================== */

                case "ocr.status": {
                    // 模型就绪 + server 状态 + 存活探测（设置页「本地模型（OCR）」/前端状态卡用）
                    JSONObject data = new JSONObject()
                            .put("modelReady", LlamaServerManager.installReady(activity))
                            .put("modelName", LlamaServerManager.DEFAULT_MODEL)
                            .put("serverState", LlamaServerManager.status().name())
                            .put("serverUp", LlamaServerManager.healthz(activity));
                    return ok(data);
                }

                case "ocr.model.list": {
                    // 本地模型列表（filesDir/models/unlimited-ocr/，版本隔离）——照 OcrApiBridge.listLocalModels
                    JSONArray arr = new JSONArray();
                    File dir = new File(activity.getFilesDir(), "models/unlimited-ocr");
                    if (dir.isDirectory()) {
                        File[] files = dir.listFiles();
                        if (files != null) {
                            for (File f : files) {
                                if (f.isFile()) {
                                    arr.put(new JSONObject()
                                            .put("name", f.getName())
                                            .put("sizeMB", f.length() / 1048576L));
                                }
                            }
                        }
                    }
                    return ok(new JSONObject().put("models", arr));
                }

                case "ocr.chat": {
                    // 本地大模型文本对话（llama-server OpenAI 兼容，DESIGN_OCR_MOBILE §三能力②）。
                    // 真视觉识别走 vision_infer C API 链（embd 注入），此处是文本直跑（本地 LLM 兜底）。
                    String text = req.optString("text", "");
                    if (text.isEmpty()) return err("BAD_REQUEST", "text 不能为空");
                    if (!LlamaServerManager.ensureRunning(activity)) {
                        String reason = LlamaServerManager.installReady(activity)
                                ? "llama-server 启动失败" : "模型未就绪（设置页可下载，约 2GB）";
                        return err("OCR_NOT_READY", reason);
                    }
                    try {
                        String token = LlamaServerManager.token(activity);
                        Request r = new Request.Builder()
                                .url(LlamaClient.BASE_URL + "/v1/chat/completions")
                                .header("Authorization", "Bearer " + token)
                                .post(RequestBody.create(
                                        MediaType.get("application/json; charset=utf-8"),
                                        LlamaClient.buildChatPayload(null, text, 256)))
                                .build();
                        try (Response resp = OCR_HTTP.newCall(r).execute()) {
                            String body = resp.body() != null ? resp.body().string() : "";
                            String content = LlamaClient.parseResponse(body);
                            if (content != null) return ok(new JSONObject().put("content", content));
                            return err("OCR_FAILED", LlamaClient.mapError(resp.code(), body));
                        }
                    } catch (Exception e) {
                        return err("OCR_FAILED", "OCR 请求异常: " + e.getMessage());
                    }
                }

                /* 派单№9: 系统级设置 — Linux/Hermes/MCP 状态 (桥门禁) */
                case "linuxStatus": {
                    RootfsManager rm = new RootfsManager(activity);
                    return ok(new JSONObject()
                            .put("state", rm.getState().name())
                            .put("progress", rm.getProgress())
                            .put("errorMsg", rm.getErrorMsg() != null ? rm.getErrorMsg() : "")
                            .put("ready", rm.isReady())
                            .put("version", "24.04")
                            .put("diskMB", rm.diskUsage()));
                }
                case "hermesStatus": {
                    HermesInstaller hi = new HermesInstaller(activity);
                    return ok(new JSONObject()
                            .put("state", hi.getState().name())
                            .put("version", hi.getVersion() != null ? hi.getVersion() : "")
                            .put("errorMsg", hi.getErrorMsg() != null ? hi.getErrorMsg() : "")
                            .put("ready", hi.isReady()));
                }
                case "mcp.get": {
                    // 多 server 地基（工单25 幕一 D）：兼容旧行为，读默认第一条（无则空）
                    McpServerStore.Entry e = McpServerStore.create(activity).first();
                    return ok(new JSONObject()
                            .put("server_url", e != null ? e.url : "")
                            .put("server_token", e != null ? e.token : ""));
                }
                case "mcp.list": {
                    // 全部条目及状态（id/url/token/enabled/origin）
                    JSONArray servers = new JSONArray();
                    for (McpServerStore.Entry e : McpServerStore.create(activity).list())
                        servers.put(e.toJson());
                    return ok(new JSONObject().put("servers", servers));
                }
                case "mcp.approvalRespond": {
                    /* P2 审批闸房间内确认闭环：UI/Bridge 读到 _mcp_approval_request 事件后批准/驳回。
                       respond 走 McpApprovalGate，路径进白名单 / 记拒绝，落 _mcp_approval_result journal 事件。 */
                    String requestId = req.optString("requestId", "");
                    boolean approved = req.optBoolean("approved", false);
                    String note = req.optString("note", "");
                    if (requestId.isEmpty()) return err("BAD_REQUEST", "requestId 不能为空");
                    com.hermes.android.mcp.server.McpApprovalGate gate =
                            com.hermes.android.mcp.server.MovMcpServer.approvalGate();
                    if (gate == null) return err("MCP_NOT_RUNNING", "MCP server 未启动（审批闸不可用）");
                    boolean ok = gate.respond(requestId, approved, note);
                    if (!ok) return err("REQUEST_NOT_FOUND", "审批请求不存在或已处理: " + requestId);
                    return ok(new JSONObject().put("requestId", requestId).put("approved", approved));
                }

                /* ==================== P6 环境地图: 探索原语三件套（桥门禁，READONLY） ==================== */

                case "env.scan": {
                    // 目录树（限深 3 层 + 系统区豁免）
                    String path = req.optString("path", "");
                    if (path.isEmpty()) return err("BAD_REQUEST", "path 不能为空");
                    if (EnvMap.isSystemExempt(path)) return err("ENV_EXEMPT", "系统区豁免，不可扫描");
                    java.io.File root = new java.io.File(path);
                    if (!root.isDirectory()) return err("NOT_FOUND", "目录不存在: " + path);
                    return ok(new JSONObject().put("tree", EnvMap.tree(root, 3)));
                }

                case "env.search": {
                    // 文件名 + journal 粗搜（限深 3，系统区豁免）
                    String kw = req.optString("keyword", "");
                    if (kw.isEmpty()) return err("BAD_REQUEST", "keyword 不能为空");
                    JSONArray hits = new JSONArray();
                    java.io.File base = activity.getStorageManager().getBaseDir();
                    for (java.io.File f : EnvMap.searchByName(base, kw, 3)) {
                        hits.put(new JSONObject().put("path", f.getAbsolutePath()).put("name", f.getName()));
                    }
                    // journal 粗搜：各房间 replay 关键词命中
                    java.io.File rooms = activity.getStorageManager().getRoomsDir();
                    java.io.File[] rds = rooms.listFiles(java.io.File::isDirectory);
                    if (rds != null) {
                        for (java.io.File rd : rds) {
                            JSONObject rep = journal.replay(rd.getName(), 20);
                            JSONObject d = rep.optJSONObject("data");
                            JSONArray evs = d != null ? d.optJSONArray("events") : null;
                            if (evs == null) continue;
                            for (int i = 0; i < evs.length(); i++) {
                                JSONObject ev = evs.optJSONObject(i);
                                if (ev != null && ev.toString().contains(kw)) {
                                    hits.put(new JSONObject().put("journal", rd.getName())
                                            .put("type", ev.optString("type", "?")));
                                    break;
                                }
                            }
                        }
                    }
                    // 追剧记忆（watch_history.json，filesDir）：标题匹配——巡检#45 洞2
                    for (String title : EnvMap.searchWatchHistory(
                            new java.io.File(activity.getFilesDir(), "watch_history.json"), kw)) {
                        hits.put(new JSONObject().put("memory", "watch_history").put("title", title));
                    }
                    return ok(new JSONObject().put("hits", hits).put("count", hits.length()));
                }

                case "env.peek": {
                    // 文件摘要（类型/大小/首屏预览，200 字符）
                    String path = req.optString("path", "");
                    if (path.isEmpty()) return err("BAD_REQUEST", "path 不能为空");
                    if (EnvMap.isSystemExempt(path)) return err("ENV_EXEMPT", "系统区豁免，不可读取");
                    java.io.File f = new java.io.File(path);
                    if (!f.isFile()) return err("NOT_FOUND", "文件不存在: " + path);
                    return ok(new JSONObject().put("summary", EnvMap.peekSummary(f, 200)));
                }

                case "env.map": {
                    // 环境地图快照（任务启动注入同源）：五类 + 配置健康，每类 ≤500 字符，保险柜只名
                    return ok(EnvMap.snapshot(activity));
                }

                case "memory.curate": {
                    // L3 周期策展（DESIGN_MEMORY_LAYERS L3）：所有房间草案去重→高频晋升 + 过期清理。
                    // 触发走调度（灭屏+充电/time_cron 可挂本入口），单次各房间限 CURATE_DRAFT_LIMIT 条。
                    int total = 0;
                    java.io.File rooms = activity.getStorageManager().getRoomsDir();
                    java.io.File[] rds = rooms.listFiles(java.io.File::isDirectory);
                    if (rds != null) {
                        for (java.io.File rd : rds) {
                            total += journal.memoryCurate(rd.getName());
                        }
                    }
                    return ok(new JSONObject().put("curated", total));
                }

                case "memory.cover": {
                    // 读取时按需覆盖（DESIGN_MEMORY_LAYERS v2 §六）：预算内新记忆逐字、旧记忆塌缩摘要。
                    // 纯算法无模型调用（前台可跑）；needsCompress 待 L3 模型提炼（懒触发，空闲补齐）。
                    if (roomId.isEmpty()) return err("BAD_REQUEST", "roomId 不能为空");
                    int budget = req.optInt("budget", Journal.COVER_BUDGET_DEFAULT);
                    return ok(new JSONObject().put("cover", journal.memoryCover(roomId, budget)));
                }

                case "skills.sync": {
                    // 工单9 幕二 三件套 b: assets/skills 导出到 exchange/skills/(proot 客居脑读 SKILL.md)
                    try {
                        java.io.File skDir = new java.io.File(
                                activity.getStorageManager().getExchangeDir(), "skills");
                        int n = exportSkills(skDir,
                                () -> {
                                    try { return activity.getAssets().list("skills"); }
                                    catch (Exception e) { return null; }
                                },
                                name -> {
                                    try (java.io.InputStream is = activity.getAssets().open("skills/" + name)) {
                                        byte[] buf = new byte[Math.max(1, is.available())];
                                        int off = 0, r;
                                        while ((r = is.read(buf, off, buf.length - off)) > 0) off += r;
                                        return buf;
                                    } catch (Exception e) { return null; }
                                });
                        return ok(new JSONObject().put("synced", n).put("dir", skDir.getAbsolutePath()));
                    } catch (Exception e) {
                        return err("SKILLS_SYNC_FAILED", "技能导出失败: " + e.getMessage());
                    }
                }

                case "generateGuestContext": {
                    // 工单9 幕二 三件套 c: memoryCover 覆盖 → exchange/AGENTS.md 记忆段(客居脑工作目录引用)
                    if (roomId.isEmpty()) return err("BAD_REQUEST", "roomId 不能为空");
                    try {
                        org.json.JSONArray cover = journal.memoryCover(
                                roomId, Journal.COVER_BUDGET_DEFAULT);
                        String text = guestContextText(cover);
                        java.io.File ag = new java.io.File(
                                activity.getStorageManager().getExchangeDir(), "AGENTS.md");
                        java.nio.file.Files.write(ag.toPath(), text.getBytes("UTF-8"));
                        return ok(new JSONObject().put("path", ag.getAbsolutePath())
                                .put("bytes", text.length()));
                    } catch (Exception e) {
                        return err("GUEST_CTX_FAILED", "记忆投影失败: " + e.getMessage());
                    }
                }

                // ═══ 域记忆移植（工单8，DESIGN_MEM_DOMAIN_PORT §四）— 按域读 _tool_receipt + 预算覆盖投影 ═══
                case "mem.domain": {
                    // 目的域连续历史（工具弃用数据不死）：固定 global 房（v1 落账同例，causal 一致）。
                    String domain = req.optString("domain", "");
                    int budget = req.optInt("budget", Journal.COVER_BUDGET_DEFAULT);
                    if (domain.isEmpty()) return err("BAD_REQUEST", "domain 不能为空");
                    JSONArray cover = journal.domainCover("global", domain, budget);
                    return ok(new JSONObject().put("domain", domain).put("cover", cover));
                }

                // ═══ 因果记忆（本地因果记忆编译器，feat/causal-memory）— 只读查询；写路径走 tool.execute ═══
                case "causal.query": {
                    com.hermes.android.causal.CausalEngine ce =
                            com.hermes.android.toolprovider.CausalToolProvider.engine();
                    if (ce == null) return err("BAD_REQUEST", "因果引擎未初始化");
                    return ok(ce.query(com.hermes.android.toolprovider.CausalToolProvider.ROOM,
                            req.optInt("limit", 20)));
                }
                case "causal.match": {
                    com.hermes.android.causal.CausalEngine ce =
                            com.hermes.android.toolprovider.CausalToolProvider.engine();
                    if (ce == null) return err("BAD_REQUEST", "因果引擎未初始化");
                    JSONObject meta = req.optJSONObject("meta");
                    com.hermes.android.causal.CausalEvent ev = new com.hermes.android.causal.CausalEvent(
                            req.optString("subject", ""), req.optString("predicate", ""),
                            req.optString("object", ""), req.optString("t", ""),
                            req.optString("source", ""), meta);
                    return ok(ce.match(com.hermes.android.toolprovider.CausalToolProvider.ROOM, ev));
                }
                case "causal.chain": {
                    com.hermes.android.causal.CausalEngine ce =
                            com.hermes.android.toolprovider.CausalToolProvider.engine();
                    if (ce == null) return err("BAD_REQUEST", "因果引擎未初始化");
                    return ok(ce.chain(com.hermes.android.toolprovider.CausalToolProvider.ROOM));
                }
                case "causal.index": {
                    com.hermes.android.causal.CausalEngine ce =
                            com.hermes.android.toolprovider.CausalToolProvider.engine();
                    if (ce == null) return err("BAD_REQUEST", "因果引擎未初始化");
                    return ok(ce.index(com.hermes.android.toolprovider.CausalToolProvider.ROOM));
                }
                case "causal.sweep": {
                    // 衰减清理（写墓碑）：镜像 memory.curate 遍历全房间（当前实际固定 global 房）。
                    com.hermes.android.causal.CausalEngine ce =
                            com.hermes.android.toolprovider.CausalToolProvider.engine();
                    if (ce == null) return err("BAD_REQUEST", "因果引擎未初始化");
                    int swept = 0, forgotten = 0, removedRules = 0;
                    java.io.File rooms = activity.getStorageManager().getRoomsDir();
                    java.io.File[] rds = rooms.listFiles(java.io.File::isDirectory);
                    if (rds != null) {
                        for (java.io.File rd : rds) {
                            JSONObject r = ce.sweep(rd.getName(), System.currentTimeMillis());
                            swept += r.optInt("swept");
                            forgotten += r.optInt("forgotten");
                            removedRules += r.optInt("removedRules");
                        }
                    }
                    return ok(new JSONObject().put("swept", swept)
                            .put("forgotten", forgotten).put("removedRules", removedRules));
                }

                case "partner.config.get": {
                    // feat/wxpay-applyment: 非敏感配置读取（地址可回显，token 只回报是否已配置，绝不出值）
                    com.hermes.android.partner.PartnerConfig cfg =
                            new com.hermes.android.partner.PartnerConfig(activity);
                    return ok(new JSONObject()
                            .put("baseUrl", cfg.getBaseUrl())
                            .put("hasToken", !cfg.getToken().isEmpty())
                            .put("configured", cfg.isConfigured()));
                }

                default:
                    return err("BAD_REQUEST", "未知查询: " + q);
            }
        } catch (Exception e) {
            return err("INTERNAL", "query 异常: " + e.getMessage());
        }
    }

    // ==================== Java→JS 事件推送 ====================

    /**
     * 推送 _movEvent (契约 §2.3)。
     * {"roomId":"r17...", "channel":"journal|transient", "event":{...}}
     */
    public void pushMovEvent(String roomId, String channel, JSONObject event) {
        try {
            JSONObject envelope = new JSONObject()
                    .put("roomId", roomId)
                    .put("channel", channel)
                    .put("event", event);
            activity.evalJsPublic("window._movEvent(" + envelope.toString() + ")");
        } catch (Exception e) {
            android.util.Log.w("BridgeKernel", "pushMovEvent failed: " + e.getMessage());
        }
    }

    /**
     * 推送瞬态事件 (token/stream_state/typing, 不落 journal)。
     */
    public void pushTransient(String roomId, JSONObject transientEvent) {
        pushMovEvent(roomId, "transient", transientEvent);
    }

    // ==================== 错误信封工具 ====================

    private static String err(String code, String msg) {
        try {
            return new JSONObject()
                    .put("ok", false)
                    .put("error", new JSONObject().put("code", code).put("msg", msg))
                    .toString();
        } catch (Exception e) {
            return "{\"ok\":false,\"error\":{\"code\":\"INTERNAL\",\"msg\":\"信封构造失败\"}}";
        }
    }

    private static String ok(JSONObject data) {
        try {
            return new JSONObject().put("ok", true).put("data", data).toString();
        } catch (Exception e) {
            return "{\"ok\":false,\"error\":{\"code\":\"INTERNAL\",\"msg\":\"信封构造失败\"}}";
        }
    }

    // ==================== 工单9 幕二 三件套 可测核心 ====================

    /** 三件套 c 核心(可测): memoryCover → AGENTS.md 记忆段文本。 */
    static String guestContextText(org.json.JSONArray cover) {
        StringBuilder sb = new StringBuilder("# AGENTS 记忆段 (MOV memoryCover)\n");
        if (cover != null) {
            for (int i = 0; i < cover.length(); i++) {
                org.json.JSONObject o = cover.optJSONObject(i);
                String text = o != null ? o.optString("text", "").trim() : "";
                if (text.isEmpty()) continue;
                sb.append("- ").append(text).append('\n');
            }
        }
        return sb.toString();
    }

    /** 三件套 b 核心(可测): 按名称读取器复制 skills 到目录, 返回复制数。 */
    static int exportSkills(java.io.File dstDir,
            java.util.function.Supplier<String[]> names,
            java.util.function.Function<String, byte[]> reader) {
        if (dstDir == null) return 0;
        dstDir.mkdirs();
        String[] list = names != null ? names.get() : null;
        if (list == null) return 0;
        int n = 0;
        for (String s : list) {
            byte[] buf = reader != null ? reader.apply(s) : null;
            if (buf == null || buf.length == 0) continue;
            try {
                java.nio.file.Files.write(new java.io.File(dstDir, s).toPath(), buf);
                n++;
            } catch (Exception ignored) { /* 单文件失败跳过 */ }
        }
        return n;
    }
}
