package com.hermes.android.agent;

import android.content.Context;

import com.hermes.android.a2a.A2aClient;
import com.hermes.android.model.ModelRegistry;
import com.hermes.android.agent.VideoSourceRegistry;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * HealthProbeFactory — HealthMonitor 真实探测目标构建（H2 件一）。
 *
 * 四类起步：视频源全量（可达性 HEAD）+ 模型（已配置？）+ Hermes serve（healthz）+ relay。
 * 探测函数都是轻量（HEAD/最小查询，5s 硬顶由 HealthMonitor.runWithTimeout 兜底），
 * 失败归因用 H1 reason code（DESIGN_TOOL_HEALTH §三）。
 */
public class HealthProbeFactory {

    /** 构建真实探测目标（Hermes serve token 由 HermesServeConfig 提供） */
    public static List<HealthMonitor.Target> build(Context ctx) {
        List<HealthMonitor.Target> targets = new ArrayList<>();

        // ── 视频源（可达性探测: HEAD searchUrl）──
        try {
            VideoSourceRegistry reg = new VideoSourceRegistry(ctx);
            for (VideoSourceRegistry.Source s : reg.list()) {
                if (!s.enabled) continue;
                final String url = s.searchUrl != null ? s.searchUrl : s.embedUrl;
                targets.add(new HealthMonitor.Target(s.id, "video", () -> probeHttp(url)));
            }
        } catch (Exception ignored) {}

        // ── 模型（未配置 → NOT_CONFIGURED）──
        targets.add(new HealthMonitor.Target("model", "model", () -> {
            try {
                if (ModelRegistry.getInstance(ctx).list().isEmpty()) {
                    return new HealthMonitor.ProbeResult(
                            ToolRegistry.Result.REASON_NOT_CONFIGURED, "未配置模型");
                }
                return null;
            } catch (Exception e) {
                return new HealthMonitor.ProbeResult(ToolRegistry.Result.REASON_UNKNOWN, "模型探测异常");
            }
        }));

        // ── Hermes serve（healthz）──
        targets.add(new HealthMonitor.Target("hermes", "serve", () -> {
            try {
                HermesClient c = new HermesClient(HermesServeConfig.token(ctx));
                return c.healthz(2000) ? null
                        : new HealthMonitor.ProbeResult(ToolRegistry.Result.REASON_SOURCE_DOWN, "serve 未起");
            } catch (Exception e) {
                return new HealthMonitor.ProbeResult(ToolRegistry.Result.REASON_UNKNOWN, "serve 探测异常");
            }
        }));

        // ── relay（可达性 HEAD baseUrl）──
        targets.add(new HealthMonitor.Target("relay", "relay", () -> {
            try {
                String base = new A2aClient(ctx).baseUrl();
                return probeHttp(base);
            } catch (Exception e) {
                return new HealthMonitor.ProbeResult(ToolRegistry.Result.REASON_UNKNOWN, "relay 探测异常");
            }
        }));

        return targets;
    }

    /** 可达性探测：连接成功(任意 HTTP 响应)=正常；连接失败=SOURCE_DOWN；4xx/5xx=SOURCE_DOWN(站点响应但异常) */
    static HealthMonitor.ProbeResult probeHttp(String url) {
        if (url == null || url.trim().isEmpty()) {
            return new HealthMonitor.ProbeResult(ToolRegistry.Result.REASON_NOT_CONFIGURED, "无 URL");
        }
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestMethod("HEAD");
            conn.setConnectTimeout(4000);
            conn.setReadTimeout(4000);
            conn.setInstanceFollowRedirects(false);
            int code = conn.getResponseCode();
            if (code >= 200 && code < 400) return null;   // 可达
            return new HealthMonitor.ProbeResult(ToolRegistry.Result.REASON_SOURCE_DOWN, "HTTP " + code);
        } catch (Exception e) {
            return new HealthMonitor.ProbeResult(ToolRegistry.Result.REASON_SOURCE_DOWN,
                    "连不上: " + e.getClass().getSimpleName());
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
