package com.hermes.android.agent;

import android.content.Context;

import com.hermes.android.linux.HermesInstaller;
import com.hermes.android.linux.ProotRunner;
import com.hermes.android.linux.RootfsManager;

import java.io.File;

/**
 * HeavyWorker — 内嵌 Hermes 委派 (CONTRACT: Worker §5)。
 *
 * P2 M2 起双路径：
 *  - serve 路径（默认）：常驻 hermes mov-serve（127.0.0.1:8387）——healthz-on-call →
 *    懒启动（ProotRunner.startDaemon）→ POST /task → 轮询结果。后续调用零拉起延迟。
 *  - exec 路径（回退开关）：`hermes -z` 一次性（旧行为）。
 * 开关：HermesServeConfig.isServeEnabled()（默认开）；serve 不可达/起不来 → 自动落回 exec。
 * 任务提交成功 → serve 权威（失败/取消/超时都算 serve 结果，不 exec 重跑）。
 * 安全三件套平移：sanitize/产物校验留本侧；禁网经 constraints 下发（serve per-task unset proxy）。
 */
public class HeavyWorker implements Worker {

    /* M4 韧性 §三.4/三.5: 按 pidfile kill 旧 daemon 再起（升级重装/端口冲突；healthz 失败才走这，
        kill 不存在的 PID 静默无副作用） */
    private static final String SERVE_CMD =
            "kill $(cat /exchange/mov-serve.pid 2>/dev/null) 2>/dev/null; sleep 1; "
            + "~/.hermes-venv/bin/hermes mov-serve";
    private static final String TAG = "HeavyWorker";

    /** M3: Hermes serve 进度回调（→ BridgeAi → 房间进度卡；可空） */
    public interface ProgressListener {
        void onProgress(String text);
    }

    private final Context context;
    private final File roomWorkDir;
    private volatile boolean cancelled = false;
    private volatile ProgressListener progressListener;

    public HeavyWorker(Context context, File roomWorkDir) {
        this.context = context;
        this.roomWorkDir = roomWorkDir;
    }

    public void setProgressListener(ProgressListener l) {
        this.progressListener = l;
    }

    @Override
    public String id() {
        return "heavy:hermes";
    }

    @Override
    public boolean available() {
        return RootfsManager.isReady(context)
                && new HermesInstaller(context).isReady();
    }

    @Override
    public WorkerResult run(WorkerTask task) {
        if (!available()) {
            return WorkerResult.fail(WorkerResult.UNAVAILABLE,
                    "Hermes 未安装或 Linux 环境未就绪", false);
        }
        cancelled = false;

        /* 安全三件套 §1: 任务描述 sanitize (危险指令模式拒绝, 两路径共用) */
        String instruction = sanitize(task.instruction);
        if (instruction == null) {
            return WorkerResult.fail(WorkerResult.INTERNAL,
                    "任务描述含危险指令模式, 已拒绝", false);
        }

        if (HermesServeConfig.isServeEnabled(context)) {
            WorkerResult sr = runViaServe(task, instruction);
            if (sr != null) return sr;   // serve 路径处理完毕
            // null → serve 不可达/起不来 → 落回 exec
        }
        return runViaExec(task, instruction);
    }

    @Override
    public void cancel() {
        cancelled = true;
    }

    // ==================== serve 路径 (P2 M2) ====================

    /**
     * serve 路径：healthz-on-call → 懒启动 → 提交 → M3 SSE 等结果（progress→UI）。
     * SSE 断线重连 3 次降级 → M2 轮询兜底。
     * @return null = serve 不可达（调用方落回 exec）；非 null = serve 已处理（含任务失败/取消/超时）
     */
    private WorkerResult runViaServe(WorkerTask task, String instruction) {
        String token;
        try {
            token = HermesServeConfig.token(context);
        } catch (Exception e) {
            return null;   // 加密存储不可用 → 保守走 exec
        }
        HermesClient client = new HermesClient(token);

        // healthz-on-call: 不通 → 懒启动 serve（10s 上限）
        try {
            /* M4 韧性 §三.1/三.2: healthz-on-call → 杀 daemon 后自动恢复 / 空闲退出后再懒启动。
               logcat 计时（杀→拉起→就绪全链）供真机验收对照 */
            long recoverT0 = System.currentTimeMillis();
            if (!ensureServeUp(client, () -> {
                android.util.Log.i(TAG, "serve healthz 不通 → 懒启动拉起 (" + SERVE_CMD + ")");
                ProotRunner.startDaemon(context, SERVE_CMD, token);
            })) {
                android.util.Log.w(TAG, "serve 恢复失败 (" + (System.currentTimeMillis() - recoverT0)
                        + "ms) → 落回 exec");
                return null;   // 起不来 → 回退 exec
            }
            android.util.Log.i(TAG, "serve 就绪 (" + (System.currentTimeMillis() - recoverT0) + "ms)");
        } catch (Exception e) {
            return null;
        }

        // 提交任务：提交失败 → 回退 exec（serve 不可用）；提交成功 → serve 权威
        final String taskId;
        try {
            taskId = client.submitTask(instruction, task.network, task.timeoutSec, task.maxTokens);
        } catch (Exception e) {
            return null;
        }

        // M3: SSE 订阅（progress→进度监听器；终态→取完整结果）。断线重连 3 次 → 降级轮询。
        java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
        final WorkerResult[] result = {null};
        final java.util.concurrent.atomic.AtomicBoolean degraded =
                new java.util.concurrent.atomic.AtomicBoolean(false);
        HermesEventListener.Listener sse = new HermesEventListener.Listener() {
            @Override public void onEvent(String tid, String kind, String data) {
                if (HermesEventListener.KIND_PROGRESS.equals(kind)) {
                    ProgressListener p = progressListener;
                    if (p != null && data != null && !data.isEmpty()) p.onProgress(data);
                    return;
                }
                if (HermesEventListener.isTerminal(kind)) {
                    try {
                        HermesClient.TaskResult r = client.getTask(tid);   // 完整结果（SSE data 仅 500 截断）
                        result[0] = fromTaskResult(r, task.maxTokens);
                    } catch (Exception e) {
                        result[0] = WorkerResult.fail(WorkerResult.INTERNAL,
                                "取完整结果失败: " + e.getMessage(), true);
                    }
                    done.countDown();
                }
            }
            @Override public void onDegraded() {
                degraded.set(true);
                done.countDown();
            }
        };
        HermesEventListener el = new HermesEventListener(HermesClient.BASE_URL, token, taskId, sse);
        el.start();

        long deadline = System.currentTimeMillis() + task.timeoutSec * 1000L;
        try {
            while (true) {
                if (cancelled) {
                    el.stop();
                    client.cancelTask(taskId);
                    return WorkerResult.fail(WorkerResult.CANCELLED, "用户取消", false);
                }
                if (result[0] != null) { el.stop(); return result[0]; }
                if (degraded.get()) { el.stop(); break; }   // SSE 降级 → M2 轮询
                long remaining = deadline - System.currentTimeMillis();
                if (remaining <= 0) {
                    el.stop();
                    client.cancelTask(taskId);
                    return WorkerResult.fail(WorkerResult.TIMEOUT,
                            "serve 任务超时 (" + task.timeoutSec + "s)", true);
                }
                done.await(Math.min(remaining, 300), java.util.concurrent.TimeUnit.MILLISECONDS);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            el.stop();
            return WorkerResult.fail(WorkerResult.CANCELLED, "中断", false);
        }
        // 降级: M2 轮询兜底（事件语义/延迟指标不变）
        return pollUntilTerminal(client, task, taskId);
    }

    /**
     * M4: serve 恢复决策（可注入测，零网络）——healthz 通直接用；
     * 不通 → startDaemon 拉起 → waitHealthy；恢复失败返回 false（调用方落回 exec）。
     * 这就是「杀 daemon 自动恢复」与「空闲退出后再懒启动」的同一路径。
     */
    static boolean ensureServeUp(HermesClient client, Runnable startDaemon) {
        try {
            if (!client.healthz(1500)) {
                startDaemon.run();
                return client.waitHealthy(10_000);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** M2 轮询兜底：GET /task 轮询到终态（SSE 降级时用；SSE 稳定时不走这里） */
    private WorkerResult pollUntilTerminal(HermesClient client, WorkerTask task, String taskId) {
        long deadline = System.currentTimeMillis() + task.timeoutSec * 1000L;
        while (System.currentTimeMillis() < deadline) {
            if (cancelled) {
                client.cancelTask(taskId);
                return WorkerResult.fail(WorkerResult.CANCELLED, "用户取消", false);
            }
            HermesClient.TaskResult r;
            try {
                r = client.getTask(taskId);
            } catch (Exception e) {
                return WorkerResult.fail(WorkerResult.INTERNAL,
                        "serve 轮询失败: " + e.getMessage(), true);
            }
            if (HermesClient.STATUS_DONE.equals(r.status)
                    || HermesClient.STATUS_FAILED.equals(r.status)
                    || HermesClient.STATUS_CANCELLED.equals(r.status)) {
                WorkerResult wr = fromTaskResult(r, task.maxTokens);
                return wr != null ? wr : WorkerResult.fail(WorkerResult.INTERNAL,
                        "serve 任务异常终态", false);
            }
            try { Thread.sleep(300); } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return WorkerResult.fail(WorkerResult.CANCELLED, "中断", false);
            }
        }
        client.cancelTask(taskId);
        return WorkerResult.fail(WorkerResult.TIMEOUT,
                "serve 任务超时 (" + task.timeoutSec + "s)", true);
    }

    /** serve 任务结果 → WorkerResult（安全三件套 §3 产物校验在此；包可见供 M5 越界产物测试） */
    static WorkerResult fromTaskResult(HermesClient.TaskResult r, int maxTokens) {
        if (HermesClient.STATUS_DONE.equals(r.status)) {
            if (maxTokens > 0 && r.output != null && r.output.length() > maxTokens * 4) {
                return WorkerResult.fail(WorkerResult.OUTPUT_TOO_LARGE,
                        "产物超 maxTokens 上限 (" + maxTokens + ")", false);
            }
            return WorkerResult.success(r.output != null ? r.output : "");
        }
        if (HermesClient.STATUS_FAILED.equals(r.status)) {
            boolean retryable = r.error != null
                    && (r.error.contains("timeout") || r.error.contains("connection"));
            return WorkerResult.fail(retryable ? WorkerResult.STALLED : WorkerResult.INTERNAL,
                    r.error != null ? r.error : "serve 任务失败", retryable);
        }
        if (HermesClient.STATUS_CANCELLED.equals(r.status)) {
            return WorkerResult.fail(WorkerResult.CANCELLED, "serve 任务被取消", false);
        }
        return null;
    }

    // ==================== exec 路径（回退开关，旧行为） ====================

    private WorkerResult runViaExec(WorkerTask task, String instruction) {
        /* 安全三件套 §2: 默认禁网 (constraints.network=false 时)
           M5 加固: 直连设备下 unset proxy 不生效 (实证), 必须 LD_PRELOAD 禁网库才真正断网。
           禁网库缺失 → fail-closed 拒绝任务, 不许带网跑。 */
        String netFlag;
        if (task.network) {
            netFlag = "";
        } else if (new File(context.getFilesDir(),
                "linux-exchange/hermes-agent/mov_nonet.so").isFile()) {
            netFlag = "unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY; "
                    + "export LD_PRELOAD=/exchange/hermes-agent/mov_nonet.so; ";
        } else {
            return WorkerResult.fail(WorkerResult.INTERNAL,
                    "禁网不可用: mov_nonet.so 缺失 (network=false 任务被拒绝)", false);
        }

        String cmd = netFlag + "~/.hermes-venv/bin/hermes -z "
                + shellQuote(instruction);

        try {
            ProotRunner.ExecResult result = ProotRunner.exec(
                    context, cmd, task.timeoutSec, roomWorkDir);

            if (cancelled) {
                return WorkerResult.fail(WorkerResult.CANCELLED, "用户取消", false);
            }
            if (result.exitCode != 0) {
                String err = result.stderr.isEmpty() ? result.stdout : result.stderr;
                boolean retryable = err.contains("timeout") || err.contains("connection");
                return WorkerResult.fail(
                        retryable ? WorkerResult.STALLED : WorkerResult.INTERNAL,
                        "exit=" + result.exitCode + " " + err.trim(),
                        retryable);
            }

            /* 安全三件套 §3: 产物 canonical 回写校验在 /room 内 */
            String output = result.stdout;
            if (task.maxTokens > 0 && output.length() > task.maxTokens * 4) {
                return WorkerResult.fail(WorkerResult.OUTPUT_TOO_LARGE,
                        "产物超 maxTokens 上限 (" + task.maxTokens + ")", false);
            }

            return WorkerResult.success(output);
        } catch (Exception e) {
            return WorkerResult.fail(WorkerResult.INTERNAL,
                    "Hermes 执行异常: " + e.getMessage(), false);
        }
    }

    /* 危险指令模式过滤 (M5 实证清单: 删根/反引号注入/路径穿越/高危模式) */
    static String sanitize(String input) {
        if (input == null) return null;
        String lower = input.toLowerCase();
        String[] dangerous = {
                "rm -rf /", "rm -fr /", "rm -rf /*",   /* 删根 */
                "mkfs", "dd if=", "> /dev/sd", "chmod 777 /", ":(){", "fork bomb",
                "`", "$(",                             /* 反引号/命令替换注入 */
                "../", "..\\",                         /* 路径穿越 */
        };
        for (String d : dangerous) {
            if (lower.contains(d)) return null;
        }
        return input;
    }

    private static String shellQuote(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }
}
