package com.hermes.android.vault;

import com.hermes.android.security.PiiMasker;

import java.io.File;
import java.nio.file.Files;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * DualWriter — 双副本分流器（DESIGN_OCR_MOBILE v2 §六）。
 *
 * 输入「原始文本 + 原图路径」→
 *   ① PiiMasker 打码 → 净化副本（自由流通区：可进慢脑、可上云端精修，删除非遮蔽不可复原）
 *   ② 原文 + 原图 → SecureVault.lock（保险柜：只用户本人 Keyguard 可见，慢脑默认不可见、云端默认拒绝）
 *
 * 两区不许混存：净化副本绝不回存原文（assertNoDigitLeak 断言，≥16 位数字串 = 证件号/卡号
 * 必然被 PiiMasker 打码，若出现在净化副本即泄漏 → 拒绝写入，防「净化区 = 原文」的混存）。
 */
public class DualWriter {

    public static class Result {
        public final String maskedText;    // ① 净化副本（自由流通区）
        public final String textVaultId;   // ② 原文保险柜 id
        public final String imageVaultId;  // ② 原图保险柜 id（无原图可空）

        Result(String maskedText, String textVaultId, String imageVaultId) {
            this.maskedText = maskedText;
            this.textVaultId = textVaultId;
            this.imageVaultId = imageVaultId;
        }
    }

    /** 身份证(17+1)/银行卡(16-19) 必然命中 PiiMasker 的最短长度 —— 出现在净化副本即泄漏 */
    private static final Pattern LEAK_RUN = Pattern.compile("\\d{16,}");

    /**
     * 双副本分流。
     * @param vault     保险柜（原文+原图落这里）
     * @param name      条目名（脱敏由 SecureVault.sanitizeName 处理）
     * @param rawText   原始文本（OCR 识别结果 / 敏感文档）
     * @param imagePath 原图路径（可空；存在则原图字节入保险柜）
     * @return 净化副本 + 两个保险柜 id
     */
    public static Result split(SecureVault vault, String name, String rawText, String imagePath) throws Exception {
        if (vault == null) throw new VaultException("NO_VAULT", "保险柜不可用");
        if (rawText == null || rawText.isEmpty()) throw new VaultException("EMPTY", "原文为空，无需分流");

        // ① 净化副本（自由流通区）：PII 打码 → 删除非遮蔽，不可复原
        String masked = PiiMasker.mask(rawText);
        assertNoCrossStorage(rawText, masked);   // 两区不许混存断言

        // ② 原始副本（保险柜）：原文 + 原图
        String textId = vault.lock(name, rawText);
        String imageId = null;
        if (imagePath != null && !imagePath.trim().isEmpty()) {
            File img = new File(imagePath.trim());
            if (img.exists() && img.isFile()) {
                byte[] bytes = Files.readAllBytes(img.toPath());
                imageId = vault.lockBytes(name + " 原图", bytes);
            }
        }
        return new Result(masked, textId, imageId);
    }

    /** 净化区不得回存原文：原文里的 ≥16 位连续数字（证件号/卡号，PiiMasker 必然打码）
     *  若原样出现在净化副本 → 说明打码被跳过/失效 → 抛异常拒绝写入（防两区混存）。 */
    static void assertNoCrossStorage(String rawText, String maskedText) {
        if (rawText == null || maskedText == null) return;
        Matcher m = LEAK_RUN.matcher(rawText);
        while (m.find()) {
            String seg = m.group();
            if (maskedText.contains(seg)) {
                String head = seg.length() > 4 ? seg.substring(0, 4) : seg;
                throw new IllegalStateException(
                        "净化副本泄漏原文数字片段(" + head + "…): 两区不许混存，已拒绝写入净化区");
            }
        }
    }
}
