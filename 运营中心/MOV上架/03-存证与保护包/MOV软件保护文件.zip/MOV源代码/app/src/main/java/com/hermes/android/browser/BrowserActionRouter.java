package com.hermes.android.browser;

/**
 * 浏览器动作类型分派（纯 JVM，可单测）——每个已知类型都有执行落点，防静默丢弃。
 * 类型集 = mov_connect.js executeAction 支持的（click/type/scroll/submit）+ Java 复合
 * （click_and_read/wait_for/open）+ 高危 execute(eval_js)。
 */
public class BrowserActionRouter {

    /** 全部已知动作类型（每个必须有执行落点，未知类型 executeBrowserAction 报错回执） */
    public static final String[] KNOWN = {
        "click", "type", "scroll", "submit",   // mov_connect.executeAction
        "click_and_read", "wait_for", "open",  // Java 复合/导航
        "snapshot", "get_text",                 // W2: 页面快照/读正文（readonly）
        "execute",                              // eval_js（高危）
    };

    /** 写动作（有副作用，需审批闸；scroll 非写免审批） */
    public static boolean isWrite(String type) {
        return "click".equals(type) || "type".equals(type)
                || "submit".equals(type) || "execute".equals(type);
    }

    /** 已知类型（有执行落点） */
    public static boolean isKnown(String type) {
        if (type == null) return false;
        for (String k : KNOWN) if (k.equals(type)) return true;
        return false;
    }
}
