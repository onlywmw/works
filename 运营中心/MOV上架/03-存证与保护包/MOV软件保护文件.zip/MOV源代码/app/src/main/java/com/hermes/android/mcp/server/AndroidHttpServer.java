package com.hermes.android.mcp.server;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MCP HTTP 帧层 — 裸 ServerSocket + 每连接一线程。
 *
 * 纯 Java（不 import android.*），JVM 单测可直接起真实端口。只做 HTTP 帧的
 * 解析/响应，协议（JSON-RPC / session / SSE）全部交给 {@link RequestHandler}。
 *
 * 端点：POST/GET/DELETE /mcp（与官方 HttpServletStreamableServerTransportProvider 对齐）。
 * SSE 流式响应：{@link HttpResponse#stream} 由调用方在写头后执行，完成后连接关闭。
 */
public class AndroidHttpServer {

    private static final int READ_TIMEOUT_MS = 120_000;  // 普通请求读超时（防连接泄漏）

    /** 协议处理器：收到解析好的请求，返回响应。 */
    public interface RequestHandler {
        HttpResponse handle(HttpRequest req);
    }

    /** 解析后的 HTTP 请求。headers 键已小写。 */
    public static class HttpRequest {
        public final String method;
        public final String path;
        public final Map<String, String> headers;
        public final String body;

        public HttpRequest(String method, String path, Map<String, String> headers, String body) {
            this.method = method;
            this.path = path;
            this.headers = headers;
            this.body = body;
        }

        public String header(String name) { return headers.get(name.toLowerCase()); }
    }

    /** 响应。body 与 stream 二选一：body 非空时普通 JSON 响应；stream 非空时 SSE 流式写。 */
    public static class HttpResponse {
        public final int status;
        public final Map<String, String> headers;
        public final String body;          // 可空
        public final StreamWriter stream;  // 可空（SSE 长写，写完后由 server 关闭连接）

        public HttpResponse(int status, Map<String, String> headers, String body, StreamWriter stream) {
            this.status = status;
            this.headers = headers != null ? headers : new HashMap<>();
            this.body = body;
            this.stream = stream;
        }

        public static HttpResponse json(int status, String body) {
            Map<String, String> h = new HashMap<>();
            h.put("Content-Type", "application/json; charset=utf-8");
            return new HttpResponse(status, h, body, null);
        }

        public static HttpResponse json(int status, Map<String, String> headers, String body) {
            return new HttpResponse(status, headers, body, null);
        }
    }

    /** SSE 流式写响应体。完成后返回，server 关闭 socket。socket 可读写（GET 监听流需读断开信号）。 */
    public interface StreamWriter {
        void write(Socket socket) throws IOException;
    }

    private final RequestHandler handler;
    private int port;
    private ServerSocket serverSocket;
    private volatile boolean running;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Set<Socket> openSockets = ConcurrentHashMap.newKeySet();

    public AndroidHttpServer(int port, RequestHandler handler) {
        this.port = port;
        this.handler = handler;
    }

    /** 幂等启动。固定传入端口绑定，被占返回 false（明确失败降级）。
        技术债修复（工单5）：原自动上移 +200 导致实际端口偏移（8389→8390），
        客户端/文档假设固定端口会失联；端口确定优先于可用性。 */
    public synchronized boolean start() {
        if (running) return true;
        try {
            ServerSocket ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress("127.0.0.1", port));
            this.serverSocket = ss;
            this.port = ss.getLocalPort();  // 实际绑定端口（端口 0 = OS 自动分配）
            this.running = true;
            pool.submit(this::acceptLoop);
            return true;
        } catch (IOException e) {
            return false;   // 端口被占：明确失败，调用方决定降级
        }
    }

    public synchronized void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (IOException ignored) {}
        for (Socket s : openSockets) {
            try { s.close(); } catch (IOException ignored) {}
        }
        openSockets.clear();
        pool.shutdownNow();
    }

    /** 实际绑定端口（端口被占时可能偏移）。 */
    public int getPort() { return port; }
    public boolean isRunning() { return running; }

    private void acceptLoop() {
        while (running) {
            try {
                Socket client = serverSocket.accept();
                openSockets.add(client);
                pool.submit(() -> handleConnection(client));
            } catch (Exception e) {
                if (running) System.err.println("MCP http accept: " + e.getMessage());
            }
        }
    }

    private void handleConnection(Socket client) {
        try {
            client.setSoTimeout(READ_TIMEOUT_MS);
            /* P4 真机验收 2026-08-05: 同 MovInboundServer —— Content-Length 是字节数,
               按字符读多字节 UTF-8 体会阻塞/丢帧; 一律按字节解析。 */
            java.io.BufferedInputStream in =
                    new java.io.BufferedInputStream(client.getInputStream());
            HttpRequest req = parse(in);
            if (req == null) return;

            HttpResponse resp = handler.handle(req);
            OutputStream out = client.getOutputStream();
            writeStatusLine(out, resp.status);
            for (Map.Entry<String, String> e : resp.headers.entrySet()) {
                writeHeader(out, e.getKey(), e.getValue());
            }
            out.write("\r\n".getBytes(StandardCharsets.UTF_8));
            out.flush();

            if (resp.body != null) {
                out.write(resp.body.getBytes(StandardCharsets.UTF_8));
                out.flush();
            } else if (resp.stream != null) {
                resp.stream.write(client);
                out.flush();
            }
        } catch (Exception e) {
            // 客户端断开或帧解析失败：静默（不写 logcat，纯 Java 无 Log）
        } finally {
            openSockets.remove(client);
            try { client.close(); } catch (IOException ignored) {}
        }
    }

    private HttpRequest parse(java.io.BufferedInputStream in) throws IOException {
        String head = readHead(in);
        if (head == null || head.isEmpty()) return null;
        String[] headLines = head.split("\r\n");
        String[] parts = headLines[0].split(" ");
        String method = parts.length > 0 ? parts[0] : "";
        String path = parts.length > 1 ? parts[1].split("\\?")[0] : "";

        Map<String, String> headers = new HashMap<>();
        int contentLength = 0;
        for (int i = 1; i < headLines.length; i++) {
            int idx = headLines[i].indexOf(':');
            if (idx > 0) {
                String k = headLines[i].substring(0, idx).trim().toLowerCase();
                String v = headLines[i].substring(idx + 1).trim();
                headers.put(k, v);
                if ("content-length".equals(k)) {
                    try { contentLength = Integer.parseInt(v); } catch (NumberFormatException ignored) {}
                }
            }
        }

        String body = "";
        if (contentLength > 0) {
            byte[] raw = readFully(in, contentLength);
            body = new String(raw, StandardCharsets.UTF_8);
        }
        return new HttpRequest(method, path, headers, body);
    }

    /** 读请求头字节块 (到 \r\n\r\n, 上限 16KB; 头按 ASCII 安全解码为 UTF-8) */
    private static String readHead(java.io.InputStream in) throws IOException {
        java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
        int b, matched = 0;
        int[] end = {'\r', '\n', '\r', '\n'};
        while ((b = in.read()) != -1) {
            buf.write(b);
            matched = (b == end[matched]) ? matched + 1 : (b == '\r' ? 1 : 0);
            if (matched == 4) {
                byte[] raw = buf.toByteArray();
                return new String(raw, 0, raw.length - 4, StandardCharsets.UTF_8);
            }
            if (buf.size() > 16384) return null;
        }
        return null;
    }

    /** 精确读 n 字节 (EOF 提前结束返回已读部分) */
    private static byte[] readFully(java.io.InputStream in, int n) throws IOException {
        java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream(n);
        byte[] tmp = new byte[Math.min(n, 8192)];
        int off = 0;
        while (off < n) {
            int r = in.read(tmp, 0, Math.min(tmp.length, n - off));
            if (r < 0) break;
            buf.write(tmp, 0, r);
            off += r;
        }
        return buf.toByteArray();
    }

    private void writeStatusLine(OutputStream out, int status) throws IOException {
        String reason = switch (status) {
            case 200 -> "OK";
            case 202 -> "Accepted";
            case 400 -> "Bad Request";
            case 401 -> "Unauthorized";
            case 404 -> "Not Found";
            case 405 -> "Method Not Allowed";
            case 503 -> "Service Unavailable";
            default -> "OK";
        };
        out.write(("HTTP/1.1 " + status + " " + reason + "\r\n").getBytes(StandardCharsets.UTF_8));
    }

    private void writeHeader(OutputStream out, String k, String v) throws IOException {
        out.write((k + ": " + v + "\r\n").getBytes(StandardCharsets.UTF_8));
    }
}
