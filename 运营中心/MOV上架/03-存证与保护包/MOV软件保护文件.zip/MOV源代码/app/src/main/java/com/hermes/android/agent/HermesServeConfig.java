package com.hermes.android.agent;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

/**
 * Hermes 常驻 serve 配置（P2 M2）：token + 路径开关。
 *
 * token 由 MOV 生成（HermesClient.tokenUrlSafe），存 EncryptedSharedPreferences，
 * 经 env（X_MOV_TOKEN）传给 daemon —— daemon 每次启动从 env 读，不落地 rootfs 以外盘（设计 §二）。
 * serve 开关 pref：默认开（serve 优先），exec 路径保留回退。
 */
public class HermesServeConfig {

    private static final String TAG = "HermesServeConfig";
    private static final String PREFS = "hermes_serve_prefs";
    private static final String KEY_TOKEN = "mov_token";
    private static final String KEY_ENABLED = "serve_enabled";
    private static final String KEY_MCP_WRITE = "mcp_write_enabled";

    /** 打开加密 prefs；Keystore 不可用不降级明文（BUG-7 纪律，抛异常让调用方决定） */
    private static SharedPreferences prefs(Context ctx) {
        try {
            MasterKey mk = new MasterKey.Builder(ctx)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build();
            return EncryptedSharedPreferences.create(ctx, PREFS, mk,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
        } catch (Exception e) {
            throw new RuntimeException("Hermes serve 加密存储不可用", e);
        }
    }

    /** 当前 token；不存在则生成并落盘（MOV 侧唯一生成点） */
    public static String token(Context ctx) {
        SharedPreferences p = prefs(ctx);
        String t = p.getString(KEY_TOKEN, null);
        if (t == null || t.isEmpty()) {
            t = HermesClient.tokenUrlSafe();
            p.edit().putString(KEY_TOKEN, t).apply();
            Log.i(TAG, "生成 serve token");
        }
        return t;
    }

    /** serve 路径开关：默认开；关掉走 exec 路径 */
    public static boolean isServeEnabled(Context ctx) {
        try {
            return prefs(ctx).getBoolean(KEY_ENABLED, true);
        } catch (Exception e) {
            return false;   // 加密存储不可用 → 保守走 exec
        }
    }

    public static void setServeEnabled(Context ctx, boolean enabled) {
        try {
            prefs(ctx).edit().putBoolean(KEY_ENABLED, enabled).apply();
        } catch (Exception e) {
            Log.w(TAG, "setServeEnabled: " + e.getMessage());
        }
    }

    /** MCP write 工具显式开关（工单 P5）：默认关闭——写工具不出现在 tools/list，显式开启才暴露。 */
    public static boolean isMcpWriteEnabled(Context ctx) {
        try {
            return prefs(ctx).getBoolean(KEY_MCP_WRITE, false);
        } catch (Exception e) {
            return false;   // 加密存储不可用 → 保守不暴露写工具
        }
    }

    public static void setMcpWriteEnabled(Context ctx, boolean enabled) {
        try {
            prefs(ctx).edit().putBoolean(KEY_MCP_WRITE, enabled).apply();
        } catch (Exception e) {
            Log.w(TAG, "setMcpWriteEnabled: " + e.getMessage());
        }
    }
}
