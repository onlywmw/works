package com.hermes.android.toolprovider

import android.content.Context
import com.hermes.android.agent.ToolRegistry
import com.hermes.android.agent.ToolRegistry.*
import com.hermes.android.model.ModelConfig
import com.hermes.android.model.ModelRegistry
import org.json.JSONArray
import org.json.JSONObject

/**
 * ModelToolProvider — 模型管理工具（Kotlin 版，Java→Kotlin 渐进迁移第一站）。
 */
class ModelToolProvider : ToolProvider {

    companion object {
        private var appContext: Context? = null
        @JvmStatic
        fun init(ctx: Context) { appContext = ctx.applicationContext }
    }

    override fun id() = "model"

    override fun discover(): List<Tool> {
        val ctx = appContext ?: return emptyList()
        return listOf(
            // ═══ model.list — 列出模型 ═══
            Tool("model.list",
                "列出所有已配置的 AI 模型（API Key 已脱敏，只显示是否配置）",
                null,
                Handler { a ->
                    try {
                        val reg = ModelRegistry.getInstance(ctx)
                        val arr = JSONArray()
                        for (c in reg.list()) {
                            val o = JSONObject().apply {
                                put("id", c.id)
                                put("provider", c.provider)
                                put("name", c.name)
                                put("model", c.model)
                                put("hasKey", c.apiKey != null && c.apiKey!!.isNotEmpty())
                                put("isDefault", c.isDefault)
                                put("enabled", c.enabled)
                            }
                            arr.put(o)
                        }
                        Result(true, arr.toString(2))
                    } catch (e: Exception) {
                        Result(false, "获取失败: ${e.message}")
                    }
                },
                "native", "readonly", "none", true, 3, "model",
                arrayOf(),
                "JSON 数组，每项含 id/provider/name/model/hasKey/isDefault/enabled",
                arrayOf("{\"action\":\"tool.execute\",\"name\":\"model.list\",\"args\":{}}"),
                arrayOf("API Key 已脱敏(hasKey=true/false)，不会泄露"),
                2000,
                ToolRegistry.Manifest("模型列表", "low", "查看已配置的AI模型", false, "meta"),
                null
            ),

            // ═══ model.add — 添加模型 ═══
            Tool("model.add",
                "添加一个新的 AI 模型。需要 provider + apiKey + model，baseUrl 可选（空走默认）",
                null,
                Handler { a ->
                    val provider = a.optString("provider", "")
                    val apiKey = a.optString("apiKey", "")
                    val model = a.optString("model", "")
                    if (provider.isEmpty() || apiKey.isEmpty() || model.isEmpty())
                        return@Handler Result(false, "provider/apiKey/model 必填")
                    try {
                        val mc = ModelConfig().apply {
                            this.provider = provider
                            name = a.optString("name", provider)
                            this.model = model
                            this.apiKey = apiKey
                            baseUrl = a.optString("baseUrl", "")
                            enabled = true
                            isDefault = a.optBoolean("isDefault", false)
                            role = a.optString("role", "通用")
                        }
                        val reg = ModelRegistry.getInstance(ctx)
                        val id = reg.add(mc)
                        val o = JSONObject().apply {
                            put("ok", true)
                            put("id", id)
                            put("msg", "模型已添加: ${mc.name}")
                        }
                        Result(true, o.toString())
                    } catch (e: Exception) {
                        Result(false, "添加失败: ${e.message}")
                    }
                },
                "native", "write", "none", true, 5, "model",
                arrayOf(
                    ParamDef("provider", "string", true, "", "厂商key，如 deepseek / qwen / mimo"),
                    ParamDef("apiKey", "string", true, "", "API Key"),
                    ParamDef("model", "string", true, "", "模型名，如 deepseek-v4-flash"),
                    ParamDef("name", "string", false, "默认=provider", "显示名"),
                    ParamDef("baseUrl", "string", false, "空=默认", "自定义Base URL"),
                    ParamDef("isDefault", "boolean", false, "默认 false", "是否设为默认大脑")
                ),
                "成功: {\"ok\":true,\"id\":\"...\",\"msg\":\"...\"} | 失败: 错误原因",
                arrayOf("{\"action\":\"tool.execute\",\"name\":\"model.add\",\"args\":{\"provider\":\"deepseek\",\"apiKey\":\"sk-...\",\"model\":\"deepseek-v4-flash\",\"name\":\"DeepSeek\"}}"),
                arrayOf("apiKey 会加密存储", "首次添加自动设为默认", "provider 必须匹配已支持的厂商预设"),
                1000,
                ToolRegistry.Manifest("添加模型", "medium", "添加AI模型配置", false, "meta"),
                null
            ),

            // ═══ model.set_default — 切换默认模型 ═══
            Tool("model.set_default",
                "切换默认 AI 模型（大脑）。传入模型 id（从 model.list 获取）",
                null,
                Handler { a ->
                    val id = a.optString("id", "")
                    if (id.isEmpty()) return@Handler Result(false, "id 必填")
                    try {
                        val reg = ModelRegistry.getInstance(ctx)
                        // H1: 无配置 → NOT_CONFIGURED（模型被清/从未配置）
                        if (reg.list().isEmpty())
                            return@Handler Result(false, "未配置任何模型，先用 model.add 配置",
                                null, null, Result.REASON_NOT_CONFIGURED)
                        val ok = reg.setDefault(id)
                        if (ok) Result(true, "默认模型已切换: $id")
                        else Result(false, "模型不存在: $id", null, null, Result.REASON_NOT_REGISTERED)
                    } catch (e: Exception) {
                        Result(false, "切换失败: ${e.message}", null, null, Result.REASON_UNKNOWN)
                    }
                },
                "native", "write", "none", true, 3, "model",
                arrayOf(
                    ParamDef("id", "string", true, "", "模型 ID（从 model.list 获取）")
                ),
                "成功: 已切换 | 失败: 模型不存在",
                arrayOf("{\"action\":\"tool.execute\",\"name\":\"model.set_default\",\"args\":{\"id\":\"1caed833\"}}"),
                arrayOf("需要先用 model.list 获取模型 id"),
                500,
                ToolRegistry.Manifest("切换模型", "medium", "设置默认AI模型", false, "meta"),
                null
            )
        )
    }
}
