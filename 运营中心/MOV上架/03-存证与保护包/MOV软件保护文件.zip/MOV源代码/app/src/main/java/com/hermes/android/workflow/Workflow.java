package com.hermes.android.workflow;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Workflow 模型 — canonical JSON 真理源（纯 JVM，org.json）。
 * trigger/conditions/actions 存原始 JSONObject/JSONArray（灵活扩展字段，parse 默认值兜底）。
 * 可变状态（lastFireAt/runsToday/runsTodayDate/runCount）由引擎 recordFire 更新。
 */
public class Workflow {

    public final String id;
    public String name;
    public boolean enabled;
    public final JSONObject trigger;      // {type, ...params}
    public final JSONArray conditions;    // [{type, params..., invert}]
    public final JSONArray actions;       // [{type, params...}]
    public long cooldownMs;               // 0 = 无冷却
    public int maxRunsPerDay;             // 0 = 无限
    public long lastFireAt;               // 0 = 从未触发
    public int runsToday;
    public String runsTodayDate;          // "yyyy-MM-dd"
    public long runCount;                 // 累计触发（count 条件引用）

    public Workflow(String id, JSONObject trigger, JSONArray conditions, JSONArray actions) {
        this.id = id;
        this.enabled = true;   // 默认启用（与 fromJson 的 optBoolean(..., true) 一致）
        this.trigger = trigger != null ? trigger : new JSONObject();
        this.conditions = conditions != null ? conditions : new JSONArray();
        this.actions = actions != null ? actions : new JSONArray();
    }

    public static Workflow fromJson(JSONObject o) {
        Workflow w = new Workflow(
                o.optString("id", ""),
                o.optJSONObject("trigger"),
                o.optJSONArray("conditions"),
                o.optJSONArray("actions"));
        w.name = o.optString("name", w.id);
        w.enabled = o.optBoolean("enabled", true);
        w.cooldownMs = o.optLong("cooldownMs", 0);
        w.maxRunsPerDay = o.optInt("maxRunsPerDay", 0);
        w.lastFireAt = o.optLong("lastFireAt", 0);
        w.runsToday = o.optInt("runsToday", 0);
        w.runsTodayDate = o.optString("runsTodayDate", "");
        w.runCount = o.optLong("runCount", 0);
        return w;
    }

    public JSONObject toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("name", name != null ? name : id);
            o.put("enabled", enabled);
            o.put("trigger", trigger);
            o.put("conditions", conditions);
            o.put("actions", actions);
            o.put("cooldownMs", cooldownMs);
            o.put("maxRunsPerDay", maxRunsPerDay);
            o.put("lastFireAt", lastFireAt);
            o.put("runsToday", runsToday);
            o.put("runsTodayDate", runsTodayDate != null ? runsTodayDate : "");
            o.put("runCount", runCount);
            return o;
        } catch (Exception e) {
            throw new RuntimeException("Workflow.toJson failed", e);
        }
    }

    public String triggerType() {
        return trigger.optString("type", "");
    }
}
