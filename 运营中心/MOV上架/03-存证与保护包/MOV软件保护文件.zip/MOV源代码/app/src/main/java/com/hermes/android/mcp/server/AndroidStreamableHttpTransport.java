package com.hermes.android.mcp.server;

import io.modelcontextprotocol.json.McpJsonMapper;
import io.modelcontextprotocol.json.TypeRef;
import io.modelcontextprotocol.spec.McpSchema;
import io.modelcontextprotocol.spec.McpStreamableServerSession;
import io.modelcontextprotocol.spec.McpStreamableServerTransport;
import io.modelcontextprotocol.spec.McpStreamableServerTransportProvider;
import io.modelcontextprotocol.spec.ProtocolVersions;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * MCP Streamable HTTP transport — 官方 {@link McpStreamableServerTransportProvider} 的
 * 纯 Java 实现（对接 {@code McpServer.sync()}）。
 *
 * 协议状态机（initialize 握手/版本协商/capabilities/tools 分发）全在官方 SDK
 * （McpAsyncServer），本类只做三件事：
 *  1. HTTP 帧 → JSON-RPC 消息（{@link McpSchema#deserializeJsonRpcMessage}）
 *  2. session 生命周期：initialize 建 session、Mcp-Session-Id 定位、DELETE 清理
 *  3. SSE 帧：responseStream/listeningStream 的写 + 阻塞到完成/断开
 *
 * 接入方式（与官方 HttpServletStreamableServerTransportProvider 同构）：
 *  <pre>
 *   McpSyncServer server = McpServer.sync(transport).serverInfo(...).build();
 *   // build() 时 SDK 自动回调 setSessionFactory()
 *  </pre>
 * 端点：POST/GET/DELETE /mcp。鉴权：Authorization: Bearer &lt;token&gt;（或 X-Mov-Token），fail-closed。
 */
public class AndroidStreamableHttpTransport
        implements McpStreamableServerTransportProvider, AndroidHttpServer.RequestHandler {

    public static final String ENDPOINT = "/mcp";
    private static final String JSON = "application/json";
    private static final String SSE = "text/event-stream";

    private final McpJsonMapper jsonMapper;
    private final String token;
    private volatile boolean closing;
    private volatile McpStreamableServerSession.Factory sessionFactory;
    private final Map<String, McpStreamableServerSession> sessions = new ConcurrentHashMap<>();

    public AndroidStreamableHttpTransport(McpJsonMapper jsonMapper, String token) {
        this.jsonMapper = jsonMapper;
        this.token = token;
    }

    // ═══ McpStreamableServerTransportProvider ═══

    @Override
    public List<String> protocolVersions() {
        // 全版本支持：SDK 与客户端协商到双方最高共同版本（官方 asyncInitializeRequestHandler 逻辑）
        return List.of(ProtocolVersions.MCP_2024_11_05, ProtocolVersions.MCP_2025_03_26,
                ProtocolVersions.MCP_2025_06_18, ProtocolVersions.MCP_2025_11_25);
    }

    @Override
    public void setSessionFactory(McpStreamableServerSession.Factory factory) {
        this.sessionFactory = factory;
    }

    @Override
    public Mono<Void> notifyClients(String notification, Object params) {
        // P1 无服务器主动推送（P2 审批通知接入后再实现），保持空实现
        return Mono.empty();
    }

    @Override
    public Mono<Void> closeGracefully() {
        closing = true;
        for (McpStreamableServerSession s : sessions.values()) {
            try { s.close(); } catch (Exception ignored) {}
        }
        sessions.clear();
        return Mono.empty();
    }

    @Override
    public void close() {
        closeGracefully().subscribe();
    }

    // ═══ AndroidHttpServer.RequestHandler ═══

    @Override
    public AndroidHttpServer.HttpResponse handle(AndroidHttpServer.HttpRequest req) {
        String authError = authError(req);
        if (authError != null) return rpcError(401, "UNAUTHORIZED", authError);
        if (!ENDPOINT.equals(req.path)) return rpcError(404, "NOT_FOUND", "未知端点: " + req.path);
        if (closing) return rpcError(503, "SHUTTING_DOWN", "服务关闭中");
        switch (req.method) {
            case "POST":   return handlePost(req);
            case "GET":    return handleGet(req);
            case "DELETE": return handleDelete(req);
            default:       return rpcError(405, "METHOD_NOT_ALLOWED", "仅支持 POST/GET/DELETE");
        }
    }

    // ── POST ──

    private AndroidHttpServer.HttpResponse handlePost(AndroidHttpServer.HttpRequest req) {
        List<String> bad = new ArrayList<>();
        String accept = req.header("accept");
        if (accept == null || !accept.contains(SSE)) bad.add("text/event-stream required in Accept header");
        if (accept == null || !accept.contains(JSON)) bad.add("application/json required in Accept header");

        McpSchema.JSONRPCMessage message;
        try {
            message = McpSchema.deserializeJsonRpcMessage(jsonMapper, req.body);
        } catch (Exception e) {
            return rpcError(400, "INVALID_REQUEST", "无效 JSON 消息: " + e.getMessage());
        }

        // ── initialize：建 session，返回 JSON + Mcp-Session-Id ──
        if (message instanceof McpSchema.JSONRPCRequest jsonrpcRequest
                && McpSchema.METHOD_INITIALIZE.equals(jsonrpcRequest.method())) {
            if (!bad.isEmpty()) return rpcError(400, "INVALID_ACCEPT", String.join("; ", bad));
            try {
                McpSchema.InitializeRequest initReq = jsonMapper.convertValue(jsonrpcRequest.params(),
                        new TypeRef<McpSchema.InitializeRequest>() {});
                McpStreamableServerSession.McpStreamableServerSessionInit init =
                        sessionFactory.startSession(initReq);
                sessions.put(init.session().getId(), init.session());
                McpSchema.InitializeResult initResult = init.initResult().block();
                String json = jsonMapper.writeValueAsString(new McpSchema.JSONRPCResponse(
                        McpSchema.JSONRPC_VERSION, jsonrpcRequest.id(), initResult, null));
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", JSON + "; charset=utf-8");
                headers.put("Mcp-Session-Id", init.session().getId());
                return new AndroidHttpServer.HttpResponse(200, headers, json, null);
            } catch (Exception e) {
                return rpcError(500, "INIT_FAILED", "初始化失败: " + e.getMessage());
            }
        }

        // ── 非 initialize：必须带 session id ──
        String sessionId = req.header("mcp-session-id");
        if (sessionId == null || sessionId.isBlank()) {
            bad.add("Session ID required in mcp-session-id header");
        }
        if (!bad.isEmpty()) return rpcError(400, "INVALID_REQUEST", String.join("; ", bad));

        McpStreamableServerSession session = sessions.get(sessionId);
        if (session == null) return rpcError(404, "SESSION_NOT_FOUND", "Session not found: " + sessionId);

        if (message instanceof McpSchema.JSONRPCResponse jsonrpcResponse) {
            try { session.accept(jsonrpcResponse).block(); }
            catch (Exception e) { return rpcError(500, "ACCEPT_FAILED", e.getMessage()); }
            return new AndroidHttpServer.HttpResponse(202, new HashMap<>(), "", null);
        } else if (message instanceof McpSchema.JSONRPCNotification jsonrpcNotification) {
            try { session.accept(jsonrpcNotification).block(); }
            catch (Exception e) { return rpcError(500, "ACCEPT_FAILED", e.getMessage()); }
            return new AndroidHttpServer.HttpResponse(202, new HashMap<>(), "", null);
        } else if (message instanceof McpSchema.JSONRPCRequest jsonrpcRequest) {
            // 流式响应：SSE 单事件 + close（responseStream 内部发送后 closeGracefully）
            Map<String, String> headers = new HashMap<>();
            headers.put("Content-Type", SSE + "; charset=utf-8");
            headers.put("Cache-Control", "no-cache");
            return new AndroidHttpServer.HttpResponse(200, headers, null,
                    socket -> handleRequestStream(sessionId, session, jsonrpcRequest, socket));
        } else {
            return rpcError(400, "INVALID_REQUEST", "Unknown message type");
        }
    }

    private void handleRequestStream(String sessionId, McpStreamableServerSession session,
                                     McpSchema.JSONRPCRequest request, Socket socket) throws IOException {
        socket.setSoTimeout(0);  // 取消读超时：工具执行可能超过默认 120s
        OutputStream out = socket.getOutputStream();
        SseTransport sse = new SseTransport(out, sessionId, jsonMapper);
        try {
            // responseStream 内部调 transport.closeGracefully()（协议收尾）。注意：SDK 异步链
            // （subscribeOn(boundedElastic)）存在时序竞争——closeGracefully 可能先于 sendMessage
            // 的 runnable 调度，故 SseTransport.closeGracefully 不置 closed（真正终止靠连接关闭）。
            session.responseStream(request, sse).block();
        } catch (Exception e) {
            // 流失败（客户端断开/处理器异常）：连接随即关闭
        }
        out.flush();
    }

    // ── GET（SSE 监听流：服务器主动推送通道；P1 无推送，阻塞到客户端断开） ──

    private AndroidHttpServer.HttpResponse handleGet(AndroidHttpServer.HttpRequest req) {
        String accept = req.header("accept");
        if (accept == null || !accept.contains(SSE)) {
            return rpcError(400, "INVALID_ACCEPT", "text/event-stream required in Accept header");
        }
        String sessionId = req.header("mcp-session-id");
        if (sessionId == null || sessionId.isBlank()) {
            return rpcError(400, "INVALID_REQUEST", "Session ID required in mcp-session-id header");
        }
        McpStreamableServerSession session = sessions.get(sessionId);
        if (session == null) return rpcError(404, "SESSION_NOT_FOUND", "Session not found: " + sessionId);

        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", SSE + "; charset=utf-8");
        headers.put("Cache-Control", "no-cache");
        return new AndroidHttpServer.HttpResponse(200, headers, null,
                socket -> handleListening(session, socket));
    }

    private void handleListening(McpStreamableServerSession session, Socket socket) throws IOException {
        socket.setSoTimeout(0);  // 长连接：阻塞到客户端断开，不超时
        OutputStream out = socket.getOutputStream();
        SseTransport sse = new SseTransport(out, session.getId(), jsonMapper);
        McpStreamableServerSession.McpStreamableServerSessionStream stream = session.listeningStream(sse);
        try {
            // 阻塞读 socket：客户端断开（EOF）即结束监听，释放线程
            InputStream in = socket.getInputStream();
            byte[] buf = new byte[1024];
            while (in.read(buf) != -1) { /* 客户端不在该连接上发数据，仅等待 EOF */ }
        } finally {
            stream.close();
        }
    }

    // ── DELETE ──

    private AndroidHttpServer.HttpResponse handleDelete(AndroidHttpServer.HttpRequest req) {
        String sessionId = req.header("mcp-session-id");
        if (sessionId == null || sessionId.isBlank()) {
            return rpcError(400, "INVALID_REQUEST", "Session ID required in mcp-session-id header");
        }
        McpStreamableServerSession session = sessions.get(sessionId);
        if (session == null) return rpcError(404, "SESSION_NOT_FOUND", "Session not found: " + sessionId);
        try { session.delete().block(); } catch (Exception ignored) {}
        sessions.remove(sessionId);
        return new AndroidHttpServer.HttpResponse(200, new HashMap<>(), "", null);
    }

    // ═══ 鉴权（fail-closed，与 MovInboundServer 同语义） ═══

    private String authError(AndroidHttpServer.HttpRequest req) {
        String auth = req.header("authorization");
        String supplied = null;
        if (auth != null && auth.startsWith("Bearer ")) {
            supplied = auth.substring(7).trim();
        } else {
            String x = req.header("x-mov-token");
            if (x != null) supplied = x.trim();
        }
        if (token == null || token.isEmpty()) return "服务端未配置 token";
        if (supplied == null || supplied.isEmpty() || !token.equals(supplied)) return "token 无效";
        return null;
    }

    // ═══ 标准 JSON-RPC 错误信封 ═══

    private AndroidHttpServer.HttpResponse rpcError(int status, String code, String msg) {
        String body = "{\"jsonrpc\":\"2.0\",\"error\":{\"code\":\""
                + code + "\",\"message\":\"" + escapeJson(msg) + "\"},\"id\":null}";
        return AndroidHttpServer.HttpResponse.json(status, body);
    }

    private static String escapeJson(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }

    // ═══ SSE 帧 transport（官方 HttpServletStreamableMcpSessionTransport 的纯 Java 版） ═══

    static class SseTransport implements McpStreamableServerTransport {
        private final OutputStream out;
        private final String sessionId;
        private final McpJsonMapper jsonMapper;
        private final Object lock = new Object();
        private volatile boolean closed;

        SseTransport(OutputStream out, String sessionId, McpJsonMapper jsonMapper) {
            this.out = out;
            this.sessionId = sessionId;
            this.jsonMapper = jsonMapper;
        }

        @Override
        public Mono<Void> sendMessage(McpSchema.JSONRPCMessage message) {
            return sendMessage(message, null);
        }

        @Override
        public Mono<Void> sendMessage(McpSchema.JSONRPCMessage message, String messageId) {
            return Mono.fromRunnable(() -> {
                synchronized (lock) {
                    if (closed) return;
                    try {
                        String json = jsonMapper.writeValueAsString(message);
                        String id = messageId != null ? messageId : sessionId;
                        StringBuilder sb = new StringBuilder();
                        sb.append("id: ").append(id).append('\n');
                        sb.append("event: message\n");
                        sb.append("data: ").append(json).append("\n\n");
                        out.write(sb.toString().getBytes(StandardCharsets.UTF_8));
                        out.flush();
                    } catch (Exception e) {
                        closed = true;  // 写失败（客户端断开）：后续不再写
                    }
                }
            });
        }

        @Override
        public <T> T unmarshalFrom(Object data, TypeRef<T> typeRef) {
            return jsonMapper.convertValue(data, typeRef);
        }

        @Override
        public Mono<Void> closeGracefully() {
            // 不置 closed：SDK responseStream 的 then(closeGracefully) 可能与 sendMessage 的
            // runnable 存在异步时序竞争（置 closed 会吞掉关键响应）。真正的终止靠连接关闭
            // （AndroidHttpServer 关 socket → 写失败 → closed）。
            return Mono.empty();
        }

        @Override
        public void close() {
            closed = true;
        }
    }
}
