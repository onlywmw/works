package com.hermes.android.pay;

import com.hermes.android.agent.Journal;
import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.mcp.McpServerStore;
import com.hermes.android.vault.AesGcm;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.PublicKey;
import java.util.Arrays;

import javax.crypto.spec.SecretKeySpec;

/**
 * MOV-MCP 安装器（工单26 M3-3，买家侧）：
 * 收 mkt.delivery → 解包 → 验签（卖家公钥）→ AES-GCM 解密（K 用毕即焚）→
 * 计划闸用户确认 → 按 manifest.type 安装：
 *   config 型 → McpServerStore.add(origin=market, paid=true) → mcp.* 工具下次 discover 上线
 *   package 型 → 脚本落 rootfs/usr/local/bin + chmod + ToolRegistry 动态注册
 * 安装成功 → journal mkt.installed + InstallSink 回执（桥层发 A2A mkt.installed 给卖家）。
 *
 * 全依赖注入：store/journal/binDir/confirm/sink 由桥层给，单测零 Android、零网络。
 */
public class MovmcpInstaller {

    /** 计划闸：安装动作前用户确认（「所有 AI 文件写入必须经用户确认」红线） */
    public interface ConfirmUi {
        boolean confirm(String title, String message);
    }

    /** 安装成功回执（桥层接：A2A 发 mkt.installed 给卖家 + 卖家订单 INSTALLED） */
    public interface InstallSink {
        void installed(String orderId);
    }

    /** package 型工具注册（生产 = ToolRegistry.registerDynamicTool；测试 no-op/记录） */
    public interface ToolRegistrar {
        void register(String name, String desc, ToolRegistry.Handler handler);
    }

    public static final String ROOM = OrderStore.ROOM;

    /**
     * 安装。K 用毕即焚（finally 清零），无论成败。
     *
     * @return true=安装成功（journal 已落 mkt.installed + sink 已回调）；false=拒绝/失败（journal 已留痕）
     */
    public static boolean install(byte[] zipBytes, byte[] K, PublicKey sellerPub,
                                  McpServerStore store, Journal journal, File binDir,
                                  ToolRegistrar registrar, ConfirmUi confirm, InstallSink sink) {
        try {
            MovmcpPackager.Unpacked u = MovmcpPackager.unpack(zipBytes);
            byte[] manifestBytes = u.manifest.getBytes(StandardCharsets.UTF_8);

            // ① 验签：卖家公钥对 (payload 密文 + manifest) —— 失败拒装留痕
            if (!MovmcpPackager.verify(u.payload, manifestBytes, u.signature, sellerPub)) {
                journal.append(ROOM, rejected(u.manifest, "bad_signature"));
                return false;
            }

            JSONObject manifest;
            try {
                manifest = new JSONObject(u.manifest);
            } catch (Exception e) {
                journal.append(ROOM, rejected(u.manifest, "bad_manifest"));
                return false;
            }
            String orderId = manifest.optString("orderId", "");
            String productId = manifest.optString("id", "");
            String name = manifest.optString("name", "未命名商品");
            String type = manifest.optString("type", "config");

            // ② 计划闸：安装动作前用户确认
            if (confirm == null || !confirm.confirm("安装确认",
                    "将安装「" + name + "」（" + (type.equals("package") ? "本地脚本" : "MCP 服务配置") + "）\n"
                            + "安装后工具立即可用。继续？")) {
                journal.append(ROOM, rejected(u.manifest, "user_cancelled"));
                return false;
            }

            // ③ 解密
            byte[] plain;
            try {
                plain = AesGcm.decrypt(new SecretKeySpec(K, "AES"), u.payload);
            } catch (Exception e) {
                journal.append(ROOM, rejected(u.manifest, "decrypt_failed"));
                return false;
            }

            // ④ 按 type 安装
            boolean ok;
            if ("package".equals(type)) {
                ok = installPackage(plain, name, binDir, registrar);
            } else {
                ok = installConfig(plain, store);
            }
            if (!ok) {
                journal.append(ROOM, rejected(u.manifest, "install_failed"));
                return false;
            }

            // ⑤ journal 回执 + sink
            JSONObject ev = new JSONObject();
            try {
                ev.put("type", "mkt.installed").put("actor", "mkt");
                JSONObject p = new JSONObject();
                p.put("orderId", orderId).put("productId", productId).put("type", type).put("name", name);
                ev.put("payload", p);
            } catch (Exception ignored) {}
            journal.append(ROOM, ev);
            if (sink != null) sink.installed(orderId);
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            /* E-3（P1）：K 即焚无条件——验签败/manifest 坏/用户取消/解密败/安装败/异常全路径覆盖 */
            if (K != null) Arrays.fill(K, (byte) 0);
        }
    }

    /** config 型：payload = {url, token, name, desc, cat} → store 落 market 条目（paid=true） */
    static boolean installConfig(byte[] payloadPlain, McpServerStore store) {
        try {
            JSONObject c = new JSONObject(new String(payloadPlain, StandardCharsets.UTF_8));
            String url = c.optString("url", "");
            if (url.isEmpty()) return false;
            store.add(url, c.optString("token", ""), McpServerStore.ORIGIN_MARKET,
                    c.optString("name", ""), c.optString("desc", ""),
                    c.optString("cat", McpServerStore.CAT_OTHER), true);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** package 型：payload = 脚本 → rootfs/usr/local/bin/<name> + 可执行 + 动态注册工具 */
    static boolean installPackage(byte[] payloadPlain, String name, File binDir,
                                  ToolRegistrar registrar) {
        if (payloadPlain == null || payloadPlain.length == 0) return false;
        String safe = sanitizeName(name);
        if (safe.isEmpty() || binDir == null) return false;
        try {
            binDir.mkdirs();
            File f = new File(binDir, safe);
            try (FileOutputStream os = new FileOutputStream(f)) {
                os.write(payloadPlain);
            }
            f.setExecutable(true, false);   // chmod 755 等价（rootfs 内同 uid 可执行）
            if (registrar != null) {
                registrar.register(safe, "市场安装的本地工具 " + safe, args -> {
                    // 脚本执行：sh <path>，参数 JSON 序列化后追加为位置参数
                    Process p = Runtime.getRuntime().exec(buildCmd(f, args));
                    java.io.InputStream is = p.getInputStream();
                    String out = new String(readAll(is), StandardCharsets.UTF_8);
                    int code = p.waitFor();
                    return new ToolRegistry.Result(code == 0, out, null, out);
                });
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static String[] buildCmd(File script, JSONObject args) {
        java.util.List<String> cmd = new java.util.ArrayList<>();
        cmd.add("sh");
        cmd.add(script.getAbsolutePath());
        if (args != null) {
            for (java.util.Iterator<String> it = args.keys(); it.hasNext(); ) {
                String k = it.next();
                cmd.add(k + "=" + args.optString(k, ""));
            }
        }
        return cmd.toArray(new String[0]);
    }

    /** 脚本名脱敏：只留 [a-zA-Z0-9_.-]，防路径穿越 */
    static String sanitizeName(String name) {
        if (name == null) return "";
        return name.replaceAll("[^a-zA-Z0-9_.-]", "");
    }

    private static byte[] readAll(java.io.InputStream is) throws Exception {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = is.read(b)) > 0) bos.write(b, 0, n);
        return bos.toByteArray();
    }

    private static JSONObject rejected(String manifest, String reason) {
        JSONObject ev = new JSONObject();
        try {
            ev.put("type", "mkt.install_rejected").put("actor", "mkt");
            JSONObject p = new JSONObject();
            p.put("manifest", manifest != null ? manifest.substring(0, Math.min(200, manifest.length())) : "");
            p.put("reason", reason);
            ev.put("payload", p);
        } catch (Exception ignored) {}
        return ev;
    }
}
