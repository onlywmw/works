package com.hermes.android.scene;

import org.json.JSONObject;

/**
 * 站点模型卡（WebAdapter 三段式·运行时数据）。
 * 手写 MayiSite 和 AI 生成 SiteCard 共享同一 schema，上层无差别调用。
 */
public class SiteCard {

    public String site;           // 域名 "91mayitv.com"
    public String name;           // 显示名 "蚂蚁影视"
    public String searchUrl;      // "/vodsearch/{q}-------------.html"
    public String resultLink;     // CSS selector "a.v-thumb@href"
    public String resultTitle;    // "@title" or selector
    public String episodePattern; // "/vodplay/{id}-{sid}-{nid}.html"
    public String grade;          // "A" / "B" / "C"
    public double confidence;
    public boolean verified;      // 实播验证通过
    public String verifiedAt;
    public boolean autoGrade;
    public String[] columns;       // 输出字段约定（如 ["title","episode","playUrl"]）
    public AuthConfig auth;        // 登录验证（quickCheck+verify 两段）

    public static class AuthConfig {
        public String loginUrl;            // 登录入口 URL
        public String[] quickCheckCookies; // 探测 cookie 键（如 ["sessionid"]）
        public String verifySelector;      // 登录后页面独有元素（如 ".user-avatar"）

        public JSONObject toJSON() {
            JSONObject o = new JSONObject();
            try {
                o.put("loginUrl", loginUrl);
                o.put("quickCheckCookies", new org.json.JSONArray(
                    java.util.Arrays.asList(quickCheckCookies != null ? quickCheckCookies : new String[0])));
                o.put("verifySelector", verifySelector);
            } catch (Exception ignored) {}
            return o;
        }
    }

    public SiteCard() {}

    public static SiteCard fromMayiSite() {
        SiteCard c = new SiteCard();
        c.site = "91mayitv.com";
        c.name = "蚂蚁影视";
        c.searchUrl = "/vodsearch/{q}-------------.html";
        c.resultLink = "a.v-thumb@href";
        c.resultTitle = "@title";
        c.episodePattern = "/vodplay/{id}-{sid}-{nid}.html";
        c.grade = "A";
        c.confidence = 0.95;
        c.verified = true;
        c.verifiedAt = "2026-07-31";
        c.autoGrade = false;
        c.columns = new String[]{"title", "episode", "playUrl"};
        c.auth = null; // 蚂蚁免登录
        return c;
    }

    public JSONObject toJSON() {
        JSONObject o = new JSONObject();
        try {
            o.put("site", site); o.put("name", name);
            o.put("searchUrl", searchUrl); o.put("resultLink", resultLink);
            o.put("resultTitle", resultTitle); o.put("episodePattern", episodePattern);
            o.put("grade", grade); o.put("confidence", confidence);
            o.put("verified", verified); o.put("verifiedAt", verifiedAt);
            o.put("autoGrade", autoGrade);
            if (columns != null) o.put("columns", new org.json.JSONArray(java.util.Arrays.asList(columns)));
            if (auth != null) o.put("auth", auth.toJSON());
        } catch (Exception ignored) {}
        return o;
    }

    public static SiteCard fromJSON(JSONObject o) {
        SiteCard c = new SiteCard();
        c.site = o.optString("site");
        c.name = o.optString("name");
        c.searchUrl = o.optString("searchUrl");
        c.resultLink = o.optString("resultLink");
        c.resultTitle = o.optString("resultTitle");
        c.episodePattern = o.optString("episodePattern");
        c.grade = o.optString("grade", "C");
        c.confidence = o.optDouble("confidence", 0);
        c.verified = o.optBoolean("verified", false);
        c.verifiedAt = o.optString("verifiedAt", "");
        c.autoGrade = o.optBoolean("autoGrade", false);
        return c;
    }
}
