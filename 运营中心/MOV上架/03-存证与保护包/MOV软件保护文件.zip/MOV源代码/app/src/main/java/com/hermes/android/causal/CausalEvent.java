package com.hermes.android.causal;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

/**
 * 因果事件四元组值类（蓝图 §2：`[时间, 主体, 谓词, 客体]`）。
 *
 * 原子 = 主体/谓词/客体（规范化后的标签）；meta 存附加事实（金额/到期日等）。
 * 事件内不存哈希——原子哈希由 {@link CausalHash#atomHash} 现算，索引可再生、可校验。
 * 纯 Java，零 android 依赖。
 */
public class CausalEvent {

    public final String subject;
    public final String predicate;
    public final String object;
    /** 业务时间（可选字符串，如 "2025-06-01"；空 = 以写入 ts 为准） */
    public final String t;
    /** 来源标记：ocr|manual|plan|agent */
    public final String source;
    /** 附加事实（可空） */
    public final JSONObject meta;

    public CausalEvent(String subject, String predicate, String object) {
        this(subject, predicate, object, null, null, null);
    }

    public CausalEvent(String subject, String predicate, String object,
                       String t, String source, JSONObject meta) {
        this.subject = CausalHash.normalize(subject);
        this.predicate = CausalHash.normalize(predicate);
        this.object = CausalHash.normalize(object);
        this.t = t != null ? t.trim() : null;
        this.source = source;
        this.meta = meta;
    }

    /** 规范串：业务时间|主体|谓词|客体|meta键排序——事件指纹（账本 dataHash 用）。 */
    public String canonicalString() {
        StringBuilder sb = new StringBuilder();
        sb.append(t != null ? t : "").append('|');
        sb.append(subject).append('|').append(predicate).append('|').append(object);
        if (meta != null && meta.length() > 0) {
            TreeSet<String> keys = new TreeSet<>();
            java.util.Iterator<String> it = meta.keys();
            while (it.hasNext()) keys.add(it.next());
            sb.append('|');
            for (String k : keys) {
                sb.append(k).append('=').append(meta.optString(k)).append(';');
            }
        }
        return sb.toString();
    }

    /** 三个原子（规范化标签），索引/匹配用。 */
    public List<String> atoms() {
        List<String> list = new ArrayList<>(3);
        list.add(subject);
        list.add(predicate);
        list.add(object);
        return list;
    }

    /** meta 字段读取（dateAfter 钩子取 dueDate 用）。 */
    public String metaString(String key) {
        return meta != null ? meta.optString(key, "") : "";
    }

    /** → journal _causal_event payload。 */
    public JSONObject toPayload() {
        JSONObject p = new JSONObject();
        try {
            if (t != null && !t.isEmpty()) p.put("t", t);
            p.put("subject", subject);
            p.put("predicate", predicate);
            p.put("object", object);
            if (source != null && !source.isEmpty()) p.put("source", source);
            if (meta != null && meta.length() > 0) p.put("meta", meta);
        } catch (org.json.JSONException ignored) {}
        return p;
    }

    public static CausalEvent fromPayload(JSONObject payload) {
        if (payload == null) return new CausalEvent("", "", "");
        JSONObject meta = payload.optJSONObject("meta");
        return new CausalEvent(
                payload.optString("subject", ""),
                payload.optString("predicate", ""),
                payload.optString("object", ""),
                payload.optString("t", ""),
                payload.optString("source", ""),
                meta);
    }
}
