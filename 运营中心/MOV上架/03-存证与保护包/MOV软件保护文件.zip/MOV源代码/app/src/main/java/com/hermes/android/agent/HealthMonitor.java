package com.hermes.android.agent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * HealthMonitor — 工具/源周期探测器（DESIGN_TOOL_HEALTH §三，H2）。
 *
 * 每源/关键工具 30min 一次轻探测（HEAD 或最小查询，硬顶 5s，后台线程，失败只记状态不弹窗）。
 * 结果带 H1 reason code（ToolRegistry.Result 的 7 码）；失败同源退避（连续失败间隔翻倍，上限 2h）。
 * 结果供设置页「能力」区块健康行（✓ 正常 / ⚠ 最近失败 reason / ✗ 连续失败 N 次）。
 *
 * 纯 JVM 可测：nextInterval（退避）/ probeTarget（探测+状态记录）/ healthJson（输出）——
 * 探测函数 ProbeFn 注入式（测试用 Fake，零网络）。
 */
public class HealthMonitor {

    public static final long BASE_INTERVAL_MS = 30 * 60 * 1000L;    // 30min 正常
    public static final long MAX_INTERVAL_MS = 2 * 60 * 60 * 1000L; // 2h 退避上限
    public static final long PROBE_TIMEOUT_MS = 5000;               // 探测硬顶 5s

    /** 探测结果：null = 正常；非 null = 失败（带 H1 reason + 人话 detail） */
    public static class ProbeResult {
        public final String reason;   // H1: NOT_CONFIGURED/SOURCE_DOWN/PARSE_DRIFT/...
        public final String detail;   // 人话（源挂/超时/未配置...）
        public ProbeResult(String reason, String detail) {
            this.reason = reason; this.detail = detail;
        }
    }

    /** 探测函数（注入式，真探测走网络/Registry，测试用 Fake） */
    public interface ProbeFn {
        /** 超时/异常内部消化，返回 ProbeResult（失败）或 null（正常） */
        ProbeResult probe() throws Exception;
    }

    /** 探测目标：源/工具 + 探测函数 + 健康状态（volatile 供后台线程写、UI 线程读） */
    public static class Target {
        public final String id;        // mayi91 / model / hermes / relay
        public final String category;  // video / model / serve / relay
        public final ProbeFn fn;
        public volatile String reason = null;            // null = 正常
        public volatile String detail = null;
        public volatile int consecutiveFailures = 0;
        public volatile long lastCheckedMs = 0;
        public volatile long nextProbeMs = 0;

        Target(String id, String category, ProbeFn fn) {
            this.id = id; this.category = category; this.fn = fn;
        }
    }

    private final List<Target> targets;
    private volatile boolean running = false;
    private Thread thread;

    public HealthMonitor(List<Target> targets) {
        this.targets = targets != null ? targets : new ArrayList<>();
    }

    // ==================== 退避（纯函数，单测） ====================

    /** 连续失败 N 次 → 下次间隔翻倍，上限 2h（H2 节流纪律） */
    public static long nextInterval(int consecutiveFailures) {
        if (consecutiveFailures <= 0) return BASE_INTERVAL_MS;
        long interval = BASE_INTERVAL_MS;
        for (int i = 0; i < consecutiveFailures && interval < MAX_INTERVAL_MS; i++) {
            interval *= 2;
        }
        return Math.min(interval, MAX_INTERVAL_MS);
    }

    // ==================== 探测（可测：注入 Fake 目标） ====================

    /** 带 5s 硬顶超时跑探测函数；超时 = 失败(TIMEOUT)。 */
    static ProbeResult runWithTimeout(ProbeFn fn, long timeoutMs) {
        final AtomicReference<ProbeResult> ref = new AtomicReference<>();
        final CountDownLatch done = new CountDownLatch(1);
        Thread t = new Thread(() -> {
            try {
                ref.set(fn.probe());
            } catch (Exception e) {
                ref.set(new ProbeResult(ToolRegistry.Result.REASON_UNKNOWN,
                        "探测异常: " + e.getMessage()));
            } finally {
                done.countDown();
            }
        }, "health-probe");
        t.setDaemon(true);
        t.start();
        try {
            if (!done.await(timeoutMs, TimeUnit.MILLISECONDS)) {
                t.interrupt();
                return new ProbeResult(ToolRegistry.Result.REASON_SOURCE_DOWN, "探测超时(>" + timeoutMs + "ms)");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return new ProbeResult(ToolRegistry.Result.REASON_UNKNOWN, "探测被中断");
        }
        return ref.get();
    }

    /** 探测单个目标：记录状态 + 更新退避（下次探测时刻）。 */
    public void probeTarget(Target t) {
        long now = System.currentTimeMillis();
        ProbeResult r = runWithTimeout(t.fn, PROBE_TIMEOUT_MS);
        t.lastCheckedMs = now;
        if (r == null) {
            t.reason = null; t.detail = null; t.consecutiveFailures = 0;
        } else {
            t.reason = r.reason; t.detail = r.detail; t.consecutiveFailures++;
        }
        t.nextProbeMs = now + nextInterval(t.consecutiveFailures);
    }

    /** 跑一轮：探测所有到期目标（后台循环/手动重测入口）。 */
    public void runRound() {
        long now = System.currentTimeMillis();
        for (Target t : targets) {
            if (t.nextProbeMs <= now) probeTarget(t);
        }
    }

    /** 手动重测指定目标（设置页点按行）。 */
    public void retest(String id) {
        for (Target t : targets) {
            if (id.equals(t.id)) { probeTarget(t); return; }
        }
    }

    /** 健康 JSON（设置页能力区块数据源）：[{id, category, status:ok|warn|down, reason?, detail?, consecutiveFailures}] */
    public JSONArray healthJson() {
        JSONArray arr = new JSONArray();
        for (Target t : targets) {
            JSONObject o = new JSONObject();
            try {
                o.put("id", t.id).put("category", t.category);
                if (t.reason == null) {
                    o.put("status", "ok");
                } else if (t.consecutiveFailures >= 3) {
                    o.put("status", "down");
                    o.put("reason", t.reason).put("detail", t.detail)
                     .put("consecutiveFailures", t.consecutiveFailures);
                } else {
                    o.put("status", "warn");
                    o.put("reason", t.reason).put("detail", t.detail)
                     .put("consecutiveFailures", t.consecutiveFailures);
                }
            } catch (Exception ignored) {}
            arr.put(o);
        }
        return arr;
    }

    // ==================== 后台循环（零打扰：30s tick，跑到期目标） ====================

    public void start() {
        if (running) return;
        running = true;
        thread = new Thread(() -> {
            while (running) {
                try {
                    runRound();
                    Thread.sleep(30_000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }, "health-monitor");
        thread.setDaemon(true);
        thread.start();
    }

    public void stop() {
        running = false;
        if (thread != null) thread.interrupt();
    }
}
