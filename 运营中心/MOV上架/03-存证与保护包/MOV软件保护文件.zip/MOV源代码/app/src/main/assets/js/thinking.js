/* ============================================================
   thinking.js — MOV 思考区模块 v2
   黑底终端渲染 token 流 + M 流光脉冲 + 语法高亮
   ============================================================ */

window.MovThinking = (function(){
  var el, head, body, live, act, tokEl, secEl, foldBtn;
  var stEl, mflow, mfill, mpulse, tpsEl;
  var lines = [], curText = '', totalChars = 0;
  var secTimer = null;
  var active = false, collapsed = false, _t0 = 0;   /* _t0: done「已思考 N 秒」计时起点 */

  /* ── 初始化 (派单№5: 容器可注入; 老 #think 已删, 专家会话动态 attach) ── */
  function init(containerId){
    el = document.getElementById(containerId || 'think');
    if(!el) return;
    head = el.querySelector('.think-head');
    body = el.querySelector('.think-body');
    live = el.querySelector('.think-head .live');
    act = el.querySelector('.think-head .proc');
    secEl = el.querySelector('#thinkSec');
    foldBtn = el.querySelector('#thinkFold');
    stEl = el.querySelector('#thinkSt');

    if(head && !head._tbBound){ head._tbBound = true; head.addEventListener('click', toggle); }
    // BUG-3: 令牌只通过 MovThinking.feed() 来自 chat.js，不走 transient 通道
    showIdle();
  }
  /* 派单№5: 动态挂到专家会话思考容器 (老 #think 删后 token 数据不再静默丢弃) */
  function attach(containerId){ init(containerId); }

  /* ── 折叠 ── */
  function toggle(){
    collapsed = !collapsed;
    el.classList.toggle('collapsed', collapsed);
    if(foldBtn) foldBtn.textContent = collapsed ? '展开 ▸' : '收起 ▾';
  }

  /* ── token 事件 ── */
  function onToken(roomId, event){
    if(!active) return;
    var text = event.text || event.delta || '';
    if(!text) return;
    curText += text; totalChars += text.length;
    /* 无感工作态: 只累积思考内容(done 展开看), 去 tok 计数/tok/s 渲染 */
    if(!collapsed) appendText(text);
  }

  /* ── 追加文本 (语法高亮的分行) ── */
  function appendText(chunk){
    var parts = chunk.split('\n');
    for(var i = 0; i < parts.length; i++){
      if(i > 0){ newLine(); }
      if(!parts[i]) continue;
      if(lines.length === 0) newLine();
      var last = lines[lines.length - 1];
      if(last) last.raw += parts[i];
      renderLine(lines.length - 1);
    }
    body.scrollTop = body.scrollHeight;
  }

  function newLine(){
    var div = document.createElement('div'); div.className = 'tline';
    var span = document.createElement('span'); span.className = 't-raw';
    div.appendChild(span); body.appendChild(div);
    lines.push({el:div, raw:'', textEl:span, rendered:''});
  }

  function renderLine(idx){
    if(idx < 0 || idx >= lines.length) return;
    var l = lines[idx];
    if(l.rendered === l.raw) return;
    l.rendered = l.raw;
    var html = escHtml(l.raw);
    html = html.replace(/(\/\/.*$|#[^\n]*)/gm, '<i class="tk-c">$1</i>');
    html = html.replace(/("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/g, '<i class="tk-s">$1</i>');
    html = html.replace(/\b(var|const|let|function|return|if|else|for|while|import|export|class|new|try|catch|throw|async|await|true|false|null|undefined|action|tool\.execute|file\.read|file\.write|shell\.exec|app\.package|device\.cmd)\b/g, '<i class="tk-k">$1</i>');
    html = html.replace(/\b(\d+(?:\.\d+)?)\b/g, '<i class="tk-n">$1</i>');
    html = html.replace(/(=>|->|::)/g, '<i class="tk-f">$1</i>');
    html = html.replace(/([{}()[\]])/g, '<i class="tk-a">$1</i>');
    l.textEl.innerHTML = html;
  }

  /* ── 开始 / 停止 ── */
  function start(loopId){
    if(!el) return;   /* 验收人临时止血：同 stop() */
    active = true; curText = ''; totalChars = 0; lines = [];
    _t0 = Date.now();
    if(body) body.innerHTML = '';
    el.classList.remove('hidden','collapsed','done-state','fail-state');
    el.classList.add('streaming');   /* 无感工作态: running 一行态 (body 隐藏) */
    collapsed = false;
    if(foldBtn) foldBtn.textContent = '收起 ▾';
    /* 无感工作态: 一行灰字「思考中…」(无大写标题/无 tok/无波形) */
    setStatus('思考中…', true);
    startSecTimer();
  }

  function stop(ok){
    if(!el) return;   /* 验收人临时止血：#think 在老视图已删（第三幕清场），专家视图思考条待 P1 移植（见 TASKS 打回） */
    active = false; stopSecTimer();
    /* 无感工作态: 保留思考内容, 标题「已思考 N 秒 ›」默认收起, 点开看 lines */
    el.classList.remove('hidden');
    var secs = ((Date.now() - _t0) / 1000).toFixed(1);
    var label = (window.NewFaceExpert && NewFaceExpert.thinkLine) ? NewFaceExpert.thinkLine('done', secs) : ('已思考 ' + secs + ' 秒 ›');
    if(act) act.textContent = label;
    if(stEl) stEl.textContent = label;
    el.classList.remove('streaming');   /* 无感工作态: done 收起态, 展开可看思考内容 */
    collapsed = true;
    el.classList.add('collapsed');
    if(foldBtn) foldBtn.textContent = '展开 ▸';
    el.classList.add(ok !== false ? 'done-state' : 'fail-state');
    if(live) live.classList.add('done');
  }

  /* ── 状态文字 ── */
  function setStatus(text, pulsing){
    if(act) act.textContent = text;
    if(stEl) stEl.textContent = text;
    if(mflow){ if(pulsing) mflow.classList.add('indet'); else mflow.classList.remove('indet'); }
  }

  /* ── 秒计时器 ── */
  function startSecTimer(){
    var t0 = Date.now();
    secTimer = setInterval(function(){
      if(secEl) secEl.textContent = ((Date.now() - t0) / 1000).toFixed(1);
    }, 500);
  }
  function stopSecTimer(){
    if(secTimer){ clearInterval(secTimer); secTimer = null; }
  }

  /* 无感工作态: M 流光脉冲/tok 窗口已删 (消灭清单: 无波形/无 tok/s) */

  /* ── 公共 API ── */
  function feed(loopId, token){
    if(!el) return false;
    if(!active) start(loopId);
    onToken(null, {text: token, delta: token});
    return true;
  }

  function finish(ok){ if(active) stop(ok); }   /* 无感工作态: 保留 done 态「已思考 N 秒 ›」, 不再 showIdle 清空 */
  function reset(){
    stop(true); active = false;
    if(body) body.innerHTML = '';
    lines = []; curText = ''; totalChars = 0;
    showIdle();
  }
  function showIdle(){
    if(!el) return;
    /* 无感工作态: idle 完全隐藏 (无「等待输入」常驻条, 无 tok/秒清零) */
    el.classList.add('hidden');
    el.classList.remove('collapsed','done-state','fail-state');
    if(live) live.classList.remove('done');
    collapsed = false;
  }

  function agentPhase(idx){
    if(!active) return;
    /* 无感工作态: 统一「思考中…」, 不随阶段变 (无大写阶段标题) */
    setStatus('思考中…', true);
  }

  function escHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else { init(); }

  return { feed:feed, finish:finish, reset:reset, agentPhase:agentPhase, active:function(){return active;}, attach:attach };
})();
