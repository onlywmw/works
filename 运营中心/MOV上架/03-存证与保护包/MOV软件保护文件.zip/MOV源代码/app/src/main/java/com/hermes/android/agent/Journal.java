package com.hermes.android.agent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Journal — MOV Kernel 事件溯源轻量版 (CONTRACT: Envelope v1.0)。
 *
 * 每房间一份 append-only journal.jsonl + index.json 轻量索引 + snapshot.json 回放锚点。
 * 写点全部在 Java 层; WebView 只读尾部渲染。
 *
 * 磁盘布局 (StorageManager.baseDir 下):
 *   rooms/<id>/journal.jsonl          事件流 (一行一条 envelope)
 *   rooms/<id>/journal.archive.jsonl  滚动截下的历史
 *   rooms/<id>/index.json             轻量索引 (seq→type/ts/summary)
 *   rooms/<id>/snapshot.json          回放锚点 (AgentLoop 恢复用)
 *
 * 性能红线: 默认回放 = snapshot + 最近 REPLAY_TAIL_N 条; 禁止全量解析进内存。
 */
public class Journal {

    private static final String TAG = "Journal";

    /** 日志接口 (生产走 android.util.Log, 单测注入 no-op) */
    public interface Logger {
        void i(String tag, String msg);
        void w(String tag, String msg);
        void e(String tag, String msg, Throwable t);
    }

    private static Logger logger = new Logger() {
        @Override public void i(String tag, String msg) { android.util.Log.i(tag, msg); }
        @Override public void w(String tag, String msg) { android.util.Log.w(tag, msg); }
        @Override public void e(String tag, String msg, Throwable t) { android.util.Log.e(tag, msg, t); }
    };

    /** 单测注入: Journal.setLogger(noop) */
    public static void setLogger(Logger l) { logger = l != null ? l : new Logger() {
        @Override public void i(String tag, String msg) {}
        @Override public void w(String tag, String msg) {}
        @Override public void e(String tag, String msg, Throwable t) {}
    }; }

    /** 默认回放尾部条数 (常量可调, 契约 §1.5) */
    public static final int REPLAY_TAIL_N = 500;

    /** journal.jsonl 滚动阈值 (契约 §1.4) */
    private static final long ROLL_THRESHOLD_BYTES = 1024 * 1024; // 1MB

    /** index.json 最大条目数 (超出随 snapshot 截尾, 契约 §1.4) */
    private static final int INDEX_MAX_ENTRIES = 2000;

    /** 方案 B 语义召回（DESIGN/PLAN_SEMANTIC_RECALL_2026-08-09.md）：子串命中 ≥ 此值走保底（不做语义）；< 此值补语义。 */
    static final int SEMANTIC_K = 3;
    /** 方案 B：语义补充候选条数上限（最近 N 条事件，单批 batch ≤50）。 */
    static final int SEMANTIC_CANDIDATE_LIMIT = 50;

    /** 语义召回重排器（默认 null = 纯子串，与现状逐字节一致）。 */
    private static SearchReranker reranker;

    /** 单测/装配注入：语义重排器（llama/SemanticReranker 实现；传 null 恢复纯子串）。 */
    public static void setSearchReranker(SearchReranker r) { reranker = r; }

    private final File roomsDir;
    /** 顺手①: 已删房间登记（room_destroy 竞态防御）——append 对已删房间拒绝重建目录。
     *  synchronized 方法内访问；进程内生命周期（App 重启后磁盘已删，无残留目录可重建）。 */
    private final java.util.Set<String> deletedRooms = new java.util.HashSet<>();
    /** 工单22: seq 分配文件级锁——跨 Journal 实例互斥（实例 synchronized 锁跨实例失效，
     *  工单13 实证双实例并发 append 重号 seq 6,6）。锁对象 = roomsDir 绝对路径（全进程唯一）。 */
    private static final java.util.Map<String, Object> SEQ_LOCKS =
            new java.util.concurrent.ConcurrentHashMap<>();

    public Journal(File roomsDir) {
        this.roomsDir = roomsDir;
    }

    // ==================== 写入 ====================

    /**
     * 追加一条事件到房间 journal。
     * 自动分配 seq (房间内单调递增, 从 1 开始) 和 ts。
     * 同步维护 index.json。
     * 超 1MB 触发滚动 (snapshot + 截尾 + archive)。
     *
     * @param roomId 房间 ID
     * @param event  事件 JSON (须含 type/actor/payload; seq/ts 由本方法填充)
     * @return 分配到的 seq; 写入失败返回 -1
     */
    public int append(String roomId, JSONObject event) {
        /* 工单22: 跨实例锁（实例 synchronized 锁跨实例失效 → 双实例并发 append 重号）。
           roomsDir 路径级锁对象，全进程同路径共享；串行化 seq 分配+写入。 */
        Object lock = SEQ_LOCKS.computeIfAbsent(roomsDir.getAbsolutePath(), k -> new Object());
        synchronized (lock) {
            return appendLocked(roomId, event);
        }
    }

    private int appendLocked(String roomId, JSONObject event) {
        try {
            if (!isValidId(roomId)) {
                logger.w(TAG, "append: 非法房间ID " + roomId);
                return -1;
            }
            /* 顺手①: 已删房间拒绝 append（防 loop 临终事件重建目录） */
            if (deletedRooms.contains(roomId)) {
                logger.w(TAG, "append: 房间已删除, 拒绝写入 " + roomId);
                return -1;
            }
            File roomDir = new File(roomsDir, roomId);
            roomDir.mkdirs();
            File journalFile = new File(roomDir, "journal.jsonl");

            // 首行写 _header (不占 seq)
            boolean isNew = !journalFile.exists() || journalFile.length() == 0;
            if (isNew) {
                try (OutputStreamWriter w = new OutputStreamWriter(
                        new FileOutputStream(journalFile, true), StandardCharsets.UTF_8)) {
                    w.write("{\"v\":1,\"type\":\"_header\"}\n");
                }
            }

            // 分配 seq: 读 index.json 取最大 seq + 1
            int seq = nextSeq(roomDir);

            // 填充公共字段
            event.put("seq", seq);
            event.put("ts", System.currentTimeMillis());

            // 追加到 journal.jsonl
            try (OutputStreamWriter w = new OutputStreamWriter(
                    new FileOutputStream(journalFile, true), StandardCharsets.UTF_8)) {
                w.write(event.toString() + "\n");
            }

            // 同步维护 index.json
            updateIndex(roomDir, seq, event);

            // 滚动检查
            if (journalFile.length() > ROLL_THRESHOLD_BYTES) {
                roll(roomDir, journalFile);
            }

            return seq;
        } catch (Exception e) {
            logger.e(TAG, "append failed: " + e.getMessage(), e);
            return -1;
        }
    }

    /**
     * 删除房间（用户确认的破坏性操作：room_destroy 桥命令的最终落点）。
     * 递归删除 rooms/<id>/ 整个目录（journal/交付物/索引一并删除）——
     * 不删目录则 face_history（扫磁盘）仍列出该房间：2026-08-07 用户报障
     * 「点了删除列表没少」根因（原 room_destroy 只落 journal 标记不删目录）。
     * isValidId 防路径穿越；目录不存在返回 false。
     */
    public synchronized boolean deleteRoom(String roomId) {
        if (!isValidId(roomId)) {
            logger.w(TAG, "deleteRoom: 非法房间ID " + roomId);
            return false;
        }
        /* 顺手①: 登记已删房间（append 侧拒绝重建，room_destroy 竞态双保险之二） */
        deletedRooms.add(roomId);
        File roomDir = new File(roomsDir, roomId);
        if (!roomDir.exists()) return false;
        return deleteRecursive(roomDir);
    }

    private static boolean deleteRecursive(File f) {
        File[] children = f.listFiles();
        if (children != null) {
            for (File c : children) deleteRecursive(c);
        }
        return f.delete();
    }

    // ==================== 读取 ====================

    /**
     * 读取 journal 尾部 (增量查询, 契约 §2.2 query journal_tail)。
     *
     * @param roomId  房间 ID
     * @param afterSeq 只返回 seq > afterSeq 的事件 (0 = 从头)
     * @param count   最多返回条数 (≤100, 契约 §2.2)
     * @return JSONObject {ok:true, data:{events:[...], latestSeq:N}} 或错误信封
     */
    public JSONObject tail(String roomId, int afterSeq, int count) {
        try {
            if (!isValidId(roomId)) return errEnvelope("BAD_REQUEST", "非法房间ID");
            count = Math.min(Math.max(count, 1), 100);
            File journalFile = new File(new File(roomsDir, roomId), "journal.jsonl");
            if (!journalFile.exists()) {
                return okEnvelope(new JSONObject().put("events", new JSONArray()).put("latestSeq", 0));
            }

            List<JSONObject> events = new ArrayList<>();
            int latestSeq = 0;
            try (BufferedReader r = new BufferedReader(new InputStreamReader(
                    new FileInputStream(journalFile), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    try {
                        JSONObject ev = new JSONObject(line);
                        if ("_header".equals(ev.optString("type"))) continue;
                        int seq = ev.optInt("seq", 0);
                        if (seq > latestSeq) latestSeq = seq;
                        if (seq > afterSeq) {
                            events.add(ev);
                        }
                    } catch (Exception ignored) {
                        // 单行解析失败不中断
                    }
                }
            }

            // 只取最后 count 条
            int from = Math.max(0, events.size() - count);
            JSONArray arr = new JSONArray();
            for (int i = from; i < events.size(); i++) {
                arr.put(events.get(i));
            }
            return okEnvelope(new JSONObject().put("events", arr).put("latestSeq", latestSeq));
        } catch (Exception e) {
            logger.e(TAG, "tail failed: " + e.getMessage(), e);
            return errEnvelope("INTERNAL", "读取失败: " + e.getMessage());
        }
    }

    /**
     * 枚举已有房间 ID（工单 P5：mov.roomList 只读查询）。只读，不建不写。
     * 判定：roomsDir 下存在 journal.jsonl 的子目录。按字典序（确定性）。
     */
    public java.util.List<String> roomIds() {
        java.util.List<String> out = new java.util.ArrayList<>();
        File[] dirs = roomsDir.listFiles();
        if (dirs == null) return out;
        for (File d : dirs) {
            if (d.isDirectory() && new File(d, "journal.jsonl").exists()) out.add(d.getName());
        }
        out.sort(null);
        return out;
    }

    /** 工单15: 孤儿房间目录对账——磁盘有目录但无有效 journal(历史删房只落标记不删磁盘的残留)。 */
    public java.util.List<String> orphanRooms() {
        java.util.List<String> orphans = new java.util.ArrayList<>();
        File[] dirs = roomsDir.listFiles();
        if (dirs == null) return orphans;
        java.util.Set<String> valid = new java.util.HashSet<>(roomIds());
        for (File d : dirs) {
            if (d.isDirectory() && !valid.contains(d.getName())) orphans.add(d.getName());
        }
        orphans.sort(null);
        return orphans;
    }

    /**
     * 默认回放: snapshot + 最近 REPLAY_TAIL_N 条 (契约 §1.5)。
     * 用于 AgentLoop 恢复和进房间渲染。
     *
     * @return JSONObject {snapshot:..., events:[...], latestSeq:N} 或错误信封
     */
    public JSONObject replay(String roomId) {
        return replay(roomId, REPLAY_TAIL_N);
    }

    public JSONObject replay(String roomId, int tailN) {
        try {
            if (!isValidId(roomId)) return errEnvelope("BAD_REQUEST", "非法房间ID");
            File roomDir = new File(roomsDir, roomId);
            File journalFile = new File(roomDir, "journal.jsonl");

            JSONObject snapshot = null;
            File snapFile = new File(roomDir, "snapshot.json");
            if (snapFile.exists()) {
                try {
                    String content = readFileUtf8(snapFile);
                    snapshot = new JSONObject(content);
                } catch (Exception e) {
                    logger.w(TAG, "snapshot parse failed, ignoring: " + e.getMessage());
                }
            }

            JSONArray events = new JSONArray();
            int latestSeq = 0;
            if (journalFile.exists() && journalFile.length() > 0) {
                tailN = Math.max(1, Math.min(tailN, REPLAY_TAIL_N));
                /* P5: RandomAccessFile 尾部反向读 — 只解析尾部 tailN 行, O(tailN) 内存 */
                long fileLen = journalFile.length();
                long estimatedTailBytes = (long) tailN * 256L; // 保守估计每行 256 字节
                long seekPos = Math.max(0, fileLen - Math.max(estimatedTailBytes, 8192));
                int linesToSkip = 0;

                try (RandomAccessFile raf = new RandomAccessFile(journalFile, "r")) {
                    raf.seek(seekPos);
                    /* 跳过可能不完整的第一行 (seek 可能落在行中间) */
                    if (seekPos > 0) {
                        raf.readLine(); // 丢弃不完整行
                    }
                    /* 读尾部所有行, 用 ArrayDeque 保留最后 tailN 行
                       RandomAccessFile.readLine() 用 Latin-1 解码, 需转回 UTF-8 */
                    Deque<String> tailLines = new ArrayDeque<>(tailN);
                    String raw;
                    while ((raw = raf.readLine()) != null) {
                        String line = new String(raw.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8).trim();
                        if (line.isEmpty()) continue;
                        if (tailLines.size() >= tailN) tailLines.removeFirst();
                        tailLines.addLast(line);
                    }
                    /* 解析保留的行 */
                    for (String kept : tailLines) {
                        try {
                            JSONObject ev = new JSONObject(kept);
                            if ("_header".equals(ev.optString("type"))) continue;
                            events.put(ev);
                            int seq = ev.optInt("seq", 0);
                            if (seq > latestSeq) latestSeq = seq;
                        } catch (Exception ignored) {}
                    }
                }
                /* 如果反向读拿到的行数 < tailN (小文件), 回退正序补足 */
                if (events.length() < tailN && seekPos > 0) {
                    events = new JSONArray();
                    latestSeq = 0;
                    List<JSONObject> all = new ArrayList<>();
                    try (BufferedReader r = new BufferedReader(new InputStreamReader(
                            new FileInputStream(journalFile), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = r.readLine()) != null) {
                            line = line.trim();
                            if (line.isEmpty()) continue;
                            try {
                                JSONObject ev = new JSONObject(line);
                                if ("_header".equals(ev.optString("type"))) continue;
                                all.add(ev);
                                int seq = ev.optInt("seq", 0);
                                if (seq > latestSeq) latestSeq = seq;
                            } catch (Exception ignored) {}
                        }
                    }
                    int from = Math.max(0, all.size() - tailN);
                    for (int i = from; i < all.size(); i++) {
                        events.put(all.get(i));
                    }
                }
            }

            JSONObject data = new JSONObject();
            if (snapshot != null) data.put("snapshot", snapshot);
            data.put("events", events);
            data.put("latestSeq", latestSeq);
            return okEnvelope(data);
        } catch (Exception e) {
            logger.e(TAG, "replay failed: " + e.getMessage(), e);
            return errEnvelope("INTERNAL", "回放失败: " + e.getMessage());
        }
    }

    /**
     * 历史分页 (契约 §2.1 subscribe_history): beforeSeq 往前取 count 条。
     * 大结果集走 _movEvent 分批推送, 这里返回单批。
     */
    public JSONObject historyPage(String roomId, int beforeSeq, int count) {
        try {
            if (!isValidId(roomId)) return errEnvelope("BAD_REQUEST", "非法房间ID");
            count = Math.min(Math.max(count, 1), 50);
            File journalFile = new File(new File(roomsDir, roomId), "journal.jsonl");
            if (!journalFile.exists()) {
                return okEnvelope(new JSONObject().put("events", new JSONArray()).put("hasMore", false));
            }

            List<JSONObject> matched = new ArrayList<>();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(
                    new FileInputStream(journalFile), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    try {
                        JSONObject ev = new JSONObject(line);
                        if ("_header".equals(ev.optString("type"))) continue;
                        int seq = ev.optInt("seq", 0);
                        if (seq < beforeSeq) matched.add(ev);
                    } catch (Exception ignored) {}
                }
            }

            // 取最后 count 条 (最接近 beforeSeq 的)
            int from = Math.max(0, matched.size() - count);
            JSONArray arr = new JSONArray();
            for (int i = from; i < matched.size(); i++) {
                arr.put(matched.get(i));
            }
            boolean hasMore = from > 0;
            return okEnvelope(new JSONObject().put("events", arr).put("hasMore", hasMore));
        } catch (Exception e) {
            logger.e(TAG, "historyPage failed: " + e.getMessage(), e);
            return errEnvelope("INTERNAL", "历史读取失败: " + e.getMessage());
        }
    }

    /**
     * 阶段3 C2: 按内容全文检索 journal 历史事件（对齐 hermes FTS 检索语义）。
     * 搜索字段：payload 的 text/draft/summary/name/content/reason/cmd/gate 等文本（大小写不敏感子串）。
     * 覆盖 journal.jsonl + journal.archive.jsonl（滚动归档的历史也要搜得到）。
     * 返回 {ok, data:{events:[{seq,ts,type,snippet}], count}}，按 ts 倒序（最近在前），limit ≤50。
     */
    public JSONObject search(String roomId, String query, int limit) {
        try {
            if (!isValidId(roomId)) return errEnvelope("BAD_REQUEST", "非法房间ID");
            if (query == null || query.trim().isEmpty()) {
                return errEnvelope("BAD_REQUEST", "query 为空");
            }
            String q = query.trim().toLowerCase();
            limit = Math.min(Math.max(limit, 1), 50);
            File roomDir = new File(roomsDir, roomId);
            List<JSONObject> matched = new ArrayList<>();
            for (File f : new File[]{new File(roomDir, "journal.jsonl"),
                                     new File(roomDir, "journal.archive.jsonl")}) {
                if (!f.exists()) continue;
                try (BufferedReader r = new BufferedReader(new InputStreamReader(
                        new FileInputStream(f), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = r.readLine()) != null) {
                        line = line.trim();
                        if (line.isEmpty()) continue;
                        try {
                            JSONObject ev = new JSONObject(line);
                            if ("_header".equals(ev.optString("type"))) continue;
                            String text = searchableText(ev);
                            if (text != null && text.toLowerCase().contains(q)) {
                                matched.add(ev);
                            }
                        } catch (Exception ignored) {}
                    }
                }
            }
            /* 方案 B：子串命中 < SEMANTIC_K 且注入 reranker → 语义补充（失败/未注入静默回退保底）。
               保底路径行为不变（ts+seq 排序，查验红线——含 seq 次级键）。 */
            if (matched.size() < SEMANTIC_K && reranker != null) {
                List<JSONObject> semantic = semanticSupplement(roomDir, query.trim(), matched);
                if (semantic != null && !semantic.isEmpty()) {
                    matched.sort(TS_SEQ_DESC);
                    List<JSONObject> merged = new ArrayList<>(matched);
                    merged.addAll(semantic);
                    return buildResultEnvelope(merged, limit);
                }
            }

            /* ts 倒序 + seq 次级键（同 ts 按 seq 倒序，确定性——修 C 回归 flaky，查验表 A14） */
            matched.sort(TS_SEQ_DESC);
            return buildResultEnvelope(matched, limit);
        } catch (Exception e) {
            logger.e(TAG, "search failed: " + e.getMessage(), e);
            return errEnvelope("INTERNAL", "检索失败: " + e.getMessage());
        }
    }

    /** C2 检索文本提取：payload 各文本字段拼接（大小写不敏感子串匹配用） */
    static String searchableText(JSONObject ev) {
        if (ev == null) return "";
        JSONObject p = ev.optJSONObject("payload");
        if (p == null) return ev.toString();
        StringBuilder sb = new StringBuilder();
        String[] keys = {"text", "draft", "summary", "name", "content", "reason", "cmd", "gate", "phase", "state"};
        for (String k : keys) {
            String v = p.optString(k, "");
            if (!v.isEmpty()) sb.append(v).append(' ');
        }
        return sb.toString();
    }

    // ==================== 方案 B 语义补充（DESIGN_SEMANTIC_RECALL_2026-08-09.md） ====================

    /** 排序比较器：ts 倒序 + seq 次级键（同 ts 按 seq 倒序，确定性）。保底路径与语义路径共用。 */
    private static final java.util.Comparator<JSONObject> TS_SEQ_DESC = (a, b) -> {
        int c = Long.compare(b.optLong("ts", 0), a.optLong("ts", 0));
        return c != 0 ? c : Integer.compare(b.optInt("seq", 0), a.optInt("seq", 0));
    };

    /** 方案 B 语义补充：取最近 ≤SEMANTIC_CANDIDATE_LIMIT 条事件（排除已子串命中），rerank 按相关度排序。
     *  返回语义命中事件列表（高相似在前）；reranker 返回 null / 异常 → 返回 null（调用方回退保底）。 */
    private List<JSONObject> semanticSupplement(File roomDir, String query, List<JSONObject> matched) {
        try {
            List<JSONObject> recent = recentEvents(roomDir, SEMANTIC_CANDIDATE_LIMIT);
            if (recent.isEmpty()) return null;
            java.util.Set<Integer> matchedSeqs = new java.util.HashSet<>();
            for (JSONObject ev : matched) matchedSeqs.add(ev.optInt("seq", -1));
            List<JSONObject> cand = new ArrayList<>();
            List<String> texts = new ArrayList<>();
            for (JSONObject ev : recent) {
                int seq = ev.optInt("seq", -1);
                if (matchedSeqs.contains(seq)) continue;
                cand.add(ev);
                texts.add(searchableText(ev));
            }
            if (texts.isEmpty()) return null;
            List<Integer> order = reranker.rerank(query, texts);
            if (order == null) return null;
            List<JSONObject> out = new ArrayList<>();
            for (Integer idx : order) {
                if (idx != null && idx >= 0 && idx < cand.size()) out.add(cand.get(idx));
            }
            return out;
        } catch (Exception e) {
            logger.w(TAG, "semantic supplement failed: " + e.getMessage());
            return null;
        }
    }

    /** 读取房间最近 ≤n 条事件（按 seq 倒序；扫 journal + archive，排除 _header）。语义补充候选用。 */
    private List<JSONObject> recentEvents(File roomDir, int n) {
        List<JSONObject> all = new ArrayList<>();
        for (File f : new File[]{new File(roomDir, "journal.jsonl"),
                                 new File(roomDir, "journal.archive.jsonl")}) {
            if (!f.exists()) continue;
            try (BufferedReader r = new BufferedReader(new InputStreamReader(
                    new FileInputStream(f), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    try {
                        JSONObject ev = new JSONObject(line);
                        if ("_header".equals(ev.optString("type"))) continue;
                        all.add(ev);
                    } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}
        }
        all.sort(TS_SEQ_DESC);
        int take = Math.min(all.size(), n);
        return new ArrayList<>(all.subList(0, take));
    }

    /** 搜索结果 envelope 构建（snippet/seq/ts/type 契约不变，前端零改动）。构建失败返回错误信封不抛异常。 */
    private JSONObject buildResultEnvelope(List<JSONObject> events, int limit) {
        try {
            JSONArray arr = new JSONArray();
            for (int i = 0; i < Math.min(events.size(), limit); i++) {
                JSONObject ev = events.get(i);
                String text = searchableText(ev);
                String snippet = text.length() > 120 ? text.substring(0, 120) + "…" : text;
                arr.put(new JSONObject()
                        .put("seq", ev.optInt("seq", 0))
                        .put("ts", ev.optLong("ts", 0))
                        .put("type", ev.optString("type", "unknown"))
                        .put("snippet", snippet));
            }
            return okEnvelope(new JSONObject().put("events", arr).put("count", arr.length()));
        } catch (Exception e) {
            logger.w(TAG, "buildResultEnvelope failed: " + e.getMessage());
            return errEnvelope("INTERNAL", "检索结果构建失败");
        }
    }

    /**
     * 读取 index.json (轻量索引, 进房间先上屏摘要)。
     */
    public JSONObject readIndex(String roomId) {
        try {
            if (!isValidId(roomId)) return errEnvelope("BAD_REQUEST", "非法房间ID");
            File indexFile = new File(new File(roomsDir, roomId), "index.json");
            if (!indexFile.exists()) {
                return okEnvelope(new JSONObject().put("version", 1).put("entries", new JSONArray()));
            }
            String content = readFileUtf8(indexFile);
            return okEnvelope(new JSONObject(content));
        } catch (Exception e) {
            logger.e(TAG, "readIndex failed: " + e.getMessage(), e);
            return errEnvelope("INTERNAL", "索引读取失败: " + e.getMessage());
        }
    }

    // ==================== 内部方法 ====================

    private int nextSeq(File roomDir) {
        File indexFile = new File(roomDir, "index.json");
        int fromIndex = 1;
        if (indexFile.exists()) {
            try {
                JSONObject idx = new JSONObject(readFileUtf8(indexFile));
                JSONArray entries = idx.optJSONArray("entries");
                if (entries != null && entries.length() > 0) {
                    // 最后一条的 seq + 1
                    JSONObject last = entries.optJSONObject(entries.length() - 1);
                    if (last != null) fromIndex = last.optInt("seq", 0) + 1;
                }
            } catch (Exception e) {
                logger.w(TAG, "nextSeq: index parse failed, scanning journal: " + e.getMessage());
                return scanMaxSeq(roomDir) + 1;
            }
        }
        // 工单7 G2: index 可能落后于 journal（崩溃于 updateIndex 前）——以 journal 尾部实际最大 seq
        // 兜底取 max，杜绝 seq 复用（复用会导致同 seq 两条事件，回放/检索重复）。
        return Math.max(fromIndex, tailSeq(roomDir) + 1);
    }

    /** 读 journal 尾部的实际最大 seq（O(1) 尾读；滚动 _header/行损坏跳过；失败返回 0 降级）。 */
    private int tailSeq(File roomDir) {
        File journalFile = new File(roomDir, "journal.jsonl");
        if (!journalFile.exists()) return 0;
        try (RandomAccessFile raf = new RandomAccessFile(journalFile, "r")) {
            long fileLen = raf.length();
            if (fileLen <= 0) return 0;
            long seekPos = Math.max(0, fileLen - Math.min(fileLen, 8192));
            raf.seek(seekPos);
            if (seekPos > 0) raf.readLine();  // 丢弃可能不完整的首行
            String last = null, line;
            while ((line = raf.readLine()) != null) {
                String s = new String(line.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8).trim();
                if (!s.isEmpty()) last = s;
            }
            if (last == null) return 0;
            try {
                JSONObject ev = new JSONObject(last);
                if ("_header".equals(ev.optString("type"))) return 0;
                return ev.optInt("seq", 0);
            } catch (Exception ignored) {
                return 0;
            }
        } catch (Exception e) {
            logger.w(TAG, "tailSeq failed: " + e.getMessage());
            return 0;
        }
    }

    /** index 损坏时的兜底: 扫 journal 取最大 seq */
    private int scanMaxSeq(File roomDir) {
        File journalFile = new File(roomDir, "journal.jsonl");
        if (!journalFile.exists()) return 0;
        int max = 0;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                new FileInputStream(journalFile), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                try {
                    JSONObject ev = new JSONObject(line);
                    int seq = ev.optInt("seq", 0);
                    if (seq > max) max = seq;
                } catch (Exception ignored) {}
            }
        } catch (Exception e) {
            logger.w(TAG, "scanMaxSeq failed: " + e.getMessage());
        }
        return max;
    }

    /** 增量更新 index.json (契约 §1.4: 只留 seq/type/ts/summary≤80字) */
    private void updateIndex(File roomDir, int seq, JSONObject event) {
        try {
            File indexFile = new File(roomDir, "index.json");
            JSONObject idx;
            if (indexFile.exists()) {
                try {
                    idx = new JSONObject(readFileUtf8(indexFile));
                } catch (Exception e) {
                    idx = new JSONObject().put("version", 1).put("entries", new JSONArray());
                }
            } else {
                idx = new JSONObject().put("version", 1).put("entries", new JSONArray());
            }

            JSONArray entries = idx.optJSONArray("entries");
            if (entries == null) {
                entries = new JSONArray();
                idx.put("entries", entries);
            }

            // 构造索引条目
            String type = event.optString("type", "unknown");
            String summary = buildSummary(event);
            JSONObject entry = new JSONObject()
                    .put("seq", seq)
                    .put("type", type)
                    .put("ts", event.optLong("ts"))
                    .put("summary", summary);
            entries.put(entry);

            // 截尾: 超 INDEX_MAX_ENTRIES 时保留后半
            if (entries.length() > INDEX_MAX_ENTRIES) {
                JSONArray trimmed = new JSONArray();
                int from = entries.length() - INDEX_MAX_ENTRIES;
                for (int i = from; i < entries.length(); i++) {
                    trimmed.put(entries.opt(i));
                }
                idx.put("entries", trimmed);
            }

            writeFileUtf8(indexFile, idx.toString());
        } catch (Exception e) {
            logger.w(TAG, "updateIndex failed: " + e.getMessage());
        }
    }

    /** 从事件 payload 提取 ≤80 字摘要 */
    private static String buildSummary(JSONObject event) {
        String type = event.optString("type", "");
        JSONObject payload = event.optJSONObject("payload");
        String text;
        switch (type) {
            case "user_input":
                text = payload != null ? payload.optString("text", "") : "";
                break;
            case "plan":
                text = "计划 " + (payload != null ? payload.optJSONArray("steps") != null
                        ? payload.optJSONArray("steps").length() + " 步" : "" : "");
                break;
            case "tool_call":
                text = payload != null ? payload.optString("name", "") : "";
                break;
            case "tool_result":
                text = payload != null ? payload.optString("summary", "") : "";
                break;
            case "deliver":
                text = payload != null ? payload.optString("summary", "") : "";
                break;
            case "fail":
                text = payload != null ? payload.optString("reason", "") : "";
                break;
            case "note":
                text = payload != null ? payload.optString("text", "") : "";
                break;
            case "gate":
                text = payload != null
                        ? payload.optString("gate", "") + " " + payload.optString("state", "")
                        : "";
                break;
            case "phase":
                text = payload != null ? payload.optString("phase", "") : "";
                break;
            case "stopped":
                text = "已停止";
                break;
            case "paused":
                text = payload != null ? "暂停: " + payload.optString("reason", "") : "暂停";
                break;
            case "resumed":
                text = "续跑";
                break;
            case "summary":
                text = payload != null ? payload.optString("text", "") : "";
                break;
            case "understand":
                text = payload != null ? payload.optString("summary", "") : "";
                break;
            case "_causal_event":
                text = payload != null ? "因果 " + payload.optString("subject", "")
                        + " " + payload.optString("predicate", "")
                        + " " + payload.optString("object", "") : "";
                break;
            case "_tool_receipt":
                text = payload != null ? "工具回执 " + payload.optString("tool", "")
                        + "·" + payload.optString("domain", "") : "";
                break;
            default:
                text = type;
                break;
        }
        if (text.length() > 80) text = text.substring(0, 80);
        return text;
    }

    /**
     * 滚动 (契约 §1.4): journal >1MB → 写 snapshot + journal 截尾 + 截下部分追加 archive。
     * snapshot 记录当前最大 seq 和 AgentLoop 恢复所需最小状态。
     */
    private void roll(File roomDir, File journalFile) {
        try {
            // 读全部事件
            List<JSONObject> allEvents = new ArrayList<>();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(
                    new FileInputStream(journalFile), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    try {
                        JSONObject ev = new JSONObject(line);
                        if (!"_header".equals(ev.optString("type"))) {
                            allEvents.add(ev);
                        }
                    } catch (Exception ignored) {}
                }
            }
            if (allEvents.isEmpty()) return;

            // 保留尾部 REPLAY_TAIL_N 条, 截下的归档
            int keepFrom = Math.max(0, allEvents.size() - REPLAY_TAIL_N);
            int snapshotSeq = keepFrom > 0
                    ? allEvents.get(keepFrom - 1).optInt("seq", 0) : 0;

            // 截下的追加到 archive
            if (keepFrom > 0) {
                File archiveFile = new File(roomDir, "journal.archive.jsonl");
                try (OutputStreamWriter w = new OutputStreamWriter(
                        new FileOutputStream(archiveFile, true), StandardCharsets.UTF_8)) {
                    for (int i = 0; i < keepFrom; i++) {
                        w.write(allEvents.get(i).toString() + "\n");
                    }
                }
            }

            // 写 snapshot
            JSONObject snapshot = new JSONObject()
                    .put("version", 1)
                    .put("seq", snapshotSeq)
                    .put("ts", System.currentTimeMillis())
                    .put("state", new JSONObject()); // AgentLoop 恢复最小状态 (P0 占位, P1 填充)
            writeFileUtf8(new File(roomDir, "snapshot.json"), snapshot.toString());

            // 重写 journal: _header + 尾部
            try (OutputStreamWriter w = new OutputStreamWriter(
                    new FileOutputStream(journalFile, false), StandardCharsets.UTF_8)) {
                w.write("{\"v\":1,\"type\":\"_header\"}\n");
                for (int i = keepFrom; i < allEvents.size(); i++) {
                    w.write(allEvents.get(i).toString() + "\n");
                }
            }

            // 重建 index (只保留尾部事件的索引)
            JSONObject idx = new JSONObject().put("version", 1).put("entries", new JSONArray());
            JSONArray entries = idx.getJSONArray("entries");
            for (int i = keepFrom; i < allEvents.size(); i++) {
                JSONObject ev = allEvents.get(i);
                entries.put(new JSONObject()
                        .put("seq", ev.optInt("seq"))
                        .put("type", ev.optString("type"))
                        .put("ts", ev.optLong("ts"))
                        .put("summary", buildSummary(ev)));
            }
            writeFileUtf8(new File(roomDir, "index.json"), idx.toString());

            logger.i(TAG, "rolled: archived " + keepFrom + " events, kept "
                    + (allEvents.size() - keepFrom) + ", snapshot@" + snapshotSeq);
        } catch (Exception e) {
            logger.e(TAG, "roll failed: " + e.getMessage(), e);
        }
    }

    // ==================== 工具方法 ====================

    private static boolean isValidId(String id) {
        /* r{timestamp} 格式 + 默认房间 (desk/fit/hainan 等字母数字 ID) */
        return id != null && id.matches("^[a-zA-Z][a-zA-Z0-9_-]*$");
    }

    private static String readFileUtf8(File f) throws Exception {
        byte[] bytes = java.nio.file.Files.readAllBytes(f.toPath());
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private static void writeFileUtf8(File f, String content) throws Exception {
        try (OutputStreamWriter w = new OutputStreamWriter(
                new FileOutputStream(f), StandardCharsets.UTF_8)) {
            w.write(content);
        }
    }

    /** 统一错误信封 (契约 §2.4) */
    private static JSONObject errEnvelope(String code, String msg) {
        try {
            return new JSONObject()
                    .put("ok", false)
                    .put("error", new JSONObject().put("code", code).put("msg", msg));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private static JSONObject okEnvelope(JSONObject data) {
        try {
            return new JSONObject().put("ok", true).put("data", data);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    // ==================== L1 记忆草案区（DESIGN_MEMORY_LAYERS，P6 №5） ====================
    // 草案 = journal 事件子集（修正③：长在 journal 上，不平行造系统）。
    // 单行硬顶（修正②）；14 天未引用衰减（修正①）；晋升靠使用不靠自审（修正①）。

    public static final String TYPE_DRAFT       = "_memory_draft";
    public static final String TYPE_PROMOTED    = "_memory_promoted";
    public static final String TYPE_DRAFT_EXPIRE = "_memory_draft_expired";
    /** L3 模型提炼的冻结摘要事件（DESIGN_MEMORY_LAYERS v2 §六）：append-only，原文 journal 不动 */
    public static final String TYPE_MEMORY_SUMMARY = "_memory_summary";
    public static final long DRAFT_TTL_MS = 14L * 24 * 3600 * 1000;

    // ==================== 因果记忆事件（本地因果记忆编译器，feat/causal-memory） ====================
    // 四元组事件/规则/账本区块/遗忘墓碑/关联强度，全部 append-only，长在 journal（铁律③）。
    public static final String TYPE_CAUSAL_EVENT = "_causal_event";
    public static final String TYPE_CAUSAL_RULE  = "_causal_rule";
    public static final String TYPE_CAUSAL_BLOCK = "_causal_rule_block";
    public static final String TYPE_CAUSAL_FORGET = "_causal_forget";
    public static final String TYPE_CAUSAL_LINK  = "_causal_link";
    /** 域记忆移植（工单8，DESIGN_MEM_DOMAIN_PORT §二）：MCP 工具回执信封——tool/domain/ts/payload 四字段，原文零解释 */
    public static final String TYPE_TOOL_RECEIPT = "_tool_receipt";

    /**
     * 按类型读全部事件（journal + archive，seq 升序，去重）——因果引擎重建索引/规则/账本用。
     * 因果事件量级远小于对话事件，全量正序扫描便宜（性能红线不针对此）。
     */
    public JSONArray eventsOfType(String roomId, String type) {
        JSONArray out = new JSONArray();
        if (!isValidId(roomId)) return out;
        File roomDir = new File(roomsDir, roomId);
        java.util.TreeMap<Integer, JSONObject> bySeq = new java.util.TreeMap<>();
        java.util.List<File> files = new ArrayList<>();
        File jf = new File(roomDir, "journal.jsonl");
        if (jf.exists()) files.add(jf);
        File ar = new File(roomDir, "journal.archive.jsonl");
        if (ar.exists()) files.add(ar);
        for (File f : files) {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(
                    new FileInputStream(f), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    try {
                        JSONObject ev = new JSONObject(line);
                        if (!type.equals(ev.optString("type", ""))) continue;
                        bySeq.put(ev.optInt("seq", 0), ev);
                    } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}
        }
        for (JSONObject ev : bySeq.values()) out.put(ev);
        return out;
    }

    /** 域记忆移植（工单8，DESIGN_MEM_DOMAIN_PORT §二）：构造 _tool_receipt 信封事件（四字段 tool/domain/ts/payload 原文零解释）。
     *  供截取点（McpProvider）与单测共用；异常返回 null。 */
    public static JSONObject toolReceiptEvent(String tool, String domain, String payload) {
        try {
            long now = System.currentTimeMillis();
            JSONObject p = new JSONObject()
                    .put("tool", tool)
                    .put("domain", domain)
                    .put("ts", now)
                    .put("payload", payload == null ? "" : payload);
            return new JSONObject()
                    .put("actor", "agent")
                    .put("type", TYPE_TOOL_RECEIPT)
                    .put("ts", now)
                    .put("payload", p);
        } catch (Exception e) {
            return null;
        }
    }

    /** 域记忆移植（工单8，DESIGN_MEM_DOMAIN_PORT §二/§四）：按域读 _tool_receipt 信封（seq 升序，与 eventsOfType 同源）。
     *  domain 为空 = 全量；非空 = 精确匹配该域。原文 payload 逐字节保留。 */
    public JSONArray domainReceipts(String roomId, String domain) {
        JSONArray out = new JSONArray();
        try {
            JSONArray events = eventsOfType(roomId, TYPE_TOOL_RECEIPT);
            for (int i = 0; i < events.length(); i++) {
                JSONObject ev = events.optJSONObject(i);
                JSONObject p = ev != null ? ev.optJSONObject("payload") : null;
                if (p == null) continue;
                if (domain != null && !domain.isEmpty() && !domain.equals(p.optString("domain", ""))) continue;
                out.put(new JSONObject()
                        .put("tool", p.optString("tool", ""))
                        .put("domain", p.optString("domain", ""))
                        .put("ts", p.optLong("ts", ev.optLong("ts", 0)))
                        .put("payload", p.optString("payload", "")));
            }
        } catch (Exception e) {
            logger.w(TAG, "domainReceipts: " + e.getMessage());
        }
        return out;
    }

    /** 域记忆移植：同域回执的预算覆盖投影（对齐 memoryCover 思路，纯算法，不动 memoryCover 核心）。
     *  预算内新回执逐字；超预算旧回执塌缩成一行摘要。 */
    public JSONArray domainCover(String roomId, String domain, int budgetLines) {
        JSONArray out = new JSONArray();
        try {
            JSONArray receipts = domainReceipts(roomId, domain);
            int n = receipts.length();
            if (budgetLines <= 0) budgetLines = COVER_BUDGET_DEFAULT;
            int keep = Math.min(n, budgetLines);
            int collapsed = n - keep;
            for (int i = 0; i < keep; i++) {
                JSONObject it = receipts.optJSONObject(i);
                out.put(new JSONObject()
                        .put("mode", "verbatim")
                        .put("tool", it.optString("tool", ""))
                        .put("ts", it.optLong("ts", 0))
                        .put("text", it.optString("payload", "")));
            }
            if (collapsed > 0) {
                out.put(new JSONObject()
                        .put("mode", "summary")
                        .put("collapsed", collapsed)
                        .put("text", "[域历史 " + collapsed + " 条 · " + domain + "]"));
            }
        } catch (Exception e) {
            logger.w(TAG, "domainCover: " + e.getMessage());
        }
        return out;
    }

    // ==================== 工单12 健身竖闭环 ====================

    /** 幕一: 健身文本入账 — OCR 结果落 fitness 域 _tool_receipt(tool=ocr.local)。
     *  纯数据落账(可测); 真实 OCR 识别依赖 llama-server 模型就绪(ocr 工具诚实卡不假识别)。 */
    public synchronized int fitnessIngest(String roomId, String text) {
        if (text == null || text.trim().isEmpty()) return -2;
        JSONObject ev = toolReceiptEvent("ocr.local", "fitness", text.trim());
        if (ev == null) return -1;
        return append(roomId, ev);
    }

    /** 幕二: 周叙事 prompt 构造(纯函数, 可测) — fitness 域 receipts → 提炼 prompt(趋势/异常/一句建议)。 */
    public static String weeklyNarrativePrompt(String domain, JSONArray receipts) {
        StringBuilder sb = new StringBuilder(
                "你是健身记录提炼助手。基于以下健身域记录生成「本周身体叙事」：\n"
                + "1) 趋势  2) 异常/值得注意  3) 一句对身体的建议。只输出叙事, 禁解释/JSON。\n"
                + "【" + domain + " 域近 7 天记录】\n");
        if (receipts != null) {
            for (int i = 0; i < receipts.length(); i++) {
                JSONObject o = receipts.optJSONObject(i);
                String t = o != null ? o.optString("payload", "").trim() : "";
                if (t.isEmpty()) continue;
                sb.append("- ").append(t).append('\n');
            }
        }
        return sb.toString();
    }

    /** L1 草案写入：单行硬顶（含换行/回车 → 拒写返回 -1），kind ∈ memory/todo/error */
    public synchronized int appendDraft(String roomId, String draft, String kind) {
        if (draft == null || draft.trim().isEmpty()) return -2;   // EMPTY
        if (draft.contains("\n") || draft.contains("\r")) return -1;  // 超行拒写（修正②）
        try {
            JSONObject ev = new JSONObject()
                    .put("actor", "agent")
                    .put("type", TYPE_DRAFT)
                    .put("payload", new JSONObject()
                            .put("draft", draft.trim())
                            .put("kind", kind != null ? kind : "memory"));
            return append(roomId, ev);
        } catch (Exception e) {
            logger.w(TAG, "appendDraft: " + e.getMessage());
            return -1;
        }
    }

    /** 已晋升的草案文本集合（晋升 = _memory_promoted 事件，修正①）。G7: 全量 eventsOfType, 滚动后不丢 */
    private java.util.Set<String> promotedDraftSet(String roomId) {
        java.util.Set<String> set = new java.util.HashSet<>();
        JSONArray events = eventsOfType(roomId, TYPE_PROMOTED);
        for (int i = 0; i < events.length(); i++) {
            JSONObject ev = events.optJSONObject(i);
            JSONObject p = ev != null ? ev.optJSONObject("payload") : null;
            if (p != null && p.optString("draft", "").length() > 0) set.add(p.optString("draft"));
        }
        return set;
    }

    /** 有效草案（未过期 + 未晋升）：[{draft, kind, ts}]。G6: 全量 eventsOfType(draft+tombstone, seq 升序), 滚动后不丢 */
    public JSONArray memoryDrafts(String roomId) {
        JSONArray out = new JSONArray();
        if (!isValidId(roomId)) return out;
        JSONArray events = eventsOfType(roomId, TYPE_DRAFT);
        java.util.Set<String> promoted = promotedDraftSet(roomId);
        long now = System.currentTimeMillis();
        /* 批2: tombstone 按 seq 生效（工单7 G1）——只压制"其之前的"同文本草案；
           删除后重新 add 的同文本（seq 更晚）恢复有效，不永久压制。 */
        java.util.Map<String, Integer> tombstoneSeq = new java.util.HashMap<>();
        for (int i = 0; i < events.length(); i++) {
            JSONObject ev = events.optJSONObject(i);
            JSONObject p = ev != null ? ev.optJSONObject("payload") : null;
            if (p != null && TYPE_DRAFT.equals(ev.optString("type"))
                    && p.optBoolean("tombstone", false)) {
                tombstoneSeq.put(p.optString("draft", ""), ev.optInt("seq", 0));
            }
        }
        for (int i = 0; i < events.length(); i++) {
            JSONObject ev = events.optJSONObject(i);
            if (ev == null || !TYPE_DRAFT.equals(ev.optString("type"))) continue;
            JSONObject p = ev.optJSONObject("payload");
            if (p == null || p.optString("draft", "").isEmpty()) continue;
            if (p.optBoolean("tombstone", false)) continue;      // tombstone 事件本身跳过
            String draftText = p.optString("draft");
            Integer removedAfter = tombstoneSeq.get(draftText);
            if (removedAfter != null && ev.optInt("seq", 0) < removedAfter) continue;  // 该草案早于删除 → 排除
            if (promoted.contains(draftText)) continue;         // 已晋升 → 排除
            long ts = ev.optLong("ts", 0);
            if (ts > 0 && now - ts > DRAFT_TTL_MS) continue;    // 14 天衰减 → 排除
            try {
                out.put(new JSONObject()
                        .put("draft", draftText)
                        .put("kind", p.optString("kind", "memory"))
                        .put("ts", ts));
            } catch (Exception ignored) {}
        }
        return out;
    }

    // ==================== 批2: memory curated 层（一表双脑真共用，对齐 Hermes MEMORY.md §分隔语义） ====================

    /** 记忆条目 remove：写 tombstone 事件标记该文本删除（journal 仍 append-only，唯一事件源）。 */
    public synchronized int memoryRemove(String roomId, String text) {
        String t = text != null ? text.trim() : "";
        if (t.isEmpty()) return -2;
        try {
            JSONObject ev = new JSONObject().put("actor", "memory")
                    .put("type", TYPE_DRAFT)
                    .put("payload", new JSONObject().put("draft", t).put("kind", "memory").put("tombstone", true));
            return append(roomId, ev);
        } catch (Exception e) {
            logger.w(TAG, "memoryRemove: " + e.getMessage());
            return -1;
        }
    }

    /** 记忆条目 replace：tombstone 旧条目 + add 新条目。 */
    public synchronized int memoryReplace(String roomId, String oldText, String newText, String kind) {
        if (newText == null || newText.trim().isEmpty()) return -2;
        memoryRemove(roomId, oldText);
        return appendDraft(roomId, newText.trim(), kind);
    }

    /** curated 投影：有效条目（memoryDrafts 已排除 tombstone/过期/晋升）→ §分隔文本（对齐 Hermes MEMORY.md）。 */
    public String memoryCurated(JSONArray drafts) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < drafts.length(); i++) {
            JSONObject o = drafts.optJSONObject(i);
            String draft = o != null ? o.optString("draft", "") : "";
            if (draft.isEmpty()) continue;
            if (sb.length() > 0) sb.append('§');
            sb.append(draft);
        }
        return sb.toString();
    }

    /** 读取时按需覆盖预算（行）默认值——冻结注入预算同源，调用方可覆盖（DESIGN_MEMORY_LAYERS v2 §六） */
    public static final int COVER_BUDGET_DEFAULT = 20;

    /** 读取时按需覆盖（DESIGN_MEMORY_LAYERS v2 §六，吸收 OptMem cover 思路）：
     *  预算 N 内新记忆逐字、旧记忆塌缩成一行摘要。选块与读取 = 纯算法（无模型调用，前台可跑）。
     *  摘要为确定性占位（塌缩数量/最早日期/kind 统计），needsCompress=true 标记待 L3 模型提炼
     *  （懒触发，空闲补齐）；原文长在 journal 永不丢（修正③），覆盖只影响"读到什么"。
     *  @return JSONArray（旧→新）：逐字 {mode:"verbatim",text,kind,ts,needsCompress:false}；
     *          摘要 {mode:"summary",text,collapsed,needsCompress:true} */
    public JSONArray memoryCover(String roomId, int budgetLines) {
        JSONArray out = new JSONArray();
        JSONArray drafts = memoryDrafts(roomId);
        int n = drafts.length();
        int budget = Math.max(1, budgetLines);
        if (n <= budget) {
            for (int i = 0; i < n; i++) out.put(coverVerbatim(drafts.optJSONObject(i)));
            return out;
        }
        int collapsedN = n - budget;
        java.util.Map<String, Integer> kindCount = new java.util.HashMap<>();
        long oldestTs = Long.MAX_VALUE;
        for (int i = 0; i < collapsedN; i++) {
            JSONObject d = drafts.optJSONObject(i);
            long ts = d.optLong("ts", 0);
            if (ts > 0 && ts < oldestTs) oldestTs = ts;
            String kind = d.optString("kind", "memory");
            kindCount.merge(kind, 1, Integer::sum);
        }
        StringBuilder sb = new StringBuilder("[历史草案 ").append(collapsedN).append(" 条");
        if (oldestTs != Long.MAX_VALUE) {
            sb.append(" · 最早 ").append(new java.text.SimpleDateFormat("MM-dd", java.util.Locale.CHINA)
                    .format(new java.util.Date(oldestTs)));
        }
        for (java.util.Map.Entry<String, Integer> e : kindCount.entrySet()) {
            sb.append(" · ").append(e.getKey()).append("×").append(e.getValue());
        }
        sb.append("]");
        /* G8(工单7 P1): span 追加原文指纹——不同原文同统计形状(N/最早日期/kind) 占位串相同 → 会误命中缓存;
           折叠 hash(31*f + draft.hashCode) 区分原文, 原文变 span 变(改动即失效语义不变)。 */
        int finger = 0;
        for (int i = 0; i < collapsedN; i++) {
            String t = drafts.optJSONObject(i).optString("draft", "");
            finger = 31 * finger + (t != null ? t.hashCode() : 0);
        }
        sb.append("[f:").append(Integer.toHexString(finger)).append("]");
        // L3 冻结注入：已缓存 span 匹配的提炼摘要 → 用真摘要 needsCompress=false（改动即失效：原文变则 span 变）
        String span = sb.toString();
        String cached = cachedSummary(roomId, span);
        try {
            out.put(new JSONObject()
                    .put("mode", "summary")
                    .put("text", cached != null ? cached : span)
                    .put("collapsed", collapsedN)
                    .put("needsCompress", cached == null));
        } catch (Exception ignored) {}
        for (int i = collapsedN; i < n; i++) out.put(coverVerbatim(drafts.optJSONObject(i)));
        return out;
    }

    private static JSONObject coverVerbatim(JSONObject d) {
        try {
            return new JSONObject()
                    .put("mode", "verbatim")
                    .put("text", d.optString("draft"))
                    .put("kind", d.optString("kind", "memory"))
                    .put("ts", d.optLong("ts", 0))
                    .put("needsCompress", false);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    /** L3 模型提炼的单发模型调用接口（注入 fake 测编排，零网络；生产 = ModelRegistry 默认模型 AiClient.chat） */
    public interface Brain {
        String chat(String systemPrompt, String userText);
    }

    /** L3 模型提炼（摘要懒生成，DESIGN_MEMORY_LAYERS v2 §六）：对 memoryCover 的 needsCompress=true
     *  摘要调模型提炼成真摘要，冻结注入 journal（_memory_summary，append-only，原文不动）。
     *  懒触发（读取后/空闲补齐由调用方定，不阻塞主链路——本方法同步，调用方决定时机）。
     *  归因复用 ToolRegistry.Result 7 码 + ProbeResult(reason,detail) 形态：
     *  NOT_CONFIGURED（模型未注入/不可用）、SOURCE_DOWN（调用失败/源丢失）、UNKNOWN 兜底。
     *  @return {ok:true,seq} 注入成功；{ok:true,skipped:true} 无待提炼条；{ok:false,reason,detail} 归因 */
    public synchronized JSONObject distillMemory(String roomId, Brain brain, int budgetLines) {
        try {
            if (!isValidId(roomId)) return distillFail("BAD_ROOM", "非法房间标识");
            JSONArray cover = memoryCover(roomId, budgetLines);
            JSONObject summaryEntry = null;
            for (int i = 0; i < cover.length(); i++) {
                JSONObject o = cover.optJSONObject(i);
                if (o != null && "summary".equals(o.optString("mode")) && o.optBoolean("needsCompress")) {
                    summaryEntry = o;
                    break;
                }
            }
            if (summaryEntry == null) {
                // 预算内全逐字，或已命中冻结摘要 → 无待提炼
                return new JSONObject().put("ok", true).put("skipped", true);
            }
            if (brain == null) {
                return distillFail(ToolRegistry.Result.REASON_NOT_CONFIGURED, "未注入提炼模型（Brain 为 null）");
            }
            String span = summaryEntry.optString("text", "");
            int collapsed = summaryEntry.optInt("collapsed", 0);
            // 收集被塌缩原文作为提炼输入（memoryDrafts 旧→新，前 collapsed 条）
            JSONArray drafts = memoryDrafts(roomId);
            StringBuilder src = new StringBuilder();
            for (int i = 0; i < Math.min(collapsed, drafts.length()); i++) {
                JSONObject d = drafts.optJSONObject(i);
                String t = d != null ? d.optString("draft", "") : "";
                if (t.isEmpty()) continue;
                if (src.length() > 0) src.append('\n');
                src.append("· ").append(t);
            }
            if (src.length() == 0) {
                return distillFail(ToolRegistry.Result.REASON_SOURCE_DOWN, "被塌缩原文已不存在（源丢失）");
            }
            String summary;
            try {
                summary = brain.chat(
                        "你是记忆提炼助手。把多条记忆浓缩成一条 ≤80 字的中文摘要，保留关键实体与时间线索。只输出摘要文本，禁止解释/JSON。",
                        "把下面记忆浓缩成一句摘要：\n" + src);
            } catch (Exception e) {
                return distillFail(ToolRegistry.Result.REASON_SOURCE_DOWN, "模型调用异常: " + e.getMessage());
            }
            if (summary == null || summary.trim().isEmpty()) {
                return distillFail(ToolRegistry.Result.REASON_SOURCE_DOWN, "模型返回空摘要");
            }
            // 冻结注入 _memory_summary（append-only；span 作"改动即失效"锚，原文 journal 不动）
            int seq = append(roomId, new JSONObject()
                    .put("actor", "l3")
                    .put("type", TYPE_MEMORY_SUMMARY)
                    .put("payload", new JSONObject()
                            .put("span", span)
                            .put("summary", summary.trim())
                            .put("collapsed", collapsed)));
            if (seq < 0) return distillFail("WRITE_FAILED", "journal 写入失败");
            return new JSONObject().put("ok", true).put("seq", seq);
        } catch (Exception e) {
            return distillFail(ToolRegistry.Result.REASON_UNKNOWN, "提炼异常: " + e.getMessage());
        }
    }

    /** 查 journal 里 span 匹配的冻结摘要（改动即失效：原文变化 → 塌缩占位 span 变化 → 缓存失效重算） */
    private String cachedSummary(String roomId, String span) {
        /* G7: 全量 eventsOfType(_memory_summary)——滚动后摘要事件进 archive, tail 内找不到会失效重算 */
        JSONArray events = eventsOfType(roomId, TYPE_MEMORY_SUMMARY);
        if (events == null) return null;
        for (int i = 0; i < events.length(); i++) {
            JSONObject ev = events.optJSONObject(i);
            if (ev == null || !TYPE_MEMORY_SUMMARY.equals(ev.optString("type"))) continue;
            JSONObject p = ev.optJSONObject("payload");
            if (p == null) continue;
            String s = p.optString("summary", "");
            if (!s.isEmpty() && span.equals(p.optString("span", ""))) return s;
        }
        return null;
    }

    private static JSONObject distillFail(String reason, String detail) {
        JSONObject out = new JSONObject();
        try {
            out.put("ok", false).put("reason", reason).put("detail", detail);
        } catch (Exception ignored) {}
        return out;
    }

    /** 14 天衰减清理：扫描超 TTL 未晋升草案，写 _memory_draft_expired 标记；返回清理数。
     *  工单7 P1 G10 幂等: expired 事件带 draftSeq, 已过期草案不重复清理(连续跑只写一条)。 */
    public synchronized int expireStaleDrafts(String roomId, long nowMs) {
        if (!isValidId(roomId)) return 0;
        /* G10: 收集已过期草案 seq(有 _memory_draft_expired 且 payload.draftSeq 匹配) */
        JSONArray expiredEvents = eventsOfType(roomId, TYPE_DRAFT_EXPIRE);
        java.util.Set<Integer> expiredDraftSeqs = new java.util.HashSet<>();
        for (int i = 0; i < expiredEvents.length(); i++) {
            JSONObject p = expiredEvents.optJSONObject(i).optJSONObject("payload");
            if (p != null && p.has("draftSeq")) expiredDraftSeqs.add(p.optInt("draftSeq", -1));
        }
        JSONObject rep = replay(roomId, REPLAY_TAIL_N);
        JSONObject d = rep.optJSONObject("data");
        JSONArray events = d != null ? d.optJSONArray("events") : null;
        if (events == null) return 0;
        java.util.Set<String> promoted = promotedDraftSet(roomId);
        int cleaned = 0;
        for (int i = 0; i < events.length(); i++) {
            JSONObject ev = events.optJSONObject(i);
            if (ev == null || !TYPE_DRAFT.equals(ev.optString("type"))) continue;
            JSONObject p = ev.optJSONObject("payload");
            if (p == null) continue;
            String draftText = p.optString("draft", "");
            if (promoted.contains(draftText)) continue;
            long ts = ev.optLong("ts", 0);
            int draftSeq = ev.optInt("seq", -1);
            if (ts > 0 && nowMs - ts > DRAFT_TTL_MS && !expiredDraftSeqs.contains(draftSeq)) {
                try {
                    append(roomId, new JSONObject()
                            .put("actor", "system")
                            .put("type", TYPE_DRAFT_EXPIRE)
                            .put("payload", new JSONObject()
                                    .put("draft", draftText)
                                    .put("draftSeq", draftSeq)));
                    cleaned++;
                } catch (Exception ignored) {}
            }
        }
        return cleaned;
    }

    /** 晋升：草案被引用且验证有效 → 写 _memory_promoted（裁判是使用不是自审，修正①） */
    public synchronized int promoteDraft(String roomId, String draftText) {
        if (draftText == null || draftText.trim().isEmpty()) return -1;
        try {
            return append(roomId, new JSONObject()
                    .put("actor", "system")
                    .put("type", TYPE_PROMOTED)
                    .put("payload", new JSONObject()
                            .put("draft", draftText.trim())
                            .put("verified", true)));
        } catch (Exception e) {
            return -1;
        }
    }

    // ==================== L3 周期策展（DESIGN_MEMORY_LAYERS L3，P6 记忆三层末层） ====================
    // 时机：空闲（灭屏+充电 / time_cron，修正④）。内容：记忆整合（去重→高频晋升）+
    // 老化清理。确定性闸门（律③）：何时走代码（触发），晋升靠使用证据（重复写入=修正①弱证据）。

    /** 单次策展草案数上限（时长钳制，修正④：移动端电/热硬约束） */
    public static final int CURATE_DRAFT_LIMIT = 50;

    /** L3 记忆整合：草案去重 → 高频草案晋升（重复写入≥2 = 使用证据，修正①）；过期草案清理。
     *  返回整合动作数（晋升 + 清理）。单次限 CURATE_DRAFT_LIMIT 条草案（时长钳制）。 */
    public synchronized int memoryCurate(String roomId) {
        if (!isValidId(roomId)) return 0;
        /* G7: 全量 eventsOfType(TYPE_DRAFT)——滚动后草案/晋升状态不丢 */
        JSONArray events = eventsOfType(roomId, TYPE_DRAFT);
        if (events == null) return 0;

        java.util.Set<String> promoted = promotedDraftSet(roomId);
        java.util.Map<String, Integer> count = new java.util.HashMap<>();
        long now = System.currentTimeMillis();
        int scanned = 0;
        for (int i = 0; i < events.length(); i++) {
            if (scanned >= CURATE_DRAFT_LIMIT) break;   // 时长钳制
            JSONObject ev = events.optJSONObject(i);
            if (ev == null || !TYPE_DRAFT.equals(ev.optString("type"))) continue;
            JSONObject p = ev.optJSONObject("payload");
            if (p == null) continue;
            String txt = p.optString("draft", "");
            if (txt.isEmpty() || promoted.contains(txt)) continue;
            long ts = ev.optLong("ts", 0);
            if (ts > 0 && now - ts > DRAFT_TTL_MS) continue;  // 过期交给 expireStaleDrafts
            count.merge(txt, 1, Integer::sum);
            scanned++;
        }

        int actions = 0;
        for (java.util.Map.Entry<String, Integer> e : count.entrySet()) {
            if (e.getValue() >= 2) {   // 重复写入 ≥2 = 使用证据（修正①：裁判是使用不靠自审）
                if (promoteDraft(roomId, e.getKey()) > 0) actions++;
            }
        }
        actions += expireStaleDrafts(roomId, now);
        return actions;
    }
}
