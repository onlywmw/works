package com.hermes.android.pay;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.hermes.android.HermesActivity;
import com.hermes.android.agent.Journal;
import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.a2a.A2aClient;
import com.hermes.android.mcp.McpServerStore;
import com.hermes.android.vault.SecureVault;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 市场引擎（工单26 编排核心）——单真机双角色：mov-seller / mov-buyer-test。
 *
 * 卖家侧：收 mkt.buy → 锁屏确认 → 微信 Native 下单 → 回发订单卡 → 查单轮询（5s≤30min）
 *   → SUCCESS 才发货（未付款不发货守卫）→ A2A 加密发货 → 收回执 INSTALLED。
 * 买家侧：收 mkt.order（唤醒 buy cb）→ 收 mkt.delivery → 验签/解密/K 即焚 → 计划闸 → 安装 → 回执。
 *
 * 全部订单迁移 append 进 journal（OrderStore），轮询绑 App 生命周期（onResume/onPause）。
 */
public class MarketEngine {

    private static final String TAG = "MarketEngine";

    public static final String SELLER_ID = "mov-seller";
    public static final String BUYER_ID  = "mov-buyer-test";

    /** 查单轮询：5s 间隔，≤30min（360 次）→ EXPIRED；连续 5 次异常 → MANUAL */
    static final int POLL_INTERVAL_MS = 5000;
    static final int POLL_MAX = 360;
    static final int ERR_MAX = 5;

    private final HermesActivity activity;
    private final A2aClient seller;
    private final A2aClient buyer;
    private final OrderStore orders;
    private final McpServerStore store;
    private final Journal journal;
    private final SecureVault vault;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Map<String, String> pendingBuyCb = new HashMap<>();   // productId → cbId
    private final Map<String, Integer> pollCount = new HashMap<>();
    private final Map<String, Integer> errCount = new HashMap<>();
    /** 验收打回 P3：per-order 在轮标记——防 onResume 重挂与在途回调重挂出同订单双轮询链（预算双倍烧） */
    private final PollGuard polling = new PollGuard();
    /** E-2：前台标志——onPause 后 OkHttp 回调不重挂轮询（等 onResume 统一重挂） */
    private volatile boolean foreground = false;

    /** package 型工具注册钩子（AgentLoop 装配处注入；null = 只落盘不注册） */
    public interface ToolRegistryHook {
        void register(String name, String desc, ToolRegistry.Handler handler);
    }
    private static ToolRegistryHook toolHook;
    public static void setToolHook(ToolRegistryHook h) { toolHook = h; }

    public MarketEngine(HermesActivity activity) {
        this.activity = activity;
        this.seller = new A2aClient(activity, SELLER_ID);
        this.buyer  = new A2aClient(activity, BUYER_ID);
        this.journal = new Journal(activity.getStorageManager().getRoomsDir());
        this.orders = OrderStore.rebuild(journal);
        this.store = McpServerStore.create(activity);
        this.vault = new SecureVault(activity);
    }

    /* ═══ 生命周期：App 前台起轮询，退后台停（含查单轮询）═══ */

    public void onResume() {
        foreground = true;
        /* E-7（P0）：双身份注册通路——未注册才 register（register 幂等：本地 token 复用），
           注册成败落 Log.i 供真机取证（a2a_prefs 出现 mov-seller:device_token / mov-buyer-test:device_token） */
        ensureRegistered();
        seller.startPolling(this::onSellerMsg);
        buyer.startPolling(this::onBuyerMsg);
        /* E-1（P0）：回前台重挂 PAYING 订单查单——后台支付→回前台→立即补查+重挂 5s 循环 */
        resumePolling();
    }

    /** E-7：未注册身份补注册（异步；register 成功后 token 落盘 + 轮询才能带鉴权头） */
    private void ensureRegistered() {
        /* E-10：双身份注册都就绪后才触发自动配对（pairRequest 用 buyer token，pairAccept 用 seller token） */
        final java.util.concurrent.atomic.AtomicInteger ready = new java.util.concurrent.atomic.AtomicInteger(0);
        final Runnable tryPair = () -> { if (ready.incrementAndGet() >= 2) ensurePaired(); };
        if (!seller.isRegistered()) {
            seller.register(SELLER_ID, "MOV商店", "pro", null, regLog(SELLER_ID, tryPair));
        } else {
            Log.i(TAG, SELLER_ID + " 已注册（复用本地 token）");
            tryPair.run();
        }
        if (!buyer.isRegistered()) {
            buyer.register(BUYER_ID, "测试买家", "buyer", null, regLog(BUYER_ID, tryPair));
        } else {
            Log.i(TAG, BUYER_ID + " 已注册（复用本地 token）");
            tryPair.run();
        }
    }

    /**
     * E-10：自动配对（relay 策略：收发双方必须先配对，未配对 /msg 403）。
     * 幂等：先查 peers，已有对方则跳过；没有则 buyer.pairRequest → seller.pairAccept 一把完成。
     */
    private void ensurePaired() {
        buyer.peers(new A2aClient.Callback<List<A2aClient.Peer>>() {
            @Override public void onSuccess(List<A2aClient.Peer> peers) {
                for (A2aClient.Peer p : peers) {
                    if (SELLER_ID.equals(p.deviceId)) {
                        Log.i(TAG, "buyer↔seller 已配对（跳过）");
                        return;
                    }
                }
                autoPair();
            }
            @Override public void onFailure(java.io.IOException e) {
                Log.w(TAG, "peers 查询失败: " + e.getMessage() + "（下次 onResume 重试，幂等安全）");
            }
        });
    }

    /** 自动配对：buyer 发起配对码 → seller 接受（同机双身份一把完成） */
    private void autoPair() {
        buyer.pairRequest(new A2aClient.Callback<String>() {
            @Override public void onSuccess(String code) {
                seller.pairAccept(code, new A2aClient.Callback<A2aClient.Peer>() {
                    @Override public void onSuccess(A2aClient.Peer peer) {
                        Log.i(TAG, "自动配对成功：buyer↔seller（peer=" + peer.deviceId + "）");
                    }
                    @Override public void onFailure(java.io.IOException e) {
                        Log.w(TAG, "自动配对失败（seller 侧）: " + e.getMessage());
                    }
                });
            }
            @Override public void onFailure(java.io.IOException e) {
                Log.w(TAG, "自动配对失败（pairRequest）: " + e.getMessage());
            }
        });
    }

    /** 注册回调：成败落 Log（取证：key 名 + 结果，token 不回显全文）；成功后跑 after（E-10 配对链） */
    private A2aClient.Callback<String> regLog(final String deviceId, final Runnable after) {
        return new A2aClient.Callback<String>() {
            @Override public void onSuccess(String token) {
                Log.i(TAG, deviceId + " 注册成功 → a2a_prefs key \"" + deviceId + ":device_token\" 已落盘"
                        + (token != null && token.length() > 8 ? "（token " + token.substring(0, 4) + "…" + token.substring(token.length() - 4) + "）" : ""));
                after.run();
            }
            @Override public void onFailure(java.io.IOException e) {
                Log.w(TAG, deviceId + " 注册失败: " + e.getMessage() + "（购买/发货消息将因无 token 被 relay 拒收）");
            }
        };
    }

    public void onPause() {
        foreground = false;
        seller.stopPolling();
        buyer.stopPolling();
        handler.removeCallbacksAndMessages(null);
        polling.clear();   // P3：所有待发链已被清空 → 标记全释放，onResume 才能重挂
    }

    /** E-1：遍历 PAYING 订单，逐单立即 pollOnce 补查（非 SUCCESS 时内部重挂 5s）。
        P3：PollGuard.tryAcquire 去重——已在轮的订单不重复挂链（在途回调重挂与 onResume 重挂竞态防护） */
    private void resumePolling() {
        for (OrderStore.Order o : orders.paying()) {
            if (!polling.tryAcquire(o.orderId)) continue;
            final Runnable self = new Runnable() {
                @Override public void run() { pollOnce(o.orderId, this); }
            };
            handler.post(self);
        }
    }

    /* ═══ 桥层接口 ═══ */

    /** 买家「立即购买」（E-8 设计变更：去锁屏闸——未付款订单无资金流动 + 30min EXPIRED 自动关单，
        钱闸 = 微信支付密码（微信侧必输））→ 直接发 mkt.buy 给卖家 → 挂 cbId 等订单卡 */
    public void buy(String productId, String cbId) {
        Shelf.Item item = Shelf.find(productId);
        if (item == null) {
            evalCb(cbId, "{\"ok\":false,\"error\":{\"code\":\"PRODUCT_NOT_FOUND\",\"msg\":\"商品不存在\"}}");
            return;
        }
        pendingBuyCb.put(productId, cbId);
        try {
            buyer.send(SELLER_ID, "mkt.buy", buyRequest(productId),
                    new A2aClient.Callback<Long>() {
                        @Override public void onSuccess(Long id) { /* 等卖家回订单卡 */ }
                        @Override public void onFailure(java.io.IOException e) {
                            pendingBuyCb.remove(productId);
                            evalCb(cbId, "{\"ok\":false,\"error\":{\"code\":\"SEND_FAIL\",\"msg\":\"购买请求发送失败\"}}");
                        }
                    });
        } catch (Exception e) {
            pendingBuyCb.remove(productId);
            evalCb(cbId, "{\"ok\":false,\"error\":{\"code\":\"SEND_FAIL\",\"msg\":\"购买请求发送失败\"}}");
        }
    }

    /** E-8：购买请求 payload（纯函数可测：点购买直达出单，无锁屏环节） */
    static JSONObject buyRequest(String productId) {
        JSONObject o = new JSONObject();
        try {
            o.put("productId", productId).put("buyerId", BUYER_ID);
        } catch (Exception ignored) {}
        return o;
    }

    /** 订单投影查询（买家收款卡轮询） */
    public JSONObject orderView(String orderId) {
        OrderStore.Order o = orders.get(orderId);
        if (o == null) return null;
        JSONObject j = new JSONObject();
        try {
            j.put("orderId", o.orderId).put("state", o.state.name())
                    .put("fen", o.fen).put("name", o.productId)
                    .put("codeUrl", o.codeUrl);
        } catch (Exception ignored) {}
        return j;
    }

    /** 商户四证 + AppID + 卖家私钥入保险柜（prefs 只存 vault id + 非机密 appid 明文） */
    public void saveMerchant(String mchid, String serial, String apiv3Key, String pem,
                             String appid, String sellerPem) {
        try {
            String pemId    = vault.lock("wxpay-pem", pem);
            String serialId = vault.lock("wxpay-serial", serial);
            String apiv3Id  = vault.lock("wxpay-apiv3", apiv3Key);
            JSONObject o = new JSONObject()
                    .put("mchid", mchid)
                    .put("appid", appid == null ? "" : appid.trim())   // E-12：非机密，明文存
                    .put("pemVaultId", pemId)
                    .put("serialVaultId", serialId)
                    .put("apiv3VaultId", apiv3Id);
            if (sellerPem != null && !sellerPem.trim().isEmpty()) {
                o.put("sellerVaultId", vault.lock("seller-rsa", sellerPem.trim()));
            }
            activity.getSharedPreferences(MerchantCreds.PREFS_FILE, 0).edit()
                    .putString(MerchantCreds.KEY_JSON, o.toString()).apply();
        } catch (Exception e) {
            Log.w(TAG, "saveMerchant: " + e.getMessage());
            throw new IllegalStateException("凭证保存失败", e);
        }
    }

    /* ═══ 卖家侧 ═══ */

    private void onSellerMsg(List<A2aClient.Msg> msgs) {
        for (A2aClient.Msg m : msgs) {
            try {
                if ("mkt.buy".equals(m.type)) onBuyRequest(m);
                else if ("mkt.installed".equals(m.type)) onInstalledReceipt(m);
            } catch (Exception e) {
                Log.w(TAG, "seller msg " + m.type + ": " + e.getMessage());
            }
        }
    }

    /** 收到购买请求：查货架 → 建单 → 微信下单 → 回发订单卡 → 启动查单轮询 */
    private void onBuyRequest(A2aClient.Msg m) {
        JSONObject p = m.payload;
        if (p == null) return;
        final String productId = p.optString("productId", "");
        final String buyerId = p.optString("buyerId", "");
        final Shelf.Item item = Shelf.find(productId);
        if (item == null || buyerId.isEmpty()) {
            Log.w(TAG, "mkt.buy 拒绝: 未知商品或买家 " + productId + "/" + buyerId);
            return;
        }
        createOrderAndSend(item, buyerId);
    }

    private void createOrderAndSend(final Shelf.Item item, final String buyerId) {
        final OrderStore.Order o = orders.create(item.id, buyerId, item.fen);   // CREATED
        MerchantCreds creds;
        try {
            creds = MerchantCreds.load(activity);
            if (!creds.wxComplete()) throw new IllegalStateException("商户四证未配置");
        } catch (Exception e) {
            orders.transit(o.orderId, OrderStore.State.MANUAL,
                    extra("merchant_missing", e.getMessage()));
            toast("出单失败：商户四证未配置");
            return;
        }
        /* 工单26 E-14：partner-server 已配置 → JSAPI 链路（微信内 chooseWXPay 原生付款），
           codeUrl 位置放 https 支付页链接；未配置 → Native 扫码兜底 */
        com.hermes.android.partner.PartnerClient partner =
                new com.hermes.android.partner.PartnerConfig(activity).clientOrNull();
        if (partner != null) {
            com.hermes.android.partner.PartnerClient.Resp pr =
                    partner.createPayOrder(o.orderId, item.name, item.fen);
            if (pr.ok && pr.data != null && !pr.data.optString("pay_url", "").isEmpty()) {
                String payUrl = pr.data.optString("pay_url", "");
                o.codeUrl = payUrl;
                orders.transit(o.orderId, OrderStore.State.PAYING, extra("codeUrl", payUrl));
                sendOrderCard(o, item, buyerId, payUrl);
                return;
            }
            android.util.Log.w(TAG, "JSAPI 下单失败，回退 Native：" + pr.code + " " + pr.msg);
        }
        WxPayClient wx = new WxPayClient(creds, new WxPayClient.OkHttpTransport());
        wx.nativeCreateOrder(item.name, o.orderId, item.fen, item.id, new WxPayClient.Cb<String>() {
            @Override public void ok(String codeUrl) {
                o.codeUrl = codeUrl;
                orders.transit(o.orderId, OrderStore.State.PAYING, extra("codeUrl", codeUrl));
                sendOrderCard(o, item, buyerId, codeUrl);
            }
            @Override public void fail(String code, String msg) {
                orders.transit(o.orderId, OrderStore.State.MANUAL, extra("wx_create_fail", code + ":" + msg));
                toast("微信下单失败：" + msg);
            }
        });
    }

    /** 发订单卡给买家 + 成功后挂查单轮询（JSAPI/Native 两路共用） */
    private void sendOrderCard(final OrderStore.Order o, final Shelf.Item item,
                               final String buyerId, final String codeUrl) {
        try {
            seller.send(buyerId, "mkt.order", new JSONObject()
                            .put("orderId", o.orderId)
                            .put("codeUrl", codeUrl)
                            .put("fen", item.fen)
                            .put("name", item.name)
                            .put("productId", item.id),
                    new A2aClient.Callback<Long>() {
                        @Override public void onSuccess(Long id) { startPollQuery(o.orderId); }
                        @Override public void onFailure(java.io.IOException e) {
                            orders.transit(o.orderId, OrderStore.State.MANUAL,
                                    extra("order_send_fail", e.getMessage()));
                            toast("订单卡发送失败");
                        }
                    });
        } catch (Exception e) {
            orders.transit(o.orderId, OrderStore.State.MANUAL, extra("order_send_fail", e.getMessage()));
        }
    }

    /** 查单轮询：5s × ≤360 次（30min）→ EXPIRED；SUCCESS → PAID + 发货；连续 5 错 → MANUAL */
    private void startPollQuery(final String orderId) {
        if (!polling.tryAcquire(orderId)) return;   // P3：已有链在轮 → 不重复挂
        final Runnable self = new Runnable() {
            @Override public void run() { pollOnce(orderId, this); }
        };
        handler.postDelayed(self, POLL_INTERVAL_MS);
    }

    void pollOnce(final String orderId, final Runnable self) {
        OrderStore.Order o = orders.get(orderId);
        if (o == null || o.state != OrderStore.State.PAYING) {   // 已离开 PAYING → 停
            polling.release(orderId);
            return;
        }
        try {
            MerchantCreds creds = MerchantCreds.load(activity);
            if (!creds.wxComplete()) {
                // 验收打回 P4：凭证缺失不再静默永卡 PAYING——转 MANUAL + 明示
                polling.release(orderId);
                orders.transit(orderId, OrderStore.State.MANUAL, extra("merchant_missing", "商户凭证不完整"));
                toast("商户凭证不完整，订单转人工处理");
                return;
            }
            WxPayClient wx = new WxPayClient(creds, new WxPayClient.OkHttpTransport());
            wx.queryByOutTradeNo(orderId, new WxPayClient.Cb<JSONObject>() {
                @Override public void ok(JSONObject j) {
                    String st = j.optString("trade_state", "");
                    if (shouldDeliver(st)) {           // ← 变异靶①：恒返 SUCCESS → 未付款也发货
                        polling.release(orderId);
                        orders.transit(orderId, OrderStore.State.PAID, j);
                        deliver(orderId);
                        return;
                    }
                    int n = pollCount.merge(orderId, 1, Integer::sum);
                    if (n >= POLL_MAX) {
                        polling.release(orderId);
                        orders.transit(orderId, OrderStore.State.EXPIRED, null);
                        notifyJs(orderId, "EXPIRED");
                        return;
                    }
                    reschedule(orderId, self);           // E-2：仅前台重挂
                }
                @Override public void fail(String code, String msg) {
                    /* E-14：JSAPI 惰性建单——买家打开支付页前微信侧订单不存在（ORDER_NOT_EXIST），
                       这是「等买家」而非故障：不计连错、不转 MANUAL，继续按 5s 节奏等 */
                    if (isWaitingBuyer(code)) {
                        reschedule(orderId, self);
                        return;
                    }
                    int n = errCount.merge(orderId, 1, Integer::sum);
                    if (n >= ERR_MAX) {
                        polling.release(orderId);
                        orders.transit(orderId, OrderStore.State.MANUAL, extra("query_fail", code + ":" + msg));
                        toast("查单异常，订单转人工处理");
                        return;
                    }
                    reschedule(orderId, self);           // E-2：仅前台重挂
                }
            });
        } catch (Exception e) {
            reschedule(orderId, self);                   // E-2：仅前台重挂
        }
    }

    /** E-2：后台（onPause 后回调返回）不重挂——onResume 的 resumePolling 统一重挂。
        P3：后台不挂 = 链死，必须释放 polling 标记，否则 onResume 去重逻辑会误以为还在轮而不重挂 */
    private void reschedule(String orderId, Runnable self) {
        if (foreground) handler.postDelayed(self, POLL_INTERVAL_MS);
        else polling.release(orderId);
    }

    /** 未付款不发货守卫：只有微信 trade_state=SUCCESS 才触发发货 */
    static boolean shouldDeliver(String tradeState) {
        return "SUCCESS".equals(tradeState);
    }

    /** E-14：查单失败是否属「等买家开支付页」（JSAPI 惰性建单，微信侧尚未有单）——不计连错 */
    static boolean isWaitingBuyer(String code) {
        return "ORDER_NOT_EXIST".equals(code);
    }

    /** M3-2 发货器：PAID 触发 → 打包（K 每单随机）→ K 随单加密存 vault → A2A 发 mkt.delivery → DELIVERED */
    void deliver(String orderId) {
        OrderStore.Order o = orders.get(orderId);
        if (o == null || o.state != OrderStore.State.PAID) return;   // 未付款不发货（双保险）
        Shelf.Item item = Shelf.find(o.productId);
        if (item == null) {
            orders.transit(orderId, OrderStore.State.MANUAL, extra("product_missing", o.productId));
            return;
        }
        MerchantCreds creds;
        try {
            creds = MerchantCreds.load(activity);
            if (!creds.sellerReady()) throw new IllegalStateException("卖家签名私钥未配置");
        } catch (Exception e) {
            orders.transit(orderId, OrderStore.State.MANUAL, extra("seller_key_missing", e.getMessage()));
            toast("发货失败：卖家签名私钥未配置");
            return;
        }
        try {
            MovmcpPackager.Pack pack = MovmcpPackager.pack(item.manifest(orderId), item.spec,
                    item.report, item.payload, creds.sellerKey);
            // K 先编码（send 的 payload 在 post() 同步构造，之后清零不影响已构造报文）
            final String k = Base64.getEncoder().encodeToString(pack.key);
            final String pkg = Base64.getEncoder().encodeToString(pack.zipBytes);
            try {
                // K 随单加密存（红线：卖家侧 K 不落明文；vault 名称脱敏内建）
                vault.lock("order-" + orderId + "-K", k);
            } finally {
                // K 即焚：已转存 vault + 已进 A2A 报文，内存立即清零
                java.util.Arrays.fill(pack.key, (byte) 0);
            }
            seller.send(o.buyerId, "mkt.delivery", new JSONObject()
                            .put("orderId", orderId)
                            .put("k", k)
                            .put("pkg", pkg),
                    new A2aClient.Callback<Long>() {
                        @Override public void onSuccess(Long id) {
                            orders.transit(orderId, OrderStore.State.DELIVERED, null);
                            notifyJs(orderId, "DELIVERED");
                        }
                        @Override public void onFailure(java.io.IOException e) {
                            orders.transit(orderId, OrderStore.State.MANUAL,
                                    extra("deliver_send_fail", e.getMessage()));
                            toast("发货失败：消息发送失败");
                        }
                    });
        } catch (Exception e) {
            Log.w(TAG, "deliver " + orderId + ": " + e.getMessage());
            orders.transit(orderId, OrderStore.State.MANUAL, extra("deliver_fail", e.getMessage()));
        }
    }

    /** 卖家收 mkt.installed 回执 → INSTALLED（状态机闭环） */
    private void onInstalledReceipt(A2aClient.Msg m) {
        if (m.payload == null) return;
        String orderId = m.payload.optString("orderId", "");
        if (orders.transit(orderId, OrderStore.State.INSTALLED, null)) {
            notifyJs(orderId, "INSTALLED");
        }
    }

    /* ═══ 买家侧 ═══ */

    private void onBuyerMsg(List<A2aClient.Msg> msgs) {
        for (A2aClient.Msg m : msgs) {
            try {
                if ("mkt.order".equals(m.type)) onOrderCard(m);
                else if ("mkt.delivery".equals(m.type)) onDelivery(m);
            } catch (Exception e) {
                Log.w(TAG, "buyer msg " + m.type + ": " + e.getMessage());
            }
        }
    }

    /** 收订单卡 → 唤醒 buy 的 cbId（JS 显示收款卡） */
    private void onOrderCard(A2aClient.Msg m) {
        if (m.payload == null) return;
        String orderId = m.payload.optString("orderId", "");
        String productId = m.payload.optString("productId", "");
        String cbId = pendingBuyCb.remove(productId);
        if (cbId == null) return;
        try {
            JSONObject data = new JSONObject()
                    .put("orderId", orderId)
                    .put("codeUrl", m.payload.optString("codeUrl", ""))
                    .put("fen", m.payload.optInt("fen", 0))
                    .put("name", m.payload.optString("name", ""));
            evalCb(cbId, "{\"ok\":true,\"data\":" + data + "}");
        } catch (Exception e) {
            evalCb(cbId, "{\"ok\":false,\"error\":{\"code\":\"ORDER_CARD\",\"msg\":\"订单卡解析失败\"}}");
        }
    }

    /** 收 mkt.delivery → 验签/解密（K 即焚）/计划闸/安装/回执 */
    private void onDelivery(A2aClient.Msg m) {
        if (m.payload == null) return;
        String orderId = m.payload.optString("orderId", "");
        OrderStore.Order o = orders.get(orderId);
        if (o == null) { Log.w(TAG, "mkt.delivery 未知订单 " + orderId); return; }
        Shelf.Item item = Shelf.find(o.productId);
        if (item == null) { Log.w(TAG, "mkt.delivery 未知商品 " + o.productId); return; }
        byte[] K;
        byte[] pkg;
        try {
            K = Base64.getDecoder().decode(m.payload.optString("k", ""));
            pkg = Base64.getDecoder().decode(m.payload.optString("pkg", ""));
        } catch (Exception e) {
            Log.w(TAG, "mkt.delivery 解码失败: " + e.getMessage());
            return;
        }
        File binDir = new File(activity.getFilesDir(), "linux/rootfs/usr/local/bin");
        MovmcpInstaller.ConfirmUi confirmUi = new DialogConfirm(activity);
        MovmcpInstaller.ToolRegistrar registrar = (name, desc, handler) -> {
            if (toolHook != null) toolHook.register(name, desc, handler);
        };
        MovmcpInstaller.InstallSink sink = installedOrderId -> {
            try {
                buyer.send(SELLER_ID, "mkt.installed", new JSONObject().put("orderId", installedOrderId),
                        new A2aClient.Callback<Long>() {
                            @Override public void onSuccess(Long id) { /* 卖家侧 transit INSTALLED */ }
                            @Override public void onFailure(java.io.IOException e) { Log.w(TAG, "installed 回执失败"); }
                        });
            } catch (Exception e) { Log.w(TAG, "installed 回执失败: " + e.getMessage()); }
            orders.transit(installedOrderId, OrderStore.State.INSTALLED, null);
            notifyJs(installedOrderId, "INSTALLED");
        };
        boolean ok = MovmcpInstaller.install(pkg, K, item.sellerPubKey(), store, journal, binDir,
                registrar, confirmUi, sink);
        if (!ok) notifyJs(orderId, "INSTALL_REJECTED");
    }

    /* ═══ 工具 ═══ */

    private void notifyJs(String orderId, String state) {
        try {
            JSONObject ev = new JSONObject().put("orderId", orderId).put("state", state);
            activity.evalJsPublic("window._mktEvent && _mktEvent(" + ev + ")");
        } catch (Exception e) {
            Log.w(TAG, "notifyJs: " + e.getMessage());
        }
    }

    private void evalCb(String cbId, String json) {
        if (cbId == null) return;
        activity.evalJsPublic("window._hermesCb('" + cbId + "'," + json + ")");
    }

    private void toast(String msg) {
        activity.runOnUiThread(() ->
                android.widget.Toast.makeText(activity, msg, android.widget.Toast.LENGTH_SHORT).show());
    }

    private static JSONObject extra(String k, String v) {
        JSONObject e = new JSONObject();
        try { e.put(k, v); } catch (Exception ignored) {}
        return e;
    }

    static String fenToYuan(int fen) {
        return String.format(java.util.Locale.US, "%.2f", fen / 100.0);
    }

    /** 计划闸生产实现：主线程 AlertDialog + CountDownLatch（桥线程阻塞等用户，60s 超时=取消） */
    static class DialogConfirm implements MovmcpInstaller.ConfirmUi {
        private final HermesActivity activity;
        DialogConfirm(HermesActivity activity) { this.activity = activity; }

        @Override public boolean confirm(String title, String message) {
            final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(1);
            final boolean[] result = {false};
            activity.runOnUiThread(() -> new androidx.appcompat.app.AlertDialog.Builder(activity)
                    .setTitle(title).setMessage(message)
                    .setPositiveButton("允许安装", (d, w) -> { result[0] = true; latch.countDown(); })
                    .setNegativeButton("取消", (d, w) -> { result[0] = false; latch.countDown(); })
                    .setOnCancelListener(d -> { result[0] = false; latch.countDown(); })
                    .show());
            try {
                latch.await(60, java.util.concurrent.TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                return false;
            }
            return result[0];
        }
    }
}
