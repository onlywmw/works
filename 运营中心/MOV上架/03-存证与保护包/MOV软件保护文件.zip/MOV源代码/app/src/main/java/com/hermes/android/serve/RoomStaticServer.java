package com.hermes.android.serve;

import android.content.Context;
import android.util.Log;

import com.hermes.android.StorageManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * RoomStaticServer — 房间产物静态文件服务器 (HtmlViewer 多文件 HTML 项目支持).
 *
 * 背景: WebView 的 file:// 页面无法加载 file:// 子资源 JS (Chromium 硬限制, WebSettings 无法绕过),
 * 多文件 HTML 项目 (HTML + 多个 js/css/img) 在 file:// 下 JS 不执行。本服务器把房间 work 目录经
 * http://127.0.0.1:8787 serve, HtmlViewer 用 http URL 加载 → 无 file:// 限制, JS/CSS 全部正常。
 *
 * 路由: GET /rooms/&lt;roomId&gt;/files/work/&lt;subpath&gt; → 读文件返回 (二进制安全)。
 *
 * 安全:
 * - 只绑定 127.0.0.1 (仅本机), 非回环地址一律 403
 * - roomId 白名单 ^[A-Za-z0-9_-]{1,64}$; subpath canonical 校验限 work 目录内 (防 ../ 越界)
 * - 只接受 GET; 非 GET → 405; 越界/不存在 → 400/404
 * - 纯展示只读, 不注册任何桥
 *
 * 可测性: dispatch(method, path, roomsDir) 是包可见纯逻辑 (零网络零 Android 依赖),
 * 单测传临时目录直调 (同 MovInboundServerTest / StorageManagerCanonicalTest 范式)。
 */
public class RoomStaticServer {

    private static final String TAG = "RoomStatic";
    /** 端口: 避开 8387(serve daemon)/8388(MOV 入站)/8389(MCP 固定，工单5 已移除自动上移) */
    public static final int PORT = 8787;
    public static final String BASE_PATH = "/rooms/";

    private final Context context;
    private ServerSocket serverSocket;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean running;
    private static volatile RoomStaticServer instance;

    private RoomStaticServer(Context ctx) { this.context = ctx.getApplicationContext(); }

    /** 进程级静态单例, 幂等 (同 MovInboundServer.ensureRunning 模式) */
    public static synchronized boolean ensureRunning(Context ctx) {
        if (instance != null && instance.running) return true;
        instance = new RoomStaticServer(ctx);
        return instance.start();
    }

    public synchronized boolean start() {
        if (running) return false;
        try {
            serverSocket = new ServerSocket();
            serverSocket.setReuseAddress(true);
            serverSocket.bind(new InetSocketAddress("127.0.0.1", PORT));
            running = true;
            pool.submit(this::acceptLoop);
            Log.i(TAG, "房间静态服务启动 http://127.0.0.1:" + PORT);
            return true;
        } catch (Exception e) {
            Log.w(TAG, "启动失败 (" + PORT + " 被占用?): " + e.getMessage());
            return false;
        }
    }

    public synchronized void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        pool.shutdownNow();
    }

    // ==================== HTTP 循环 (MovInboundServer 同款) ====================

    private void acceptLoop() {
        while (running) {
            try {
                Socket client = serverSocket.accept();
                pool.submit(() -> handle(client));
            } catch (Exception e) {
                if (running) Log.w(TAG, "accept 异常: " + e.getMessage());
            }
        }
    }

    private void handle(Socket client) {
        try {
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
            OutputStream out = client.getOutputStream();

            String requestLine = reader.readLine();
            if (requestLine == null) { client.close(); return; }
            String[] parts = requestLine.split(" ");
            String method = parts.length > 0 ? parts[0] : "";
            String path = parts.length > 1 ? parts[1].split("\\?")[0] : "";
            /* 静态服务不读 body, 只把请求头读完避免客户端写阻塞 */
            String line;
            while ((line = reader.readLine()) != null && !line.isEmpty()) { /* drain headers */ }

            if (!isLoopback(client.getInetAddress())) {
                writeResponse(out, 403, "text/plain;charset=UTF-8",
                        "forbidden".getBytes(StandardCharsets.UTF_8));
                client.close();
                return;
            }
            File roomsDir = new StorageManager(context).getRoomsDir();
            Response resp = dispatch(method, path, roomsDir);
            writeResponse(out, resp.status, resp.mime, resp.body);
            client.close();
        } catch (Exception e) {
            Log.w(TAG, "处理请求异常: " + e.getMessage());
        }
    }

    private static void writeResponse(OutputStream out, int status, String mime, byte[] body)
            throws IOException {
        String statusText = status == 200 ? "200 OK"
                : status == 405 ? "405 Method Not Allowed"
                : status == 400 ? "400 Bad Request"
                : status == 403 ? "403 Forbidden" : "404 Not Found";
        String header = "HTTP/1.1 " + statusText + "\r\n"
                + "Content-Type: " + mime + "\r\n"
                + "Content-Length: " + body.length + "\r\n"
                + "Connection: close\r\n\r\n";
        out.write(header.getBytes(StandardCharsets.UTF_8));
        out.write(body);
        out.flush();
    }

    // ==================== 路由分发 (纯逻辑, 零网络, 单测直接调) ====================

    /**
     * 解析 GET 请求并读文件。roomsDir = StorageManager.getRoomsDir()。
     * 目录穿越防护: canonical 校验 target 必须在 work 目录内 (与 resolveWorkFile 同语义)。
     */
    static Response dispatch(String method, String path, File roomsDir) {
        if (!"GET".equalsIgnoreCase(method)) {
            return new Response(405, "method_not_allowed".getBytes(StandardCharsets.UTF_8), "text/plain");
        }
        if (path == null || !path.startsWith(BASE_PATH)) {
            return notFound();
        }
        String rest = path.substring(BASE_PATH.length());
        int slash = rest.indexOf('/');
        if (slash <= 0) return notFound();
        String roomId = rest.substring(0, slash);
        /* roomId 白名单 (与 BridgeValidator/StorageManager.isValidId 同规则), 防路径穿越 */
        if (!roomId.matches("^[A-Za-z0-9_-]{1,64}$")) {
            return new Response(400, "bad_room".getBytes(StandardCharsets.UTF_8), "text/plain");
        }
        String sub = rest.substring(slash + 1);
        /* 只 serve files/work/ 下 (产出物目录) */
        if (!sub.startsWith("files/work/")) return notFound();
        String filePath = sub.substring("files/work/".length());
        if (filePath.isEmpty()) return notFound();

        File workDir = new File(roomsDir, roomId + "/files/work");
        File target = new File(workDir, filePath);
        if (!isWithin(workDir, target)) {
            /* 目录穿越 (../ 逃出 work) */
            return new Response(400, "bad_path".getBytes(StandardCharsets.UTF_8), "text/plain");
        }
        if (!target.isFile()) return notFound();
        try {
            byte[] data = Files.readAllBytes(target.toPath());
            return new Response(200, data, mimeFor(filePath));
        } catch (IOException e) {
            return notFound();
        }
    }

    private static Response notFound() {
        return new Response(404, "not_found".getBytes(StandardCharsets.UTF_8), "text/plain");
    }

    /** canonical 前缀校验 (与 StorageManager.isCanonicalWithin 同逻辑, 独立实现便于 serve 包单测) */
    static boolean isWithin(File base, File target) {
        try {
            String b = base.getCanonicalFile().getPath();
            String t = target.getCanonicalFile().getPath();
            return t.equals(b) || t.startsWith(b + File.separator);
        } catch (IOException e) {
            return false;
        }
    }

    static String mimeFor(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".html") || n.endsWith(".htm")) return "text/html;charset=UTF-8";
        if (n.endsWith(".js") || n.endsWith(".mjs")) return "application/javascript";
        if (n.endsWith(".css")) return "text/css;charset=UTF-8";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".json")) return "application/json;charset=UTF-8";
        if (n.endsWith(".txt")) return "text/plain;charset=UTF-8";
        if (n.endsWith(".woff2")) return "font/woff2";
        if (n.endsWith(".woff")) return "font/woff";
        if (n.endsWith(".ttf")) return "font/ttf";
        return "application/octet-stream";
    }

    private static boolean isLoopback(InetAddress addr) {
        return addr != null && (addr.isLoopbackAddress() || addr.isAnyLocalAddress());
    }

    static class Response {
        final int status;
        final byte[] body;
        final String mime;
        Response(int status, byte[] body, String mime) {
            this.status = status;
            this.body = body;
            this.mime = mime;
        }
    }
}
