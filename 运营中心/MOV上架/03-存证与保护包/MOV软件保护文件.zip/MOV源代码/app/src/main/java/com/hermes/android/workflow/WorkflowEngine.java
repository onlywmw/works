package com.hermes.android.workflow;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Workflow 引擎 — 事件驱动 fire 链路（纯 JVM，零 Android/WebView）。
 *
 * fire(event, snapshot)：enabled → TriggerEvaluator 命中 → cooldown → daily-cap
 * → ConditionEvaluator（AND+invert）→ ActionExecutor → recordFire。
 * 动作副作用经 ActionExecutor 注入接口解耦。
 */
public class WorkflowEngine {

    private final WorkflowRepository repo;
    private final ActionExecutor actions;
    /** 管道埋点：每环判定一行 trace（纯 JVM Consumer，调用方打 Log；null = 不埋） */
    private final java.util.function.Consumer<String> trace;

    public WorkflowEngine(WorkflowRepository repo, ActionExecutor actions) {
        this(repo, actions, null);
    }

    public WorkflowEngine(WorkflowRepository repo, ActionExecutor actions,
                          java.util.function.Consumer<String> trace) {
        this.repo = repo;
        this.actions = actions;
        this.trace = trace;
    }

    private void tr(String msg) {
        if (trace != null) trace.accept(msg);
    }

    public FireResult fire(WorkflowEvent event, Snapshot snap) {
        return fire(event, snap, null);
    }

    /** fire 指定 workflow（manual 精确触发用；onlyWorkflowId=null 时全部评估） */
    public FireResult fire(WorkflowEvent event, Snapshot snap, String onlyWorkflowId) {
        List<String> fired = new ArrayList<>();
        List<String> skipped = new ArrayList<>();
        for (Workflow wf : repo.list()) {
            if (onlyWorkflowId != null && !onlyWorkflowId.equals(wf.id)) continue;
            if (!wf.enabled) {
                tr("wf=" + wf.id + " event=" + event.type + " DISABLED");
                continue;
            }
            boolean hit = TriggerEvaluator.matches(wf.trigger, event, wf, snap.now);
            tr("wf=" + wf.id + " event=" + event.type + " trigger=" + wf.triggerType() + " hit=" + hit);
            if (!hit) continue;

            // cooldown gate
            if (wf.cooldownMs > 0 && snap.now - wf.lastFireAt < wf.cooldownMs) {
                tr("  skip cooldown (last=" + wf.lastFireAt + " now=" + snap.now + " cd=" + wf.cooldownMs + ")");
                skipped.add(wf.id + ":cooldown");
                continue;
            }
            // daily-cap gate（本地日期 rollover）
            String today = dateStr(snap.now);
            if (!today.equals(wf.runsTodayDate)) {
                wf.runsToday = 0;
                wf.runsTodayDate = today;
            }
            if (wf.maxRunsPerDay > 0 && wf.runsToday >= wf.maxRunsPerDay) {
                tr("  skip daily_cap (runs=" + wf.runsToday + "/" + wf.maxRunsPerDay + ")");
                skipped.add(wf.id + ":daily_cap");
                continue;
            }
            // 条件评估（AND，全部通过才执行）；last_run_ago 用 per-workflow lastFireAt
            Snapshot condSnap = snap.withLastRunAt(wf.lastFireAt);
            boolean cond = ConditionEvaluator.evaluateAll(wf.conditions, condSnap);
            tr("  condition=" + (cond ? "PASS" : "FAIL") + " count=" + (wf.conditions != null ? wf.conditions.length() : 0));
            if (!cond) {
                skipped.add(wf.id + ":condition");
                continue;
            }
            // 执行动作（F2：只在真实执行回执时落账；全拒/超时不落 cooldown）
            Map<String, Object> ctx = new HashMap<>();
            ctx.put("workflowId", wf.id);
            ctx.put("url", snap.url);
            ctx.put("now", snap.now);
            ActionExecutor.ActionReceipt receipt = actions.execute(wf.actions, ctx);
            tr("  actionReceipt=" + receipt);
            if (receipt != ActionExecutor.ActionReceipt.SUCCESS) {
                skipped.add(wf.id + ":no_effect(" + receipt + ")");
                continue;   // 不落 lastFireAt/runsToday/save
            }
            wf.lastFireAt = snap.now;
            wf.runsToday++;
            wf.runCount++;
            repo.save(wf);
            tr("  FIRED actions=" + (wf.actions != null ? wf.actions.length() : 0));
            fired.add(wf.id);
        }
        return new FireResult(fired, skipped);
    }

    /** 运行结果：fired = 本次触发的 workflow id；skipped = "id:原因" 列表 */
    public static class FireResult {
        public final List<String> fired;
        public final List<String> skipped;
        public FireResult(List<String> fired, List<String> skipped) {
            this.fired = fired;
            this.skipped = skipped;
        }
    }

    static String dateStr(long now) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(now);
        int y = c.get(Calendar.YEAR);
        int mo = c.get(Calendar.MONTH) + 1;
        int d = c.get(Calendar.DAY_OF_MONTH);
        return (y < 10 ? "0" : "") + y + "-" + (mo < 10 ? "0" : "") + mo + "-" + (d < 10 ? "0" : "") + d;
    }
}
