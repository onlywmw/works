package com.hermes.android.workflow;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 设备事件触发器族规划（纯 JVM，可单测）——按启用 workflow 的触发器类型算需要的 receiver 家族。
 * 零启用 = 空集（DeviceTriggerManager 据此零常驻 receiver）。
 */
public class DeviceTriggerPlanner {

    public enum Family { SCREEN, POWER, BATTERY, HEADPHONES, WIFI, BT }

    /** 触发器类型 → 家族；无设备触发器（未知/null）→ null */
    public static Family familyOf(String triggerType) {
        if (triggerType == null) return null;
        switch (triggerType) {
            case "screen_on": case "screen_off": return Family.SCREEN;
            case "power_connected": case "power_disconnected": return Family.POWER;
            case "battery_below": case "battery_above": return Family.BATTERY;
            case "headphones_plugged": case "headphones_unplugged": return Family.HEADPHONES;
            case "wifi_connected": case "wifi_disconnected": return Family.WIFI;
            case "bt_connected": case "bt_disconnected": return Family.BT;
            default: return null;
        }
    }

    /** 启用 workflows 需要的家族集合（零启用 = 空集） */
    public static Set<Family> computeNeeded(List<Workflow> enabled) {
        Set<Family> need = new HashSet<>();
        if (enabled != null) {
            for (Workflow w : enabled) {
                if (w.enabled) {
                    Family f = familyOf(w.triggerType());
                    if (f != null) need.add(f);
                }
            }
        }
        return need;
    }
}
