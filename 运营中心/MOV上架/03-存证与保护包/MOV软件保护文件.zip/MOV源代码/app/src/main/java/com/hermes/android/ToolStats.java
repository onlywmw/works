package com.hermes.android;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * FUSION F6: 晋升统计 — 扫描所有房间 journal，按工具统计 step 调用频次。
 * 数据喂慢脑/验收人做 SLOW→FAST 固化决策（DESIGN_FUSION 四节：高频+链路固定+无需组合）。
 *
 * 输入即目录（注入式，照 TrainSourceTest 风格），单测零网络可用临时目录。
 */
public class ToolStats {

    /**
     * 统计所有房间 journal 的工具调用频次（step 事件按 name 聚合）。
     *
     * @param roomsDir StorageManager.getRoomsDir()
     * @return JSONArray: [{name, count, ok, fail}, ...] 按 count 降序
     */
    public static JSONArray collect(File roomsDir) throws org.json.JSONException {
        Map<String, int[]> stat = new TreeMap<>();   // name → [count, ok, fail]
        File[] roomDirs = roomsDir.listFiles(File::isDirectory);
        if (roomDirs != null) {
            for (File rd : roomDirs) {
                File jf = new File(rd, "journal.jsonl");
                if (!jf.exists()) continue;
                try (BufferedReader r = new BufferedReader(new InputStreamReader(
                        new FileInputStream(jf), "UTF-8"))) {
                    String line;
                    while ((line = r.readLine()) != null) {
                        line = line.trim();
                        if (!line.contains("\"type\":\"step\"")) continue;
                        try {
                            JSONObject ev = new JSONObject(line);
                            if (!"step".equals(ev.optString("type"))) continue;
                            String name = ev.optString("name", "");
                            if (name.isEmpty()) continue;
                            boolean ok = ev.optBoolean("ok", false);
                            int[] c = stat.get(name);
                            if (c == null) { c = new int[3]; stat.put(name, c); }
                            c[0]++;
                            if (ok) c[1]++; else c[2]++;
                        } catch (Exception ignored) {}
                    }
                } catch (Exception ignored) {}
            }
        }
        List<Map.Entry<String, int[]>> sorted = new ArrayList<>(stat.entrySet());
        sorted.sort((a, b) -> b.getValue()[0] - a.getValue()[0]);
        JSONArray arr = new JSONArray();
        for (Map.Entry<String, int[]> e : sorted) {
            int[] c = e.getValue();
            arr.put(new JSONObject()
                    .put("name", e.getKey())
                    .put("count", c[0])
                    .put("ok", c[1])
                    .put("fail", c[2]));
        }
        return arr;
    }
}
