package com.hermes.android.llama;

import android.content.Context;

import com.hermes.android.agent.SearchReranker;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * SemanticReranker —— SearchReranker 端侧实现（M3，A9 变异靶点）。
 * 流程：query 加 BGE 指令前缀 + 候选截断 → llama.cpp 8081 批量 embedding → cosine 降序 → 阈值过滤。
 * A4 首启：ensureReadyWithin(≤1s) 未就绪 → 返回 null（本次回退 + 后台预热，不阻塞搜索）。
 * 全异常 catch 返回 null（容错——Journal 侧静默回退保底）。
 * 可注入 Transport（单测假 responder 零网络，ctx null 跳过就绪检查）。
 */
public class SemanticReranker implements SearchReranker {

    /** BGE query 指令前缀（官方要求 query 加、passage 不加，否则检索质量打折）。 */
    public static final String QUERY_PREFIX = "为这个句子生成表示以用于检索相关文章：";
    /** 候选文本截断上限（bge 512 token 安全值 ~768 字符；超长截尾保留最新语义，A3/A10）。 */
    public static final int MAX_EMBED_CHARS = 768;
    /** 相似度阈值：低于此值的候选不进结果（A5，防完全无关候选被前置）。
     *  M4 真机实测调参（2026-08-10）：0.5 过严——带 BGE 前缀 query + 语境长句候选的真实语义命中
     *  cosine=0.46（「为…睡眠不足」vs「请记住：我经常凌晨三点才睡…」），被 0.5 过滤漏检；
     *  无关反例 0.30 仍被滤。阈值 0.4 同时保留正例、滤掉反例。 */
    public static final double THRESHOLD = 0.4;
    /** 首启就绪等待上限（A4：本次回退，不阻塞搜索）。 */
    public static final long READY_AWAIT_MS = 1000;

    /** HTTP 传输（单测注入假 responder，零网络）。异常 = 网络失败 → 调用方回退。 */
    public interface Transport {
        String postEmbeddings(String payload, String token) throws Exception;
    }

    private static class Scored {
        final int index;
        final double sim;
        Scored(int index, double sim) { this.index = index; this.sim = sim; }
    }

    private final Context ctx;
    private final Transport transport;

    public SemanticReranker(Context ctx) {
        this(ctx, null);
    }

    /** 包内可见构造：单测注入假 transport（ctx null = 跳过 A4 就绪检查与 token 读取） */
    SemanticReranker(Context ctx, Transport transport) {
        this.ctx = ctx;
        this.transport = transport != null ? transport : defaultTransport();
    }

    private static Transport defaultTransport() {
        return (payload, token) -> {
            HttpURLConnection c = (HttpURLConnection) new URL(
                    EmbeddingClient.BASE_URL + "/v1/embeddings").openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(3000);
            c.setReadTimeout(5000);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Authorization", "Bearer " + (token != null ? token : ""));
            c.setDoOutput(true);
            try (OutputStream os = c.getOutputStream()) {
                os.write(payload.getBytes(StandardCharsets.UTF_8));
            }
            int code = c.getResponseCode();
            if (code != 200) throw new IllegalStateException("embedding HTTP " + code);
            return readAll(c);
        };
    }

    @Override
    public List<Integer> rerank(String query, List<String> texts) {
        try {
            if (query == null || query.trim().isEmpty() || texts == null || texts.isEmpty()) return null;
            // A4 首启：未就绪本次回退（ctx null 用于单测，跳过就绪检查）
            if (ctx != null && !EmbeddingServerManager.ensureReadyWithin(ctx, READY_AWAIT_MS)) {
                return null;
            }
            List<String> input = new ArrayList<>(texts.size() + 1);
            input.add(QUERY_PREFIX + query.trim());
            for (String t : texts) input.add(truncate(t));
            String payload = EmbeddingClient.buildEmbeddingPayload(null, input);
            String token = ctx != null ? EmbeddingServerManager.token(ctx) : "";
            String raw = transport.postEmbeddings(payload, token);
            float[][] vecs = EmbeddingClient.parseResponse(raw);
            if (vecs == null || vecs.length != input.size()) return null;
            float[] vq = vecs[0];
            List<Scored> scored = new ArrayList<>();
            for (int i = 0; i < texts.size(); i++) {
                double sim = EmbeddingClient.cosine(vq, vecs[i + 1]);
                if (sim >= THRESHOLD) scored.add(new Scored(i, sim));
            }
            scored.sort((x, y) -> Double.compare(y.sim, x.sim));   // 高相似在前
            List<Integer> result = new ArrayList<>(scored.size());
            for (Scored s : scored) result.add(s.index);
            return result;
        } catch (Exception e) {
            return null;
        }
    }

    /** 候选文本截断：超 MAX_EMBED_CHARS 截尾保留最新语义（方案 B 无命中位置可用，A3/A10）。 */
    static String truncate(String s) {
        if (s == null) return "";
        if (s.length() <= MAX_EMBED_CHARS) return s;
        return s.substring(s.length() - MAX_EMBED_CHARS);
    }

    private static String readAll(HttpURLConnection c) throws Exception {
        try (java.io.InputStream in = c.getInputStream();
             java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
