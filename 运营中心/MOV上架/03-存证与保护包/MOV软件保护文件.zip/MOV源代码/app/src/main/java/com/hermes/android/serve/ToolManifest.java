package com.hermes.android.serve;

import android.content.Context;
import android.util.Log;

import com.hermes.android.agent.ToolRegistry;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.nio.file.Files;

/**
 * 阶段3 A3: MOV 工具清单生成 + 推送 daemon。
 *
 * serve 的 GET /tools 需要真实 ToolRegistry 清单（name/description/level/tier/params/examples），
 * 经 /exchange bind 共享写入 mov-tools.json，daemon 读它返回（清单=唯一真相，删注册条目即同步变）。
 *
 * 注：registry 构建与 A0 buildServerRegistry 同构（清单必须反映 A0 能执行的工具集）；
 * 为不碰已交付的 MovInboundServer，此处保留同构副本。
 */
public class ToolManifest {

    private static final String TAG = "ToolManifest";

    /** 写清单到 /exchange/mov-tools.json（幂等，失败静默——非致命，daemon 读到旧/空表降级）。 */
    public static void writeToExchange(Context ctx) {
        try {
            ToolRegistry registry = buildRegistry(ctx);
            JSONArray arr = toManifest(registry);
            File ex = new File(ctx.getFilesDir(), "linux-exchange");
            ex.mkdirs();
            File f = new File(ex, "mov-tools.json");
            Files.write(f.toPath(), arr.toString(2).getBytes("UTF-8"));
            Log.i(TAG, "MOV 工具清单写入 " + f.getAbsolutePath() + " (" + arr.length() + " 工具)");
        } catch (Exception e) {
            Log.w(TAG, "清单写入失败: " + e.getMessage());
        }
    }

    /** ToolRegistry → 清单 JSON 数组（name/description/level/tier/params/examples）。 */
    static JSONArray toManifest(ToolRegistry registry) throws Exception {
        JSONArray arr = new JSONArray();
        for (ToolRegistry.Tool t : registry.allTools()) {
            JSONObject o = new JSONObject();
            o.put("name", t.name);
            o.put("description", t.desc != null ? t.desc : t.name);
            String level = t.manifest != null ? t.manifest.level : null;
            o.put("level", level != null ? level : "SLOW");
            o.put("tier", tierOf(t));
            JSONArray params = new JSONArray();
            if (t.params != null) {
                for (ToolRegistry.ParamDef p : t.params) {
                    JSONObject po = new JSONObject();
                    po.put("name", p.name);
                    po.put("type", p.type);
                    po.put("required", p.required);
                    if (p.description != null && !p.description.isEmpty()) po.put("description", p.description);
                    params.put(po);
                }
            }
            o.put("params", params);
            JSONArray exs = new JSONArray();
            if (t.examples != null) for (String e : t.examples) exs.put(e);
            o.put("examples", exs);
            arr.put(o);
        }
        return arr;
    }

    /** tier 映射：readonly→READONLY / approval=always→DANGEROUS / 其余 ACTION（照 DevicePolicy 分级语义） */
    private static String tierOf(ToolRegistry.Tool t) {
        if ("readonly".equals(t.access)) return "READONLY";
        if ("always".equals(t.approval)) return "DANGEROUS";
        return "ACTION";
    }

    /** 统一构建源（与 A0 MovInboundServer 共用 RegistryProvider，消除重复副本） */
    private static ToolRegistry buildRegistry(Context ctx) {
        return com.hermes.android.mcp.server.RegistryProvider.build(ctx);
    }
}
