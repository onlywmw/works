package com.hermes.android.workflow;

import com.hermes.android.browser.BrowserActionExecutor;

import android.content.Context;

import java.io.File;


/**
 * Workflows 应用级单例 — 触发器引擎（com.hermes.android.workflow 纯 JVM）的 ConnectWeb 集成壳。
 * 持有 repo + engine + 页面事件源；动作执行接 BrowserActionExecutor（ConnectWeb 浏览器动作）。
 * 纯 JVM 引擎保持零 android 依赖，集成逻辑都在这层。
 */
public class Workflows {

    private static Workflows instance;

    private final WorkflowRepository repo;
    private final WorkflowEngine engine;
    private final WorkflowEventSource source;
    /** 设备事件 fire 后台线程（receiver 回调 mainLooper → fire 切后台，防 BrowserActionExecutor await 死锁） */
    private final java.util.concurrent.ExecutorService exec =
            java.util.concurrent.Executors.newSingleThreadExecutor();
    private DeviceTriggerManager deviceTriggers;

    private Workflows(WorkflowRepository repo) {
        this.repo = repo;
        this.engine = new WorkflowEngine(repo, new BrowserActionExecutor(),
                msg -> android.util.Log.i("Workflow", msg));   // 管道埋点：引擎每环判定一行 log
        this.source = new WorkflowEventSource(engine);
    }

    /** 种子版本：升版时 migrateSeeds 合并更新（按 id 覆盖种子，不碰用户自建） */
    private static final String PREFS = "workflows_meta";
    private static final int SEED_VERSION = 3;   // v3: 京东绕行 → 自家演示店 demo_shop_search

    public static synchronized void init(Context ctx) {
        if (instance != null) return;
        Context app = ctx.getApplicationContext();
        File dir = new File(app.getFilesDir(), "workflows");
        WorkflowRepository repo = new WorkflowRepository(dir);
        migrateSeeds(app, repo);   // 库内版本 < assets 版本 → 合并更新种子
        instance = new Workflows(repo);
        instance.deviceTriggers = new DeviceTriggerManager(app, instance.source, instance.exec);
        instance.source.setDeviceStateProvider(new DeviceStateReader(app));   // 拉取式设备状态（snapshot 现查，与 receiver 解耦）
        instance.resyncDeviceTriggers();   // 首次：按启用设备触发器 workflow 注册 receiver（零启用零常驻）
        // 第二幕: time_cron 周期任务（WorkManager 15min，平台最小；cron 匹配当前时间即 fire）
        try {
            androidx.work.PeriodicWorkRequest cronReq = new androidx.work.PeriodicWorkRequest.Builder(
                    CronWorker.class, 15, java.util.concurrent.TimeUnit.MINUTES).build();
            androidx.work.WorkManager.getInstance(app).enqueueUniquePeriodicWork(
                    "wf_cron", androidx.work.ExistingPeriodicWorkPolicy.KEEP, cronReq);
        } catch (Exception e) {
            android.util.Log.e("Workflow", "workmanager schedule error", e);
        }
    }

    /** 设备触发器 resync：workflow 变更后调用（ConnectWeb 页面加载时顺带） */
    public void resyncDeviceTriggers() {
        if (deviceTriggers != null) deviceTriggers.resync(repo.list());
    }

    /** manual 触发（Run now）：精确触发指定 workflow */
    public void wfRunManual(String workflowId) {
        if (workflowId != null && source != null) {
            source.onManual(workflowId, System.currentTimeMillis());
        }
    }

    /** 种子升级：assets 版本 > 库内版本 → 按 id 覆盖同名种子（用户自建 workflow 不受影响） */
    private static void migrateSeeds(Context app, WorkflowRepository repo) {
        android.content.SharedPreferences prefs = app.getSharedPreferences(PREFS, 0);
        int libVersion = prefs.getInt("seed_version", 0);
        if (libVersion >= SEED_VERSION) return;
        seedOne(app, repo, "workflows/demo_shop_search.json");   // 自家演示店（京东反爬绕行）
        prefs.edit().putInt("seed_version", SEED_VERSION).apply();
        android.util.Log.i("Workflow", "seed migrated lib=" + libVersion + " -> " + SEED_VERSION);
    }

    private static void seedOne(Context app, WorkflowRepository repo, String assetPath) {
        try (java.io.InputStream is = app.getAssets().open(assetPath)) {
            java.io.BufferedReader r = new java.io.BufferedReader(
                    new java.io.InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            repo.save(com.hermes.android.workflow.Workflow.fromJson(
                    new org.json.JSONObject(sb.toString())));
        } catch (Exception e) {
            android.util.Log.e("Workflow", "seed load error: " + assetPath, e);
        }
    }

    public static Workflows get() { return instance; }

    public WorkflowRepository repo() { return repo; }
    public WorkflowEngine engine() { return engine; }
    public WorkflowEventSource source() { return source; }

    /** 启用的 element_appear 触发器 selector 列表（ConnectWeb 检测 JS 注入用） */
    public java.util.List<String> elementSelectors() {
        java.util.List<String> sels = new java.util.ArrayList<>();
        for (com.hermes.android.workflow.Workflow w : repo.list()) {
            if (!w.enabled || !"element_appear".equals(w.triggerType())) continue;
            String s = w.trigger.optString("selector", "");
            if (!s.isEmpty()) sels.add(s);
        }
        return sels;
    }

    /** 条件快照 v2：启用的 workflow 中 element 条件的 selector 列表（页面状态查询 JS 用） */
    public java.util.List<String> conditionElementSelectors() {
        java.util.List<String> sels = new java.util.ArrayList<>();
        for (com.hermes.android.workflow.Workflow w : repo.list()) {
            if (!w.enabled) continue;
            org.json.JSONArray conds = w.conditions;
            for (int i = 0; i < conds.length(); i++) {
                org.json.JSONObject c = conds.optJSONObject(i);
                if (c != null && "element".equals(c.optString("type"))) {
                    String s = c.optString("selector", "");
                    if (!s.isEmpty() && !sels.contains(s)) sels.add(s);
                }
            }
        }
        return sels;
    }

    /** 启用的 text_match 触发器 pattern 列表（ConnectWeb 检测 JS 注入用） */
    public java.util.List<String> textPatterns() {
        java.util.List<String> pats = new java.util.ArrayList<>();
        for (com.hermes.android.workflow.Workflow w : repo.list()) {
            if (!w.enabled || !"text_match".equals(w.triggerType())) continue;
            String p = w.trigger.optString("pattern", "");
            if (!p.isEmpty()) pats.add(p);
        }
        return pats;
    }
}
