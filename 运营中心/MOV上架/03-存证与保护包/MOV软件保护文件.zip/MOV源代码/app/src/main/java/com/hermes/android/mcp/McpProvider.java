package com.hermes.android.mcp;

import android.content.Context;
import android.util.Log;

import com.hermes.android.StorageManager;
import com.hermes.android.agent.Journal;
import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.agent.ToolRegistry.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * McpProvider — MCP 工具来源 (TOOL_PORTING P0；工单25 幕一 D：多 server)。
 *
 * 实现 ToolProvider 接口，连 HTTP MCP Server，动态发现工具并注册。
 * check_fn 探测连通性 + Token 有效性，不可用时不注入 Prompt。
 * 多 server：discover() 遍历 McpServerStore 中 enabled=true 的条目逐个健康检查+注册。
 */
public class McpProvider implements ToolRegistry.ToolProvider {

    private static final String TAG = "McpProvider";
    private static Context appContext;
    private final McpClient client;
    private McpServerStore store;

    public McpProvider() {
        this(null, new McpClient());
    }

    /** 单测注入：store（内存 fake Prefs）+ client（零网络 fake）。 */
    McpProvider(McpServerStore store, McpClient client) {
        this.store = store;
        this.client = client;
    }

    public static void init(Context ctx) { appContext = ctx.getApplicationContext(); }

    @Override public String id() { return "mcp"; }

    @Override
    public List<Tool> discover() {
        List<Tool> tools = new ArrayList<>();
        McpServerStore s = store();
        if (s == null) return tools;  // 无 Context 且未注入 store（单测环境, 无配置）
        for (McpServerStore.Entry srv : s.list()) {
            if (!srv.enabled) continue;  // 只注册启用条目
            discoverFrom(srv.url, srv.token, tools);
        }
        return tools;
    }

    private McpServerStore store() {
        if (store == null && appContext != null) store = McpServerStore.create(appContext);
        return store;
    }

    /** 单 server 健康检查 + tools/list + 注册 mcp.* 动态工具。 */
    private void discoverFrom(final String url, final String token, List<Tool> tools) {
        // 未配置 url → 不接入（验收打回修复 2026-08-05：
        // 禁静默默认第三方服务——未配置时 discover 会在桥线程同步出网到外部服务器）
        if (url == null || url.isEmpty()) return;

        // 健康检查 + tools/list
        try {
            if (!client.healthCheck(url, token)) {
                logW("MCP Server 不可达: " + url);
                return;
            }
            JSONArray list = client.listTools(url, token);
            if (list == null) return;
            for (int i = 0; i < list.length(); i++) {
                JSONObject t = list.optJSONObject(i);
                if (t == null) continue;
                String name = t.optString("name", "");
                String desc = t.optString("description", name);
                // MCP Schema → ParamDef
                JSONObject schema = t.optJSONObject("inputSchema");
                ParamDef[] params = schema != null ? schemaToProps(schema) : null;
                Tool tool = new Tool("mcp." + name, desc, null, args -> {
                    JSONObject result = client.callTool(url, token, name, args);
                    boolean ok = result != null && !result.has("error");
                    // 域记忆移植（工单8，DESIGN_MEM_DOMAIN_PORT §二）：MCP 工具回执统一截取——成功才落账，失败/空不落。
                    if (ok && result != null) {
                        try { ingestReceipt(name, result, "biz"); }
                        catch (Exception e) { logW("ingest receipt fail: " + e.getMessage()); }
                    }
                    return new Result(ok, result != null ? result.toString() : "调用失败",
                            null, result != null ? result.toString() : "");
                }, "remote", "readonly", "none", true, 30,
                        "biz", params, desc, null, null, 8000,
                        new Manifest(name, "medium", "远程 MCP 工具: " + desc, false, "remote"),
                        () -> {
                            try { return client.healthCheck(url, token) ? null : "MCP Server 不可达"; }
                            catch (Exception e) { return "MCP 连接失败"; }
                        });
                tools.add(tool);
            }
            logI("MCP 发现 " + list.length() + " 工具 from " + url);
        } catch (Exception e) {
            logW("MCP discover failed: " + e.getMessage());
        }
    }

    /* android.util.Log 在 JVM 单测不可用（android.jar stub 会抛）→ 仅设备侧落日志 */
    private static void logI(String msg) { if (appContext != null) Log.i(TAG, msg); }
    private static void logW(String msg) { if (appContext != null) Log.w(TAG, msg); }

    /** 域记忆移植（工单8，DESIGN_MEM_DOMAIN_PORT §二）：信封四字段 tool/domain/ts/payload 原文，落 global 房（v1 与 causal 同例）。
     *  仅本地落账零出网（拍板E：PII 闸随 G15 读取管线，此处不涉网）。domain v1 固定 "biz"（MCP toolset 推导，见文档 §八出入1）。 */
    private void ingestReceipt(String toolName, JSONObject result, String domain) {
        if (appContext == null) return;
        try {
            Journal j = new Journal(new StorageManager(appContext).getRoomsDir());
            JSONObject ev = Journal.toolReceiptEvent("mcp." + toolName, domain, result.toString());
            if (ev != null) j.append("global", ev);
        } catch (Exception e) {
            Log.w(TAG, "ingestReceipt: " + e.getMessage());
        }
    }

    private ParamDef[] schemaToProps(JSONObject schema) {
        JSONObject props = schema.optJSONObject("properties");
        if (props == null) return null;
        JSONArray required = schema.optJSONArray("required");
        List<ParamDef> list = new ArrayList<>();
        java.util.Iterator<String> it = props.keys();
        while (it.hasNext()) {
            String key = it.next();
            JSONObject p = props.optJSONObject(key);
            if (p == null) continue;
            boolean req = required != null && required.toString().contains("\"" + key + "\"");
            list.add(new ParamDef(key, p.optString("type", "string"), req,
                    "", p.optString("description", "")));
        }
        return list.toArray(new ParamDef[0]);
    }
}
