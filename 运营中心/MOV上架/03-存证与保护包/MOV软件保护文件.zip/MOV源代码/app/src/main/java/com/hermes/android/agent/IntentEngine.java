package com.hermes.android.agent;

import android.content.Context;
import android.util.Log;

import com.hermes.android.ai.AiClient;
import com.hermes.android.model.ModelConfig;
import com.hermes.android.model.ModelRegistry;

import org.json.JSONObject;

/**
 * IntentEngine — LLM 驱动的意图分类器（Phase 2A.1）。
 *
 * 输入用户原话 → 调默认模型 → 返回结构化意图 JSON：
 * {type: "service"|"creation"|"chat", domain, slots, confidence}
 *
 * 不依赖 AgentLoop；直接用 AiClient 做单轮 LLM 调用。
 */
public class IntentEngine {

    private static final String TAG = "IntentEngine";
    private static final String PROMPT_FILE = "intent_rules.txt";
    /** FUSION F2/P2-6: intent 合法值白名单 — LLM 返回怪值归 unknown，防路由猜错 */
    private static final String[] KNOWN_INTENTS = {"music", "train", "drama", "browser", "a2a", "chat", "creation", "unknown"};
    private static boolean isValidIntent(String s) {
        for (String k : KNOWN_INTENTS) if (k.equals(s)) return true;
        return false;
    }

    /** 硬编码 fallback（PromptLoader 文件丢失时兜底） */
    private static final String FALLBACK_PROMPT =
        "你是 MOV 的意图分类器。输入用户的一句话，输出 JSON 分类结果。\n" +
        "三种意图类型: service(外部服务), creation(创造生产), chat(闲聊问答)。\n" +
        "场景意图 intent: music(听歌), train(火车票), drama(追剧), browser(网页搜索/查资料), a2a(点餐), creation(创作), chat(闲聊), unknown(拿不准)。\n" +
        "领域: travel, entertainment, shopping, development, productivity, general。\n" +
        "槽位 slots: 从话中提取的参数对象，无则 {}。\n" +
        "置信度 confidence: 0.0-1.0。\n" +
        "只输出 JSON: {\"intent\":\"...\",\"type\":\"...\",\"domain\":\"...\",\"slots\":{...},\"confidence\":0.0}\n";

    private final Context ctx;
    private boolean initialized;
    /** FUSION F4: 注册表（快脑场景卡清单来源），可能为 null（未注入时只靠 intent_rules.txt） */
    private ToolRegistry toolRegistry;

    public IntentEngine(Context ctx) {
        this.ctx = ctx != null ? ctx.getApplicationContext() : null;
    }

    /** FUSION F4: 注入注册表（BridgeAi 从 agentStart 缓存的 registry 传；未跑过 agentStart 时为 null） */
    public void setToolRegistry(ToolRegistry r) {
        this.toolRegistry = r;
    }

    private void ensureInit() {
        if (initialized || ctx == null) return;
        PromptLoader.init(ctx);
        initialized = true;
    }

    /**
     * 【测试入口】用预设 LLM 响应做分类（不实际调模型）。
     * 仅对 type/domain 做合法性校验，不做关键词降级。
     */
    IntentResult classifyWithMockResponse(String text, String mockJson) {
        try {
            String json = extractJSON(mockJson);
            JSONObject obj = new JSONObject(json);
            String type = obj.optString("type", "chat");
            if (!type.equals("service") && !type.equals("creation") && !type.equals("chat")) {
                type = "chat";
            }
            String domain = obj.optString("domain", "general");
            String slots = obj.optJSONObject("slots") != null
                    ? obj.getJSONObject("slots").toString()
                    : "{}";
            float confidence = (float) obj.optDouble("confidence", 0.5);
            String intent = obj.optString("intent", IntentResult.deriveIntent(type, domain));
            if (!isValidIntent(intent)) intent = "unknown";   // P2-6: 非法 intent 归 unknown
            return new IntentResult(type, domain, intent, slots, confidence);
        } catch (org.json.JSONException e) {
            return fallbackClassify(text);
        }
    }

    /**
     * 分类用户输入。
     *
     * @param text 用户原话（非空）
     * @return IntentResult，永远不会返回 null（错误时返回 chat 类型降级）
     */
    public IntentResult classify(String text) {
        if (text == null || text.trim().isEmpty()) {
            return new IntentResult("chat", "general", "{}", 1.0f);
        }
        ensureInit();

        // 1. 获取默认模型
        ModelConfig model = ModelRegistry.getInstance(ctx).getDefault();
        if (model == null || model.apiKey == null || model.apiKey.isEmpty()) {
            Log.w(TAG, "无可用模型，退回关键词降级");
            return fallbackClassify(text);
        }

        // 2. 加载 prompt
        String systemPrompt = PromptLoader.load(PROMPT_FILE, FALLBACK_PROMPT);
        // 去掉 @version 行
        if (systemPrompt.startsWith("@version:")) {
            int nl = systemPrompt.indexOf('\n');
            if (nl > 0) systemPrompt = systemPrompt.substring(nl + 1);
        }
        // FUSION F4: 拼接注册表工具清单（FAST 直达卡 + SLOW 工具名），LLM 认识能直达的服务才分流得准
        if (toolRegistry != null) {
            systemPrompt += "\n\n" + toolRegistry.intentPromptText();
        }

        // 3. 调 LLM
        try {
            AiClient client = new AiClient(model, systemPrompt);
            // 短超时：connect 5s / read 8s，超时即走 fallback
            AiClient.AiResponse resp = client.chat(text, 5000, 8000);

            if (!resp.success || resp.content == null || resp.content.trim().isEmpty()) {
                Log.w(TAG, "LLM 调用失败: success=" + resp.success + " content=" + resp.content);
                return fallbackClassify(text);
            }

            // 4. 解析 JSON
            String json = extractJSON(resp.content);
            JSONObject obj = new JSONObject(json);

            String type = obj.optString("type", "chat");
            if (!type.equals("service") && !type.equals("creation") && !type.equals("chat")) {
                type = "chat";
            }
            String domain = obj.optString("domain", "general");
            String slots = obj.optJSONObject("slots") != null
                    ? obj.getJSONObject("slots").toString()
                    : "{}";
            float confidence = (float) obj.optDouble("confidence", 0.5);
            String intent = obj.optString("intent", IntentResult.deriveIntent(type, domain));
            if (!isValidIntent(intent)) intent = "unknown";   // P2-6: 非法 intent 归 unknown

            return new IntentResult(type, domain, intent, slots, confidence);

        } catch (org.json.JSONException e) {
            Log.w(TAG, "JSON 解析失败: " + e.getMessage());
            return fallbackClassify(text);
        } catch (Exception e) {
            Log.w(TAG, "LLM 调用异常: " + e.getMessage());
            return fallbackClassify(text);
        }
    }

    /**
     * 从 LLM 输出中提取 JSON 片段（处理模型多输出 markdown 包裹等情况）。
     */
    private String extractJSON(String raw) {
        if (raw == null) return "{}";
        String s = raw.trim();
        // 去掉 markdown 代码块包裹
        if (s.startsWith("```")) {
            int start = s.indexOf('\n');
            int end = s.lastIndexOf("```");
            if (start > 0 && end > start) s = s.substring(start, end).trim();
            else if (start > 0) s = s.substring(start).trim();
        }
        // 找到第一个 { 和最后一个 }
        int l = s.indexOf('{');
        int r = s.lastIndexOf('}');
        if (l >= 0 && r > l) return s.substring(l, r + 1);
        return s;
    }

    /**
     * 关键词降级分类（无模型 / LLM 失败 / JSON 非法时）。
     * 规则覆盖率不高，但保证不崩溃。
     */
    IntentResult fallbackClassify(String text) {
        String t = text.toLowerCase();
        // creation 类关键词
        if (t.contains("写") || t.contains("做") || t.contains("生成") || t.contains("开发")
                || t.contains("app") || t.contains("网页") || t.contains("代码") || t.contains("程序")
                || t.contains("报告") || t.contains("ppt") || t.contains("文档")) {
            if (t.contains("游戏") || t.contains("贪吃蛇") || t.contains("app") || t.contains("网页")) {
                return new IntentResult("creation", "development",
                        "{\"type\":\"" + extractKeyword(text) + "\"}", 0.7f);
            }
            return new IntentResult("creation", "productivity", "{}", 0.7f);
        }
        // service 类关键词
        if (t.contains("订") || t.contains("买") || t.contains("机票") || t.contains("高铁")
                || t.contains("酒店") || t.contains("追剧") || t.contains("看") || t.contains("购物")
                || t.contains("下单") || t.contains("牛奶") || t.contains("导航") || t.contains("翻译")) {
            if (t.contains("机票") || t.contains("高铁") || t.contains("酒店") || t.contains("订")) {
                return new IntentResult("service", "travel", "{}", 0.7f);
            }
            if (t.contains("剧") || t.contains("看") || t.contains("电影")) {
                return new IntentResult("service", "entertainment", "{}", 0.7f);
            }
            if (t.contains("买") || t.contains("牛奶") || t.contains("购物") || t.contains("下单")) {
                return new IntentResult("service", "shopping", "{}", 0.7f);
            }
            return new IntentResult("service", "general", "{}", 0.6f);
        }
        // 默认 chat
        return new IntentResult("chat", "general", "{}", 0.6f);
    }

    private String extractKeyword(String text) {
        // 简单提取创作物的关键词
        if (text.contains("贪吃蛇")) return "贪吃蛇游戏";
        if (text.contains("计算器")) return "计算器";
        if (text.contains("App") || text.contains("app")) return "App";
        if (text.contains("网页")) return "网页";
        if (text.contains("报告")) return "报告";
        return text.length() > 20 ? text.substring(0, 18) : text;
    }

    /** 意图分类结果 */
    public static class IntentResult {
        public final String type;       // "service" | "creation" | "chat"
        public final String domain;     // travel, entertainment, shopping, development, productivity, general
        public final String intent;     // FUSION F2: music|train|drama|a2a|chat|creation|unknown (场景卡直达意图)
        public final String slots;      // JSON 字符串，如 {"destination":"北京"}
        public final float confidence;  // 0.0 ~ 1.0

        /** 旧构造：intent 从 type/domain 推导 */
        public IntentResult(String type, String domain, String slots, float confidence) {
            this(type, domain, deriveIntent(type, domain), slots, confidence);
        }

        /** 新构造：显式 intent（LLM 返回时用） */
        public IntentResult(String type, String domain, String intent, String slots, float confidence) {
            this.type = type;
            this.domain = domain;
            this.intent = intent;
            this.slots = slots;
            this.confidence = Math.max(0f, Math.min(1f, confidence));
        }

        /** 无 intent 时的缺省推导（fallback/LLM 未返回时兜底） */
        private static String deriveIntent(String type, String domain) {
            if ("creation".equals(type)) return "creation";
            if ("service".equals(type)) {
                if ("entertainment".equals(domain)) return "drama";
                if ("travel".equals(domain)) return "unknown"; // 机票/高铁/酒店无法仅凭 domain 区分
                return "unknown";
            }
            return "chat";
        }

        public boolean isService() { return "service".equals(type); }
        public boolean isCreation() { return "creation".equals(type); }
        public boolean isChat() { return "chat".equals(type); }

        @Override
        public String toString() {
            return "IntentResult{type=" + type + ", domain=" + domain
                    + ", slots=" + slots + ", confidence=" + confidence + "}";
        }
    }
}
