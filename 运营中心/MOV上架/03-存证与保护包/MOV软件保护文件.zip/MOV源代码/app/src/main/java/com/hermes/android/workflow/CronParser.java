package com.hermes.android.workflow;

import java.util.Calendar;

/**
 * cron 表达式最小集解析（纯 JVM）——分/时/日/周 4 字段，不支持秒。
 * 字段：minute hour day-of-month day-of-week（4 字段）。
 * 值支持：星号、数字、步进 n 的倍数（斜杠星 n）、区间 a-b、逗号列表。
 * day-of-week：0=周日..6=周六（日历对齐，DAY_OF_WEEK-1）。
 * 第二幕 time_cron：WorkManager 15min 周期触发时用 matches 判断当前时间是否命中。
 */
public class CronParser {

    /**
     * 当前时间是否匹配 cron。
     * @return false（空/非法表达式、不匹配）
     */
    public static boolean matches(String cron, long nowMs) {
        String[] parts = fields(cron);
        if (parts == null) return false;
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(nowMs);
        int min = c.get(Calendar.MINUTE);
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int dom = c.get(Calendar.DAY_OF_MONTH);
        int dow = c.get(Calendar.DAY_OF_WEEK) - 1;   // 1=Sun..7=Sat → 0=Sun..6=Sat
        return fieldMatch(parts[0], min) && fieldMatch(parts[1], hour)
                && fieldMatch(parts[2], dom) && fieldMatch(parts[3], dow);
    }

    /** 从 fromMs 起找下一个命中时刻（分钟精度，上限 7 天）；找不到返回 -1 */
    public static long nextFire(String cron, long fromMs) {
        long t = fromMs - (fromMs % 60000L) + 60000L;   // 下一个整分
        for (int i = 0; i < 7 * 24 * 60; i++) {
            if (matches(cron, t)) return t;
            t += 60000L;
        }
        return -1;
    }

    /** 拆 4 字段；非法（字段数≠4 或空）返回 null */
    static String[] fields(String cron) {
        if (cron == null || cron.trim().isEmpty()) return null;
        String[] parts = cron.trim().split("\\s+");
        return parts.length == 4 ? parts : null;
    }

    /** 单字段匹配：星号 / 数字 / 步进 n / 区间 a-b / 逗号列表 */
    static boolean fieldMatch(String field, int value) {
        if ("*".equals(field)) return true;
        for (String part : field.split(",")) {
            if (part.startsWith("*/")) {
                try {
                    int step = Integer.parseInt(part.substring(2));
                    if (step > 0 && value % step == 0) return true;
                } catch (Exception e) { /* 非法 step 忽略 */ }
            } else if (part.contains("-")) {
                try {
                    String[] r = part.split("-");
                    int lo = Integer.parseInt(r[0].trim());
                    int hi = Integer.parseInt(r[1].trim());
                    if (value >= lo && value <= hi) return true;
                } catch (Exception e) { /* 非法区间忽略 */ }
            } else {
                try {
                    if (Integer.parseInt(part.trim()) == value) return true;
                } catch (Exception e) { /* 非法数字忽略 */ }
            }
        }
        return false;
    }
}
