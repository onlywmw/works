package com.hermes.android.a2a;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * A2A 传输层 — register/pair/send/poll, OkHttp 异步, token 存 EncryptedSharedPreferences.
 *
 * 接口合同以 docs/DESIGN_A2A.md §协议 v0.1 冻结为准, P1 买家侧复用本类不变。
 */
public class A2aClient {
    private static final String TAG = "A2aClient";
    static final String DEFAULT_BASE_URL = "https://mow.kim"; // TLS (Caddy+Let's Encrypt, relay→8080)
    private static final String PREFS_NAME = "a2a_prefs";
    private static final String KEY_TOKEN = "device_token";
    private static final String KEY_DEVICE_ID = "device_id";
    private static final String KEY_BASE_URL = "relay_base_url";   // 设置页 A2A 区块可编辑
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    /**
     * 存储抽象（仿 McpServerStore.Prefs）：Android 侧包 EncryptedSharedPreferences，
     * 单测侧注入内存 fake。多身份（工单26 M0-2）：key 按 deviceId 加前缀，
     * 双身份各自 token 独立互不串。
     */
    public interface TokenStore {
        String get(String key, String def);
        void put(String key, String value);
    }

    /** Android 生产实现：EncryptedSharedPreferences（BUG-7 纪律：不降级明文） */
    private static class EspStore implements TokenStore {
        private final SharedPreferences sp;
        EspStore(Context ctx) {
            this.sp = openEncryptedPrefs(ctx);
        }
        @Override public String get(String key, String def) { return sp.getString(key, def); }
        @Override public void put(String key, String value) { sp.edit().putString(key, value).apply(); }
    }

    private final OkHttpClient http;
    private final TokenStore store;
    private String keyPrefix = "";   // 多身份: deviceId + ":"；单身份(旧行为): ""
    private String deviceId;
    private String token;

    /* ── 数据类 ── */
    public static class Peer {
        public String deviceId;
        public String name;
    }

    public static class Msg {
        public long id;
        public String fromId;
        public String type;
        public JSONObject payload;
    }

    /* ── 构造 ── */
    public A2aClient(Context context) {
        this(new EspStore(context), null);
    }

    /** 多身份构造（工单26 M0-2）：指定 deviceId → token 存 deviceId 前缀 key，互不串 */
    public A2aClient(Context context, String deviceId) {
        this(new EspStore(context), deviceId);
    }

    /** 测试注入构造：fake TokenStore（零 Android 依赖、零网络） */
    A2aClient(TokenStore store, String deviceId) {
        this.http = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .build();
        this.store = store;
        this.deviceId = deviceId;
        if (deviceId != null && !deviceId.isEmpty()) {
            this.keyPrefix = deviceId + ":";
            this.token = store.get(keyPrefix + KEY_TOKEN, null);
        } else {
            // 旧单身份行为：读默认 key 的 device_id + token
            this.token = store.get(KEY_TOKEN, null);
            this.deviceId = store.get(KEY_DEVICE_ID, null);
        }
    }

    /* ── Relay 服务器地址（可配置；设置页 A2A 区块编辑，空则默认） ── */

    /** 当前 relay 地址（读 prefs，空回退默认；空串/非法 URL 由 setBaseUrl 拦截） */
    public String baseUrl() {
        String u = store.get(KEY_BASE_URL, "");
        return (u != null && !u.trim().isEmpty()) ? u.trim() : DEFAULT_BASE_URL;
    }

    /** 设置 relay 地址：空串=恢复默认；非 http(s) 前缀=非法拒绝写入 */
    public void setBaseUrl(String url) {
        String t = (url == null) ? "" : url.trim();
        if (!t.isEmpty() && !t.startsWith("http://") && !t.startsWith("https://")) return;
        store.put(KEY_BASE_URL, t);
    }

    private static SharedPreferences openEncryptedPrefs(Context ctx) {
        try {
            MasterKey mk = new MasterKey.Builder(ctx)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build();
            return EncryptedSharedPreferences.create(ctx, PREFS_NAME, mk,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
        } catch (Exception e) {
            // BUG-7 纪律: 不降级明文, 抛异常让调用方决定
            throw new RuntimeException("A2A 加密存储不可用", e);
        }
    }

    public String getDeviceId() { return deviceId; }
    public String getToken()    { return token; }
    public boolean isRegistered() { return token != null && !token.isEmpty(); }

    /* ── 1. register ── */

    /** 注册 payload 构造（纯 JVM 可测）：缺省 role=buyer，无 professions 不加字段（兼容旧调用点） */
    public static JSONObject buildRegisterPayload(String deviceId, String name, String role, JSONArray professions) {
        JSONObject body = new JSONObject();
        try {
            body.put("device_id", deviceId != null ? deviceId : "");
            body.put("name", name != null ? name : "");
            body.put("role", role != null ? role : "buyer");   // 职业注册表：缺省 buyer
            if (professions != null && professions.length() > 0) body.put("professions", professions);
        } catch (Exception e) {
            throw new RuntimeException("buildRegisterPayload", e);
        }
        return body;
    }

    public void register(String deviceId, String name, Callback<String> cb) {
        register(deviceId, name, null, null, cb);   // 缺省兼容：role=buyer，无 professions
    }

    /** 职业注册表注册：role（buyer|pro）+ professions（工种数组），缺省兼容 */
    public void register(String deviceId, String name, String role, JSONArray professions, Callback<String> cb) {
        this.deviceId = deviceId;
        this.keyPrefix = (deviceId == null || deviceId.isEmpty()) ? "" : deviceId + ":";
        this.token = store.get(keyPrefix + KEY_TOKEN, null);   // 已注册过 → 直接复用本地 token
        try {
            JSONObject body = buildRegisterPayload(deviceId, name, role, professions);
            post("/register", body, (ok, resp) -> {
                if (ok) {
                    String t = resp.optString("token", "");
                    if (!t.isEmpty()) {
                        token = t;
                        saveRegistration(deviceId, t);
                        cb.onSuccess(t);
                    } else {
                        cb.onFailure(new IOException("register: 无 token"));
                    }
                } else {
                    cb.onFailure(new IOException("register failed: " + resp));
                }
            });
        } catch (Exception e) {
            cb.onFailure(new IOException("register error", e));
        }
    }

    /** 注册成功后落 token（按身份前缀 key；测试可直接调此方法验证多身份隔离） */
    void saveRegistration(String deviceId, String token) {
        String p = (deviceId == null || deviceId.isEmpty()) ? "" : deviceId + ":";
        store.put(p + KEY_TOKEN, token);
        store.put(p + KEY_DEVICE_ID, deviceId);
    }

    /* ── 1.5 query_pro（职业注册表附近发现） ── */

    /** query_pro 参数构造（纯 JVM 可测）：craft 可选、radiusKm/online 必填 */
    public static JSONObject buildQueryProPayload(String craft, int radiusKm, boolean online) {
        JSONObject body = new JSONObject();
        try {
            if (craft != null && !craft.isEmpty()) body.put("craft", craft);
            body.put("radius_km", radiusKm);
            body.put("online", online);
        } catch (Exception e) {
            throw new RuntimeException("buildQueryProPayload", e);
        }
        return body;
    }

    /** query_pro 响应解析（纯 JVM 可测）：relay 返回 {devices:[{device_id,name,...}]} → List<Peer> */
    public static java.util.List<Peer> parseDevices(JSONObject resp) {
        java.util.List<Peer> out = new java.util.ArrayList<>();
        JSONArray arr = resp != null ? resp.optJSONArray("devices") : null;
        if (arr == null) return out;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            Peer p = new Peer();
            p.deviceId = o.optString("device_id", o.optString("deviceId", ""));
            p.name = o.optString("name", "");
            out.add(p);
        }
        return out;
    }

    /** 附近职业人发现（relay query_pro，cbId 异步）：按 craft + radiusKm + online 查 */
    public void queryPro(String craft, int radiusKm, boolean online, Callback<java.util.List<Peer>> cb) {
        try {
            JSONObject body = buildQueryProPayload(craft, radiusKm, online);
            post("/query_pro", body, (ok, resp) -> {
                if (ok) cb.onSuccess(parseDevices(resp));
                else cb.onFailure(new IOException("query_pro failed: " + resp));
            });
        } catch (Exception e) {
            cb.onFailure(new IOException("query_pro error", e));
        }
    }

    /* ── 2. pairRequest ── */
    public void pairRequest(Callback<String> cb) {
        try {
            JSONObject body = new JSONObject().put("device_id", deviceId);
            post("/pair/request", body, (ok, resp) -> {
                if (ok) {
                    String code = resp.optString("pair_code", "");
                    cb.onSuccess(code);
                } else {
                    cb.onFailure(new IOException("pairRequest failed: " + resp));
                }
            });
        } catch (Exception e) {
            cb.onFailure(new IOException("pairRequest error", e));
        }
    }

    /* ── 3. pairAccept ── */
    public void pairAccept(String pairCode, Callback<Peer> cb) {
        try {
            JSONObject body = new JSONObject();
            body.put("device_id", deviceId);
            body.put("pair_code", pairCode);
            post("/pair/accept", body, (ok, resp) -> {
                if (ok) {
                    Peer p = new Peer();
                    // relay 返回 peer_id/peer_name, 兼容 device_id/name
                    p.deviceId = optFirst(resp, "peer_id", "device_id");
                    p.name = optFirst(resp, "peer_name", "name");
                    cb.onSuccess(p);
                } else {
                    cb.onFailure(new IOException("pairAccept failed: " + resp));
                }
            });
        } catch (Exception e) {
            cb.onFailure(new IOException("pairAccept error", e));
        }
    }

    /* ── 4. peers ── */
    public void peers(Callback<List<Peer>> cb) {
        try {
            get("/peers?device_id=" + deviceId, (ok, resp) -> {
                if (ok) {
                    List<Peer> list = new ArrayList<>();
                    JSONArray arr = resp.optJSONArray("peers");
                    if (arr != null) {
                        for (int i = 0; i < arr.length(); i++) {
                            try {
                                JSONObject o = arr.getJSONObject(i);
                                Peer p = new Peer();
                                p.deviceId = optFirst(o, "peer_id", "device_id");
                                p.name = optFirst(o, "peer_name", "name");
                                list.add(p);
                            } catch (Exception ignored) {}
                        }
                    }
                    cb.onSuccess(list);
                } else {
                    cb.onFailure(new IOException("peers failed: " + resp));
                }
            });
        } catch (Exception e) {
            cb.onFailure(new IOException("peers error", e));
        }
    }

    /* ── 5. send ── */
    public void send(String toId, String type, JSONObject payload,
                     Callback<Long> cb) {
        try {
            JSONObject body = new JSONObject();
            body.put("from_id", deviceId);
            body.put("to_id", toId);
            body.put("type", type);
            body.put("payload", payload != null ? payload : new JSONObject());
            post("/msg", body, (ok, resp) -> {
                if (ok) {
                    long id = resp.optLong("msg_id", -1);
                    cb.onSuccess(id);
                } else {
                    cb.onFailure(new IOException("send failed: " + resp));
                }
            });
        } catch (Exception e) {
            cb.onFailure(new IOException("send error", e));
        }
    }

    /* ── 6. poll ── */
    public void poll(long afterId, Callback<List<Msg>> cb) {
        try {
            String url = "/poll?device_id=" + deviceId + "&after_id=" + afterId + "&limit=50";
            get(url, (ok, resp) -> {
                if (ok) {
                    List<Msg> list = new ArrayList<>();
                    JSONArray arr = resp.optJSONArray("messages");
                    if (arr != null) {
                        for (int i = 0; i < arr.length(); i++) {
                            try {
                                JSONObject o = arr.getJSONObject(i);
                                Msg m = new Msg();
                                m.id = o.optLong("id", 0);
                                m.fromId = o.optString("from_id", "");
                                m.type = o.optString("type", "");
                                m.payload = o.optJSONObject("payload");
                                list.add(m);
                            } catch (Exception ignored) {}
                        }
                    }
                    cb.onSuccess(list);
                } else {
                    cb.onFailure(new IOException("poll failed: " + resp));
                }
            });
        } catch (Exception e) {
            cb.onFailure(new IOException("poll error", e));
        }
    }

    /* ── 轮询 (5s Handler, 前台启后台停) ── */
    private Handler pollHandler;
    private Runnable pollRunnable;
    private long lastPollId = 0;
    private PollListener pollListener;

    public interface PollListener {
        void onMessages(List<Msg> messages);
    }

    public void startPolling(PollListener listener) {
        this.pollListener = listener;
        this.pollHandler = new Handler(Looper.getMainLooper());
        this.pollRunnable = new Runnable() {
            @Override public void run() {
                if (pollListener == null) return;
                poll(lastPollId, new Callback<List<Msg>>() {
                    @Override public void onSuccess(List<Msg> msgs) {
                        if (msgs != null && !msgs.isEmpty()) {
                            for (Msg m : msgs) {
                                if (m.id > lastPollId) lastPollId = m.id;
                            }
                            pollListener.onMessages(msgs);
                        }
                        if (pollHandler != null) {
                            pollHandler.postDelayed(pollRunnable, 5000);
                        }
                    }
                    @Override public void onFailure(IOException e) {
                        Log.w(TAG, "poll error: " + e.getMessage());
                        if (pollHandler != null) {
                            pollHandler.postDelayed(pollRunnable, 5000);
                        }
                    }
                });
            }
        };
        pollHandler.post(pollRunnable);
    }

    public void stopPolling() {
        pollListener = null;
        if (pollHandler != null) {
            pollHandler.removeCallbacks(pollRunnable);
            pollHandler = null;
        }
    }

    /* ── HTTP helpers ── */

    private void post(String path, JSONObject body, HttpCb cb) {
        RequestBody rb = RequestBody.create(body.toString(), JSON);
        Request req = new Request.Builder()
                .url(baseUrl() + path)
                .header("X-Device-Token", token != null ? token : "")
                .post(rb).build();
        enqueue(req, cb);
    }

    private void get(String path, HttpCb cb) {
        Request req = new Request.Builder()
                .url(baseUrl() + path)
                .header("X-Device-Token", token != null ? token : "")
                .get().build();
        enqueue(req, cb);
    }

    private void enqueue(Request req, HttpCb cb) {
        http.newCall(req).enqueue(new okhttp3.Callback() {
            @Override public void onFailure(Call call, IOException e) {
                Log.w(TAG, req.method() + " " + req.url() + " → " + e.getMessage());
                cb.done(false, new JSONObject());
            }
            @Override public void onResponse(Call call, Response response) throws IOException {
                try {
                    String body = response.body() != null ? response.body().string() : "{}";
                    JSONObject json = new JSONObject(body);
                    boolean ok = response.isSuccessful();
                    if (!ok) Log.w(TAG, req.method() + " " + req.url()
                            + " → " + response.code() + " " + body);
                    cb.done(ok, json);
                } catch (Exception e) {
                    Log.w(TAG, req.method() + " " + req.url() + " parse err: " + e.getMessage());
                    cb.done(false, new JSONObject());
                } finally {
                    response.close();
                }
            }
        });
    }

    private interface HttpCb {
        void done(boolean ok, JSONObject resp);
    }

    /** 双键兼容: 先试 key1, 没有则 key2, 都没有返空串 */
    private static String optFirst(JSONObject o, String key1, String key2) {
        String v = o.optString(key1, null);
        return (v != null && !v.isEmpty()) ? v : o.optString(key2, "");
    }

    /* ── 结果包装 ── */

    /** 回调接口 (自包含, 不依赖外部库) */
    public interface Callback<T> {
        void onSuccess(T data);
        void onFailure(IOException error);
    }
}
