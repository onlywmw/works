package com.hermes.android.security;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * S2 PII 打码器（安全 P0，双副本核心件，纯 JVM 可单测）。
 * 身份证/银行卡/手机号/姓名泛化 → [证件号]/[卡号]/[手机号]/[姓名]。
 * 召回率优先（宁误杀不放过）；删除非遮蔽（识别结果副本打码后原样丢弃，不可复原）。
 * 规则表数据驱动（后续好扩）。
 */
public class PiiMasker {

    /* 技术债治理（工单5）：身份证/银行卡/手机号识别收敛到 PiiPatterns 单一来源，边界策略保本组件收紧。 */
    private static final Pattern IDCARD = PiiPatterns.ID_CARD_18;      // 18 位身份证（前后数字边界，防 19 位卡子串命中）
    private static final Pattern BANKCARD = PiiPatterns.BANK_CARD_16_19; // 16-19 位银行卡（前后数字边界）
    private static final Pattern PHONE = PiiPatterns.PHONE_CORE;         // 11 位手机号
    private static final Pattern NAME = Pattern.compile("(叫|姓名[:：]?|我是|他是|她是|收货人[:：]?)([\\u4e00-\\u9fa5]{2,3})");

    /** 打码：识别结果 → 无 PII 文本（三证号型 + 姓名泛化） */
    public static String mask(String text) {
        if (text == null) return null;
        String t = text;
        t = IDCARD.matcher(t).replaceAll("[证件号]");      // 18 位精确（含 X）优先
        t = BANKCARD.matcher(t).replaceAll("[卡号]");       // 其余 16-19 位纯数字卡号
        t = PHONE.matcher(t).replaceAll("[手机号]");
        t = maskNames(t);
        return t;
    }

    /** 姓名启发式：上下文（叫/我是/姓名：/收货人：）后 2-3 个中文字 → [姓名]；召回优先宁误杀 */
    private static String maskNames(String text) {
        Matcher m = NAME.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            m.appendReplacement(sb, Matcher.quoteReplacement(m.group(1) + "[姓名]"));
        }
        m.appendTail(sb);
        return sb.toString();
    }
}
