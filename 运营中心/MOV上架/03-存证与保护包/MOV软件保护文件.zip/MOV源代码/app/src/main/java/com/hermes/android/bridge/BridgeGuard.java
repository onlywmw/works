package com.hermes.android.bridge;

import android.util.Log;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * BridgeGuard — JS 参数统一校验 (ARCH_DEBT #2)。
 *
 * 边界: check() 只校验首个 json 参数。多数桥方法是单参 (String json);
 * 少数多参方法（如带 callback id）只校验第一个业务参数。
 * ALLOW_EMPTY 白名单放行 ping/getVersion 等空参方法。
 */
public class BridgeGuard {

    private static final String TAG = "BridgeGuard";

    /** 允许空参的方法（如 ping/getVersion 这类查询类方法） */
    private static final Set<String> ALLOW_EMPTY = new HashSet<>(Arrays.asList(
            "ping", "getVersion", "agentState", "tokenStats"
    ));

    /**
     * 校验首个 json 参数。null = 通过，否则返回错误 JSON 字符串，调用方直接 return。
     * 仅校验以 { 或 [ 开头的参数（跳过纯文本/URL/命令等非 JSON 入参）。
     */
    public static String check(String method, String json) {
        if (json == null || json.isEmpty()) {
            if (ALLOW_EMPTY.contains(method)) return null;
            return err(method, "EMPTY_PARAM", "参数为空");
        }
        String t = json.trim();
        if (!t.startsWith("{") && !t.startsWith("[")) return null; // 非 JSON，放行
        try {
            new JSONObject(t);
        } catch (Exception e) {
            if (t.startsWith("[")) {
                try { new org.json.JSONArray(t); return null; } catch (Exception e2) {}
            }
            Log.w(TAG, method + ": BAD_JSON " + e.getMessage());
            return err(method, "BAD_JSON", "JSON 格式错误");
        }
        return null;
    }

    private static String err(String method, String code, String msg) {
        Log.w(TAG, method + ": " + code + " " + msg);
        return "{\"ok\":false,\"error\":{\"code\":\"" + code + "\",\"msg\":\"" + msg + "\"}}";
    }
}
