package com.hermes.android.bridge;

import android.webkit.JavascriptInterface;

import java.io.File;
import java.util.concurrent.TimeUnit;

import com.hermes.android.HermesActivity;

import com.hermes.android.llama.LlamaClient;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * llama-server 本地 API 客户端壳（第二件）——OpenAI 兼容，cbId 异步（禁同步桥红线）。
 * 契约：POST 127.0.0.1:8080/v1/chat/completions，Bearer token（设置页大脑区块配置）。
 * server 未起/连接失败/鉴权失败 → 诚实卡（mapError 文案），不假识别。
 * 懒启动请求接口预留：P4 交付 llama-server 后此处即对联。
 */
public class OcrApiBridge extends BaseBridge {

    public static final String PREFS = "llama_prefs";
    public static final String KEY_TOKEN = "token";

    private final OkHttpClient http;

    public OcrApiBridge(HermesActivity activity) {
        super(activity);
        this.http = new OkHttpClient.Builder()
                .connectTimeout(3, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build();
    }

    /** llama-server 调用（cbId 异步）：成功 → {ok:true, content}；失败/未配置 → 诚实卡 */
    @JavascriptInterface
    public void ocrChat(String text, String cbId) {
        // 工单12 幕四: token 走 LlamaServerManager.token(唯一生成点, 不存在则生成落盘, 仿 HermesServeConfig)——
        // 不再直接读裸 prefs(llama_prefs 旧键与 llama-server 启动用 llama_serve_prefs 不一致)
        String token = com.hermes.android.llama.LlamaServerManager.token(activity);
        if (token == null || token.isEmpty()) {
            evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":\"OCR token 生成失败\"})");
            return;
        }
        try {
            Request req = new Request.Builder()
                    .url(LlamaClient.BASE_URL + "/v1/chat/completions")
                    .header("Authorization", "Bearer " + token)
                    .post(RequestBody.create(MediaType.get("application/json; charset=utf-8"),
                            LlamaClient.buildChatPayload(null, text, 256)))
                    .build();
            http.newCall(req).enqueue(new Callback() {
                @Override public void onFailure(Call c, java.io.IOException e) {
                    respond(cbId, false, LlamaClient.mapError(-1, null), null);
                }
                @Override public void onResponse(Call c, Response resp) {
                    try {
                        String body = resp.body() != null ? resp.body().string() : "";
                        String content = LlamaClient.parseResponse(body);
                        if (content != null) {
                            respond(cbId, true, null, content);
                        } else {
                            respond(cbId, false, LlamaClient.mapError(resp.code(), body), null);
                        }
                    } catch (Exception e) {
                        respond(cbId, false, "OCR 响应解析失败", null);
                    }
                }
            });
        } catch (Exception e) {
            respond(cbId, false, "OCR 请求异常", null);
        }
    }

    /** 本地模型列表（filesDir/models/unlimited-ocr/，版本隔离）：{ok, models:[{name,sizeMB,version}]} */
    @JavascriptInterface
    public String listLocalModels() {
        try {
            org.json.JSONArray arr = new org.json.JSONArray();
            File dir = new File(activity.getFilesDir(), "models/unlimited-ocr");
            if (dir.isDirectory()) {
                File[] files = dir.listFiles();
                if (files != null) {
                    for (File f : files) {
                        if (f.isFile()) {
                            arr.put(new org.json.JSONObject()
                                    .put("name", f.getName())
                                    .put("sizeMB", f.length() / 1048576L)
                                    .put("version", inferVersion(f.getName())));
                        }
                    }
                }
            }
            return new org.json.JSONObject().put("ok", true).put("models", arr).toString();
        } catch (Exception e) {
            return "{\"ok\":false,\"error\":\"list models failed\"}";
        }
    }

    /** 删除本地模型文件 */
    @JavascriptInterface
    public String deleteLocalModel(String name) {
        try {
            if (name == null || name.isEmpty() || name.contains("/") || name.contains("..")) {
                return "{\"ok\":false,\"error\":\"非法文件名\"}";
            }
            File f = new File(new File(activity.getFilesDir(), "models/unlimited-ocr"), name);
            if (f.exists() && f.isFile() && f.delete()) return "{\"ok\":true}";
            return "{\"ok\":false,\"error\":\"删除失败或文件不存在\"}";
        } catch (Exception e) {
            return "{\"ok\":false}";
        }
    }

    /** 从模型文件名推断版本片段（q4/int4/3b）——DESIGN v2 版本隔离 */
    private static String inferVersion(String name) {
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(q\\d|int\\d|\\d+b)").matcher(name.toLowerCase());
        return m.find() ? m.group(1) : "unknown";
    }

    private void respond(String cbId, boolean ok, String error, String content) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"ok\":").append(ok);
        if (error != null) sb.append(",\"error\":").append(org.json.JSONObject.quote(error));
        if (content != null) sb.append(",\"content\":").append(org.json.JSONObject.quote(content));
        sb.append("}");
        evalJs("window._hermesCb('" + cbId + "'," + sb + ")");
    }
}
