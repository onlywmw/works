package com.hermes.android.security;

import java.util.regex.Pattern;

/**
 * 共享 PII 识别 Pattern（技术债治理 工单5，审计 AUDIT_PRIVACY_CAUSAL_LINK §3）：
 * PiiMasker（保险柜副本净化）与 PiiScrubber（出网前哨）曾各自定义身份证/银行卡/手机号正则，
 * 重复且易漂移。此处收敛为**识别规则单一来源**，两个组件引用 + 按各自边界策略组合。
 *
 * 职责边界（不合并组件）：
 *  - PiiMasker（security）：保险柜副本打码，删除非遮蔽——边界收紧（只认 18 位身份证 / 16-19 卡 / 无边界手机号），宁误杀不误放。
 *  - PiiScrubber（causal）：文本出设备前最后关口——边界放宽（15 位身份证 / 13 位卡 / 手机号加数字边界），宁打码多不漏。
 *  识别核心（位数/字符集）共享本类，边界差异在各自组合里体现。
 */
public final class PiiPatterns {

    private PiiPatterns() {}

    /** 18 位身份证（含尾位 X，前后数字边界，防 19 位卡子串命中）——两个组件共用。 */
    public static final Pattern ID_CARD_18 =
            Pattern.compile("(?<!\\d)\\d{17}[\\dXx](?!\\d)");

    /** 银行卡 16-19 位（前后数字边界）——共享识别；PiiScrubber 另有 13-15 位扩展。 */
    public static final Pattern BANK_CARD_16_19 =
            Pattern.compile("(?<!\\d)\\d{16,19}(?!\\d)");

    /** 手机号核心 11 位（无边界）——PiiMasker 直接用；PiiScrubber 叠加数字边界。 */
    public static final Pattern PHONE_CORE =
            Pattern.compile("1[3-9]\\d{9}");
}
