package com.hermes.android.causal;

import com.hermes.android.agent.Journal;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 脱敏叙事合成（DESIGN_CAUSAL_APIFACT §二）：从 CausalEngine 合成一段紧凑脱敏叙事，供云端因果分析。
 * 隐私红线：实体→实体A/B/C（按出现顺序），金额→一笔款项，日期→相对表述，绝不输出真实姓名/数字金额/原文。
 * 谓词/关系保留语义（分析价值所在，与身份无关）。纯 Java，零 android 依赖。
 */
public class NarrativeBuilder {

    /** 从 CausalEngine 合成脱敏叙事（≤10 行）。无数据/异常返回 ""。 */
    public static String narrate(CausalEngine engine, String room) {
        if (engine == null) return "";
        try {
            JSONObject q = engine.query(room, 10);
            JSONArray links = q.optJSONArray("links");
            if (links == null || links.length() == 0) return "";
            // 实体编号：label → 实体A/B/C（按出现顺序，去重）
            java.util.Map<String, String> ent = new java.util.LinkedHashMap<>();
            int idx = 0;
            for (int i = 0; i < links.length(); i++) {
                JSONObject l = links.optJSONObject(i);
                String a = l.optString("a"), b = l.optString("b");
                if (!ent.containsKey(a)) ent.put(a, "实体" + (char) ('A' + Math.min(idx++, 25)));
                if (!ent.containsKey(b)) ent.put(b, "实体" + (char) ('A' + Math.min(idx++, 25)));
            }
            // 事件统计：meta.outcome=negative + 谓词频次（journal eventsOfType 扫描，不动引擎核心）
            JSONArray events = engine.journal().eventsOfType(room, Journal.TYPE_CAUSAL_EVENT);
            int negative = 0, total = 0;
            java.util.Map<String, Integer> pred = new java.util.HashMap<>();
            for (int i = 0; i < events.length(); i++) {
                JSONObject ev = events.optJSONObject(i);
                JSONObject p = ev != null ? ev.optJSONObject("payload") : null;
                if (p == null) continue;
                total++;
                JSONObject meta = p.optJSONObject("meta");
                if (meta != null && "negative".equals(meta.optString("outcome"))) negative++;
                String pr = p.optString("predicate", "");
                if (!pr.isEmpty()) pred.merge(pr, 1, Integer::sum);
            }
            // 叙事拼接（≤10 行）
            StringBuilder sb = new StringBuilder("（脱敏因果叙事）\n");
            for (int i = 0; i < links.length(); i++) {
                JSONObject l = links.optJSONObject(i);
                String a = ent.get(l.optString("a")), b = ent.get(l.optString("b"));
                int st = (int) Math.round(l.optDouble("strength", 0) * 100);
                sb.append("- ").append(a).append(" 与 ").append(b)
                        .append(" 有往来关联（强度 ").append(st).append("%）\n");
                if (sb.toString().split("\n").length >= 9) break;   // ≤10 行
            }
            if (total > 0) {
                sb.append("- 近期共 ").append(total).append(" 条因果事件，其中 ")
                        .append(negative).append(" 条负面结果（如逾期/冲突）\n");
            }
            java.util.List<java.util.Map.Entry<String, Integer>> top =
                    new java.util.ArrayList<>(pred.entrySet());
            top.sort((x, y) -> Integer.compare(y.getValue(), x.getValue()));
            // 谓词是用户自由文本，可能夹带手机号/金额/邮箱等（隐私审计 2026-08-05）→ 拼接前打码
            if (!top.isEmpty()) {
                sb.append("- 高频关系类型：");
                for (int i = 0; i < Math.min(3, top.size()); i++) {
                    if (i > 0) sb.append("、");
                    sb.append(PiiScrubber.scrub(top.get(i).getKey()));
                }
                sb.append("\n");
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }
}
