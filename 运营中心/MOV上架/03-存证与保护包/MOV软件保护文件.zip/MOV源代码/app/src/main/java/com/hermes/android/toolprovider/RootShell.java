package com.hermes.android.toolprovider;

/**
 * 工单10: RootShell — KernelSU root 执行封装(uid=0 已授权)。
 * 命令构造/isDenied 为纯函数(单测零 root); 执行经 `su -c` + 超时。
 * 红线黑名单硬编码(工具层拦截, 模型不可绕过): 支付/短信/通讯录/通话记录。
 */
public final class RootShell {

    /** 硬编码红线黑名单(支付/短信/通讯录/通话记录相关包名, 含匹配) */
    public static final String[] DENIED_PACKAGES = {
            "com.alipay", "com.eg.android.AlipayGphone", "com.tencent.mm", "com.unionpay",
            "com.android.mms", "com.android.contacts", "com.android.dialer",
            "com.google.android.dialer", "com.tencent.mobileqq",
    };
    /** 硬编码红线黑名单(支付/短信/通讯录/通话记录相关 action, 精确匹配) */
    public static final String[] DENIED_ACTIONS = {
            "android.intent.action.CALL", "android.intent.action.DIAL",
            "android.intent.action.SENDTO",
    };

    /** 黑名单命中检测(纯函数): 包名(含匹配)/action(精确匹配) 命中 → true(拒)。 */
    public static boolean isDenied(String packageName, String action) {
        if (packageName != null) {
            for (String p : DENIED_PACKAGES) if (packageName.contains(p)) return true;
        }
        if (action != null) {
            for (String a : DENIED_ACTIONS) if (a.equals(action)) return true;
        }
        return false;
    }

    /** 命令构造(纯函数, 可测): su -c "cmd"。 */
    public static String buildCommand(String cmd) {
        return "su -c \"" + (cmd == null ? "" : cmd.replace("\"", "\\\"")) + "\"";
    }

    /** 执行(root 环境, 超时); 返回 "exit=N\n<stdout+stderr>" 或错误。 */
    public static String exec(String cmd, int timeoutSec) {
        String c = cmd == null ? "" : cmd;
        try {
            Process p = new ProcessBuilder("su", "-c", c).start();
            StringBuilder out = new StringBuilder();
            Thread reader = new Thread(() -> {
                try (java.io.BufferedReader r = new java.io.BufferedReader(
                        new java.io.InputStreamReader(p.getInputStream()))) {
                    String l;
                    while ((l = r.readLine()) != null) out.append(l).append('\n');
                } catch (Exception ignored) {}
            });
            reader.start();
            StringBuilder err = new StringBuilder();
            Thread errReader = new Thread(() -> {
                try (java.io.BufferedReader r = new java.io.BufferedReader(
                        new java.io.InputStreamReader(p.getErrorStream()))) {
                    String l;
                    while ((l = r.readLine()) != null) err.append(l).append('\n');
                } catch (Exception ignored) {}
            });
            errReader.start();
            java.util.concurrent.ExecutorService ex =
                    java.util.concurrent.Executors.newSingleThreadExecutor();
            try {
                java.util.concurrent.Future<?> fut = ex.submit(() -> {
                    try { p.waitFor(); } catch (Exception ignored) {}
                });
                fut.get(timeoutSec > 0 ? timeoutSec : 30, java.util.concurrent.TimeUnit.SECONDS);
            } catch (Exception ex2) {
                p.destroy();
                return "exit=-1\nroot 执行超时(" + timeoutSec + "s)";
            } finally {
                ex.shutdownNow();
            }
            reader.join(2000);
            errReader.join(2000);
            String text = out.toString().trim();
            String errT = err.toString().trim();
            if (!errT.isEmpty()) text = text.isEmpty() ? errT : text + "\n" + errT;
            return "exit=" + p.exitValue() + "\n" + text;
        } catch (Exception ex3) {
            return "exit=-1\nroot 执行失败: " + ex3.getMessage();
        }
    }

    private RootShell() {}
}
