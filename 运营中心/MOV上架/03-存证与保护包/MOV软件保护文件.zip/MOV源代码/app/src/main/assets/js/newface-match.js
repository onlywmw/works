/* ============================================================
   newface-match.js — 模糊匹配纯逻辑（无 DOM，node 可单测）
   追剧/A2A 菜名匹配 fuzzyScore（W1 清欠，从 newface.js 抽出真代码）。
   浏览器: window.NewFaceMatch / Node: module.exports
   ============================================================ */
(function(root, factory) {
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    root.NewFaceMatch = api;
  }
})(typeof window !== 'undefined' ? window : this, function() {

  /**
   * 模糊分数 0~1：完全匹配=1.0 / 包含=0.85 / 字符级（共同字符/字长）。
   * @param {string} dish 目标（如菜名）
   * @param {string} itemName 候选
   */
  function fuzzyScore(dish, itemName) {
    var d = String(dish || '').toLowerCase().replace(/\s/g, '');
    var n = String(itemName || '').toLowerCase().replace(/\s/g, '');
    if (!d || !n) return 0;   // 空目标/候选无意义匹配（空串 indexOf 恒 0）
    if (d === n) return 1.0;
    if (n.indexOf(d) >= 0 || d.indexOf(n) >= 0) return 0.85;
    // 中文字符级匹配: 共同字符 / max(字长)
    var common = 0;
    for (var i = 0; i < d.length; i++) {
      if (n.indexOf(d.charAt(i)) >= 0) common++;
    }
    var charScore = common / Math.max(d.length, n.length);
    if (charScore >= 0.6) return 0.5 + charScore * 0.3;
    return charScore >= 0.4 ? 0.45 : 0;
  }

  /**
   * 候选卡标签（W1 清欠）：第 0 位（分数最高）→ 🏆 最佳匹配；score>0.7 → ✨ 推荐；否则空。
   * @param {number} index 排序后位置（0 起）
   * @param {number} score 模糊分数 0~1
   */
  function badgeFor(index, score) {
    if (index === 0) return '🏆 最佳匹配';
    if (score > 0.7) return '✨ 推荐';
    return '';
  }

  /**
   * 随机抽评抽签（W1 第二幕）：hash(orderId + 日期盐) → 0~99，< 40 抽中评价卡。
   * 确定性（同 order 同日期结果一致）/ 可验证（纯函数）/ 不可预测（djb2 哈希）。
   * @param {string} orderId 订单号
   * @param {string} dateSalt 当日日期盐（YYYY-MM-DD）
   * @returns {boolean} 是否抽中（约 40%）
   */
  function reviewDrawn(orderId, dateSalt) {
    var seed = String(orderId || '') + '|' + String(dateSalt || '');
    var h = 0;
    for (var i = 0; i < seed.length; i++) {
      h = ((h << 5) - h + seed.charCodeAt(i)) | 0;   // djb2
    }
    return (Math.abs(h) % 100) < 40;
  }

  return { fuzzyScore: fuzzyScore, badgeFor: badgeFor, reviewDrawn: reviewDrawn };
});
