/* ============================================================
   newface-delivery.js — 交付卡数据提取（纯逻辑，无 DOM）
   FUSION F5: 慢脑 AgentLoop deliver 事件 → newface 交付卡。
   抽成独立模块便于 node 单测（app/src/test/js/newface-delivery.test.js）。
   浏览器: window.NewFaceDelivery / Node: module.exports
   ============================================================ */
(function(root, factory) {
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    root.NewFaceDelivery = api;
  }
})(typeof window !== 'undefined' ? window : this, function() {

  /** 截断摘要（卡片单行显示，超长省略） */
  function clip(s, maxLen) {
    if (typeof s !== 'string') return '';
    s = s.trim();
    if (s.length <= maxLen) return s;
    return s.slice(0, maxLen - 1) + '…';
  }

  /**
   * deliver 事件 → 交付卡数据。
   * @param {Object} ev AgentLoop deliver 事件（summary/files/goal/elapsedSec/promptTokens...）
   * @return {Object} {summary, filesN, goal}
   */
  function toCardData(ev) {
    if (!ev || typeof ev !== 'object') {
      return { summary: '', filesN: 0, goal: '' };
    }
    var files = Array.isArray(ev.files) ? ev.files : [];
    return {
      summary: clip(ev.summary, 48),
      filesN: files.length,
      goal: typeof ev.goal === 'string' ? ev.goal : ''
    };
  }

  return { toCardData: toCardData, clip: clip };
});
