package com.hermes.android;

import com.hermes.android.workflow.Workflows;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * 第二幕 boot_completed 触发器：BOOT_COMPLETED receiver（manifest 声明，boot 广播只能静态收）。
 * 按需：无启用 boot_completed workflow 时 onReceive 不 fire（零动作）。
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (intent == null || !Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        try {
            Workflows w = Workflows.get();
            if (w == null) { Workflows.init(ctx); w = Workflows.get(); }   // boot 冷启动确保 init
            if (w != null) w.source().onBoot(System.currentTimeMillis());
        } catch (Exception e) {
            Log.e("Workflow", "boot receiver error", e);
        }
    }
}
