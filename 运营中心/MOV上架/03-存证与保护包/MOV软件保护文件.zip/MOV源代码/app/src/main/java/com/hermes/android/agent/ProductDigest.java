package com.hermes.android.agent;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ProductDigest — finish summary 的「功能自检清单」解析 (纯逻辑, 可单测)。
 *
 * parseChecklist: 从 finish summary 解析「功能自检清单」(✅真实现/⚠️演示),
 * 供交付卡结构化展示。
 * (2026-07-30: 多模型评审机制移除, 原"产物内容摘要/交互元素清单"部分随评审一并删除)
 */
public class ProductDigest {

    // ==================== 功能自检清单解析 ====================

    public static class CheckItem {
        public final boolean real;      // true=✅真实现 false=⚠️演示
        public final String text;

        public CheckItem(boolean real, String text) {
            this.real = real;
            this.text = text;
        }
    }

    private static final Pattern CHECK_LINE = Pattern.compile(
            "^\\s*[-*•]?\\s*(✅|⚠️)\\s*[：:]?\\s*(.+?)\\s*$");

    /** 从 finish summary 提取自检清单行 (✅=真实现 ⚠️=演示); 无清单返回空表 */
    public static List<CheckItem> parseChecklist(String summary) {
        List<CheckItem> out = new ArrayList<>();
        if (summary == null) return out;
        for (String line : summary.split("\n")) {
            Matcher m = CHECK_LINE.matcher(line);
            if (m.find()) {
                out.add(new CheckItem("✅".equals(m.group(1)), m.group(2).trim()));
            }
        }
        return out;
    }
}
