package com.hermes.android.toolprovider;

import android.content.Context;

import com.hermes.android.StorageManager;
import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.causal.CausalEngine;
import com.hermes.android.causal.CausalEvent;
import com.hermes.android.causal.CausalOracle;
import com.hermes.android.causal.NarrativeBuilder;
import com.hermes.android.causal.PatchCompiler;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 因果记忆工具 Provider（本地因果记忆编译器，feat/causal-memory）— 薄壳，照 MemoryToolProvider 模式。
 *
 * 注册 5 个 causal.* 工具，handler 转发 {@link #engine()}（懒加载单例，基于 rooms 目录）。
 * 记忆为**全局私有数据流**（固定房间 "global"）——蓝图"手机里的私人记忆"，不按房间隔离；
 * 后续可扩展 per-room（causal.record 加 roomId 参数）。
 *
 * 唯一 Android 依赖点：init(Context) 注入 appContext + StorageManager 定位 roomsDir。
 */
public class CausalToolProvider implements ToolRegistry.ToolProvider {

    /** 全局记忆房间（蓝图：私有数据流唯一仓库） */
    public static final String ROOM = "global";

    private static Context appContext;
    private static volatile CausalEngine engine;

    public static void init(Context ctx) {
        appContext = ctx.getApplicationContext();
        engine = null;  // 重初始化时重建
    }

    /** 懒加载单例：rooms 目录（StorageManager）构造。未 init → null（handler 报 context 未初始化）。 */
    public static CausalEngine engine() {
        if (engine == null && appContext != null) {
            synchronized (CausalToolProvider.class) {
                if (engine == null && appContext != null) {
                    engine = new CausalEngine(new StorageManager(appContext).getRoomsDir());
                }
            }
        }
        return engine;
    }

    /** 测试用：临时目录注入（JVM 单测 handler roundtrip）。 */
    public static void initForTest(java.io.File roomsDir) {
        appContext = null;
        engine = new CausalEngine(roomsDir);
    }

    @Override public String id() { return "causal"; }

    @Override public List<ToolRegistry.Tool> discover() {
        List<ToolRegistry.Tool> list = new ArrayList<>();

        // ── causal.record：记录四元组事件 → 索引 + 规则命中 ──
        list.add(new ToolRegistry.Tool("causal.record", "记录一个因果事件（时间/主体/谓词/客体），"
                + "自动哈希索引并匹配逻辑钩子。meta 传 JSON（如 {\"amount\":5000,\"dueDate\":\"2025-06-01\"}）。",
                null, a -> {
            if (engine() == null) return new ToolRegistry.Result(false, "context 未初始化");
            try {
                CausalEvent ev = new CausalEvent(
                        a.optString("subject"), a.optString("predicate"), a.optString("object"),
                        a.optString("t"), a.optString("source"), parseMeta(a.optString("meta", "")));
                JSONObject r = engine().record(ROOM, ev);
                return new ToolRegistry.Result(r.optBoolean("ok", false),
                        r.optBoolean("ok", false) ? "因果事件已记录" : r.optString("error", "失败"),
                        r.toString());
            } catch (Exception e) {
                return new ToolRegistry.Result(false, "记录失败: " + e.getMessage());
            }
        }, "native", "write", "none", true, 5, "memory",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("subject", "string", true, "", "主体（如 张三）"),
                new ToolRegistry.ParamDef("predicate", "string", true, "", "谓词（如 欠款）"),
                new ToolRegistry.ParamDef("object", "string", true, "", "客体（如 李四）"),
                new ToolRegistry.ParamDef("t", "string", false, "默认写入时间", "业务时间（如 2025-06-01）"),
                new ToolRegistry.ParamDef("meta", "string", false, "JSON", "附加事实 JSON"),
                new ToolRegistry.ParamDef("source", "string", false, "ocr/manual/plan", "来源"),
            },
            "JSON: {seq, fired:[规则], alerts:[...], links:N}",
            new String[]{"记录：张三欠李四5000元6月1日还"}, null, 10000,
            new ToolRegistry.Manifest("记录因果事件", "low", "把关键事件固化为四元组记忆", true, "io", "SLOW", false, 5000), null));

        // ── causal.query：查询因果记忆概览 ──
        list.add(new ToolRegistry.Tool("causal.query", "查询因果记忆概览：活性逻辑钩子、高关联对、事件统计。",
                null, a -> {
            if (engine() == null) return new ToolRegistry.Result(false, "context 未初始化");
            try {
                JSONObject r = engine().query(ROOM, Math.max(1, a.optInt("limit", 20)));
                return new ToolRegistry.Result(r.optBoolean("ok", false),
                        r.optBoolean("ok", false) ? "因果记忆" : r.optString("error", "失败"),
                        r.toString());
            } catch (Exception e) {
                return new ToolRegistry.Result(false, "查询失败: " + e.getMessage());
            }
        }, "native", "readonly", "none", true, 5, "memory",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("limit", "int", false, "默认 20", "关联强度 top-N"),
            },
            "JSON: {rules:[], atomCount, links:[], eventCount}",
            new String[]{"查因果记忆"}, null, 10000,
            new ToolRegistry.Manifest("查询因果记忆", "low", "查看固化的逻辑规则与关联", true, "io", "SLOW", false, 5000), null));

        // ── causal.link：调整关联强度 ──
        list.add(new ToolRegistry.Tool("causal.link", "手动调整两个原子的关联强度（delta 可正负，钳制 [0,1]）。",
                null, a -> {
            if (engine() == null) return new ToolRegistry.Result(false, "context 未初始化");
            try {
                JSONObject r = engine().link(ROOM, a.optString("a"), a.optString("b"),
                        a.optDouble("delta", 0), a.optString("reason", "manual"));
                return new ToolRegistry.Result(r.optBoolean("ok", false),
                        r.optBoolean("ok", false) ? "关联强度已调整" : r.optString("error", "失败"),
                        r.toString());
            } catch (Exception e) {
                return new ToolRegistry.Result(false, "调整失败: " + e.getMessage());
            }
        }, "native", "write", "none", false, 5, "memory",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("a", "string", true, "", "原子一"),
                new ToolRegistry.ParamDef("b", "string", true, "", "原子二"),
                new ToolRegistry.ParamDef("delta", "double", true, "", "强度增量（±）"),
                new ToolRegistry.ParamDef("reason", "string", false, "manual", "原因"),
            },
            "JSON: {a, b, strength}",
            new String[]{"加强 张三-李四 关联"}, null, 5000,
            new ToolRegistry.Manifest("调整关联强度", "low", "手动增强/削弱原子关联", true, "io", "SLOW", false, 5000), null));

        // ── causal.forget：遗忘 ──
        list.add(new ToolRegistry.Tool("causal.forget", "遗忘一个原子或规则（写墓碑，原文长在 journal 不删）。",
                null, a -> {
            if (engine() == null) return new ToolRegistry.Result(false, "context 未初始化");
            try {
                JSONObject r = engine().forget(ROOM, a.optString("target"),
                        a.optString("reason", "user_request"));
                return new ToolRegistry.Result(r.optBoolean("ok", false),
                        r.optBoolean("ok", false) ? "已遗忘: " + a.optString("target")
                                : r.optString("error", "失败"), r.toString());
            } catch (Exception e) {
                return new ToolRegistry.Result(false, "遗忘失败: " + e.getMessage());
            }
        }, "native", "write", "none", true, 5, "memory",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("target", "string", true, "", "原子标签或 ruleId"),
                new ToolRegistry.ParamDef("reason", "string", false, "user_request", "原因"),
            },
            "JSON: {forgotten, ok}",
            new String[]{"遗忘 张三"}, null, 5000,
            new ToolRegistry.Manifest("遗忘因果记忆", "medium", "从活性记忆移除原子/规则", true, "io", "SLOW", false, 5000), null));

        // ── causal.rule：注册逻辑钩子 ──
        list.add(new ToolRegistry.Tool("causal.rule", "注册/移除逻辑钩子（IF...THEN）。when 传 JSON，"
                + "如 {\"type\":\"cooccur\",\"atoms\":[\"张三\",\"李四\",\"欠款\"]} 或 "
                + "{\"type\":\"dateAfter\",\"whenDateField\":\"dueDate\"}。then 传 {\"linkDelta\":0.3,\"alert\":\"...\"}。",
                null, a -> {
            if (engine() == null) return new ToolRegistry.Result(false, "context 未初始化");
            try {
                String op = a.optString("op", "upsert");
                if ("remove".equals(op)) {
                    JSONObject r = engine().removeRule(ROOM, a.optString("ruleId"));
                    return new ToolRegistry.Result(r.optBoolean("ok", false),
                            r.optBoolean("ok", false) ? "规则已移除" : r.optString("error", "失败"), r.toString());
                }
                JSONObject rule = new JSONObject()
                        .put("ruleId", a.optString("ruleId"))
                        .put("label", a.optString("label"))
                        .put("when", new JSONObject(a.optString("when", "{}")))
                        .put("then", new JSONObject(a.optString("then", "{}")))
                        .put("enabled", a.optBoolean("enabled", true));
                JSONObject r = engine().upsertRule(ROOM, rule);
                return new ToolRegistry.Result(r.optBoolean("ok", false),
                        r.optBoolean("ok", false) ? "规则已注册: " + a.optString("ruleId")
                                : r.optString("error", "失败"), r.toString());
            } catch (Exception e) {
                return new ToolRegistry.Result(false, "规则操作失败: " + e.getMessage());
            }
        }, "native", "write", "none", true, 5, "memory",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("ruleId", "string", true, "", "规则 ID"),
                new ToolRegistry.ParamDef("op", "string", true, "upsert/remove", "操作"),
                new ToolRegistry.ParamDef("when", "string", true, "JSON", "触发条件"),
                new ToolRegistry.ParamDef("then", "string", false, "JSON", "动作"),
                new ToolRegistry.ParamDef("label", "string", false, "", "规则名"),
            },
            "JSON: {ruleId, blockHash, chainLen, ok}",
            new String[]{"注册债务到期提醒钩子"}, null, 5000,
            new ToolRegistry.Manifest("注册逻辑钩子", "medium", "IF...THEN 因果规则", true, "io", "SLOW", false, 5000), null));

        // ── causal.reflect：用户主动归因（本地叙事 → 云端分析 → 补丁钩子） ──
        list.add(new ToolRegistry.Tool("causal.reflect", "反思最近交往/事件模式：本地脱敏叙事 → 云端因果分析 → "
                + "编译逻辑补丁钩子（因果助手建议）。",
                null, a -> {
            if (engine() == null) return new ToolRegistry.Result(false, "context 未初始化");
            try {
                String narrative = NarrativeBuilder.narrate(engine(), ROOM);
                if (narrative.isEmpty()) return new ToolRegistry.Result(false, "暂无因果数据可反思（先 causal.record）");
                CausalOracle.Brain brain = buildOracleBrain();
                if (brain == null) return new ToolRegistry.Result(false, "未配置模型（设置→大脑→添加模型）");
                JSONObject patch = CausalOracle.analyze(brain, narrative);
                if (patch == null) return new ToolRegistry.Result(false, "归因分析未返回有效补丁（模型不可用或超时）");
                JSONObject cr = PatchCompiler.compile(engine(), ROOM, patch);
                return new ToolRegistry.Result(cr.optBoolean("ok", false),
                        cr.optBoolean("ok", false) ? "因果补丁已注册: " + cr.optString("ruleId") : cr.optString("error", "失败"),
                        cr.toString());
            } catch (Exception e) {
                return new ToolRegistry.Result(false, "反思失败: " + e.getMessage());
            }
        }, "native", "write", "none", true, 15, "memory",
            new ToolRegistry.ParamDef[]{},
            "JSON: {ruleId, blockHash, ok}",
            new String[]{"反思最近交往模式"}, null, 20000,
            new ToolRegistry.Manifest("因果反思", "medium", "本地叙事→云端归因→补丁钩子", true, "io", "SLOW", false, 20000), null));

        return list;
    }

    /** 生产 Brain：ModelRegistry 默认模型 → AiClient 单发 chat（DeepSeek）。未配置 → null。 */
    private static CausalOracle.Brain buildOracleBrain() {
        try {
            if (appContext == null) return null;
            com.hermes.android.model.ModelConfig mc =
                    com.hermes.android.model.ModelRegistry.getInstance(appContext).getDefault();
            if (mc == null || !mc.isConfigured()) return null;
            return (system, user) -> {
                com.hermes.android.ai.AiClient client = new com.hermes.android.ai.AiClient(mc, system);
                com.hermes.android.ai.AiClient.AiResponse resp = client.chat(user, 10000, 60000);
                return resp != null && resp.success ? resp.content : null;
            };
        } catch (Exception e) {
            return null;
        }
    }

    private static JSONObject parseMeta(String metaStr) {
        if (metaStr == null || metaStr.trim().isEmpty()) return null;
        try { return new JSONObject(metaStr); } catch (Exception e) { return null; }
    }
}
