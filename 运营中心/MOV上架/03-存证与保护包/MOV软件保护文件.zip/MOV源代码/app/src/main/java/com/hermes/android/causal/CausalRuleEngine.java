package com.hermes.android.causal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 因果逻辑钩子匹配引擎（蓝图 §2 IF...THEN + §4.2）。
 *
 * {@link #match}：事件四元组 → 活性规则命中 → 产出 alerts/links/firedRules（纯计算，不落库；
 * 落库由 {@code CausalEngine.record} 依据结果写 _causal_link/_causal_rule_block 事件）。
 * {@link #checkDue}：无事件的时间钩子（dateAfter 补触发，sweep 用）。
 * 纯 Java，零 android 依赖。
 */
public class CausalRuleEngine {

    /** 匹配结果（纯计算产物）。 */
    public static class CausalMatchResult {
        public final List<JSONObject> alerts = new ArrayList<>();
        public final List<JSONObject> links = new ArrayList<>();
        public final List<String> firedRules = new ArrayList<>();
    }

    /** 事件匹配活性规则。命中 → 强度增量 + 触发时间复位 + alert（占位替换）。 */
    public CausalMatchResult match(CausalRuleStore store, CausalEvent ev,
                                   CausalIndex idx, long nowMs) {
        CausalMatchResult result = new CausalMatchResult();
        List<String> atoms = ev.atoms();
        for (CausalRule rule : store.active(nowMs)) {
            if (!rule.matches(ev, nowMs)) continue;
            result.firedRules.add(rule.ruleId);
            store.touch(rule.ruleId, nowMs);

            // 强度增量：事件原子两两
            double delta = rule.linkDelta();
            if (Math.abs(delta) > 1e-9 && idx != null) {
                for (int i = 0; i < atoms.size(); i++) {
                    for (int j = i + 1; j < atoms.size(); j++) {
                        double strength = idx.addStrength(atoms.get(i), atoms.get(j), delta, nowMs);
                        if (strength > 0) {
                            JSONObject l = new JSONObject();
                            try {
                                l.put("a", atoms.get(i));
                                l.put("b", atoms.get(j));
                                l.put("delta", Math.round(delta * 1000) / 1000.0);
                                l.put("strength", Math.round(strength * 1000) / 1000.0);
                            } catch (org.json.JSONException ignored) {}
                            result.links.add(l);
                        }
                    }
                }
            }

            // alert 占位替换
            String alert = rule.renderAlert(ev);
            if (!alert.isEmpty()) {
                JSONObject a = new JSONObject();
                try {
                    a.put("ruleId", rule.ruleId);
                    a.put("label", rule.label);
                    a.put("alert", alert);
                    a.put("ts", nowMs);
                } catch (org.json.JSONException ignored) {}
                result.alerts.add(a);
            }
        }
        return result;
    }

    /**
     * 时间钩子补触发（无事件路径）：扫描近期事件 meta 的日期字段，dateAfter 规则到期则产 alert。
     * 不修改强度（无新事件原子），仅产出提醒——供 sweep 期间把"到期未记录"的债捞出来。
     */
    public List<JSONObject> checkDue(CausalRuleStore store, long nowMs, JSONArray recentEvents) {
        List<JSONObject> alerts = new ArrayList<>();
        for (CausalRule rule : store.active(nowMs)) {
            if (!"dateAfter".equals(rule.when.optString("type", ""))) continue;
            String field = rule.when.optString("whenDateField", "");
            if (field.isEmpty()) continue;
            // 扫描近期事件找 meta 日期字段
            for (int i = 0; recentEvents != null && i < recentEvents.length(); i++) {
                JSONObject ev = recentEvents.optJSONObject(i);
                if (ev == null) continue;
                CausalEvent ce = CausalEvent.fromPayload(ev.optJSONObject("payload"));
                String val = ce.metaString(field);
                if (val.isEmpty()) continue;
                if (nowMs > CausalRule.parseDateMs(val)) {
                    JSONObject a = new JSONObject();
                    try {
                        a.put("ruleId", rule.ruleId);
                        a.put("label", rule.label);
                        a.put("alert", rule.renderAlert(ce));
                        a.put("ts", nowMs);
                    } catch (org.json.JSONException ignored) {}
                    alerts.add(a);
                }
            }
        }
        return alerts;
    }
}
