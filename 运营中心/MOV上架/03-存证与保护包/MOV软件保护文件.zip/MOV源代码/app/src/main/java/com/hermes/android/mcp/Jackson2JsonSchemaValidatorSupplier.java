package com.hermes.android.mcp;

import io.modelcontextprotocol.json.schema.JsonSchemaValidator;
import io.modelcontextprotocol.json.schema.JsonSchemaValidatorSupplier;

/** MCP Java SDK 的 JsonSchemaValidator Supplier（Jackson 2），经 META-INF/services 注册。 */
public class Jackson2JsonSchemaValidatorSupplier implements JsonSchemaValidatorSupplier {
    @Override public JsonSchemaValidator get() { return new Jackson2JsonSchemaValidator(); }
}
