package com.hermes.android.skill;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * P1-7: 技能存储引擎。
 * 技能 = 可复用的指令模板 + 使用统计。
 * 存储在 SharedPreferences, 支持自动沉淀和手动安装。
 */
public class SkillStore {

    private static final String PREFS = "hermes_skills";
    private static final String KEY_SKILLS = "skills_json";

    private final SharedPreferences prefs;

    public SkillStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        seedDefaults();
    }

    /** 首次安装预置示例技能 */
    private void seedDefaults() {
        if (prefs.contains(KEY_SKILLS)) return;
        try {
            JSONArray skills = new JSONArray();

            skills.put(new JSONObject()
                    .put("id", "proxy-node-live-test")
                    .put("name", "proxy-node-live-test")
                    .put("desc", "用本地内核实测代理节点真实连通性, 区分节点失效与客户端配置问题")
                    .put("source", "自动生成")
                    .put("status", "稳定")
                    .put("revisions", 0)
                    .put("uses", 0)
                    .put("lastUsed", 0));

            skills.put(new JSONObject()
                    .put("id", "image-person-segmenter")
                    .put("name", "image-person-segmenter")
                    .put("desc", "图片人物/物体拆分与抠图, 支持绿幕与 AI 智能抠图双模式")
                    .put("source", "用户安装")
                    .put("status", "稳定")
                    .put("revisions", 0)
                    .put("uses", 0)
                    .put("lastUsed", 0));

            skills.put(new JSONObject()
                    .put("id", "kb-grow")
                    .put("name", "kb-grow")
                    .put("desc", "知识库摄入 → 自动构建 Wiki → 智能查询, 触发词 /ingest /buildkb")
                    .put("source", "自动生成")
                    .put("status", "稳定")
                    .put("revisions", 0)
                    .put("uses", 0)
                    .put("lastUsed", 0));

            prefs.edit().putString(KEY_SKILLS, skills.toString()).apply();
        } catch (Exception ignored) {}
    }

    /** 工单24: 确认卡入库——技能候选经用户确认后写入技能库 */
    public String addSkill(String skillJson) {
        try {
            JSONObject skill = SkillStore.parseSkill(skillJson);
            if (skill == null) return "{\"ok\":false,\"error\":\"技能格式非法\"}";
            JSONArray skills = new JSONArray(prefs.getString(KEY_SKILLS, "[]"));
            String id = skill.optString("id", "");
            if (id.isEmpty()) id = skill.optString("name", "skill-" + System.currentTimeMillis());
            /* 重名拒绝（库收敛） */
            for (int i = 0; i < skills.length(); i++) {
                JSONObject s = skills.getJSONObject(i);
                if (id.equals(s.optString("id", "")) || id.equals(s.optString("name", ""))) {
                    return "{\"ok\":false,\"error\":\"技能已存在: " + id + "\"}";
                }
            }
            skills.put(new JSONObject()
                    .put("id", id)
                    .put("name", skill.optString("name", id))
                    .put("desc", skill.optString("description", ""))
                    .put("triggers", skill.optJSONArray("triggers") != null ? skill.optJSONArray("triggers") : new JSONArray())
                    .put("steps", skill.optJSONArray("steps") != null ? skill.optJSONArray("steps") : new JSONArray())
                    .put("validation", skill.optString("validation", ""))
                    .put("source", "提炼确认")
                    .put("status", "候选")
                    .put("revisions", 0)
                    .put("uses", 0)
                    .put("lastUsed", 0));
            prefs.edit().putString(KEY_SKILLS, skills.toString()).apply();
            return new JSONObject().put("ok", true).put("id", id).toString();
        } catch (Exception e) {
            return "{\"ok\":false,\"error\":\"" + (e.getMessage() != null ? e.getMessage().replace("\"", "'") : "addSkill 异常") + "\"}";
        }
    }

    /** 工单24: 复用≥3 次 → 生成需求单（升级工厂产线）。存 filesDir/mcp-factory-inbox/（PC 同步读取）。
     *  返回生成的 REQ 列表。 */
    public JSONArray promoteReadySkills(Context ctx) {
        JSONArray promoted = new JSONArray();
        try {
            JSONArray skills = new JSONArray(prefs.getString(KEY_SKILLS, "[]"));
            java.io.File inbox = new java.io.File(ctx.getFilesDir(), "mcp-factory-inbox");
            inbox.mkdirs();
            for (int i = 0; i < skills.length(); i++) {
                JSONObject s = skills.getJSONObject(i);
                if (s.optInt("uses", 0) < 3) continue;
                String id = s.optString("id", "");
                if (id.isEmpty()) continue;
                /* 已生成过则跳过（防重复 REQ） */
                java.io.File req = new java.io.File(inbox, "REQ-" + id + ".json");
                if (req.exists()) continue;
                JSONObject requirement = new JSONObject()
                        .put("id", "REQ-" + id)
                        .put("title", "升级技能为真工具: " + s.optString("name", id))
                        .put("input", new JSONObject()
                                .put("type", "requirement")
                                .put("text", "技能「" + s.optString("name", id) + "」已被复用 "
                                        + s.optInt("uses", 0) + " 次，升级为工厂出厂的真工具。"
                                        + "能力: " + s.optString("desc", "")))
                        .put("expectedTools", new JSONArray()
                                .put(new JSONObject()
                                        .put("name", id.replace('_', '.'))
                                        .put("capability", s.optString("desc", ""))
                                        .put("level", "动作")
                                        .put("auth", "无需·本地")))
                        .put("checkCases", new JSONArray()
                                .put(new JSONObject().put("desc", "正例：触发语命中并执行")
                                        .put("input", (s.optJSONArray("triggers") != null
                                                && s.optJSONArray("triggers").length() > 0)
                                                ? s.optJSONArray("triggers").optString(0) : "执行技能")
                                        .put("expect", "成功执行且产出验证通过")))
                        .put("skillSource", id);
                java.io.FileWriter w = new java.io.FileWriter(req);
                w.write(requirement.toString(2));
                w.close();
                promoted.put(requirement);
            }
        } catch (Exception e) {
            /* 静默：升级通道失败不影响技能使用 */
        }
        return promoted;
    }

    /** 列出所有技能 JSON */
    public String listSkillsJson() {
        return prefs.getString(KEY_SKILLS, "[]");
    }

    /** 记录技能使用 */
    public String recordUse(String skillId) {
        try {
            JSONArray skills = new JSONArray(prefs.getString(KEY_SKILLS, "[]"));
            for (int i = 0; i < skills.length(); i++) {
                JSONObject skill = skills.getJSONObject(i);
                if (skillId.equals(skill.getString("id"))) {
                    skill.put("uses", skill.getInt("uses") + 1);
                    skill.put("lastUsed", System.currentTimeMillis());
                    prefs.edit().putString(KEY_SKILLS, skills.toString()).apply();
                    return new JSONObject().put("ok", true).toString();
                }
            }
            return "{\"ok\":false,\"error\":\"技能不存在\"}";
        } catch (Exception e) {
            return errJson(e);
        }
    }

    /** 删除技能 */
    public String deleteSkill(String skillId) {
        try {
            JSONArray skills = new JSONArray(prefs.getString(KEY_SKILLS, "[]"));
            JSONArray filtered = new JSONArray();
            boolean found = false;
            for (int i = 0; i < skills.length(); i++) {
                JSONObject skill = skills.getJSONObject(i);
                if (skillId.equals(skill.getString("id"))) {
                    found = true;
                } else {
                    filtered.put(skill);
                }
            }
            if (!found) return "{\"ok\":false,\"error\":\"技能不存在\"}";
            prefs.edit().putString(KEY_SKILLS, filtered.toString()).apply();
            return new JSONObject().put("ok", true).toString();
        } catch (Exception e) {
            return errJson(e);
        }
    }

    // ============ 批2: 动态技能（借鉴 Kimi KIMI_SKILLS_ROOT）============

    private static final String SKILLS_DIR = "skills";

    /** 释放内置技能 assets/skills/* 到 filesDir/skills/（skip-if-exists 默认策略） */
    public void ensureSeeded(Context context) {
        try {
            java.io.File dir = new java.io.File(context.getFilesDir(), SKILLS_DIR);
            if (!dir.exists()) dir.mkdirs();
            String[] assets = context.getAssets().list("skills");
            if (assets == null) return;
            for (String name : assets) {
                java.io.File out = new java.io.File(dir, name);
                if (out.exists()) continue;   // skip-if-exists（缺才拷，不覆盖已装）
                try (java.io.InputStream is = context.getAssets().open("skills/" + name);
                     java.io.FileOutputStream fos = new java.io.FileOutputStream(out)) {
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = is.read(buf)) > 0) fos.write(buf, 0, n);
                }
            }
        } catch (Exception ignored) {}
    }

    /** 列出 filesDir/skills 技能文件名 */
    public String[] listSkillFiles(Context context) {
        java.io.File dir = new java.io.File(context.getFilesDir(), SKILLS_DIR);
        String[] f = dir.list();
        return f != null ? f : new String[0];
    }

    /** 解析技能 JSON 或 SKILL.md frontmatter（批3 一表双脑共享 Hermes skills）:
     *  返回 {name, description, tools[]}，非法返回 null */
    public static JSONObject parseSkill(String json) {
        try {
            String s = json != null ? json.trim() : "";
            // SKILL.md frontmatter（--- 开头）→ 解析 name/description
            if (s.startsWith("---")) {
                int end = s.indexOf("\n---", 3);
                if (end > 0) {
                    String fm = s.substring(3, end);
                    JSONObject out = new JSONObject();
                    java.util.regex.Matcher nameM = java.util.regex.Pattern
                            .compile("name:\\s*[\"']?([^\"'\\n]+)").matcher(fm);
                    java.util.regex.Matcher descM = java.util.regex.Pattern
                            .compile("description:\\s*[\"']?([^\"'\\n]+)").matcher(fm);
                    String name = nameM.find() ? nameM.group(1).trim() : "";
                    String desc = descM.find() ? descM.group(1).trim() : "";
                    if (name.isEmpty()) return null;
                    out.put("name", name);
                    out.put("description", desc);
                    out.put("tools", new JSONArray());
                    return out;
                }
            }
            // 原 JSON 技能
            JSONObject j = new JSONObject(json);
            if (!j.has("name")) return null;
            JSONObject out = new JSONObject();
            out.put("name", j.optString("name"));
            out.put("description", j.optString("description", ""));
            JSONArray tools = j.optJSONArray("tools");
            out.put("tools", tools != null ? tools : new JSONArray());
            /* 工单24: 提炼技能保留 triggers/steps/validation/params（确认卡入库不丢字段） */
            JSONArray triggers = j.optJSONArray("triggers");
            if (triggers != null) out.put("triggers", triggers);
            JSONArray steps = j.optJSONArray("steps");
            if (steps != null) out.put("steps", steps);
            if (j.has("validation")) out.put("validation", j.optString("validation"));
            JSONObject params = j.optJSONObject("params");
            if (params != null) out.put("params", params);
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    /** JSONObject 构造错误 JSON (自动转义), 与 StorageManager.errJson 同模式 */
    private String errJson(Exception e) {
        try {
            return new JSONObject().put("ok", false)
                    .put("error", e.getMessage() != null ? e.getMessage() : "未知错误").toString();
        } catch (Exception ex) {
            return "{\"ok\":false}";
        }
    }
}
