package com.hermes.android.workflow;

/**
 * 设备状态拉取接口（纯 JVM）——条件数据在 snapshot() 时刻现查，与 receiver 触发家族完全解耦。
 * 二次打回修复：条件要的数据跟 workflow 用什么触发器无关，数据源不绑触发器注册。
 */
public interface DeviceStateProvider {

    /** snapshot 时刻的世界状态（拉取式） */
    DeviceState read();

    /** 设备状态快照（纯数据） */
    class DeviceState {
        public final int batteryLevel;      // -1 未知
        public final boolean charging;
        public final boolean screenOn;
        public final String networkType;    // "wifi"/"mobile"/null

        public DeviceState(int batteryLevel, boolean charging, boolean screenOn, String networkType) {
            this.batteryLevel = batteryLevel;
            this.charging = charging;
            this.screenOn = screenOn;
            this.networkType = networkType;
        }
    }
}
