package com.hermes.android.mcp.server;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.hermes.android.StorageManager;
import com.hermes.android.agent.HermesServeConfig;
import com.hermes.android.agent.Journal;
import com.hermes.android.agent.ToolRegistry;

import io.modelcontextprotocol.json.McpJsonDefaults;
import io.modelcontextprotocol.json.McpJsonMapper;
import io.modelcontextprotocol.server.McpServer;
import io.modelcontextprotocol.server.McpServerFeatures;
import io.modelcontextprotocol.server.McpSyncServer;
import io.modelcontextprotocol.spec.McpSchema;

import java.util.List;

/**
 * MOV 能力 MCP 化 — 进程级 MCP server 门面（P1 最小可对接；P2 扩展 = 工单 P5）。
 *
 * 锚定 HermesApplication.onCreate：ensureRunning 幂等启动（端口占用静默降级）。
 * P1：只读工具集（file.read/list、tool.describe、model.list 等）。
 * P2（本工单）：全量工具 + 审批闸 + mov.* 查询——
 *  - 写工具默认不暴露（HermesServeConfig.isMcpWriteEnabled 显式开启）；DANGEROUS 类永不开；
 *  - write 工具调用必须过 {@link McpApprovalGate}（未批准返回 APPROVAL_PENDING + 房间内确认闭环）；
 *  - mov.roomList / mov.journalTail 只读查询（journal 只追加读）。
 *
 * 连接：adb reverse tcp:8389 tcp:8389 → MCP Inspector / Claude Desktop 连 http://127.0.0.1:8389/mcp
 * 鉴权：Authorization: Bearer &lt;token&gt;（token 与 Hermes 常驻 serve 同源，HermesServeConfig）。
 */
public class MovMcpServer {

    private static final String TAG = "MovMcpServer";
    public static final int PORT = 8389;

    /** MCP write 工具落房间 + 审批事件房间（P2 固定，房间无关工具集之上给写入一个锚点）。 */
    public static final String MCP_ROOM = "global";

    private static volatile MovMcpServer instance;

    private final AndroidHttpServer http;
    private final AndroidStreamableHttpTransport transport;
    private final McpSyncServer syncServer;
    private final String token;
    private final McpApprovalGate gate;
    private volatile Activity activity;  // P2 审批弹窗用；P1 仅占位

    private MovMcpServer(AndroidHttpServer http, AndroidStreamableHttpTransport transport,
                         McpSyncServer syncServer, String token, McpApprovalGate gate) {
        this.http = http;
        this.transport = transport;
        this.syncServer = syncServer;
        this.token = token;
        this.gate = gate;
    }

    /** 幂等启动。失败（mapper 缺失/端口占满）静默降级，不阻塞 onCreate。 */
    public static synchronized void ensureRunning(Context ctx) {
        if (instance != null) return;
        try {
            McpJsonMapper mapper = McpJsonDefaults.getMapper();
            if (mapper == null) {
                Log.e(TAG, "JSON mapper 不可用（ServiceLoader 未找到 Jackson2 provider），MCP server 未启动");
                return;
            }
            String token = HermesServeConfig.token(ctx);
            AndroidStreamableHttpTransport transport = new AndroidStreamableHttpTransport(mapper, token);
            McpSyncServer server = McpServer.sync(transport)
                    .serverInfo("mov", "3.3.0")
                    .capabilities(McpSchema.ServerCapabilities.builder().tools(true).build())
                    .build();
            boolean enableWrite = HermesServeConfig.isMcpWriteEnabled(ctx);
            Journal journal = new Journal(new StorageManager(ctx).getRoomsDir());
            McpApprovalGate gate = new McpApprovalGate(journal, MCP_ROOM);
            ToolRegistry registry = enableWrite
                    ? RegistryProvider.build(ctx, MCP_ROOM, gate.getPathAllowSet())
                    : RegistryProvider.build(ctx);
            int n = registerExposedTools(server, registry, gate, enableWrite);
            n += registerMovQueryTools(server, journal);
            AndroidHttpServer http = new AndroidHttpServer(PORT, transport);
            if (!http.start()) {
                Log.e(TAG, "MCP 端口 " + PORT + " 不可用，MCP server 未启动");
                return;
            }
            instance = new MovMcpServer(http, transport, server, token, gate);
            Log.i(TAG, "MCP server 启动 127.0.0.1:" + http.getPort() + " (" + n + " 工具"
                    + (enableWrite ? ", write 已开启" : ", 只读") + "), 端点 /mcp");
        } catch (Exception e) {
            Log.e(TAG, "MCP server 启动失败: " + e, e);
        }
    }

    /** 注册暴露工具集（P2）：readonly 直接注册；write 走审批闸包装。返回注册数。 */
    private static int registerExposedTools(McpSyncServer server, ToolRegistry registry,
                                            McpApprovalGate gate, boolean enableWrite) {
        int n = 0;
        for (ToolRegistry.Tool t : RegistryProvider.exposedTools(registry, enableWrite)) {
            if ("write".equals(t.access)) {
                server.addTool(new McpServerFeatures.SyncToolSpecification(
                        McpToolAdapter.toSchema(t), McpToolAdapter.gatedHandlerFor(t, gate)));
            } else {
                server.addTool(new McpServerFeatures.SyncToolSpecification(
                        McpToolAdapter.toSchema(t), McpToolAdapter.handlerFor(t)));
            }
            n++;
        }
        return n;
    }

    /** 注册 mov.* 只读查询工具。返回注册数。 */
    private static int registerMovQueryTools(McpSyncServer server, Journal journal) {
        int n = 0;
        for (ToolRegistry.Tool t : List.of(MovQueryTools.roomList(journal), MovQueryTools.journalTail(journal))) {
            server.addTool(new McpServerFeatures.SyncToolSpecification(
                    McpToolAdapter.toSchema(t), McpToolAdapter.handlerFor(t)));
            n++;
        }
        return n;
    }

    public static synchronized void stop() {
        if (instance == null) return;
        try { instance.syncServer.closeGracefully(); } catch (Exception ignored) {}
        try { instance.transport.close(); } catch (Exception ignored) {}
        instance.http.stop();
        instance = null;
        Log.i(TAG, "MCP server 已停止");
    }

    /** P2 审批弹窗宿主。P1 仅存引用。 */
    public static void attach(Activity activity) {
        if (instance != null) instance.activity = activity;
    }

    public static boolean isRunning() { return instance != null; }
    public static int getPort() { return instance != null ? instance.http.getPort() : -1; }
    public static String getToken() { return instance != null ? instance.token : null; }

    /**
     * P2 审批闸入口（房间内确认闭环）：UI/Bridge 读到 journal 的 _mcp_approval_request
     * 事件后，调 {@link McpApprovalGate#respond(requestId, approved, note)} 完成确认。
     * 未启动 → null。
     */
    public static McpApprovalGate approvalGate() {
        return instance != null ? instance.gate : null;
    }
}
