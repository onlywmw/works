package com.hermes.android.agent;

import com.hermes.android.BuildConfig;
import com.hermes.android.ErrorReporter;
import com.hermes.android.HermesApplication;
import com.hermes.android.ai.AiClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/**
 * AgentLoop — council 房 agentic 循环 (DESIGN_AGENT_LOOP v1.1, v1 循环核心)。
 *
 * 状态机: PLANNING → PLAN_GATE → EXECUTING → DONE/FAILED/STOPPED
 * 大脑每轮输出一个 JSON 动作, 原生执行并回灌; 全局单 loop 互斥。
 *
 * 熔断: 单步超时由 AiClient 读超时兜底(60s), 连续 2 次解析失败,
 *       总步数 12, 纯执行时长 10 分钟 (ask_user 挂起暂停计时)。
 * 安全红线: file.write 路径必须在已批准计划内, 计划外硬拒绝。
 */
public class AgentLoop implements Runnable {

    // ==================== 依赖注入 (生产/测试可替换) ====================

    /** 大脑: 给定 system prompt + 用户文本, 返回 LLM 响应 */
    public interface Brain {
        AiClient.AiResponse chat(String systemPrompt, String userText);
    }

    /** 双手: 文件与设备能力 (生产实现走 StorageManager/IntentParser/CapabilityExecutor/PackageBuilder) */
    public interface Tools {
        /** 房间工作区文件列表 (文本) */
        String fileList(String roomId);
        /** 读房间工作区文件, 成功返回内容, 失败返回以 "ERROR:" 开头的文本 */
        String fileRead(String roomId, String path);
        /** 写房间工作区文件, 返回结果文本 (ok/err) */
        String fileWrite(String roomId, String path, String content);
        /** 仅解析指令 → capability (不执行); 无法解析返回 "" */
        String capabilityOf(String text);
        /** 执行设备指令, 返回结果文本 */
        String deviceCmd(String text);
        /** HTML → 签名 APK 并落到房间工作区; 成功 JSON {"ok":true,"file":..,"msg":..},
         *  失败 {"ok":false,"error":..} (旧实现 "OK: <file> · ..." / "ERR: ..." 亦兼容) */
        String packageApk(String roomId, String path, String appName);
        /** 内嵌 Linux 执行 shell 命令, 返回 "exit=N\n<stdout>\n<stderr>" 文本;
         *  rootfs 未就绪返回以 "ERROR:" 开头的引导文本 */
        String shellExec(String cmd, int timeoutSec);
        /** 工单20: hermes.task — 开放式子任务进内嵌 Linux 由 Hermes 自主完成。
         *  返回 JSON 信封 {"ok":bool, "output":.., "error":..}；复用 HeavyWorker serve 通路 */
        String hermesTask(String goal, int timeoutSec);
        /** 房间工作区文件 → Linux /exchange, 返回 JSON {ok,..} */
        String filePush(String roomId, String path);
        /** Linux /exchange 产物 → 房间工作区, 返回 JSON {ok,..} */
        String filePull(String roomId, String name);
    }

    /** 工作日志出口: 每条日志一个 JSONObject (type: phase/plan/step/ask/note/deliver/fail/stopped) */
    public interface LogSink {
        void onLog(JSONObject log);
    }

    // ==================== 常量 (熔断与预估) ====================

    /** 步数上限 — 优先 RulesManager 热更规则, 兜底 12 */
    public static int maxSteps() { try { return com.hermes.android.RulesManager.get().maxSteps; } catch (Exception e) { return 12; } }
    public static final int MAX_PARSE_FAILS = 2;
    public static final int MAX_REVISE_PLANS = 2;   // revise_plan 全任务封顶 (防规划死循环)
    /** 纯执行超时 (ms) — 优先 RulesManager 热更规则, 兜底 10 分钟 */
    public static long maxExecMs() { try { return com.hermes.android.RulesManager.get().maxExecMs; } catch (Exception e) { return 10 * 60_000; } }
    public static final long ASK_TIMEOUT_MS = 10 * 60_000;
    /** 计划闸超时: 用户长时间不批准 → 自动停止, 防僵尸 loop 堵死全局队列 */
    public static final long PLAN_GATE_TIMEOUT_MS = 10 * 60_000;
    private static final int MAX_PLAN_CYCLES = 3;
    private static final int EST_TOKENS_PER_STEP = 2500;
    private static final int EST_BASE_TOKENS = 4000;
    private static final int EST_SEC_PER_STEP = 20;

    // ==================== 全局单 loop 互斥 ====================

    private static AgentLoop current;

    public static synchronized AgentLoop current() { return current; }

    /** 有活跃 loop 返回 null (调用方负责排队/提示)
     *  allowedPaths 由组装方创建并共享给注册表 (revise_plan 时循环写入, 注册表即时可见) */
    public static synchronized AgentLoop startNew(String roomId, String goal,
                                                  Brain brain, Tools tools,
                                                  ToolRegistry registry,
                                                  Set<String> allowedPaths,
                                                  LogSink sink) {
        return startNew(roomId, goal, brain, tools, registry, allowedPaths, sink, null);
    }

    /** P4: 带 worker 注册表的启动入口 (workers 可空 → 跳过 worker 路由) */
    public static synchronized AgentLoop startNew(String roomId, String goal,
                                                  Brain brain, Tools tools,
                                                  ToolRegistry registry,
                                                  Set<String> allowedPaths,
                                                  LogSink sink,
                                                  java.util.Map<String, Worker> workers) {
        if (current != null && current.isActive()) return null;
        AgentLoop l = new AgentLoop(roomId, goal, brain, tools, registry,
                allowedPaths != null ? allowedPaths : new HashSet<>(), sink, workers);
        current = l;
        new Thread(l, "agent-loop").start();
        return l;
    }

    /** 从 Journal 恢复未完成的任务 (App 被杀后重启) */
    public static synchronized AgentLoop startRecovery(String roomId, String goal,
                                                        Brain brain, Tools tools,
                                                        ToolRegistry registry,
                                                        Set<String> allowedPaths,
                                                        LogSink sink,
                                                        int completedSteps, int totalSteps) {
        if (current != null && current.isActive()) return null;
        AgentLoop l = new AgentLoop(roomId, goal, brain, tools, registry,
                allowedPaths != null ? allowedPaths : new HashSet<>(), sink, null,
                true, completedSteps, totalSteps);
        current = l;
        new Thread(l, "agent-loop-recovery").start();
        return l;
    }

    // ==================== 实例状态 ====================

    private final String loopId;
    private final String roomId;
    private final String goal;
    private final Brain brain;
    private final Tools tools;
    private final ToolRegistry registry;   // 工具唯一入口: agent 与硬件控制的分割层
    private final LogSink sink;
    private final java.util.Map<String, Worker> workers; // P4: worker 注册表 (可空 → 跳过 worker 路由)
    private final String stepPrompt;   // 由注册表动态生成 (工具随设备而变)
    private final String planPrompt;   // 同上: 规划阶段就知道本机能力

    private volatile boolean stopRequested = false;
    private volatile int recoveryStepOffset = 0;  // RECOVERY 模式: 已完成步骤数, 从 offset+1 步开始
    private volatile int recoveryTotalSteps = 0;   // 原计划总步数
    private volatile boolean recoveryMode = false;
    private final Object gateLock = new Object();
    private volatile Boolean planApproved;
    private volatile String planNote;
    private volatile String userAnswer;
    private volatile Boolean fileWriteApproved;
    private volatile Boolean shellApproved;
    private boolean allowedShell = false;   // 计划含 shell.exec 或用户批准过一次 → 本任务放行

    private final Set<String> allowedPaths;   // 组装方共享 (注册表 file.write 直接读它)
    private final StringBuilder transcript = new StringBuilder();
    private final JSONArray producedFiles = new JSONArray();
    private int stepsDone = 0;   // 已完成步数 (失败三问: 部分产物进度)
    private int totalPrompt = 0, totalCompletion = 0;
    private final java.util.Set<String> usedWorkerTypes = new java.util.HashSet<>(); // P6: 遥测用
    private JSONArray approvedPlan;     // P8: 批准后的计划, 执行时按索引读 worker
    private int planStepIdx = 0;        // P8: 当前执行的计划步骤索引
    private int estTokens = 0, estSeconds = 0;
    private long execStartMs = 0, parkedMs = 0;
    private int stepCounter = 0;
    private int reviseCount = 0;   // revise_plan 计数 (封顶 MAX_REVISE_PLANS)
    private String finishSummary = null;

    /* BUG-5: 状态容器 (单变量, changeState() 唯一入口 → ctx.transition()) */
    private final AgentContext ctx = new AgentContext();
    /* M1b Phase 7: 执行进度管理 */
    private final ExecutionProgress progress = new ExecutionProgress();

    /**
     * Agent 状态机 — 6 态，带转换表。
     * 非法转换抛异常 + 记录调用栈，防止"半个状态"导致的切房泄漏。
     *
     * 合法转换:
     *   IDLE → PLANNING
     *   PLANNING → PLAN_GATE / FAILED / STOPPED
     *   PLAN_GATE → EXECUTING / STOPPED
     *   EXECUTING → PAUSED / PLAN_GATE(revise_plan) / DONE / FAILED / STOPPED
     *   PAUSED → EXECUTING / STOPPED
     *   DONE / FAILED / STOPPED → (终态，不允许再转换)
     */
    public enum State {
        PLANNING,
        PLAN_GATE,
        EXECUTING,
        PAUSED,
        RECOVERY,   // App 被杀后从 Journal 恢复, 只读投影已完成步骤
        DONE,
        FAILED,
        STOPPED;

        /** 返回 true 表示可以从 this 转换到 target */
        public boolean canTransitionTo(State target) {
            if (this == target) return true;
            switch (this) {
                case PLANNING:
                    return target == PLAN_GATE || target == FAILED || target == STOPPED
                            || target == RECOVERY;  // BUG-5: recovery 构造链
                case PLAN_GATE:
                    return target == EXECUTING || target == FAILED || target == STOPPED;  // P1#6: 计划阶段 failMov 需允许 → FAILED（防 IllegalStateException 崩溃）
                case EXECUTING:
                    return target == PAUSED || target == DONE || target == FAILED || target == STOPPED
                            || target == PLAN_GATE;  // revise_plan 回到闸
                case PAUSED:
                    return target == EXECUTING || target == STOPPED;
                case RECOVERY:
                    return target == EXECUTING || target == FAILED || target == STOPPED
                            || target == PLANNING;  // BUG-5: 对称, 构造链从 PLANNING 回调
                default: // DONE, FAILED, STOPPED 是终态
                    return false;
            }
        }

        public boolean isTerminal() {
            return this == DONE || this == FAILED || this == STOPPED;
        }

        public boolean isActive() {
            return this == PLANNING || this == PLAN_GATE || this == EXECUTING || this == PAUSED || this == RECOVERY;
        }
    }

    /** BUG-5 Phase2: 统一状态转换入口 — 非法转换直接抛 (fail-fast) */
    private void changeState(State target) {
        State old = ctx.getState();
        ctx.transition(target);  // 非法转换直接抛 IllegalStateException, 由 run() catch-all 兜底
        android.util.Log.i("AgentLoop", "状态: " + old + " → " + target + " (" + loopId + ")");
    }

    private AgentLoop(String roomId, String goal, Brain brain, Tools tools,
                      ToolRegistry registry, Set<String> allowedPaths,
                      LogSink sink,
                      java.util.Map<String, Worker> workers) {
        this.loopId = "loop" + System.currentTimeMillis();
        this.roomId = roomId;
        this.goal = goal;
        this.brain = brain;
        this.tools = tools;
        this.registry = registry;
        this.allowedPaths = allowedPaths;
        this.sink = sink;
        this.workers = workers;
        // 工具说明由注册表生成: 换设备/换工具, prompt 自动跟随
        this.stepPrompt = loadPrompt("step_rules.txt", STEP_RULES)
                + "\n工具协议:\n" + registry.promptText()
                + "\n\n## 代码约束（违反则驳回）\n"
                + "- 禁止 catch (Exception ignored) —— 每个 catch 必须 Log.w\n"
                + "- 工具结果必须先校验非空再使用\n"
                + "- file.write 的 content 不能为空字符串\n"
                + "- 状态只能通过 transition() 修改, 禁止 state = State.XXX\n"
                // 学习场景: 产出 HTML 时按知识页规范（全屏可开 + contenteditable 微调）
                + "\n\n## 产出 HTML 规范（当任务产出 HTML 文件时参考）\n"
                + loadPrompt("learn_page.txt", "");
        // P6 环境地图: 任务启动注入环境快照（最近文档/媒体/保险柜名/A2A/journal/配置健康），
        // agent 第一眼看到自己拥有的资产，而不是闭眼规划（DESIGN_AGENT_WORKSTYLE 一律）
        String envMapSuffix = "";
        try {
            envMapSuffix = "\n\n【环境地图】\n" + EnvMap.snapshot(HermesApplication.getAppContext()).toString();
        } catch (Exception e) {
            android.util.Log.w("AgentLoop", "环境地图注入失败: " + e.getMessage());
        }
        this.planPrompt = loadPrompt("plan_rules.txt", PLAN_RULES) + "\n可用手段:\n" + registry.promptText()
                + "\n\n## 产出 HTML 规范（当任务产出 HTML 文件时参考）\n"
                + loadPrompt("learn_page.txt", "") + envMapSuffix;
        ctx.transition(State.PLANNING);
    }

    /** 恢复构造: App 被杀后从 Journal 重建 */
    private AgentLoop(String roomId, String goal, Brain brain, Tools tools,
                      ToolRegistry registry, Set<String> allowedPaths,
                      LogSink sink,
                      java.util.Map<String, Worker> workers,
                      boolean recoveryDummy, int completedSteps, int totalSteps) {
        this(roomId, goal, brain, tools, registry, allowedPaths, sink, workers);
        ctx.transition(State.RECOVERY);
        this.recoveryMode = true;
        this.recoveryStepOffset = completedSteps;
        this.recoveryTotalSteps = totalSteps;
        this.stepsDone = completedSteps;
        this.stepCounter = completedSteps;
        // 恢复提示写入 transcript
        transcript.append("🔄 检测到未完成任务: 已完成 ")
                  .append(completedSteps).append("/").append(totalSteps)
                  .append(" 步, 从第 ").append(completedSteps + 1).append(" 步继续\n");
        try {
            sink.onLog(new JSONObject().put("type", "recovery")
                .put("completed", completedSteps)
                .put("total", totalSteps)
                .put("loopId", loopId));
        } catch (org.json.JSONException ignored) { /* 非致命 */ }
    }

    /** 检查房间是否有未完成的任务 */
    public static boolean hasUnfinishedTask(String roomId) {
        try {
            java.io.File jf = new java.io.File(
                    new com.hermes.android.StorageManager(appContext).getRoomsDir(),
                    roomId + "/journal.jsonl");
            if (!jf.exists()) return false;
            boolean hasPlan = false, hasTerminal = false;
            try (java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.InputStreamReader(new java.io.FileInputStream(jf), "UTF-8"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.contains("\"type\":\"plan\"")) hasPlan = true;
                    if (line.contains("\"type\":\"deliver\"")
                        || line.contains("\"type\":\"fail\"")
                        || line.contains("\"type\":\"stopped\"")) hasTerminal = true;
                }
            }
            return hasPlan && !hasTerminal;
        } catch (Exception ignored) { return false; }
    }

    /** 从 Journal 统计已完成步骤数（只读扫描） */
    public static int countCompletedSteps(String roomId) {
        int count = 0;
        try {
            java.io.File jf = new java.io.File(
                    new com.hermes.android.StorageManager(appContext).getRoomsDir(),
                    roomId + "/journal.jsonl");
            if (!jf.exists()) return 0;
            try (java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.InputStreamReader(new java.io.FileInputStream(jf), "UTF-8"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.contains("\"type\":\"step\"") && line.contains("\"ok\":true")) count++;
                }
            }
        } catch (Exception ignored) { }
        return count;
    }

    /** 当前是否为 RECOVERY 模式 */
    public boolean isRecovery() { return recoveryMode; }
    public int getRecoveryOffset() { return recoveryStepOffset; }

    // ── Prompt 文件加载 ──
    private static android.content.Context appContext;
    public static void setAppContext(android.content.Context ctx) { appContext = ctx.getApplicationContext(); }

    // ── G14 记忆覆盖注入（DESIGN_MEMORY_LAYERS v2 §六）：读取时按需覆盖注入 AI 上下文 ──
    /** memoryCover 的 journal 源；测试注入临时目录（纯 JVM 无 app context），null → 生产用 appContext。 */
    private static Journal memoryJournal;
    /** 测试/工具注入 journal 源（null 恢复生产默认）。 */
    public static void setMemoryJournal(Journal j) { memoryJournal = j; }
    /** 通过 PromptLoader 加载 (缓存 + debug mtime热重载 + filesDir可编辑 + 默认值兜底) */
    private static String loadPrompt(String fileName, String fallback) {
        return PromptLoader.load(fileName, fallback);
    }

    public String getLoopId() { return loopId; }
    public String getRoomId() { return roomId; }
    public State getState() { return ctx.getState(); }
    public boolean isActive() { return ctx.getState().isActive(); }

    /**
     * 错误分类 + 报告。硬错误直接记日志，软错误返回 LLM 可诊断的描述。
     * @return 软错误时返回错误描述（可喂给 LLM），硬错误返回 null（已直接报告）
     */
    private String classifyAndReport(String toolName, Exception e, JSONObject stepLog) {
        ErrorClassifier.Result r = ErrorClassifier.classify(e);
        try { stepLog.put("errorCategory", r.category.name()); } catch (Exception silentErr) {}
        try { stepLog.put("errorMessage", r.userMessage); } catch (Exception silentErr) {}
        // 上报到 errors.jsonl
        if (appContext != null) {
            ErrorReporter.Category c = ErrorReporter.Category.UNKNOWN;
            switch (r.category) {
                case USER_ERROR: c = ErrorReporter.Category.USER_ERROR; break;
                case EXTERNAL_ERROR: c = ErrorReporter.Category.NETWORK_ERROR; break;
                case INTERNAL_ERROR: c = ErrorReporter.Category.INTERNAL_ERROR; break;
            }
            ErrorReporter.report(appContext, c, "AgentLoop." + toolName, r.userMessage);
        }

        try {
            if (r.isHardError()) {
                JSONObject lo = new JSONObject();
                lo.put("type", "step");
                lo.put("text", "工具 " + toolName + " 失败: " + r.userMessage);
                lo.put("hardError", true);
                log(lo);
                return null;
            }
            JSONObject lo = new JSONObject();
            lo.put("type", "step");
            lo.put("text", "工具 " + toolName + " 异常: " + r.userMessage);
            lo.put("retryable", true);
            log(lo);
            return r.userMessage + "\n请分析原因并修正后重试。";
        } catch (org.json.JSONException je) { return null; }
    }

    /** JS Bridge 只读查询：返回 Agent 状态的 JSON */
    public JSONObject getStateJson() {
        try {
            return new JSONObject()
                    .put("loopId", loopId)
                    .put("roomId", roomId)
                    .put("phase", ctx.getState().name())
                    .put("active", ctx.getState().isActive())
                    .put("stepsDone", stepsDone)
                    .put("audit", true)
                    .put("goal", goal != null ? goal : "");
        } catch (Exception e) { return new JSONObject(); }
    }

    // ==================== 外部控制 ====================

    public void requestStop() {
        stopRequested = true;
        // Phase 8: 中断正在执行中的工具(杀 shell 进程)
        InterruptSignal s = ToolRegistry.currentSignal.get();
        if (s != null) s.interrupt();
        synchronized (gateLock) { gateLock.notifyAll(); }
    }

    /** ask_user 的答案回灌 */
    public void answer(String text) {
        userAnswer = text;
        synchronized (gateLock) { gateLock.notifyAll(); }
    }

    /** P8 理解闸: 批准/驳回+补充 (v1: 暂同 plan 闸, v2 独立状态机后拆分) */
    public void respondUnderstand(boolean approved, String note) {
        respondPlan(approved, note);
    }

    /** 计划闸: 批准/驳回+补充 */
    public void respondPlan(boolean approved, String note) {
        planApproved = approved;
        planNote = note;
        synchronized (gateLock) { gateLock.notifyAll(); }
    }

    /** P1 文件写入预览闸: 确认/驳回 (与计划闸共用唤醒锁) */
    public void respondFileWrite(boolean approved) {
        fileWriteApproved = approved;
        synchronized (gateLock) { gateLock.notifyAll(); }
    }

    /** 计划外 shell.exec 确认闸: 批准即本任务放行全部 shell.exec (照 respondFileWrite 模式) */
    public void respondShell(boolean approved) {
        shellApproved = approved;
        synchronized (gateLock) { gateLock.notifyAll(); }
    }

    // ==================== 主循环 ====================

    @Override
    public void run() {
        execStartMs = System.currentTimeMillis(); // PLANNING 阶段 fail/stopped 也需要有效起点
        try {
            int planCycles = 0;
            JSONArray plan = null;   // P8: 提到循环外, EXECUTING 阶段引用
            // ---- PLANNING + PLAN_GATE (可经驳回/revise_plan 重入) ----
            while (true) {
                if (planCycles++ >= MAX_PLAN_CYCLES) { fail("计划被驳回次数过多, 已停止"); return; }
                if (stopRequested) { stopped(); return; }
                changeState(State.PLANNING);
                phase("讨论中");
                /* P8: 拆两步 — clarifyGoal 可能直接返回 plan (兼容旧格式) */
                String fileList = tools.fileList(roomId);
                String baseGoal = "用户目标: " + goal + "\n\n═══ 当前环境 ═══\n" + envSnapshot()
                        + "\n\n房间工作区现有文件:\n" + fileList
                        + fileContext(fileList)
                        + (transcript.length() > 0 ? "\n\n补充信息:\n" + transcript : "");
                plan = clarifyThenPlan(baseGoal);
                if (plan == null) return; // 内部已 stopped 或 fail
                allowedPaths.clear();
                allowedShell = false;
                /* P4: 解析 worker 标注 + 可用性检查 (CONTRACT: Worker §6) */
                boolean workerAvailable = true;
                String workerUnavailableReason = null;
                for (int i = 0; i < plan.length(); i++) {
                    JSONObject s = plan.optJSONObject(i);
                    if (s == null) continue;
                    String stepAction = s.optString("action", "");
                    /* 兼容 tool.execute 格式: action=tool.execute 时看 name */
                    if ("tool.execute".equals(stepAction)) stepAction = s.optString("name", stepAction);
                    if ("file.write".equals(stepAction)) {
                        /* 兼容两种计划格式: 顶层 path (plan_rules 老格式) 与 args.path (P2 新格式)。
                           只读顶层 path 会漏掉 args 嵌套格式 → 多文件 plan 每个 file.write 都误判
                           计划外写入弹确认闸 (2026-08-05 修复) */
                        String wpath = s.optString("path", "");
                        if (wpath.isEmpty()) {
                            JSONObject wa = s.optJSONObject("args");
                            if (wa != null) wpath = wa.optString("path", "");
                        }
                        if (!wpath.isEmpty()) allowedPaths.add(wpath);
                    }
                    if ("shell.exec".equals(stepAction)) {
                        allowedShell = true;
                    }
                    /* worker 标注: 未标 = fast (默认大脑) */
                    String worker = s.optString("worker", "fast");
                    usedWorkerTypes.add(worker);
                    if (worker.startsWith("heavy") && workers != null) {
                        Worker hw = workers.get(worker);
                        if (hw == null || !hw.available()) {
                            workerAvailable = false;
                            workerUnavailableReason = "步骤 " + (i + 1) + " 标注 " + worker
                                    + " 但不可用" + (hw == null ? " (未注册)" : " (未就绪)");
                        }
                    }
                }
                /* P4 §6.2: 编排期可用性检查 — 不可用则不出闸, 直接提示 */
                if (!workerAvailable) {
                    note(workerUnavailableReason);
                    transcript.append("【Worker 不可用】").append(workerUnavailableReason).append("\n");
                    fail(workerUnavailableReason);
                    return;
                }
                estTokens = plan.length() * EST_TOKENS_PER_STEP + EST_BASE_TOKENS;
                estSeconds = plan.length() * EST_SEC_PER_STEP;
                JSONObject planLog = j("type", "plan", "loopId", loopId,
                        "steps", plan, "estTokens", estTokens, "estSeconds", estSeconds);
                if (planUnderstanding != null) {
                    try { planLog.put("understanding", planUnderstanding); } catch (Exception silentErr) { android.util.Log.w("AgentLoop", "suppressed", silentErr); }
                }
                log(planLog);
                planApproved = null; planNote = null; // 闸前复位 (先于开闸, 防批准被 park 窗口吞掉)
                changeState(State.PLAN_GATE);
                phase("待确认");
                if (!parkForPlan()) { stopped(); return; }
                if (Boolean.TRUE.equals(planApproved)) { approvedPlanText = formatPlan(plan); break; }
                // 驳回: 补充回灌, 重新出计划
                transcript.append("【用户驳回计划】").append(planNote != null ? planNote : "").append("\n");
                note("计划已驳回" + (planNote != null && !planNote.isEmpty() ? ": " + planNote : ""));
            }

            // ---- EXECUTING ----
            changeState(State.EXECUTING);
            approvedPlan = plan;   // P8: 存计划供 execAction 按索引读 worker
            progress.plan = plan;  progress.currentPlanStep = 0; progress.steps.clear();  // M1b
            planStepIdx = 0;
            phase("执行中");
            String summary = executeSteps(maxSteps());
            if (summary == null) return; // fail/stopped 已处理

            // ---- finish 后直接交付 (2026-07-30: 交付评审/返工循环已移除) ----
            deliver(summary);
        } catch (Exception e) {
            // BUG-5 Phase2: 兜底 — 意料外的 throw (含非法状态转换) 落 FAILED 终态
            // 顺手②: 失败文案带具体原因（MovError 截断 80 字符防超长；透传错误信封精神）
            android.util.Log.wtf("AgentLoop", "意料外异常, 兜底落 FAILED", e);
            String reason = e.getMessage() != null ? e.getMessage()
                    : (e.getClass().getSimpleName() != null ? e.getClass().getSimpleName() : "未知异常");
            failMov(MovError.internal("LOOP_EXCEPTION", "任务失败：" + reason, e));
        }
    }

    /** 执行循环主体: 跑预算内步数, 返回 finish 的 summary; fail/stop/耗尽返回 null */
    private String executeSteps(int budget) {
        finishSummary = null;
        int parseFails = 0;
        int left = budget;
        while (left > 0) {
            if (stopRequested) { stopped(); return null; }
            if (pureExecMs() > maxExecMs()) { fail("执行超时 (10 分钟)"); return null; }

            stepCounter++;
            AiClient.AiResponse resp = chatWithRetry(stepPrompt, buildStepInput(stepCounter));
            track(resp);
            if (!resp.success) {
                if (resp.cancelled) { stopped(); return null; }   // 用户取消: 不重试, 标已停止 (TC-SSE-07)
                failMov(MovError.external("BRAIN_CALL_FAILED", brainErrorMsg(resp), null)); return null;
            }

            ActionParser.Result r = ActionParser.parse(resp.content);
            if (!r.ok) {
                android.util.Log.w("MOV-DIAG", "step-parse-fail: " + r.err
                        + " raw(200):" + resp.content.substring(0, Math.min(200, resp.content.length())));
                parseFails++;
                if (parseFails == 1) {
                    // 第一次失败: 反馈具体错误 + 重试
                    transcript.append("【格式错误】").append(r.err)
                            .append(": ").append(resp.content.substring(0, Math.min(100, resp.content.length())))
                            .append("\n请只输出一个 JSON 动作\n");
                    continue;
                }
                if (parseFails >= MAX_PARSE_FAILS) {
                    // 第二次失败: 降级 Prompt（诚实——能做就 finish，不能做就 ask_user）
                    String rescuePrompt = "你的输出格式始终不对。如果任务已完成, 输出: "
                        + "{\"action\":\"finish\",\"summary\":\"简述已完成的工作\"}。"
                        + "如果任务无法完成, 诚实输出: "
                        + "{\"action\":\"ask_user\",\"text\":\"说明为什么做不了\"}。"
                        + "禁止输出 finish 当任务未完成!";
                    AiClient.AiResponse rescue = brain.chat(rescuePrompt,
                        "你的上一次输出格式不对: " + r.err + "。请按上述格式重新输出。");
                    ActionParser.Result r2 = ActionParser.parse(rescue.content);
                    if (r2.ok) { parseFails = 0; execAction(stepCounter, r2.action); continue; }
                    fail("连续 2 次动作解析失败 (" + r.err + ")");
                    return null;
                }
                continue;
            }
            parseFails = 0;
            left--; // 预算只消耗在合法动作上
            if (!execAction(stepCounter, r.action)) return finishSummary;
            stepsDone++;
        }
        fail("步数达上限 (" + budget + "), 任务未完成");
        return null;
    }

    /** 执行一个动作; 返回 false 表示循环应结束 (finish/fail/stop/revise 重进计划闸由外层状态体现) */
    private boolean execAction(int step, JSONObject a) {
        String action = a.optString("action");
        long t0 = System.currentTimeMillis();
        switch (action) {
            case "ask_user": {
                String q = a.optString("question");
                /* №8: 空/占位问题不发提问卡 (防空内容「…」卡进 journal) */
                if (q == null || q.trim().isEmpty()) {
                    transcript.append("[ask_user] → 跳过: question 为空\n");
                    return true;
                }
                JSONObject askEv = j("type", "ask", "loopId", loopId, "question", q);
                JSONArray opts = a.optJSONArray("options");
                if (opts != null) {
                    try { askEv.put("options", opts); } catch (Exception silentErr) { android.util.Log.w("AgentLoop", "suppressed", silentErr); }
                }
                userAnswer = null;   // 闸前复位 (同计划闸, 防答案被 park 窗口吞掉)
                log(askEv);
                String ans = parkForAnswer();
                if (stopRequested) { stopped(); return false; }
                String shown = ans != null ? ans : "(用户未回复)";
                note("你: " + shown);
                transcript.append("[ask_user] Q: ").append(q).append(" A: ").append(shown).append("\n");
                return true;
            }
            case "revise_plan": {
                JSONArray newPlan = a.optJSONArray("plan");
                if (newPlan == null || newPlan.length() == 0) {
                    transcript.append("[revise_plan] → 拒绝: plan 为空\n");
                    return true;
                }
                /* 修订封顶: 大脑会把 revise_plan 当"再想一下"按钮连按, 烧干步数预算零执行
                   (2026-07-23 咖啡点单现场: 8 张修订卡烧掉 12 步 + 40k tokens) */
                if (reviseCount >= MAX_REVISE_PLANS) {
                    transcript.append("[revise_plan] → 拒绝: 修订次数已用完 (上限 ")
                            .append(MAX_REVISE_PLANS)
                            .append("), 请按当前已批准计划执行, 或输出 finish。\n");
                    return true;
                }
                reviseCount++;
                allowedPaths.clear();
                for (int i = 0; i < newPlan.length(); i++) {
                    JSONObject s = newPlan.optJSONObject(i);
                    if (s == null) continue;
                    String ra = s.optString("action", "");
                    if ("tool.execute".equals(ra)) ra = s.optString("name", ra);
                    if ("file.write".equals(ra)) {
                        allowedPaths.add(s.optString("path"));
                    }
                    if ("shell.exec".equals(ra)) {
                        allowedShell = true;
                    }
                }
                estTokens = newPlan.length() * EST_TOKENS_PER_STEP + EST_BASE_TOKENS;
                estSeconds = newPlan.length() * EST_SEC_PER_STEP;
                log(j("type", "plan", "loopId", loopId,
                        "steps", newPlan, "revised", true,
                        "estTokens", estTokens, "estSeconds", estSeconds));
                planApproved = null; planNote = null; // 闸前复位 (同初始闸, 防批准被吞)
                changeState(State.PLAN_GATE);
                phase("待确认");
                if (!parkForPlan()) { stopped(); return false; }
                if (Boolean.TRUE.equals(planApproved)) {
                    approvedPlanText = formatPlan(newPlan);
                    approvedPlan = newPlan;   // P8: 修订计划也存, 供执行时读 worker
                    progress.plan = newPlan; progress.currentPlanStep = 0; progress.steps.clear();  // M1b
                    planStepIdx = 0;
                    changeState(State.EXECUTING);
                    phase("执行中");
                    return true;
                }
                transcript.append("【用户驳回修订计划】").append(planNote != null ? planNote : "").append("\n");
                changeState(State.EXECUTING); // 继续, 大脑自行调整 (驳回计入 transcript)
                phase("执行中");
                return true;
            }
            case "finish": {
                finishSummary = a.optString("summary");
                return false;
            }
            default: {
                /* P3: tool.execute 统一动作协议 (CONTRACT: Tool §1)
                   格式: {"action":"tool.execute","name":"file.write","args":{...}}
                   旧格式 {"action":"file.write",...} 仍兼容但已无别名系统 */
                String toolName;
                JSONObject toolArgs;
                if ("tool.execute".equals(action)) {
                    toolName = a.optString("name", "");
                    toolArgs = a.optJSONObject("args");
                    if (toolArgs == null) toolArgs = a;
                } else {
                    toolName = action;
                    toolArgs = a;
                }
                ToolRegistry.Tool tool = registry.find(toolName);
                if (tool == null) {
                    stepLog(step, toolName, "", false, "没有此工具或未放行 (UNKNOWN_TOOL)", t0);
                    transcript.append("[").append(toolName)
                            .append("] → 没有此工具或未放行, 请使用 tool.execute + 协议内工具名。\n");
                    return true;
                }
                String canonicalName = tool.name;
                String arg = toolArgs.optString("path", toolArgs.optString("text", ""));
                /* 步骤4: 鉴权中间件 (approval 级别 + pathScope + allowedPaths 白名单) */
                if ("file.write".equals(canonicalName) && !allowedPaths.contains(arg)) {
                    fileWriteApproved = null;   // 闸前复位
                    log(j("type", "filePreview", "loopId", loopId,
                            "path", arg, "content", toolArgs.optString("content"), "outOfPlan", true));
                    boolean writeOk = parkForFileWrite();
                    if (stopRequested) { stopped(); return false; }
                    if (!writeOk) {
                        stepLog(step, canonicalName, arg, false, "计划外写入被用户驳回", t0);
                        transcript.append("[").append(canonicalName).append(" ").append(arg)
                                .append("] → 计划外写入被驳回, 请只用计划内文件或 revise_plan。\n");
                        return true;
                    }
                    allowedPaths.add(arg);   // 用户确认 = 授权该路径
                }
                if ("shell.exec".equals(canonicalName)) {
                    String cmd = toolArgs.optString("cmd", "").trim();
                    int grade = shellGrade(cmd); // 0=白(读) 1=灰(安全写) 2=黑(高危)

                    // 黑名单永远确认——不受 allowedShell 控制，计划批准不能架空
                    if (grade == 2) {
                        shellApproved = null;
                        log(j("type", "shellPreview", "loopId", loopId, "cmd", cmd,
                                "grade", 2, "dangerous", true,
                                "timeoutSec", toolArgs.optInt("timeoutSec", 120)));
                        boolean shellOk = parkForShell();
                        if (stopRequested) { stopped(); return false; }
                        if (!shellOk) {
                            stepLog(step, canonicalName, "", false, "高危命令被用户驳回", t0);
                            transcript.append("[shell.exec] → 高危命令被驳回\n");
                            return true;
                        }
                        // 黑名单不放行后续
                    } else if (!allowedShell) {
                        // 白/灰名单: allowedShell 控制
                        if (grade == 0) {
                            stepLog(step, canonicalName, cmd, true, "白名单自动放行", t0);
                        } else {
                            shellApproved = null;
                            log(j("type", "shellPreview", "loopId", loopId, "cmd", cmd,
                                    "grade", 1, "timeoutSec", toolArgs.optInt("timeoutSec", 120)));
                            boolean shellOk = parkForShell();
                            if (stopRequested) { stopped(); return false; }
                            if (!shellOk) {
                                stepLog(step, canonicalName, "", false, "shell命令被驳回", t0);
                                transcript.append("[shell.exec] → 被驳回\n");
                                return true;
                            }
                            allowedShell = true;
                        }
                    }
                }
                /* P8: 从批准的计划里读当前步骤的 worker 标注 */
                String worker = "fast";
                JSONObject planStep = null;
                if (approvedPlan != null && planStepIdx < approvedPlan.length()) {
                    planStep = approvedPlan.optJSONObject(planStepIdx);
                    if (planStep != null) worker = planStep.optString("worker", "fast");
                }
                planStepIdx++;  // 仅 tool.execute 步骤计数

                /* 步骤5: Worker 路由 — heavy → Hermes 委派; 其余 → tool.handler */
                try {
                    /* 无感工作态: 工具调用开始事件 (技能调用卡「⚡ name · 调用中」, 谁被调用可见) */
                    log(j("type", "tool_call", "loopId", loopId, "name", canonicalName, "arg", arg));
                    ToolRegistry.Result res;
                    if (worker.startsWith("heavy:") && workers != null && workers.containsKey(worker)) {
                        Worker hw = workers.get(worker);
                        String stepDesc = planStep != null ? planStep.optString("desc", goal) : goal;
                        /* M5 禁网实证修正: 原默认 network=false — 但 hermes agent 推理需连云 LLM
                           (DeepSeek), 禁网变真后默认任务必挂 (实证: API call failed Connection error)。
                           Hermes 委派任务需联网推理 → 默认 true; 禁网 (network=false) 是显式隔离选项。 */
                        Worker.WorkerTask task = new Worker.WorkerTask(loopId, step, stepDesc,
                                new JSONObject(), tool.timeoutSec, true, 32000);
                        Worker.WorkerResult wr = hw.run(task);
                        res = new ToolRegistry.Result(wr.ok, wr.text,
                                wr.files != null && wr.files.length > 0 ? wr.files[0] : null);
                    } else {
                        // 快操作静默，慢操作有心跳。tool_result 是唯一完成通知。
                        // Phase 8: 设置中断信号，工具内部可注册进程以支持中断
                        InterruptSignal sig = new InterruptSignal();
                        ToolRegistry.currentSignal.set(sig);
                        final long startMs = System.currentTimeMillis();
                        final boolean[] hbRunning = {true};
                        java.util.concurrent.ScheduledExecutorService hb = null;
                        res = tool.handler.run(toolArgs);
                        // S1: OCR 识别文本统一收口包裹（防文档内容注入慢脑 prompt）
                        res = OcrTextSanitizer.wrapIfOcr(canonicalName, res);
                        ToolRegistry.currentSignal.remove();
                        long durMs = System.currentTimeMillis() - startMs;
                        // 只有 >5s 的操作才记"等待中"状态（被动，不额外发 running 事件）
                        if (durMs > 5000) {
                            log(j("type", "status", "state", "waiting", "tool", canonicalName,
                                    "elapsed", durMs / 1000, "label", (arg.isEmpty() ? "" : " " + arg)));
                        }
                        if (hb != null) { hbRunning[0] = false; hb.shutdownNow(); }
                    }
                    // M2 Phase 9: 统一结果校验 — 硬失败翻 ok=false, 软警告保 ok=true
                    if (res.ok && tool.validator != null) {
                        ToolRegistry.ValidationResult v = tool.validator.validate(toolArgs, res);
                        if (v.hardFail != null) {
                            res = new ToolRegistry.Result(false, "校验失败: " + v.hardFail, res.produced, "VALIDATION_FAILED: " + v.hardFail);
                        } else if (!v.warnings.isEmpty()) {
                            android.util.Log.w("MOV-VALIDATE", canonicalName + " 软警告: " + String.join("; ", v.warnings));
                        }
                    }
                    /* 步骤6: tool_result 落 journal + 进度更新 */
                    stepLog(step, canonicalName, arg, res.ok, res.text, res.aiFeedback, res.reason, t0);
                    // M1b Phase 7: 记录执行进度
                    String stepDesc = (toolArgs != null ? toolArgs.optString("desc", "") : "");
                    if (stepDesc.isEmpty() && planStep != null) stepDesc = planStep.optString("desc", "");
                    int planIdx = progress.matchPlanStep(stepDesc, canonicalName);
                    progress.addStep(planIdx, canonicalName, stepDesc, res.ok, res.aiFeedback != null ? res.aiFeedback : res.text, res.produced, System.currentTimeMillis() - t0);
                    if (res.produced != null) producedFiles.put(res.produced);
                    String forTranscript = "file.read".equals(canonicalName) ? res.text : oneLine(res.text);
                    transcript.append("[").append(canonicalName).append(arg.isEmpty() ? "" : " " + arg)
                            .append("] → ").append(forTranscript).append("\n");
                } catch (Exception e) {
                    stepLog(step, canonicalName, arg, false, "执行异常: " + e.getMessage(), t0);
                    transcript.append("[").append(canonicalName).append("] → 执行异常: ")
                            .append(oneLine(e.getMessage())).append("\n");
                }
                return true;
            }
        }
    }

    // ==================== 计划 ====================

    private JSONObject planUnderstanding;   // 需求理解 (计划卡展示, 批准计划=批准理解)
    private String approvedPlanText;        // 已批准计划文本 (压缩时钉住不丢)
    private boolean compressNoted;          // 上下文压缩提示只发一次

    /**
     * P8: clarify + plan 两阶段。先理解确认, 再出扁平 plan 数组。
     * 兼容: LLM 直接输出含 plan 的 JSON 时跳过 clarify。
     * 返回 plan JSONArray, null = stopped/failed。
     */
    private JSONArray clarifyThenPlan(String baseGoal) {
        planUnderstanding = null;
        String input = baseGoal;
        // ---- 阶段1: clarify (最多2次追问) ----
        int clarifies = 0;
        while (clarifies <= 2) {
            String phase1UserMsg = input + "\n只输出一个 JSON: {\"understanding\":{\"user\":\"给谁用\",\"scenario\":\"什么场景\",\"loop\":\"核心闭环\",\"guess\":\"你猜的\"},\"clarify\":{\"question\":\"若有歧义则问\",\"options\":[\"A\",\"B\"]}}"
                    + "\n目标清晰时 clarify.question 为空字符串。";
            AiClient.AiResponse resp = chatWithRetry(
                    loadPrompt("clarify_prompt.txt", CLARIFY_PROMPT), phase1UserMsg);
            android.util.Log.d("MOV-DIAG", "P1 raw(" + resp.content.length() + "chars): " + resp.content.substring(0, Math.min(300, resp.content.length())));
            track(resp);
            if (!resp.success) {
                if (resp.cancelled) { stopped(); return null; }
                android.util.Log.w("MOV-DIAG", "P1 fail: " + resp.content);
                failMov(MovError.external("BRAIN_CALL_FAILED", brainErrorMsg(resp), null)); return null;
            }
            try {
                String json = ActionParser.extractJson(resp.content);
                if (json == null) { android.util.Log.w("MOV-DIAG", "P1 extractJson=null"); input += "\n未找到 JSON, 请以 { 开头输出。"; continue; }
                JSONObject root = new JSONObject(json);
                // 兼容: LLM 直接给了 plan → 立即返回
                JSONArray directPlan = root.optJSONArray("plan");
                if (directPlan != null && directPlan.length() > 0) {
                    planUnderstanding = root.optJSONObject("understanding");
                    return directPlan;
                }
                JSONObject understanding = root.optJSONObject("understanding");
                JSONObject clarifyObj = root.optJSONObject("clarify");
                String question = clarifyObj != null ? clarifyObj.optString("question", "") : root.optString("clarify", "");
                if (question.isEmpty() || clarifies >= 2) {
                    if (understanding != null) {
                        planUnderstanding = understanding;
                        input += "\n用户理解: " + understanding.optString("user", "") + " / " + understanding.optString("scenario", "") + " / " + understanding.optString("loop", "");
                    }
                    break; // clarify 完毕, 进入阶段2
                }
                clarifies++;
                JSONArray opts = clarifyObj != null ? clarifyObj.optJSONArray("options") : null;
                JSONObject askEv = j("type", "ask", "loopId", loopId, "question", question);
                if (opts != null) try { askEv.put("options", opts); } catch (Exception silentErr) { android.util.Log.w("AgentLoop", "suppressed", silentErr); }
                userAnswer = null;
                log(askEv);
                String ans = parkForAnswer();
                if (stopRequested) { stopped(); return null; }
                input += "\n用户澄清: " + (ans != null ? ans : "(用户未回复, 按最合理理解继续)");
            } catch (Exception e) {
                input += "\nJSON 解析失败: " + oneLine(e.getMessage()) + "。请检查格式。";
            }
        }
        // ---- 阶段2: 出 plan 数组 ----
        input += "\n\n根据以上理解, 输出执行计划 JSON 数组:"
                + "\n[{\"action\":\"tool.execute\",\"name\":\"file.write\",\"args\":{...},\"desc\":\"做什么\",\"worker\":\"fast\"}]"
                + "\n严格规则:"
                + "\n1. 只输出数组, 不要附加任何解释文字"
                + "\n2. args 里只写路径/参数, 禁止放长代码或 HTML"
                + "\n3. 代码内容在执行阶段再生成, 现在只写计划步骤";
        String planArrayPrompt = PLAN_ARRAY_RULES + "\n可用手段:\n" + registry.promptText();
        for (int attempt = 1; attempt <= MAX_PARSE_FAILS; attempt++) {
            AiClient.AiResponse resp = chatWithRetry(planArrayPrompt, input);
            android.util.Log.d("MOV-DIAG", "P2-att" + attempt + " raw(" + resp.content.length() + "chars): " + resp.content.substring(0, Math.min(300, resp.content.length())));
            track(resp);
            if (!resp.success) {
                if (resp.cancelled) { stopped(); return null; }
                android.util.Log.w("MOV-DIAG", "P2-att" + attempt + " fail: " + resp.content);
                failMov(MovError.external("BRAIN_CALL_FAILED", brainErrorMsg(resp), null)); return null;
            }
            try {
                String json = ActionParser.extractJson(resp.content);
                if (json == null) {
                    String snippet = resp.content.length() > 100 ? resp.content.substring(0, 100) : resp.content;
                    android.util.Log.w("MOV-DIAG", "P2-att" + attempt + " extractJson=null raw=" + snippet);
                    input += "\n你的回复中找不到 JSON。请只输出: [{...}] 格式的 JSON 数组。不要加解释文字。";
                    continue;
                }
                JSONArray plan = null;
                try { plan = new JSONArray(json); } catch (Exception e) {
                    try { plan = new JSONObject(json).optJSONArray("plan"); } catch (Exception ex) {}
                }
                if (plan != null && plan.length() > 0) return plan;
                // 自动修复 1: {action:..., name:..., args:{...}} → [{...}]
                try {
                    JSONObject single = new JSONObject(json);
                    if (single.has("action")) {
                        plan = new JSONArray(); plan.put(single);
                        android.util.Log.i("MOV-DIAG", "P2-att" + attempt + " 自动包装(有action)");
                        return plan;
                    }
                    // 自动修复 2: {path:"/x"} 缺 action → 补全为 tool.execute+file.write
                    if (single.has("path") && !single.has("action")) {
                        JSONObject fixed = new JSONObject();
                        fixed.put("action", "tool.execute");
                        fixed.put("name", "file.write");
                        fixed.put("desc", single.optString("desc", single.optString("path","")));
                        JSONObject args = new JSONObject();
                        args.put("path", single.optString("path"));
                        if (single.has("content")) args.put("content", single.optString("content"));
                        fixed.put("args", args);
                        fixed.put("worker", single.optString("worker", "fast"));
                        plan = new JSONArray(); plan.put(fixed);
                        android.util.Log.i("MOV-DIAG", "P2-att" + attempt + " 自动修复(补action+name)");
                        return plan;
                    }
                } catch (Exception ex) {}
                // 精准反馈：告诉 LLM 它输出的是什么，缺少什么
                String snippet = json.length() > 100 ? json.substring(0, 100) + "..." : json;
                android.util.Log.w("MOV-DIAG", "P2-att" + attempt + " invalid. got=" + snippet);
                input += "\n格式不对。你输出的是: " + snippet
                    + "\n正确格式: {\"action\":\"tool.execute\",\"name\":\"file.write\",\"args\":{\"path\":\"文件名\"},\"desc\":\"做什么\",\"worker\":\"fast\"}"
                    + "\n必须包含 action, name, args 三个字段。";
            } catch (Exception e) {
                input += "\nJSON 解析失败: " + oneLine(e.getMessage());
            }
        }
        fail("连续 " + MAX_PARSE_FAILS + " 次计划解析失败");
        return null;
    }

    private String buildStepInput(int step) {
        String t = compressTranscript(transcript.toString());
        return "目标: " + goal + "\n已批准的可写文件: " + allowedPaths
                + (approvedPlanText != null ? "\n已批准计划:\n" + approvedPlanText : "")
                + "\n\n" + progress.toPromptText()
                + "\n\n这是第 " + step + " 次工具调用（预算剩余 " + (maxSteps() - step) + " 次）"
                + (progress.plan != null ? "，当前在计划第 " + (progress.currentPlanStep + 1) + "/"
                    + progress.plan.length() + " 步" : "")
                + "。只输出一个 JSON 动作。"
                + "\n\n【记忆草案】本轮可写最多一行（记忆/todo/error）——用 append_event type=_memory_draft 写（超一行拒写，不强制）。"
                + causalMemorySuffix()
                + memoryCoverSuffix();
    }

    /** 记忆覆盖冻结注入（工单7 G14，DESIGN_MEMORY_LAYERS v2 §六）：memoryCover 预算内逐字/塌缩摘要，
     *  § 连接成【记忆】段注入上下文。纯读 journal；房间无草案不注入（不占 token）；失败静默。 */
    private String memoryCoverSuffix() {
        try {
            Journal j = memoryJournal;
            if (j == null) {
                if (appContext == null) return "";
                // 工单7 G14 打回修复：journal 真理源在 StorageManager 外部目录（getExternalFilesDir/mov/rooms），
                // 与 serve / McpProvider / 真机一致；旧用内部 getFilesDir/rooms 造成 cover 恒空（真机实证打回）。
                j = new Journal(new com.hermes.android.StorageManager(appContext).getRoomsDir());
            }
            org.json.JSONArray cover = j.memoryCover(roomId, Journal.COVER_BUDGET_DEFAULT);
            if (cover.length() == 0) return "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < cover.length(); i++) {
                String t = cover.optJSONObject(i).optString("text", "").trim();
                if (t.isEmpty()) continue;
                if (sb.length() > 0) sb.append('§');
                sb.append(t);
            }
            return sb.length() == 0 ? "" : "\n\n【记忆】" + sb;
        } catch (Exception e) {
            android.util.Log.w("AgentLoop", "记忆覆盖注入失败: " + e.getMessage());
            return "";
        }
    }

    /** 因果记忆冻结注入（本地因果记忆编译器）：活性钩子/强关联/到期提醒，≤5 行；失败静默。 */
    private String causalMemorySuffix() {
        try {
            com.hermes.android.causal.CausalEngine ce =
                    com.hermes.android.toolprovider.CausalToolProvider.engine();
            if (ce == null) return "";
            String cm = com.hermes.android.causal.CausalPromptBuilder.build(ce,
                    com.hermes.android.toolprovider.CausalToolProvider.ROOM, 5);
            return cm.isEmpty() ? "" : "\n\n" + cm;
        } catch (Exception e) {
            android.util.Log.w("AgentLoop", "因果记忆注入失败: " + e.getMessage());
            return "";
        }
    }

    /** 大脑调用 + 一次网络重试 (手机网络抖动是常态, 单次失败不该判任务死刑);
       配置错误(未配置/key 无效)不重试 — 重试只会写两条误导性日志 */
    private AiClient.AiResponse chatWithRetry(String systemPrompt, String input) {
        AiClient.AiResponse resp = brain.chat(systemPrompt, input);
        if (!resp.success && !stopRequested && isTransientNetError(resp.content)) {
            note("网络抖动, 2 秒后重试大脑调用… (" + oneLine(resp.content) + ")");
            parkedMs += 2000; // 重试等待不计入纯执行时长
            try { Thread.sleep(2000); } catch (InterruptedException e) { return resp; }
            resp = brain.chat(systemPrompt, input);
        }
        /* 网络类错误重试耗尽 → 「已暂停·可续跑」(红线: 禁直接 fail);
           AUTH/MODEL_CONFIG/RUNTIME 维持 fail */
        if (!resp.success && !stopRequested && !resp.cancelled
                && resp.errorClass != null
                && com.hermes.android.ai.StreamWatchdog.isRecoverable(resp.errorClass)) {
            Boolean resume = parkForResume(oneLine(resp.content));
            if (stopRequested) return resp;
            if (Boolean.TRUE.equals(resume)) {
                note("续跑: 从断点重连大脑…");
                return chatWithRetry(systemPrompt, input);
            }
        }
        return resp;
    }

    /** 计划外 shell 闸同款 park: 暂停等待 [立即续跑]/[放弃]; true=续跑 */
    private volatile Boolean resumeApproved;

    /** 网络恢复/用户点续跑 → 断点续跑 (stepsDone/producedFiles/transcript 不重置) */
    public void respondResume(boolean approved) {
        resumeApproved = approved;
        synchronized (gateLock) { gateLock.notifyAll(); }
    }

    private Boolean parkForResume(String reason) {
        resumeApproved = null;
        changeState(State.PAUSED);
        phase("已暂停 · 可续跑");
        log(j("type", "paused", "loopId", loopId,
                "reason", reason, "stepsDone", stepCounter,
                "produced", producedFiles));
        long t0 = System.currentTimeMillis();
        synchronized (gateLock) {
            while (resumeApproved == null && !stopRequested) {
                /* KI-001 修复: 对齐其他闸 10 分钟超时兜底, 防暂停卡 DOM 被删后永久死锁 */
                if (System.currentTimeMillis() - t0 > PLAN_GATE_TIMEOUT_MS) {
                    note("暂停超时未续跑, 自动停止");
                    break;
                }
                try { gateLock.wait(1000); } catch (InterruptedException e) { break; }
            }
        }
        parkedMs += System.currentTimeMillis() - t0;
        if (Boolean.TRUE.equals(resumeApproved)) {
            changeState(State.EXECUTING);
            phase("执行中");
            log(j("type", "note", "loopId", loopId, "text", "已续跑 (断点: 第 " + stepCounter + " 步)"));
        }
        return resumeApproved;
    }

    private static boolean isTransientNetError(String err) {
        if (err == null) return false;
        return err.contains("超时") || err.contains("abort") || err.contains("Socket")
                || err.contains("onnection") || err.contains("网络") || err.contains("timed out");
    }

    /** 压缩: 超 16k 钉住头部(早期上下文)截中段 — 旧版只留尾部, 计划/已读文件会蒸发 */
    private String compressTranscript(String t) {
        if (t.length() <= 16000) return t;
        if (!compressNoted) {
            compressNoted = true;
            note("🗜️ 上下文已压缩: 保留了开头和最近进展, 中间步骤省略");
            // P6 记忆 L2 抢救（DESIGN_MEMORY_LAYERS 律①: 先抢救后压缩）：
            // 压缩前把当前进度抽进草案区（_memory_draft, kind=todo），压缩后关键仍可检索。
            try {
                String prog = progress.toPromptText().replace("\n", " ").trim();
                if (prog.length() > 180) prog = prog.substring(0, 180);
                new Journal(new com.hermes.android.StorageManager(
                        HermesApplication.getAppContext()).getRoomsDir())
                        .appendDraft(roomId, "压缩抢救-当前进度: " + prog, "todo");
            } catch (Exception e) {
                android.util.Log.w("AgentLoop", "L2 抢救草案失败: " + e.getMessage());
            }
        }
        return compressText(t);
    }

    /** 纯函数版压缩 (测试用): 头 1500 + 尾 13000 */
    public static String compressText(String t) {
        if (t.length() <= 16000) return t;
        return t.substring(0, 1500) + "\n…(中段已压缩, 头部保留)\n" + t.substring(t.length() - 13000);
    }

    /** 计划格式化为钉住文本 (压缩时随每步提示大脑, 防"忘了计划") */
    private static String formatPlan(JSONArray plan) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < plan.length(); i++) {
            JSONObject s = plan.optJSONObject(i);
            if (s == null) continue;
            sb.append(i + 1).append(". ").append(s.optString("action"));
            String path = s.optString("path");
            if (!path.isEmpty()) sb.append(" ").append(path);
            String desc = s.optString("desc");
            if (!desc.isEmpty()) sb.append(" — ").append(desc);
            sb.append("\n");
        }
        return sb.toString();
    }

    // ==================== 暂停 (挂起暂停总时长计时) ====================

    private boolean parkForPlan() {
        /* 注意: planApproved/planNote 的复位必须在 state=PLAN_GATE 之前由调用方完成 —
           在这里复位会吞掉"闸已开但 park 尚未进入"窗口内到达的批准 (真机等 10 分钟超时) */
        long t0 = System.currentTimeMillis();
        boolean ok = false;
        synchronized (gateLock) {
            while (planApproved == null && !stopRequested) {
                if (System.currentTimeMillis() - t0 > PLAN_GATE_TIMEOUT_MS) {
                    note("计划超时未批准, 自动停止");
                    break;
                }
                try { gateLock.wait(1000); } catch (InterruptedException e) { break; }
            }
            ok = planApproved != null && !stopRequested;
        }
        parkedMs += System.currentTimeMillis() - t0; // 计划闸停留与 ask_user 一样不计入纯执行时长
        return ok;
    }

    /** P1: 写入预览挂起 (复用计划闸 wait/notify 模式); true=用户确认写入 */
    private boolean parkForFileWrite() {
        /* 注意: fileWriteApproved 的复位必须在 filePreview 事件发出前由调用方完成 */
        long t0 = System.currentTimeMillis();
        synchronized (gateLock) {
            while (fileWriteApproved == null && !stopRequested) {
                if (System.currentTimeMillis() - t0 > PLAN_GATE_TIMEOUT_MS) {
                    note("写入确认超时, 视为驳回");
                    break;
                }
                try { gateLock.wait(1000); } catch (InterruptedException e) { break; }
            }
        }
        parkedMs += System.currentTimeMillis() - t0; // 与计划闸一样不计入纯执行时长
        return Boolean.TRUE.equals(fileWriteApproved);
    }

    /** 计划外 shell.exec 确认挂起 (复用 fileWrite 闸 wait/notify 模式); true=用户批准 */
    private boolean parkForShell() {
        /* 注意: shellApproved 的复位必须在 shellPreview 事件发出前由调用方完成 */
        long t0 = System.currentTimeMillis();
        synchronized (gateLock) {
            while (shellApproved == null && !stopRequested) {
                if (System.currentTimeMillis() - t0 > PLAN_GATE_TIMEOUT_MS) {
                    note("shell 确认超时, 视为驳回");
                    break;
                }
                try { gateLock.wait(1000); } catch (InterruptedException e) { break; }
            }
        }
        parkedMs += System.currentTimeMillis() - t0;
        return Boolean.TRUE.equals(shellApproved);
    }

    private String parkForAnswer() {
        /* 注意: userAnswer 的复位必须在 ask 事件发出前由调用方完成 (同计划闸) */
        long t0 = System.currentTimeMillis();
        synchronized (gateLock) {
            while (userAnswer == null && !stopRequested) {
                long left = ASK_TIMEOUT_MS - (System.currentTimeMillis() - t0);
                if (left <= 0) break;
                try { gateLock.wait(Math.min(left, 1000)); } catch (InterruptedException e) { break; }
            }
        }
        parkedMs += System.currentTimeMillis() - t0;
        String a = userAnswer; userAnswer = null;
        return a;
    }

    private long pureExecMs() {
        return System.currentTimeMillis() - execStartMs - parkedMs;
    }

    // ==================== 日志与收尾 ====================

    /** 安全 JSON 构造 (org.json put 抛受检异常, 统一吞掉) */
    private static JSONObject j(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(String.valueOf(kv[i]), kv[i + 1]);
        } catch (Exception silentErr) { android.util.Log.w("AgentLoop", "suppressed", silentErr); }
        return o;
    }

    private void log(JSONObject j) {
        try { sink.onLog(j); } catch (Exception silentErr) { android.util.Log.w("AgentLoop", "suppressed", silentErr); }
    }

    private void phase(String p) {
        log(j("type", "phase", "loopId", loopId, "phase", p));
    }

    private void note(String text) {
        log(j("type", "note", "loopId", loopId, "text", text));
    }

    private void stepLog(int seq, String name, String arg, boolean ok, String result, long t0) {
        stepLog(seq, name, arg, ok, result, null, null, t0);
    }
    private void stepLog(int seq, String name, String arg, boolean ok, String result, String aiFeedback, long t0) {
        stepLog(seq, name, arg, ok, result, aiFeedback, null, t0);
    }
    private void stepLog(int seq, String name, String arg, boolean ok, String result,
                         String aiFeedback, String reason, long t0) {
        long dur = System.currentTimeMillis() - t0;
        log(j("type", "step", "loopId", loopId,
                "seq", seq, "name", name, "arg", arg, "ok", ok,
                "result", result, "durMs", dur,
                "reason", reason != null ? reason : JSONObject.NULL,
                "aiFeedback", aiFeedback != null ? aiFeedback : "",
                "promptTokens", totalPrompt, "completionTokens", totalCompletion,
                "elapsedSec", pureExecMs() / 1000));
    }

    private void deliver(String summary) {
        phase("已交付");
        JSONObject d = j("type", "deliver", "audit", true, "loopId", loopId,
                "goal", goal, "summary", summary, "files", producedFiles,
                "promptTokens", totalPrompt, "completionTokens", totalCompletion,
                "elapsedSec", pureExecMs() / 1000,
                "estTokens", estTokens, "estSeconds", estSeconds);
        try {
            /* 功能自检清单 (M-QUALITY: finish summary 的 ✅/⚠️ 行, 供交付卡结构化展示) */
            org.json.JSONArray checklist = new org.json.JSONArray();
            for (ProductDigest.CheckItem item : ProductDigest.parseChecklist(summary)) {
                checklist.put(new JSONObject().put("real", item.real).put("text", item.text));
            }
            d.put("checklist", checklist);
        } catch (Exception silentErr) { android.util.Log.w("AgentLoop", "suppressed", silentErr); }
        /* P8 DeliveryGate v1: ComplianceScanner 扫描产物 */
        try {
            String[] fileNames = new String[producedFiles.length()];
            for (int i = 0; i < producedFiles.length(); i++) fileNames[i] = producedFiles.optString(i);
            ComplianceScanner.ContentProvider cp = name -> {
                try { return tools.fileRead(roomId, name); } catch (Exception e) { return null; }
            };
            ComplianceScanner.Report report = new ComplianceScanner()
                    .scan(fileNames, cp, false);
            JSONObject compliance = new JSONObject()
                    .put("verdict", report.verdict.name())
                    .put("passedFiles", report.passedFiles)
                    .put("totalFiles", report.totalFiles)
                    .put("defectCount", report.defects.size())
                    .put("summary", report.summary());
            if (!report.defects.isEmpty()) {
                org.json.JSONArray defectList = new org.json.JSONArray();
                for (ComplianceScanner.Defect def : report.defects) {
                    defectList.put(new JSONObject()
                            .put("file", def.file)
                            .put("rule", def.rule)
                            .put("detail", def.detail));
                }
                compliance.put("defects", defectList);
            }
            d.put("compliance", compliance);
        } catch (Exception silentErr) { android.util.Log.w("AgentLoop", "suppressed", silentErr); }
        log(d);
        /* P6: 遥测埋点 (只写 journal, 不进 UI — MovRender 过滤 _ 前缀) */
        try {
            String primaryWorker = usedWorkerTypes.isEmpty() ? "none"
                    : usedWorkerTypes.contains("fast") && usedWorkerTypes.size() == 1 ? "fast"
                    : String.join(",", usedWorkerTypes);
            JSONObject telemetry = j("type", "_telemetry", "loopId", loopId,
                    "payload", new JSONObject()
                            .put("worker", primaryWorker)
                            .put("planSteps", producedFiles.length() > 0 || stepsDone > 0 ? stepsDone : 0)
                            .put("producedCount", producedFiles.length())
                            .put("promptTokens", totalPrompt)
                            .put("completionTokens", totalCompletion)
                            .put("elapsedSec", pureExecMs() / 1000)
                            .put("estTokens", estTokens)
                            .put("estSeconds", estSeconds));
            sink.onLog(telemetry);
        } catch (Exception silentErr) { android.util.Log.w("AgentLoop", "suppressed", silentErr); }
        /* 交付事件落盘后再置终态 — 否则观察者(测试/UI)会在 deliver 事件前读到 DONE */
        // BUG-5 Phase1: 终态竞速守卫 — 先到者胜 (e.g. STOPPED 后不覆盖 DONE)
        if (ctx.getState().isTerminal()) return;
        /* 工单24 自动通道: 交付后同域成功 ≥2 次才自动提炼候选（防噪声：闲聊/单次任务零触发）。
           异步旁路，失败静默不阻塞交付。 */
        try {
            String domain = (goal != null && goal.length() > 8) ? goal.substring(0, 8) : goal;
            int n = domainDeliverCount(domain);
            if (n >= 2) {
                final String fRoom = roomId;
                new Thread(() -> {
                    try {
                        com.hermes.android.skill.SkillStore ss =
                                new com.hermes.android.skill.SkillStore(
                                        com.hermes.android.agent.AgentLoop.appContext);
                        org.json.JSONArray existing = new org.json.JSONArray(ss.listSkillsJson());
                        org.json.JSONObject page = distillerJournal().replay(fRoom, 200);
                        org.json.JSONObject dd = page.optJSONObject("data");
                        org.json.JSONArray evs = (dd != null) ? dd.optJSONArray("events") : null;
                        if (evs == null) return;
                        org.json.JSONObject r = com.hermes.android.skill.SkillDistiller.distill(
                                brain, evs, existing);
                        if ("save".equals(r.optString("action"))) {
                            android.util.Log.i("SkillDistiller", "自动候选: " + r.optJSONObject("skill")
                                    .optString("name", "?") + "（同域已成功 " + n + " 次）");
                        }
                    } catch (Exception ignored) {}
                }, "skill-distiller-auto").start();
            }
        } catch (Exception ignored) {}
        changeState(State.DONE);
    }

    /** 工单24: 同域成功次数统计（按 goal 前缀，防噪声触发） */
    /** 工单24: 同域成功次数统计（按 goal 前缀，防噪声触发） */
    private int domainDeliverCount(String domain) {
        try {
            org.json.JSONObject page = distillerJournal().replay(roomId, 500);
            org.json.JSONObject dd = page.optJSONObject("data");
            org.json.JSONArray evs = (dd != null) ? dd.optJSONArray("events") : null;
            if (evs == null) return 0;
            int n = 0;
            for (int i = 0; i < evs.length(); i++) {
                org.json.JSONObject ev = evs.optJSONObject(i);
                if (ev == null || !"deliver".equals(ev.optString("type", ""))) continue;
                String g = ev.optString("goal", "");
                if (g != null && g.length() > 8 && g.substring(0, 8).equals(domain)) n++;
            }
            return n;
        } catch (Exception e) { return 0; }
    }

    /** 工单24: 提炼器用的 journal（memoryJournal 兜底同款——StorageManager 外部目录） */
    private com.hermes.android.agent.Journal distillerJournal() {
        com.hermes.android.agent.Journal j = memoryJournal;
        if (j == null && appContext != null) {
            j = new com.hermes.android.agent.Journal(
                    new com.hermes.android.StorageManager(appContext).getRoomsDir());
        }
        return j;
    }

    private void fail(String reason) {
        // BUG-5 Phase1: 终态竞速守卫 — 用户喊停最高意志, 后续 fail 不覆盖
        if (ctx.getState().isTerminal()) return;
        changeState(State.FAILED);
        phase("失败");
        /* 失败三问: 人话原因 + 部分产物(files) + 进度(stepsDone) + 原目标(goal, 供一键重开) */
        log(j("type", "fail", "audit", true, "loopId", loopId, "reason", reason,
                "retryable", false,
                "files", producedFiles, "stepsDone", stepsDone, "goal", goal,
                "promptTokens", totalPrompt, "completionTokens", totalCompletion,
                "elapsedSec", pureExecMs() / 1000));
    }

    /** 结构化错误版本: 带 MovError 分类, INTERNAL 会上报 ErrorReporter */
    private void failMov(MovError err) {
        // BUG-5 Phase1: 终态竞速守卫
        if (ctx.getState().isTerminal()) return;
        changeState(State.FAILED);
        phase("失败");
        // 采样上报: INTERNAL全报, EXTERNAL去重, USER只计数
        try {
            com.hermes.android.ErrorReporter.Category cat;
            switch (err.kind) {
                case USER: cat = com.hermes.android.ErrorReporter.Category.USER_ERROR; break;
                case EXTERNAL: cat = com.hermes.android.ErrorReporter.Category.AI_ERROR; break;
                default: cat = com.hermes.android.ErrorReporter.Category.INTERNAL_ERROR; break;
            }
            com.hermes.android.ErrorReporter.reportSampled(cat, "AgentLoop." + loopId, err.code);
        } catch (Exception ignored) {}
        log(j("type", "fail", "audit", true, "loopId", loopId,
                "errorKind", err.kind.name(), "errorCode", err.code,
                "retryable", err.retryable, "reason", err.msg,
                "files", producedFiles, "stepsDone", stepsDone, "goal", goal,
                "promptTokens", totalPrompt, "completionTokens", totalCompletion,
                "elapsedSec", pureExecMs() / 1000));
    }

    private void stopped() {
        // BUG-5 Phase1: 终态竞速守卫 (与 fail/deliver 对称)
        if (ctx.getState().isTerminal()) return;
        changeState(State.STOPPED);
        phase("已停止");
        log(j("type", "stopped", "audit", true, "loopId", loopId,
                "goal", goal, "files", producedFiles, "stepsDone", stepsDone,
                "promptTokens", totalPrompt, "completionTokens", totalCompletion,
                "elapsedSec", pureExecMs() / 1000));
    }

    private void track(AiClient.AiResponse resp) {
        if (resp != null) {
            totalPrompt += Math.max(0, resp.promptTokens);
            totalCompletion += Math.max(0, resp.completionTokens);
        }
    }

    /** Shell 命令分级: 0=白(读,自动) 1=灰(安全写,可记忆) 2=黑(高危,永远确认) */
    private static int shellGrade(String cmd) {
        if (cmd == null || cmd.trim().isEmpty()) return 2;
        String c = cmd.trim().split("\\s+")[0]; // 取命令名（第一个词）
        // 红线硬编码: 破坏性命令永不信任本地文件, RulesManager JSON 改不了
        if (com.hermes.android.RulesManager.isRedline(cmd.trim())) return 2;
        // 黄线 JSON 可配: 用户自定义需确认的命令 (如 curl, pip install)
        try {
            if (com.hermes.android.RulesManager.get().isShellConfirmRequired(cmd.trim())) return 1;
        } catch (Exception ignored) {}
        // 白名单: 只读命令（tee/sed 有写能力，不放这里）
        if (c.matches("ls|cat|which|echo|pwd|du|df|ps|whoami|uname|id|env|printenv|date|uptime|free|wc|head|tail|file|stat|find|grep|awk|sort|uniq|cut|tr|diff|comm|join|paste|xargs|basename|dirname|realpath|readlink"))
            return 0;
        // 黑名单: 高危命令,永远单次确认
        if (c.matches("rm|kill|reboot|shutdown|dd|mkfs|apt|apt-get|dpkg|rpm|yum|pacman|zypper|systemctl|service|init|poweroff|halt"))
            return 2;
        // 灰名单: 安全写操作,可记忆
        return 1;
    }

    /** M4 Phase 5: 从 file list JSON 里挑前2个文本文件自动读前2000字注入计划 */
    private String fileContext(String fileList) {
        if (fileList == null || fileList.trim().isEmpty() || "[]".equals(fileList.trim())) return "";
        try {
            org.json.JSONArray arr = new org.json.JSONArray(fileList);
            int count = 0;
            StringBuilder sb = new StringBuilder("\n\n═══ 已有文件内容 ═══\n");
            for (int i = 0; i < arr.length() && count < 2; i++) {
                org.json.JSONObject f = arr.optJSONObject(i);
                if (f == null) continue;
                if (f.optBoolean("isDir")) continue;
                String fn = f.optString("name", "");
                if (fn.isEmpty() || fn.endsWith(".apk") || fn.endsWith(".png")) continue;
                String content = tools.fileRead(roomId, fn);
                if (content == null || content.startsWith("ERROR:")) continue;
                String preview = content.length() > 2000 ? content.substring(0, 2000) : content;
                sb.append("── ").append(fn).append(" ──\n").append(preview).append("\n");
                if (content.length() > 2000) sb.append("…(已截断)\n");
                count++;
            }
            sb.append("═══ 文件内容结束 ═══");
            return count > 0 ? sb.toString() : "";
        } catch (Exception e) { return ""; }
    }

    /** M4 Phase 3: 环境快照 — AI 知道屏幕、Linux工具、管理员规则 */
    private String envSnapshot() {
        StringBuilder sb = new StringBuilder();
        sb.append("房间: ").append(roomId).append("\n");
        try {
            if (appContext != null) {
                android.view.WindowManager wm = (android.view.WindowManager)
                    appContext.getSystemService(android.content.Context.WINDOW_SERVICE);
                android.graphics.Point p = new android.graphics.Point();
                wm.getDefaultDisplay().getSize(p);
                float density = appContext.getResources().getDisplayMetrics().density;
                sb.append("屏幕: ").append(p.x).append("×").append(p.y).append(" | 密度 ").append(density).append("\n");
            }
        } catch (Exception e) { sb.append("屏幕: 未知\n"); }
        sb.append("设备: ").append(android.os.Build.MODEL).append(" | Android ").append(android.os.Build.VERSION.SDK_INT).append("\n");
        boolean linuxOk = appContext != null && com.hermes.android.linux.RootfsManager.isReady(appContext);
        sb.append("Linux 工具: ").append(linuxOk ? "python3 ✓ node ✓ gcc ✓ git ✓ jq ✓ curl ✓ (Ubuntu 24.04)" : "未安装").append("\n");
        try {
            java.util.Set<String> dis = com.hermes.android.RulesManager.get().deviceDisabledCapabilities;
            sb.append("管理员规则: 禁用=").append(dis.isEmpty() ? "无" : String.join(",", dis)).append("\n");
        } catch (Exception e) { sb.append("管理员规则: 未知\n"); }
        sb.append("═══ 环境结束 ═══");
        return sb.toString();
    }

    private static String oneLine(String s) {
        if (s == null) return "";
        String l = s.replace('\n', ' ');
        return l.length() > 120 ? l.substring(0, 120) + "…" : l;
    }

    /** 工单13: 大脑调用失败 → 面向新人的明确报错。
        配置类错误(AUTH/MODEL_CONFIG/PROVIDER_API)透传具体原因 + 重试指引,
        不再统一笼统文案「AI 服务暂时不可用」(新人无从知道是 key 填错)。 */
    private static String brainErrorMsg(AiClient.AiResponse resp) {
        String detail = oneLine(resp != null ? resp.content : "");
        String hint = null;
        if (resp != null && resp.errorClass != null) {
            switch (resp.errorClass) {
                case PROVIDER_AUTH:
                    hint = "AI 鉴权失败（API Key 无效或已过期）——请到「设置 → 模型管理」核对 API Key，改完重新下达任务";
                    break;
                case MODEL_CONFIG:
                    hint = "AI 模型配置有误——请到「设置 → 模型管理」核对模型名/Base URL，改完重新下达任务";
                    break;
                case PROVIDER_API:
                    hint = "AI 服务返回错误——请到「设置 → 模型管理」用「测连接」检查后重新下达任务";
                    break;
                default: break;
            }
        }
        String base = hint != null ? hint : "AI 服务暂时不可用，请稍后重试";
        return detail.isEmpty() || detail.equals("无详细信息") ? base : base + " · " + detail;
    }

    // ==================== Prompt ====================

    private static final String PLAN_RULES =
            "你是 MOV agent 的大脑, 运行在一个 Android 房间的 agentic 循环里。"
            + "把用户目标拆成执行计划, 只输出 JSON, 不要输出其他任何文字:\n"
            + "{\"understanding\":{\"user\":\"给谁用\",\"scenario\":\"什么场景下用\",\"loop\":\"核心闭环(一句话)\",\"guess\":\"你猜的,可能错的部分\"},\"plan\":[{\"action\":\"file.write\",\"path\":\"文件名\",\"desc\":\"这一步做什么\",\"worker\":\"fast\"}]}\n"
            + "规则: file.write 的 path 是你计划创建/修改的文件, 后续执行只允许写这些文件;"
            + "计划必须完整覆盖到交付 — 修改类任务 = 读取(如需要)+file.write(每个要改的文件都有步)+"
            + "app.package(需要 APK 时), 禁止只规划读取/调查步骤;"
            + "worker 标注: 每步标 \"worker\":\"fast\"(默认,云端模型);"
            + "开放重活（目标明确但步骤写不出的活：数据分析/多文件项目/深度调研/需要自主决策的连续操作）"
            + "规划为 tool.execute + hermes.task 一步（goal 写结果不写步骤，由内嵌 Hermes 自主拆解执行，产物回房间 /room）;"
            + "hermes.task 需要 Linux 环境+Hermes 已安装, 不可用时计划会被拒绝;"
            + "小游戏/网页类需求可规划为多文件项目(HTML+CSS+JS+图片); app.package 打包时自动内联;"
            + "工作区里的 .apk 都由同名 .html 打包而来 — 用户要求改游戏/改应用时,"
            + "计划 = 修改源 .html + 重新 app.package, 不要问用户玩的是 html 还是 apk;"
            + "APK 安装用 app.install(原生安装, 无需 ADB), 禁止用 shell.exec adb install;"
            + "涉及手机硬件操作(手电/音量/亮度/震动/语音/通知/启动应用/查询状态)时,"
            + "直接计划 device.cmd 真做, 禁止写成 HTML 模拟。"
            + "🔧 环境检测（必须第一步）: 每个计划的第一条动作必须是检测所需工具是否存在。"
            + "用 shell.exec 执行 'which <tool> || command -v <tool>'。"
            + "缺失则自动安装: apt install / pip install / git clone / curl 下载。"
            + "禁止因为工具缺失就降级方案或放弃。"
            + "你的房间是完整 Ubuntu 24.04，什么都能装。"
            + "能力边界 (CONTRACT_CAPABILITY 压缩版, 对照执行):"
            + "✅能做全做=多文件HTML+CSS+JS项目(自动内联)→APK+localStorage+IndexedDB+文件读写+设备控制"
            + "(手电/音量/亮度/震动/TTS/通知/剪贴板/电量/截屏/定位/通讯录/短信/应用启动)"
            + "+APK内浏览器能力(HTTPS联网fetch/相机getUserMedia(前置默认; 扫一扫/拍照用后置须写"
            + "facingMode:'environment')/录音recordAudio走MovShell"
            + "/体感传感器DeviceMotion/音频播放/WebGL/手柄Gamepad)"
            + "+APK内JS桥MovShell(全部同步返回值, 严禁当回调用): "
            + "notify(title,text)→\"ok\"/\"no-permission\"; vibrate(ms)→布尔(false=无马达), hasVibrator()→布尔; "
            + "recordAudio(秒)→\"recording:N\"/\"err\", 到点后 recordResult()→\"ok:字节:路径\"/\"err\", "
            + "recordBase64()→base64或null(录音中返回null)。语音消息正确写法(轮询防竞态): "
            + "recordAudio(3) → 每500ms查一次recordBase64()直到非null(最多查10次) → "
            + "存'data:audio/mp4;base64,'+b64(容器m4a不是ogg), 禁止用固定setTimeout猜完成时间;"
            + "+内嵌Ubuntu24.04完整Linux就是你的房间: 房间=guest里的项目目录/room,"
            + "与房间文件同一批 (file.write写的shell直接可见可跑, shell产物file.read直接可读, 零搬运);"
            + "shell.exec是主工具 (python3/git/node/jq/curl/gcc/apt/联网抓取/真实构建齐全),"
            + "file.*只是同目录的快捷方式; 已授权时可读写/sdcard(含Obsidian vault路径);"
            + "🔧 环境自愈（必须第一步）: 每个任务的第一步必须检测所需工具(which/command -v)。"
            + "缺失 → 自动安装: apt install / pip install --break-system-packages / git clone / curl。"
            + "常见: Flutter→git clone /opt/flutter; JDK→apt install openjdk-17-jdk;"
            + "Node包→npm install -g; 编译→apt install build-essential; 失败→换镜像源。"
            + "禁止因为工具缺失就直接放弃——你的房间是完整 Ubuntu 24.04。"
            + "shell纪律=大输出重定向到文件再grep/tail分段看, 长构建timeoutSec给足(最大600秒),"
            + "产物落在/room即房间文件, 用 file.write 或 shell 直接产出都算交付;"
            + "pip纪律=Ubuntu24系统python禁止pip直装(PEP668), 装包用 python3 -m venv 建虚拟环境"
            + "或 pip install --break-system-packages;"
            + "重任务委派=shell.exec 里可调内嵌 Hermes agent (深度调研/大文件生成/多步骤自动化):"
            + "~/.hermes-venv/bin/hermes -z '<任务描述>' (headless 单发, 自动批准工具, 模型配置已注入;"
            + "timeoutSec 给足 300-600; 它在 /room 里干活, 产物直接留在房间);"
            + "+全栈交付=可写真实后端 (FastAPI/Express), 房间里本地起服务 curl 自测,"
            + "再 ssh/scp 部署到用户服务器 (movssh '远端命令' / movscp 本地文件 [远端目录];"
            + "需用户先在设置页配好部署服务器, 未配置→ask_user 引导), APK/前端经 HTTPS 对接;"
            + "部署纪律=服务用 systemd unit 或 nohup+日志落盘守护, 部署后必须 curl 健康检查再交付,"
            + "长部署命令 timeoutSec 给足; 提示用户防火墙开端口; 有域名→nginx 反代+certbot 签证书;"
            + "无域名→诚实说明 WebView 拦明文 HTTP, 需 HTTPS/自签信任方案, 不许假装能直连;"
            + "⚠️带条件=APK内明文HTTP被系统拦(targetSdk36, 须服务器上HTTPS或走代理), "
            + "多用户/账号体系界面、财务系统(无后端, 必须在计划里明示「演示版」及边界);"
            + "❌做不了=打包APK内定位/支付接口/应用推送"
            + " — 禁止闷头糊界面, 先说明做不到并给替代(如交付 server.js+部署说明 或 收款码图片方案);"
            + "完成度标准: 承诺的功能全部真实现, 禁止占位符/桩代码/TODO/色块当图片/按钮无响应。"
            + "理解闸: 当目标存在多种合理的场景解读(给谁用/在哪用不明确, 如「做个点单应用」"
            + "可能是顾客扫码用也可能是老板记账用)时, 禁止猜, 改输出 "
            + "{\"clarify\":{\"question\":\"一句话确认问题\",\"options\":[\"最可能的选项A\",\"选项B\",\"选项C\"]}}, "
            + "options 给 2-3 个用户最可能选的具体选项(不是「是/否」), 拿到回答后再出计划;"
            + "只有唯一合理解读时才直接出计划, 并在 understanding.guess 里写明你猜的部分。";

    /** P8: Phase 1 clarify 专用 prompt — 不提 plan, 不和 PLAN_RULES 冲突 */
    private static final String CLARIFY_PROMPT =
            "你是 MOV agent 的大脑。分析用户目标，只输出一个 JSON: "
            + "{\"understanding\":{\"user\":\"给谁用\",\"scenario\":\"什么场景\",\"loop\":\"核心闭环\",\"guess\":\"你猜的\"},"
            + "\"clarify\":{\"question\":\"若有歧义则问\",\"options\":[\"A\",\"B\"]}}"
            + "目标清晰时 clarify.question 为空字符串。不要输出 plan 字段，不要附加其他文字。\n"
            + "提炼契约 (确认结构化, DESIGN_DISTILLATION): 若有歧义, question 必须提炼两要素 — "
            + "①目标: 用户要答案/选项/报告/东西中的哪一种; ②验收标准: 什么样算好 "
            + "(一句话答案? 选项卡? 结论+依据+不确定项三段的结构化报告?); 让用户确认后再执行。\n";

    /** P8: Phase 2 独立 prompt — 只出步骤数组，不和 PLAN_RULES 冲突 */
    private static final String PLAN_ARRAY_RULES =
            "你是 MOV agent 的大脑。根据已确认的理解，直接输出执行计划 JSON 数组。\n"
            + "硬性要求：\n"
            + "1. 只输出一个 JSON 数组，前后禁止任何文字/解释/代码围栏/思考过程。禁止写\"我们需要...\"\"我理解...\"\"我们根据指令...\"这类元思考。\n"
            + "2. 数组每个元素是一个执行步骤，格式 {\"action\":\"tool.execute\",\"name\":\"真实工具名\",\"args\":{真实参数},\"desc\":\"简述\",\"worker\":\"fast\"}。\n"
            + "3. name 必须是真实工具名（如 file.write / file.read / shell.exec），禁止用\"工具名\"\"xxx\"等占位词。\n"
            + "4. args 必须真实：file.write 的 args.path 用精确文件名（如 style.css），禁止在 path 里写自然语言描述。\n"
            + "5. 计划要覆盖到交付：所有要产出的文件都要有对应 file.write 步骤（多文件项目 = 每个文件一个 file.write）。\n"
            + "6. 计划里不写 finish/ask_user（那是执行动作，不是计划步骤）。\n"
            + "格式示例（结构照此，内容必须按任务真实写，禁止照抄）：\n"
            + "[{\"action\":\"tool.execute\",\"name\":\"file.write\",\"args\":{\"path\":\"index.html\"},\"desc\":\"写页面结构\",\"worker\":\"fast\"},"
            + "{\"action\":\"tool.execute\",\"name\":\"file.write\",\"args\":{\"path\":\"style.css\"},\"desc\":\"写样式\",\"worker\":\"fast\"}]\n"
            + "网页搜索/查询类任务（查评价/资讯/价格/内容）：用浏览器链路 — "
            + "browser.open(platform+keyword 自动构造搜索 URL，如 platform=douyin keyword=庆余年 评价) → "
            + "browser.snapshot 拿元素编号 eid → browser.type/browser.click 按 eid 操作 → browser.read 读结果；"
            + "browser.open 会自动拉起内置浏览器，其余 browser 工具须先 open。\n"
            + "涉及人/钱/承诺/往来关系的任务：先 causal.query 看因果记忆，新事实 causal.record 记四元组（因果助手，非主目标可跳过）。\n";

    private static final String STEP_RULES =
            "你是 MOV agent 的大脑, 正在驱动一个 agentic 循环。规则:\n"
            + "1. 每轮只输出一个 JSON 动作, 不要输出其他文字。\n"
            + "2. 流程控制动作: {\"action\":\"ask_user\",\"question\":\"问用户的问题\",\"options\":[\"选项A\",\"选项B\"](可选, 有就给出 2-3 个具体选项)} | "
            + "{\"action\":\"revise_plan\",\"reason\":\"原因\",\"plan\":[...]}(全任务最多 2 次, 用完只能执行或 finish) | "
            + "{\"action\":\"finish\",\"summary\":\"交付说明\"}\n"
            + "finish 的 summary 格式纪律 (诚实交付, №8): 最终答案必须先给结论 (用户要的那句话, 第一行就是结论), "
            + "过程一句话带过, 不报告命令/token/步骤细节; 然后必须有【功能自检清单】—"
            + "逐项列出计划承诺的每个功能, 每行一条: 「- ✅ 功能名: 真实现」或「- ⚠️ 功能名: 演示版(原因)」,"
            + "禁止漏项; 做不到真实现的功能必须标 ⚠️ 并写明原因, 不许含糊带过;"
            + "做不出真功能的 UI 元素 (按钮/控件) 必须在产物里带可见「演示」角标, 禁止死按钮。\n"
            + "3. 工具调用统一格式: {\"action\":\"tool.execute\",\"name\":\"<工具名>\",\"args\":{...}}。"
            + "file.write 只能写已批准计划中的文件, content 必须是完整最终内容。\n"
            + "4. 工具结果在工作日志里, 根据结果决定下一步; 需要回看文件内容用 file.read;"
            + "仅当结果尾部明确提示『继续读』才用 offset 续读, 显示『文件读完』就禁止再读同一文件。\n"
            + "5. 目标完成就输出 finish。\n"
            + "6. ask_user 仅限真正卡住(缺信息且无法自行判断)时使用; 用户发来的修改/反馈意见"
            + "本身就是指令, 直接照做, 禁止反问「是否需要我修改」这类确认问题。\n"
            + "7. .apk 是 .html 的打包产物 — 改游戏永远改源 .html 再重新打包, 不要问用户玩的是哪个文件。\n"
            + "8. 工具纪律: 已读过的文件内容就在上方工作日志里, 禁止重复 file.read 同一文件;"
            + "每个疑问最多 2-3 次工具调用, 没有明确下一步就立即 finish, 不要边缘试探。\n"
            + "9. 部署纪律 (全栈任务): 服务先在内嵌 Linux 本地起 curl 自测通过才允许部署;"
            + "部署用 movssh/movscp mov-deploy; 服务守护用 systemd 或 nohup+日志落盘;"
            + "长部署命令 timeoutSec 给足; 部署后必须 curl 健康检查通过才 finish 交付。\n"
            + "10. 提炼契约 (三维精炼, DESIGN_DISTILLATION, 交付按维对号入座): 形态=一句话/选项卡/结构化报告/交付物, "
            + "侧重=快/准/全/可执行, 深度=直接答/确认后答/计划后答 — 按任务自判, 不枚举任务类型; "
            + "复杂交付按确认环节的验收标准执行。\n"
            + "11. 诚实边界: 缺数据明说(不许编), 不确定项单列在答案里(如报告含「不确定项」段), "
            + "绝不把「命令完成」当答案。";
}
