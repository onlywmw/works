package com.hermes.android.agent;

/**
 * MovError — 结构化错误分类 (ARCH_DEBT #1)。
 *
 * 三类:
 *   USER     — 用户输入/操作问题, retryable=false
 *   EXTERNAL — 外部依赖挂了, retryable=true (给重试按钮)
 *   INTERNAL — 程序 bug, retryable=false (自动上报)
 *
 * msg 构造时自动截断到 80 字符。
 */
public class MovError {

    public enum Kind { USER, EXTERNAL, INTERNAL }

    public final Kind kind;
    public final boolean retryable;
    public final String code;
    public final String msg;
    public final String detail;

    private MovError(Kind kind, boolean retryable, String code, String msg, String detail) {
        this.kind = kind;
        this.retryable = retryable;
        this.code = code;
        this.msg = msg != null && msg.length() > 80 ? msg.substring(0, 80) : msg;
        this.detail = detail != null ? detail : (msg != null ? msg : "");
    }

    /** 用户问题: 文件不存在/非法输入等, 不可重试 */
    public static MovError user(String code, String msg) {
        return new MovError(Kind.USER, false, code, msg, msg);
    }

    /** 外部依赖: 网络/超时/API拒绝, 可重试 */
    public static MovError external(String code, String msg, Throwable cause) {
        String detail = cause != null ? cause.toString() : msg;
        return new MovError(Kind.EXTERNAL, true, code, msg, detail);
    }

    /** 程序bug: NPE/解析失败/状态不一致, 不可重试 */
    public static MovError internal(String code, String msg, Throwable cause) {
        String detail = cause != null ? cause.toString() : msg;
        return new MovError(Kind.INTERNAL, false, code, msg, detail);
    }
}
