package com.hermes.android.mcp.server;

import com.hermes.android.agent.Journal;
import com.hermes.android.agent.ToolRegistry;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * mov.* 只读查询工具（工单 P5：MCP P2 扩展）— journal 只追加读，走 Journal 既有 API。
 *
 *  - mov.roomList：枚举已有房间（Journal.roomIds 只读）
 *  - mov.journalTail：读指定房间 journal 尾部（Journal.tail）
 *
 * 纯 JVM，零 android 依赖，零网络。返回结构化 JSON 文本（CallToolResult content）。
 */
public final class MovQueryTools {

    private MovQueryTools() {}

    /** mov.roomList：列出所有已有房间。access=readonly/approval=none，永不审批。 */
    public static ToolRegistry.Tool roomList(Journal journal) {
        return new ToolRegistry.Tool("mov.roomList", "列出所有已有房间 ID（只读）", null, a -> {
            JSONArray arr = new JSONArray();
            for (String r : journal.roomIds()) arr.put(r);
            JSONObject out = new JSONObject().put("rooms", arr).put("count", arr.length());
            return new ToolRegistry.Result(true, out.toString());
        }, "native", "readonly", "none", true, 10, "system",
            new ToolRegistry.ParamDef[]{}, "JSON: {rooms:[...], count}",
            new String[]{"列房间"}, null, 8000,
            new ToolRegistry.Manifest("列出房间", "low", "列出所有已有房间", true, "io"), null);
    }

    /** mov.journalTail：读指定房间 journal 尾部（增量：afterSeq 起，≤100 条）。 */
    public static ToolRegistry.Tool journalTail(Journal journal) {
        return new ToolRegistry.Tool("mov.journalTail", "读取指定房间 journal 事件流尾部（只读，append-only）", null, a -> {
            String roomId = a.optString("roomId");
            int afterSeq = a.optInt("afterSeq", 0);
            int count = a.optInt("count", 20);
            JSONObject r = journal.tail(roomId, afterSeq, Math.min(Math.max(count, 1), 100));
            if (!r.optBoolean("ok")) {
                return new ToolRegistry.Result(false, r.optString("error", "读取失败"));
            }
            return new ToolRegistry.Result(true, r.optJSONObject("data").toString());
        }, "native", "readonly", "none", true, 10, "system",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("roomId", "string", true, "", "房间 ID"),
                new ToolRegistry.ParamDef("afterSeq", "int", false, "默认 0", "只返回 seq > afterSeq 的事件"),
                new ToolRegistry.ParamDef("count", "int", false, "默认 20，最大 100", "返回条数上限"),
            }, "JSON: {events:[...], latestSeq}",
            new String[]{"读 global 房间最近 20 条"}, null, 8000,
            new ToolRegistry.Manifest("读取 journal 尾部", "low", "读取房间事件流尾部", true, "io"), null);
    }
}
