package com.hermes.android.causal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/**
 * 因果逻辑钩子规则（蓝图 §3.2 逻辑变化链的规则形态）。
 *
 * 规则 JSON（journal _causal_rule payload）：
 * <pre>
 * {
 *   "ruleId": "r_debt_alert", "label": "债务到期提醒",
 *   "when": { "type": "cooccur", "atoms": ["张三","李四","欠款"] },
 *          | { "type": "subjectOf", "subject": "张三", "predicate": "欠款" }
 *          | { "type": "dateAfter", "whenDateField": "dueDate" }
 *   "then": { "linkDelta": 0.3, "alert": "债务到期: {dueDate}", "expireAt": "2025-07-01" },
 *   "enabled": true
 * }
 * </pre>
 * 同一 ruleId 后写覆盖前写（事件流即版本历史）。lastFiredTs 为运行时状态（内存，
 * 重建时以事件 ts 近似）。纯 Java，零 android 依赖。
 */
public class CausalRule {

    public final String ruleId;
    public final String label;
    public final JSONObject when;
    public final JSONObject then;
    public final boolean enabled;
    /** 运行时最后触发时间（内存态；重建以事件 ts 近似） */
    public long lastFiredTs;

    public CausalRule(String ruleId, String label, JSONObject when, JSONObject then, boolean enabled) {
        this.ruleId = ruleId;
        this.label = label != null ? label : ruleId;
        this.when = when != null ? when : new JSONObject();
        this.then = then != null ? then : new JSONObject();
        this.enabled = enabled;
    }

    public static CausalRule fromJSON(JSONObject p) {
        if (p == null) return new CausalRule("", "", null, null, false);
        JSONObject then = p.optJSONObject("then");
        return new CausalRule(
                p.optString("ruleId", ""),
                p.optString("label", ""),
                p.optJSONObject("when"),
                then,
                p.optBoolean("enabled", true));
    }

    public JSONObject toJSON() {
        JSONObject p = new JSONObject();
        try {
            p.put("ruleId", ruleId);
            p.put("label", label);
            p.put("when", when);
            p.put("then", then);
            p.put("enabled", enabled);
        } catch (org.json.JSONException ignored) {}
        return p;
    }

    /** 硬到期：then.expireAt（"yyyy-MM-dd"）已过 → true。 */
    public boolean expired(long nowMs) {
        String expireAt = then.optString("expireAt", "");
        if (expireAt.isEmpty()) return false;
        return nowMs > parseDateMs(expireAt);
    }

    /** 规则是否命中事件（三类型钩子，全部原子哈希 O(1) 判定）。 */
    public boolean matches(CausalEvent ev, long nowMs) {
        if (!enabled || expired(nowMs)) return false;
        String type = when.optString("type", "");
        switch (type) {
            case "subjectOf":
                return ev.subject.equals(when.optString("subject", ""))
                        && ev.predicate.equals(when.optString("predicate", ""));
            case "dateAfter": {
                String field = when.optString("whenDateField", "");
                String val = ev.metaString(field);
                return !val.isEmpty() && nowMs > parseDateMs(val);
            }
            case "cooccur":
            default: {
                JSONArray atoms = when.optJSONArray("atoms");
                if (atoms == null || atoms.length() == 0) return false;
                Set<String> evHashes = new HashSet<>();
                for (String a : ev.atoms()) {
                    String h = CausalHash.atomHash(a);
                    if (!h.isEmpty()) evHashes.add(h);
                }
                for (int i = 0; i < atoms.length(); i++) {
                    if (!evHashes.contains(CausalHash.atomHash(atoms.optString(i)))) {
                        return false;  // 缺任一原子 → 不命中（防误触）
                    }
                }
                return true;
            }
        }
    }

    /** alert 文案占位替换：{whenDateField} → 事件 meta 对应值。 */
    public String renderAlert(CausalEvent ev) {
        String alert = then.optString("alert", "");
        String field = when.optString("whenDateField", "");
        if (!field.isEmpty() && alert.contains("{" + field + "}")) {
            alert = alert.replace("{" + field + "}", ev.metaString(field));
        }
        return alert;
    }

    public double linkDelta() {
        return then.optDouble("linkDelta", 0);
    }

    /** "yyyy-MM-dd" → epoch ms（本地时区）；解析失败返回 0（视为不过期/不触发）。 */
    public static long parseDateMs(String date) {
        try {
            String[] p = date.trim().split("-");
            if (p.length != 3) return 0;
            java.util.Calendar c = java.util.Calendar.getInstance();
            c.clear();
            c.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, Integer.parseInt(p[2]));
            return c.getTimeInMillis();
        } catch (Exception e) {
            return 0;
        }
    }
}
