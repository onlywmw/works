package com.hermes.android.causal;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.Normalizer;

/**
 * 因果记忆哈希工具（蓝图 §3.1 数据指纹链 + §3.2 哈希链）。
 *
 * 纯 Java，零 android 依赖。三类哈希：
 *  - {@link #sha256}：通用 SHA-256 hex
 *  - {@link #atomHash}：原子（主体/谓词/客体标签）规范化后哈希——索引键，O(1) 匹配
 *  - {@link #blockHash}：账本区块哈希 = sha256(prevHash | dataHash)——链式锁定，防篡改
 */
public final class CausalHash {

    private CausalHash() {}

    /** SHA-256 hex（确定性，纯 Java）。 */
    public static String sha256(String input) {
        if (input == null) return sha256("");
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(d.length * 2);
            for (byte b : d) {
                sb.append(Character.forDigit((b >> 4) & 0xF, 16));
                sb.append(Character.forDigit(b & 0xF, 16));
            }
            return sb.toString();
        } catch (Exception e) {
            // SHA-256 必然可用（JDK/Android 均提供）；兜底哈希防运行时空指针
            return Integer.toHexString(input.hashCode());
        }
    }

    /** 原子规范化：trim + Unicode NFKC + 内部空白折叠（"张三 "→"张三"，全半角归一）。 */
    public static String normalize(String atom) {
        if (atom == null) return "";
        String s = Normalizer.normalize(atom.trim(), Normalizer.Form.NFKC);
        return s.replaceAll("\\s+", " ");
    }

    /** 原子哈希（索引键）：规范化后 sha256。空原子返回空串（不索引）。 */
    public static String atomHash(String atom) {
        String n = normalize(atom);
        if (n.isEmpty()) return "";
        return sha256(n);
    }

    /** 账本区块哈希：sha256(prevHash + "|" + dataHash)。prevHash 空 = 创世块。 */
    public static String blockHash(String prevHash, String dataHash) {
        return sha256((prevHash == null ? "" : prevHash) + "|" + (dataHash == null ? "" : dataHash));
    }

    /** 规则快照数据哈希（区块 dataHash 用）。 */
    public static String dataHash(String snapshotJson) {
        return sha256(snapshotJson == null ? "" : snapshotJson);
    }
}
