package com.hermes.android.pay;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/**
 * 卖家侧货架（工单26 M4）——真实交易数据源（JS 货架仅展示，这里才是下单/打包依据）。
 *
 * v1 静态 JSON 表：6 件演示商品 + 1 件「0.01 元验收专用包」（config 型，
 * 指向本机 MOV MCP 端点 8389，真单验收用）。生态仓库 registry.json 对接留后续工单。
 *
 * SELLER_PUB_KEY_B64：施工时生成的卖家 RSA 公钥（X509 SPKI base64），与 mov-market.js
 * GOODS 条目 sellerPubKey 一致；对应私钥由用户经「商户收款」表单存 SecureVault
 * （MerchantCreds.sellerKey），私钥永不出现在代码/仓库。
 */
public final class Shelf {

    public static final String SELLER_DEVICE_ID = "mov-seller";

    /** 卖家发货签名公钥（X509 SPKI base64）——施工时生成，与 mov-market.js GOODS 条目一致 */
    public static final String SELLER_PUB_KEY_B64 =
            "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAkmVKcRqYXSM9JWP44qSBjFSq1IoFnOLpHdnVmQvTRPnUbuR1Ntek5jMiMtkGAlfMsF9+ztJKXlMEUUTNWYv4uiOOEC9gCF0A45PmXLV7m+9JSk9KqASOkB2iRZ74hcuRWu0Hsc5tIvCb072dIbNub8SDYXDWG7xUhUOv3p1uZVpPptjNLzIMlCMwRDuLgweSDuciSUIDi2vUi020lZLmnPysPuh1zCYGm5RmxQd0mkTLNgA9kNumMB+uLOlMM/X0GS9G4tnzNlOWW6i9tpJuQ+nKUcWA9/UvKSioYmdui3UE7J2G3chG5nhvHHu4YSyKSKYZywbjZe9dFZxi0k7hgQIDAQAB";

    /** 货架条目（交易数据源） */
    public static class Item {
        public final String id;
        public final String name;
        public final int fen;              // 价格（分）
        public final String type;          // config | package
        public final String cat;
        public final String desc;
        public final JSONObject spec;      // 能力说明书（随包）
        public final JSONObject report;    // 质检报告（随包）
        public final byte[] payload;       // 明文 payload（打包时加密）

        Item(String id, String name, int fen, String type, String cat, String desc,
             JSONObject spec, JSONObject report, byte[] payload) {
            this.id = id; this.name = name; this.fen = fen; this.type = type;
            this.cat = cat; this.desc = desc; this.spec = spec; this.report = report;
            this.payload = payload;
        }

        /** 每单 manifest（含 orderId 绑定，打包/验签用） */
        public JSONObject manifest(String orderId) {
            JSONObject m = new JSONObject();
            try {
                m.put("id", id).put("name", name).put("version", "1.0.0")
                        .put("type", type).put("cat", cat)
                        .put("sellerDeviceId", SELLER_DEVICE_ID)
                        .put("sellerPubKey", SELLER_PUB_KEY_B64)
                        .put("paid", true).put("orderId", orderId);
            } catch (Exception ignored) {}
            return m;
        }

        public PublicKey sellerPubKey() {
            try {
                return KeyFactory.getInstance("RSA").generatePublic(
                        new X509EncodedKeySpec(Base64.getDecoder().decode(SELLER_PUB_KEY_B64)));
            } catch (Exception e) {
                throw new IllegalStateException("卖家公钥损坏", e);
            }
        }
    }

    private static final JSONObject SPEC_FETCH = j("提供", "URL → 正文 markdown → 写入本机记忆",
            "输入", "url 必填 · selector/maxLen 可选", "依赖", "出网内容自动过 PII 打码闸");
    private static final JSONObject REPORT_FETCH = j("结果", "✓ 真实站点抓取回归通过 · ✓ 乱码/坏链拒收实测 · ✓ 清洗入库闭环",
            "报告号", "RPT-20260807-011-fetch-kit");

    private static final Item[] ITEMS = new Item[] {
            new Item("pkg-accept-001", "0.01元验收专用包", 1, "config", "net",
                    "验收专用：装的是官方能力包（本机 MOV MCP 端点，装完工具立即可调）",
                    SPEC_FETCH, REPORT_FETCH,
                    configPayload("http://127.0.0.1:8389", "", "官方能力包",
                            "MOV 本机 MCP 端点（验收专用）", "net"))
    };

    /** config 型 payload：{url, token, name, desc, cat} */
    static byte[] configPayload(String url, String token, String name, String desc, String cat) {
        JSONObject o = new JSONObject();
        try {
            o.put("url", url).put("token", token).put("name", name)
                    .put("desc", desc).put("cat", cat);
        } catch (Exception ignored) {}
        return o.toString().getBytes(StandardCharsets.UTF_8);
    }

    static JSONObject j(String... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(kv[i], kv[i + 1]);
        } catch (Exception ignored) {}
        return o;
    }

    /** 按 id 查货架；不存在 → null（卖家拒单） */
    public static Item find(String id) {
        if (id == null) return null;
        for (Item i : ITEMS) if (id.equals(i.id)) return i;
        return null;
    }

    /** 全部货架（真机诊断用） */
    public static Item[] all() { return ITEMS; }
}
