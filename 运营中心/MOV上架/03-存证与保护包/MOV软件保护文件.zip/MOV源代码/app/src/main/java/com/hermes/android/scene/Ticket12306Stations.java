package com.hermes.android.scene;

import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 12306 站点表（四表）— 对齐 12306-mcp getStations()。
 *
 * 从 www.12306.cn/index/ 首页正则动态提取 station_name.js 路径（不硬编码，抗站点改版），
 * 解析构建四张索引表：
 *  - byCode：station_code → Station
 *  - byName：station_name → Station
 *  - byCity：城市名 → 该市所有站
 *  - cityRep：城市名 → 代表站（station_name==city 的那一个）
 *
 * 缓存：进程内单例 + TTL 24h + 磁盘缓存（filesDir/ticket12306/stations.json），
 * 冷启动命中磁盘免下载；站表大（~100KB+），不能每次查询都拉。
 *
 * 单测零网络：静态 {@link #parse(String)} 是纯解析（喂 js 文本 → 四表），查询方法纯内存。
 */
public class Ticket12306Stations {

    private static final String TAG = "Ticket12306Stations";
    private static final String WEB_URL = "https://www.12306.cn/index/";
    private static final String STATIONS_TTL_MS = "stations_ttl_ms";
    private static final long TTL_DEFAULT_MS = 24L * 3600 * 1000;

    /** 缺失车站手工补齐（12306-mcp MISSING_STATIONS，成都东站 code 修正）。10 字段直接对应 StationDataKeys。 */
    private static final String[] MISSING_STATION = {
        "@cdd", "成  都东", "WEI", "chengdudong", "cdd", "", "1707", "成都", "", "",
    };

    /** 站点条目（station_name.js 每 10 字段一组）。 */
    public static class Station {
        public final String stationId;   // @bjb（带 @ 前缀，官方格式）
        public final String name;        // 北京北
        public final String code;        // VAP（station_code/电报码）
        public final String pinyin;      // beijingbei
        public final String shortName;   // bjb
        public final String index;       // 序号
        public final String secondaryCode; // 城市二级码
        public final String city;        // 所属城市（字段[7]）
        public final String r1, r2;      // 预留字段

        Station(String[] f) {
            this.stationId = at(f, 0);
            this.name = at(f, 1);
            this.code = at(f, 2);
            this.pinyin = at(f, 3);
            this.shortName = at(f, 4);
            this.index = at(f, 5);
            this.secondaryCode = at(f, 6);
            this.city = at(f, 7);
            this.r1 = at(f, 8);
            this.r2 = at(f, 9);
        }

        public JSONObject toJson() {
            try {
                return new JSONObject()
                    .put("station_code", code)
                    .put("station_name", name)
                    .put("station_pinyin", pinyin)
                    .put("station_short", shortName)
                    .put("city", city);
            } catch (Exception e) { return new JSONObject(); }
        }
    }

    private final Map<String, Station> byCode = new HashMap<>();
    private final Map<String, Station> byName = new HashMap<>();
    private final Map<String, List<Station>> byCity = new HashMap<>();
    private final Map<String, Station> cityRep = new HashMap<>();

    // ── 进程内单例 + TTL ──
    private static volatile Ticket12306Stations instance;
    private static volatile long loadedAt;
    private static long ttlMs = TTL_DEFAULT_MS;

    /** 测试用：注入构建好的表（零网络）。 */
    public Ticket12306Stations(Map<String, Station> byCode, Map<String, List<Station>> byCity,
                               Map<String, Station> cityRep, Map<String, Station> byName) {
        if (byCode != null) this.byCode.putAll(byCode);
        if (byCity != null) this.byCity.putAll(byCity);
        if (cityRep != null) this.cityRep.putAll(cityRep);
        if (byName != null) this.byName.putAll(byName);
    }

    /** 真实构造：解析已加载的 js 文本（网络加载由 get() 负责）。 */
    private Ticket12306Stations(String jsContent) {
        parseInto(jsContent, this);
    }

    // ══════════ 单例 + 加载 ══════════

    /** 获取站表单例（懒加载）。加载失败抛异常（调用方归因为 SOURCE_DOWN）。 */
    public static synchronized Ticket12306Stations get() throws Exception {
        long now = System.currentTimeMillis();
        if (instance != null && now - loadedAt < ttlMs) return instance;
        if (instance != null) {
            // TTL 过期 → 静默刷新；失败保留旧表不污染
            try {
                Ticket12306Stations fresh = loadFromNetwork();
                instance = fresh; loadedAt = now;
                saveToDisk(fresh);
            } catch (Exception e) {
                Log.w(TAG, "站表刷新失败，沿用旧表: " + e.getMessage());
            }
            return instance;
        }
        // 冷启动：先磁盘缓存，再网络
        Ticket12306Stations disk = loadFromDisk();
        if (disk != null && now - loadedAt < ttlMs) {
            instance = disk; loadedAt = now;
            return instance;
        }
        Ticket12306Stations fresh = loadFromNetwork();
        instance = fresh; loadedAt = now;
        saveToDisk(fresh);
        return instance;
    }

    /** 强制刷新（PARSE_DRIFT 时主动重载）。 */
    public static void forceRefresh() throws Exception {
        Ticket12306Stations fresh = loadFromNetwork();
        instance = fresh; loadedAt = System.currentTimeMillis();
        saveToDisk(fresh);
    }

    /** 测试用：设置 TTL 并复位单例。 */
    static void resetForTest(long ttl) { instance = null; loadedAt = 0; ttlMs = ttl; }

    // ══════════ 网络加载 ══════════

    /** 从 12306 官网加载并解析站表（2 个请求：首页找路径 + 拉 JS）。 */
    private static Ticket12306Stations loadFromNetwork() throws Exception {
        String html = httpGet(WEB_URL, null);
        if (html == null) throw new Exception("get 12306 web page failed");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(
            "'(/script/core/common/station_name.+?\\.js)'").matcher(html);
        if (!m.find()) throw new Exception("get station name js file failed (path regex)");
        String jsPath = m.group(1);
        String jsUrl = jsPath.startsWith("http") ? jsPath : "https://www.12306.cn" + jsPath;
        String stationJs = httpGet(jsUrl, null);
        if (stationJs == null) throw new Exception("get station name js content failed");
        String raw = stationJs
            .replace("var station_names ='", "")
            .replace("';", "");
        return new Ticket12306Stations(raw);
    }

    /** HttpURLConnection GET（超时 8s），返回 body 文本或 null。 */
    static String httpGet(String urlStr, String cookie) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
            c.setConnectTimeout(8000); c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
            int code = c.getResponseCode();
            if (code != 200) return null;
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close(); c.disconnect();
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    // ══════════ 磁盘缓存 ══════════

    private static File cacheFile() {
        try {
            android.content.Context ctx = com.hermes.android.HermesApplication.getAppContext();
            if (ctx == null) return null;
            File dir = new File(ctx.getFilesDir(), "ticket12306");
            return new File(dir, "stations.json");
        } catch (Exception e) { return null; }
    }

    private static void saveToDisk(Ticket12306Stations s) {
        try {
            File f = cacheFile();
            if (f == null) return;
            JSONObject root = new JSONObject();
            for (Station st : s.byCode.values()) {
                root.put(st.code, st.toJson());
            }
            File p = f.getParentFile();
            if (p != null && !p.exists()) p.mkdirs();
            FileOutputStream os = new FileOutputStream(f);
            os.write(root.toString().getBytes("UTF-8"));
            os.close();
        } catch (Exception e) { Log.w(TAG, "站表磁盘缓存写失败: " + e.getMessage()); }
    }

    private static Ticket12306Stations loadFromDisk() {
        try {
            File f = cacheFile();
            if (f == null || !f.exists()) return null;
            FileInputStream is = new FileInputStream(f);
            byte[] buf = new byte[(int) f.length()];
            int off = 0;
            while (off < buf.length) {
                int n = is.read(buf, off, buf.length - off);
                if (n < 0) break;
                off += n;
            }
            is.close();
            JSONObject root = new JSONObject(new String(buf, "UTF-8"));
            Map<String, Station> byCode = new HashMap<>();
            java.util.Iterator<String> keys = root.keys();
            while (keys.hasNext()) {
                String code = keys.next();
                JSONObject o = root.optJSONObject(code);
                if (o == null) continue;
                String[] fs = new String[10];
                fs[2] = code;
                fs[1] = o.optString("station_name");
                fs[3] = o.optString("station_pinyin");
                fs[4] = o.optString("station_short");
                fs[7] = o.optString("city");
                fs[0] = "@" + (o.optString("station_short", code));
                byCode.put(code, new Station(fs));
            }
            if (byCode.isEmpty()) return null;
            return buildTables(byCode);
        } catch (Exception e) {
            Log.w(TAG, "站表磁盘缓存读失败: " + e.getMessage());
            return null;
        }
    }

    // ══════════ 纯解析（单测入口） ══════════

    /** 解析 station_name.js 原始文本 → 四表。纯逻辑，无网络。 */
    public static Ticket12306Stations parse(String rawData) {
        Ticket12306Stations s = new Ticket12306Stations("x");
        parseInto(rawData, s);
        return s;
    }

    private static void parseInto(String rawData, Ticket12306Stations s) {
        Map<String, Station> byCode = new HashMap<>();
        String[] arr = rawData.split("\\|");
        int groups = arr.length / 10;
        for (int i = 0; i < groups; i++) {
            String[] f = new String[10];
            System.arraycopy(arr, i * 10, f, 0, 10);
            if (f[2] == null || f[2].isEmpty()) continue;  // 无 station_code 跳过
            // station_id 首个元素带 @ 前缀（官方格式），补全后续条目
            if (f[0] == null || !f[0].startsWith("@")) f[0] = "@" + f[0];
            Station st = new Station(f);
            if (byCode.containsKey(st.code)) continue;  // 重复 code 跳过
            byCode.put(st.code, st);
        }
        // 缺失车站补齐（成都东 code 修正）
        if (!byCode.containsKey(MISSING_STATION[2])) {
            String[] f = new String[MISSING_STATION.length];
            System.arraycopy(MISSING_STATION, 0, f, 0, MISSING_STATION.length);
            Station st = new Station(f);
            byCode.put(st.code, st);
        }
        Ticket12306Stations built = buildTables(byCode);
        s.byCode.putAll(built.byCode);
        s.byName.putAll(built.byName);
        s.byCity.putAll(built.byCity);
        s.cityRep.putAll(built.cityRep);
    }

    /** 由 byCode 构建四表。 */
    private static Ticket12306Stations buildTables(Map<String, Station> byCode) {
        Map<String, List<Station>> byCity = new HashMap<>();
        Map<String, Station> cityRep = new HashMap<>();
        Map<String, Station> byName = new HashMap<>();
        for (Station st : byCode.values()) {
            String city = st.city != null ? st.city.trim() : "";
            if (!city.isEmpty()) {
                byCity.computeIfAbsent(city, k -> new ArrayList<>()).add(st);
                // 代表站：该城所有站中 station_name==city 的那一个
                if (st.name != null && st.name.equals(city) && !cityRep.containsKey(city)) {
                    cityRep.put(city, st);
                }
            }
            if (st.name != null && !st.name.isEmpty()) {
                byName.put(st.name, st);
            }
        }
        return new Ticket12306Stations(byCode, byCity, cityRep, byName);
    }

    // ══════════ 查询 ══════════

    public Map<String, Station> byCode() { return byCode; }
    public Map<String, List<Station>> byCity() { return byCity; }
    public Map<String, Station> cityRep() { return cityRep; }
    public Map<String, Station> byName() { return byName; }

    /**
     * 中文名/带"站"后缀/telecode → station_code。未知返回 null。
     * 对齐 12306-mcp parseStationCode：纯字母且命中 byCode → 直通；否则中文名查 byName。
     */
    public String resolveCode(String input) {
        if (input == null || input.isEmpty()) return null;
        if (input.matches("^[A-Z]+$") && byCode.containsKey(input)) return input;
        String name = input.endsWith("站") ? input.substring(0, input.length() - 1) : input;
        Station st = byName.get(name);
        return st != null ? st.code : null;
    }

    /** 工具名 → code 的可读信息（get-station-by-telecode 用）。 */
    public Station byTelecode(String code) { return byCode.get(code); }

    private static String at(String[] f, int i) {
        return (i < f.length && f[i] != null) ? f[i] : "";
    }
}
