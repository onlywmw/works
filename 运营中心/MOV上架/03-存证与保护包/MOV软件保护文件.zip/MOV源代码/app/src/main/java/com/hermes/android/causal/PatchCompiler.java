package com.hermes.android.causal;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 补丁编译（DESIGN_CAUSAL_APIFACT §四）：API 返回的 patch_rule → 本地 CausalRule 钩子 → 落库 + 账本新区块。
 * 映射：condition→when.cooccur+atoms；action=INSERT_NODE+suggested_trigger→then.alert；
 *      confidence_boost→then.linkDelta；hidden_variables→then.diagnosis（then 是自由 JSON，不改 CausalRule 核心）。
 * 不改本地引擎核心（设计红线）；落库走 CausalEngine.upsertRule（自动写账本区块，evidence 含 patch 来源）。
 */
public class PatchCompiler {

    /** 编译补丁并落库。返回 {ruleId, blockHash, ok}；失败 {ok:false}。 */
    public static JSONObject compile(CausalEngine engine, String room, JSONObject patch) {
        JSONObject r = new JSONObject();
        try {
            if (engine == null || patch == null) { r.put("ok", false); return r; }
            JSONObject rule = patch.optJSONObject("patch_rule");
            if (rule == null) { r.put("ok", false); r.put("error", "patch 无 patch_rule"); return r; }
            String condition = rule.optString("condition", "");
            String action = rule.optString("action", "");
            JSONObject newNode = rule.optJSONObject("new_node");
            double boost = rule.optDouble("confidence_boost", 0);

            // 隐私闸门（隐私审计 2026-08-05）：云端写回的 condition/suggested_trigger/hidden_variables
            // 若含手机号/证件/邮箱/卡号/金额/URL 原文 → 拒绝落库（防模型鹦鹉学舌把泄露的 PII 写回本地规则）。
            StringBuilder wback = new StringBuilder(condition).append('|')
                    .append(newNode != null ? newNode.optString("suggested_trigger", "") : "");
            JSONArray hvCheck = patch.optJSONArray("hidden_variables");
            if (hvCheck != null) for (int i = 0; i < hvCheck.length(); i++) {
                wback.append('|').append(hvCheck.optString(i));
            }
            if (PiiScrubber.containsPii(wback.toString())) {
                r.put("ok", false);
                r.put("error", "补丁含未脱敏原文（PII），拒绝写回");
                return r;
            }

            // when：condition → cooccur 原子（提取关键词，≤8 字）
            JSONObject when = new JSONObject();
            when.put("type", "cooccur");
            JSONArray atoms = new JSONArray();
            for (String kw : condition.split("当|且|，|,|时|与|和|无|产生|后")) {
                String t = kw.trim();
                if (!t.isEmpty() && t.length() <= 8) atoms.put(t);
            }
            if (atoms.length() == 0) atoms.put("因果补丁");
            when.put("atoms", atoms);

            // then：INSERT_NODE → alert；confidence_boost → linkDelta；hidden_variables → diagnosis
            JSONObject then = new JSONObject();
            if (newNode != null) {
                String tip = newNode.optString("suggested_trigger", "");
                then.put("alert", "因果助手建议：" + (tip.isEmpty() ? "注意缺失环节" : tip));
            }
            if (boost > 0) then.put("linkDelta", boost);
            JSONArray hv = patch.optJSONArray("hidden_variables");
            if (hv != null && hv.length() > 0) then.put("diagnosis", hv);

            // 组装 ruleJson
            JSONObject ruleJson = new JSONObject();
            String seed = condition + "|" + action + "|" + boost;
            String ruleId = "patch_" + Integer.toHexString(seed.hashCode());  // 完整 hex（负哈希也安全，不截断防越界）
            ruleJson.put("ruleId", ruleId);
            String label = condition.length() > 20 ? condition.substring(0, 20) + "…" : condition;
            ruleJson.put("label", "因果补丁:" + (label.isEmpty() ? "反思建议" : label));
            ruleJson.put("when", when);
            ruleJson.put("then", then);
            ruleJson.put("enabled", true);

            JSONObject ur = engine.upsertRule(room, ruleJson);
            r.put("ruleId", ur.optString("ruleId", ""));
            r.put("blockHash", ur.optString("blockHash", ""));
            r.put("ok", ur.optBoolean("ok", false));
            return r;
        } catch (Exception e) {
            try { r.put("ok", false); r.put("error", "编译补丁失败: " + e.getMessage()); }
            catch (org.json.JSONException ignored) {}
            return r;
        }
    }
}
