package com.hermes.android.llama;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import com.hermes.android.linux.Proot;
import com.hermes.android.linux.RootfsManager;

/**
 * llama-server 常驻管理（P6 №4，DESIGN_OCR_MOBILE v2 §三 本地 API 大模型形态）。
 *
 * 形态：rootfs glibc loader 直跑 llama-server（vision_infer 同款运行模式），
 * OpenAI 兼容 API 绑死 127.0.0.1:8080，Bearer token 鉴权（MOV 独占）。
 * 生命周期：懒启动（ocr 调用触发）→ healthz-on-call → 空闲 30min 退出
 * （Manager 层计时——b10216 llama-server 无 --idle-timeout，距上次调用超 30min 即停旧进程）。
 *
 * 可测设计：状态机决策 = 纯函数 {@link #decide}（healthy/process/installReady → 动作），
 * healthz 走 {@link HealthProbe} 注入（单测替换为假探针，零网络）。
 */
public class LlamaServerManager {

    public enum State { IDLE, STARTING, READY, EXITED }
    /** ensureRunning 的决策结果 */
    public enum Decision { REUSE, WAIT, NO_INSTALL, START }

    private static final String TAG = "LlamaServerManager";
    private static final String PREFS = "llama_serve_prefs";
    private static final String KEY_TOKEN = "token";

    public static final String MODEL_DIR = "models/unlimited-ocr";
    public static final String LLAMA_DIR = "llama";
    public static final String DEFAULT_MODEL = "q4_K_M.gguf";
    /** 工单12 幕四: 视觉投影 mmproj(验收员 Windows 侧转换, 826MB, Unlimited-OCR 视觉塔) */
    public static final String MMPROJ_MODEL = "mmproj-f16.gguf";
    public static final int PORT = 8080;
    public static final int IDLE_TIMEOUT_SEC = 1800;      // 30min
    public static final int HEALTHZ_TIMEOUT_MS = 2000;
    public static final long START_WAIT_MS = 30_000;      // 懒启动后轮询 healthz 上限

    private static Process process;
    private static volatile State state = State.IDLE;
    private static long lastCallMs = 0;   // 最近一次 ensureRunning 时间（空闲超时判定）

    /** healthz 探针（单测注入假探针，零网络） */
    public interface HealthProbe {
        boolean healthz();
    }
    private static HealthProbe probeOverride;

    private LlamaServerManager() {}

    /** 单测注入：替换 healthz 探针（null 恢复默认 HttpURLConnection） */
    public static void setProbeForTest(HealthProbe p) { probeOverride = p; }

    // ==================== token（EncryptedSharedPreferences，照 HermesServeConfig） ====================

    private static SharedPreferences prefs(Context ctx) {
        try {
            MasterKey mk = new MasterKey.Builder(ctx)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build();
            return EncryptedSharedPreferences.create(ctx, PREFS, mk,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
        } catch (Exception e) {
            throw new RuntimeException("llama serve 加密存储不可用", e);
        }
    }

    /** token：不存在则生成并落盘（llama-server --api-key 用，MOV 侧唯一生成点） */
    public static String token(Context ctx) {
        SharedPreferences p = prefs(ctx);
        String t = p.getString(KEY_TOKEN, null);
        if (t == null || t.isEmpty()) {
            t = urlSafeToken(24);
            p.edit().putString(KEY_TOKEN, t).apply();
            Log.i(TAG, "生成 llama-server token");
        }
        return t;
    }

    // ==================== 路径 ====================

    public static File modelDir(Context ctx)    { return new File(ctx.getFilesDir(), MODEL_DIR); }
    public static File llamaDir(Context ctx)    { return new File(ctx.getFilesDir(), LLAMA_DIR); }

    public static File modelFile(Context ctx) {
        File f = new File(modelDir(ctx), DEFAULT_MODEL);
        return f.isFile() ? f : null;
    }

    /** 启动前置：模型 + llama-server 二进制都就位（ctx null = 不可用，单测容忍） */
    public static boolean installReady(Context ctx) {
        if (ctx == null) return false;
        return modelFile(ctx) != null && new File(llamaDir(ctx), "llama-server").isFile();
    }

    public static State status() { return state; }

    // ==================== healthz ====================

    /** 默认探针：GET /health（b10216 llama-server 端点，--api-key 全局鉴权需带 Bearer token），200 且 status:ok */
    private static boolean defaultHealthz(String token) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(
                    "http://127.0.0.1:" + PORT + "/health").openConnection();
            c.setConnectTimeout(HEALTHZ_TIMEOUT_MS);
            c.setReadTimeout(HEALTHZ_TIMEOUT_MS);
            c.setRequestMethod("GET");
            if (token != null && !token.isEmpty()) {
                c.setRequestProperty("Authorization", "Bearer " + token);
            }
            int code = c.getResponseCode();
            if (code != 200) return false;
            try (InputStream in = c.getInputStream()) {
                byte[] buf = new byte[256];
                int n = in.read(buf);
                if (n <= 0) return false;
                String body = new String(buf, 0, n, "UTF-8");
                return body.contains("\"status\":\"ok\"");
            }
        } catch (Exception e) {
            return false;
        }
    }

    /** healthz-on-call（单测注入探针优先；默认探针带 token 鉴权） */
    public static boolean healthz(Context ctx) {
        if (probeOverride != null) return probeOverride.healthz();
        return defaultHealthz(ctx != null ? token(ctx) : null);
    }

    // ==================== 决策纯函数（可单测） ====================

    /**
     * 懒启动决策：healthz 通 → 复用；有进程但 healthz 不通 → 等/查；无进程且缺安装 → 不可用；否则启动。
     */
    public static Decision decide(boolean healthy, boolean hasProcess, boolean installReady) {
        if (healthy) return Decision.REUSE;
        if (hasProcess) return Decision.WAIT;
        if (!installReady) return Decision.NO_INSTALL;
        return Decision.START;
    }

    // ==================== 懒启动 ====================

    /** ocr 调用前调：确保 llama-server 就绪（healthz → 复用；否则启动 + 轮询） */
    public static synchronized boolean ensureRunning(Context ctx) {
        checkIdleTimeout();      // 空闲超时 → 停旧进程（下次调用重启）
        lastCallMs = System.currentTimeMillis();
        boolean healthy = healthz(ctx);
        boolean hasProcess = process != null && process.isAlive();
        Decision d = decide(healthy, hasProcess, installReady(ctx));

        switch (d) {
            case REUSE:
                state = State.READY;
                return true;
            case WAIT:
                // 进程在但 healthz 不通：给一点时间，仍不通则 kill 重启
                if (waitHealthy(ctx, 5000)) { state = State.READY; return true; }
                destroyProcess();
                // 落到 START
                break;
            case NO_INSTALL:
                state = State.IDLE;
                return false;
            case START:
                break;
        }

        state = State.STARTING;
        process = start(ctx);
        if (process == null) { state = State.EXITED; return false; }
        if (waitHealthy(ctx, START_WAIT_MS)) { state = State.READY; return true; }
        state = State.EXITED;
        return false;
    }

    /** 主动停（设置页卸载/测试用） */
    public static synchronized void stop() {
        destroyProcess();
        state = State.IDLE;
    }

    private static void destroyProcess() {
        if (process != null) {
            try { process.destroy(); } catch (Exception ignored) {}
            process = null;
        }
    }

    /** 空闲超时判定（纯函数可测）：进程在 + 有 lastCall + 距 lastCall 超 IDLE_TIMEOUT_SEC */
    static boolean isIdleTimedOut(boolean hasProcess, long lastCallMs, long nowMs) {
        return hasProcess && lastCallMs > 0
                && (nowMs - lastCallMs) > IDLE_TIMEOUT_SEC * 1000L;
    }

    /** 空闲超时执行（Manager 层实现——b10216 llama-server 无 --idle-timeout）：
     *  距上次调用超 30min 且进程仍在 → 停掉（下次调用懒重启）。 */
    static void checkIdleTimeout() {
        if (isIdleTimedOut(process != null, lastCallMs, System.currentTimeMillis())) {
            Log.i(TAG, "空闲 " + IDLE_TIMEOUT_SEC + "s 超时, 停 llama-server");
            destroyProcess();
            state = State.IDLE;
        }
    }

    private static boolean waitHealthy(Context ctx, long waitMs) {
        long deadline = System.currentTimeMillis() + waitMs;
        while (System.currentTimeMillis() < deadline) {
            if (healthz(ctx)) return true;
            try { Thread.sleep(300); } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        return false;
    }

    /** 启动 llama-server：proot 内托管（app 域只能 exec jniLibs 的 libproot.so；
     *  llama-server 二进制/模型经 -b 绑进 guest，proot 内 exec 无 SELinux 限制）。
     *  照 ProotRunner.startDaemon 模式：proot 进程即常驻宿主，app 死 → proot 随死。 */
    private static Process start(Context ctx) {
        try {
            File rootfs = new RootfsManager(ctx).rootfsDir();
            File llamaDir = llamaDir(ctx);
            File modelDir = modelDir(ctx);
            File llamaBin = new File(llamaDir, "llama-server");
            File model = modelFile(ctx);
            if (!Proot.binary(ctx).isFile() || !llamaBin.isFile() || model == null) {
                Log.w(TAG, "start 前置缺失: proot/llama-server/model");
                return null;
            }

            List<String> args = new ArrayList<>();
            args.add(Proot.binary(ctx).getAbsolutePath());
            args.add("-0");
            args.add("--kill-on-exit");
            args.add("--link2symlink");
            args.add("-r");     args.add(rootfs.getAbsolutePath());
            args.add("-b");     args.add("/dev");
            args.add("-b");     args.add("/proc");
            args.add("-b");     args.add("/sys");
            args.add("-b");     args.add(llamaDir.getAbsolutePath() + ":/llama");
            args.add("-b");     args.add(modelDir.getAbsolutePath() + ":/models");
            args.add("-w");     args.add("/root");
            args.add("/usr/bin/env");
            args.add("PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin");
            args.add("HOME=/root");
            args.add("/usr/bin/bash"); args.add("-lc");
            args.add(buildServerCommand(DEFAULT_MODEL, MMPROJ_MODEL, token(ctx)));

            ProcessBuilder pb = new ProcessBuilder(args);
            pb.environment().put("LD_LIBRARY_PATH", Proot.libDir(ctx));
            File tmp = new File(ctx.getFilesDir(), "linux/tmp");
            tmp.mkdirs();
            pb.environment().put("PROOT_TMP_DIR", tmp.getAbsolutePath());
            pb.environment().put("PROOT_LOADER", Proot.loader(ctx).getAbsolutePath());
            pb.redirectErrorStream(true);
            Process p = pb.start();
            Log.i(TAG, "llama-server (proot) 启动, port=" + PORT);
            return p;
        } catch (Exception e) {
            Log.w(TAG, "start: " + e.getMessage());
            return null;
        }
    }

    /** 工单12 幕四: llama-server 启动命令构造(纯函数, 可测) — 含 mmproj 视觉投影, 消除"image not supported" 500 */
    static String buildServerCommand(String modelName, String mmprojName, String token) {
        String cmd = "LD_LIBRARY_PATH=/llama:/usr/lib/aarch64-linux-gnu:/usr/lib:/lib "
                + "/llama/llama-server -m /models/" + modelName;
        if (mmprojName != null && !mmprojName.isEmpty()) {
            cmd += " --mmproj /models/" + mmprojName;
        }
        return cmd + " --host 127.0.0.1 --port " + PORT + " -t 6 --api-key " + token;
    }

    /** URL 安全随机 token（MOV 生成，写 EncryptedSharedPreferences） */
    static String urlSafeToken(int len) {
        final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-";
        SecureRandom rnd = new SecureRandom();
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) sb.append(chars.charAt(rnd.nextInt(chars.length())));
        return sb.toString();
    }
}
