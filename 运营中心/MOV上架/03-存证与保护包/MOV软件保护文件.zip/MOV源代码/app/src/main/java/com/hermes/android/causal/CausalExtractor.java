package com.hermes.android.causal;

import com.hermes.android.agent.AgentLoop;
import com.hermes.android.ai.AiClient;
import com.hermes.android.toolprovider.CausalToolProvider;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 工单22 幕三: 文本→四元组自动抽取器（近档欠账核心）。
 *
 * 用户原文/文本 → DeepSeek 结构化抽取（JSON 四元组数组）→ 既有 causal.record 引擎入库。
 * 设计约束：
 * - 抽取是模型调用（Brain.chat 结构化输出），入库走既有 CausalEngine（纯 Java 长在 journal，铁律③不动）
 * - 抽取失败静默降级（不影响对话/写入路径）——抽不到就跳过，绝不抛
 * - 只抽明确的因果事实（借贷/承诺/往来/时间关系），无事实返回空数组（省 token）
 */
public class CausalExtractor {

    /** 抽取 prompt：要求模型输出 JSON 数组（subject/predicate/object/t/meta），无事实则 [] */
    static final String EXTRACT_PROMPT =
            "你是因果记忆抽取器。从用户消息中提取明确的因果事实（借贷/欠款/承诺/约定/"
            + "人-钱-往来/时间承诺等），输出 JSON 数组，每项："
            + "{\"subject\":\"主体\",\"predicate\":\"谓词\",\"object\":\"客体\","
            + "\"t\":\"业务时间(可选)\",\"meta\":{\"amount\":数字(可选),\"dueDate\":\"日期(可选)\"}}。"
            + "没有因果事实时输出 []。只输出 JSON，不要其他文字。";

    /**
     * 抽取并入库。全静默：模型不可用/解析失败/无事实 → 返回 0，不抛异常。
     *
     * @param brain 模型通道（null = 不抽取）
     * @param text  用户原文
     * @return 入库的四元组条数
     */
    public static int extractAndRecord(AgentLoop.Brain brain, String text) {
        if (brain == null || text == null || text.trim().isEmpty()) return 0;
        try {
            AiClient.AiResponse resp = brain.chat(EXTRACT_PROMPT, text.trim());
            if (resp == null || !resp.success || resp.content == null) return 0;
            String content = resp.content.trim();
            /* 模型可能带 ```json 围栏或前后解释——剥到第一个 [ 到最后一个 ] */
            int start = content.indexOf('[');
            int end = content.lastIndexOf(']');
            if (start < 0 || end <= start) return 0;
            JSONArray arr = new JSONArray(content.substring(start, end + 1));
            if (arr.length() == 0) return 0;

            CausalEngine engine = CausalToolProvider.engine();
            if (engine == null) return 0;

            int recorded = 0;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String subject = o.optString("subject", "").trim();
                String predicate = o.optString("predicate", "").trim();
                String object = o.optString("object", "").trim();
                if (subject.isEmpty() || predicate.isEmpty()) continue;
                CausalEvent ev = new CausalEvent(subject, predicate, object,
                        o.optString("t", null), "extractor",
                        o.optJSONObject("meta"));
                JSONObject r = engine.record(CausalToolProvider.ROOM, ev);
                if (r.optBoolean("ok", false)) recorded++;
            }
            return recorded;
        } catch (Exception e) {
            /* 静默降级：抽取失败不影响对话 */
            return 0;
        }
    }
}
