package com.hermes.android.mcp;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * McpServerStore — 多 MCP server 配置存储（工单25 幕一 D：多 server 地基）。
 *
 * SharedPreferences「mcp_config」文件内新增 key「mcp_servers」JSON 列表，
 * 每条: id / url / token / enabled / origin∈{manual,market}。
 *
 * 旧单条键 server_url/server_token 首次读取时自动迁移为列表第一条
 * （origin=manual, enabled=true）；迁移后旧键保留不删（只读迁移，升级不丢数据）。
 *
 * 单测经 {@link Prefs} 构造注入内存 fake，零 Android 依赖、零网络。
 */
public class McpServerStore {

    public static final String PREFS_FILE = "mcp_config";
    public static final String KEY_SERVERS = "mcp_servers";
    /** 旧单条配置键（迁移后保留不删） */
    public static final String LEGACY_URL = "server_url";
    public static final String LEGACY_TOKEN = "server_token";

    public static final String ORIGIN_MANUAL = "manual";
    public static final String ORIGIN_MARKET = "market";

    /** 分类（本地页分组）：db/net/file/home/efficiency/dev/other（手动添加默认 other） */
    public static final String CAT_OTHER = "other";

    /** 存储抽象：Android 侧包 SharedPreferences，单测侧内存 fake。 */
    public interface Prefs {
        String getString(String key, String def);
        void putString(String key, String value);
    }

    /** 一条 server 配置。 */
    public static class Entry {
        public final String id;
        public String url;
        public String token;
        public boolean enabled;
        public String origin;
        public String name;   /* 显示名（空 → UI 兜底显 url） */
        public String desc;   /* 一句话简介（空 → UI 兜底显 url） */
        public String cat;    /* 分类：db/net/file/home/efficiency/dev/other */
        public boolean paid;  /* 市场付费购入（黑金开关） */

        Entry(String id, String url, String token, boolean enabled, String origin) {
            this(id, url, token, enabled, origin, "", "", CAT_OTHER, false);
        }

        Entry(String id, String url, String token, boolean enabled, String origin,
              String name, String desc, String cat, boolean paid) {
            this.id = id;
            this.url = url;
            this.token = token;
            this.enabled = enabled;
            this.origin = origin;
            this.name = name;
            this.desc = desc;
            this.cat = cat;
            this.paid = paid;
        }

        public JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("id", id)
                        .put("url", url)
                        .put("token", token)
                        .put("enabled", enabled)
                        .put("origin", origin)
                        .put("name", name)
                        .put("desc", desc)
                        .put("cat", cat)
                        .put("paid", paid);
            } catch (Exception ignored) { /* org.json put 基本类型不抛，防御性 */ }
            return o;
        }

        /** 缺 id/url 的坏条目丢弃（返回 null）。 */
        static Entry fromJson(JSONObject o) {
            if (o == null) return null;
            String id = o.optString("id", "");
            String url = o.optString("url", "");
            if (id.isEmpty() || url.isEmpty()) return null;
            String origin = o.optString("origin", ORIGIN_MANUAL);
            if (!ORIGIN_MARKET.equals(origin)) origin = ORIGIN_MANUAL;
            return new Entry(id, url, o.optString("token", ""),
                    o.optBoolean("enabled", true), origin,
                    o.optString("name", ""), o.optString("desc", ""),
                    o.optString("cat", CAT_OTHER), o.optBoolean("paid", false));
        }
    }

    private final Prefs prefs;

    public McpServerStore(Prefs prefs) {
        this.prefs = prefs;
    }

    /** Android 侧工厂：包 SharedPreferences「mcp_config」。 */
    public static McpServerStore create(android.content.Context ctx) {
        final android.content.SharedPreferences sp =
                ctx.getSharedPreferences(PREFS_FILE, android.content.Context.MODE_PRIVATE);
        return new McpServerStore(new Prefs() {
            @Override public String getString(String key, String def) { return sp.getString(key, def); }
            @Override public void putString(String key, String value) {
                sp.edit().putString(key, value).apply();
            }
        });
    }

    /** 全部条目；首次读取触发旧单条配置自动迁移。 */
    public synchronized List<Entry> list() {
        String raw = prefs.getString(KEY_SERVERS, null);
        if (raw == null) raw = migrateLegacy();  // 无旧配置 → 仍为 null
        List<Entry> out = new ArrayList<>();
        if (raw == null || raw.isEmpty()) return out;
        JSONArray arr;
        try {
            arr = new JSONArray(raw);
        } catch (Exception e) {
            return out;  // 存储损坏不崩溃，降级为空列表（写操作会覆盖重写）
        }
        for (int i = 0; i < arr.length(); i++) {
            Entry e = Entry.fromJson(arr.optJSONObject(i));
            if (e != null) out.add(e);
        }
        return out;
    }

    /** 旧单条配置 → 列表第一条（origin=manual, enabled=true）；旧键保留不删。 */
    private String migrateLegacy() {
        String url = prefs.getString(LEGACY_URL, "");
        if (url == null || url.isEmpty()) return null;
        Entry e = new Entry(newId(), url, prefs.getString(LEGACY_TOKEN, ""), true, ORIGIN_MANUAL);
        JSONArray arr = new JSONArray();
        arr.put(e.toJson());
        String raw = arr.toString();
        prefs.putString(KEY_SERVERS, raw);
        return raw;
    }

    /** 新增条目（生成 id，enabled=true）。url 空 / origin 非法 → IllegalArgumentException。 */
    public synchronized Entry add(String url, String token, String origin) {
        return add(url, token, origin, "", "", CAT_OTHER, false);
    }

    /** 新增条目（全字段，工单25 本地页定稿：分类/简介/付费标）。 */
    public synchronized Entry add(String url, String token, String origin,
                                  String name, String desc, String cat, boolean paid) {
        if (url == null || url.isEmpty()) throw new IllegalArgumentException("url 不能为空");
        if (!ORIGIN_MANUAL.equals(origin) && !ORIGIN_MARKET.equals(origin))
            throw new IllegalArgumentException("origin 非法: " + origin);
        List<Entry> l = list();
        Entry e = new Entry(newId(), url, token != null ? token : "", true, origin,
                name != null ? name : "", desc != null ? desc : "",
                cat != null && !cat.isEmpty() ? cat : CAT_OTHER, paid);
        l.add(e);
        save(l);
        return e;
    }

    /** 组内排序（工单25：分类内顺序即默认——排第一 = 默认）。
     *  把 id 移到其所属分类组内的第 to 位（0 起，越界收敛）；不存在 → false。 */
    public synchronized boolean moveWithinCat(String id, int to) {
        List<Entry> l = list();
        Entry target = null;
        for (Entry e : l) if (e.id.equals(id)) target = e;
        if (target == null) return false;
        l.remove(target);
        // 同组条目在新列表中的插入点：数目标位置前有几个同 cat 的；越界收敛到组尾
        int idx = 0, seen = 0, groupTail = -1;
        for (; idx < l.size(); idx++) {
            if (l.get(idx).cat.equals(target.cat)) {
                if (seen == to) break;
                seen++;
                groupTail = idx;
            }
        }
        if (idx >= l.size() && groupTail >= 0) idx = groupTail + 1;
        l.add(idx, target);
        save(l);
        return true;
    }

    /** 某分类的默认服务 = 组内排第一个（停用的不算）。无 → null。 */
    public synchronized Entry defaultForCat(String cat) {
        for (Entry e : list()) {
            if (e.cat.equals(cat) && e.enabled) return e;
        }
        return null;
    }

    /** 按 id 删除；不存在 → false。 */
    public synchronized boolean remove(String id) {
        List<Entry> l = list();
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).id.equals(id)) {
                l.remove(i);
                save(l);
                return true;
            }
        }
        return false;
    }

    /** 按 id 开关 enabled；不存在 → false。 */
    public synchronized boolean setEnabled(String id, boolean enabled) {
        List<Entry> l = list();
        for (Entry e : l) {
            if (e.id.equals(id)) {
                e.enabled = enabled;
                save(l);
                return true;
            }
        }
        return false;
    }

    /** 兼容旧 mcp.get：默认第一条（无 → null）。 */
    public synchronized Entry first() {
        List<Entry> l = list();
        return l.isEmpty() ? null : l.get(0);
    }

    /** 兼容旧 mcp.set：写默认第一条的 url/token；列表为空则新建 manual 条目。 */
    public synchronized Entry setFirst(String url, String token) {
        List<Entry> l = list();
        Entry e;
        if (l.isEmpty()) {
            e = new Entry(newId(), url, token, true, ORIGIN_MANUAL);
            l.add(e);
        } else {
            e = l.get(0);
            e.url = url;
            e.token = token;
        }
        save(l);
        return e;
    }

    private void save(List<Entry> l) {
        JSONArray arr = new JSONArray();
        for (Entry e : l) arr.put(e.toJson());
        prefs.putString(KEY_SERVERS, arr.toString());
    }

    static String newId() {
        return "srv-" + UUID.randomUUID().toString().substring(0, 8);
    }
}
