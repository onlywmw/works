package com.hermes.android.toolprovider;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Environment;
import android.speech.RecognizerIntent;
import android.util.Base64;

import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.agent.ToolRegistry.*;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * UtilityToolProvider — 通用工具 (剪贴板/邮件/语音/下载/加密/编码)。
 */
public class UtilityToolProvider implements ToolProvider {

    private static Context appContext;
    private static MediaRecorder activeRecorder;
    private static File activeRecordFile;

    public static void init(Context ctx) { appContext = ctx.getApplicationContext(); }

    @Override public String id() { return "utility"; }

    @Override
    public List<Tool> discover() {
        List<Tool> list = new ArrayList<>();
        if (appContext == null) return list;

        // ═══ clipboard.read — 读剪贴板 ═══
        list.add(new Tool("clipboard.read",
            "读取系统剪贴板内容（仅文本）。Android 10+ 无额外权限要求",
            null, a -> {
                try {
                    android.content.ClipboardManager cm = (android.content.ClipboardManager)
                        appContext.getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm == null) return new Result(false, "ClipboardManager 不可用");
                    android.content.ClipData cd = cm.getPrimaryClip();
                    if (cd == null || cd.getItemCount() == 0) return new Result(true, "(剪贴板为空)");
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < cd.getItemCount(); i++) {
                        CharSequence s = cd.getItemAt(i).getText();
                        if (s != null) sb.append(s);
                    }
                    String text = sb.toString();
                    return new Result(true, text.isEmpty() ? "(剪贴板为空)" : text);
                } catch (Exception e) {
                    return new Result(false, "读取剪贴板失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 3, "util",
            new ParamDef[]{},
            "成功: 剪贴板文本 | 失败: 错误原因",
            null,
            new String[]{"仅支持文本内容（非图片/文件）", "Android 10+ 无权限要求"},
            5000,
            new ToolRegistry.Manifest("读剪贴板", "low", "读取剪贴板文本", false, "io"),
            null));

        // ═══ email.send — 发邮件 ═══
        list.add(new Tool("email.send",
            "通过系统邮件 App 发送邮件（会弹出邮件 App，用户确认后发送）",
            null, a -> {
                String to = a.optString("to", "");
                String subject = a.optString("subject", "");
                String body = a.optString("body", "");
                if (to.isEmpty() && subject.isEmpty() && body.isEmpty())
                    return new Result(false, "收件人、主题、正文至少填一项");
                try {
                    Intent email = new Intent(Intent.ACTION_SENDTO);
                    email.setData(Uri.parse("mailto:"));
                    email.putExtra(Intent.EXTRA_EMAIL, to.isEmpty() ? new String[]{} : new String[]{to});
                    if (!subject.isEmpty()) email.putExtra(Intent.EXTRA_SUBJECT, subject);
                    if (!body.isEmpty()) email.putExtra(Intent.EXTRA_TEXT, body);
                    email.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    appContext.startActivity(email);
                    return new Result(true, "邮件 App 已打开" + (to.isEmpty() ? "" : " → " + to));
                } catch (Exception e) {
                    return new Result(false, "启动邮件失败: " + e.getMessage());
                }
            }, "native", "write", "none", true, 10, "email",
            new ParamDef[]{
                new ParamDef("to", "string", false, "", "收件人邮箱"),
                new ParamDef("subject", "string", false, "", "邮件主题"),
                new ParamDef("body", "string", false, "", "邮件正文"),
            },
            "成功: 邮件 App 已打开 | 失败: 错误原因",
            null,
            new String[]{"需要设备上有邮件 App（Gmail/Outlook 等）", "邮件内容需用户手动确认发送"},
            1000,
            new ToolRegistry.Manifest("发邮件", "low", "通过邮件 App 发邮件", false, "io"),
            null));

        // ═══ speech.recognize — 语音识别 ═══
        list.add(new Tool("speech.recognize",
            "语音转文字（打开系统语音输入面板，用户说话后返回识别文本）",
            null, a -> {
                try {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    String lang = a.optString("lang", Locale.getDefault().getLanguage());
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "请说话…");
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    appContext.startActivity(intent);
                    return new Result(true, "语音识别已启动（结果通过 onActivityResult 返回，暂时无法直接捕获）\n"
                        + "提示: 如需获取结果，请用 shell.exec 配合外部 STT 引擎");
                } catch (Exception e) {
                    return new Result(false, "启动语音识别失败: " + e.getMessage() + "\n"
                        + "提示: 用 shell.exec 'whisper audio.wav' 离线识别");
                }
            }, "native", "write", "none", true, 15, "media",
            new ParamDef[]{
                new ParamDef("lang", "string", false, "默认系统语言", "识别语言代码，如 zh-CN / en-US"),
            },
            "成功: 语音面板已启动 | 失败: 无语音服务",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"speech.recognize\",\"args\":{\"lang\":\"zh-CN\"}}"},
            new String[]{"依赖系统语音识别服务（Google App / 厂商语音助手）", "结果无法直接捕获回 MOV，会显示在系统界面"},
            1000,
            new ToolRegistry.Manifest("语音识别", "medium", "语音转文字", false, "media"),
            null));

        // ═══ audio.record — 录音 ═══
        list.add(new Tool("audio.record",
            "开始/停止录音。调用一次开始，再调用一次停止并返回文件路径",
            null, a -> {
                String action = a.optString("action", "toggle");
                if ("stop".equals(action) || "toggle".equals(action) && activeRecorder != null) {
                    if (activeRecorder == null) return new Result(false, "没有正在进行的录音");
                    try {
                        activeRecorder.stop();
                        activeRecorder.release();
                        activeRecorder = null;
                        return new Result(true, "录音已停止 → " + activeRecordFile.getAbsolutePath(),
                            activeRecordFile.getAbsolutePath());
                    } catch (Exception e) {
                        activeRecorder = null;
                        return new Result(false, "停止录音失败: " + e.getMessage());
                    }
                }
                // start
                if (activeRecorder != null) return new Result(false, "已有录音进行中，请先停止");
                if (appContext.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                    return new Result(false, "无 RECORD_AUDIO 权限");
                try {
                    File dir = new File(appContext.getExternalFilesDir(null), "recordings");
                    dir.mkdirs();
                    activeRecordFile = new File(dir, "MOV_" + UUID.randomUUID().toString().substring(0, 8) + ".m4a");
                    MediaRecorder mr = new MediaRecorder();
                    mr.setAudioSource(MediaRecorder.AudioSource.MIC);
                    mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                    mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                    mr.setOutputFile(activeRecordFile.getAbsolutePath());
                    mr.prepare();
                    mr.start();
                    activeRecorder = mr;
                    return new Result(true, "录音开始 → " + activeRecordFile.getName() + "（再次调用 audio.record 停止）");
                } catch (Exception e) {
                    activeRecorder = null;
                    return new Result(false, "启动录音失败: " + e.getMessage());
                }
            }, "native", "write", "always", false, 300, "media",
            new ParamDef[]{
                new ParamDef("action", "string", false, "默认 toggle", "start 开始 / stop 停止 / toggle 切换"),
            },
            "开始: 录音中… | 停止: 文件路径",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"audio.record\",\"args\":{\"action\":\"start\"}}",
                "{\"action\":\"tool.execute\",\"name\":\"audio.record\",\"args\":{\"action\":\"stop\"}}"},
            new String[]{"需要 RECORD_AUDIO 权限", "最长录制 5 分钟（300 秒）", "格式 M4A/AAC"},
            1000,
            new ToolRegistry.Manifest("录音", "medium", "录制音频", false, "media"),
            null));

        // ═══ download.file — 下载文件 ═══
        list.add(new Tool("download.file",
            "从 URL 下载文件到房间（支持 HTTP/HTTPS，大文件需在 shell.exec 里用 curl）",
            null, a -> {
                String url = a.optString("url", "");
                if (url.isEmpty()) return new Result(false, "URL 为空");
                if (!url.startsWith("http://") && !url.startsWith("https://"))
                    return new Result(false, "URL 必须以 http:// 或 https:// 开头");
                String filename = a.optString("filename", "");
                if (filename.isEmpty()) {
                    String[] parts = url.split("/");
                    filename = parts[parts.length - 1];
                    if (filename.isEmpty() || filename.contains("?")) filename = "download";
                }
                int timeout = a.optInt("timeoutSec", 30);
                if (timeout < 5 || timeout > 300) timeout = 30;
                try {
                    File dir = new File(appContext.getExternalFilesDir(null), "downloads");
                    dir.mkdirs();
                    File outFile = new File(dir, filename);
                    HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(timeout * 1000);
                    conn.setRequestProperty("User-Agent", "MOV-Agent/1.0");
                    conn.setInstanceFollowRedirects(true);
                    conn.connect();
                    int code = conn.getResponseCode();
                    if (code != 200) return new Result(false, "HTTP " + code);
                    long total = conn.getContentLengthLong();
                    InputStream in = conn.getInputStream();
                    OutputStream out = new FileOutputStream(outFile);
                    byte[] buf = new byte[8192];
                    int n, downloaded = 0;
                    while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); downloaded += n; }
                    in.close(); out.close(); conn.disconnect();
                    String size = downloaded >= 1_000_000 ? String.format("%.1fMB", downloaded / 1_000_000.0)
                        : downloaded >= 1000 ? (downloaded / 1000) + "KB" : downloaded + "B";
                    return new Result(true, filename + " → " + size + " 已下载", outFile.getAbsolutePath());
                } catch (Exception e) {
                    return new Result(false, "下载失败: " + e.getMessage() + "\n"
                        + "大文件建议用 shell.exec 'curl -L -o file \"URL\"'");
                }
            }, "native", "write", "plan", false, 300, "file",
            new ParamDef[]{
                new ParamDef("url", "string", true, "", "文件 URL（HTTP/HTTPS）"),
                new ParamDef("filename", "string", false, "从 URL 提取", "保存文件名"),
                new ParamDef("timeoutSec", "int", false, "默认 30", "超时秒数（5-300）"),
            },
            "成功: 文件名 + 大小 | 失败: 错误原因",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"download.file\",\"args\":{\"url\":\"https://example.com/data.json\"}}"},
            new String[]{"小文件（<50MB）直接用，大文件用 shell.exec curl", "不支持 FTP/磁力链", "文件名不含路径，保存到 downloads/"},
            2000,
            new ToolRegistry.Manifest("下载文件", "medium", "从 URL 下载文件", false, "io"),
            null));

        // ═══ hash.text — 计算哈希 ═══
        list.add(new Tool("hash.text",
            "计算文本的 MD5 / SHA256 哈希值",
            null, a -> {
                String text = a.optString("text", "");
                if (text.isEmpty()) return new Result(false, "文本为空");
                String algo = a.optString("algo", "sha256").toLowerCase(Locale.US);
                if (!"md5".equals(algo) && !"sha256".equals(algo) && !"sha1".equals(algo))
                    return new Result(false, "不支持的算法: " + algo + "，支持 md5/sha1/sha256");
                try {
                    MessageDigest md = MessageDigest.getInstance(algo.replace("sha256", "SHA-256").replace("sha1", "SHA-1").replace("md5", "MD5"));
                    byte[] digest = md.digest(text.getBytes("UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    for (byte b : digest) sb.append(String.format("%02x", b));
                    return new Result(true, algo.toUpperCase(Locale.US) + ": " + sb.toString());
                } catch (Exception e) {
                    return new Result(false, "哈希失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 5, "util",
            new ParamDef[]{
                new ParamDef("text", "string", true, "", "要哈希的文本"),
                new ParamDef("algo", "string", false, "默认 sha256", "md5 / sha1 / sha256"),
            },
            "成功: 算法名: 十六进制哈希值",
            null,
            new String[]{"用于校验文件完整性", "文本内容不要过长（建议 < 100KB）"},
            2000,
            new ToolRegistry.Manifest("哈希计算", "low", "计算文本哈希", false, "io"),
            null));

        // ═══ uuid.generate — 生成 UUID ═══
        list.add(new Tool("uuid.generate",
            "生成随机 UUID v4",
            null, a -> {
                int count = a.optInt("count", 1);
                if (count < 1 || count > 20) count = 1;
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < count; i++) sb.append(UUID.randomUUID().toString()).append("\n");
                return new Result(true, sb.toString().trim());
            }, "native", "readonly", "none", true, 1, "util",
            new ParamDef[]{
                new ParamDef("count", "int", false, "默认 1", "生成数量（1-20）"),
            },
            "成功: UUID 列表（每行一个）",
            null,
            new String[]{"UUID v4 = 随机生成，全局唯一", "count 最大 20"},
            500,
            new ToolRegistry.Manifest("生成 UUID", "low", "生成随机 ID", false, "io"),
            null));

        // ═══ base64.encode — Base64 编码 ═══
        list.add(new Tool("base64.encode",
            "将文本编码为 Base64",
            null, a -> {
                String text = a.optString("text", "");
                if (text.isEmpty()) return new Result(false, "文本为空");
                try {
                    String encoded = Base64.encodeToString(text.getBytes("UTF-8"), Base64.NO_WRAP);
                    return new Result(true, encoded);
                } catch (Exception e) {
                    return new Result(false, "编码失败: " + e.getMessage());
                }
            }, "native", "readonly", "none", true, 3, "util",
            new ParamDef[]{
                new ParamDef("text", "string", true, "", "要编码的文本"),
            },
            "成功: Base64 字符串 | 失败: 错误原因",
            null,
            new String[]{"用于编码凭证/二进制数据嵌入 JSON", "解码用 base64.decode"},
            5000,
            new ToolRegistry.Manifest("Base64 编码", "low", "文本→Base64", false, "io"),
            null));

        // ═══ base64.decode — Base64 解码 ═══
        list.add(new Tool("base64.decode",
            "将 Base64 字符串解码为原文",
            null, a -> {
                String text = a.optString("text", "");
                if (text.isEmpty()) return new Result(false, "文本为空");
                try {
                    byte[] decoded = Base64.decode(text, Base64.NO_WRAP);
                    return new Result(true, new String(decoded, "UTF-8"));
                } catch (Exception e) {
                    return new Result(false, "解码失败: " + e.getMessage() + "（输入可能不是有效 Base64）");
                }
            }, "native", "readonly", "none", true, 3, "system",
            new ParamDef[]{
                new ParamDef("text", "string", true, "", "要解码的 Base64 文本"),
            },
            "成功: 解码后的文本 | 失败: 错误原因",
            null,
            new String[]{"输入必须是标准 Base64", "解码结果长度限制 50KB"},
            3000,
            new ToolRegistry.Manifest("Base64 解码", "low", "Base64→文本", false, "io"),
            null));

        // ═══ qr.generate — 生成二维码 ═══
        list.add(new Tool("qr.generate",
            "生成二维码文本（返回终端可显示的 ANSI QR 码，或引导用 Python 库）",
            null, a -> {
                String text = a.optString("text", "");
                if (text.isEmpty()) return new Result(false, "文本为空");
                // 纯 Java 实现 QR 太复杂，引导用 Python
                return new Result(true, "QR 生成建议:\n"
                    + "1. shell.exec 'python3 -c \"import qrcode; qrcode.make(\\\"\"\""
                    + text.replace("\"", "\\\"") + "\"\"\\\").save(\\\"/room/qr.png\\\")\"'\n"
                    + "2. 或安装: shell.exec 'pip install qrcode[pil] --break-system-packages'\n"
                    + "3. 生成后 file.read qr.png 确认");
            }, "native", "readonly", "none", true, 5, "util",
            new ParamDef[]{
                new ParamDef("text", "string", true, "", "要编码的文本/URL"),
                new ParamDef("size", "int", false, "默认 10", "模块大小（1-40）"),
            },
            "引导说明 + shell.exec 命令",
            null,
            new String[]{"需要 shell.exec 和 Python qrcode 库", "生成 PNG 图片到 /room/ 目录"},
            1000,
            new ToolRegistry.Manifest("生成二维码", "low", "生成 QR 码图片", false, "io"),
            null));

        return list;
    }
}
