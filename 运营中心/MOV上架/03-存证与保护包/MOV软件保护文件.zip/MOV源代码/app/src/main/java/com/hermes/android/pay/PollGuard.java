package com.hermes.android.pay;

import java.util.HashSet;
import java.util.Set;

/**
 * PollGuard — 查单轮询在轮标记（验收打回 P3 的可测核心）。
 * 不变量：
 *   ① 同一 orderId 同时最多一条轮询链（tryAcquire 二次调用必 false）
 *   ② release 后可重新获取（链终结/后台链死释放标记）
 *   ③ clear 全释放（onPause 清空 handler 后配套调用）
 * 主线程使用（MarketEngine 全部回调在 main Handler），无需并发保护。
 */
class PollGuard {

    private final Set<String> polling = new HashSet<>();

    /** 尝试占链：成功 true（调用方负责挂 Runnable）；已在轮 false（不得再挂） */
    boolean tryAcquire(String orderId) {
        return polling.add(orderId);
    }

    /** 释放标记：链终结（PAID/EXPIRED/MANUAL）或后台不重挂（链死）时调用 */
    void release(String orderId) {
        polling.remove(orderId);
    }

    /** 全释放：onPause 清空 handler 后调用 */
    void clear() {
        polling.clear();
    }

    boolean isPolling(String orderId) {
        return polling.contains(orderId);
    }
}
