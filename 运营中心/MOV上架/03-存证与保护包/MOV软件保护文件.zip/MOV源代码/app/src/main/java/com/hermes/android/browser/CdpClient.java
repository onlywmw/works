package com.hermes.android.browser;

import org.json.JSONObject;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/**
 * 批3: CDP 客户端——通过 Chrome DevTools Protocol 控制真实浏览器（借鉴 Kimi webbridge）。
 * 静态单例：connect(wsUrl) 连调试端点，send(method, params) 发 CDP 命令等响应。
 * 未连接时 send 抛错（工具返回"未配置浏览器"归因，非假绿）。
 */
public class CdpClient {

    private static CdpClient instance;

    private final OkHttpClient http;
    private final Map<Integer, CompletableFuture<JSONObject>> pending = new ConcurrentHashMap<>();
    private WebSocket ws;
    private volatile boolean connected = false;
    private final java.util.concurrent.atomic.AtomicInteger nextId = new java.util.concurrent.atomic.AtomicInteger(1);

    private CdpClient() {
        http = new OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();
    }

    public static CdpClient instance() {
        if (instance == null) instance = new CdpClient();
        return instance;
    }

    public boolean isConnected() { return connected; }

    /** 连接 CDP 调试端点（如 ws://127.0.0.1:9222/devtools/page/<id>） */
    public void connect(String wsUrl) {
        if (ws != null) { try { ws.close(1000, null); } catch (Exception ignored) {} }
        connected = false;
        Request req = new Request.Builder().url(wsUrl).build();
        ws = http.newWebSocket(req, new WebSocketListener() {
            @Override public void onOpen(WebSocket webSocket, Response response) { connected = true; }
            @Override public void onMessage(WebSocket webSocket, String text) {
                try {
                    JSONObject msg = new JSONObject(text);
                    int id = msg.optInt("id", -1);
                    CompletableFuture<JSONObject> f = pending.remove(id);
                    if (f != null) f.complete(msg);
                } catch (Exception ignored) {}
            }
            @Override public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                connected = false;
                for (CompletableFuture<JSONObject> f : pending.values()) f.completeExceptionally(t);
                pending.clear();
            }
            @Override public void onClosed(WebSocket webSocket, int code, String reason) { connected = false; }
        });
    }

    /** 发送 CDP 命令并等待响应（≤15s）；未连接抛错 */
    public JSONObject send(String method, JSONObject params) throws Exception {
        if (!connected || ws == null) {
            throw new Exception("浏览器 CDP 未连接（需 Chrome/Edge 开远程调试端口后 connect）");
        }
        int id = nextId.getAndIncrement();
        JSONObject cmd = new JSONObject().put("id", id).put("method", method);
        if (params != null) cmd.put("params", params);
        CompletableFuture<JSONObject> f = new CompletableFuture<>();
        pending.put(id, f);
        ws.send(cmd.toString());
        JSONObject resp = f.get(15, TimeUnit.SECONDS);
        if (resp.has("error")) {
            JSONObject err = resp.optJSONObject("error");
            throw new Exception("CDP " + method + " 失败: "
                    + (err != null ? err.optString("message", "") : ""));
        }
        return resp.optJSONObject("result");
    }
}
