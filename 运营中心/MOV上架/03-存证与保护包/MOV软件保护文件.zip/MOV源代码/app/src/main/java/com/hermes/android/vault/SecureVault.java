package com.hermes.android.vault;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * SecureVault — 双副本保险柜「原始副本」加密存储（DESIGN_OCR_MOBILE v2 §六②）。
 *
 * Keystore-backed AES-GCM 加密落盘 filesDir/vault/&lt;id&gt;.enc；
 * 条目索引 filesDir/vault/index.json 只存元信息（id/名称/时间/大小），不存内容。
 * 文件名 = 不透明 UUID（脱敏），原文/原图只在 vault 目录内。
 *
 * 纪律：
 * - 原文不进 vault 目录以外的任何地方（不落房间/journal/外部路径）
 * - index 不许出现内容片段；名称自动脱敏（长数字串 → [数字]，防身份证/手机/卡号进索引）
 * - 加密 = 真 Keystore AES-GCM（生产 AndroidKeyStore / JVM 测试真 JCEKS 白盒，共用 AesGcm 核心），
 *   禁止 mock 假装加密（KeystoreFallback 三形态①）
 */
public class SecureVault {

    /** 加密引擎：真加解密，不 mock（三形态①防守点） */
    public interface CryptoEngine {
        byte[] encrypt(byte[] plaintext) throws Exception;
        byte[] decrypt(byte[] data) throws Exception;   // data = [12B IV][GCM 密文+tag]

        /**
         * v1.1 钥匙轮换：尝试用旧版本 key 解密（条目可能是升级前用旧别名 key 加密的）。
         * 非旧 key 加密返回 null。默认无旧 key。KeystoreCrypto 实现真迁移回退。
         */
        default byte[] decryptLegacy(byte[] data) { return null; }
    }

    /** 列表条目 — 只含元信息，无内容 */
    public static class VaultEntry {
        public final String id;
        public final String name;
        public final long createdAtMs;
        public final long sizeBytes;   // 密文长度（可感知内容量级，非内容）
        VaultEntry(String id, String name, long createdAtMs, long sizeBytes) {
            this.id = id; this.name = name; this.createdAtMs = createdAtMs; this.sizeBytes = sizeBytes;
        }
    }

    private static final Pattern LONG_DIGITS = Pattern.compile("\\d{6,}");
    private static final int NAME_MAX = 40;

    private final File vaultDir;
    private final File indexFile;
    private final CryptoEngine crypto;

    /** 生产构造：filesDir/vault/ + AndroidKeyStore 主密钥 */
    public SecureVault(Context ctx) {
        this(new File(ctx.getFilesDir(), "vault"), new KeystoreCrypto());
    }

    /** 测试/注入构造：任意目录 + 任意真 CryptoEngine */
    public SecureVault(File vaultDir, CryptoEngine crypto) {
        this.vaultDir = vaultDir;
        this.indexFile = new File(vaultDir, "index.json");
        this.crypto = crypto;
    }

    public File getVaultDir() { return vaultDir; }

    /** 存一条文本 → 返回 id */
    public synchronized String lock(String name, String plainText) throws Exception {
        return lockBytes(name, plainText.getBytes(StandardCharsets.UTF_8));
    }

    /** 存一条二进制（原图等）→ 返回 id */
    public synchronized String lockBytes(String name, byte[] data) throws Exception {
        if (data == null || data.length == 0) throw new VaultException("EMPTY", "不能存空内容");
        byte[] ct = crypto.encrypt(data);
        String id = UUID.randomUUID().toString();
        writeFile(new File(vaultDir, id + ".enc"), ct);
        JSONObject index = loadIndex();
        JSONArray entries = index.getJSONArray("entries");
        entries.put(new JSONObject()
                .put("id", id)
                .put("name", sanitizeName(name))
                .put("createdAtMs", System.currentTimeMillis())
                .put("sizeBytes", ct.length));
        saveIndex(index);
        return id;
    }

    /** 取回文本（件2 起须先过 Keyguard 闸再调本方法） */
    public synchronized String unlock(String id) throws Exception {
        return new String(unlockBytes(id), StandardCharsets.UTF_8);
    }

    /** 取回二进制（v1.1 钥匙轮换：当前 key 失败 → 试旧 key → 成功则重加密到当前 key） */
    public synchronized byte[] unlockBytes(String id) throws Exception {
        File f = new File(vaultDir, id + ".enc");
        if (!f.exists()) throw new VaultException("NOT_FOUND", "保险柜条目不存在");
        byte[] ct = readFile(f);
        try {
            return crypto.decrypt(ct);
        } catch (Exception e) {
            byte[] legacy = crypto.decryptLegacy(ct);
            if (legacy != null) {
                // v1.1: 旧 key 加密的条目 → 用当前 key 重加密落盘（迁移），旧条目零丢失
                writeFile(f, crypto.encrypt(legacy));
                return legacy;
            }
            throw new VaultException("DECRYPT_FAILED", "密文损坏或密钥不匹配");
        }
    }

    /** 列表 — 只有元信息，无内容（vault_list 工具 / 设置页列表用） */
    public synchronized List<VaultEntry> list() {
        List<VaultEntry> out = new ArrayList<>();
        try {
            JSONObject index = loadIndex();
            JSONArray entries = index.optJSONArray("entries");
            if (entries != null) {
                for (int i = 0; i < entries.length(); i++) {
                    JSONObject o = entries.optJSONObject(i);
                    if (o == null) continue;
                    out.add(new VaultEntry(
                            o.optString("id", ""),
                            o.optString("name", ""),
                            o.optLong("createdAtMs", 0),
                            o.optLong("sizeBytes", 0)));
                }
            }
        } catch (Exception e) {
            // index 损坏 → 空列表，不抛（列表本身是只读降级路径）
        }
        return out;
    }

    /** 删除：文件 + index 条目都清 */
    public synchronized boolean delete(String id) {
        File f = new File(vaultDir, id + ".enc");
        boolean removed = f.exists() && f.delete();
        try {
            JSONObject index = loadIndex();
            JSONArray entries = index.getJSONArray("entries");
            JSONArray kept = new JSONArray();
            for (int i = 0; i < entries.length(); i++) {
                JSONObject o = entries.optJSONObject(i);
                if (o != null && !id.equals(o.optString("id"))) kept.put(o);
            }
            index.put("entries", kept);
            saveIndex(index);
        } catch (Exception e) {
            // index 更新失败不吞文件删除结果
        }
        return removed;
    }

    /**
     * 名称脱敏：长数字串（≥6 位，身份证/手机/卡号片段）→ [数字]，并截断到 40 字。
     * 保证 index 里即使名称含 PII 也不落原文片段。
     */
    public static String sanitizeName(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "未命名";
        String t = raw.trim().replace('\n', ' ').replace('\r', ' ');
        t = LONG_DIGITS.matcher(t).replaceAll("[数字]");
        if (t.length() > NAME_MAX) t = t.substring(0, NAME_MAX) + "…";
        return t;
    }

    // ==================== index 读写 ====================

    private JSONObject loadIndex() throws Exception {
        if (indexFile.exists()) {
            String s = new String(readFile(indexFile), StandardCharsets.UTF_8);
            JSONObject o = new JSONObject(s);
            if (!o.has("entries")) o.put("entries", new JSONArray());
            return o;
        }
        return new JSONObject().put("entries", new JSONArray());
    }

    private void saveIndex(JSONObject index) throws Exception {
        writeFile(indexFile, index.toString(2).getBytes(StandardCharsets.UTF_8));
    }

    private void writeFile(File f, byte[] data) throws Exception {
        vaultDir.mkdirs();
        try (FileOutputStream os = new FileOutputStream(f)) {
            os.write(data);
        }
    }

    private byte[] readFile(File f) throws IOException {
        try (FileInputStream is = new FileInputStream(f)) {
            java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = is.read(b)) > 0) buf.write(b, 0, n);
            return buf.toByteArray();
        }
    }
}
