package com.hermes.android.browser;
import com.hermes.android.ConnectWebActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Map;

import com.hermes.android.workflow.ActionExecutor;

/**
 * Workflow 动作执行器 — 浏览器动作经 ConnectWeb 同步执行（javaCbMap 桥 + CountDownLatch）。
 * 浏览器未打开时动作跳过（诚实：不伪装执行）；动作 type 为空跳过。
 */
public class BrowserActionExecutor implements ActionExecutor {

    @Override
    public ActionReceipt execute(JSONArray actions, Map<String, Object> context) {
        if (actions == null || actions.length() == 0) return ActionReceipt.NO_EFFECT;
        ActionReceipt overall = ActionReceipt.SUCCESS;
        for (int i = 0; i < actions.length(); i++) {
            JSONObject a = actions.optJSONObject(i);
            if (a == null) continue;
            String type = a.optString("type", "");
            if (type.isEmpty()) continue;
            ConnectWebActivity cw = ConnectWebActivity.getCurrent();
            if (cw == null) { overall = ActionReceipt.REJECTED; continue; }   // 浏览器未开
            try {
                String r = cw.executeBrowserActionSync(a);
                ActionReceipt one = classify(r);
                if (one != ActionReceipt.SUCCESS) overall = one;   // 取最差回执
            } catch (Exception e) {
                android.util.Log.e("Workflow", "action execute error", e);
                overall = ActionReceipt.REJECTED;
            }
        }
        return overall;
    }

    /** 执行结果分类：null=超时；error/gate_rejected=拒绝；其余=成功 */
    private static ActionReceipt classify(String result) {
        if (result == null) return ActionReceipt.TIMEOUT;
        if (result.contains("gate_rejected") || result.contains("\"error\"")) return ActionReceipt.REJECTED;
        return ActionReceipt.SUCCESS;
    }
}
