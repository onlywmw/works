// newface-fitness.js — 工单12 幕三 新脸健身卡（今日速记 / 域历史时间线 / 周叙事卡）
// 纪律：createElement + textContent，禁 innerHTML 拼用户输入；纯逻辑函数供 node 单测。
(function () {
  'use strict';
  var NS = window.MovFitness = window.MovFitness || {};

  // ── 纯逻辑（node 单测） ──

  /** 域历史时间线：mem.domain 数据 → 时间倒序 verbatim 项 */
  NS.timeline = function (data) {
    var cover = (data && data.data && data.data.cover) || [];
    var arr = [];
    for (var i = 0; i < cover.length; i++) {
      var it = cover[i];
      if (it && it.mode === 'verbatim' && it.ts) arr.push({ ts: it.ts, text: it.text || '' });
    }
    arr.sort(function (a, b) { return b.ts - a.ts; });
    return arr;
  };

  /** 周叙事解析：weekly_narrative 响应 → 非空行数组（趋势/异常/建议…） */
  NS.narrative = function (resp) {
    var n = (resp && resp.data && resp.data.narrative) || '';
    return n.split('\n').map(function (l) { return l.trim(); }).filter(Boolean);
  };

  // ── 渲染（createElement，禁 innerHTML 拼用户输入） ──

  NS.renderTimelineItem = function (item, doc) {
    doc = doc || document;
    var row = doc.createElement('div');
    row.className = 'fitness-tl-item';
    var time = doc.createElement('span');
    time.className = 'fitness-tl-ts';
    time.textContent = item.ts ? new Date(item.ts).toLocaleDateString('zh-CN') : '';
    var text = doc.createElement('span');
    text.className = 'fitness-tl-text';
    text.textContent = item.text;
    row.appendChild(time);
    row.appendChild(text);
    return row;
  };

  NS.renderNarrativeItem = function (line, doc) {
    doc = doc || document;
    var li = doc.createElement('div');
    li.className = 'fitness-narr-item';
    li.textContent = line;
    return li;
  };

  /** 把三块渲染进容器（#view-face 或指定 el） */
  NS.render = function (memData, narrResp, el) {
    el = el || document.getElementById('view-face');
    if (!el) return;
    // 清理旧健身卡容器
    var host = document.getElementById('fitness-card');
    if (host) host.parentNode.removeChild(host);
    host = document.createElement('div');
    host.id = 'fitness-card';

    var title = document.createElement('div');
    title.className = 'fitness-title';
    title.textContent = '健身';
    host.appendChild(title);

    // ① 域历史时间线
    var tlTitle = document.createElement('div');
    tlTitle.className = 'fitness-sec';
    tlTitle.textContent = '域历史';
    host.appendChild(tlTitle);
    var items = NS.timeline(memData);
    if (items.length === 0) {
      var empty = document.createElement('div');
      empty.textContent = '暂无健身记录';
      host.appendChild(empty);
    } else {
      for (var i = 0; i < items.length; i++) host.appendChild(NS.renderTimelineItem(items[i]));
    }

    // ② 周叙事卡
    var nrTitle = document.createElement('div');
    nrTitle.className = 'fitness-sec';
    nrTitle.textContent = '本周身体叙事';
    host.appendChild(nrTitle);
    var lines = NS.narrative(narrResp);
    if (lines.length === 0) {
      var nEmpty = document.createElement('div');
      nEmpty.textContent = '暂无周叙事';
      host.appendChild(nEmpty);
    } else {
      for (var j = 0; j < lines.length; j++) host.appendChild(NS.renderNarrativeItem(lines[j]));
    }

    el.appendChild(host);
  };
})();
