package com.hermes.android.serve;

import android.content.Context;
import android.util.Log;

import com.hermes.android.agent.ToolRegistry;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MOV 入站监听 — Hermes 阶段3 A0（反向通道地基）。
 *
 * serve（proot 内）要回调 MOV 执行工具/推理/记忆，但 MOV 只有出站 OkHttp，无入站监听。
 * 本组件起 127.0.0.1:8388 HTTP 监听，暴露：
 *   GET  /healthz               → {ok, version}（回调前探活，与 daemon healthz-on-call 对称；无鉴权）
 *   POST /tools/{name}/invoke   → {params} → ToolRegistry.find().handler.run() → {ok, data}/{ok, error}
 *   POST /infer、/memory        → 404 预留（B/C 吃同一通道，本件不实现）
 *
 * 鉴权：X-Mov-Token（与 daemon 同 token，HermesServeConfig），fail-closed——
 * 未配置 token / 错 token 一律 401；非 127.0.0.1 来源拒绝（bind 127.0.0.1 + 显式来源校验双保险）。
 * 信封：统一 {ok, data?} / {ok, error:{code,msg}}（照 serve 契约）。
 *
 * 安全闸：本件「不新增闸」——dispatch 只调 ToolRegistry.find().handler.run()，走 ToolRegistry 内建
 * DevicePolicy；危险工具的 approval 确认闸是 A（工具统一）件的职责，A0 不做。
 */
public class MovInboundServer {

    private static final String TAG = "MovInboundServer";
    public static final int PORT = 8388;

    private final ToolRegistry registry;
    private final String token;
    private ServerSocket serverSocket;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean running;

    /** 单例（app 进程内常驻，HermesApplication.onCreate 起） */
    private static volatile MovInboundServer instance;

    private final Context context;   // 阶段3 B: /infer 需要 ModelRegistry（默认模型）取 LLM

    public MovInboundServer(ToolRegistry registry, String token, Context context) {
        this.registry = registry;
        this.token = token;
        this.context = context;
    }

    // ==================== 生命周期 ====================

    /** 幂等启动；返回是否在本实例起成功（已跑则 false）。 */
    public synchronized boolean start() {
        if (running) return false;
        try {
            serverSocket = new ServerSocket();
            serverSocket.setReuseAddress(true);
            serverSocket.bind(new InetSocketAddress("127.0.0.1", PORT));
            running = true;
            logI("MOV 入站监听启动 127.0.0.1:" + PORT);
            pool.submit(this::acceptLoop);
            return true;
        } catch (Exception e) {
            logW("启动失败 (8388 被占用?): " + e.getMessage());
            return false;
        }
    }

    public synchronized void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        pool.shutdownNow();
        logI("MOV 入站监听已停止");
    }

    /* 日志尽力而为 (同 invokeTool 既有模式: JVM 单测无 android.util.Log stub, 静默跳过) */
    private static void logI(String msg) {
        try { Log.i(TAG, msg); } catch (Exception ignored) {}
    }

    private static void logW(String msg) {
        try { Log.w(TAG, msg); } catch (Exception ignored) {}
    }

    public boolean isRunning() { return running; }

    /** app 进程内单例启动（幂等）：起常驻监听，供 daemon 回调。 */
    public static void ensureRunning(Context ctx) {
        MovInboundServer s = instance;
        if (s != null && s.isRunning()) return;
        synchronized (MovInboundServer.class) {
            if (instance != null && instance.isRunning()) return;
            try {
                String tok = com.hermes.android.agent.HermesServeConfig.token(ctx);
                instance = new MovInboundServer(buildServerRegistry(ctx), tok, ctx);
                instance.start();
            } catch (Exception e) {
                Log.w(TAG, "ensureRunning 失败: " + e.getMessage());
            }
        }
    }

    /** A0 专用 Context 级注册表（统一构建源：与 ToolManifest 共用 RegistryProvider） */
    private static ToolRegistry buildServerRegistry(Context ctx) {
        return com.hermes.android.mcp.server.RegistryProvider.build(ctx);
    }

    // ==================== HTTP 循环（McpServer 同款） ====================

    private void acceptLoop() {
        while (running) {
            try {
                Socket client = serverSocket.accept();
                pool.submit(() -> handle(client));
            } catch (Exception e) {
                if (running) logW("accept 异常: " + e.getMessage());
            }
        }
    }

    private void handle(Socket client) {
        try {
            /* 真机验收 2026-08-05 (P4): 请求体必须按字节读 —— Content-Length 是字节数,
               原实现用 BufferedReader 按字符读, 多字节 UTF-8 (中文参数) 会读到长度不足
               阻塞到客户端超时 (causal.record 中文参数必挂, 真机实测 120s 无响应)。
               头部逐字节扫到 \r\n\r\n (HTTP 头为 ASCII), 再精确读 contentLength 字节体。 */
            java.io.BufferedInputStream in =
                    new java.io.BufferedInputStream(client.getInputStream());
            OutputStream out = client.getOutputStream();

            String head = readHead(in);
            if (head == null) { client.close(); return; }
            String[] headLines = head.split("\r\n");
            String[] parts = headLines[0].split(" ");
            String method = parts.length > 0 ? parts[0] : "";
            String path = parts.length > 1 ? parts[1].split("\\?")[0] : "";

            String authHeader = "";
            int contentLength = 0;
            for (int i = 1; i < headLines.length; i++) {
                String lower = headLines[i].toLowerCase();
                if (lower.startsWith("x-mov-token:")) authHeader = headLines[i].substring(12).trim();
                // 工单9 幕一 出网网关: serve agent 走 OpenAI 兼容调用带 Authorization: Bearer(标准方式)——
                // 与 X-Mov-Token 并列接受(同 token, fail-closed 语义不变)
                if (lower.startsWith("authorization: bearer ")) authHeader = headLines[i].substring(21).trim();
                if (lower.startsWith("content-length:")) {
                    try { contentLength = Integer.parseInt(headLines[i].substring(15).trim()); } catch (Exception ignored) {}
                }
            }

            byte[] body = readFully(in, contentLength);
            JSONObject jsonBody = null;
            if (body != null && body.length > 0) {
                try { jsonBody = new JSONObject(new String(body, "UTF-8")); } catch (Exception ignored) {}
            }

            Response resp = dispatch(method, path, jsonBody, authHeader,
                    client.getInetAddress());

            byte[] respBytes = resp.body.getBytes("UTF-8");
            String statusText = resp.status == 401 ? "401 Unauthorized"
                    : resp.status == 404 ? "404 Not Found" : "200 OK";
            String header = "HTTP/1.1 " + statusText + "\r\n"
                    + "Content-Type: application/json;charset=UTF-8\r\n"
                    + "Content-Length: " + respBytes.length + "\r\n\r\n";
            out.write(header.getBytes("UTF-8"));
            out.write(respBytes);
            out.flush();
            client.close();
        } catch (Exception e) {
            logW("处理请求异常: " + e.getMessage());
        }
    }

    /** 读请求头字节块 (到 \r\n\r\n 为止, 上限 16KB 防呆; 头部按 ASCII 解码) */
    private static String readHead(java.io.InputStream in) throws java.io.IOException {
        java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
        int b, matched = 0;
        int[] end = {'\r', '\n', '\r', '\n'};
        while ((b = in.read()) != -1) {
            buf.write(b);
            matched = (b == end[matched]) ? matched + 1 : (b == '\r' ? 1 : 0);
            if (matched == 4) {
                byte[] raw = buf.toByteArray();
                return new String(raw, 0, raw.length - 4, "UTF-8");
            }
            if (buf.size() > 16384) return null;   // 头部超限, 拒读
        }
        return null;
    }

    /** 精确读 n 字节 (不足 n 遇 EOF 返回已读部分) */
    private static byte[] readFully(java.io.InputStream in, int n) throws java.io.IOException {
        if (n <= 0) return null;
        java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream(n);
        byte[] tmp = new byte[Math.min(n, 8192)];
        int off = 0;
        while (off < n) {
            int r = in.read(tmp, 0, Math.min(tmp.length, n - off));
            if (r < 0) break;
            buf.write(tmp, 0, r);
            off += r;
        }
        return buf.toByteArray();
    }

    // ==================== 路由分发（纯逻辑，零网络，单测直接调） ====================

    static class Response {
        final int status;
        final String body;
        Response(int status, String body) { this.status = status; this.body = body; }
    }

    Response dispatch(String method, String path, JSONObject body, String authHeader,
                      InetAddress remote) {
        // 来源校验：只接受回环（bind 127.0.0.1 已挡，显式再验）
        if (remote != null && !remote.isLoopbackAddress()) {
            return new Response(401, errJson("UNAUTHORIZED", "非 127.0.0.1 来源拒绝"));
        }
        // healthz 免鉴权（liveness）
        if ("/healthz".equals(path)) {
            return new Response(200, okJson(healthJson()));
        }
        // 其余一律鉴权，fail-closed
        if (token == null || token.isEmpty()) {
            return new Response(401, errJson("UNAUTHORIZED", "服务端未配置 token"));
        }
        if (authHeader == null || !authHeader.equals(token)) {
            return new Response(401, errJson("UNAUTHORIZED", "token 无效"));
        }
        // 阶段3 B: /infer（MOV BridgeAi 推理）；C: /memory（journal 读/写/检索）
        if ("/infer".equals(path)) {
            return infer(body);
        }
        if ("/v1/chat/completions".equals(path)) {
            return openaiCompatible(body);
        }
        if ("/memory".equals(path)) {
            return memory(body);
        }
        // /tools/{name}/invoke
        if ("POST".equals(method) && path.startsWith("/tools/") && path.endsWith("/invoke")) {
            String name = path.substring("/tools/".length(), path.length() - "/invoke".length());
            if (name.isEmpty()) return new Response(404, errJson("NOT_FOUND", "工具名为空"));
            JSONObject params = body != null ? body.optJSONObject("params") : null;
            if (params == null) params = new JSONObject();
            return invokeTool(name, params);
        }
        return new Response(404, errJson("NOT_FOUND", "未知路由: " + method + " " + path));
    }

    private Response invokeTool(String name, JSONObject args) {
        ToolRegistry.Tool t = registry.find(name);
        if (t == null) {
            return new Response(404, errJson("TOOL_NOT_FOUND", "工具不存在: " + name));
        }
        try {
            /* 阶段3 A 可观测性: MOV 工具执行日志（验收证据链「MOV ToolRegistry 执行行」）。
               尽力而为——JVM 单测无 android.util.Log（stub 抛异常），静默跳过 */
            try { android.util.Log.i(TAG, "MOV 工具执行 name=" + name); } catch (Exception ignoredLog) {}
            ToolRegistry.Result res = t.handler.run(args);
            if (res.ok) {
                JSONObject data = new JSONObject().put("text", res.text != null ? res.text : "");
                if (res.produced != null) data.put("produced", res.produced);
                if (res.aiFeedback != null) data.put("aiFeedback", res.aiFeedback);
                if (res.reason != null) data.put("reason", res.reason);
                return new Response(200, okJson(data));
            }
            return new Response(200, errJson("TOOL_FAILED",
                    res.text != null ? res.text : "工具执行失败"));
        } catch (Exception e) {
            return new Response(200, errJson("TOOL_ERROR",
                    "工具执行异常: " + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName())));
        }
    }

    // ==================== 阶段3 B: /infer（MOV BridgeAi 推理） ====================

    /**
     * POST /infer → {messages:[{role,content}...]} → MOV 默认模型推理（AiClient）→ {ok,data:{content}}。
     * 只调 AiClient（不碰 BridgeAi 本体）；无默认模型/未配置 → NOT_CONFIGURED。
     */
    private Response infer(JSONObject body) {
        try {
            com.hermes.android.model.ModelConfig dm =
                    com.hermes.android.model.ModelRegistry.getInstance(context).getDefault();
            if (dm == null || dm.apiKey == null || dm.apiKey.isEmpty()) {
                return new Response(200, errJson("NOT_CONFIGURED", "未配置默认 AI 模型"));
            }
            com.hermes.android.ai.AiClient client = new com.hermes.android.ai.AiClient(dm);
            /* 阶段3 B 可观测性: MOV 推理日志（验收证据链「MOV 模型请求」）；JVM 单测无 Log，静默 */
            try { android.util.Log.i(TAG, "MOV 推理 model=" + (dm.model != null ? dm.model : dm.name)); }
            catch (Exception ignoredLog) {}
            JSONArray msgs = body != null ? body.optJSONArray("messages") : null;
            java.util.List<com.hermes.android.ai.AiClient.Message> history = new java.util.ArrayList<>();
            StringBuilder prompt = new StringBuilder();
            splitInferMessages(msgs, history, prompt);
            com.hermes.android.ai.AiClient.AiResponse resp = client.chat(prompt.toString(), history);
            if (resp.success) {
                return new Response(200, okJson(new JSONObject().put("content", resp.content)));
            }
            return new Response(200, errJson("INFER_FAILED",
                    resp.content != null ? resp.content : "推理失败"));
        } catch (Exception e) {
            return new Response(200, errJson("INFER_ERROR",
                    "推理异常: " + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName())));
        }
    }

    /**
     * 工单9 幕一 出网网关: OpenAI 兼容端点(POST /v1/chat/completions)——客居/serve agent 的 LLM base_url
     * 指向本端点, MOV 侧转发默认模型出网(proot 内直连外部不通的欠账销账)。
     * **PII 闸点**: 出网前对全部消息 content 过 PiiScrubber.scrub(与 AUDIT_PRIVACY_CAUSAL_LINK 出网关口同律)。
     */
    private Response openaiCompatible(JSONObject body) {
        try {
            JSONArray msgs = body != null ? body.optJSONArray("messages") : null;
            if (msgs == null || msgs.length() == 0) {
                return new Response(200, errJson("BAD_REQUEST", "messages 不能为空"));
            }
            /* PII 闸点: 出网前对全部消息 content 打码(客居任务文本可能含 PII) */
            JSONArray scrubbed = new JSONArray();
            for (int i = 0; i < msgs.length(); i++) {
                JSONObject m = msgs.optJSONObject(i);
                if (m == null) continue;
                scrubbed.put(new JSONObject()
                        .put("role", m.optString("role", "user"))
                        .put("content", com.hermes.android.causal.PiiScrubber.scrub(m.optString("content", ""))));
            }
            java.util.List<com.hermes.android.ai.AiClient.Message> history = new java.util.ArrayList<>();
            StringBuilder prompt = new StringBuilder();
            splitInferMessages(scrubbed, history, prompt);
            com.hermes.android.model.ModelConfig dm =
                    com.hermes.android.model.ModelRegistry.getInstance(context).getDefault();
            if (dm == null || dm.apiKey == null || dm.apiKey.isEmpty()) {
                return new Response(200, errJson("NOT_CONFIGURED", "未配置默认 AI 模型"));
            }
            com.hermes.android.ai.AiClient client = new com.hermes.android.ai.AiClient(dm);
            com.hermes.android.ai.AiClient.AiResponse resp = client.chat(prompt.toString(), history);
            if (!resp.success) {
                return new Response(200, errJson("INFER_FAILED",
                        resp.content != null ? resp.content : "推理失败"));
            }
            JSONObject out = new JSONObject();
            JSONArray choices = new JSONArray();
            choices.put(new JSONObject()
                    .put("index", 0)
                    .put("message", new JSONObject().put("role", "assistant").put("content", resp.content))
                    .put("finish_reason", "stop"));
            out.put("choices", choices);
            return new Response(200, out.toString());
        } catch (Exception e) {
            return new Response(200, errJson("INFER_ERROR",
                    "推理异常: " + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName())));
        }
    }

    /**
     * B1 纯函数: OpenAI messages → (prompt, history) 拆分。
     * 末条 role=user 当 prompt；其余进 history（空 content 跳过，顺序保留；末条非 user 也进 history）。
     * 包可见，单测直接喂 JSON 断言（禁 mock LLM，测的是真拆分逻辑）。
     */
    static void splitInferMessages(JSONArray msgs,
                                   java.util.List<com.hermes.android.ai.AiClient.Message> historyOut,
                                   StringBuilder promptOut) {
        if (msgs == null) return;
        for (int i = 0; i < msgs.length(); i++) {
            JSONObject m = msgs.optJSONObject(i);
            if (m == null) continue;
            String role = m.optString("role", "user");
            String content = m.optString("content", "");
            if (i == msgs.length() - 1 && "user".equals(role)) {
                promptOut.append(content);
            } else if (!content.isEmpty()) {
                historyOut.add(new com.hermes.android.ai.AiClient.Message(role, content));
            }
        }
    }

    // ==================== 阶段3 C: /memory（journal 唯一事件源，读/写/检索） ====================

    /**
     * POST /memory {action, roomId, ...} → MOV journal。
     *  read:   {action:"read", roomId} → journal.replay（回放投影）
     *  write:  {action:"write", roomId, event:{type,actor,payload}} → journal.append（真 append）
     *  search: {action:"search", roomId, query, limit} → journal.search（C2 按内容检索）
     * 只用 journal 公共 API（append/replay/search），不破 append-only 语义。
     */
    private Response memory(JSONObject body) {
        try {
            if (context == null) return new Response(200, errJson("NO_CONTEXT", "无 app 上下文"));
            com.hermes.android.agent.Journal journal = new com.hermes.android.agent.Journal(
                    new com.hermes.android.StorageManager(context).getRoomsDir());
            String action = body != null ? body.optString("action", "") : "";
            String roomId = body != null ? body.optString("roomId", "") : "";
            switch (action) {
                case "read": {
                    JSONObject rep = journal.replay(roomId);
                    return new Response(200, rep.toString());
                }
                case "write": {
                    JSONObject event = body.optJSONObject("event");
                    if (event == null) return new Response(200, errJson("BAD_REQUEST", "event 为空"));
                    int seq = journal.append(roomId, event);
                    if (seq < 0) return new Response(200, errJson("WRITE_FAILED", "journal 写入失败"));
                    return new Response(200, okJson(new JSONObject().put("seq", seq)));
                }
                case "search": {
                    String query = body.optString("query", "");
                    int limit = body.optInt("limit", 10);
                    JSONObject res = journal.search(roomId, query, limit);
                    return new Response(200, res.toString());
                }
                // 批2: memory curated 层（一表双脑真共用）——Hermes memory 工具读写走 MOV journal
                case "curated": {
                    // 有效条目投影（§分隔，对齐 Hermes MEMORY.md 语义）
                    return new Response(200, okJson(new JSONObject()
                            .put("curated", journal.memoryCurated(journal.memoryDrafts(roomId)))
                            .put("count", journal.memoryDrafts(roomId).length())));
                }
                case "replace": {
                    String oldText = body.optString("old", "");
                    String newText = body.optString("new", "");
                    if (newText.isEmpty()) return new Response(200, errJson("BAD_REQUEST", "new 为空"));
                    int seq = journal.memoryReplace(roomId, oldText, newText,
                            body.optString("kind", "memory"));
                    if (seq < 0) return new Response(200, errJson("WRITE_FAILED", "replace 失败"));
                    return new Response(200, okJson(new JSONObject().put("seq", seq)));
                }
                case "remove": {
                    String text = body.optString("text", "");
                    if (text.isEmpty()) return new Response(200, errJson("BAD_REQUEST", "text 为空"));
                    int seq = journal.memoryRemove(roomId, text);
                    if (seq < 0) return new Response(200, errJson("WRITE_FAILED", "remove 失败"));
                    return new Response(200, okJson(new JSONObject().put("seq", seq)));
                }
                case "distill": {
                    // 工单7 G15: L3 摘要懒生成调度入口——对 memoryCover 的 needsCompress=true 摘要
                    // 用 MOV 默认模型提炼成真摘要并冻结注入 _memory_summary（懒触发：慢脑任务后/空闲可调本端点）。
                    if (roomId.isEmpty()) return new Response(200, errJson("BAD_REQUEST", "roomId 不能为空"));
                    int budget = body.optInt("budget", com.hermes.android.agent.Journal.COVER_BUDGET_DEFAULT);
                    JSONObject res = runDistill(journal, roomId, budget, buildDistillBrain(context));
                    return new Response(200, res.toString());
                }
                case "fitness_ingest": {
                    // 工单12 幕一: 健身文本入账(fitness 域 _tool_receipt, tool=ocr.local)
                    if (roomId.isEmpty()) return new Response(200, errJson("BAD_REQUEST", "roomId 不能为空"));
                    String text = body.optString("text", "");
                    if (text.isEmpty()) return new Response(200, errJson("BAD_REQUEST", "text 不能为空"));
                    int seq = journal.fitnessIngest(roomId, text);
                    if (seq < 0) return new Response(200, errJson("WRITE_FAILED", "入账失败 seq=" + seq));
                    return new Response(200, okJson(new JSONObject().put("seq", seq).put("domain", "fitness")));
                }
                case "weekly_narrative": {
                    // 工单12 幕二: 周叙事 — fitness 域近 7 天 receipts → 模型提炼(趋势/异常/建议)
                    if (roomId.isEmpty()) return new Response(200, errJson("BAD_REQUEST", "roomId 不能为空"));
                    try {
                        org.json.JSONArray receipts = journal.domainReceipts(roomId, "fitness");
                        org.json.JSONArray week = new org.json.JSONArray();
                        long cutoff = System.currentTimeMillis() - 7L * 24 * 3600 * 1000;
                        for (int i = 0; i < receipts.length(); i++) {
                            org.json.JSONObject o = receipts.optJSONObject(i);
                            if (o != null && o.optLong("ts", 0) >= cutoff) week.put(o);
                        }
                        String prompt = com.hermes.android.agent.Journal.weeklyNarrativePrompt("fitness", week);
                        com.hermes.android.agent.Journal.Brain brain = buildDistillBrain(context);
                        if (brain == null) return new Response(200, errJson("NOT_CONFIGURED", "未配置默认 AI 模型"));
                        String narrative = "";
                        try {
                            String r = brain.chat("", prompt);
                            narrative = r != null ? r : "";
                        } catch (Exception e) {
                            return new Response(200, errJson("NARRATIVE_FAILED",
                                    "提炼失败: " + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName())));
                        }
                        return new Response(200, okJson(new org.json.JSONObject()
                                .put("domain", "fitness").put("narrative", narrative)
                                .put("count", week.length())));
                    } catch (Exception e) {
                        return new Response(200, errJson("NARRATIVE_FAILED",
                                "周叙事异常: " + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName())));
                    }
                }
                default:
                    return new Response(200, errJson("BAD_REQUEST", "未知 action: " + action));
            }
        } catch (Exception e) {
            return new Response(200, errJson("MEMORY_ERROR",
                    "记忆异常: " + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName())));
        }
    }

    /** G15: 从 MOV 默认模型构造摘要提炼 Brain（AiClient→Journal.Brain）；无默认模型/构造失败返回 null。
     *  依赖 ModelRegistry/AiClient，真机路径；JVM 单测走 runDistill 注入 fake Brain。 */
    private static com.hermes.android.agent.Journal.Brain buildDistillBrain(Context context) {
        try {
            com.hermes.android.model.ModelConfig dm =
                    com.hermes.android.model.ModelRegistry.getInstance(context).getDefault();
            if (dm == null || dm.apiKey == null || dm.apiKey.isEmpty()) return null;
            com.hermes.android.ai.AiClient client = new com.hermes.android.ai.AiClient(dm);
            return (sys, user) -> {
                java.util.List<com.hermes.android.ai.AiClient.Message> hist = new java.util.ArrayList<>();
                hist.add(new com.hermes.android.ai.AiClient.Message("system", sys));
                com.hermes.android.ai.AiClient.AiResponse r = client.chat(user, hist);
                return r.success && r.content != null ? r.content : null;
            };
        } catch (Exception e) {
            android.util.Log.w(TAG, "distillBrain 构造失败: " + e.getMessage());
            return null;
        }
    }

    /** G15 包级可见纯逻辑: 执行摘要提炼（透传 journal.distillMemory）。brain 由调用方注入，禁 mock LLM——
     *  JVM 单测喂 fake Brain + 临时目录 Journal，测真透传（冻结注入 _memory_summary）。 */
    static JSONObject runDistill(com.hermes.android.agent.Journal journal,
                                 String roomId, int budget,
                                 com.hermes.android.agent.Journal.Brain brain) {
        if (brain == null) {
            try {
                return new JSONObject().put("ok", false)
                        .put("error", new JSONObject().put("code", "NOT_CONFIGURED").put("msg", "未配置默认 AI 模型"));
            } catch (Exception e) {
                return new JSONObject();
            }
        }
        return journal.distillMemory(roomId, brain, budget);
    }

    // ==================== 信封 ====================

    private static JSONObject healthJson() {
        try { return new JSONObject().put("ok", true).put("version", "0.1.0"); }
        catch (Exception e) { return new JSONObject(); }
    }

    private static String okJson(JSONObject data) {
        try { return new JSONObject().put("ok", true).put("data", data).toString(); }
        catch (Exception e) { return "{\"ok\":true,\"data\":{}}"; }
    }

    private static String errJson(String code, String msg) {
        try {
            return new JSONObject().put("ok", false)
                    .put("error", new JSONObject().put("code", code).put("msg", msg)).toString();
        } catch (Exception e) { return "{\"ok\":false}"; }
    }
}
