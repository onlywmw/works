package com.hermes.android.browser;

import com.hermes.android.agent.ToolRegistry;

/**
 * ToolRuntimeLimits — browser_* 运行时限制（DESIGN_BROWSER_PROTOCOL §3 双超时，W2 P2 侧）。
 *
 * 双超时（runaway loop 成本封顶）：
 *  1. per-tool 硬超时 30s（可调）：browser_* 单次动作执行上限。
 *  2. 单任务窗口 5min：browser.open 开窗、browser.done 关窗；窗尽后所有 browser_*
 *     工具回 task_timeout envelope（带 recovery 引导），不许无限循环烧 token。
 *
 * 纯 JVM 可测：expiredAt（过期判定）/ checkWindow（窗尽回 timeout Result）/ 常量。
 * 窗口状态 volatile（agent 线程写、工具 handler 读）。
 */
public class ToolRuntimeLimits {

    public static final long WINDOW_TIMEOUT_MS = 5 * 60 * 1000L;  // 单任务窗口 5min
    public static final int PER_TOOL_HARD_TIMEOUT_S = 30;         // per-tool 硬超时 30s（可调）
    public static final String ERROR_TASK_TIMEOUT = "browser_task_timeout";

    /** 0 = 无窗口；否则 = 窗口截止时间戳（now + WINDOW_TIMEOUT_MS）。
     *  包可见（测试同包驱动窗口过期/未过期路径） */
    static volatile long windowDeadlineMs = 0;

    /** browser.open 开窗（记录窗口截止） */
    public static void openWindow() {
        windowDeadlineMs = System.currentTimeMillis() + WINDOW_TIMEOUT_MS;
    }

    /** browser.done 关窗（结束本次浏览会话） */
    public static void closeWindow() {
        windowDeadlineMs = 0;
    }

    public static boolean windowOpen() {
        return windowDeadlineMs != 0;
    }

    /** 纯函数：给定 now + deadline，判定窗口是否过期（deadline=0 无窗口 → 永不过期） */
    public static boolean expiredAt(long now, long deadlineMs) {
        return deadlineMs != 0 && now > deadlineMs;
    }

    /** 当前窗口是否过期（真实时钟） */
    public static boolean windowExpired() {
        return expiredAt(System.currentTimeMillis(), windowDeadlineMs);
    }

    /** P1: browser_* 可用性——窗口超时才是硬不可用（未开浏览器由运行期自动拉起/引导兜底）。
     *  纯 JVM 可测：不触碰 ConnectWebActivity。返回 null=可用。 */
    public static String availabilityReason() {
        return windowExpired()
                ? "浏览器任务窗口已超时(5min)，请用 browser.open 重新开窗"
                : null;
    }

    /**
     * browser_* 工具执行前检查：窗尽 → 返回 task_timeout Result（带 recovery）；
     * 否则返回 null = 放行。
     */
    public static ToolRegistry.Result checkWindow() {
        if (!windowExpired()) return null;
        return new ToolRegistry.Result(false,
                "浏览器任务窗口已超时(5min): 请调用 browser.done 收尾总结，或 browser.open 开新窗重新开始",
                null, null, ToolRegistry.Result.REASON_SOURCE_DOWN);
    }
}
