package com.hermes.android.skill;

import com.hermes.android.agent.ToolRegistry;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 批2: 技能激活——把已释放技能的工具注册进 ToolRegistry。
 * 技能 JSON 声明 tools[]，handler 由内置实现提供（handlerFor），
 * 无实现的工具不注册（反假菜单：技能必须是真能执行的）。
 */
public class SkillActivator {

    /** 内置技能工具 handler：按工具名返回实现；未实现返回 null（不注册假工具） */
    public static ToolRegistry.Handler handlerFor(String toolName) {
        if ("skill.echo".equals(toolName)) {
            return args -> new ToolRegistry.Result(true, "echo:" + args.optString("text", ""));
        }
        // 批3: mov-webbridge 真实浏览器工具（CDP；未连接返回"未配置浏览器"归因，非假绿）
        if (toolName != null && toolName.startsWith("wb.")) {
            return args -> {
                JSONObject cmd = com.hermes.android.browser.MovWebBridge.cdpCommand(toolName, args);
                if (cmd == null) return new ToolRegistry.Result(false, "未知浏览器工具: " + toolName);
                try {
                    JSONObject res = com.hermes.android.browser.CdpClient.instance()
                            .send(cmd.getString("method"), cmd.optJSONObject("params"));
                    return new ToolRegistry.Result(true, res != null ? res.toString() : "{}");
                } catch (Exception e) {
                    return new ToolRegistry.Result(false, "浏览器操作失败: " + e.getMessage());
                }
            };
        }
        return null;
    }

    /** 激活一个技能：解析 skillJson → 逐个工具注册（有实现的才注册）；返回成功注册数 */
    public static int activate(ToolRegistry registry, String skillJson) {
        JSONObject skill = SkillStore.parseSkill(skillJson);
        if (skill == null) return 0;
        JSONArray tools = skill.optJSONArray("tools");
        if (tools == null) return 0;
        int n = 0;
        for (int i = 0; i < tools.length(); i++) {
            JSONObject t = tools.optJSONObject(i);
            if (t == null) continue;
            String name = t.optString("name", "");
            String desc = t.optString("description", name);
            ToolRegistry.Handler h = handlerFor(name);
            if (h != null) {
                registry.registerDynamicTool(name, desc, h, accessFor(name));
                n++;
            }
        }
        return n;
    }

    /** 技能工具 access 分级：wb.evaluate=远程任意 JS（dangerous）；其余 wb.*=操控浏览器（write）；其他=readonly */
    static String accessFor(String toolName) {
        if ("wb.evaluate".equals(toolName)) return "dangerous";
        if (toolName != null && toolName.startsWith("wb.")) return "write";
        return "readonly";
    }
}
