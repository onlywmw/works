package com.hermes.android.mcp.server;

import com.hermes.android.agent.ToolRegistry;

import io.modelcontextprotocol.spec.McpSchema;
import io.modelcontextprotocol.server.McpSyncServerExchange;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;

/**
 * ToolRegistry.Tool ↔ MCP 标准 schema 适配器（P1）。
 *
 * 映射规则：
 *  - {@link #toSchema}：ParamDef → inputSchema（type=object + properties + required）
 *  - {@link #handlerFor}：Tool.handler(JSONObject args) → CallToolResult(content/isError)
 *  - {@link #isReadonly}：只读工具集过滤（P1 只暴露 access==readonly，危险工具不暴露）
 *
 * 纯 Java（不 import android.*），映射逻辑 JVM 单测全覆盖。
 */
public final class McpToolAdapter {

    private McpToolAdapter() {}

    /** P1 暴露门槛：只读工具（file.read/list、tool.describe、model.list 等），写/审批类一律不暴露。 */
    public static boolean isReadonly(ToolRegistry.Tool t) {
        return "readonly".equals(t.access);
    }

    /** Tool → McpSchema.Tool（name/description + inputSchema）。 */
    public static McpSchema.Tool toSchema(ToolRegistry.Tool t) {
        Map<String, Object> properties = new LinkedHashMap<>();
        List<String> required = new ArrayList<>();
        if (t.params != null) {
            for (ToolRegistry.ParamDef p : t.params) {
                Map<String, Object> prop = new LinkedHashMap<>();
                prop.put("type", jsonTypeOf(p.type));
                if (p.description != null && !p.description.isEmpty()) {
                    prop.put("description", p.description);
                }
                properties.put(p.name, prop);
                if (p.required) required.add(p.name);
            }
        }
        McpSchema.JsonSchema schema = new McpSchema.JsonSchema("object", properties, required, false, null, null);
        String desc = t.desc != null ? t.desc : t.name;
        // McpSchema.Tool = (name, title, description, inputSchema, outputSchema, annotations, meta)
        return new McpSchema.Tool(t.name, t.name, desc, schema, null, null, null);
    }

    /** 执行 handler，产出标准 CallToolResult。异常 → isError=true（不吞，报给客户端）。 */
    public static BiFunction<McpSyncServerExchange, McpSchema.CallToolRequest, McpSchema.CallToolResult>
    handlerFor(ToolRegistry.Tool t) {
        return (ex, req) -> {
            try {
                Map<String, Object> args = req.arguments() != null ? req.arguments() : Map.of();
                ToolRegistry.Result res = t.handler.run(new JSONObject(args));
                String text = res.text != null ? res.text : "";
                if (t.maxResultChars > 0 && text.length() > t.maxResultChars) {
                    text = text.substring(0, t.maxResultChars) + "\n…(已截断, 原" + res.text.length() + "字符)";
                }
                return new McpSchema.CallToolResult(
                        List.of(new McpSchema.TextContent(text)), !res.ok, null, null);
            } catch (Exception e) {
                return new McpSchema.CallToolResult(
                        List.of(new McpSchema.TextContent("错误: " + e.getMessage())), true, null, null);
            }
        };
    }

    /**
     * write 工具审批包装（工单 P5 审批闸）：执行前过 {@link McpApprovalGate}——
     * 未批准 → 明确 error code（APPROVAL_PENDING，已发起房间内审批请求）；驳回 → APPROVAL_DENIED；
     * 批准后走原 handler（复用既有 protected path/白名单/validator 闸）。
     */
    public static BiFunction<McpSyncServerExchange, McpSchema.CallToolRequest, McpSchema.CallToolResult>
    gatedHandlerFor(ToolRegistry.Tool t, McpApprovalGate gate) {
        return (ex, req) -> {
            try {
                Map<String, Object> args = req.arguments() != null ? req.arguments() : Map.of();
                String path = pathOf(t, args);
                /* 去重路径归一化：与 McpApprovalGate.normalize 一致（缺省 "" → "*"）。
                   raw path 直接 equals 会和已归一化的 pr.path("*") 不匹配 → 缺省 path 时重复登记 pending（工单任务2） */
                String normPath = (path == null || path.isEmpty()) ? "*" : path;
                McpApprovalGate.Decision d = gate.check(t.name, path);
                if (d == McpApprovalGate.Decision.PENDING) {
                    /* 去重：已有在途请求不重复写 journal 事件（hasPending 语义，修复 G2），复用已有 requestId */
                    String requestId;
                    if (!gate.hasPending(t.name, normPath)) {
                        requestId = gate.requestApproval(t.name, normPath, new JSONObject(args));
                    } else {
                        requestId = null;
                        for (McpApprovalGate.PendingRequest pr : gate.pendingRequests()) {
                            if (pr.tool.equals(t.name) && pr.path.equals(normPath)) { requestId = pr.requestId; break; }
                        }
                        if (requestId == null) {
                            requestId = gate.requestApproval(t.name, normPath, new JSONObject(args));
                        }
                    }
                    return approvalResult("[" + McpApprovalGate.CODE_PENDING + "] 需要审批：已向房间发起确认请求 "
                            + requestId + "；在房间内批准后重试该调用");
                }
                if (d == McpApprovalGate.Decision.DENIED) {
                    return approvalResult("[" + McpApprovalGate.CODE_DENIED + "] 审批已被驳回，本调用拒绝执行");
                }
                ToolRegistry.Result res = t.handler.run(new JSONObject(args));
                String text = res.text != null ? res.text : "";
                if (t.maxResultChars > 0 && text.length() > t.maxResultChars) {
                    text = text.substring(0, t.maxResultChars) + "\n…(已截断, 原" + res.text.length() + "字符)";
                }
                return new McpSchema.CallToolResult(
                        List.of(new McpSchema.TextContent(text)), !res.ok, null, null);
            } catch (Exception e) {
                return new McpSchema.CallToolResult(
                        List.of(new McpSchema.TextContent("错误: " + e.getMessage())), true, null, null);
            }
        };
    }

    /** 工具 args 里取路径（file.write 等有 path 参数；无 → "*" 工具级批准）。 */
    private static String pathOf(ToolRegistry.Tool t, Map<String, Object> args) {
        if (t.params != null) {
            for (ToolRegistry.ParamDef p : t.params) {
                if ("path".equals(p.name)) {
                    Object v = args.get("path");
                    return v != null ? String.valueOf(v) : "";
                }
            }
        }
        return "*";
    }

    /** 审批类结果：isError=true + 文本含明确 error code。 */
    private static McpSchema.CallToolResult approvalResult(String text) {
        return new McpSchema.CallToolResult(List.of(new McpSchema.TextContent(text)), true, null, null);
    }

    /** MOV ParamDef.type → JSON Schema type。 */
    private static String jsonTypeOf(String movType) {
        if (movType == null) return "string";
        switch (movType) {
            case "int": return "integer";
            case "boolean": return "boolean";
            default: return "string";
        }
    }
}
