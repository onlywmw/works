/* MOV SDK v2.0 — Generated apps call MOV tools via MCP (localhost:10000).
   Works in standalone APKs, not just inside MOV WebView. */
window.MOV = (function() {
  var MCP_URL = 'http://127.0.0.1:10000/mcp';
  var _seq = 0;

  function _mcpCall(toolName, args) {
    var id = ++_seq;
    var body = JSON.stringify({
      method: 'tools/call',
      params: { name: toolName, args: args || {} },
      id: id
    });
    try {
      var xhr = new XMLHttpRequest();
      xhr.open('POST', MCP_URL, false); // sync for simplicity
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.send(body);
      if (xhr.status === 200) {
        var r = JSON.parse(xhr.responseText);
        if (r.result && r.result.content) return { ok: true, data: r.result.content };
        return { ok: true, data: r.result };
      }
      return { ok: false, error: 'MCP HTTP ' + xhr.status };
    } catch(e) {
      return { ok: false, error: 'MCP unavailable: ' + e.message };
    }
  }

  return {
    /* ── 设备 ── */
    device: {
      cmd: function(text) { return _mcpCall('execCommand', { arg0: text }); },
      info: function() { return _mcpCall('getDeviceInfo', {}); }
    },

    /* ── 文件（通过 shell.exec 操作） ── */
    file: {
      write: function(path, content) {
        return _mcpCall('writeFile', { arg0: 'work', arg1: path, arg2: content });
      },
      read: function(path) {
        return _mcpCall('readFile', { arg0: 'work', arg1: path });
      }
    },

    /* ── Shell ── */
    shell: {
      exec: function(cmd) { return _mcpCall('shellExec', { arg0: cmd, arg1: '30' }); }
    },

    /* ── AI ── */
    ai: {
      chat: function(text) { return _mcpCall('aiChat', { arg0: text }); }
    },

    /* ── 系统 ── */
    system: {
      notify: function(title, text) { return _mcpCall('notification', { arg0: title, arg1: text }); },
      toast: function(msg) { return _mcpCall('toast', { arg0: msg }); }
    },

    /* ── 存储（localStorage） ── */
    storage: {
      get: function(key) { try { return JSON.parse(localStorage.getItem('mov_'+key)); } catch { return null; } },
      set: function(key, val) { try { localStorage.setItem('mov_'+key, JSON.stringify(val)); return true; } catch { return false; } },
      del: function(key) { localStorage.removeItem('mov_'+key); }
    }
  };
})();
