package com.hermes.android.browser;

/**
 * WebView evaluateJavascript 返回值的 JSON 字符串解码器（纯 JVM，可单测）。
 * 从 HtmlViewerActivity 抽出：原类的静态字段 Color.parseColor 触 Android API，
 * 纯 JVM 单测加载即 ExceptionInInitializerError，无法直接测。
 */
public final class JsStringCodec {

    private JsStringCodec() {}

    /** 反解 evaluateJavascript 返回的 JSON 字符串（首尾引号 + 转义）；输入非法返回 null */
    public static String unescapeJsString(String value) {
        if (value == null || value.length() < 2) return null;
        String v = value.trim();
        if (v.startsWith("\"") && v.endsWith("\"")) v = v.substring(1, v.length() - 1);
        StringBuilder sb = new StringBuilder(v.length());
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            if (c == '\\' && i + 1 < v.length()) {
                char n = v.charAt(++i);
                switch (n) {
                    case 'n': sb.append('\n'); break;
                    case 't': sb.append('\t'); break;
                    case 'r': sb.append('\r'); break;
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case 'u':
                        if (i + 4 < v.length()) {
                            try {
                                sb.append((char) Integer.parseInt(v.substring(i + 1, i + 5), 16));
                                i += 4;
                            } catch (Exception e) { sb.append('u'); }
                        } else sb.append('u');
                        break;
                    default: sb.append(n);
                }
            } else sb.append(c);
        }
        return sb.toString();
    }
}
