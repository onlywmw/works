package com.hermes.android;
import com.hermes.android.toolprovider.ModelToolProvider;

import com.hermes.android.browser.BrowserToolProvider;

import com.hermes.android.toolprovider.OcrToolProvider;

import com.hermes.android.toolprovider.MemoryToolProvider;

import com.hermes.android.toolprovider.ChatMemoryProvider;

import com.hermes.android.toolprovider.FileOpsProvider;

import com.hermes.android.toolprovider.HermesGapProvider;

import com.hermes.android.toolprovider.UtilityToolProvider;

import com.hermes.android.toolprovider.ExtraToolProvider;

import com.hermes.android.toolprovider.HermesToolProvider;

import com.hermes.android.toolprovider.SystemToolProvider;

import com.hermes.android.scene.FastSceneProvider;

import com.hermes.android.workflow.Workflows;

import android.app.Application;

import com.hermes.android.agent.PromptLoader;
import com.hermes.android.agent.Journal;
import com.hermes.android.llama.SemanticReranker;
import com.hermes.android.ai.AiProviderConfig;
import com.hermes.android.model.ModelRegistry;
import com.hermes.android.model.ModelConfig;
import org.json.JSONArray;
import org.json.JSONObject;

public class HermesApplication extends Application {

    private static HermesApplication instance;
    public static HermesApplication getInstance() { return instance; }
    public static android.content.Context getAppContext() { return instance; }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        /* W4: WebView 预热 — 预创建触发 Chromium 进程启动 (冷启动最大瓶颈, 首屏提速; 保留复用) */
        try {
            android.webkit.WebView prewarm = new android.webkit.WebView(this);
            prewarm.loadDataWithBaseURL(null, "", "text/html", "UTF-8", null);
        } catch (Exception ignored) {}
        /* 工单28 语义召回：端侧 embedding 增强 Journal.search——装配重排器。
           失败静默（reranker 保持 null → search 纯子串保底，零回归）。 */
        try {
            Journal.setSearchReranker(new SemanticReranker(this));
        } catch (Exception ignored) {}
        // 仅 debuggable 包开启 WebView 远程调试 (chrome://inspect / CDP), release 关闭
        if ((getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            android.webkit.WebView.setWebContentsDebuggingEnabled(true);
            // debug 宿主: ContextProvider 情境传感器层 v1 — 插拔充电器/WiFi 即落盘到 filesDir/context/
            // 零订阅=零 receiver（电池卫生铁律），debug 宿主须订阅四族以激活落盘
            com.hermes.android.context.ContextProvider cp = new com.hermes.android.context.ContextProvider(
                this,
                new com.hermes.android.context.SensorSourceImpl(this),
                new com.hermes.android.context.ContextPersister(
                    new java.io.File(getFilesDir(), "context"))
            );
            cp.start();
            // 激活四族 receiver（no-op 回调，落盘由 ContextProvider 内部 fire() 路径完成）
            com.hermes.android.context.TransitionListener noop = e -> {};
            cp.subscribe(noop, com.hermes.android.context.ContextEventType.WIFI_CONNECTED,
                    com.hermes.android.context.ContextEventType.WIFI_DISCONNECTED);
            cp.subscribe(noop, com.hermes.android.context.ContextEventType.POWER_CONNECTED,
                    com.hermes.android.context.ContextEventType.POWER_DISCONNECTED);
            cp.subscribe(noop, com.hermes.android.context.ContextEventType.SCREEN_ON,
                    com.hermes.android.context.ContextEventType.SCREEN_OFF);
            cp.addBatteryListener(noop, 80, true);   // 升穿 80%（充电到 80%）
            cp.addBatteryListener(noop, 20, false);  // 降穿 20%（低电量告警）
        }
        TokenMeter.init(this);
        MigrationManager.run(this);
        RulesManager.init(this);
        ErrorReporter.init(this);
        PromptLoader.init(this);
        com.hermes.android.mcp.McpProvider.init(this);
        ModelToolProvider.init(this);
        SystemToolProvider.init(this);
        HermesToolProvider.init(this);
        ExtraToolProvider.init(this);
        UtilityToolProvider.init(this);
        HermesGapProvider.init(this);
        FileOpsProvider.init(this);
        ChatMemoryProvider.init(this);
        FastSceneProvider.init(this);
        MemoryToolProvider.init(this);
        com.hermes.android.toolprovider.CausalToolProvider.init(this);   // 因果记忆编译器（四元组+哈希+逻辑钩子）
        OcrToolProvider.init(this);   // OCR 集成面（模型/llama-server 归 P4）
        com.hermes.android.toolprovider.PbToolProvider.init(this);   // MCP 工厂首品种：PocketBase 本地后端 pb.*
        com.hermes.android.toolprovider.PartnerToolProvider.init(this);   // 微信支付服务商进件 wxpay.applyment.*
        Workflows.init(this);   // 触发器引擎（workflow 纯 JVM + ConnectWeb 集成壳）
        /* 阶段3 A0: MOV 入站监听（127.0.0.1:8388，daemon→MOV 回调地基）。
           幂等启动；端口占用/进程竞争静默降级（仅主进程持监听）。 */
        com.hermes.android.serve.MovInboundServer.ensureRunning(this);
        /* 阶段3 A3: MOV 工具清单推送 daemon（/exchange/mov-tools.json，serve GET /tools 读） */
        com.hermes.android.serve.ToolManifest.writeToExchange(this);
        /* MOV 能力 MCP 化 P1: 进程级 MCP server（127.0.0.1:8389/mcp，官方 SDK，只读工具集）。
           幂等启动；mapper 缺失/端口占用静默降级（不阻塞 onCreate）。 */
        com.hermes.android.mcp.server.MovMcpServer.ensureRunning(this);
        /* HtmlViewer 多文件 HTML 项目支持: 房间静态文件服务器（127.0.0.1:8787，file:// 无法执行
           file:// JS 子资源，多文件项目走 http 加载）。幂等启动；端口占用静默降级。 */
        com.hermes.android.serve.RoomStaticServer.ensureRunning(this);
        /* APK 预置 rootfs: 首启/每次启动后台自动就绪（isReady 幂等，无 UI 无感）——
           rootfs 未就绪 → assets 种子自动解压；READY 后联动装 Hermes（装进 rootfs，需网络，失败下次补）。 */
        ensureLinuxBootstrap();
        ensureDefaultsAndCleanup();
    }

    /** 后台静默引导 Linux + Hermes（用户无感；rootfs 已就绪则跳过，坏了自己修）。 */
    private void ensureLinuxBootstrap() {
        final android.content.Context ctx = this;
        new Thread(() -> {
            try {
                final com.hermes.android.linux.RootfsManager rm = new com.hermes.android.linux.RootfsManager(ctx);
                rm.setListener((s, p, m) -> {
                    // rootfs READY 后 ensure Hermes：种子含 venv 走快路径（~3s），无 venv 回落完整装
                    if (s == com.hermes.android.linux.RootfsManager.State.READY) {
                        new com.hermes.android.linux.HermesInstaller(ctx).ensureReady();
                    }
                });
                if (!rm.isReady()) {
                    rm.install();
                } else {
                    // rootfs 已就绪 → 直接 ensure Hermes（venv 在 → 快路径；缺 → 完整装）
                    new com.hermes.android.linux.HermesInstaller(ctx).ensureReady();
                }
            } catch (Exception e) {
                android.util.Log.w("MOV", "Linux/Hermes 自动就绪失败: " + e.getMessage());
            }
        }, "linux-bootstrap").start();
    }

    /**
     * 清理历史遗留的已弃用模型名。
     * getProvider() 默认返回 "deepseek"，无需显式写入。
     * 不再预置 API Key——用户需在 AI 设置中自行填写。
     */
    private void ensureDefaultsAndCleanup() {
        AiProviderConfig config = new AiProviderConfig(this);
        // 清理历史遗留的已弃用模型名（deepseek-chat / deepseek-reasoner 已于 7/24 弃用）
        String m = config.getModel();
        if ("deepseek-chat".equals(m) || "deepseek-reasoner".equals(m)) {
            config.setModel("");
        }

        // MCP: 模型配置持久化（重装不丢模型）
        autoImportModels();
        // 启动时同步模型到内嵌 Hermes
        syncToHermes();
    }

    /** 启动时自动从内部存储导入模型配置（MCP 口），重装不丢（-r 升级保留内部数据）。
        技术债修复（工单5）：原落外部存储 getExternalFilesDir 明文含 apiKey，改内部 filesDir；
        顺手清掉历史遗留的外部明文文件。 */
    private void autoImportModels() {
        try {
            java.io.File legacy = new java.io.File(getExternalFilesDir(null), "mcp_models.json");
            if (legacy.exists()) legacy.delete();   // 旧外部明文文件清理
            java.io.File mcpFile = new java.io.File(getFilesDir(), "mcp_models.json");
            if (!mcpFile.exists()) return;
            String json = new String(java.nio.file.Files.readAllBytes(mcpFile.toPath()), "UTF-8");
            JSONArray arr = new JSONArray(json);
            ModelRegistry registry = ModelRegistry.getInstance(this);
            int imported = 0;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                boolean exists = false;
                for (ModelConfig c : registry.list()) {
                    if (o.optString("provider","").equals(c.provider)
                        && o.optString("model","").equals(c.model)) { exists = true; break; }
                }
                if (!exists) {
                    ModelConfig mc = new ModelConfig();
                    mc.provider = o.optString("provider", "");
                    mc.name = o.optString("name", mc.provider);
                    mc.model = o.optString("model", "");
                    mc.apiKey = o.optString("apiKey", "");
                    mc.baseUrl = o.optString("baseUrl", "");
                    mc.enabled = true;
                    mc.isDefault = o.optBoolean("isDefault", false);
                    mc.role = o.optString("role", "通用");
                    registry.add(mc);
                    imported++;
                }
            }
            if (imported > 0) {
                android.util.Log.i("MOV", "MCP: 从外部存储导入 " + imported + " 个模型");
            }
        } catch (Exception e) {
            android.util.Log.w("MOV", "MCP 导入失败: " + e.getMessage());
        }
    }

    /** 启动时将默认模型同步到内嵌 Hermes (~/.hermes/.env + config.yaml) */
    private void syncToHermes() {
        new Thread(() -> {
            try {
                if (com.hermes.android.linux.HermesInstaller.isReady(this)) {
                    com.hermes.android.linux.HermesInstaller.writeModelConfig(this);
                }
            } catch (Exception ignored) { /* 非致命 */ }
        }, "hermes-sync").start();
    }

    /** MCP 口: JS 调此方法导出当前模型配置到外部存储 */
    @android.webkit.JavascriptInterface
    public String exportModels() {
        try {
            ModelRegistry registry = ModelRegistry.getInstance(this);
            JSONArray arr = new JSONArray();
            for (ModelConfig c : registry.list()) {
                JSONObject o = new JSONObject();
                o.put("provider", c.provider);
                o.put("name", c.name);
                o.put("model", c.model);
                o.put("apiKey", c.apiKey);
                o.put("baseUrl", c.baseUrl != null ? c.baseUrl : "");
                o.put("isDefault", c.isDefault);
                o.put("role", c.role != null ? c.role : "通用");
                arr.put(o);
            }
            /* 技术债修复（工单5）：写内部 filesDir（getFilesDir），不再落外部存储明文含 key。 */
            java.io.File mcpFile = new java.io.File(getFilesDir(), "mcp_models.json");
            java.nio.file.Files.write(mcpFile.toPath(), arr.toString(2).getBytes("UTF-8"));
            return "{\"ok\":true,\"count\":" + arr.length() + ",\"path\":\"" + mcpFile.getAbsolutePath() + "\"}";
        } catch (Exception e) {
            return "{\"ok\":false,\"error\":\"" + e.getMessage() + "\"}";
        }
    }
}
