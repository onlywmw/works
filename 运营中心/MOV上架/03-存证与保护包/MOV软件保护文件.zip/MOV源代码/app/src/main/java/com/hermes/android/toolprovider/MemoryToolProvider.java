package com.hermes.android.toolprovider;
import com.hermes.android.StorageManager;
import com.hermes.android.HermesApplication;

import com.hermes.android.scene.DramaMemory;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import com.hermes.android.agent.ToolRegistry;

/**
 * FUSION F3: 记忆读写收编 — watch_history/drama_memory/face_history/face_mine
 * 归入一个 MemoryToolProvider，注册进 ToolRegistry（level=FAST，快脑慢脑共用）。
 *
 * 路径约定（照原 BridgeKernel case）：
 * - drama_memory.json / watch_history.json → getFilesDir()（内部私有目录）
 * - rooms/ 产物 → new StorageManager(appContext)（externalFilesDir/mov）
 *
 * 全部本地文件，零网络，sync=false。
 */
public class MemoryToolProvider implements ToolRegistry.ToolProvider {

    private static Context appContext;

    /** 静态注入（照 ChatMemoryProvider 模式，HermesApplication.onCreate 调用） */
    public static void init(Context ctx) {
        appContext = ctx.getApplicationContext();
    }

    @Override public String id() { return "memory"; }

    @Override public List<ToolRegistry.Tool> discover() {
        List<ToolRegistry.Tool> list = new ArrayList<>();

        // ── face_history: 扫描所有房间 journal, 提取最后用户输入, 按今天/昨天/本周分组 ──
        list.add(new ToolRegistry.Tool("face_history", "各房间最近对话历史", null,
            a -> {
                if (appContext == null) return new ToolRegistry.Result(false, "context 未初始化");
                try {
                    StorageManager sm = new StorageManager(appContext);
                    JSONArray groups = new JSONArray();
                    JSONArray today = new JSONArray();
                    JSONArray yesterday = new JSONArray();
                    JSONArray thisWeek = new JSONArray();
                    long now = System.currentTimeMillis();
                    long todayStart = now - (now % 86400000L); // 今天 00:00 近似

                    File roomsDir = sm.getRoomsDir();
                    File[] roomDirs = roomsDir.listFiles(File::isDirectory);
                    if (roomDirs != null) {
                        for (File rd : roomDirs) {
                            /* 工单17: 首页对话固定房间 r_home 不进左侧历史（历史列表语义不变） */
                            if ("r_home".equals(rd.getName())) continue;
                            File jf = new File(rd, "journal.jsonl");
                            if (!jf.exists()) continue;
                            String lastUserText = null;
                            long lastTs = 0;
                            try (BufferedReader r = new BufferedReader(new InputStreamReader(
                                    new FileInputStream(jf), StandardCharsets.UTF_8))) {
                                String line;
                                while ((line = r.readLine()) != null) {
                                    line = line.trim();
                                    if (line.isEmpty()) continue;
                                    try {
                                        JSONObject ev = new JSONObject(line);
                                        if ("_header".equals(ev.optString("type"))) continue;
                                        String t = ev.optString("type", "");
                                        String payloadText = ev.optJSONObject("payload") != null
                                                ? ev.optJSONObject("payload").optString("text", "") : "";
                                        // user_input 优先, agent_start 次之
                                        if ("user_input".equals(t) && !payloadText.isEmpty()) {
                                            lastUserText = payloadText;
                                            lastTs = ev.optLong("ts", 0);
                                        } else if (lastUserText == null && "agent_start".equals(t) && !payloadText.isEmpty()) {
                                            lastUserText = ev.optJSONObject("payload").optString("goal", "");
                                            lastTs = ev.optLong("ts", 0);
                                        }
                                    } catch (org.json.JSONException ignored) {}
                                }
                            } catch (Exception ignored) {}

                            if (lastUserText != null && lastUserText.length() > 0) {
                                JSONObject entry = new JSONObject()
                                        .put("roomId", rd.getName())
                                        .put("text", lastUserText.length() > 50
                                                ? lastUserText.substring(0, 47) + "..." : lastUserText)
                                        .put("ts", lastTs);
                                if (lastTs > todayStart) today.put(entry);
                                else if (lastTs > todayStart - 86400000L) yesterday.put(entry);
                                else if (lastTs > todayStart - 7 * 86400000L) thisWeek.put(entry);
                            }
                        }
                    }
                    if (today.length() > 0) groups.put(new JSONObject().put("label", "今天").put("items", today));
                    if (yesterday.length() > 0) groups.put(new JSONObject().put("label", "昨天").put("items", yesterday));
                    if (thisWeek.length() > 0) groups.put(new JSONObject().put("label", "本周").put("items", thisWeek));
                    return new ToolRegistry.Result(true, "历史记录",
                            new JSONObject().put("groups", groups).toString());
                } catch (Exception e) {
                    return new ToolRegistry.Result(false, "历史读取失败: " + e.getMessage());
                }
            },
            "native", "readonly", "none", true, 10, "memory",
            new ToolRegistry.ParamDef[]{},
            "JSON: {\"groups\":[{\"label\":\"今天\",\"items\":[...]}]}",
            new String[]{"各房间历史"}, null, 10000,
            new ToolRegistry.Manifest("历史记录", "low", "各房间最近对话历史", false, "io", "FAST", false, 10000),
            null));

        // ── drama_memory: 追剧收藏/屏蔽记忆 (op 分发) ──
        list.add(new ToolRegistry.Tool("drama_memory", "追剧收藏/屏蔽记忆", null,
            a -> {
                if (appContext == null) return new ToolRegistry.Result(false, "context 未初始化");
                try {
                    DramaMemory dm = new DramaMemory(appContext.getFilesDir());
                    String op = a.optString("op", "");
                    if ("clear".equals(op)) {
                        dm.clearAll();   // 设置页隐私区块：清空全部追剧记忆
                        return new ToolRegistry.Result(true, "已清空追剧记忆",
                                new JSONObject().put("cleared", true).toString());
                    }
                    if ("add_fav".equals(op)) {
                        dm.addFav(a.optString("title"), a.optString("url"), a.optString("poster"));
                        return new ToolRegistry.Result(true, "已收藏",
                                new JSONObject().put("added", true).toString());
                    }
                    if ("remove_fav".equals(op)) {
                        dm.removeFav(a.optString("title"));
                        return new ToolRegistry.Result(true, "已取消收藏",
                                new JSONObject().put("removed", true).toString());
                    }
                    if ("add_block".equals(op)) {
                        dm.addBlock(a.optString("title"), a.optString("source"));
                        dm.removeFav(a.optString("title")); // 屏蔽自动去收藏
                        return new ToolRegistry.Result(true, "已屏蔽",
                                new JSONObject().put("added", true).toString());
                    }
                    if ("remove_block".equals(op)) {
                        dm.removeBlock(a.optString("title"));
                        return new ToolRegistry.Result(true, "已取消屏蔽",
                                new JSONObject().put("removed", true).toString());
                    }
                    // 默认返回全量
                    JSONObject data = new JSONObject();
                    try {
                        data.put("favs", dm.getFavs());
                        data.put("blocks", dm.getBlocks());
                        data.put("signals", dm.getSignals());
                    } catch (Exception ignored) {}
                    return new ToolRegistry.Result(true, "剧集记忆", data.toString());
                } catch (Exception e) {
                    return new ToolRegistry.Result(false, "记忆读写失败: " + e.getMessage());
                }
            },
            "native", "write", "none", true, 5, "memory",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("op", "string", false, "add_fav/remove_fav/add_block/remove_block/list", "操作类型"),
                new ToolRegistry.ParamDef("title", "string", false, "剧名", "收藏/屏蔽的剧名"),
                new ToolRegistry.ParamDef("url", "string", false, "URL", "add_fav 用"),
                new ToolRegistry.ParamDef("poster", "string", false, "海报URL", "add_fav 用"),
                new ToolRegistry.ParamDef("source", "string", false, "来源", "add_block 用"),
            },
            "JSON: {\"favs\":[],\"blocks\":[],\"signals\":{}} 或 {\"added\":true}",
            new String[]{"收藏漫长的季节", "屏蔽某剧"}, null, 5000,
            new ToolRegistry.Manifest("剧集记忆", "low", "追剧收藏/屏蔽记忆", false, "io", "FAST", false, 5000),
            null));

        // ── watch_history: 观看进度历史 (读 watch_history.json 全量) ──
        list.add(new ToolRegistry.Tool("watch_history", "观看进度历史", null,
            a -> {
                if (appContext == null) return new ToolRegistry.Result(false, "context 未初始化");
                try {
                    File wh = new File(appContext.getFilesDir(), "watch_history.json");
                    if ("clear".equals(a.optString("op", ""))) {
                        if (wh.exists()) wh.delete();   // 设置页隐私区块：清空观看历史
                        return new ToolRegistry.Result(true, "已清空观看历史",
                                new JSONObject().put("cleared", true).toString());
                    }
                    if (wh.exists()) {
                        BufferedReader r = new BufferedReader(new InputStreamReader(
                                new FileInputStream(wh), "UTF-8"));
                        try {
                            StringBuilder sb = new StringBuilder();
                            String line;
                            while ((line = r.readLine()) != null) sb.append(line);
                            return new ToolRegistry.Result(true, "观看历史",
                                    new JSONObject(sb.toString()).toString());
                        } finally {
                            r.close();
                        }
                    }
                    return new ToolRegistry.Result(true, "观看历史", new JSONObject().toString());
                } catch (Exception e) {
                    // 原 case 读失败返回空对象，保持兼容
                    return new ToolRegistry.Result(true, "观看历史", new JSONObject().toString());
                }
            },
            "native", "write", "none", true, 5, "memory",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("op", "string", false, "list/clear", "list=读取, clear=清空"),
            },
            "JSON: watch_history 全量",
            new String[]{"看剧进度"}, null, 5000,
            new ToolRegistry.Manifest("观看历史", "low", "剧集观看进度历史", false, "io", "FAST", false, 5000),
            null));

        // ── face_mine: 扫描所有房间 work/ 目录产物 ──
        list.add(new ToolRegistry.Tool("face_mine", "各房间工作产物列表", null,
            a -> {
                if (appContext == null) return new ToolRegistry.Result(false, "context 未初始化");
                try {
                    StorageManager sm = new StorageManager(appContext);
                    JSONArray items = new JSONArray();
                    File roomsDir = sm.getRoomsDir();
                    File[] roomDirs = roomsDir.listFiles(File::isDirectory);
                    if (roomDirs != null) {
                        for (File rd : roomDirs) {
                            File workDir = sm.getRoomWorkDir(rd.getName());
                            if (!workDir.exists() || !workDir.isDirectory()) continue;
                            File[] files = workDir.listFiles();
                            if (files == null) continue;
                            for (File f : files) {
                                if (f.isDirectory()) continue;
                                String name = f.getName();
                                String ext = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1).toLowerCase() : "";
                                String type = ext.equals("apk") ? "apk" :
                                        (ext.equals("html") || ext.equals("htm") ? "html" : "file");
                                items.put(new JSONObject()
                                        .put("name", name)
                                        .put("type", type)
                                        .put("roomId", rd.getName())
                                        .put("size", f.length())
                                        .put("ts", f.lastModified()));
                            }
                        }
                    }
                    return new ToolRegistry.Result(true, "我的产物",
                            new JSONObject().put("items", items).toString());
                } catch (Exception e) {
                    return new ToolRegistry.Result(false, "产物列表失败: " + e.getMessage());
                }
            },
            "native", "readonly", "none", true, 10, "memory",
            new ToolRegistry.ParamDef[]{},
            "JSON: {\"items\":[...]}",
            new String[]{"我的产物"}, null, 10000,
            new ToolRegistry.Manifest("我的产物", "low", "各房间工作产物列表", false, "io", "FAST", false, 10000),
            null));

        // ── memory: curated 记忆条目管理（批2 一表双脑真共用，Hermes memory 工具重定向目标） ──
        list.add(new ToolRegistry.Tool("memory", "记忆条目管理（curated，§分隔，journal 唯一事件源）。"
                + "op=read 读有效条目 / add 追加 / replace 替换 / remove 删除。",
                null, a -> {
            if (appContext == null) return new ToolRegistry.Result(false, "context 未初始化");
            try {
                com.hermes.android.agent.Journal j = new com.hermes.android.agent.Journal(
                        new StorageManager(appContext).getRoomsDir());
                String roomId = a.optString("roomId", "");
                String op = a.optString("op", "read");
                switch (op) {
                    case "add": {
                        String text = a.optString("text", "");
                        int seq = j.appendDraft(roomId, text, a.optString("kind", "memory"));
                        if (seq < 0) return new ToolRegistry.Result(false, "写入失败 seq=" + seq);
                        return new ToolRegistry.Result(true, "记忆已记录",
                                new JSONObject().put("seq", seq).toString());
                    }
                    case "replace": {
                        String oldText = a.optString("old", "");
                        String newText = a.optString("new", "");
                        int seq = j.memoryReplace(roomId, oldText, newText, a.optString("kind", "memory"));
                        if (seq < 0) return new ToolRegistry.Result(false, "替换失败 seq=" + seq);
                        return new ToolRegistry.Result(true, "记忆已替换",
                                new JSONObject().put("seq", seq).toString());
                    }
                    case "remove": {
                        String text = a.optString("text", "");
                        int seq = j.memoryRemove(roomId, text);
                        if (seq < 0) return new ToolRegistry.Result(false, "删除失败 seq=" + seq);
                        return new ToolRegistry.Result(true, "记忆已删除",
                                new JSONObject().put("seq", seq).toString());
                    }
                    default: {
                        org.json.JSONArray drafts = j.memoryDrafts(roomId);
                        return new ToolRegistry.Result(true, "记忆条目",
                                new JSONObject().put("curated", j.memoryCurated(drafts))
                                        .put("count", drafts.length()).toString());
                    }
                }
            } catch (Exception e) {
                return new ToolRegistry.Result(false, "记忆操作失败: " + e.getMessage());
            }
        }, "native", "write", "none", true, 5, "memory",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("op", "string", true, "read/add/replace/remove", "操作类型"),
                new ToolRegistry.ParamDef("text", "string", false, "add/remove 用", "记忆条目文本"),
                new ToolRegistry.ParamDef("old", "string", false, "replace 用", "旧条目"),
                new ToolRegistry.ParamDef("new", "string", false, "replace 用", "新条目"),
                new ToolRegistry.ParamDef("kind", "string", false, "memory", "条目类型"),
            },
            "JSON: {curated, count} 或 {seq}",
            new String[]{"记住：张三欠我5000"}, null, 8000,
            new ToolRegistry.Manifest("记忆条目", "low", "curated 记忆条目读写", true, "io", "FAST", false, 8000),
            null));

        // ── 工单9 幕二 三件套 a: memory.cover / memory.search 只读查询（8389 只读集暴露给客居脑） ──
        list.add(new ToolRegistry.Tool("memory.cover", "记忆覆盖投影(只读): 预算内新记忆逐字/旧记忆塌缩摘要(冻结注入友好)。",
                null, a -> {
            if (appContext == null) return new ToolRegistry.Result(false, "context 未初始化");
            try {
                com.hermes.android.agent.Journal j = new com.hermes.android.agent.Journal(
                        new StorageManager(appContext).getRoomsDir());
                String roomId = a.optString("roomId", "");
                int budget = a.optInt("budget", com.hermes.android.agent.Journal.COVER_BUDGET_DEFAULT);
                org.json.JSONArray cover = j.memoryCover(roomId, budget);
                return new ToolRegistry.Result(true, "记忆覆盖",
                        new org.json.JSONObject().put("cover", cover).toString());
            } catch (Exception e) {
                return new ToolRegistry.Result(false, "记忆覆盖失败: " + e.getMessage());
            }
        }, "native", "readonly", "none", true, 10, "memory",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("roomId", "string", false, "房间ID", "房间"),
                new ToolRegistry.ParamDef("budget", "integer", false, "20", "覆盖预算行数"),
            },
            "JSON: {cover:[{mode,text,...}]}",
            new String[]{"读取当前记忆覆盖投影"}, null, 8000,
            new ToolRegistry.Manifest("记忆覆盖", "low", "只读记忆覆盖投影", true, "io", "FAST", false, 8000),
            null));

        list.add(new ToolRegistry.Tool("memory.search", "记忆检索(只读): 按内容检索 journal 历史(大小写不敏感子串)。",
                null, a -> {
            if (appContext == null) return new ToolRegistry.Result(false, "context 未初始化");
            try {
                com.hermes.android.agent.Journal j = new com.hermes.android.agent.Journal(
                        new StorageManager(appContext).getRoomsDir());
                String roomId = a.optString("roomId", "");
                String query = a.optString("query", "");
                int limit = a.optInt("limit", 10);
                org.json.JSONObject res = j.search(roomId, query, limit);
                org.json.JSONObject data = res.optJSONObject("data");
                return new ToolRegistry.Result(true, "记忆检索",
                        data != null ? data.toString() : res.toString());
            } catch (Exception e) {
                return new ToolRegistry.Result(false, "记忆检索失败: " + e.getMessage());
            }
        }, "native", "readonly", "none", true, 10, "memory",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("roomId", "string", false, "房间ID", "房间"),
                new ToolRegistry.ParamDef("query", "string", true, "检索词", "检索内容"),
                new ToolRegistry.ParamDef("limit", "integer", false, "10", "结果上限"),
            },
            "JSON: {events:[{seq,ts,type,snippet}], count}",
            new String[]{"检索相关记忆"}, null, 8000,
            new ToolRegistry.Manifest("记忆检索", "low", "只读按内容检索", true, "io", "FAST", false, 8000),
            null));

        return list;
    }
}
