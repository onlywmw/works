/* ============================================================
   app.js — 入口: 初始化 + 全局事件
   第三幕清场: btnBack 老视图绑定已删 (专家模式新脸化接管房间/会话/文件/运行);
   app-chat/app-files 纯老视图 JS 已删; 新脸 init 由 newface.js showFace() 接管
   ============================================================ */

/* ============ 初始化 ============ */
initLang();
applyI18n();
if(typeof refreshModelAvatars==='function')refreshModelAvatars();
/* P2: 投影渲染器由 enterRoom 参数化 init 到注入容器 (chatBody 老 DOM 已删, 不再全局 init);
   refreshRuntime 已随老运行页删除 (派单№5: 设置迁新脸抽屉, TOKEN/模型由抽屉区块渲染) */
ev('MOV v3.0 '+t('ready')+(B.present?' · '+t('bridge.on'):' · '+t('bridge.off')));

/* 加密状态检查 */
if(B.present){
  var enc=B.encStatus();
  if(enc&&!enc.ok){
    setTimeout(function(){B.toast('⚠ 加密存储不可用, API Key 以明文存储');}, 2000);
  }
}
