package com.hermes.android.causal;

import com.hermes.android.agent.Journal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 认知账本（蓝图 §3.2 逻辑变化链）— 哈希链只可追加、不可篡改。
 *
 * 区块 = journal _causal_rule_block 事件：`{prevHash, dataHash, blockHash, reason, evidence}`。
 * 规则增删改 + 规则命中触发均 append 区块（触发区块带 evidence，回答"哪天基于哪条证据认定高风险"）。
 * blockHash = CausalHash.blockHash(prevHash, dataHash)，首块 prevHash 为空。
 * 纯 Java，零 android 依赖。
 */
public class CausalChain {

    /** 追加一个区块（规则变更/触发）。返回 blockHash。 */
    public String append(Journal journal, String roomId, String dataHash,
                         String reason, JSONObject evidence) {
        String prevHash = lastBlockHash(journal, roomId);
        String blockHash = CausalHash.blockHash(prevHash, dataHash);
        JSONObject payload = new JSONObject();
        try {
            payload.put("prevHash", prevHash == null ? "" : prevHash);
            payload.put("dataHash", dataHash == null ? "" : dataHash);
            payload.put("blockHash", blockHash);
            payload.put("reason", reason == null ? "" : reason);
            if (evidence != null) payload.put("evidence", evidence);
        } catch (org.json.JSONException ignored) {}
        JSONObject ev = new JSONObject();
        try {
            ev.put("actor", "causal");
            ev.put("type", Journal.TYPE_CAUSAL_BLOCK);
            ev.put("payload", payload);
        } catch (org.json.JSONException ignored) {}
        journal.append(roomId, ev);
        return blockHash;
    }

    /** 回放账本：{blocks:[{seq,ts,reason,dataHash,blockHash,evidence}], verified:bool, head}。 */
    public JSONObject replay(Journal journal, String roomId) {
        JSONArray blocks = journal.eventsOfType(roomId, Journal.TYPE_CAUSAL_BLOCK);
        JSONObject result = new JSONObject();
        JSONArray arr = new JSONArray();
        boolean verified = true;
        String expectedPrev = null;
        String head = "";
        try {
            for (int i = 0; i < blocks.length(); i++) {
                JSONObject ev = blocks.optJSONObject(i);
                JSONObject p = ev != null ? ev.optJSONObject("payload") : null;
                if (p == null) continue;
                String prev = p.optString("prevHash", "");
                String data = p.optString("dataHash", "");
                String block = p.optString("blockHash", "");
                String computed = CausalHash.blockHash(prev.isEmpty() ? null : prev, data);
                // 校验：区块哈希 = blockHash(prev,data) 且 prev 链到前块
                boolean ok = computed.equals(block)
                        && (expectedPrev == null ? prev.isEmpty() : prev.equals(expectedPrev));
                if (!ok) verified = false;
                expectedPrev = block;
                head = block;
                JSONObject b = new JSONObject();
                b.put("seq", ev.optInt("seq", 0));
                b.put("ts", ev.optLong("ts", 0));
                b.put("reason", p.optString("reason", ""));
                b.put("dataHash", data);
                b.put("blockHash", block);
                b.put("ok", ok);
                if (p.has("evidence")) b.put("evidence", p.optJSONObject("evidence"));
                arr.put(b);
            }
            result.put("blocks", arr);
            result.put("verified", verified);
            result.put("head", head);
        } catch (org.json.JSONException ignored) {}
        return result;
    }

    /** 链完整校验（false = 被篡改）。 */
    public boolean verify(Journal journal, String roomId) {
        return replay(journal, roomId).optBoolean("verified", false);
    }

    /** 最后区块哈希（创世 prev）。 */
    public String lastBlockHash(Journal journal, String roomId) {
        JSONObject replay = replay(journal, roomId);
        return replay.optString("head", "");
    }

    /** 区块数（测试/诊断用）。 */
    public int size(Journal journal, String roomId) {
        return journal.eventsOfType(roomId, Journal.TYPE_CAUSAL_BLOCK).length();
    }
}
