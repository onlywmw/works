package com.hermes.android.mcp;

import android.util.Log;
import io.modelcontextprotocol.server.McpServer;
import io.modelcontextprotocol.server.McpStatelessServerFeatures;
import io.modelcontextprotocol.server.McpStatelessSyncServer;
import io.modelcontextprotocol.spec.McpSchema;
import io.modelcontextprotocol.spec.McpStatelessServerTransport;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

/**
 * P1 spike: 真机验证官方 MCP Java SDK（mcp-core 1.0.2）在 Android 运行时可用——
 * records desugar/Reactor/ServiceLoader(JSON 提供者) 全部过，build+listTools 出标准 schema。
 * HermesApplication.onCreate 触发，logcat tag=McpSpike。
 */
public class McpSpikeCheck {

    public static void run() {
        try {
            McpStatelessServerTransport t = new McpStatelessServerTransport() {
                @Override public void setMcpHandler(io.modelcontextprotocol.server.McpStatelessServerHandler h) {}
                @Override public Mono<Void> closeGracefully() { return Mono.empty(); }
            };
            McpStatelessSyncServer server = McpServer.sync(t)
                    .serverInfo("mov", "1.0.0")
                    .capabilities(McpSchema.ServerCapabilities.builder().tools(true).build())
                    .build();
            McpSchema.JsonSchema schema = new McpSchema.JsonSchema("object",
                    Map.of("text", Map.of("type", "string")), List.of(), false, null, null);
            server.addTool(new McpStatelessServerFeatures.SyncToolSpecification(
                    new McpSchema.Tool("echo", "Echo test", null, schema, null, null, null),
                    (ex, req) -> new McpSchema.CallToolResult(
                            List.of(new McpSchema.TextContent("pong")), false, null, null)));
            List<McpSchema.Tool> tools = server.listTools();
            Log.i("McpSpike", "SDK OK tools=" + tools.size() + " first=" + tools.get(0).name());
        } catch (Throwable e) {
            Log.e("McpSpike", "SDK FAIL: " + e, e);
        }
    }
}
