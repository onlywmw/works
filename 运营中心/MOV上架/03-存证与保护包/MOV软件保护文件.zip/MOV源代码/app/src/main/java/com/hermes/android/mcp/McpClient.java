package com.hermes.android.mcp;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Scanner;

/**
 * McpClient — HTTP MCP 客户端 (TOOL_PORTING P0)。
 *
 * 双协议支持：
 *  - **旧 JSON-RPC**（MOV 老 MCP server / 兼容 server）：POST + application/json 响应，无 session。
 *  - **Streamable HTTP**（MCP 新标准，如 mcp.golcer.com 企业信息服务）：initialize 握手 →
 *    Mcp-Session-Id 头 + Accept 双类型 + SSE 帧响应（event: message / data: {...}）。
 *
 * 用 Android 内置 HttpURLConnection，不引第三方库。listTools/callTool 自动协商：
 * 先试旧 JSON-RPC，响应非纯 JSON 或 server 要求 session → 走 Streamable 会话。
 */
public class McpClient {

    private static final int TIMEOUT_CONNECT = 5000;
    private static final int TIMEOUT_READ = 30000;
    /** Streamable HTTP 要求的双 Accept：JSON + SSE。 */
    private static final String ACCEPT_BOTH = "application/json, text/event-stream";

    // ══════════ 旧 JSON-RPC 路径（兼容，保留签名） ══════════

    public boolean healthCheck(String serverUrl, String token) {
        // 旧 JSON-RPC：POST 空对象，2xx 即可达
        try {
            PostResult pr = post(serverUrl, token, new JSONObject().toString(), ACCEPT_BOTH);
            if (pr != null && pr.status >= 200 && pr.status < 300) return true;
        } catch (Exception ignored) {}
        // Streamable HTTP：initialize 握手成功即可达（旧 POST 会被要求 session/SSE）
        try {
            StreamableSession s = StreamableSession.connect(serverUrl, token);
            s.close();
            return true;
        } catch (Exception e) { return false; }
    }

    public JSONArray listTools(String serverUrl, String token) throws Exception {
        JSONObject req = new JSONObject();
        req.put("method", "tools/list");
        PostResult pr = post(serverUrl, token, req.toString(), ACCEPT_BOTH);
        if (pr != null && pr.status >= 200 && pr.status < 300
                && pr.contentType != null && pr.contentType.contains("application/json")) {
            JSONObject r = new JSONObject(pr.body);
            JSONArray tools = r.optJSONArray("tools");
            if (tools != null) return tools;
        }
        // 非纯 JSON 响应（SSE）或 server 要求 session → Streamable 会话
        StreamableSession s = StreamableSession.connect(serverUrl, token);
        try { return s.listTools(); } finally { s.close(); }
    }

    public JSONObject callTool(String serverUrl, String token, String toolName, JSONObject args) throws Exception {
        JSONObject req = new JSONObject();
        req.put("method", "tools/call");
        JSONObject params = new JSONObject();
        params.put("name", toolName);
        params.put("arguments", args != null ? args : new JSONObject());
        req.put("params", params);
        PostResult pr = post(serverUrl, token, req.toString(), ACCEPT_BOTH);
        if (pr != null && pr.status >= 200 && pr.status < 300
                && pr.contentType != null && pr.contentType.contains("application/json")) {
            return new JSONObject(pr.body);
        }
        StreamableSession s = StreamableSession.connect(serverUrl, token);
        try { return s.callTool(toolName, args); } finally { s.close(); }
    }

    // ══════════ HTTP POST ══════════

    /** 包级可见：单测可构造 fake 响应。 */
    static class PostResult {
        final int status;
        final String contentType;
        final String body;
        final java.util.Map<String, String> headers;
        PostResult(int status, String contentType, String body, java.util.Map<String, String> headers) {
            this.status = status; this.contentType = contentType; this.body = body; this.headers = headers;
        }
        String header(String name) { return headers != null ? headers.get(name) : null; }
    }

    private static PostResult post(String url, String token, String json, String accept) {
        return postRaw(url, token, null, json, accept, "POST");
    }

    /**
     * 传输层抽象（包级）：默认实现走 HttpURLConnection；单测注入记录型 fake，零网络。
     * 返回 null 表示传输失败（等价 postRaw 的 catch 语义）。
     */
    interface Transport {
        PostResult send(String url, String token, String sessionId, String json, String accept, String method);
    }

    private static final Transport HTTP_TRANSPORT =
        (url, token, sessionId, json, accept, method) -> postRaw(url, token, sessionId, json, accept, method);

    private static PostResult postRaw(String url, String token, String sessionId, String json, String accept, String method) {
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(TIMEOUT_CONNECT);
            conn.setReadTimeout(TIMEOUT_READ);
            conn.setRequestMethod(method);
            if (json != null) {
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
            }
            if (accept != null) conn.setRequestProperty("Accept", accept);
            if (token != null && !token.isEmpty()) conn.setRequestProperty("Authorization", "Bearer " + token);
            if (sessionId != null && !sessionId.isEmpty()) conn.setRequestProperty("Mcp-Session-Id", sessionId);
            if (json != null) {
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                }
            }
            int status = conn.getResponseCode();
            String contentType = conn.getHeaderField("Content-Type");
            // 收集响应头（Streamable 需 Mcp-Session-Id）
            java.util.Map<String, String> headers = new java.util.HashMap<>();
            java.util.Map<String, List<String>> hf = conn.getHeaderFields();
            if (hf != null) {
                for (java.util.Map.Entry<String, List<String>> e : hf.entrySet()) {
                    String k = e.getKey();
                    if (k != null && e.getValue() != null && !e.getValue().isEmpty()) {
                        headers.put(k.toLowerCase(), e.getValue().get(0));
                    }
                }
            }
            InputStream is = status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream();
            String body = is != null ? readAll(is) : "";
            return new PostResult(status, contentType, body, headers);
        } catch (Exception e) { return null; }
    }

    private static String readAll(InputStream is) {
        try (Scanner s = new Scanner(is, "UTF-8").useDelimiter("\\A")) {
            return s.hasNext() ? s.next() : "{}";
        } catch (Exception e) { return "{}"; }
    }

    /**
     * SSE 帧解析：按空行（\n\n，兼容 \r\n\r\n）分帧，逐帧提取 data（单帧多行 data 仍按 SSE 标准拼接）。
     * 一个响应可能含多个事件帧（如 notification 帧在 result 帧之前），拼在一起不是合法 JSON。
     * 选取策略：返回第一个能解析为 JSON-RPC response（含 "result" 或 "error" 键）的帧的 data；
     * 都没有则返回最后一帧 data；无 data 行返回 null。
     */
    static String sseData(String sseBody) {
        if (sseBody == null) return null;
        String lastData = null;
        for (String frame : sseBody.split("\r?\n\r?\n")) {
            StringBuilder data = new StringBuilder();
            for (String line : frame.split("\r?\n")) {
                if (line.startsWith("data:")) {
                    String d = line.substring(5).trim();
                    if (!d.isEmpty()) {
                        if (data.length() > 0) data.append('\n');
                        data.append(d);
                    }
                }
            }
            if (data.length() == 0) continue;
            String frameData = data.toString();
            lastData = frameData;
            // 优先取 JSON-RPC response 帧（含 result/error），跳过 notification 等中间帧
            try {
                JSONObject obj = new JSONObject(frameData);
                if (obj.has("result") || obj.has("error")) return frameData;
            } catch (Exception ignored) {}
        }
        return lastData;
    }

    // ══════════ Streamable HTTP 会话 ══════════

    /**
     * Streamable HTTP 会话：initialize 握手拿 session id，业务请求带 Mcp-Session-Id 头，
     * 响应为 SSE 帧。close() 发 DELETE 清理。
     */
    public static class StreamableSession {
        public final String serverUrl;
        public final String token;
        /** 非 final：会话过期重连后写回新 id；close() 后清空（本地状态清理）。 */
        public String sessionId;
        public final String protocolVersion;
        private final Transport transport;

        private StreamableSession(String serverUrl, String token, String sessionId, String protocolVersion,
                                  Transport transport) {
            this.serverUrl = serverUrl;
            this.token = token;
            this.sessionId = sessionId;
            this.protocolVersion = protocolVersion;
            this.transport = transport;
        }

        /** 建立会话：POST initialize → 从响应头拿 Mcp-Session-Id，从 SSE 帧拿 InitializeResult。 */
        public static StreamableSession connect(String serverUrl, String token) throws Exception {
            return connect(serverUrl, token, HTTP_TRANSPORT);
        }

        /** 包级重载：单测注入 fake transport，零网络。 */
        static StreamableSession connect(String serverUrl, String token, Transport transport) throws Exception {
            JSONObject req = new JSONObject()
                .put("jsonrpc", "2.0")
                .put("method", "initialize")
                .put("params", new JSONObject()
                    .put("protocolVersion", "2025-06-18")
                    .put("capabilities", new JSONObject())
                    .put("clientInfo", new JSONObject().put("name", "mov").put("version", "3.3.0")))
                .put("id", 1);
            PostResult pr = transport.send(serverUrl, token, null, req.toString(), ACCEPT_BOTH, "POST");
            if (pr == null || pr.status < 200 || pr.status >= 300) {
                throw new Exception("MCP initialize 失败 (HTTP " + (pr != null ? pr.status : "null") + ")");
            }
            // session id 在响应头（Streamable HTTP 标准），部分实现也在 body result._sessionId
            String sessionId = pr.header("mcp-session-id");
            String data = sseData(pr.body);
            if (sessionId == null || sessionId.isEmpty()) {
                // 某些实现回 session id 在 body JSON 里
                if (data != null) {
                    JSONObject r = new JSONObject(data);
                    String sid = r.optJSONObject("result") != null
                        ? r.optJSONObject("result").optString("_sessionId", "") : "";
                    sessionId = sid;
                }
            }
            if (sessionId == null || sessionId.isEmpty()) {
                throw new Exception("MCP initialize 未返回 session id");
            }
            String pv = "";
            if (data != null) {
                JSONObject r = new JSONObject(data);
                pv = r.optJSONObject("result") != null
                    ? r.optJSONObject("result").optString("protocolVersion", "") : "";
            }
            // 通知 server initialized（必须带 session id，否则 server 不建立会话状态）
            try {
                JSONObject notif = new JSONObject().put("jsonrpc", "2.0")
                    .put("method", "notifications/initialized");
                transport.send(serverUrl, token, sessionId, notif.toString(), ACCEPT_BOTH, "POST");
            } catch (Exception ignored) {}
            return new StreamableSession(serverUrl, token, sessionId, pv, transport);
        }

        public JSONArray listTools() throws Exception {
            JSONObject req = new JSONObject().put("jsonrpc", "2.0")
                .put("method", "tools/list").put("params", new JSONObject()).put("id", 2);
            String data = request(req);
            JSONObject r = new JSONObject(data);
            // result 是对象（含 tools 数组）；optJSONObject 判存在（optJSONArray 对对象返回 null）
            JSONArray tools = r.optJSONObject("result") != null
                ? r.optJSONObject("result").optJSONArray("tools") : null;
            if (tools == null && r.has("error")) {
                throw new Exception("tools/list 失败: " + r.optJSONObject("error").optString("message"));
            }
            return tools != null ? tools : new JSONArray();
        }

        public JSONObject callTool(String toolName, JSONObject args) throws Exception {
            JSONObject req = new JSONObject().put("jsonrpc", "2.0")
                .put("method", "tools/call")
                .put("params", new JSONObject()
                    .put("name", toolName)
                    .put("arguments", args != null ? args : new JSONObject()))
                .put("id", 3);
            String data = request(req);
            JSONObject r = new JSONObject(data);
            if (r.has("error")) {
                JSONObject err = r.optJSONObject("error");
                JSONObject out = new JSONObject();
                out.put("error", err != null ? err.toString() : "调用失败");
                return out;
            }
            return r.optJSONObject("result") != null ? r.optJSONObject("result") : r;
        }

        public void close() {
            // MCP Streamable HTTP 规范：会话关闭发 HTTP DELETE（带 Mcp-Session-Id）。
            // DELETE 失败不阻塞、不抛错；无论结果如何都清理本地状态。
            try {
                if (sessionId != null && !sessionId.isEmpty()) {
                    transport.send(serverUrl, token, sessionId, null, null, "DELETE");
                }
            } catch (Exception ignored) {} finally {
                sessionId = null;
            }
        }

        private String request(JSONObject req) throws Exception {
            PostResult pr = postWithSession(req.toString());
            if (pr == null) throw new Exception("MCP 请求失败");
            if (pr.status < 200 || pr.status >= 300) {
                // 会话可能过期 → 原地重连，新 sessionId 写回本会话字段，后续调用沿用新会话
                StreamableSession fresh = connect(serverUrl, token, transport);
                this.sessionId = fresh.sessionId;
                PostResult retry = postWithSession(req.toString());
                if (retry == null || retry.status < 200 || retry.status >= 300) {
                    throw new Exception("MCP 请求失败 (HTTP " + (retry != null ? retry.status : "null") + ")");
                }
                pr = retry;
            }
            String data = sseData(pr.body);
            if (data == null) {
                // 某些实现直接回 JSON
                if (pr.body.trim().startsWith("{")) return pr.body;
                throw new Exception("MCP 响应非 SSE/JSON");
            }
            return data;
        }

        private PostResult postWithSession(String json) {
            return transport.send(serverUrl, token, sessionId, json, ACCEPT_BOTH, "POST");
        }
    }
}
