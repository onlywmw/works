package com.hermes.android.toolprovider;
import com.hermes.android.HermesActivity;
import com.hermes.android.R;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.util.Log;

import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.agent.ToolRegistry.*;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * SystemToolProvider — 本地系统工具 (TOOL_PORTING P1)。
 * 10 个 L1 无权限工具: 剪贴板/通知/定时/设备信息/音量亮度。
 */
public class SystemToolProvider implements ToolProvider {

    private static final String TAG = "SysTools";
    private static Context appContext;
    private static final Map<Integer, PendingIntent> timers = new ConcurrentHashMap<>();
    private static int timerId = 100;

    public static void init(Context ctx) { appContext = ctx.getApplicationContext(); }

    @Override public String id() { return "system"; }

    @Override
    public List<Tool> discover() {
        List<Tool> list = new ArrayList<>();
        if (appContext == null) return list;

        // ═══ clipboard.write ═══
        list.add(new Tool("clipboard.write", "写内容到系统剪贴板", null, a -> {
            String text = a.optString("text", "");
            if (text.isEmpty()) return new Result(false, "内容为空");
            ClipboardManager cm = (ClipboardManager) appContext.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("MOV", text));
            return new Result(true, "已写入剪贴板");
        }, "native", "write", "none", true, 5, "util",
                new ParamDef[]{new ParamDef("text", "string", true, "", "要写入的内容")},
                "成功: 已写入剪贴板", null, null, 500,
                new Manifest("写剪贴板", "low", "将文本复制到系统剪贴板", false, "io"), null));

        // ═══ notification.post ═══
        list.add(new Tool("notification.post", "发送系统通知", null, a -> {
            String title = a.optString("title", "MOV");
            String body = a.optString("body", "");
            if (body.isEmpty()) return new Result(false, "通知内容为空");
            try {
                NotificationManager nm = (NotificationManager) appContext.getSystemService(Context.NOTIFICATION_SERVICE);
                if (Build.VERSION.SDK_INT >= 33 && !nm.areNotificationsEnabled()) {
                    return new Result(false, "通知权限未开启");
                }
                if (Build.VERSION.SDK_INT >= 26) {
                    nm.createNotificationChannel(new NotificationChannel("mov", "MOV", NotificationManager.IMPORTANCE_DEFAULT));
                }
                android.app.Notification n = new android.app.Notification.Builder(appContext, "mov")
                        .setContentTitle(title).setContentText(body)
                        .setSmallIcon(android.R.drawable.ic_dialog_info).build();
                nm.notify((int) (System.currentTimeMillis() % 100000), n);
                return new Result(true, "通知已发送");
            } catch (Exception e) { return new Result(false, "通知失败: " + e.getMessage()); }
        }, "native", "write", "none", true, 3, "notification",
                new ParamDef[]{new ParamDef("title", "string", false, "", "通知标题"),
                        new ParamDef("body", "string", true, "", "通知内容")},
                "成功: 通知已发送", null, null, 500,
                new Manifest("发通知", "low", "发送系统通知到通知栏", false, "io"),
                () -> {
                    NotificationManager nm = (NotificationManager) appContext.getSystemService(Context.NOTIFICATION_SERVICE);
                    return (Build.VERSION.SDK_INT >= 33 && !nm.areNotificationsEnabled()) ? "通知权限未开启" : null;
                }));

        // ═══ notification.cancel ═══
        list.add(new Tool("notification.cancel", "取消全部 MOV 通知", null, a -> {
            NotificationManager nm = (NotificationManager) appContext.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.cancelAll();
            return new Result(true, "已取消全部通知");
        }, "native", "write", "none", true, 3, "notification", null, "成功", null, null, 200,
                new Manifest("取消通知", "low", "取消所有 MOV 发送的通知", false, "io"), null));

        // ═══ timer.set ═══
        list.add(new Tool("timer.set", "设置定时提醒（best-effort, 省电模式可能不准）", null, a -> {
            int sec = a.optInt("seconds", 0);
            String msg = a.optString("message", "时间到");
            if (sec <= 0 || sec > 86400) return new Result(false, "秒数需在 1-86400 之间");
            int id = timerId++;
            AlarmManager am = (AlarmManager) appContext.getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(appContext, HermesActivity.class);
            intent.putExtra("timer_msg", msg);
            PendingIntent pi = PendingIntent.getActivity(appContext, id, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + sec * 1000L, pi);
            timers.put(id, pi);
            return new Result(true, "定时已设置: " + sec + "秒后提醒 '" + msg + "'");
        }, "native", "write", "none", true, 3, "notification",
                new ParamDef[]{new ParamDef("seconds", "int", true, "1-86400", "秒数"),
                        new ParamDef("message", "string", false, "", "提醒内容")},
                "成功: 已设置", null, null, 500,
                new Manifest("定时提醒", "low", "设置定时提醒（省电模式可能不准时）", false, "io"), null));

        // ═══ timer.cancel ═══
        list.add(new Tool("timer.cancel", "取消所有定时提醒", null, a -> {
            AlarmManager am = (AlarmManager) appContext.getSystemService(Context.ALARM_SERVICE);
            for (PendingIntent pi : timers.values()) am.cancel(pi);
            timers.clear();
            return new Result(true, "已取消所有定时");
        }, "native", "write", "none", true, 2, "notification", null, "成功", null, null, 200,
                new Manifest("取消定时", "low", "取消所有定时提醒", false, "io"), null));

        // ═══ timer.list ═══
        list.add(new Tool("timer.list", "列出所有活跃的定时提醒", null, a -> {
            if (timers.isEmpty()) return new Result(true, "当前无定时");
            StringBuilder sb = new StringBuilder("活跃定时 (" + timers.size() + "):\n");
            for (Map.Entry<Integer, PendingIntent> e : timers.entrySet())
                sb.append("  #").append(e.getKey()).append("\n");
            return new Result(true, sb.toString());
        }, "native", "readonly", "none", true, 2, "notification", null, "定时列表", null, null, 300,
                new Manifest("定时列表", "low", "查看所有活跃定时", false, "io"), null));

        // ═══ battery.status ═══
        list.add(new Tool("battery.status", "查询电池状态和电量", null, a -> {
            BatteryManager bm = (BatteryManager) appContext.getSystemService(Context.BATTERY_SERVICE);
            int pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            boolean charging = bm.isCharging();
            return new Result(true, "电量: " + pct + "%" + (charging ? "（充电中）" : ""));
        }, "native", "readonly", "none", true, 2, "system", null, "电量+充电状态", null, null, 200,
                new Manifest("电池状态", "low", "查询电量百分比和充电状态", false, "io"), null));

        // ═══ network.info ═══
        list.add(new Tool("network.info", "查询当前网络状态", null, a -> {
            ConnectivityManager cm = (ConnectivityManager) appContext.getSystemService(Context.CONNECTIVITY_SERVICE);
            android.net.Network net = cm.getActiveNetwork();
            if (net == null) return new Result(true, "无网络连接");
            NetworkCapabilities caps = cm.getNetworkCapabilities(net);
            String type = "unknown";
            if (caps != null) {
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) type = "WiFi";
                else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) type = "蜂窝";
            }
            return new Result(true, "网络: " + type + "（已连接）");
        }, "native", "readonly", "none", true, 2, "system", null, "网络类型", null, null, 200,
                new Manifest("网络状态", "low", "查询当前网络连接类型", false, "io"), null));

        // ═══ storage.info ═══
        list.add(new Tool("storage.info", "查询存储空间使用情况", null, a -> {
            StatFs stat = new StatFs(Environment.getDataDirectory().getPath());
            long total = stat.getTotalBytes();
            long free = stat.getAvailableBytes();
            long used = total - free;
            return new Result(true, "存储: " + (used / 1024 / 1024) + "MB / " + (total / 1024 / 1024)
                    + "MB（剩余 " + (free / 1024 / 1024) + "MB）");
        }, "native", "readonly", "none", true, 2, "system", null, "存储信息", null, null, 200,
                new Manifest("存储空间", "low", "查询存储使用量", false, "io"), null));

        // ═══ volume.set ═══
        list.add(new Tool("volume.set", "设置系统音量（0-100）", null, a -> {
            int vol = a.optInt("level", -1);
            if (vol < 0 || vol > 100) return new Result(false, "音量需在 0-100 之间");
            AudioManager am = (AudioManager) appContext.getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, vol * max / 100, 0);
            return new Result(true, "音量已设为 " + vol);
        }, "native", "write", "none", true, 2, "system",
                new ParamDef[]{new ParamDef("level", "int", true, "0-100", "音量级别")},
                "成功: 已设置", null, null, 300,
                new Manifest("调音量", "low", "设置系统媒体音量", false, "io"), null));

        // ═══ brightness.set ═══
        list.add(new Tool("brightness.set", "设置屏幕亮度（0-255）", null, a -> {
            int b = a.optInt("level", -1);
            if (b < 0 || b > 255) return new Result(false, "亮度需在 0-255 之间");
            if (!Settings.System.canWrite(appContext)) return new Result(false, "需授权修改系统设置");
            Settings.System.putInt(appContext.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, b);
            return new Result(true, "亮度已设为 " + b);
        }, "native", "write", "none", true, 2, "system",
                new ParamDef[]{new ParamDef("level", "int", true, "0-255", "亮度值")},
                "成功: 已设置", null, null, 300,
                new Manifest("调亮度", "low", "设置屏幕亮度", false, "io"),
                () -> Settings.System.canWrite(appContext) ? null : "需授权'修改系统设置'权限"));

        return list;
    }
}
