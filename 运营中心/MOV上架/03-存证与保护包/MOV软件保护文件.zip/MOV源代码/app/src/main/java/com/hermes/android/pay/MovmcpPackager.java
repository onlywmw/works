package com.hermes.android.pay;

import com.hermes.android.vault.AesGcm;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import javax.crypto.spec.SecretKeySpec;

/**
 * MOV-MCP 加密包打包器（工单26 M3-1，卖家侧）。
 *
 * zip 内 5 件：manifest.json / spec.json / report.json / payload.bin（AES-256-GCM 密文，
 * K=每单随机 32B）/ signature（卖家 RSA 签名：对 payload 密文 + manifest 原文）。
 *
 * K 由调用方管理即焚（卖家侧 vault 加密存、买家侧用毕清零）。
 */
public class MovmcpPackager {

    public static final String EN_MANIFEST = "manifest.json";
    public static final String EN_SPEC = "spec.json";
    public static final String EN_REPORT = "report.json";
    public static final String EN_PAYLOAD = "payload.bin";
    public static final String EN_SIGNATURE = "signature";

    /** 打包产物：zipBytes 可随意传（密文+签名），key=K 必须单独安全通道 */
    public static class Pack {
        public final byte[] zipBytes;
        public final byte[] key;      // 32B 随机 K；调用方负责即焚
        Pack(byte[] zipBytes, byte[] key) { this.zipBytes = zipBytes; this.key = key; }
    }

    private static final SecureRandom RNG = new SecureRandom();

    /** 打包：payloadPlain 明文 → 加密包 + K。 */
    public static Pack pack(JSONObject manifest, JSONObject spec, JSONObject report,
                            byte[] payloadPlain, PrivateKey sellerKey) throws Exception {
        byte[] K = new byte[32];
        RNG.nextBytes(K);
        byte[] encPayload = AesGcm.encrypt(new SecretKeySpec(K, "AES"), payloadPlain);

        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(sellerKey);
        s.update(encPayload);
        s.update(manifest.toString().getBytes(StandardCharsets.UTF_8));
        byte[] sig = s.sign();

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(bos)) {
            put(zos, EN_MANIFEST, manifest.toString().getBytes(StandardCharsets.UTF_8));
            put(zos, EN_SPEC, spec.toString().getBytes(StandardCharsets.UTF_8));
            put(zos, EN_REPORT, report.toString().getBytes(StandardCharsets.UTF_8));
            put(zos, EN_PAYLOAD, encPayload);
            put(zos, EN_SIGNATURE, sig);
        }
        return new Pack(bos.toByteArray(), K);
    }

    /** 解包：zip → 5 件内容（不改写文件，纯内存） */
    public static Unpacked unpack(byte[] zipBytes) throws IOException {
        Unpacked u = new Unpacked();
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            ZipEntry e;
            while ((e = zis.getNextEntry()) != null) {
                byte[] data = readAll(zis);
                switch (e.getName()) {
                    case EN_MANIFEST: u.manifest = new String(data, StandardCharsets.UTF_8); break;
                    case EN_SPEC:     u.spec = new String(data, StandardCharsets.UTF_8); break;
                    case EN_REPORT:   u.report = new String(data, StandardCharsets.UTF_8); break;
                    case EN_PAYLOAD:  u.payload = data; break;
                    case EN_SIGNATURE: u.signature = data; break;
                    default: /* 未知条目忽略 */
                }
            }
        }
        if (u.manifest == null || u.payload == null || u.signature == null)
            throw new IOException("包不完整: 缺 manifest/payload/signature");
        return u;
    }

    /** 验签：SHA256withRSA 对 (payload 密文 + manifest 原文)；篡改任一字节 → false */
    public static boolean verify(byte[] payloadEnc, byte[] manifestBytes, byte[] signature,
                                 java.security.PublicKey sellerPub) {
        try {
            Signature s = Signature.getInstance("SHA256withRSA");
            s.initVerify(sellerPub);
            s.update(payloadEnc);
            s.update(manifestBytes);
            return s.verify(signature);
        } catch (Exception e) {
            return false;
        }
    }

    /** 解包产物（含明文 manifest/spec/report 字符串 + 密文 payload + 签名） */
    public static class Unpacked {
        public String manifest;
        public String spec;
        public String report;
        public byte[] payload;      // AES-GCM 密文
        public byte[] signature;
    }

    private static void put(ZipOutputStream zos, String name, byte[] data) throws IOException {
        zos.putNextEntry(new ZipEntry(name));
        zos.write(data);
        zos.closeEntry();
    }

    private static byte[] readAll(ZipInputStream zis) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = zis.read(b)) > 0) bos.write(b, 0, n);
        return bos.toByteArray();
    }
}
