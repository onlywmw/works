package com.hermes.android.context;

/**
 * 情境转移事件类型 — 状态转移边（时间导数），不是当前状态（瞬时值）。
 *
 * <p>4 族 8 种事件（v1），对应 rikkahub-agent workflow/trigger/ 的
 * TriggerSpec 体系。后续 geofence/notification/app_launched 族在 v2 加入。
 */
public enum ContextEventType {
    /** WiFi 连接（SSID 已知时附带） */
    WIFI_CONNECTED,
    /** WiFi 断开 */
    WIFI_DISCONNECTED,
    /** 电源接通（充电器插入） */
    POWER_CONNECTED,
    /** 电源断开（充电器拔出） */
    POWER_DISCONNECTED,
    /** 屏幕亮起 */
    SCREEN_ON,
    /** 屏幕熄灭 */
    SCREEN_OFF,
    /** 电量从 ≥threshold 降到 <threshold */
    BATTERY_BELOW,
    /** 电量从 <threshold 升到 ≥threshold */
    BATTERY_ABOVE;
}
