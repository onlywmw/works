package com.hermes.android.scene;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.agent.VideoSourceRegistry;

/**
 * FUSION F2: 快脑场景卡 Provider — 一表两脑，快脑慢脑共用同一张 ToolRegistry。
 *
 * 原 BridgeKernel switch-case 里的场景卡逻辑整体搬家到此（train/music/drama/video源/
 * 站点/蚂蚁最新集/更新雷达），注册为 level=FAST 工具。快脑 B.query 查表转发、
 * 慢脑 AgentLoop 直接可调，同一份 handler。
 *
 * 网络 IO 工具 sync=true（禁同步桥红线）；单测零网络（只测 discover 元数据，不执行 handler）。
 */
public class FastSceneProvider implements ToolRegistry.ToolProvider {

    private static Context appContext;
    /** PERF: VideoSourceRegistry 实例缓存（首次构造后复用，避免每次读 filesDir JSON） */
    private static VideoSourceRegistry videoSourceRegistry;

    /** 静态注入（照 ChatMemoryProvider 模式，HermesApplication.onCreate 调用） */
    public static void init(Context ctx) {
        appContext = ctx.getApplicationContext();
    }

    /** 缓存实例（懒初始化，synchronized 防并发双建） */
    private static synchronized VideoSourceRegistry videoRegistry() {
        if (videoSourceRegistry == null && appContext != null) {
            videoSourceRegistry = new VideoSourceRegistry(appContext);
        }
        return videoSourceRegistry;
    }

    @Override public String id() { return "fast-scene"; }

    @Override public List<ToolRegistry.Tool> discover() {
        List<ToolRegistry.Tool> list = new ArrayList<>();

        // ── train_search: 12306 火车票 ──
        list.add(new ToolRegistry.Tool("train_search", "查火车票(12306)", null,
            a -> {
                String from = a.optString("from", "");
                String to = a.optString("to", "");
                String date = a.optString("date", "");
                if (from.isEmpty() || to.isEmpty()) {
                    return new ToolRegistry.Result(false, "from/to 必填");
                }
                if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) date = TrainSource.parseDate(date);
                try {
                    TrainSource ts = new TrainSource();
                    List<TrainSource.Train> trains = ts.search(from, to, date);
                    JSONArray arr = new JSONArray();
                    for (TrainSource.Train t : trains) arr.put(t.toJSON());
                    JSONObject data = new JSONObject().put("trains", arr).put("date", date);
                    return new ToolRegistry.Result(true, "找到 " + trains.size() + " 趟车次", data.toString());
                } catch (Exception e) {
                    return new ToolRegistry.Result(false, "火车票搜索失败: " + e.getMessage());
                }
            },
            "native", "readonly", "none", true, 8, "travel",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("from", "string", true, "出发地", "出发城市"),
                new ToolRegistry.ParamDef("to", "string", true, "目的地", "到达城市"),
                new ToolRegistry.ParamDef("date", "string", false, "yyyy-MM-dd", "出发日期"),
            },
            "JSON: {\"trains\":[...],\"date\":\"yyyy-MM-dd\"}",
            new String[]{"明天北京到上海", "后天上海到广州"}, null, 8000,
            new ToolRegistry.Manifest("查火车票", "low", "查 12306 火车票班次", false, "io", "FAST", true, 8000),
            null));

        // ── shop_search: 京东购物 (W3, SPIKE 骨架: DOM 解析待真机沉淀) ──
        list.add(new ToolRegistry.Tool("shop_search", "搜京东商品", null,
            a -> {
                String kw = a.optString("keyword", "");
                if (kw.isEmpty()) return new ToolRegistry.Result(false, "keyword 必填");
                try {
                    ShopSource ss = new ShopSource();
                    List<ShopSource.Item> items = ss.search(kw);
                    JSONArray arr = new JSONArray();
                    for (ShopSource.Item it : items) arr.put(it.toJSON());
                    JSONObject data = new JSONObject().put("items", arr);
                    return new ToolRegistry.Result(true, "找到 " + items.size() + " 件商品", data.toString());
                } catch (Exception e) {
                    return new ToolRegistry.Result(false, "京东搜索失败: " + e.getMessage());
                }
            },
            "native", "readonly", "none", true, 6, "web",
            new ToolRegistry.ParamDef[]{ new ToolRegistry.ParamDef("keyword", "string", true, "关键词", "要搜的商品") },
            "JSON: {\"items\":[...]}",
            new String[]{"帮我买牛奶", "搜苹果手机"}, null, 8000,
            new ToolRegistry.Manifest("搜京东商品", "low", "京东 H5 商品搜索", false, "io", "FAST", true, 8000),
            null));

        // ── music_search: 网易云音乐 ──
        list.add(new ToolRegistry.Tool("music_search", "搜歌曲(网易云)", null,
            a -> {
                String keyword = a.optString("keyword", "");
                if (keyword.isEmpty()) return new ToolRegistry.Result(false, "keyword 必填");
                try {
                    MusicSource ms = new MusicSource();
                    List<MusicSource.Song> songs = ms.search(keyword);
                    JSONArray arr = new JSONArray();
                    for (MusicSource.Song s : songs) arr.put(s.toJSON());
                    return new ToolRegistry.Result(true, "找到 " + songs.size() + " 首歌",
                            new JSONObject().put("songs", arr).toString());
                } catch (Exception e) {
                    return new ToolRegistry.Result(false, "音乐搜索失败: " + e.getMessage());
                }
            },
            "native", "readonly", "none", true, 5, "scene",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("keyword", "string", true, "歌名/歌手", "搜索关键词"),
            },
            "JSON: {\"songs\":[...]}",
            new String[]{"小苹果", "周杰伦"}, null, 5000,
            new ToolRegistry.Manifest("搜歌", "low", "搜索网易云歌曲", false, "io", "FAST", true, 5000),
            null));

        // ── face_search_drama: 影视搜索 ──
        list.add(new ToolRegistry.Tool("face_search_drama", "搜影视(多源)", null,
            a -> {
                String query = a.optString("query", "");
                if (query.isEmpty()) return new ToolRegistry.Result(false, "query 必填");
                try {
                    DramaSource ds = new DramaSource();
                    VideoSourceRegistry vr = videoRegistry();
                    if (vr != null) ds.setRegistry(vr);
                    List<DramaSource.DramaItem> items = ds.search(query);
                    /* H1: 解析空 → PARSE_DRIFT（所有源解析无果，多半源结构变更） */
                    if (items.isEmpty()) {
                        return new ToolRegistry.Result(false,
                                "解析漂移: 所有源均无结果（可能站点结构变更）",
                                null, null, ToolRegistry.Result.REASON_PARSE_DRIFT);
                    }
                    JSONArray arr = new JSONArray();
                    for (DramaSource.DramaItem item : items) arr.put(item.toJSON());
                    return new ToolRegistry.Result(true, "找到 " + items.size() + " 个结果",
                            new JSONObject().put("items", arr).toString());
                } catch (Exception e) {
                    /* H1: 连接异常 → SOURCE_DOWN */
                    return new ToolRegistry.Result(false, "影视搜索失败: " + e.getMessage(),
                            null, null, ToolRegistry.Result.REASON_SOURCE_DOWN);
                }
            },
            "native", "readonly", "none", true, 5, "scene",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("query", "string", true, "剧名", "影视搜索词"),
            },
            "JSON: {\"items\":[...]}",
            new String[]{"漫长的季节"}, null, 5000,
            new ToolRegistry.Manifest("追剧搜索", "low", "多源搜索影视剧集", false, "io", "FAST", true, 5000),
            null));

        // ── video_sources: 视频源注册表 列表/开关 ──
        list.add(new ToolRegistry.Tool("video_sources", "视频源管理", null,
            a -> {
                if (appContext == null) return new ToolRegistry.Result(false, "context 未初始化");
                try {
                    VideoSourceRegistry reg = videoRegistry();
                    if (reg == null) return new ToolRegistry.Result(false, "context 未初始化");
                    String act = a.optString("action", "list");
                    if ("toggle".equals(act)) {
                        boolean done = reg.setEnabled(a.optString("id", ""), a.optBoolean("enabled", true));
                        return new ToolRegistry.Result(done, done ? "已切换" : "切换失败");
                    }
                    return new ToolRegistry.Result(true, "视频源列表", reg.listJson());
                } catch (Exception e) {
                    return new ToolRegistry.Result(false, "视频源操作失败: " + e.getMessage());
                }
            },
            "native", "readonly", "none", true, 5, "scene",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("action", "string", false, "list/toggle", "操作类型"),
                new ToolRegistry.ParamDef("id", "string", false, "源ID", "toggle 时必填"),
                new ToolRegistry.ParamDef("enabled", "boolean", false, "true/false", "toggle 目标状态"),
            },
            "JSON: {\"sources\":[...]}",
            new String[]{"列出视频源"}, null, 5000,
            new ToolRegistry.Manifest("视频源管理", "low", "查看/开关视频源", false, "io", "FAST", false, 5000),
            null));

        // ── web_sites: 已接入站点列表 ──
        list.add(new ToolRegistry.Tool("web_sites", "已接入站点列表", null,
            a -> {
                try {
                    JSONArray arr = new JSONArray();
                    arr.put(SiteCard.fromMayiSite().toJSON());
                    return new ToolRegistry.Result(true, "站点列表",
                            new JSONObject().put("sites", arr).toString());
                } catch (Exception e) {
                    return new ToolRegistry.Result(false, "站点列表失败: " + e.getMessage());
                }
            },
            "native", "readonly", "none", true, 3, "web",
            new ToolRegistry.ParamDef[]{},
            "JSON: {\"sites\":[...]}",
            new String[]{"有哪些已接入站点"}, null, 3000,
            new ToolRegistry.Manifest("站点列表", "low", "已接入的站点列表", false, "io", "FAST", false, 3000),
            null));

        // ── web_adapt: 站点适配引导（四段法，无真实请求） ──
        list.add(new ToolRegistry.Tool("web_adapt", "适配一个网站(引导)", null,
            a -> {
                String url = a.optString("url", "");
                if (url.isEmpty()) return new ToolRegistry.Result(false, "url 必填");
                try {
                    String domain = url.replace("https://", "").replace("www.", "").split("/")[0];
                    JSONObject result = new JSONObject()
                        .put("status", "C")
                        .put("site", domain)
                        .put("stage", "site-recon")
                        .put("antiCrawl", new JSONObject()
                            .put("check_signals", new JSONArray()
                                .put("acw_sc__v2").put("__cf_bm").put("_abck").put("geetest"))
                            .put("strategy", "浏览器上下文优先验证→确认fetch可行性→定后续路线"))
                        .put("next_stages", new JSONArray()
                            .put("api-discovery").put("field-decode").put("verify"))
                        .put("guidance", "四段法：①site-recon(反爬指纹检测)→②api-discovery(找数据endpoint)→③field-decode(字段解码)→④verify(实跑验证)");
                    return new ToolRegistry.Result(true, "站点适配引导", result.toString());
                } catch (Exception e) {
                    return new ToolRegistry.Result(false, "适配引导失败: " + e.getMessage());
                }
            },
            "native", "readonly", "none", true, 3, "web",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("url", "string", true, "https://...", "要适配的站点 URL"),
            },
            "JSON: {\"status\":\"C\",\"stage\":\"site-recon\",...}",
            new String[]{"适配 https://example.com"}, null, 3000,
            new ToolRegistry.Manifest("站点适配", "medium", "引导适配一个网站", false, "io", "FAST", false, 3000),
            null));

        // ── mayi_latest: 蚂蚁影视最新一集 ──
        list.add(new ToolRegistry.Tool("mayi_latest", "查追剧最新一集(蚂蚁影视)", null,
            a -> {
                String title = a.optString("title", "");
                if (title.isEmpty()) return new ToolRegistry.Result(false, "title 必填");
                try {
                    MayiSite site = new MayiSite();
                    List<MayiSite.Show> shows = site.search(title);
                    if (!shows.isEmpty()) {
                        MayiSite.Show s = shows.get(0);
                        int lep = site.latestEpisode(s.id);
                        MayiSite.PlayResult pr = site.playUrl(s.id, lep);
                        JSONObject data = new JSONObject()
                                .put("latestEp", lep)
                                .put("playUrl", pr.playUrl)
                                .put("showId", s.id)
                                .put("title", s.title);
                        return new ToolRegistry.Result(true, "最新到第 " + lep + " 集", data.toString());
                    }
                    return new ToolRegistry.Result(true, "未找到该剧",
                            new JSONObject().put("latestEp", 0).toString());
                } catch (Exception e) {
                    /* H1: 连接异常 → SOURCE_DOWN */
                    return new ToolRegistry.Result(false, "查询最新集失败: " + e.getMessage(),
                            null, null, ToolRegistry.Result.REASON_SOURCE_DOWN);
                }
            },
            "native", "readonly", "none", true, 10, "scene",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("title", "string", true, "剧名", "在追剧名"),
            },
            "JSON: {\"latestEp\":N,\"playUrl\":\"...\",\"title\":\"...\"}",
            new String[]{"漫长的季节最新一集"}, null, 10000,
            new ToolRegistry.Manifest("查最新集", "low", "查在追剧最新一集", false, "io", "FAST", true, 10000),
            null));

        // ── check_drama_updates: 更新雷达（读 watch_history.json） ──
        list.add(new ToolRegistry.Tool("check_drama_updates", "更新雷达(在追列表)", null,
            a -> {
                try {
                    if (appContext == null) return new ToolRegistry.Result(false, "context 未初始化");
                    File wh = new File(appContext.getFilesDir(), "watch_history.json");
                    JSONArray arr = new JSONArray();
                    if (wh.exists()) {
                        BufferedReader r = new BufferedReader(new InputStreamReader(
                                new FileInputStream(wh), "UTF-8"));
                        try {
                            StringBuilder sb = new StringBuilder();
                            String line;
                            while ((line = r.readLine()) != null) sb.append(line);
                            JSONObject root = new JSONObject(sb.toString());
                            java.util.Iterator<String> keys = root.keys();
                            while (keys.hasNext()) {
                                JSONObject entry = root.getJSONObject(keys.next());
                                if (entry.optInt("episode", 0) > 0 && entry.has("url")) {
                                    arr.put(new JSONObject()
                                            .put("title", entry.optString("title"))
                                            .put("episode", entry.optInt("episode"))
                                            .put("url", entry.optString("url", ""))
                                            .put("ts", entry.optLong("ts", 0)));
                                }
                            }
                        } finally {
                            r.close();
                        }
                    }
                    return new ToolRegistry.Result(true, "在追 " + arr.length() + " 部",
                            new JSONObject().put("watching", arr).toString());
                } catch (Exception e) {
                    return new ToolRegistry.Result(false, "更新雷达失败: " + e.getMessage());
                }
            },
            "native", "readonly", "none", true, 5, "scene",
            new ToolRegistry.ParamDef[]{},
            "JSON: {\"watching\":[...]}",
            new String[]{"我追的剧有更新吗"}, null, 5000,
            new ToolRegistry.Manifest("更新雷达", "low", "在追剧更新列表", false, "io", "FAST", false, 5000),
            null));

        return list;
    }
}
