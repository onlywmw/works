package com.hermes.android.scene;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 京东 H5 购物搜索（W3 SPIKE: m.jd.com curl 200 正向; 反爬程度/搜索 DOM 待真机验证）。
 * 照 MusicSource 结构：search → parseItems → Item 列表。解析用正则（内容结构型②），
 * 反爬/结构变化 → 诚实错误（京东支付最后一厘米交人，④ 红线）。
 */
public class ShopSource {

    private static final String SEARCH_URL = "https://so.m.jd.com/ware/search.action?keyword=%s";

    public static class Item {
        public final String name, price, url;
        Item(String name, String price, String url) {
            this.name = name; this.price = price; this.url = url;
        }
        public JSONObject toJSON() {
            JSONObject o = new JSONObject();
            try { o.put("name", name); o.put("price", price); o.put("url", url); } catch (Exception ignored) {}
            return o;
        }
    }

    /** 搜索京东商品（SPIKE 骨架：HTTP 抓取 + 正则解析；真机沉淀 DOM 后可调） */
    public List<Item> search(String keyword) throws Exception {
        String encoded = URLEncoder.encode(keyword, "UTF-8");
        URL url = new URL(SEARCH_URL.replace("%s", encoded));
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(6000); conn.setReadTimeout(6000);
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Mobile Safari/537.36");
        conn.setRequestProperty("Referer", "https://m.jd.com/");
        int code = conn.getResponseCode();
        if (code != 200) throw new Exception("jd search returned " + code);
        BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close(); conn.disconnect();
        List<Item> items = parseItems(sb.toString());
        if (items.isEmpty()) throw new Exception("京东搜索无结果或反爬拦截");
        return items;
    }

    /** 解析京东移动搜索页商品列表（正则, 内容结构型②；SPIKE 待真机沉淀精确选择器） */
    List<Item> parseItems(String html) {
        List<Item> items = new ArrayList<>();
        if (html == null || html.isEmpty()) return items;
        Pattern itemP = Pattern.compile("<div[^>]*class=\"[^\"]*item[^\"]*\"[^>]*>");
        Matcher m = itemP.matcher(html);
        Pattern nameP = Pattern.compile("pro-name[^>]*>([^<]{2,60})<");
        Pattern priceP = Pattern.compile("pro-price[^>]*>([^<]{1,20})<");
        Pattern urlP = Pattern.compile("href=\"(//item\\.jd\\.com/[^\"]+)\"");
        while (m.find() && items.size() < 6) {
            int end = html.indexOf("</div>", m.end());
            if (end < 0 || end - m.end() > 4000) continue;
            String block = html.substring(m.end(), end);
            String name = extract(nameP, block);
            if (name.isEmpty()) continue;
            items.add(new Item(name,
                    extract(priceP, block).isEmpty() ? "—" : extract(priceP, block),
                    extract(urlP, block)));
        }
        return items;
    }
    private static String extract(Pattern p, String s) {
        Matcher mm = p.matcher(s);
        if (mm.find()) return mm.group(1).trim().replaceAll("<[^>]+>", "").trim();
        return "";
    }
}
