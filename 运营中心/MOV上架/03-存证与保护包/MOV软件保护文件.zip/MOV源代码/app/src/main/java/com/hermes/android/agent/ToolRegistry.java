package com.hermes.android.agent;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Vibrator;
import android.provider.Settings;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;

/**
 * ToolRegistry — agent 的工具注册表 (agent 与硬件控制的分割层)。
 *
 * M1a 升级 (TOOL_ENV_UPGRADE.md Phase 1+2):
 * - Tool 类结构化: ParamDef/Manifest/CheckFn/toolset/examples/pitfalls
 * - ToolProvider 接口: 工具来源抽象 (builtin/mcp/plugin/remote)
 * - promptText() 重写: 按 toolset 分组 + check_fn 过滤 + 结构化文档
 *
 * AgentLoop 不认识任何具体工具: 拿动作名来查, 查到就执行。
 * - 工具 = 数据 (name/desc/handler), 加工具 = 注册一行, 循环零改动
 * - DevicePolicy = 唯一安全闸门: device.cmd 的风险分级(只读/动作/危险)
 *   + 硬件能力探测(无闪光灯/无马达/权限未批 → 对应能力一开始就不放行)
 * - 换手机 = 重新 probe 生成注册表, 可携带的 agent 核心(循环/文件/大脑)不变
 */
public class ToolRegistry {

    // Phase 8: 工具执行时的中断信号 (AgentLoop.execAction 设置, handler 读取)
    public static final ThreadLocal<InterruptSignal> currentSignal = new ThreadLocal<>();

    // ==================== 工具 ====================

    public interface Handler {
        Result run(JSONObject args) throws Exception;
    }

    /** 工具执行结果: ok/文本/产出文件路径(可空)/AI反馈 */
    public static class Result {
        // ==================== H1: 失败归因码 (DESIGN_TOOL_HEALTH §一) ====================
        /** 配置缺失（模型/key/权限未开） */
        public static final String REASON_NOT_CONFIGURED = "NOT_CONFIGURED";
        /** 源不可达（网络/站点挂/风控） */
        public static final String REASON_SOURCE_DOWN = "SOURCE_DOWN";
        /** 源结构变了，解析失效 */
        public static final String REASON_PARSE_DRIFT = "PARSE_DRIFT";
        /** 系统权限未授权 */
        public static final String REASON_PERMISSION_MISSING = "PERMISSION_MISSING";
        /** 环境损坏（rootfs/证书/二进制） */
        public static final String REASON_ENV_BROKEN = "ENV_BROKEN";
        /** 源/工具未在注册表 */
        public static final String REASON_NOT_REGISTERED = "NOT_REGISTERED";
        /** 其它（必须带原始错误摘要） */
        public static final String REASON_UNKNOWN = "UNKNOWN";

        public final boolean ok;
        public final String text;
        public final String produced;
        public final String aiFeedback;   // M1b: 给 AI 看的结构化反馈(截断+exit code+行数)
        public final String reason;       // H1: 失败归因码（成功 null）——「调用不了」升级为「可归因的话」

        public Result(boolean ok, String text) { this(ok, text, null, null, null); }
        public Result(boolean ok, String text, String produced) { this(ok, text, produced, null, null); }
        public Result(boolean ok, String text, String produced, String aiFeedback) {
            this(ok, text, produced, aiFeedback, null);
        }
        public Result(boolean ok, String text, String produced, String aiFeedback, String reason) {
            this.ok = ok; this.text = text; this.produced = produced;
            this.aiFeedback = aiFeedback; this.reason = reason;
        }

        /** H1: 复制本 Result 并设置 reason（失败归因；成功保持 null） */
        public Result withReason(String r) {
            return new Result(ok, text, produced, aiFeedback, r);
        }

        /** M1b: shell 专用构造 — 截断长输出 + exit code + 耗时 */
        public static Result shell(int exitCode, String stdout, String stderr,
                                    long elapsedMs, int maxChars) {
            boolean ok = exitCode == 0;
            boolean truncated = stdout.length() > maxChars;
            String body = truncated ? stdout.substring(stdout.length() - maxChars) : stdout;
            String feedback = "exit=" + exitCode + " | " + elapsedMs + "ms | stdout="
                + stdout.split("\n").length + "行"
                + (truncated ? " | 已截断(原" + stdout.length() + "字符)" : "");
            return new Result(ok,
                ok ? "命令完成" : "命令失败(exit=" + exitCode + ")",
                null,
                feedback + "\n" + (ok ? body : "STDERR: " + tailStr(stderr, 500)));
        }

        private static String tailStr(String s, int max) {
            if (s == null || s.isEmpty()) return "";
            return s.length() > max ? "…" + s.substring(s.length() - max) : s;
        }
    }

    /**
     * H1: 环境损坏探测（纯函数，shell.exec 用）——共享库/证书/段错误是明确的环境坏信号，
     * 不把「No such file」「command not found」这类普通命令错误误判为 ENV_BROKEN。
     */
    public static boolean isEnvBroken(String stderr) {
        if (stderr == null || stderr.isEmpty()) return false;
        String s = stderr.toLowerCase();
        return s.contains("cannot open shared object")
                || s.contains("certificate verify failed")
                || s.contains("segmentation fault")
                || s.contains("illegal instruction");
    }

    // ==================== M1a: 结构化参数定义 ====================

    /** 参数定义 (参考 Hermes JSON Schema + Dyad .describe()) */
    public static class ParamDef {
        public final String name;
        public final String type;        // "string" / "int" / "boolean"
        public final boolean required;
        public final String constraint;  // "相对路径" / "默认 120，最大 600"
        public final String description; // 给 AI 看的一句话说明

        public ParamDef(String name, String type, boolean required, String constraint, String description) {
            this.name = name; this.type = type; this.required = required;
            this.constraint = constraint; this.description = description;
        }
    }

    /** 三视角 Manifest (AI/用户/系统) + FUSION F2 注册表元数据 */
    public static class Manifest {
        public final String title;        // 用户看到的: "写入文件"
        public final String risk;         // "low" / "medium" / "high"
        public final String userDesc;     // 用户看得懂的话
        public final boolean rollbackable;
        public final String category;     // "io" / "exec" / "device" (权限路由用)
        public final String level;        // FUSION F2: "FAST"(场景卡) | "SLOW"(慢脑工具)，默认 SLOW
        public final boolean sync;        // FUSION F2: 网络 IO 禁同步桥
        public final int timeoutMs;       // FUSION F2: 工具超时(毫秒)，默认 30000
        public final String domain;       // 域记忆移植（工单8，DESIGN_MEM_DOMAIN_PORT §四）：目的域，null=未声明（Tool.effectiveDomain 兜底）

        /** 旧构造：默认 SLOW / 非同步 / 30s（兼容现有全部调用点） */
        public Manifest(String title, String risk, String userDesc, boolean rollbackable, String category) {
            this(title, risk, userDesc, rollbackable, category, "SLOW", false, 30000, null);
        }

        /** FUSION F2 完整构造：显式 level/sync/timeoutMs */
        public Manifest(String title, String risk, String userDesc, boolean rollbackable, String category,
                        String level, boolean sync, int timeoutMs) {
            this(title, risk, userDesc, rollbackable, category, level, sync, timeoutMs, null);
        }

        /** 工单8（DESIGN_MEM_DOMAIN_PORT §四）：+domain 目的域，null=未声明 */
        public Manifest(String title, String risk, String userDesc, boolean rollbackable, String category,
                        String level, boolean sync, int timeoutMs, String domain) {
            this.title = title; this.risk = risk; this.userDesc = userDesc;
            this.rollbackable = rollbackable; this.category = category;
            this.level = level; this.sync = sync; this.timeoutMs = timeoutMs;
            this.domain = domain;
        }
    }

    /** 动态可用性检查 (参考 Hermes check_fn) */
    @FunctionalInterface
    public interface CheckFn {
        /** 返回 null = 可用，返回字符串 = 不可用原因 */
        String check();
    }

    /** 结果校验 (TOOL_ENV_UPGRADE Phase 9) */
    @FunctionalInterface
    public interface Validator {
        ValidationResult validate(JSONObject args, Result result);
    }

    public static class ValidationResult {
        public final String hardFail;              // 非空=硬失败, 翻 ok=false
        public final java.util.List<String> warnings;  // 软警告, ok保持true
        public ValidationResult(String hf, java.util.List<String> w) { hardFail = hf; warnings = w; }
        public static ValidationResult pass() { return new ValidationResult(null, java.util.List.of()); }
        public static ValidationResult fail(String reason) { return new ValidationResult(reason, java.util.List.of()); }
        public static ValidationResult warn(String... w) { return new ValidationResult(null, java.util.List.of(w)); }
    }

    public static class Tool {
        // ═══ 已有字段，不动 ═══
        public final String name;
        public final String desc;
        public final String[] keywords;
        public final Handler handler;
        public final String executor;      // native | linux | hermes
        public final String access;        // readonly | write
        public final String approval;      // none | plan | always
        public final boolean idempotent;
        public final int timeoutSec;

        // ═══ M1a 新增字段 ═══
        public final String toolset;       // "file" / "shell" / "device" / "system"
        public final ParamDef[] params;
        public final String returns;
        public final String[] examples;
        public final String[] pitfalls;
        public final int maxResultChars;
        public final Manifest manifest;
        public final CheckFn checkFn;      // null = 始终可用
        public final String domain;        // 域记忆移植（工单8，DESIGN_MEM_DOMAIN_PORT §四）：目的域，null=未声明（effectiveDomain 兜底）
        public Validator validator;  // null = 不校验(只读工具), setter 方式设置
        public java.util.function.Supplier<String> descOverride;  // Phase 6: 动态描述覆盖(环境注入)

        /** 完整构造 (M1a) */
        public Tool(String name, String desc, String[] keywords, Handler handler,
                    String executor, String access, String approval,
                    boolean idempotent, int timeoutSec,
                    String toolset, ParamDef[] params, String returns,
                    String[] examples, String[] pitfalls, int maxResultChars,
                    Manifest manifest, CheckFn checkFn) {
            this(name, desc, keywords, handler, executor, access, approval, idempotent, timeoutSec,
                 toolset, params, returns, examples, pitfalls, maxResultChars, manifest, checkFn, null);
        }

        /** 工单8（DESIGN_MEM_DOMAIN_PORT §四）：+domain 目的域，null=走 effectiveDomain() 兜底链 */
        public Tool(String name, String desc, String[] keywords, Handler handler,
                    String executor, String access, String approval,
                    boolean idempotent, int timeoutSec,
                    String toolset, ParamDef[] params, String returns,
                    String[] examples, String[] pitfalls, int maxResultChars,
                    Manifest manifest, CheckFn checkFn, String domain) {
            this.name = name; this.desc = desc; this.keywords = keywords; this.handler = handler;
            this.executor = executor; this.access = access; this.approval = approval;
            this.idempotent = idempotent; this.timeoutSec = timeoutSec;
            this.toolset = toolset; this.params = params; this.returns = returns;
            this.examples = examples; this.pitfalls = pitfalls; this.maxResultChars = maxResultChars;
            this.manifest = manifest; this.checkFn = checkFn; this.domain = domain;
        }

        /** 域记忆移植（工单8，DESIGN_MEM_DOMAIN_PORT §四拍板C）：目的域解析链 Tool.domain → Manifest.domain → toolset 推导 → other */
        public String effectiveDomain() {
            if (domain != null && !domain.isEmpty()) return domain;
            if (manifest != null && manifest.domain != null && !manifest.domain.isEmpty()) return manifest.domain;
            if (toolset != null && !toolset.isEmpty()) return toolset;
            return "other";
        }

        /** 兼容旧构造 (无 M1a 字段) */
        public Tool(String name, String desc, String[] keywords, Handler handler) {
            this(name, desc, keywords, handler, "native", "readonly", "none", true, 30,
                 null, null, null, null, null, 8000, null, null);
        }

        public Tool(String name, String desc, String[] keywords, Handler handler,
                    String executor, String access, String approval,
                    boolean idempotent, int timeoutSec) {
            this(name, desc, keywords, handler, executor, access, approval, idempotent, timeoutSec,
                 null, null, null, null, null, 8000, null, null);
        }

        /** 兼容旧代码：无关键词 */
        public Tool(String name, String desc, Handler handler,
                    String executor, String access, String approval,
                    boolean idempotent, int timeoutSec) {
            this(name, desc, null, handler, executor, access, approval, idempotent, timeoutSec);
        }
    }

    // ==================== M1a: ToolProvider 接口 ====================

    /** 工具来源抽象: 内置 / MCP / 插件 / 远程 */
    public interface ToolProvider {
        String id();
        List<Tool> discover();
    }

    // ==================== 设备策略 (唯一安全闸门) ====================

    public static class DevicePolicy {
        private static final Set<String> READONLY = new HashSet<>(Arrays.asList(
                "battery.status", "system.info", "network.info", "process.list",
                "volume.get", "brightness.get", "wifi.status", "clipboard.get"));
        private static final Set<String> ACTION = new HashSet<>(Arrays.asList(
                "torch.on", "torch.off", "volume.set", "brightness.set", "vibrate",
                "tts.speak", "notification.post", "app.launch", "clipboard.set", "location.get"));

        private final Set<String> unavailable;

        public DevicePolicy(Set<String> unavailable) {
            this.unavailable = unavailable;
        }

        public static DevicePolicy probe(Context ctx) {
            Set<String> un = new HashSet<>();
            boolean hasFlash = false;
            try {
                CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
                for (String id : cm.getCameraIdList()) {
                    Boolean b = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    if (b != null && b) { hasFlash = true; break; }
                }
            } catch (Exception ignored) {}
            if (!hasFlash) { un.add("torch.on"); un.add("torch.off"); }
            try {
                Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
                if (v == null || !v.hasVibrator()) un.add("vibrate");
            } catch (Exception e) { un.add("vibrate"); }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.System.canWrite(ctx)) {
                un.add("brightness.set");
            }
            if (ctx.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED
                    && ctx.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                un.add("location.get");
            }
            return new DevicePolicy(un);
        }

        public String check(String capability) {
            if (capability == null || capability.isEmpty()) return "无法解析指令";
            try {
                if (com.hermes.android.RulesManager.get().isCapabilityDisabled(capability))
                    return "管理员规则禁止该能力: " + capability;
                if (com.hermes.android.RulesManager.get().isCapabilityConfirmRequired(capability))
                    return "需要确认: " + capability;
            } catch (Exception ignored) {}
            if (unavailable.contains(capability)) return "此设备不支持该能力: " + capability;
            if (READONLY.contains(capability) || ACTION.contains(capability)) return null;
            return "循环内禁止该能力: " + capability;
        }

        /** 从自然语言指令提取能力名 (Phase 9 PermissionPolicy 用) */
        public static String capabilityOf(String text) {
            if (text == null || text.isEmpty()) return "unknown";
            String t = text.toLowerCase().trim();
            for (String kw : READONLY) if (t.contains(kw)) return kw;
            for (String kw : ACTION) if (t.contains(kw)) return kw;
            return "unknown";
        }

        public String promptText() {
            return "device.cmd{text} 控制手机(自然语言)。只读: " + READONLY
                    + "; 动作: " + ACTION
                    + (unavailable.isEmpty() ? "" : "; 本机不可用: " + unavailable)
                    + "; 其余一律禁止。";
        }
    }

    // ==================== 注册表 ====================

    private final Map<String, Tool> tools = new LinkedHashMap<>();
    private final DevicePolicy devicePolicy;
    private final List<ToolProvider> providers = new ArrayList<>();

    private ToolRegistry(DevicePolicy policy) {
        this.devicePolicy = policy;
    }

    private void register(Tool t) {
        tools.put(t.name, t);
    }

    /** 批2: 动态注册技能工具（技能激活时调用, 与静态 register 同闸）。默认 readonly（只读技能工具） */
    public void registerDynamicTool(String name, String desc, Handler handler) {
        registerDynamicTool(name, desc, handler, "readonly");
    }

    /** 批2: 动态注册技能工具（显式 access 级别）。
        验收修复 2026-08-05: wb.* 浏览器工具会操控真实浏览器（navigate/fill/evaluate），
        不得借兼容构造器混入 readonly——否则会被 MCP 只读服务（isReadonly 过滤）对外暴露 */
    public void registerDynamicTool(String name, String desc, Handler handler, String access) {
        register(new Tool(name, desc, null, handler, "native", access, "none", true, 30,
                null, null, null, null, null, 8000, null, null));
    }

    public void addProvider(ToolProvider p) { providers.add(p); }

    /** M1a: 从所有 provider 发现工具并注册 */
    public void buildFromProviders() {
        for (ToolProvider p : providers) {
            for (Tool t : p.discover()) {
                register(t);
            }
        }
    }

    public Tool find(String name) {
        return name == null ? null : tools.get(name);
    }

    /** FUSION F2: 全量工具遍历（快脑 tool_manifest 用） */
    public java.util.Collection<Tool> allTools() {
        return tools.values();
    }

    // ==================== M1a: check_fn 缓存 ====================

    private static class CachedCheck {
        final String result;      // null = 可用
        final long timestamp;
        CachedCheck(String result) { this.result = result; this.timestamp = System.currentTimeMillis(); }
    }
    private final Map<String, CachedCheck> checkCache = new LinkedHashMap<>();
    private static final long CHECK_TTL_MS = 30_000;

    /** 带缓存的可用性检查 (30s TTL) */
    private String checkWithCache(Tool t) {
        if (t.checkFn == null) return null;
        CachedCheck cached = checkCache.get(t.name);
        if (cached != null && System.currentTimeMillis() - cached.timestamp < CHECK_TTL_MS) {
            return cached.result;
        }
        String result;
        try { result = t.checkFn.check(); } catch (Exception e) { result = null; }
        checkCache.put(t.name, new CachedCheck(result));
        return result;
    }

    /** 公开可用性检查（供 ToolDescribe 等外部调用） */
    public String checkAvailability(Tool t) {
        if (t == null) return "工具不存在";
        return checkWithCache(t);
    }

    /** shell.exec 成功后调: 清缓存，下次重新探测 (apt install 后环境变了) */
    public void invalidateCheckCache() { checkCache.clear(); }

    // ==================== M1a: promptText 重写 ====================

    private static final Map<String, String> GROUP_LABELS = new LinkedHashMap<>();
    static {
        GROUP_LABELS.put("file", "文件操作");
        GROUP_LABELS.put("shell", "Shell 执行");
        GROUP_LABELS.put("device", "设备控制");
        GROUP_LABELS.put("system", "系统状态");
        GROUP_LABELS.put("meta", "元工具");
        GROUP_LABELS.put("vault", "保险柜");
        GROUP_LABELS.put("travel", "出行/票务");
        GROUP_LABELS.put("geo", "地图/位置");
        GROUP_LABELS.put("memory", "记忆");
        GROUP_LABELS.put("browser", "浏览器");
        GROUP_LABELS.put("web", "网页搜索");
        GROUP_LABELS.put("app", "应用管理");
        GROUP_LABELS.put("notification", "通知/提醒");
        GROUP_LABELS.put("message", "通信");
        GROUP_LABELS.put("media", "设备媒体");
        GROUP_LABELS.put("scene", "影视场景");
        GROUP_LABELS.put("ocr", "OCR");
        GROUP_LABELS.put("image", "图片生成");
        GROUP_LABELS.put("util", "工具/编码");
        GROUP_LABELS.put("model", "模型管理");
        GROUP_LABELS.put("todo", "待办/看板");
        GROUP_LABELS.put("email", "邮件");
        GROUP_LABELS.put("share", "分享");
        GROUP_LABELS.put("biz", "企业信息");
        GROUP_LABELS.put("mcp", "外部 MCP");
    }

    // ── 工具发现系统: 菜单 + tool.describe ──

    /** 灰度开关: true = 旧行为(全量注入), false = 新行为(菜单+点单) */
    private static final boolean FULL_TOOLS_MODE = false;

    /** 核心工具集: 这些工具始终在 prompt 中展示完整文档 */
    private static final Set<String> ESSENTIAL_TOOLS = new HashSet<>(Arrays.asList(
        "file.read", "file.write", "file.list", "file.delete", "file.rename",
        "search.replace",
        "shell.exec",
        "device.cmd",
        "app.package",
        "web.search", "web.fetch",
        "camera.capture",
        "location.get",
        "clipboard.read", "clipboard.write",
        "download.file",
        "notification.post",
        "search.chats", "read.chat",
        "model.list", "model.add", "model.set_default",
        "app.scaffold",
        /* W2: browser 协议核心工具进 ESSENTIAL (compact 模式也可见, LLM 知道 open→snapshot 链路) */
        "browser.open", "browser.snapshot", "browser.read", "browser.click", "browser.type",
        /* 因果记忆: 模型需看到 record/rule 完整参数才能正确调用（四元组+钩子注册是显式写入路径） */
        "causal.record", "causal.query", "causal.link", "causal.forget", "causal.rule",
        /* 工单20 打回④-1: hermes.task 进 ESSENTIAL——compact 模式非 ESSENTIAL 只剩菜单行，
           模型看不到 goal 参数 schema 只能空猜（真机探针 tool_call arg:"" 实证，causal 同款病） */
        "hermes.task",
        "tool.describe"
    ));

    /**
     * 按 toolset 分组输出工具文档。
     * 新行为(默认): 核心工具完整文档 + 菜单 + tool.describe 入口
     * 旧行为(FULL_TOOLS_MODE=true): 全量注入
     */
    public String promptText() {
        return promptText(null);
    }

    public String promptText(String filterToolset) {
        if (FULL_TOOLS_MODE) return fullPromptText(filterToolset);
        return compactPromptText(filterToolset);
    }

    /** FUSION F4: 意图分类器专用工具清单 — FAST 场景卡(直达)详细 + SLOW 工具(专家模式)名列表。
     *  快脑 LLM 分类看到能直达的服务才能正确分流；新工具注册一行，意图层零改动。 */
    public String intentPromptText() {
        StringBuilder sb = new StringBuilder("═══ 场景服务清单 ═══\n");
        sb.append("以下服务可直达（用户说一句即执行，无需专家模式）:\n");
        for (Tool t : tools.values()) {
            if (t.manifest != null && "FAST".equals(t.manifest.level)) {
                sb.append("- ").append(t.name).append(" (").append(t.toolset != null ? t.toolset : "?")
                  .append(")");
                if (t.examples != null && t.examples.length > 0) {
                    sb.append(" 例: ").append(t.examples[0]);
                }
                sb.append("\n");
            }
        }
        java.util.List<String> slowNames = new java.util.ArrayList<>();
        for (Tool t : tools.values()) {
            if (t.manifest == null || !"FAST".equals(t.manifest.level)) slowNames.add(t.name);
        }
        if (!slowNames.isEmpty()) {
            sb.append("专家模式(AgentLoop)可用工具: ").append(String.join(", ", slowNames)).append("\n");
        }
        return sb.toString();
    }

    /** 旧行为: 全量注入（灰度回退用） */
    private String fullPromptText(String filterToolset) {
        StringBuilder sb = new StringBuilder("═══ 可用工具 ═══\n");
        sb.append("调用格式: {\"action\":\"tool.execute\",\"name\":\"<工具名>\",\"args\":{...}}\n\n");
        Map<String, List<Tool>> groups = new LinkedHashMap<>();
        for (Tool t : tools.values()) {
            if (filterToolset != null && !filterToolset.equals(t.toolset)) continue;
            if (checkWithCache(t) != null) continue;
            String group = t.toolset != null ? t.toolset : "other";
            groups.computeIfAbsent(group, k -> new ArrayList<>()).add(t);
        }
        for (Map.Entry<String, List<Tool>> entry : groups.entrySet()) {
            String label = GROUP_LABELS.getOrDefault(entry.getKey(), entry.getKey());
            sb.append("── ").append(label).append(" ──\n");
            for (Tool t : entry.getValue()) appendToolDoc(sb, t);
        }
        sb.append(devicePolicy.promptText()).append("\n");
        sb.append("═══ 工具结束 ═══");
        return sb.toString();
    }

    /** 新行为: 核心工具完整文档 + 菜单 + tool.describe */
    private String compactPromptText(String filterToolset) {
        StringBuilder sb = new StringBuilder("═══ 可用工具 ═══\n");
        sb.append("调用格式: {\"action\":\"tool.execute\",\"name\":\"<工具名>\",\"args\":{...}}\n\n");

        // 收集可用工具，分核心/菜单
        Map<String, List<Tool>> essentialGroups = new LinkedHashMap<>();
        List<Tool> menuTools = new ArrayList<>();
        int hiddenCount = 0;

        for (Tool t : tools.values()) {
            if (filterToolset != null && !filterToolset.equals(t.toolset)) continue;
            if (checkWithCache(t) != null) continue;
            if (ESSENTIAL_TOOLS.contains(t.name)) {
                String g = t.toolset != null ? t.toolset : "other";
                essentialGroups.computeIfAbsent(g, k -> new ArrayList<>()).add(t);
            } else {
                menuTools.add(t);
                hiddenCount++;
            }
        }

        // 1) 核心工具完整文档
        for (Map.Entry<String, List<Tool>> entry : essentialGroups.entrySet()) {
            String label = GROUP_LABELS.getOrDefault(entry.getKey(), entry.getKey());
            sb.append("── ").append(label).append(" ──\n");
            for (Tool t : entry.getValue()) {
                // shell.exec 加约束提示
                if ("shell.exec".equals(t.name)) {
                    sb.append("## shell.exec\n");
                    sb.append(t.desc).append("\n");
                    sb.append("⚠ 优先级: 如果已有专门工具(file.delete/search.replace/download.file 等)，必须用专门工具。仅在无专门工具时使用 shell.exec。\n");
                    if (t.descOverride != null) {
                        try { String ov = t.descOverride.get(); if (ov != null && !ov.isEmpty()) sb.append("  当前: ").append(ov).append("\n"); }
                        catch (Exception ignored) {}
                    }
                    appendToolParams(sb, t);
                    if (t.returns != null) sb.append("返回: ").append(t.returns).append("\n");
                    if (t.examples != null && t.examples.length > 0) sb.append("示例: ").append(t.examples[0]).append("\n");
                    if (t.pitfalls != null && t.pitfalls.length > 0) sb.append("⚠ ").append(String.join(" | ", t.pitfalls)).append("\n");
                    sb.append("\n");
                } else {
                    appendToolDoc(sb, t);
                }
            }
        }

        // 2) tool.describe 入口（自举）
        sb.append("── 工具发现 ──\n");
        sb.append("## tool.describe\n");
        sb.append("获取指定工具的完整参数签名。从下方菜单选工具名，调用此工具获取详细用法。\n");
        sb.append("参数:\n");
        sb.append("  name (string, 必填) — 工具名，从下方菜单精确选取\n");
        sb.append("示例: {\"action\":\"tool.execute\",\"name\":\"tool.describe\",\"args\":{\"name\":\"search.replace\"}}\n\n");

        // 3) 菜单：非核心工具速查
        if (!menuTools.isEmpty()) {
            sb.append("── 可用工具速查 (").append(menuTools.size()).append(" 个) ──\n");
            Map<String, List<Tool>> menuGroups = new LinkedHashMap<>();
            for (Tool t : menuTools) {
                String g = t.toolset != null ? t.toolset : "other";
                menuGroups.computeIfAbsent(g, k -> new ArrayList<>()).add(t);
            }
            // shell.exec 如果不在核心列表中则在菜单底部加分隔
            for (Map.Entry<String, List<Tool>> entry : menuGroups.entrySet()) {
                String label = GROUP_LABELS.getOrDefault(entry.getKey(), entry.getKey());
                sb.append("  ").append(label).append(": ");
                List<String> items = new ArrayList<>();
                for (Tool t : entry.getValue()) {
                    String desc = t.desc;
                    if (desc.length() > 35) desc = desc.substring(0, 35) + "…";
                    items.add(t.name + " — " + desc);
                }
                // 每行最多 3 个工具
                for (int i = 0; i < items.size(); i++) {
                    if (i > 0) sb.append(" | ");
                    sb.append(items.get(i));
                    if ((i + 1) % 3 == 0 && i + 1 < items.size()) sb.append("\n    ");
                }
                sb.append("\n");
            }
        }

        // 4) 兜底提示
        if (hiddenCount > 0) {
            sb.append("\n").append(hiddenCount).append(" 个扩展工具可用 tool.describe(\"工具名\") 获取完整用法\n");
        }

        sb.append(devicePolicy.promptText()).append("\n");
        sb.append("═══ 工具结束 ═══");
        return sb.toString();
    }

    /** 抽取参数表渲染（shell.exec 约束提示时复用） */
    private void appendToolParams(StringBuilder sb, Tool t) {
        if (t.params != null && t.params.length > 0) {
            sb.append("参数:\n");
            for (ParamDef p : t.params) {
                sb.append("  ").append(p.name)
                  .append(" (").append(p.type)
                  .append(p.required ? ", 必填" : ", 选填");
                if (p.constraint != null && !p.constraint.isEmpty()) sb.append(", ").append(p.constraint);
                sb.append(") — ").append(p.description).append("\n");
            }
        }
    }

    private void appendToolDoc(StringBuilder sb, Tool t) {
        sb.append("## ").append(t.name).append("\n");
        sb.append(t.desc).append("\n");
        if (t.descOverride != null) {
            try { String ov = t.descOverride.get(); if (ov != null && !ov.isEmpty()) sb.append("  当前: ").append(ov).append("\n"); }
            catch (Exception ignored) {}
        }
        // 参数表
        if (t.params != null && t.params.length > 0) {
            sb.append("参数:\n");
            for (ParamDef p : t.params) {
                sb.append("  ").append(p.name)
                  .append(" (").append(p.type)
                  .append(p.required ? ", 必填" : ", 选填");
                if (p.constraint != null && !p.constraint.isEmpty()) sb.append(", ").append(p.constraint);
                sb.append(") — ").append(p.description).append("\n");
            }
        }
        // 返回值
        if (t.returns != null) sb.append("返回: ").append(t.returns).append("\n");
        // 示例（只给第一个，省 token）
        if (t.examples != null && t.examples.length > 0)
            sb.append("示例: ").append(t.examples[0]).append("\n");
        // 陷阱
        if (t.pitfalls != null && t.pitfalls.length > 0)
            sb.append("⚠ ").append(String.join(" | ", t.pitfalls)).append("\n");
        sb.append("\n");
    }

    // ==================== 组装 ====================

    public static ToolRegistry build(AgentLoop.Tools tools, String roomId,
                                     Supplier<Set<String>> allowedPaths, DevicePolicy policy) {
        return build(tools, roomId, allowedPaths, policy, false);
    }

    public static ToolRegistry build(AgentLoop.Tools tools, String roomId,
                                     Supplier<Set<String>> allowedPaths, DevicePolicy policy,
                                     boolean linuxAvailable) {
        ToolRegistry r = new ToolRegistry(policy);

        // ═══ file.list ═══
        r.register(new Tool("file.list", "列房间文件", null,
                a -> new Result(true, tools.fileList(roomId)),
                "native", "readonly", "none", true, 10,
                "file",
                new ParamDef[]{},
                "文件列表文本",
                new String[]{"{\"action\":\"tool.execute\",\"name\":\"file.list\",\"args\":{}}"},
                null, 4000,
                new Manifest("列出文件", "low", "查看房间里有哪些文件", true, "io"),
                null));

        // ═══ file.read ═══
        r.register(new Tool("file.read",
                "读房间文件 (分页: offset=起始字符默认0, length=本次长度默认32k, 单次上限32k;"
                + " 结果尾部写『用 offset=N 继续读』就再调一次传 offset=N, 写『文件读完』则禁止再读)",
                null, a -> {
            String res = tools.fileRead(roomId, a.optString("path"));
            if (res.startsWith("ERROR:")) return new Result(false, res);
            boolean baseCapped = res.endsWith("\n…(截断)");
            if (baseCapped) res = res.substring(0, res.length() - "\n…(截断)".length());
            int total = res.length();
            int offset = Math.max(0, a.optInt("offset", 0));
            int length = a.optInt("length", 32768);
            if (length <= 0 || length > 32768) length = 32768;
            if (offset >= total) {
                return new Result(false, "offset 越界: 文件共 " + total + " 字符, 全部内容已在你的工作日志里,"
                        + "禁止再读, 直接用已读内容完成修改" + (baseCapped ? " (文件超底层 100k 上限)" : ""));
            }
            int end = Math.min(total, offset + length);
            String out = res.substring(offset, end);
            if (end < total) out += "\n…(已读 " + offset + "-" + end + "/" + total + " 字符, 用 offset=" + end + " 继续读)";
            else if (baseCapped) out += "\n…(已达底层 100k 上限, 文件实际更大)";
            else out += "\n—(文件读完, 共 " + total + " 字符)";
            return new Result(true, out);
        }, "native", "readonly", "none", true, 30,
                "file",
                new ParamDef[]{
                    new ParamDef("path", "string", true, "相对路径", "要读取的文件路径"),
                    new ParamDef("offset", "int", false, "默认 0", "起始字符位置"),
                    new ParamDef("length", "int", false, "默认 32768，最大 32768", "本次读取长度"),
                },
                "文件内容 + 分页页脚",
                new String[]{"{\"action\":\"tool.execute\",\"name\":\"file.read\",\"args\":{\"path\":\"index.html\"}}"},
                new String[]{
                    "offset 越界会报错，看页脚提示的 offset 值继续读",
                    "文件读完（页脚写'文件读完'）后禁止再读，直接用已读内容",
                }, 32768,
                new Manifest("读取文件", "low", "查看文件内容", true, "io"),
                null));

        // ═══ file.write ═══
        r.register(new Tool("file.write", "写房间文件 (仅限已批准计划内路径)", null, a -> {
            String path = a.optString("path");
            try {
                if (com.hermes.android.RulesManager.get().isFilePathProtected(path))
                    return new Result(false, "受保护路径, 禁止写入: " + path);
            } catch (Exception ignored) {}
            if (!allowedPaths.get().contains(path)) {
                return new Result(false, "此文件不在批准计划内");
            }
            String res = tools.fileWrite(roomId, path, a.optString("content"));
            boolean ok = res.startsWith("OK:");
            return new Result(ok, ok ? path + " → " + a.optString("content").length() + " 字符已写入" : res,
                    ok ? path : null);
        }, "native", "write", "plan", true, 30,
                "file",
                new ParamDef[]{
                    new ParamDef("path", "string", true, "相对路径，相对 /room/",
                        "文件路径。只接受相对路径（如 index.html），绝对路径会被拒绝。"),
                    new ParamDef("content", "string", true, "不能为空",
                        "完整文件内容。不能是空字符串，不能是 diff/patch，必须是完整文件。"),
                },
                "成功: \"<path> → N 字符已写入\" | 失败: \"此文件不在批准计划内\" / \"受保护路径, 禁止写入\"",
                new String[]{"{\"action\":\"tool.execute\",\"name\":\"file.write\",\"args\":{\"path\":\"index.html\",\"content\":\"<!DOCTYPE html><html>...\"}}"},
                new String[]{
                    "path 写绝对路径（/room/index.html）会失败，只接受相对路径（index.html）",
                    "content 为空字符串会被拒绝",
                    "不在批准计划内的路径会被拒绝——先确认计划里有这个文件",
                    "不要写 diff 或 patch，必须写完整文件内容",
                }, 10000,
                new Manifest("写入文件", "medium", "会覆盖已有文件内容", true, "io"),
                null));
            r.find("file.write").validator = (args, result) -> {
                if (!result.ok) return ToolRegistry.ValidationResult.pass();
                String path = args.optString("path");
                String content = args.optString("content");
                String readBack = tools.fileRead(roomId, path);
                if (readBack == null || readBack.startsWith("ERROR:"))
                    return ToolRegistry.ValidationResult.fail("文件写入后不存在: " + path);
                long expected = content.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
                long actual = readBack.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
                if (Math.abs(actual - expected) > expected * 0.1 + 10)
                    return ToolRegistry.ValidationResult.warn("文件大小偏差: 期望" + expected + " 实际" + actual);
                return ToolRegistry.ValidationResult.pass();
            };

        // ═══ device.cmd ═══
        r.register(new Tool("device.cmd", "控制手机(自然语言, 分级放行)", null, a -> {
            String cap = tools.capabilityOf(a.optString("text"));
            String deny = policy.check(cap);
            if (deny != null) return new Result(false, deny);
            return new Result(true, tools.deviceCmd(a.optString("text")));
        }, "native", "write", "always", false, 15,
                "device",
                new ParamDef[]{
                    new ParamDef("text", "string", true, "", "自然语言设备指令，如\"打开手电筒\"、\"音量调到50%\""),
                },
                "执行结果文本",
                new String[]{"{\"action\":\"tool.execute\",\"name\":\"device.cmd\",\"args\":{\"text\":\"打开手电筒\"}}"},
                new String[]{
                    "只读指令（查电量/查网络）永远放行",
                    "动作指令（手电筒/音量/震动）需硬件支持才放行",
                    "电话/短信/联系人/截屏/触摸/全局文件一律禁止",
                }, 2000,
                new Manifest("控制设备", "high", "控制手机硬件（手电筒、音量等）", false, "device"),
                null));
            r.find("device.cmd").descOverride = () -> EnvironmentProbe.deviceSummary()
                + " | " + EnvironmentProbe.deviceInfo();

        // ═══ app.scaffold — 从模板创建项目骨架 ═══
        r.register(new Tool("app.scaffold",
            "从模板创建项目骨架。type=app(通用应用)/game(游戏)。自动生成完整 HTML 文件（含响应式+CSS变量+错误处理+localStorage），AI 只需填充业务逻辑",
            null, a -> {
                String type = a.optString("type", "app");
                String name = a.optString("name", "my-project");
                String title = a.optString("title", name);
                if (!"app".equals(type) && !"game".equals(type))
                    return new Result(false, "type 只能是 app 或 game");

                try {
                    String tmplName = type + ".html";
                    // 从 assets/templates/ 读取模板
                    java.io.InputStream is = appContext().getAssets().open("templates/" + tmplName);
                    String template = readStream(is);
                    is.close();
                    // 替换占位符
                    String key = name.replaceAll("[^a-zA-Z0-9]", "_").toLowerCase();
                    String scaffold = template
                        .replace("{{APP_NAME}}", title)
                        .replace("{{APP_TITLE}}", title)
                        .replace("{{APP_BODY}}", "<!-- TODO: AI fills content here -->")
                        .replace("{{APP_FOOTER}}", "")
                        .replace("{{APP_STYLES}}", "/* TODO: AI adds custom styles here */")
                        .replace("{{APP_SCRIPT}}", "// TODO: AI adds custom logic here")
                        .replace("{{GAME_NAME}}", title)
                        .replace("{{GAME_KEY}}", key)
                        .replace("{{GAME_STYLES}}", "/* TODO: AI adds game styles */")
                        .replace("{{GAME_INIT}}", "// TODO: AI adds init logic")
                        .replace("{{GAME_LOOP}}", "// TODO: AI adds render loop")
                        .replace("{{GAME_SCRIPT}}", "// TODO: AI adds game logic");
                    // 写入房间文件
                    String mainFile = name + ".html";
                    // 同时写入 SDK 文件
                    java.io.InputStream sdk = appContext().getAssets().open("templates/mov-sdk.js");
                    String sdkJs = readStream(sdk); sdk.close();
                    tools.fileWrite(roomId, "mov-sdk.js", sdkJs);

                    String res = tools.fileWrite(roomId, mainFile, scaffold);
                    if (res.startsWith("OK:"))
                        return new Result(true, "项目骨架已创建: " + mainFile + " + mov-sdk.js (模板: " + type + ")\n\n"
                            + "模板已包含: 响应式布局 + CSS变量 + 错误处理 + localStorage + MOV SDK(设备/文件/Shell/AI/通知)\n"
                            + "SDK 用法: MOV.device.torch.on() / MOV.file.write('x', data) / MOV.shell.exec('cmd') / MOV.ai.chat('text') / MOV.storage.set('k',v)\n"
                            + "你需要做: file.read " + mainFile + " → 在 TODO 标记处填充业务内容 → app.package " + mainFile,
                            mainFile);
                    return new Result(false, res);
                } catch (java.io.FileNotFoundException e) {
                    return new Result(false, "模板不存在: templates/" + type + ".html");
                } catch (Exception e) {
                    return new Result(false, "创建失败: " + e.getMessage());
                }
            }, "native", "write", "none", true, 5,
            "system",
            new ParamDef[]{
                new ParamDef("type", "string", true, "app/game", "app=通用应用 / game=游戏"),
                new ParamDef("name", "string", true, "", "项目名（生成 <name>.html）"),
                new ParamDef("title", "string", false, "默认=name", "应用标题"),
            },
            "成功: 项目骨架已创建 + 文件名 | 失败: 错误原因",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"app.scaffold\",\"args\":{\"type\":\"game\",\"name\":\"snake\",\"title\":\"贪吃蛇\"}}"},
            new String[]{"模板已含响应式/CSS变量/错误处理/localStorage，AI只需填业务", "创建后用 file.read 打开文件，在 TODO 处填充内容", "完成后用 app.package 打包"},
            2000,
            new Manifest("项目模板", "low", "从模板创建项目脚手架", false, "meta"),
            null));

        // ═══ app.package ═══
        r.register(new Tool("app.package",
                "多文件项目打包成签名 APK。支持 HTML+CSS+JS 分离文件, 打包时自动内联所有相对引用。"
                + "只需传入口 HTML 路径, 引用的 .css/.js/图片自动合并。",
                null, a -> {
            String path = a.optString("path");
            if (!path.toLowerCase().endsWith(".html") && !path.toLowerCase().endsWith(".htm")) {
                return new Result(false, "app.package 只支持 HTML 入口文件");
            }
            // 多文件支持: 读取 HTML → 内联所有本地引用 → 写临时文件 → 打包
            String inlinedPath = path;
            try {
                String html = tools.fileRead(roomId, path);
                if (html.startsWith("ERROR:")) {
                    return new Result(false, "读取入口文件失败: " + html);
                }
                int inlinedCount = 0;
                // 匹配 <link href="xxx.css"> → 读文件内容 → 替换为 <style>...</style>
                java.util.regex.Matcher cssM = java.util.regex.Pattern.compile(
                    "<link[^>]*href=\"([^\"]+\\.css)\"[^>]*>",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
                StringBuilder sb = new StringBuilder();
                while (cssM.find()) {
                    String cssFile = cssM.group(1);
                    if (cssFile.startsWith("http")) { cssM.appendReplacement(sb, cssM.group()); continue; }
                    String cssContent = tools.fileRead(roomId, cssFile);
                    if (!cssContent.startsWith("ERROR:")) {
                        cssM.appendReplacement(sb, "<style>" + cssContent + "</style>");
                        inlinedCount++;
                    } else { cssM.appendReplacement(sb, cssM.group()); }
                }
                cssM.appendTail(sb);
                html = sb.toString();
                // 匹配 <script src="xxx.js"> → 替换为 <script>...</script>
                java.util.regex.Matcher jsM = java.util.regex.Pattern.compile(
                    "<script[^>]*src=\"([^\"]+\\.js)\"[^>]*>\\s*</script>",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
                sb = new StringBuilder();
                while (jsM.find()) {
                    String jsFile = jsM.group(1);
                    if (jsFile.startsWith("http")) { jsM.appendReplacement(sb, jsM.group()); continue; }
                    String jsContent = tools.fileRead(roomId, jsFile);
                    if (!jsContent.startsWith("ERROR:")) {
                        jsM.appendReplacement(sb, "<script>" + jsContent + "</script>");
                        inlinedCount++;
                    } else { jsM.appendReplacement(sb, jsM.group()); }
                }
                jsM.appendTail(sb);
                html = sb.toString();
                // 匹配 url(xxx.png/xxx.jpg) → 转为 base64 data URI
                java.util.regex.Matcher imgM = java.util.regex.Pattern.compile(
                    "url\\(['\"]?([^'\"()]+\\.(?:png|jpg|jpeg|gif|svg|ico|webp))['\"]?\\)",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
                sb = new StringBuilder();
                while (imgM.find()) {
                    String imgFile = imgM.group(1);
                    if (imgFile.startsWith("http") || imgFile.startsWith("data:")) { imgM.appendReplacement(sb, imgM.group()); continue; }
                    try {
                        String b64 = java.util.Base64.getEncoder().encodeToString(
                            java.nio.file.Files.readAllBytes(
                                new java.io.File(inlineDir(roomId), imgFile).toPath()));
                        String ext = imgFile.substring(imgFile.lastIndexOf('.') + 1).toLowerCase();
                        String mime = ext.equals("svg") ? "image/svg+xml" : "image/" + ext;
                        imgM.appendReplacement(sb, "url(data:" + mime + ";base64," + b64 + ")");
                        inlinedCount++;
                    } catch (Exception e) { imgM.appendReplacement(sb, imgM.group()); }
                }
                imgM.appendTail(sb);
                html = sb.toString();
                if (inlinedCount > 0) {
                    java.io.File tmpFile = new java.io.File(inlineDir(roomId), "index_inlined.html");
                    java.nio.file.Files.write(tmpFile.toPath(), html.getBytes("UTF-8"));
                    inlinedPath = tmpFile.getAbsolutePath();
                }
            } catch (Exception e) {
                // 内联失败时用原路径继续, 打包器会报友好错误
            }
            // 打包前品质校验
            String htmlContent = inlinedPath.equals(path) ? "" : "";
            try {
                java.io.File f = new java.io.File(inlineDir(roomId), inlinedPath.equals(path) ? path : "index_inlined.html");
                if (!f.exists()) f = new java.io.File(new java.io.File(
                    appContext().getExternalFilesDir(null), "mov/rooms/" + roomId + "/files/work"), path);
                if (f.exists()) htmlContent = new String(java.nio.file.Files.readAllBytes(f.toPath()), "UTF-8");
            } catch (Exception ignored) {}
            if (!htmlContent.isEmpty()) {
                java.util.List<String> errors = new java.util.ArrayList<>();
                java.util.List<String> warns = new java.util.ArrayList<>();
                // Critical checks (block packaging)
                if (!htmlContent.toLowerCase().contains("viewport") || !htmlContent.contains("device-width"))
                    errors.add("Missing <meta viewport> - mobile display will be broken");
                if (htmlContent.contains("eval("))
                    errors.add("Uses eval() - security risk, forbidden");
                if (htmlContent.contains("catch(") && htmlContent.matches("(?s).*catch\\s*\\([^)]*\\)\\s*\\{\\s*\\}.*"))
                    errors.add("Empty catch block - errors silently swallowed");
                // Non-critical (warn only, don't block)
                if (htmlContent.contains("font-size:10px") || htmlContent.contains("font-size:11px"))
                    warns.add("Font < 12px, suggest 14px+ for touch targets");
                if (!htmlContent.contains("--") && (htmlContent.contains("<style>") || htmlContent.contains("style>")))
                    warns.add("No CSS variables found, suggest using --bg/--primary/--text");

                if (!errors.isEmpty()) {
                    StringBuilder sb = new StringBuilder("Quality check failed:\n");
                    for (String e : errors) { sb.append("  FAIL: ").append(e).append("\n"); }
                    if (!warns.isEmpty()) {
                        sb.append("Suggestions:\n");
                        for (String w : warns) { sb.append("  WARN: ").append(w).append("\n"); }
                    }
                    return new Result(false, sb.toString());
                }
            }
            String res = tools.packageApk(roomId, inlinedPath, a.optString("appName", ""));
            if (res.startsWith("{")) {
                try {
                    JSONObject o = new JSONObject(res);
                    if (!o.optBoolean("ok")) {
                        return new Result(false, o.optString("error", "打包失败"));
                    }
                    String file = o.optString("file");
                    return new Result(true, o.optString("msg", file),
                            file.isEmpty() ? null : file);
                } catch (Exception ignored) {}
            }
            if (!res.startsWith("OK:")) return new Result(false, res);
            int sep = res.indexOf(" · ", 4);
            String produced = sep > 0 ? res.substring(4, sep) : res.substring(4);
            return new Result(true, res.substring(4), produced);
        }, "native", "write", "plan", false, 120,
                "system",
                new ParamDef[]{
                    new ParamDef("path", "string", true, "必须是 .html/.htm", "要打包的 HTML 文件路径"),
                    new ParamDef("appName", "string", false, "", "应用名称，默认用文件名"),
                },
                "成功: APK 路径 + 信息 | 失败: 错误原因",
                new String[]{"{\"action\":\"tool.execute\",\"name\":\"app.package\",\"args\":{\"path\":\"game.html\",\"appName\":\"贪吃蛇\"}}"},
                new String[]{
                    "支持多文件项目(HTML+CSS+JS+图片), 打包时自动内联",
                    "外部 CDN 引用(http://...) 不会被内联, 运行需网络",
                    "图片建议 < 500KB, 太大 APK 会膨胀",
                }, 2000,
                new Manifest("打包 APK", "medium", "把 HTML 打包成可安装的 APK", false, "io"),
                null));
            // Validator removed: packager validates its own output, relative path caused false negatives

        // ═══ shell.exec (内嵌 Linux 就绪才注册) ═══
        if (linuxAvailable) {
            final int shellMaxChars = 8000;
            r.register(new Tool("shell.exec",
                    "在内嵌 Ubuntu 24.04 里执行 shell 命令。当前工作目录 /room 与房间文件是同一批"
                    + "（file.write 写的这里直接可见可跑，shell 产物 file.read 直接可读，零搬运）。"
                    + "python3/git/node/jq/curl/gcc 齐全，可联网。",
                    null, a -> {
                String cmd = a.optString("cmd");
                if (cmd.isEmpty()) return new Result(false, "cmd 为空");
                int tSec = a.optInt("timeoutSec", 120);
                long t0 = System.currentTimeMillis();
                String res = tools.shellExec(cmd, tSec);
                long elapsed = System.currentTimeMillis() - t0;
                int exitCode = -1; String stdout = res, stderr = "";
                if (res.startsWith("exit=")) {
                    int nl = res.indexOf('\n');
                    try { exitCode = Integer.parseInt(res.substring(5, nl > 0 ? nl : res.length())); } catch(Exception ignored){}
                    stdout = nl > 0 ? res.substring(nl+1) : ""; stderr = "";
                }
                boolean ok = exitCode == 0;
                if (ok) r.invalidateCheckCache();
                Result shellRes = Result.shell(exitCode, stdout, stderr, elapsed, shellMaxChars);
                /* H1: 环境损坏 → ENV_BROKEN（共享库/证书/段错误——明确是环境坏，不误伤普通命令错误）
                   注意: shell.exec 的 exit=N 格式把输出合并进 stdout，stderr 解析恒空 */
                if (!ok && isEnvBroken(stdout)) {
                    shellRes = shellRes.withReason(Result.REASON_ENV_BROKEN);
                }
                return shellRes;
            }, "linux", "write", "plan", false, 600,
                    "shell",
                    new ParamDef[]{
                        new ParamDef("cmd", "string", true, "", "要执行的 shell 命令，支持 bash 语法"),
                        new ParamDef("timeoutSec", "int", false, "默认 120，最大 600",
                            "超时秒数。装包/编译/抓取等长任务必须给足"),
                    },
                    "成功: stdout 内容 | 失败: \"exit=N\" + stderr 摘要",
                    new String[]{"{\"action\":\"tool.execute\",\"name\":\"shell.exec\",\"args\":{\"cmd\":\"python3 build.py\",\"timeoutSec\":60}}"},
                    new String[]{
                        "大输出重定向到文件再 grep/tail 分段看，不要直接 cat 几万行",
                        "长构建 timeoutSec 给足（最大 600 秒），否则超时被杀",
                        "pip 装包用 --break-system-packages 或建 venv（Ubuntu 24 PEP 668）",
                    }, shellMaxChars,
                    new Manifest("执行命令", "high", "在 Linux 环境里执行命令，可能修改文件、安装软件、访问网络", false, "exec"),
                    () -> linuxAvailable ? null : "内嵌 Linux 未就绪"));
            r.find("shell.exec").descOverride = () -> "当前环境: " + EnvironmentProbe.linuxSummary();
            r.find("shell.exec").validator = (args, result) -> {
                if (!result.ok) return ToolRegistry.ValidationResult.pass();
                String stdout = result.aiFeedback != null ? result.aiFeedback : result.text;
                if (stdout != null && stdout.length() > 100) {
                    long printable = stdout.chars().filter(c -> (c >= 32 && c < 127) || c == '\n' || c == '\t' || c > 0x4E00).count();
                    if ((double) printable / stdout.length() < 0.8)
                        return ToolRegistry.ValidationResult.warn("输出疑似乱码（可打印字符 < 80%）");
                }
                return ToolRegistry.ValidationResult.pass();
            };

            // ═══ 工单20: hermes.task — 开放式子任务（Hermes 自主拆解/执行/纠错，产物回 /room）═══
            r.register(new Tool("hermes.task",
                    "开放式子任务——目标明确但步骤写不出的活。进内嵌 Linux 由 Hermes 自主完成，产物回房间 /room。"
                    + "与 shell.exec 是快慢搭档：确定小事用 shell.exec（零 LLM 开销），开放重活（数据分析/多文件项目/"
                    + "深度调研/需要自主决策的连续操作）用 hermes.task。产物经 file.read 直接可读。",
                    null, a -> {
                String goal = a.optString("goal");
                if (goal.isEmpty()) return new Result(false, "goal 为空");
                int tSec = a.optInt("timeoutSec", 600);
                String res = tools.hermesTask(goal, tSec);
                try {
                    org.json.JSONObject rj = new org.json.JSONObject(res);
                    boolean ok = rj.optBoolean("ok", false);
                    String output = rj.optString("output", rj.optString("error", ""));
                    String file = rj.optString("file", null);
                    if (ok && file != null) r.invalidateCheckCache();
                    return new Result(ok, output, null,
                            ok ? null : "hermes.task 执行失败",
                            ok ? null : ("hermes.task 执行失败: " + output));
                } catch (Exception e) {
                    return new Result(false, "hermes.task 回包解析失败: " + res, null,
                            null, "hermes.task 回包异常");
                }
            }, "linux", "write", "plan", false, 600,
                    "hermes",
                    new ParamDef[]{
                        new ParamDef("goal", "string", true, "", "开放式任务目标（步骤由 Hermes 自主决定）"),
                        new ParamDef("timeoutSec", "int", false, "默认 600，最大 600",
                            "超时秒数。大任务给足"),
                    },
                    "成功: JSON {ok:true, output, file?} | 失败: {ok:false, error}",
                    new String[]{"{\"action\":\"tool.execute\",\"name\":\"hermes.task\",\"args\":{\"goal\":\"把这份 CSV 清洗后出分析图\",\"timeoutSec\":600}}"},
                    new String[]{
                        "目标是结果不是步骤——拆解交给 Hermes，别写死操作序列",
                        "大输出产物会落房间 /room，用 file.read 读，不要指望 output 里带全量",
                    }, 60000,
                    new Manifest("开放式子任务", "high", "进内嵌 Linux 由 Hermes 自主执行，可能修改文件/联网", false, "exec"),
                    () -> linuxAvailable ? null : "内嵌 Linux 未就绪"));
        }

        // P0: MCP 动态工具（HTTP 网关连社区 MCP Server 生态）
        r.addProvider(new com.hermes.android.mcp.McpProvider());
        // P1: 本地系统工具（无权限 L1 级）
        r.addProvider(new com.hermes.android.toolprovider.SystemToolProvider());
        // P3: Hermes 源码移植工具（web.search/web.fetch/session.search/skill.list）
        r.addProvider(new com.hermes.android.toolprovider.HermesToolProvider());
        // P4: 补充工具（相机/定位/日历/联系人/应用管理/分享/蓝牙/WiFi）
        r.addProvider(new com.hermes.android.toolprovider.ExtraToolProvider());
        // P5: 通用工具（剪贴板/邮件/语音/下载/哈希/UUID/编码/QR）
        r.addProvider(new com.hermes.android.toolprovider.UtilityToolProvider());
        // P6: 补齐 Hermes 差距（截屏/WiFi状态开关/Toast/相机信息/传感器/短信/媒体播放/应用管理/设置）
        r.addProvider(new com.hermes.android.toolprovider.HermesGapProvider());
        // 工单10: UI 驱动三件套(ui.dump/tap/swipe/input, DANGEROUS 审批闸 + 红线黑名单)
        r.addProvider(new com.hermes.android.toolprovider.UiToolProvider());
        // P7: 文件操作增强（重命名/删除/复制/搜索替换）对标 Dyad file_ops
        r.addProvider(new com.hermes.android.toolprovider.FileOpsProvider());
        // P8: 对话记忆 + 日志 + 代码搜索 + AI 生图 对标 Dyad chat/search tools
        r.addProvider(new com.hermes.android.toolprovider.ChatMemoryProvider());
        // P9: 模型管理 (model.list/add/set_default) — AI agent 可直接管理模型
        r.addProvider(new com.hermes.android.toolprovider.ModelToolProvider());
        // FUSION F2: 快脑场景卡（train/music/drama/video源/站点/最新集/更新雷达）— 一表两脑
        r.addProvider(new com.hermes.android.scene.FastSceneProvider());
        // 12306 查票 8 工具（get-tickets 余票+票价 / 车站查询 / 中转 / 经停站）— 只读，8389 MCP 自动暴露
        r.addProvider(new com.hermes.android.scene.Ticket12306Provider());
        // 百度地图 10 工具（地理编码/POI/路线/天气/IP定位/路况）— 只读，需 AK（checkFn 未配置拦截）
        r.addProvider(new com.hermes.android.scene.BaiduMapProvider());
        // FUSION F3: 记忆读写（watch_history/drama_memory/face_history/face_mine）— 一表收编
        r.addProvider(new com.hermes.android.toolprovider.MemoryToolProvider());
        // 因果记忆（本地因果记忆编译器）: causal.record/query/link/forget/rule — 四元组+哈希+逻辑钩子
        r.addProvider(new com.hermes.android.toolprovider.CausalToolProvider());
        // W2: browser_* 分级收编（ConnectWeb 动作进统一注册表，DESIGN_PAYMENT_GATE §三）
        r.addProvider(new com.hermes.android.browser.BrowserToolProvider());
        // OCR 集成面: ocr 工具骨架（模型/llama-server 归 P4，此仅诚实卡 + checkFn）
        r.addProvider(new com.hermes.android.toolprovider.OcrToolProvider());
        // P5: 双副本保险柜工具（vault_lock/unlock=ACTION审批闸, vault_list=READONLY）
        r.addProvider(new com.hermes.android.vault.VaultToolProvider());
        // MCP 工厂首品种（REQ-20260807-001）: PocketBase 本地后端工具组 pb.*
        r.addProvider(new com.hermes.android.toolprovider.PbToolProvider());
        // feat/wxpay-applyment: 微信支付服务商进件三工具 wxpay.applyment.*（私钥在后端，DESIGN_WXPAY_APPLYMENT）
        r.addProvider(new com.hermes.android.toolprovider.PartnerToolProvider());
        r.buildFromProviders();

        // P9: 工具发现 — 菜单 + tool.describe（必须在 buildFromProviders 之后注册）
        r.registerToolDescribe();

        return r;
    }

    /** 注册 tool.describe 元工具（依赖 tools 已完整填充） */
    private void registerToolDescribe() {
        register(new Tool("tool.describe",
            "获取指定工具的完整参数签名。从上方菜单选工具名，调用此工具获取详细用法（params/returns/example/pitfalls）",
            null,
            com.hermes.android.agent.ToolDescribe.handler(this),
            "native", "readonly", "none", true, 3,
            "meta",
            new ParamDef[]{
                new ParamDef("name", "string", true, "",
                    "工具名，从上方菜单中精确选取（如 file.delete / search.replace / camera.capture）"),
            },
            "JSON: {name, desc, toolset, executor, access, approval, params:[{name,type,required,description}], returns, example, pitfalls}",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"tool.describe\",\"args\":{\"name\":\"search.replace\"}}"},
            new String[]{
                "必须传精确工具名（从菜单选），不支持模糊匹配",
                "工具名不存在会返回错误",
                "工具当前不可用(如Linux未就绪)也会返回错误",
            }, 3000,
            new Manifest("工具描述", "low", "查看工具详情", false, "meta"),
            null));  // checkFn=null 始终可用
    }

    /** 多文件打包临时目录 */
    private static java.io.File inlineDir(String roomId) {
        return new java.io.File(appContext().getFilesDir(), "rooms/" + roomId + "/.inline_tmp");
    }

    private static android.content.Context appContext() {
        return com.hermes.android.HermesApplication.getAppContext();
    }

    private static String readStream(java.io.InputStream is) throws java.io.IOException {
        java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
        byte[] b = new byte[4096]; int n;
        while ((n = is.read(b)) > 0) buf.write(b, 0, n);
        return new String(buf.toByteArray(), "UTF-8");
    }

    /** 测试用: 不探测硬件, 手工指定不可用集 */
    public static DevicePolicy policyForTest(Set<String> unavailable) {
        return new DevicePolicy(unavailable);
    }
}
