package com.hermes.android.workflow;

import org.json.JSONObject;

import java.util.regex.Pattern;

/**
 * 5 触发器判定（纯 JVM）：
 * pageload / interval / element_appear / text_match / url_change。
 * 事件 + workflow 状态（lastFireAt）判定命中。
 */
public class TriggerEvaluator {

    public static boolean matches(JSONObject trigger, WorkflowEvent event, Workflow wf, long now) {
        if (trigger == null || event == null) return false;
        String type = trigger.optString("type", "");
        switch (type) {
            case "pageload":
                return event.type == WorkflowEvent.Type.PAGE_LOAD;
            case "interval":
                return now - wf.lastFireAt >= trigger.optLong("intervalMs", 0);
            case "element_appear":
                return event.type == WorkflowEvent.Type.ELEMENT_APPEAR
                        && matchPattern(trigger.optString("selector", ""), event.selector,
                                trigger.optString("match", "exact"));
            case "text_match":
                return event.type == WorkflowEvent.Type.TEXT_MATCH
                        && matchPattern(trigger.optString("pattern", ""), event.text,
                                trigger.optString("match", "contains"));
            case "url_change":
                return event.type == WorkflowEvent.Type.URL_CHANGE
                        && matchPattern(trigger.optString("pattern", ""), event.url,
                                trigger.optString("match", "contains"));
            // 设备事件触发器族（第一幕）：事件类型精确命中；level 沿触发由 DeviceTriggerManager 检测
            case "screen_on": return event.type == WorkflowEvent.Type.SCREEN_ON;
            case "screen_off": return event.type == WorkflowEvent.Type.SCREEN_OFF;
            case "power_connected": return event.type == WorkflowEvent.Type.POWER_CONNECTED;
            case "power_disconnected": return event.type == WorkflowEvent.Type.POWER_DISCONNECTED;
            case "battery_below": return event.type == WorkflowEvent.Type.BATTERY_BELOW;
            case "battery_above": return event.type == WorkflowEvent.Type.BATTERY_ABOVE;
            case "headphones_plugged": return event.type == WorkflowEvent.Type.HEADPHONES_PLUGGED;
            case "headphones_unplugged": return event.type == WorkflowEvent.Type.HEADPHONES_UNPLUGGED;
            case "wifi_connected": return event.type == WorkflowEvent.Type.WIFI_CONNECTED;
            case "wifi_disconnected": return event.type == WorkflowEvent.Type.WIFI_DISCONNECTED;
            case "bt_connected": return event.type == WorkflowEvent.Type.BT_CONNECTED;
            case "bt_disconnected": return event.type == WorkflowEvent.Type.BT_DISCONNECTED;
            // 第二幕：time_cron（cron 匹配当前时间）/ manual（Run now）/ boot
            case "time_cron": return CronParser.matches(trigger.optString("cron", ""), now);
            case "manual": return event.type == WorkflowEvent.Type.MANUAL;
            case "boot_completed": return event.type == WorkflowEvent.Type.BOOT_COMPLETED;
            default:
                return false;
        }
    }

    /** pattern 匹配：mode = exact | contains | regex（默认 contains） */
    public static boolean matchPattern(String pattern, String target, String mode) {
        if (pattern == null || pattern.isEmpty()) return true;   // 空 pattern = 任意
        if (target == null) return false;
        String m = mode != null ? mode : "contains";
        if ("exact".equals(m)) return pattern.equals(target);
        if ("regex".equals(m)) {
            try { return Pattern.compile(pattern).matcher(target).find(); }
            catch (Exception e) { return false; }   // 非法 regex 视为不匹配（诚实降级）
        }
        return target.contains(pattern);
    }
}
