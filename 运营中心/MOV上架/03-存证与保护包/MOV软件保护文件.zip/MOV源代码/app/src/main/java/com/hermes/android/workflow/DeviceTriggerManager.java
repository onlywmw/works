package com.hermes.android.workflow;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.util.Log;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;


/**
 * 设备事件触发器族（第一幕）：按需注册 receiver，零启用零常驻。
 * 屏幕/电源/电池/耳机/wifi/bt → WorkflowEventSource.onDeviceEvent（wfExec 后台 fire，防 mainLooper 死锁）。
 * 电池阈值沿触发（跨阈一次，回摆不重复）+ 2s debounce（同类事件合并）。
 */
public class DeviceTriggerManager {

    private static final String TAG = "Workflow";
    private static final long DEBOUNCE_MS = 2000;

    private final Context app;
    private final WorkflowEventSource source;
    private final ExecutorService exec;
    private final Set<DeviceTriggerPlanner.Family> registered = new HashSet<>();
    private final Map<String, Long> debounce = new HashMap<>();
    private int prevBatteryLevel = -1;
    private final Set<Integer> belowThresholds = new HashSet<>();
    private final Set<Integer> aboveThresholds = new HashSet<>();

    public DeviceTriggerManager(Context app, WorkflowEventSource source, ExecutorService exec) {
        this.app = app;
        this.source = source;
        this.exec = exec;
    }

    /** 按启用 workflows 重新规划 receiver：需要的注册，不要的注销（diff） */
    public synchronized void resync(List<Workflow> enabled) {
        Set<DeviceTriggerPlanner.Family> need = DeviceTriggerPlanner.computeNeeded(enabled);
        // 更新电池阈值（battery_below/above 的 level 参数）
        belowThresholds.clear();
        aboveThresholds.clear();
        if (enabled != null) {
            for (Workflow w : enabled) {
                if (!w.enabled) continue;
                if ("battery_below".equals(w.triggerType())) {
                    int lv = w.trigger.optInt("level", 0);
                    if (lv > 0) belowThresholds.add(lv);
                } else if ("battery_above".equals(w.triggerType())) {
                    int lv = w.trigger.optInt("level", 0);
                    if (lv > 0) aboveThresholds.add(lv);
                }
            }
        }
        for (DeviceTriggerPlanner.Family f : need) {
            if (!registered.contains(f)) { register(f); registered.add(f); }
        }
        for (DeviceTriggerPlanner.Family f : new HashSet<>(registered)) {
            if (!need.contains(f)) { unregister(f); registered.remove(f); }
        }
    }

    private void fire(WorkflowEvent.Type type, long now) {
        String k = type.name();
        Long last = debounce.get(k);
        if (last != null && now - last < DEBOUNCE_MS) return;   // 2s 同类合并
        debounce.put(k, now);
        exec.submit(() -> source.onDeviceEvent(type, now));
    }

    private void register(DeviceTriggerPlanner.Family f) {
        try {
            switch (f) {
                case SCREEN: {
                    IntentFilter fl = new IntentFilter();
                    fl.addAction(Intent.ACTION_SCREEN_ON);
                    fl.addAction(Intent.ACTION_SCREEN_OFF);
                    app.registerReceiver(screenReceiver, fl);
                    break;
                }
                case POWER: {
                    IntentFilter fl = new IntentFilter();
                    fl.addAction(Intent.ACTION_POWER_CONNECTED);
                    fl.addAction(Intent.ACTION_POWER_DISCONNECTED);
                    app.registerReceiver(powerReceiver, fl);
                    break;
                }
                case BATTERY: {
                    app.registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                    break;
                }
                case HEADPHONES: {
                    app.registerReceiver(headphoneReceiver, new IntentFilter(Intent.ACTION_HEADSET_PLUG));
                    break;
                }
                case WIFI: {
                    ConnectivityManager cm = (ConnectivityManager) app.getSystemService(Context.CONNECTIVITY_SERVICE);
                    if (cm != null) {
                        NetworkRequest req = new NetworkRequest.Builder()
                                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build();
                        cm.registerNetworkCallback(req, wifiCb);
                    }
                    break;
                }
                case BT: {
                    IntentFilter fl = new IntentFilter();
                    fl.addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED);
                    fl.addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED);
                    app.registerReceiver(btReceiver, fl);
                    break;
                }
            }
            Log.i(TAG, "device family registered: " + f);
        } catch (Exception e) {
            Log.e(TAG, "register family " + f + " error", e);
        }
    }

    private void unregister(DeviceTriggerPlanner.Family f) {
        try {
            switch (f) {
                case SCREEN: app.unregisterReceiver(screenReceiver); break;
                case POWER: app.unregisterReceiver(powerReceiver); break;
                case BATTERY: app.unregisterReceiver(batteryReceiver); break;
                case HEADPHONES: app.unregisterReceiver(headphoneReceiver); break;
                case WIFI: {
                    ConnectivityManager cm = (ConnectivityManager) app.getSystemService(Context.CONNECTIVITY_SERVICE);
                    if (cm != null) cm.unregisterNetworkCallback(wifiCb);
                    break;
                }
                case BT: app.unregisterReceiver(btReceiver); break;
            }
            Log.i(TAG, "device family unregistered: " + f);
        } catch (Exception e) {
            Log.w(TAG, "unregister family " + f + " (已注销竞态忽略)");
        }
    }

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            long now = System.currentTimeMillis();
            if (Intent.ACTION_SCREEN_ON.equals(a)) fire(WorkflowEvent.Type.SCREEN_ON, now);
            else if (Intent.ACTION_SCREEN_OFF.equals(a)) fire(WorkflowEvent.Type.SCREEN_OFF, now);
        }
    };
    private final BroadcastReceiver powerReceiver = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            long now = System.currentTimeMillis();
            if (Intent.ACTION_POWER_CONNECTED.equals(a)) fire(WorkflowEvent.Type.POWER_CONNECTED, now);
            else if (Intent.ACTION_POWER_DISCONNECTED.equals(a)) fire(WorkflowEvent.Type.POWER_DISCONNECTED, now);
        }
    };
    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            int level = i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
            int scale = i.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100);
            if (level < 0) return;
            int pct = level * 100 / scale;
            long now = System.currentTimeMillis();
            if (prevBatteryLevel >= 0) {
                for (Integer t : belowThresholds) {
                    if (prevBatteryLevel > t && pct <= t) fire(WorkflowEvent.Type.BATTERY_BELOW, now);   // 过阈沿
                }
                for (Integer t : aboveThresholds) {
                    if (prevBatteryLevel < t && pct >= t) fire(WorkflowEvent.Type.BATTERY_ABOVE, now);
                }
            }
            prevBatteryLevel = pct;
        }
    };
    private final BroadcastReceiver headphoneReceiver = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            int state = i.getIntExtra("state", -1);
            long now = System.currentTimeMillis();
            if (state == 1) fire(WorkflowEvent.Type.HEADPHONES_PLUGGED, now);
            else if (state == 0) fire(WorkflowEvent.Type.HEADPHONES_UNPLUGGED, now);
        }
    };
    private final BroadcastReceiver btReceiver = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            long now = System.currentTimeMillis();
            if (android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED.equals(a)) fire(WorkflowEvent.Type.BT_CONNECTED, now);
            else if (android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(a)) fire(WorkflowEvent.Type.BT_DISCONNECTED, now);
        }
    };
    private final ConnectivityManager.NetworkCallback wifiCb = new ConnectivityManager.NetworkCallback() {
        public void onAvailable(Network n) { fire(WorkflowEvent.Type.WIFI_CONNECTED, System.currentTimeMillis()); }
        public void onLost(Network n) { fire(WorkflowEvent.Type.WIFI_DISCONNECTED, System.currentTimeMillis()); }
    };
}
