package com.hermes.android.toolprovider;

import com.hermes.android.agent.ToolRegistry;

/**
 * 工单10: UI 驱动三件套(ui.dump / ui.tap / ui.swipe / ui.input) — level=DANGEROUS
 * (Manifest risk=high + approval=plan 走审批闸)。红线黑名单经 RootShell.isDenied 工具层拦截。
 */
public class UiToolProvider implements ToolRegistry.ToolProvider {

    @Override public String id() { return "ui"; }

    private static ToolRegistry.Result denied() {
        return new ToolRegistry.Result(false, "PERMANENT_DENIED: 命中红线黑名单(支付/短信/通讯录/通话记录)");
    }

    @Override public java.util.List<ToolRegistry.Tool> discover() {
        java.util.List<ToolRegistry.Tool> list = new java.util.ArrayList<>();
        list.add(new ToolRegistry.Tool("ui.dump",
                "抓取当前界面控件树(uiautomator dump, 元素文本/坐标, 供 UI 操作定位)",
                null, a -> {
            if (RootShell.isDenied(a.optString("packageName", ""), a.optString("action", ""))) return denied();
            return new ToolRegistry.Result(true, "UI 控件树",
                    RootShell.exec("uiautomator dump /sdcard/mov_ui.xml >/dev/null 2>&1; cat /sdcard/mov_ui.xml",
                            a.optInt("timeoutSec", 30)));
        }, "native", "write", "plan", true, 15, "device",
            new ToolRegistry.ParamDef[]{},
            "XML 控件树(含 text/bounds)", null, null, 15000,
            new ToolRegistry.Manifest("UI 控件树", "high", "抓取界面控件树", false, "device",
                    "SLOW", false, 15000, "device"),
            null));

        list.add(new ToolRegistry.Tool("ui.tap",
                "点击屏幕坐标(可先 ui.dump 定位): input tap x y",
                null, a -> {
            if (RootShell.isDenied(a.optString("packageName", ""), a.optString("action", ""))) return denied();
            int x = a.optInt("x", -1), y = a.optInt("y", -1);
            if (x < 0 || y < 0) return new ToolRegistry.Result(false, "x/y 不能为空");
            return new ToolRegistry.Result(true, "已点击",
                    RootShell.exec("input tap " + x + " " + y, a.optInt("timeoutSec", 15)));
        }, "native", "write", "plan", true, 10, "device",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("x", "integer", true, "x 坐标", "横坐标"),
                new ToolRegistry.ParamDef("y", "integer", true, "y 坐标", "纵坐标"),
            },
            "exit=N\n<输出>", null, null, 10000,
            new ToolRegistry.Manifest("UI 点击", "high", "模拟点击屏幕坐标", false, "device",
                    "SLOW", false, 10000, "device"),
            null));

        list.add(new ToolRegistry.Tool("ui.swipe",
                "滑动屏幕: input swipe x1 y1 x2 y2 [duration]",
                null, a -> {
            if (RootShell.isDenied(a.optString("packageName", ""), a.optString("action", ""))) return denied();
            String cmd = "input swipe " + a.optInt("x1", 0) + " " + a.optInt("y1", 0) + " "
                    + a.optInt("x2", 0) + " " + a.optInt("y2", 0)
                    + (a.has("duration") ? " " + a.optInt("duration", 300) : "");
            return new ToolRegistry.Result(true, "已滑动", RootShell.exec(cmd, a.optInt("timeoutSec", 15)));
        }, "native", "write", "plan", true, 10, "device",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("x1", "integer", true, "起点 x", "起点横坐标"),
                new ToolRegistry.ParamDef("y1", "integer", true, "起点 y", "起点纵坐标"),
                new ToolRegistry.ParamDef("x2", "integer", true, "终点 x", "终点横坐标"),
                new ToolRegistry.ParamDef("y2", "integer", true, "终点 y", "终点纵坐标"),
            },
            "exit=N\n<输出>", null, null, 10000,
            new ToolRegistry.Manifest("UI 滑动", "high", "模拟滑动屏幕", false, "device",
                    "SLOW", false, 10000, "device"),
            null));

        list.add(new ToolRegistry.Tool("ui.input",
                "输入文本: input text '内容'(空格转 %s)",
                null, a -> {
            if (RootShell.isDenied(a.optString("packageName", ""), a.optString("action", ""))) return denied();
            String text = a.optString("text", "");
            if (text.isEmpty()) return new ToolRegistry.Result(false, "text 不能为空");
            return new ToolRegistry.Result(true, "已输入",
                    RootShell.exec("input text '" + text.replace(" ", "%s") + "'",
                            a.optInt("timeoutSec", 15)));
        }, "native", "write", "plan", true, 10, "device",
            new ToolRegistry.ParamDef[]{
                new ToolRegistry.ParamDef("text", "string", true, "输入文本", "要输入的文本"),
            },
            "exit=N\n<输出>", null, null, 10000,
            new ToolRegistry.Manifest("UI 输入", "high", "模拟键盘输入文本", false, "device",
                    "SLOW", false, 10000, "device"),
            null));

        return list;
    }
}
