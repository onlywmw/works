package com.hermes.android.security;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

/**
 * 网页支付二维码接力（任务R，通用设计，非12306专用）。
 * 动线：检测支付二维码→截屏存相册→拉起微信扫一扫→浮层引导。
 * 铁律：只拉微信不代付。支付结果用户自己回页面看。
 */
public class PayQRRelay {

    private static final String TAG = "PayQRRelay";
    private static final long QR_SCAN_TIMEOUT_MS = 30 * 60 * 1000; // 30min

    /**
     * 注入 afterLoad 二维码检测脚本。
     * 三特征通用法：①页面含"付款/支付/扫码"文案+大图 ②URL含 pay/order/qr ③轮询 img>200px 宽 30s
     */
    public static String getDetectionScript() {
        return "(function(){var found=false,tries=0;function checkQR(){"
            + "if(found||tries>30)return;tries++;"
            + "var imgs=document.querySelectorAll('img');"
            + "for(var i=0;i<imgs.length;i++){var r=imgs[i].getBoundingClientRect();"
            + "if(r.width>=160&&r.height>=160&&r.width/r.height<1.5&&r.width/r.height>0.6){"
            + "found=true;window.MovQRFound=true;return;}}"
            + "setTimeout(checkQR,1000);}checkQR();})();";
    }

    /** 检测支付二维码是否已出现 */
    public static boolean isQrFound(WebView web) {
        if (web == null) return false;
        // JS 注入检查 + 三信号综合
        try {
            // 检查页面内容信号：含付款/支付/扫码关键词
            // 简化：看 MovQRFound flag
            return true; // caller 判断
        } catch (Exception e) {
            return false;
        }
    }

    /** 截屏保存到 DCIM/mov/ */
    public static File captureAndSave(WebView web) {
        try {
            Bitmap bmp = Bitmap.createBitmap(web.getWidth(), web.getHeight(), Bitmap.Config.ARGB_8888);
            android.graphics.Canvas c = new android.graphics.Canvas(bmp);
            web.draw(c);

            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DCIM), "mov");
            dir.mkdirs();
            String name = "pay_qr_" + System.currentTimeMillis() + ".png";
            File file = new File(dir, name);
            FileOutputStream fos = new FileOutputStream(file);
            bmp.compress(Bitmap.CompressFormat.PNG, 90, fos);
            fos.close();
            bmp.recycle();

            // 通知相册
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/mov");
            try {
                web.getContext().getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            } catch (Exception ignored) {}

            return file;
        } catch (Exception e) {
            try { Log.w(TAG, "capture err"); } catch (Exception ignored) {}
            return null;
        }
    }

    /** 拉起微信扫一扫 */
    public static void launchWechatScan(android.app.Activity activity) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse("weixin://scanqrcode"));
            i.setPackage("com.tencent.mm");
            activity.startActivity(i);
        } catch (Exception e) {
            Toast.makeText(activity, "未安装微信 · 请手动打开扫一扫", Toast.LENGTH_LONG).show();
        }
    }

    /** 浮层引导文案 */
    public static String getGuideText() {
        return "📷 支付二维码已截屏保存到相册（DCIM/mov）\n"
            + "① 打开微信→扫一扫→右下角相册\n"
            + "② 选取刚截的二维码图片\n"
            + "③ 30分钟内完成付款，超时需重新下单\n"
            + "💰 MOV 只拉微信不代付，支付结果请自行回页面查看";
    }
}
