package com.hermes.android.scene;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 蚂蚁影视站点解析器（任务J，MCP 工具后端）。
 * 三个方法对应三个 MCP 工具，纯 HTTP+正则，不硬逆向加密。
 */
public class MayiParser {

    private static final String TAG = "MayiParser";
    private static final String BASE = "https://91mayitv.com";

    /** 搜索结果 */
    public static class Show {
        public final String id;      // /voddetail/xxx/
        public final String title;
        public final String cover;
        public final String info;    // 年份/地区/集数

        public Show(String id, String title, String cover, String info) {
            this.id = id; this.title = title; this.cover = cover; this.info = info;
        }
        public JSONObject toJSON() {
            JSONObject o = new JSONObject();
            try { o.put("id", id); o.put("title", title); o.put("cover", cover); o.put("info", info); } catch (Exception ignored) {}
            return o;
        }
    }

    /** 剧集 */
    public static class Episode {
        public final String text;    // "第1话" / "第12话"
        public final String url;     // /vodplay/xxx-1-1.html

        public Episode(String text, String url) { this.text = text; this.url = url; }
        public JSONObject toJSON() {
            JSONObject o = new JSONObject();
            try { o.put("text", text); o.put("url", url); } catch (Exception ignored) {}
            return o;
        }
    }

    /**
     * mayi_search(剧名) → [{id, title, cover, info}]
     * GET /vodsearch/-------------.html?wd=xxx
     */
    public static List<Show> search(String keyword) {
        List<Show> results = new ArrayList<>();
        try {
            String encoded = URLEncoder.encode(keyword, "UTF-8");
            // 验收人实测的搜索规格：查询词在路径里，不是 ?wd= 参数
            URL url = new URL(BASE + "/vodsearch/" + encoded + "-------------.html");
            String html = get(url.toString());
            if (html == null) return results;

            // 正则提取搜索结果
            Pattern card = Pattern.compile("<a[^>]*href=\"(/voddetail/[^\"]+)\"[^>]*>.*?"
                    + "<img[^>]*src=\"([^\"]+)\"[^>]*>.*?"
                    + "<span[^>]*class=\"[^\"]*title[^\"]*\"[^>]*>([^<]+)</span>.*?"
                    + "<span[^>]*class=\"[^\"]*info[^\"]*\"[^>]*>([^<]*)</span>",
                    Pattern.DOTALL);
            Matcher m = card.matcher(html);
            while (m.find() && results.size() < 20) {
                results.add(new Show(
                        m.group(1),
                        m.group(3).trim(),
                        m.group(2),
                        m.group(4) != null ? m.group(4).trim() : ""));
            }
            // 宽松正则兜底
            if (results.isEmpty()) {
                Pattern alt = Pattern.compile("<a[^>]*href=\"(/voddetail/[^\"]+)\"[^>]*>\\s*<span[^>]*>([^<]+)</span>",
                        Pattern.DOTALL);
                Matcher ma = alt.matcher(html);
                while (ma.find() && results.size() < 10) {
                    results.add(new Show(ma.group(1), ma.group(2).trim(), "", ""));
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "search failed: " + e.getMessage());
        }
        return results;
    }

    /**
     * mayi_episodes(showId) → [{text, url}]
     * GET /voddetail/xxx/
     */
    public static List<Episode> episodes(String showId) {
        List<Episode> results = new ArrayList<>();
        try {
            String html = get(BASE + showId);
            if (html == null) return results;

            // 提取播放列表链接: /vodplay/xxx-1-1.html 等
            Pattern ep = Pattern.compile("<a[^>]*href=\"(/vodplay/[^\"]+)\"[^>]*>([^<]*)</a>",
                    Pattern.DOTALL);
            Matcher m = ep.matcher(html);
            while (m.find()) {
                String url = m.group(1);
                String text = m.group(2).trim();
                if (text.isEmpty()) {
                    // 提取集数：xxx-1-1 → "第1话"
                    Pattern num = Pattern.compile("-(\\d+)-(\\d+)\\.html");
                    Matcher nm = num.matcher(url);
                    if (nm.find()) text = "第" + nm.group(1) + "话";
                }
                if (!text.isEmpty()) results.add(new Episode(text, url));
            }
        } catch (Exception e) {
            Log.w(TAG, "episodes failed: " + e.getMessage());
        }
        return results;
    }

    /**
     * mayi_play_url(playUrl) → {video_url, play_url}
     * 不硬逆向加密——用 ConnectWeb 承载播放页，JS 取 video.currentSrc。
     * 此处返回输入 url（调用方用 ConnectWeb 容器执行 JS 提取）。
     */
    public static JSONObject playUrl(String playUrl) {
        JSONObject r = new JSONObject();
        try {
            String fullUrl = playUrl.startsWith("http") ? playUrl : (BASE + playUrl);
            r.put("play_url", fullUrl);
            r.put("extract_method", "ConnectWeb JS: video.currentSrc");
            r.put("timeout_sec", 5);
        } catch (Exception ignored) {}
        return r;
    }

    // ==================== HTTP util ====================

    private static String get(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36");
            conn.setRequestProperty("Accept", "text/html");
            int code = conn.getResponseCode();
            if (code != 200) return null;

            BufferedReader r = new BufferedReader(new InputStreamReader(
                    conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            r.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
