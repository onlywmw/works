package com.hermes.android.agent;

import java.util.List;

/**
 * 语义召回重排器（方案 B，PLAN_SEMANTIC_RECALL_2026-08-09.md §五）。
 * Journal.search 子串命中不足时注入，对最近候选做语义重排。
 * 默认不注入（Journal.search 与现状逐字节一致）；端侧实现见 llama/SemanticReranker。
 */
public interface SearchReranker {

    /**
     * 给定搜索词与候选文本，返回候选下标重排顺序（高相似在前）。
     * 允许返回子集——被阈值过滤的候选下标不出现；子集内保持高相似在前。
     * 返回 null 表示不重排（Journal 保持原排序）。实现必须容错，任何异常返回 null。
     */
    List<Integer> rerank(String query, List<String> texts);
}
