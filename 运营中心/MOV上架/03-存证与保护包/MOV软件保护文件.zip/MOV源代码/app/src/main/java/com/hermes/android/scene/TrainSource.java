package com.hermes.android.scene;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 12306 火车票数据源（v1，OpenCLI 端点情报直接移植）。
 * 动线：init 铸会话 → station_name 解析电报码 → queryG 查车次 → 竖线串解析。
 */
public class TrainSource {

    private static final String TAG = "TrainSource";
    private static final String BASE = "https://kyfw.12306.cn";
    private static final String STATION_JS = BASE + "/otn/resources/js/framework/station_name.js";
    private static final String INIT_URL = BASE + "/otn/leftTicket/init";
    private static final String QUERY_URL = BASE + "/otn/leftTicket/queryG";

    private final String cookie;  // init 铸造的会话 cookie
    private Map<String, String> nameToCode; // 站名→电报码

    public static class Train {
        public final String trainNo, fromStation, toStation, departTime, arriveTime;
        public final String duration, seatType, price, remaining;

        Train(String trainNo, String from, String to, String depart, String arrive,
              String duration, String seatType, String remaining) {
            this.trainNo = trainNo; this.fromStation = from; this.toStation = to;
            this.departTime = depart; this.arriveTime = arrive;
            this.duration = duration; this.seatType = seatType;
            this.price = ""; this.remaining = remaining;
        }

        public JSONObject toJSON() {
            JSONObject o = new JSONObject();
            try {
                o.put("trainNo", trainNo); o.put("from", fromStation); o.put("to", toStation);
                o.put("depart", departTime); o.put("arrive", arriveTime);
                o.put("duration", duration); o.put("seatType", seatType);
                o.put("remaining", remaining); o.put("price", price);
            } catch (Exception ignored) {}
            return o;
        }
    }

    /** 测试用：注入车站表，跳过网络初始化 */
    TrainSource(Map<String,String> stationMap) {
        this.cookie = "";
        this.nameToCode = stationMap;
    }

    public TrainSource() throws Exception {
        // 1. 铸会话
        HttpURLConnection init = (HttpURLConnection) new URL(INIT_URL).openConnection();
        init.setConnectTimeout(5000); init.setReadTimeout(5000);
        init.setRequestProperty("User-Agent", "Mozilla/5.0");
        init.connect();
        StringBuilder ck = new StringBuilder();
        for (Map.Entry<String, List<String>> e : init.getHeaderFields().entrySet()) {
            if ("Set-Cookie".equalsIgnoreCase(e.getKey())) {
                for (String v : e.getValue()) {
                    String[] parts = v.split(";");
                    if (parts.length > 0) ck.append(parts[0]).append("; ");
                }
            }
        }
        this.cookie = ck.toString();
        init.disconnect();

        // 2. 加载站名→电报码
        this.nameToCode = loadStationMap();
    }

    /** 搜索车次 */
    public List<Train> search(String from, String to, String date) throws Exception {
        if (nameToCode == null) throw new Exception("station map not loaded");
        String fromCode = resolveCode(from);
        String toCode = resolveCode(to);
        if (fromCode == null || toCode == null) throw new Exception("unknown station: " + from + "/" + to);

        String queryUrl = QUERY_URL + "?leftTicketDTO.train_date=" + date
                + "&leftTicketDTO.from_station=" + fromCode
                + "&leftTicketDTO.to_station=" + toCode
                + "&purpose_codes=ADULT";

        HttpURLConnection conn = (HttpURLConnection) new URL(queryUrl).openConnection();
        conn.setConnectTimeout(8000); conn.setReadTimeout(8000);
        conn.setRequestProperty("User-Agent", "Mozilla/5.0");
        conn.setRequestProperty("Cookie", cookie);
        int code = conn.getResponseCode();
        if (code == 302) throw new Exception("cookie expired, re-init required");
        if (code != 200) throw new Exception("queryG returned " + code);

        BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        conn.disconnect();

        JSONObject resp = new JSONObject(sb.toString());
        JSONObject data = resp.optJSONObject("data");
        if (data == null) return new ArrayList<>();

        // 端点轮换：c_url 指示换端点
        String cUrl = data.optString("c_url", "");
        if (!cUrl.isEmpty()) {
            HttpURLConnection c = (HttpURLConnection) new URL(BASE + cUrl
                    + "?leftTicketDTO.train_date=" + date
                    + "&leftTicketDTO.from_station=" + fromCode
                    + "&leftTicketDTO.to_station=" + toCode
                    + "&purpose_codes=ADULT").openConnection();
            c.setConnectTimeout(8000); c.setReadTimeout(8000);
            c.setRequestProperty("Cookie", cookie);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            BufferedReader cr = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder csb = new StringBuilder();
            while ((line = cr.readLine()) != null) csb.append(line);
            cr.close(); c.disconnect();
            resp = new JSONObject(csb.toString());
            data = resp.optJSONObject("data");
            if (data == null) return new ArrayList<>();
        }

        // 解析 result 竖线串
        return parseResults(data.optJSONArray("result"), from, to, date);
    }

    List<Train> parseResults(JSONArray results, String from, String to, String date) {  // package-private for test
        List<Train> trains = new ArrayList<>();
        if (results == null) return trains;
        java.util.Map<String, String> seatMap = loadSeatMap();
        int limit = Math.min(results.length(), 6);
        for (int i = 0; i < limit; i++) {
            try {
                String raw = results.optString(i);
                // URL decode the pipe-delimited string
                String decoded = java.net.URLDecoder.decode(raw, "UTF-8");
                String[] parts = decoded.split("\\|");
                // 字段映射（OpenCLI trains.js）：[3]=车次 [6]=出发站码 [7]=到站码 [8]=发时 [9]=到时
                // [10]=历时 [26]=二等座余票(yp_info)
                String trainNo = idx(parts, 3);
                String depart = idx(parts, 8);
                String arrive = idx(parts, 9);
                String duration = idx(parts, 10);
                String remaining = "";
                // 解析 yp_info（各席别余票，按顺序排列）
                for (int j = 26; j < parts.length && j < 36; j++) {
                    String v = parts[j];
                    if (v != null && !v.isEmpty() && !"无".equals(v) && !"*".equals(v)) {
                        remaining = v + "张";
                        break;
                    }
                }
                if (remaining.isEmpty()) remaining = "有票";
                if (trainNo.isEmpty()) continue;
                trains.add(new Train(trainNo, from, to, depart, arrive, duration, "二等座", remaining));
            } catch (Exception ignored) {}
        }
        return trains;
    }

    // ══════ 站名解析 ══════

    private Map<String, String> loadStationMap() {
        Map<String, String> map = new HashMap<>();
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(STATION_JS).openConnection();
            c.setConnectTimeout(5000); c.setReadTimeout(5000);
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close(); c.disconnect();
            // 格式：@bjb|北京北|VAP|beijingbei|bjb|0|...
            String[] entries = sb.toString().split("@");
            for (String e : entries) {
                if (e.isEmpty()) continue;
                String[] parts = e.split("\\|");
                if (parts.length >= 3) {
                    map.put(parts[1], parts[2]); // 站名→电报码
                    // 别名映射
                    if (parts.length >= 4) map.put(parts[3], parts[2]);
                }
            }
        } catch (Exception ex) {
            try { Log.w(TAG, "station load err"); } catch (Exception ignored) {}
        }
        // TOP30 主站映射（城市名→主站电报码）
        map.put("北京", "BJP"); map.put("上海", "SHH"); map.put("广州", "GZQ");
        map.put("深圳", "SZQ"); map.put("杭州", "HZH"); map.put("南京", "NJH");
        map.put("成都", "CDW"); map.put("武汉", "WHN"); map.put("重庆", "CQW");
        map.put("西安", "XAY"); map.put("天津", "TJP"); map.put("长沙", "CSQ");
        map.put("郑州", "ZZF"); map.put("昆明", "KMM"); map.put("苏州", "SZH");
        return map;
    }

    String resolveCode(String name) {  // package-private for test
        if (nameToCode.containsKey(name)) return nameToCode.get(name);
        // 模糊匹配：站名包含城市名
        for (Map.Entry<String, String> e : nameToCode.entrySet()) {
            if (e.getKey().startsWith(name)) return e.getValue();
        }
        return null;
    }

    private Map<String, String> loadSeatMap() {
        Map<String, String> m = new HashMap<>();
        m.put("0", "商务座"); m.put("1", "一等座"); m.put("2", "二等座");
        m.put("3", "软卧"); m.put("4", "硬卧"); m.put("5", "硬座"); m.put("6", "无座");
        return m;
    }

    // ══════ 日期解析 ══════

    public static String parseDate(String text) {
        Calendar c = Calendar.getInstance();
        if (text.contains("明天")) { c.add(Calendar.DATE, 1); }
        else if (text.contains("后天")) { c.add(Calendar.DATE, 2); }
        else if (text.contains("大后天")) { c.add(Calendar.DATE, 3); }
        else {
            // 匹配 "X月X日" 或 "下周X"
            java.util.regex.Matcher md = java.util.regex.Pattern.compile("(\\d+)月(\\d+)日").matcher(text);
            if (md.find()) {
                c.set(Calendar.MONTH, Integer.parseInt(md.group(1)) - 1);
                c.set(Calendar.DATE, Integer.parseInt(md.group(2)));
            }
            java.util.regex.Matcher mw = java.util.regex.Pattern.compile("下周([一二三四五六日])").matcher(text);
            if (mw.find()) {
                int dow = "一二三四五六日".indexOf(mw.group(1));
                c.add(Calendar.DATE, (dow - c.get(Calendar.DAY_OF_WEEK) + 2 + 7) % 7);
                if (c.get(Calendar.DAY_OF_WEEK) - 1 <= dow) c.add(Calendar.DATE, 7);
            }
        }
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(c.getTime());
    }

    private static String idx(String[] arr, int i) {
        return (i < arr.length && arr[i] != null) ? arr[i] : "";
    }
}
