package com.hermes.android.bridge;

import com.hermes.android.HermesActivity;
import com.hermes.android.agent.AgentLoop;
import com.hermes.android.scene.DramaSource;
import com.hermes.android.agent.IntentEngine;
import com.hermes.android.ai.AiClient;
import com.hermes.android.ai.AiProviderConfig;
import com.hermes.android.ai.ContextWindow;
import com.hermes.android.model.ModelRegistry;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;

/**
 * AI Bridge — 异步对话 + Council + 配置查询
 */
public class BridgeAi extends BaseBridge {

    private final AiProviderConfig aiConfig;
    private final ModelRegistry modelRegistry;
    private final ExecutorService aiExecutor;
    // ARCH_DEBT #8: per-room chatHistory, 按 roomId 分桶防串上下文
    private final java.util.Map<String, java.util.List<AiClient.Message>> roomHistories = new java.util.concurrent.ConcurrentHashMap<>();
    private static final String GLOBAL_KEY = "__global__";
    /** 工单17: 首页对话固定房间（方案 b — 首页对话落 journal 房间，全局桶从它懒重建）。
     *  isValidId 允许字母数字混合 → "r_home" 合法；face_history 扫描跳过该房间（MemoryToolProvider）。 */
    private static final String HOME_ROOM_ID = "r_home";
    private final com.hermes.android.agent.Journal journal;
    private static final int MAX_HISTORY = 50;
    /** FUSION F2: 最近一次 agentStart 构建的工具注册表（快脑查表转发复用同一张表）。
     *  volatile：agentStart 在工作线程构建后写入，快脑 query 在 JS 桥线程读取。
     *  happens-before 依据：volatile store 先于后续 volatile load 可见（JLS §17.4.5），
     *  registry 内部（handler 等）在 store 之前完成初始化，load 线程必看到完整构建的表。 */
    private volatile com.hermes.android.agent.ToolRegistry registry;

    /** FUSION F2: 快脑查表转发用（可能为 null——agentStart 尚未跑过） */
    public com.hermes.android.agent.ToolRegistry getRegistry() { return registry; }

    private java.util.List<AiClient.Message> getHistory(String roomId) {
        String key = roomId != null ? roomId : GLOBAL_KEY;
        java.util.List<AiClient.Message> hist = roomHistories.computeIfAbsent(key,
                k -> java.util.Collections.synchronizedList(new java.util.ArrayList<>()));
        // BUG-4b: 首次访问房间桶时从 journal.jsonl 懒重建（防重入守卫）
        // 工单17: 全局桶（首页对话）也从固定首页房间 r_home 的 journal 懒重建（方案 b）
        String srcRoom = roomId != null ? roomId : HOME_ROOM_ID;
        if (hist.isEmpty() && !rebuilding.contains(srcRoom)) {
            rebuilding.add(srcRoom);
            try {
                rebuildFromJournal(srcRoom, hist);
            } finally {
                rebuilding.remove(srcRoom);
            }
        }
        return hist;
    }

    /** 工单17: 首页对话（全局桶）成功后持久化到 r_home journal——
     *  事件格式对齐 rebuildHistoryFromJournal 提取规则（user_input→user / deliver→assistant） */
    private void persistHomeChat(String userText, String replyText) {
        try {
            JSONObject u = new JSONObject()
                    .put("actor", "user")
                    .put("type", "user_input")
                    .put("taskId", JSONObject.NULL)
                    .put("payload", new JSONObject().put("text", userText));
            if (journal.append(HOME_ROOM_ID, u) < 0) return;
            JSONObject a = new JSONObject()
                    .put("actor", "assistant")
                    .put("type", "deliver")
                    .put("taskId", JSONObject.NULL)
                    .put("payload", new JSONObject().put("summary", replyText));
            journal.append(HOME_ROOM_ID, a);
        } catch (Exception e) {
            android.util.Log.w("BridgeAi", "persistHomeChat: " + e.getMessage());
        }
    }

    /** BUG-4b: 防重入守卫 — rebuildFromJournal 不再回调 getHistory，避免循环 */
    private final java.util.Set<String> rebuilding = java.util.Collections.synchronizedSet(new java.util.HashSet<>());

    /** BUG-4b: 从房间 journal.jsonl 懒重建内存历史桶（真实落盘路径） */
    private void rebuildFromJournal(String roomId, java.util.List<AiClient.Message> hist) {
        if (roomId == null || roomId.isEmpty()) return;
        try {
            java.io.File journalFile = new java.io.File(
                    activity.getStorageManager().getRoomsDir(), roomId + "/journal.jsonl");
            rebuildHistoryFromJournal(journalFile, hist, MAX_HISTORY);
        } catch (Exception e) {
            android.util.Log.w("BridgeAi", "rebuildFromJournal: " + e.getMessage());
        }
    }

    /**
     * BUG-4b: 从 journal.jsonl 提取对话事件重建历史桶。返回加载条数。
     * 提取规则：user_input(actor=user) → Message("user", payload.text)
     *          deliver               → Message("assistant", payload.summary)
     *          fail                  → Message("assistant", "(失败) " + payload.reason)
     * kernel 侧 user_input (actor≠user) 不取, 防 council 主持词等系统词污染
     * 静态方法，可独立单测（注入临时 journal 文件）。
     */
    static int rebuildHistoryFromJournal(java.io.File journalFile,
                                          java.util.List<AiClient.Message> hist,
                                          int maxHistory) {
        if (!journalFile.exists() || !journalFile.isFile()) return 0;

        java.util.Set<String> seen = new java.util.HashSet<>();
        for (AiClient.Message m : hist) {
            seen.add(m.role + "::" + m.content);
        }
        java.util.List<AiClient.Message> loaded = new java.util.ArrayList<>();
        try {
            String content = new String(java.nio.file.Files.readAllBytes(journalFile.toPath()),
                    java.nio.charset.StandardCharsets.UTF_8);
            for (String line : content.split("\n")) {
                line = line.trim();
                if (line.isEmpty()) continue;
                try {
                    org.json.JSONObject ev = new org.json.JSONObject(line);
                    String type = ev.optString("type", "");
                    String role = null;
                    String text = null;

                    if ("user_input".equals(type)) {
                        // 只取 actor=user 的 user_input; kernel 侧注入(council主持词等)不进桶
                        if (!"user".equals(ev.optString("actor", ""))) continue;
                        org.json.JSONObject payload = ev.optJSONObject("payload");
                        role = "user";
                        text = payload != null ? payload.optString("text", "") : "";
                    } else if ("deliver".equals(type)) {
                        org.json.JSONObject payload = ev.optJSONObject("payload");
                        role = "assistant";
                        text = payload != null ? payload.optString("summary", "") : "";
                    } else if ("fail".equals(type)) {
                        org.json.JSONObject payload = ev.optJSONObject("payload");
                        role = "assistant";
                        String reason = payload != null ? payload.optString("reason", "") : "";
                        text = "(失败) " + reason;
                    }

                    if (role != null && text != null && !text.isEmpty()) {
                        String key = role + "::" + text;
                        if (!seen.contains(key)) {
                            seen.add(key);
                            loaded.add(new AiClient.Message(role, text));
                        }
                    }
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        if (!loaded.isEmpty()) {
            hist.addAll(loaded);
            while (hist.size() > maxHistory * 2) hist.remove(0);
        }
        return loaded.size();
    }

    public BridgeAi(HermesActivity activity) {
        super(activity);
        this.aiConfig = activity.getAiConfig();
        this.modelRegistry = activity.getModelRegistry();
        this.aiExecutor = activity.getAiExecutor();
        this.journal = new com.hermes.android.agent.Journal(
                activity.getStorageManager().getRoomsDir());
    }

    public void aiChatAsync(String text, String callbackId) { aiChatAsync(text, callbackId, ""); }  // 兼容旧调用

    public void aiChatAsync(String text, String callbackId, String roomId) {
        if (text == null || text.trim().isEmpty()) {
            evalJs("window._hermesCb('" + callbackId + "',{\"ok\":false,\"content\":\"消息为空\"})");
            return;
        }
        if (text.length() > 4000) {
            evalJs("window._hermesCb('" + callbackId + "',{\"ok\":false,\"content\":\"消息过长\"})");
            return;
        }
        aiExecutor.execute(() -> {
            String resultJson;
            try {
                String rid = (roomId != null && !roomId.isEmpty()) ? roomId : null;
                if (!aiConfig.isAiEnabled()) {
                    resultJson = "{\"ok\":false,\"content\":\"AI 已关闭, 点右上角 ≡ 可启用。\"}";
                } else if (!aiConfig.isConfigured()) {
                    // BUGFIX: 旧 AiProviderConfig 无 key 时 fallback ModelRegistry 默认模型
                    com.hermes.android.model.ModelConfig dm = modelRegistry.getDefault();
                    if (dm != null && dm.apiKey != null && !dm.apiKey.isEmpty()) {
                        AiClient client = new AiClient(dm);
                        java.util.List<AiClient.Message> history;
                        synchronized (getHistory(rid)) {
                            history = new ArrayList<>(getHistory(rid));
                        }
                        List<AiClient.Message> trimmed = ContextWindow.trim(history);
                        AiClient.AiResponse resp = client.chat(text, trimmed);
                        if (resp.success) {
                            synchronized (getHistory(rid)) {
                                getHistory(rid).add(new AiClient.Message("user", text));
                                getHistory(rid).add(new AiClient.Message("assistant", resp.content));
                                while (getHistory(rid).size() > MAX_HISTORY * 2) getHistory(rid).remove(0);
                            }
                            if (rid == null) persistHomeChat(text, resp.content);   // 工单17: 首页对话落 r_home journal
                            activity.saveChatHistoryPublic();
                            resultJson = new JSONObject()
                                    .put("ok", true)
                                    .put("content", resp.content).toString();
                        } else {
                            resultJson = new JSONObject()
                                    .put("ok", false)
                                    .put("content", "AI 调用失败: " + resp.content).toString();
                        }
                    } else {
                        resultJson = "{\"ok\":false,\"content\":\"AI 尚未配置 API Key, 点右上角 ≡ 设置后即可畅聊。\"}";
                    }
                } else {
                    AiClient client = new AiClient(aiConfig);
                    java.util.List<AiClient.Message> history;
                    synchronized (getHistory(rid)) {
                        history = new ArrayList<>(getHistory(rid));
                    }
                    List<AiClient.Message> trimmed = ContextWindow.trim(history);
                    AiClient.AiResponse resp = client.chat(text, trimmed);
                    if (resp.success) {
                        synchronized (getHistory(rid)) {
                            getHistory(rid).add(new AiClient.Message("user", text));
                            getHistory(rid).add(new AiClient.Message("assistant", resp.content));
                            while (getHistory(rid).size() > MAX_HISTORY * 2) getHistory(rid).remove(0);
                        }
                        if (rid == null) persistHomeChat(text, resp.content);   // 工单17: 首页对话落 r_home journal
                        activity.saveChatHistoryPublic();
                        resultJson = new JSONObject()
                                .put("ok", true)
                                .put("content", resp.content).toString();
                    } else {
                        resultJson = new JSONObject()
                                .put("ok", false)
                                .put("content", "AI 调用失败: " + resp.content).toString();
                    }
                }
            } catch (Exception e) {
                try {
                    resultJson = new JSONObject()
                            .put("ok", false)
                            .put("content", "AI 调用异常: " + e.getMessage()).toString();
                } catch (Exception ex) {
                    resultJson = "{\"ok\":false,\"content\":\"AI 调用异常\"}";
                }
            }
            evalJs("window._hermesCb('" + callbackId + "'," + resultJson + ")");
        });
    }

    /** Phase 2A.2: 异步意图分类（照 aiChatAsync cbId 模式）。 */
    public void intentClassifyAsync(String text, String callbackId) {
        if (text == null || text.trim().isEmpty()) {
            evalJs("window._hermesCb('" + callbackId + "',{\"ok\":false,\"error\":{\"code\":\"EMPTY_TEXT\",\"msg\":\"text 为空\"}})");
            return;
        }
        aiExecutor.execute(() -> {
            String resultJson;
            try {
                IntentEngine engine = new IntentEngine(activity);
                com.hermes.android.agent.ToolRegistry reg = getRegistry();
                if (reg != null) engine.setToolRegistry(reg);   // FUSION F4: 意图 prompt 拼注册表工具清单
                IntentEngine.IntentResult r = engine.classify(text);
                resultJson = new JSONObject()
                        .put("ok", true)
                        .put("data", new JSONObject()
                                .put("intent", r.intent)
                                .put("type", r.type)
                                .put("domain", r.domain)
                                .put("slots", new JSONObject(r.slots))
                                .put("confidence", r.confidence))
                        .toString();
            } catch (Exception e) {
                try {
                    resultJson = new JSONObject()
                            .put("ok", false)
                            .put("error", new JSONObject()
                                    .put("code", "CLASSIFY_FAILED")
                                    .put("msg", e.getMessage()))
                            .toString();
                } catch (Exception ex) {
                    resultJson = "{\"ok\":false,\"error\":{\"code\":\"INTERNAL\",\"msg\":\"intent classify 异常\"}}";
                }
            }
            evalJs("window._hermesCb('" + callbackId + "'," + resultJson + ")");
        });
    }

    /** Phase 2C.2: 异步追剧搜索（照 aiChatAsync cbId 模式，aiExecutor 跑 DramaSource）。 */
    public void faceSearchDramaAsync(String query, String callbackId) {
        if (query == null || query.trim().isEmpty()) {
            evalJs("window._hermesCb('" + callbackId + "',{\"ok\":false,\"error\":{\"code\":\"EMPTY_QUERY\",\"msg\":\"query 为空\"}})");
            return;
        }
        aiExecutor.execute(() -> {
            String resultJson;
            try {
                JSONArray arr = new JSONArray();
                // 本地视频优先（有权限时）
                com.hermes.android.scene.LocalVideoLibrary localLib = new com.hermes.android.scene.LocalVideoLibrary(activity);
                if (localLib.hasPermission()) {
                    java.util.List<com.hermes.android.scene.LocalVideoLibrary.LocalVideo> locals = localLib.search(query);
                    for (com.hermes.android.scene.LocalVideoLibrary.LocalVideo lv : locals) {
                        arr.put(lv.toJSON());
                    }
                }
                DramaSource ds = new DramaSource();
                ds.setRegistry(new com.hermes.android.agent.VideoSourceRegistry(activity));
                java.util.List<DramaSource.DramaItem> items = ds.search(query);
                for (DramaSource.DramaItem item : items) arr.put(item.toJSON());
                resultJson = new JSONObject()
                        .put("ok", true)
                        .put("data", new JSONObject().put("items", arr))
                        .toString();
            } catch (Exception e) {
                try {
                    resultJson = new JSONObject()
                            .put("ok", false)
                            .put("error", new JSONObject()
                                    .put("code", "SEARCH_FAILED")
                                    .put("msg", e.getMessage()))
                            .toString();
                } catch (Exception ex) {
                    resultJson = "{\"ok\":false,\"error\":{\"code\":\"INTERNAL\",\"msg\":\"drama search 异常\"}}";
                }
            }
            evalJs("window._hermesCb('" + callbackId + "'," + resultJson + ")");
        });
    }

    /** DESIGN_NEW_ROOM v2: 单聊房按房间绑定模型对话 (modelId 空/失效 → 注册表默认模型) */
    public void aiChatWithModel(String text, String modelId, String callbackId) { aiChatWithModel(text, modelId, callbackId, ""); }

    public void aiChatWithModel(String text, String modelId, String callbackId, String roomId) {
        String rid = (roomId != null && !roomId.isEmpty()) ? roomId : null;
        if (text == null || text.trim().isEmpty()) {
            evalJs("window._hermesCb('" + callbackId + "',{\"ok\":false,\"content\":\"消息为空\"})");
            return;
        }
        if (text.length() > 4000) {
            evalJs("window._hermesCb('" + callbackId + "',{\"ok\":false,\"content\":\"消息过长\"})");
            return;
        }
        aiExecutor.execute(() -> {
            String resultJson;
            try {
                com.hermes.android.model.ModelConfig mc = null;
                if (modelId != null && !modelId.isEmpty()) mc = modelRegistry.get(modelId);
                if (mc == null) mc = modelRegistry.getDefault();
                if (mc == null) {
                    resultJson = "{\"ok\":false,\"content\":\"AI 尚未配置模型, 运行页添加后即可畅聊。\"}";
                } else {
                    AiClient client = new AiClient(mc);
                    java.util.List<AiClient.Message> history;
                    synchronized (getHistory(rid)) {
                        history = new ArrayList<>(getHistory(rid));
                    }
                    List<AiClient.Message> trimmed = ContextWindow.trim(history);
                    AiClient.AiResponse resp = client.chat(text, trimmed);
                    if (resp.success) {
                        synchronized (getHistory(rid)) {
                            getHistory(rid).add(new AiClient.Message("user", text));
                            getHistory(rid).add(new AiClient.Message("assistant", resp.content));
                            while (getHistory(rid).size() > MAX_HISTORY * 2) getHistory(rid).remove(0);
                        }
                        if (rid == null) persistHomeChat(text, resp.content);   // 工单17: 首页对话落 r_home journal
                        activity.saveChatHistoryPublic();
                        resultJson = new JSONObject()
                                .put("ok", true)
                                .put("content", resp.content).toString();
                    } else {
                        resultJson = new JSONObject()
                                .put("ok", false)
                                .put("content", "AI 调用失败: " + resp.content).toString();
                    }
                }
            } catch (Exception e) {
                try {
                    resultJson = new JSONObject()
                            .put("ok", false)
                            .put("content", "AI 调用异常: " + e.getMessage()).toString();
                } catch (Exception ex) {
                    resultJson = "{\"ok\":false,\"content\":\"AI 调用异常\"}";
                }
            }
            evalJs("window._hermesCb('" + callbackId + "'," + resultJson + ")");
        });
    }

    // ==================== AgentLoop (DESIGN_AGENT_LOOP v1) ====================

    /* ---- 流式回调通道 (CONTRACT_STREAMING): token 批量推 WebView (400ms 一批, 防抖) ---- */

    private static final java.util.concurrent.ScheduledExecutorService TOKEN_FLUSH_EXEC =
            java.util.concurrent.Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "mov-token-flush");
                t.setDaemon(true);
                return t;
            });

    private static com.hermes.android.ai.StreamWatchdog.Mode pickStreamMode(
            com.hermes.android.model.ModelConfig mc) {
        String model = mc.getEffectiveModel() != null ? mc.getEffectiveModel().toLowerCase() : "";
        String base = mc.getEffectiveBaseUrl() != null ? mc.getEffectiveBaseUrl().toLowerCase() : "";
        if (base.contains("127.0.0.1") || base.contains("localhost")
                || base.contains("192.168.") || base.contains("10.")) {
            return com.hermes.android.ai.StreamWatchdog.Mode.LOCAL;
        }
        if (model.contains("reason") || model.contains("r1") || model.contains("think")) {
            return com.hermes.android.ai.StreamWatchdog.Mode.REASONING;
        }
        return com.hermes.android.ai.StreamWatchdog.Mode.STREAM;
    }

    /* 当前在途的大脑 client (agentStop 时连标志带连接一起取消, TC-SSE-07) */
    private volatile AiClient currentBrainClient;

    /** token 批量回调: 400ms 刷一次, 流完冲底 (evalJsPublic → window._movToken) */
    private AiClient.TokenListener makeTokenFlusher(String loopId) {
        if (loopId.isEmpty()) return null;
        final StringBuilder buf = new StringBuilder();
        final java.util.concurrent.atomic.AtomicBoolean closed =
                new java.util.concurrent.atomic.AtomicBoolean(false);
        Runnable flush = () -> {
            String part;
            synchronized (buf) {
                if (buf.length() == 0) return;
                part = buf.toString();
                buf.setLength(0);
            }
            activity.evalJsPublic("window._movToken(" + org.json.JSONObject.quote(loopId)
                    + "," + org.json.JSONObject.quote(part) + ")");
        };
        final java.util.concurrent.ScheduledFuture<?> tick =
                TOKEN_FLUSH_EXEC.scheduleWithFixedDelay(flush, 400, 400,
                        java.util.concurrent.TimeUnit.MILLISECONDS);
        /* 流结束由 scheduleClose 触发 (AgentLoop 终止时统一收尾) */
        loopFlushCleanup.put(loopId, () -> {
            closed.set(true);
            tick.cancel(false);
            flush.run();
        });
        return delta -> {
            if (closed.get()) return;
            synchronized (buf) { buf.append(delta); }
        };
    }

    private final java.util.Map<String, Runnable> loopFlushCleanup =
            new java.util.concurrent.ConcurrentHashMap<>();

    /** AgentLoop 终止时冲底并清定时器 (防泄漏, 合同红线) */
    private void closeTokenFlusher(String loopId) {
        Runnable r = loopFlushCleanup.remove(loopId);
        if (r != null) r.run();
    }

    // ==================== AgentLoop (DESIGN_AGENT_LOOP v1) ====================

    /** 排队中的任务 (全局单 loop, 第二个任务内部排队) */
    private String queuedGoal, queuedRoomId, queuedModelIds, queuedCbId;

    /** 启动 agentic 循环; 有活跃 loop 时排队并提示。
     *  modelIdsJson: 房间 AI 成员 (2026-07-30 评审团移除后不再消费, 仅随排队任务透传) */
    /** 工单22 幕三: 自动抽取用的 Brain 通道（无对话历史、单次结构化调用，供 CausalExtractor） */
    public AgentLoop.Brain brainForExtract() {
        return (sysPrompt, userText) -> {
            try {
                com.hermes.android.model.ModelConfig mc = modelRegistry.getDefault();
                if (mc == null || mc.apiKey == null || mc.apiKey.isEmpty()) {
                    return new AiClient.AiResponse(false, "未配置默认模型");
                }
                AiClient client = new AiClient(mc, sysPrompt);
                return client.chat(userText, new java.util.ArrayList<>());
            } catch (Exception e) {
                return new AiClient.AiResponse(false, "抽取调用异常: " + e.getMessage());
            }
        };
    }

    public void agentStart(String goal, String roomId, String modelIdsJson, String callbackId) {
        if (goal == null || goal.trim().isEmpty()) {
            evalJs("window._hermesCb('" + callbackId + "',{\"ok\":false,\"error\":\"目标为空\"})");
            return;
        }
        AgentLoop.Brain brain = (sysPrompt, userText) -> {
            com.hermes.android.model.ModelConfig mc = modelRegistry.getDefault();
            if (mc == null) {
                return new AiClient.AiResponse(false, "未配置默认模型, 请在运行页添加");
            }
            /* 流式活性: SSE 打字机 (仅显示; agent 动作解析仍等完整响应, 行为不变) */
            AiClient client = new AiClient(mc, sysPrompt);
            currentBrainClient = client;
            AgentLoop cur = AgentLoop.current();
            String lid = cur != null ? cur.getLoopId() : "";
            AiClient.TokenListener tl = makeTokenFlusher(lid);
            try {
                /* 带上对话历史，按房间分桶 */
                java.util.List<AiClient.Message> history;
                synchronized (getHistory(cur != null ? cur.getRoomId() : null)) {
                    history = new ArrayList<>(getHistory(cur != null ? cur.getRoomId() : null));
                }
                List<AiClient.Message> trimmed = ContextWindow.trim(history);
                return client.chatStream(userText, trimmed, tl, pickStreamMode(mc));
            } finally {
                currentBrainClient = null;
            }
        };
        AgentLoop.Tools tools = new AgentLoop.Tools() {
            private final com.hermes.android.StorageManager sm = activity.getStorageManager();

            @Override
            public String fileList(String roomId) {
                return sm.listRoomFiles(roomId, "files/work");
            }

            @Override
            public String fileRead(String roomId, String path) {
                try {
                    JSONObject r = new JSONObject(sm.readFile(roomId, "files/work/" + path));
                    return r.optBoolean("ok") ? r.optString("content") : "ERROR: " + r.optString("error");
                } catch (Exception e) {
                    return "ERROR: " + e.getMessage();
                }
            }

            @Override
            public String fileWrite(String roomId, String path, String content) {
                try {
                    /* 走 saveWorkFile: 覆盖已存在文件前先快照 (与 JS 用户保存路径一致) */
                    JSONObject r = new JSONObject(sm.saveWorkFile(roomId, path, content, "AI"));
                    return r.optBoolean("ok") ? "OK: 已写入" : "ERR: " + r.optString("error");
                } catch (Exception e) {
                    return "ERR: " + e.getMessage();
                }
            }

            @Override
            public String capabilityOf(String text) {
                try {
                    com.hermes.android.capability.ParsedCommand cmd =
                            new com.hermes.android.capability.IntentParser().parse(text);
                    return cmd == null || cmd.isError() ? "" : cmd.getCapability();
                } catch (Exception e) {
                    return "";
                }
            }

            @Override
            public String deviceCmd(String text) {
                try {
                    com.hermes.android.capability.ParsedCommand cmd =
                            new com.hermes.android.capability.IntentParser().parse(text);
                    com.hermes.android.capability.CommandResult r =
                            activity.getCapabilityExecutor().execute(activity, cmd);
                    return r.getMessage();
                } catch (Exception e) {
                    return "执行失败: " + e.getMessage();
                }
            }

            @Override
            public String packageApk(String roomId, String path, String appName) {
                try {
                    com.hermes.android.packager.PackageBuilder.Result r =
                            com.hermes.android.packager.PackageBuilder.build(
                                    activity, sm, roomId, path, appName);
                    if (!r.ok) {
                        return new JSONObject().put("ok", false)
                                .put("error", r.error != null ? r.error : "打包失败").toString();
                    }
                    /* APK 落到房间产出目录, 文件列表可见; ".html" 纯扩展名 → 兜底命名 */
                    String base = new java.io.File(path).getName()
                            .replaceAll("\\.[^.]+$", "");
                    if (base.isEmpty()) base = "未命名应用";
                    String label = base + ".apk";
                    java.io.File workDir = new java.io.File(
                            sm.getRoomsDir(), roomId + "/files/work");
                    workDir.mkdirs();
                    java.io.File dst = new java.io.File(workDir, label).getCanonicalFile();
                    if (!dst.getPath().startsWith(workDir.getCanonicalFile().getPath()
                            + java.io.File.separator)) {
                        return "{\"ok\":false,\"error\":\"路径越界\"}";
                    }
                    java.nio.file.Files.copy(r.apkFile.toPath(), dst.toPath(),
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    String msg = label + " · " + (r.sizeBytes / 1024) + "KB · " + r.packageName
                            + " · 已放入房间文件, 点交付卡上的「安装」按钮完成安装";
                    if (r.warning != null) msg += "\n" + r.warning;
                    return new JSONObject().put("ok", true)
                            .put("file", label).put("msg", msg).toString();
                } catch (Exception e) {
                    try {
                        return new JSONObject().put("ok", false)
                                .put("error", String.valueOf(e.getMessage())).toString();
                    } catch (Exception ex) {
                        return "{\"ok\":false,\"error\":\"打包异常\"}";
                    }
                }
            }

            @Override
            public String shellExec(String cmd, int timeoutSec) {
                if (!com.hermes.android.linux.RootfsManager.isReady(activity)) {
                    return "ERROR: Linux 环境未就绪, 请先在设置页安装 (设置 → Linux 环境 → 安装),"
                            + " 就绪后 shell.exec 才能使用";
                }
                /* 命令开始时先推开始事件 (防用户以为死机) */
                String shortCmd = cmd.length() > 50 ? cmd.substring(0, 50) + "..." : cmd;
                try {
                    String safe = org.json.JSONObject.quote(shortCmd);
                    activity.evalJsPublic(
                            "if(window._movShellStart)_movShellStart(" + safe + ")");
                } catch (Exception ignored) {}
                /* 流式输出: 每行实时推到 JS 层显示 */
                com.hermes.android.linux.ProotRunner.ExecResult r = com.hermes.android.linux.ProotRunner.exec(
                        activity, cmd, timeoutSec, sm.roomWorkDir(roomId),
                        (line, isStderr) -> {
                            try {
                                String safe = org.json.JSONObject.quote(
                                        (isStderr ? "[stderr]" : "") + line);
                                activity.evalJsPublic(
                                        "if(window._movShellLine)window._movShellLine(" + safe + ")");
                            } catch (Exception ignored) {}
                        });
                activity.evalJsPublic("if(window._movShellEnd)_movShellEnd("
                        + r.exitCode + ",0)");
                return r.format();
            }

            @Override
            public String hermesTask(String goal, int timeoutSec) {
                /* 工单20: 开放式子任务 → HeavyWorker serve 通路（submitTask + M3 SSE + 产物回 /room） */
                if (!com.hermes.android.linux.RootfsManager.isReady(activity)) {
                    return "{\"ok\":false,\"error\":\"Linux 环境未就绪\"}";
                }
                try {
                    com.hermes.android.agent.HeavyWorker hw = new com.hermes.android.agent.HeavyWorker(
                            activity, sm.roomWorkDir(roomId));
                    hw.setProgressListener(text -> hermesProgress(roomId, text));
                    com.hermes.android.agent.Worker.WorkerTask task =
                            new com.hermes.android.agent.Worker.WorkerTask(
                                    "hermes-task-" + System.currentTimeMillis(), 1,
                                    goal, new org.json.JSONObject(),
                                    timeoutSec > 0 ? timeoutSec : 600, true, 32000);
                    com.hermes.android.agent.Worker.WorkerResult wr = hw.run(task);
                    org.json.JSONObject out = new org.json.JSONObject();
                    if (wr != null && wr.ok) {
                        out.put("ok", true);
                        out.put("output", wr.text != null ? wr.text : "");
                        if (wr.files != null && wr.files.length > 0) out.put("file", wr.files[0]);
                    } else {
                        out.put("ok", false);
                        out.put("error", wr != null && wr.errorMsg != null ? wr.errorMsg
                                : (wr != null && wr.text != null ? wr.text : "Hermes 任务失败"));
                    }
                    return out.toString();
                } catch (Exception e) {
                    return "{\"ok\":false,\"error\":\"" + (e.getMessage() != null
                            ? e.getMessage().replace("\"", "'") : "hermes.task 异常") + "\"}";
                }
            }

            @Override
            public String filePush(String roomId, String path) {
                return sm.pushToExchange(roomId, path);
            }

            @Override
            public String filePull(String roomId, String name) {
                return sm.pullFromExchange(roomId, name);
            }
        };
        AgentLoop.LogSink sink = log -> {
            try {
                /* P5: _agentLog 纯状态管理 (渲染全部由 MovRender 负责) */
                evalJs("window._agentLog(" + log.toString() + ")");
            } catch (Exception ignored) {}
            /* P0: 写 journal + 推 _movEvent (MovRender 渲染入口) */
            writeToJournal(roomId, log);
        };
        /* 工具注册表: 探测本机硬件/权限生成 (agent 与硬件控制的分割层);
           内嵌 Linux rootfs 就绪时追加 shell.exec/file.push/file.pull */
        java.util.Set<String> sharedPaths = new java.util.HashSet<>();
        com.hermes.android.agent.ToolRegistry registry = com.hermes.android.agent.ToolRegistry.build(
                tools, roomId, () -> sharedPaths,
                com.hermes.android.agent.ToolRegistry.DevicePolicy.probe(activity),
                com.hermes.android.linux.RootfsManager.isReady(activity));
        this.registry = registry;   // FUSION F2: 快脑 BridgeKernel 查表转发复用同一张表
        /* 批2: 激活内置技能（assets/skills/* → 动态注册技能工具，handler 有实现才注册） */
        try {
            String[] skills = activity.getAssets().list("skills");
            if (skills != null) {
                for (String s : skills) {
                    java.io.InputStream is = activity.getAssets().open("skills/" + s);
                    byte[] buf = new byte[Math.max(1, is.available())];
                    int off = 0, n;
                    while ((n = is.read(buf, off, buf.length - off)) > 0) off += n;
                    is.close();
                    com.hermes.android.skill.SkillActivator.activate(registry,
                            new String(buf, 0, off, "UTF-8"));
                }
            }
            /* 工单24: 用户技能库（addSkill 确认入库的提炼技能）也装配——新房间触发语命中前提 */
            try {
                com.hermes.android.skill.SkillStore us = activity.getSkillStore();
                org.json.JSONArray userSkills = new org.json.JSONArray(us.listSkillsJson());
                for (int i = 0; i < userSkills.length(); i++) {
                    org.json.JSONObject sk = userSkills.optJSONObject(i);
                    if (sk == null) continue;
                    org.json.JSONObject skillJson = new org.json.JSONObject()
                            .put("name", sk.optString("id", ""))
                            .put("description", sk.optString("desc", ""))
                            .put("triggers", sk.optJSONArray("triggers") != null
                                    ? sk.optJSONArray("triggers") : new org.json.JSONArray())
                            .put("tools", new org.json.JSONArray());
                    com.hermes.android.skill.SkillActivator.activate(registry, skillJson.toString());
                }
            } catch (Exception ignored) {}
        } catch (Exception ignored) {}
        /* P8: 构建 Worker 注册表 (Hermes 可用时注册 HeavyWorker) */
        java.util.Map<String, com.hermes.android.agent.Worker> workers = new java.util.LinkedHashMap<>();
        com.hermes.android.agent.HeavyWorker hw = new com.hermes.android.agent.HeavyWorker(
                activity, activity.getStorageManager().roomWorkDir(roomId));
        /* M3: Hermes serve 进度 → 房间 journal note（复用现有通路，不新造组件） */
        hw.setProgressListener(text -> hermesProgress(roomId, text));
        if (hw.available()) workers.put(hw.id(), hw);
        /* 任务级规则加载: 文件有变化才重读, 执行期间不变 */
        com.hermes.android.RulesManager.loadIfChanged();
        AgentLoop loop = AgentLoop.startNew(roomId, goal, brain, tools, registry,
                sharedPaths, wrapSinkWithQueue(sink), workers);
        if (loop == null) {
            queuedGoal = goal; queuedRoomId = roomId;
            queuedModelIds = modelIdsJson; queuedCbId = callbackId;
            evalJs("window._hermesCb('" + callbackId
                    + "',{\"ok\":true,\"queued\":true,\"note\":\"上一个任务还在执行, 已排队\"})");
            return;
        }
        evalJs("window._hermesCb('" + callbackId
                + "',{\"ok\":true,\"loopId\":\"" + loop.getLoopId() + "\"})");
    }

    /** 在日志出口外包一层: 终态时自动启动排队任务 + 记录对话到 chatHistory */
    private AgentLoop.LogSink wrapSinkWithQueue(AgentLoop.LogSink inner) {
        return log -> {
            inner.onLog(log);
            String type = log.optString("type");
            if ("deliver".equals(type) || "fail".equals(type) || "stopped".equals(type)) {
                closeTokenFlusher(log.optString("loopId"));   // 流完冲底+清定时器 (防泄漏)
                /* 将本轮 agent 对话写入 chatHistory，保证下次 agent 有记忆 */
                String goalText = log.optString("goal", "");
                /* deliver: 交付摘要, fail: 失败原因, stopped: 用户取消 */
                String summary = "deliver".equals(type) ? log.optString("summary", "")
                        : "fail".equals(type) ? "（失败）" + log.optString("reason", "")
                        : "（已停止）";
                if (!goalText.isEmpty()) {
                    String roomId = log.optString("roomId", null);
                    java.util.List<AiClient.Message> hist = getHistory(roomId);
                    synchronized (hist) {
                        hist.add(new AiClient.Message("user", goalText));
                        if (!summary.isEmpty()) {
                            hist.add(new AiClient.Message("assistant",
                                summary.length() > 500 ? summary.substring(0, 500) + "…" : summary));
                        }
                        while (hist.size() > MAX_HISTORY * 2) hist.remove(0);
                    }
                    activity.saveChatHistoryPublic();
                }
                maybeStartQueued();
            }
        };
    }

    private synchronized void maybeStartQueued() {
        if (queuedGoal == null) return;
        String g = queuedGoal, r = queuedRoomId, m = queuedModelIds, cb = queuedCbId;
        queuedGoal = null; queuedRoomId = null; queuedModelIds = null; queuedCbId = null;
        evalJs("window._agentLog({\"type\":\"note\",\"text\":\"开始执行排队任务\"})");
        agentStart(g, r, m, cb);
    }

    public void agentStop(String loopId) {
        AgentLoop l = AgentLoop.current();
        if (l != null && l.getLoopId().equals(loopId)) {
            /* 先置标志再取消在途流 (红线: 先标志后 cancel, 取消不重试) */
            AiClient c = currentBrainClient;
            if (c != null) c.cancel();
            l.requestStop();
        }
    }

    public void agentAnswer(String loopId, String text) {
        AgentLoop l = AgentLoop.current();
        if (l != null && l.getLoopId().equals(loopId)) l.answer(text);
    }

    public void agentPlanRespond(String loopId, boolean approved, String note) {
        AgentLoop l = AgentLoop.current();
        if (l != null && l.getLoopId().equals(loopId)) l.respondPlan(approved, note);
    }

    /** P1: 文件写入预览确认/驳回 (照 agentPlanRespond 模式) */
    public void agentFileWriteRespond(String loopId, boolean approved) {
        AgentLoop l = AgentLoop.current();
        if (l != null && l.getLoopId().equals(loopId)) l.respondFileWrite(approved);
    }

    /** 计划外 shell.exec 确认/驳回 (照 agentFileWriteRespond 模式) */
    public void agentShellRespond(String loopId, boolean approved) {
        AgentLoop l = AgentLoop.current();
        if (l != null && l.getLoopId().equals(loopId)) l.respondShell(approved);
    }

    /** 暂停卡 [立即续跑]/[放弃] → 断点续跑 (CONTRACT_STREAMING 2.4) */
    public void agentResume(String loopId, boolean approved) {
        AgentLoop l = AgentLoop.current();
        if (l != null && l.getLoopId().equals(loopId)) l.respondResume(approved);
    }

    public String aiChat(String text) {
        if (!aiConfig.isAiEnabled()) return "AI 已关闭, 点右上角 ≡ 可启用。";
        // BUGFIX: 旧 AiProviderConfig 无 key 时 fallback ModelRegistry 默认模型
        com.hermes.android.model.ModelConfig dm = modelRegistry.getDefault();
        if (!aiConfig.isConfigured() && (dm == null || dm.apiKey == null || dm.apiKey.isEmpty())) {
            return "AI 尚未配置 API Key, 点右上角 ≡ 设置后即可畅聊。";
        }
        try {
            AiClient client = aiConfig.isConfigured() ? new AiClient(aiConfig) : new AiClient(dm);
            AiClient.AiResponse resp = client.chat(text, new ArrayList<>());
            if (resp.success) return resp.content;
            return "AI 调用失败: " + resp.content;
        } catch (Exception e) {
            return "AI 调用异常: " + e.getMessage();
        }
    }

    public String getAiInfo() {
        try {
            // BUGFIX: 优先读 ModelRegistry 默认模型 (新体系), 旧 AiProviderConfig 仅作 fallback
            com.hermes.android.model.ModelConfig dm = modelRegistry.getDefault();
            boolean configured = (dm != null && dm.apiKey != null && !dm.apiKey.isEmpty())
                    || aiConfig.isConfigured();
            String displayName;
            String model;
            String summary;
            if (dm != null && dm.apiKey != null && !dm.apiKey.isEmpty()) {
                displayName = dm.name != null && !dm.name.isEmpty() ? dm.name : dm.provider;
                model = dm.model != null ? dm.model : "";
                summary = dm.getProviderDisplayName() + " · " + (dm.model != null ? dm.model : "");
            } else {
                displayName = aiConfig.getProviderDisplayName().toUpperCase();
                model = aiConfig.getModel();
                summary = aiConfig.getStatusSummary();
            }
            return new JSONObject()
                    .put("enabled", aiConfig.isAiEnabled())
                    .put("configured", configured)
                    .put("displayName", displayName)
                    .put("model", model)
                    .put("summary", summary)
                    .toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    // ==================== P0: Journal 写点 + _movEvent ====================

    /**
     * 把 AgentLoop 日志映射为 Envelope 契约格式, 写入 journal 并推 _movEvent。
     * AgentLoop 日志类型 → Envelope type 映射:
     *   phase→phase, plan→plan, step→tool_result, ask→gate,
     *   note→note, review→review, deliver→deliver, fail→fail,
     *   stopped→stopped, paused→paused, filePreview→gate, shellPreview→gate
     */
    private void writeToJournal(String roomId, JSONObject log) {
        try {
            if (roomId == null || roomId.isEmpty()) return;
            String logType = log.optString("type", "");
            String loopId = log.optString("loopId", null);

            JSONObject event = new JSONObject();
            event.put("taskId", loopId != null ? loopId : JSONObject.NULL);

            switch (logType) {
                case "phase":
                    event.put("actor", "kernel");
                    event.put("type", "phase");
                    event.put("payload", new JSONObject().put("phase", log.optString("phase", "")));
                    break;
                case "plan":
                    event.put("actor", "brain");
                    event.put("type", "plan");
                    JSONObject planPayload = new JSONObject();
                    if (log.has("steps")) planPayload.put("steps", log.optJSONArray("steps"));
                    if (log.has("estTokens")) planPayload.put("estTokens", log.optInt("estTokens"));
                    if (log.has("estSeconds")) planPayload.put("estSeconds", log.optInt("estSeconds"));
                    if (log.has("understanding")) planPayload.put("understanding", log.optJSONObject("understanding"));
                    if (log.has("revised")) planPayload.put("revised", true);
                    event.put("payload", planPayload);
                    break;
                case "step":
                    event.put("actor", "worker");
                    event.put("type", "tool_result");
                    JSONObject stepPayload = new JSONObject()
                            .put("ok", log.optBoolean("ok"))
                            .put("durMs", log.optLong("durMs"))
                            .put("summary", truncate(log.optString("result", ""), 200))
                            /* 无感工作态: 补技能名/参数 (谁被调用可见, 技能调用卡数据源) */
                            .put("name", log.optString("name", ""))
                            .put("arg", log.optString("arg", ""));
                    if (!log.optBoolean("ok")) {
                        stepPayload.put("error", log.optString("result", ""));
                    }
                    /* H1: 失败归因码透出（JS 侧可读，DESIGN_TOOL_HEALTH §一） */
                    if (log.has("reason") && !log.isNull("reason")) {
                        stepPayload.put("reason", log.optString("reason", ""));
                    }
                    event.put("payload", stepPayload);
                    break;
                case "tool_call":
                    /* 无感工作态: 工具调用开始事件 (技能调用卡「⚡ name · 调用中」) */
                    event.put("actor", "worker");
                    event.put("type", "tool_call");
                    event.put("payload", new JSONObject()
                            .put("name", log.optString("name", ""))
                            .put("arg", log.optString("arg", "")));
                    break;
                case "ask":
                    event.put("actor", "brain");
                    event.put("type", "gate");
                    JSONObject askPayload = new JSONObject()
                            .put("gate", "ask")
                            .put("state", "open")
                            .put("note", log.optString("question", ""));
                    if (log.has("options")) askPayload.put("options", log.optJSONArray("options"));
                    event.put("payload", askPayload);
                    break;
                case "note":
                    event.put("actor", "kernel");
                    event.put("type", "note");
                    event.put("payload", new JSONObject().put("text", log.optString("text", "")));
                    break;
                case "deliver":
                    event.put("actor", "kernel");
                    event.put("type", "deliver");
                    JSONObject deliverPayload = new JSONObject();
                    if (log.has("summary")) deliverPayload.put("summary", log.optString("summary"));
                    if (log.has("files")) deliverPayload.put("files", log.optJSONArray("files"));
                    JSONObject metrics = new JSONObject();
                    if (log.has("promptTokens")) metrics.put("promptTokens", log.optInt("promptTokens"));
                    if (log.has("completionTokens")) metrics.put("completionTokens", log.optInt("completionTokens"));
                    if (log.has("estTokens")) metrics.put("estTokens", log.optInt("estTokens"));
                    if (log.has("elapsedSec")) metrics.put("elapsedSec", log.optLong("elapsedSec"));
                    deliverPayload.put("metrics", metrics);
                    if (log.has("checklist")) deliverPayload.put("checklist", log.optJSONArray("checklist"));
                    event.put("payload", deliverPayload);
                    break;
                case "fail":
                    event.put("actor", "kernel");
                    event.put("type", "fail");
                    JSONObject failPayload = new JSONObject()
                            .put("reason", log.optString("reason", ""))
                            .put("stepsDone", log.optInt("stepsDone"));
                    if (log.has("files")) failPayload.put("produced", log.optJSONArray("files"));
                    event.put("payload", failPayload);
                    break;
                case "stopped":
                    event.put("actor", "kernel");
                    event.put("type", "stopped");
                    JSONObject stoppedPayload = new JSONObject();
                    if (log.has("files")) stoppedPayload.put("files", log.optJSONArray("files"));
                    event.put("payload", stoppedPayload);
                    break;
                case "paused":
                    event.put("actor", "kernel");
                    event.put("type", "paused");
                    event.put("payload", new JSONObject()
                            .put("reason", log.optString("reason", ""))
                            .put("stepsDone", log.optInt("stepsDone")));
                    break;
                case "filePreview":
                    event.put("actor", "brain");
                    event.put("type", "gate");
                    event.put("payload", new JSONObject()
                            .put("gate", "fileWrite")
                            .put("state", "open")
                            .put("note", log.optString("path", "")));
                    break;
                case "shellPreview":
                    event.put("actor", "brain");
                    event.put("type", "gate");
                    event.put("payload", new JSONObject()
                            .put("gate", "shell")
                            .put("state", "open")
                            .put("note", log.optString("cmd", "")));
                    break;
                default:
                    // 未知类型: 原样落 journal, type 保持
                    event.put("actor", "kernel");
                    event.put("type", logType);
                    event.put("payload", log);
                    break;
            }

            int seq = journal.append(roomId, event);
            if (seq > 0) {
                pushMovEvent(roomId, event);
            }
        } catch (Exception e) {
            android.util.Log.w("BridgeAi", "writeToJournal failed: " + e.getMessage());
        }
    }

    /** M3: Hermes serve 进度 → 房间 journal note 事件（复用现有通路，不新造组件） */
    public void hermesProgress(String roomId, String text) {
        if (roomId == null || roomId.isEmpty() || text == null || text.isEmpty()) return;
        try {
            writeToJournal(roomId, new JSONObject()
                    .put("type", "note")
                    .put("text", truncate(text, 200)));
        } catch (Exception e) {
            android.util.Log.w("BridgeAi", "hermesProgress: " + e.getMessage());
        }
    }

    /** 推送 _movEvent (journal 通道) */
    private void pushMovEvent(String roomId, JSONObject event) {
        try {
            JSONObject envelope = new JSONObject()
                    .put("roomId", roomId)
                    .put("channel", "journal")
                    .put("event", event);
            activity.evalJsPublic("window._movEvent(" + envelope.toString() + ")");
        } catch (Exception e) {
            android.util.Log.w("BridgeAi", "pushMovEvent failed: " + e.getMessage());
        }
    }

    private static String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max);
    }
}
