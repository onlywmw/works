package com.hermes.android.browser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * 浏览器 diff-after-action（协议 §5）。
 *
 * 纯 Java 行集合差，无 Android 依赖，可在工作线程跑。
 * 输入：动作前后 body.innerText 快照 → 输出 {added, removed, truncated} 或 {unchanged:true}。
 */
public class BrowserDiffHelper {

    private static final int MAX_LINES = 60;
    private static final int MAX_CHARS_PER_SIDE = 2000;

    /** Diff 结果 JSON（调用方负责 try-catch JSONException） */
    public static JSONObject diff(String before, String after) throws JSONException {
        if (before == null) before = "";
        if (after == null) after = "";

        before = collapseWhitespace(before);
        after = collapseWhitespace(after);

        if (before.equals(after)) {
            return new JSONObject().put("unchanged", true);
        }

        Set<String> beforeLines = toLineSet(before);
        Set<String> afterLines = toLineSet(after);

        List<String> added = new ArrayList<>();
        for (String line : afterLines) {
            if (!beforeLines.contains(line)) added.add(line);
        }

        List<String> removed = new ArrayList<>();
        for (String line : beforeLines) {
            if (!afterLines.contains(line)) removed.add(line);
        }

        JSONObject result = new JSONObject();
        boolean truncated = false;

        JSONObject addedObj = packLines(added);
        result.put("added", addedObj.optJSONArray("lines"));
        result.put("added_chars", addedObj.optInt("chars"));
        if (addedObj.optBoolean("truncated")) truncated = true;

        JSONObject removedObj = packLines(removed);
        result.put("removed", removedObj.optJSONArray("lines"));
        result.put("removed_chars", removedObj.optInt("chars"));
        if (removedObj.optBoolean("truncated")) truncated = true;

        // 行集合相同 = 无意义变化（仅换序/空白差异）
        if (added.isEmpty() && removed.isEmpty()) {
            return new JSONObject().put("unchanged", true);
        }

        if (truncated) result.put("truncated", true);
        return result;
    }

    /** 打包行列表 → {lines, chars, truncated?}，硬夹 MAX_CHARS_PER_SIDE */
    static JSONObject packLines(List<String> lines) throws JSONException {
        JSONArray arr = new JSONArray();
        int chars = 0;
        boolean truncated = false;
        int count = 0;
        for (String line : lines) {
            if (count >= MAX_LINES) { truncated = true; break; }
            String clipped = line.length() > 200 ? line.substring(0, 197) + "..." : line;
            arr.put(clipped);
            chars += line.length();
            if (chars > MAX_CHARS_PER_SIDE) { truncated = true; break; }
            count++;
        }
        JSONObject o = new JSONObject();
        o.put("lines", arr);
        o.put("chars", chars);
        if (truncated) o.put("truncated", true);
        return o;
    }

    /** 行内空白折叠（\\h+ → 单空格），保留换行边界，防 reflow 噪声 */
    static String collapseWhitespace(String s) {
        return s.replaceAll("[\\t ]+", " ").trim();
    }

    /** 按行分割 → LinkedHashSet（去重+保序） */
    static Set<String> toLineSet(String s) {
        Set<String> set = new LinkedHashSet<>();
        if (s.isEmpty()) return set;
        for (String line : s.split("\n")) {
            line = line.trim();
            if (!line.isEmpty()) set.add(line);
        }
        return set;
    }
}
