package com.hermes.android.context;

import android.util.Log;

import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.file.Files;

/**
 * 情境数据端侧落盘 — JSONL + 快照文件。
 *
 * <p>隐私铁律：所有文件留在应用私有目录（filesDir/context/），永不上传。
 *
 * <p>文件结构：
 * <pre>{@code
 *   filesDir/context/
 *     context_events.jsonl   ← 追加转移事件（一行一 JSON）
 *     snapshot.json           ← 最新快照（覆盖写）
 * }</pre>
 */
public class ContextPersister {

    private final File eventsFile;
    private final File snapshotFile;

    /**
     * @param contextDir 应用私有目录下的 context 子目录（typically filesDir/context/）
     */
    public ContextPersister(File contextDir) {
        // 确保目录存在
        if (!contextDir.exists()) {
            contextDir.mkdirs();
        }
        this.eventsFile = new File(contextDir, "context_events.jsonl");
        this.snapshotFile = new File(contextDir, "snapshot.json");
    }

    /** 追加一条转移事件到 JSONL */
    synchronized void appendEvent(ContextEvent event) {
        String line = event.toJson().toString();
        try (Writer w = new FileWriter(eventsFile, true)) {
            w.write(line);
            w.write("\n");
        } catch (IOException e) {
            Log.w(TAG, "appendEvent: write failed", e);
        }
    }

    /** 覆盖写最新快照 */
    synchronized void writeSnapshot(ContextSnapshot snapshot) {
        String json = snapshot.toJson().toString();
        try (Writer w = new FileWriter(snapshotFile, false)) {
            w.write(json);
        } catch (IOException e) {
            Log.w(TAG, "writeSnapshot: write failed", e);
        }
    }

    /** 读取最新快照；文件不存在返回 null */
    ContextSnapshot readSnapshot() {
        try {
            if (!snapshotFile.exists()) return null;
            byte[] bytes = Files.readAllBytes(snapshotFile.toPath());
            JSONObject obj = new JSONObject(new String(bytes, "UTF-8"));
            return new ContextSnapshot.Builder()
                    .wifiSsid(obj.optString("wifi_ssid", null))
                    .batteryLevel(obj.has("battery_level") && !obj.isNull("battery_level")
                            ? obj.getInt("battery_level") : null)
                    .isCharging(obj.optBoolean("is_charging", false))
                    .screenOn(obj.optBoolean("screen_on", false))
                    .foregroundApp(obj.optString("foreground_app", null))
                    .capturedAtMs(obj.optLong("captured_at_ms", 0))
                    .build();
        } catch (Exception e) {
            Log.w(TAG, "readSnapshot: parse failed", e);
            return null;
        }
    }

    private static final String TAG = "ContextPersister";
}
