package com.hermes.android.agent;

import com.hermes.android.ai.AiClient;
import com.hermes.android.model.ModelConfig;

import java.util.ArrayList;

/**
 * FastWorker — 云端模型大脑 (CONTRACT: Worker §5)。
 * 封装 AiClient.chatStream，默认大脑；停滞看门狗/双速重试沿用 STREAMING。
 */
public class FastWorker implements Worker {

    private final ModelConfig model;
    private volatile AiClient currentClient;

    public FastWorker(ModelConfig model) {
        this.model = model;
    }

    @Override
    public String id() {
        return "fast:" + (model != null ? model.id : "default");
    }

    @Override
    public boolean available() {
        return model != null && model.enabled && model.isConfigured();
    }

    @Override
    public WorkerResult run(WorkerTask task) {
        if (!available()) {
            return WorkerResult.fail(WorkerResult.UNAVAILABLE, "模型未配置或已禁用", false);
        }
        try {
            AiClient client = new AiClient(model, task.instruction);
            currentClient = client;
            AiClient.AiResponse resp = client.chatStream(
                    task.instruction, new ArrayList<>(), null,
                    com.hermes.android.ai.StreamWatchdog.Mode.STREAM);
            currentClient = null;

            if (resp.cancelled) {
                return WorkerResult.fail(WorkerResult.CANCELLED, "用户取消", false);
            }
            if (!resp.success) {
                boolean retryable = resp.errorClass != null
                        && com.hermes.android.ai.StreamWatchdog.isRecoverable(resp.errorClass);
                String code = retryable ? WorkerResult.STALLED : WorkerResult.INTERNAL;
                return WorkerResult.fail(code, resp.content, retryable);
            }
            return WorkerResult.success(resp.content, null,
                    resp.promptTokens, resp.completionTokens);
        } catch (Exception e) {
            currentClient = null;
            return WorkerResult.fail(WorkerResult.INTERNAL, "执行异常: " + e.getMessage(), false);
        }
    }

    @Override
    public void cancel() {
        AiClient c = currentClient;
        if (c != null) c.cancel();
    }
}
