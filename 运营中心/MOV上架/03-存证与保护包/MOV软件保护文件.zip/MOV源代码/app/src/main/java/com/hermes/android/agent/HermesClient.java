package com.hermes.android.agent;

import org.json.JSONObject;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * HermesClient — 常驻 serve 的 Java 客户端（P2 M2，DESIGN_HERMES_SERVE §二协议）。
 *
 * 纯 JVM 核心（可单测，零网络）：payload 构造 / task_id 解析 / 状态解析 / 错误映射 / token 生成。
 * Android 实例（OkHttp）：healthz / submitTask / getTask / cancelTask —— HeavyWorker 阻塞调用。
 *
 * 信封语义：HTTP 响应即 serve 契约（{task_id} / {status,output,error} / 401/404/409 错误码），
 * 本类把这些映射成 HeavyWorker 能用的 WorkerResult 错误码（照 LlamaClient 模式）。
 */
public class HermesClient {

    public static final String BASE_URL = "http://127.0.0.1:8387";
    /** 阶段3 A0: MOV 入站监听（工具统一回调，daemon 代理的落点） */
    public static final String MOV_A0_URL = "http://127.0.0.1:8388";
    public static final String HEADER_AUTH = "X-Mov-Token";
    public static final String STATUS_QUEUED = "queued";
    public static final String STATUS_RUNNING = "running";
    public static final String STATUS_DONE = "done";
    public static final String STATUS_FAILED = "failed";
    public static final String STATUS_CANCELLED = "cancelled";

    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private static final SecureRandom RNG = new SecureRandom();

    // ==================== 纯 JVM 核心（可单测） ====================

    /** POST /task 请求体：instruction + constraints（禁网经此下发，serve 侧 per-task unset proxy） */
    public static String buildTaskPayload(String instruction, boolean network,
                                          int timeoutSec, int maxTokens) {
        try {
            JSONObject constraints = new JSONObject()
                    .put("network", network)
                    .put("timeoutSec", timeoutSec > 0 ? timeoutSec : 120)
                    .put("maxTokens", maxTokens > 0 ? maxTokens : 8000);
            return new JSONObject()
                    .put("instruction", instruction != null ? instruction : "")
                    .put("constraints", constraints)
                    .toString();
        } catch (Exception e) {
            throw new RuntimeException("buildTaskPayload", e);
        }
    }

    /** POST /task 响应 → task_id；无法解析返回 null */
    public static String parseTaskId(String body) {
        if (body == null) return null;
        try {
            String id = new JSONObject(body).optString("task_id", "");
            return id.isEmpty() ? null : id;
        } catch (Exception e) {
            return null;
        }
    }

    /** GET /task/{id} 响应 → 状态结构 */
    public static TaskResult parseTaskStatus(String body) {
        if (body == null) return new TaskResult(STATUS_FAILED, null, "空响应");
        try {
            JSONObject o = new JSONObject(body);
            return new TaskResult(
                    o.optString("status", STATUS_QUEUED),
                    o.has("output") ? o.optString("output") : null,
                    o.optString("error", null));
        } catch (Exception e) {
            return new TaskResult(STATUS_FAILED, null, "响应无法解析");
        }
    }

    /** HTTP 错误 → 人话（照 LlamaClient.mapError） */
    public static String mapError(int httpCode, String body) {
        if (httpCode <= 0) return "serve 连不上（hermes mov-serve 未启动）";
        if (httpCode == 401) return "serve token 鉴权失败（X-Mov-Token 不匹配）";
        if (httpCode == 409) return "serve 已有任务在跑（v1 串行）";
        if (httpCode == 404) return "serve 任务不存在";
        if (httpCode == 400) return "serve 请求被拒（400），instruction 非法";
        if (httpCode >= 500) return "serve 异常（" + httpCode + "），稍后再试";
        return "serve 请求失败（" + httpCode + "）";
    }

    /** MOV 侧生成的鉴权 token：32 字节 urlsafe base64（设计 §二：Secrets.tokenUrlSafe 同款） */
    public static String tokenUrlSafe() {
        byte[] b = new byte[32];
        RNG.nextBytes(b);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b);
    }

    // ==================== 阶段3 A2: invokeTool（工具统一，走 MOV A0 监听） ====================

    /** POST /tools/{name}/invoke 请求体：{params} */
    public static String buildInvokePayload(JSONObject params) {
        try {
            return new JSONObject()
                    .put("params", params != null ? params : new JSONObject())
                    .toString();
        } catch (Exception e) {
            throw new RuntimeException("buildInvokePayload", e);
        }
    }

    /** POST /tools/{name}/invoke 响应 → InvokeResult（信封 {ok,data}/{ok,error:{code,msg}}） */
    public static InvokeResult parseInvokeResult(String body) {
        if (body == null) return new InvokeResult(false, null, "EMPTY", "空响应");
        try {
            JSONObject o = new JSONObject(body);
            if (o.optBoolean("ok", false)) {
                return new InvokeResult(true, o.optJSONObject("data"), null, null);
            }
            JSONObject err = o.optJSONObject("error");
            String code = err != null ? err.optString("code", "TOOL_FAILED") : "TOOL_FAILED";
            String msg = err != null ? err.optString("msg", "工具执行失败") : "工具执行失败";
            return new InvokeResult(false, null, code, msg);
        } catch (Exception e) {
            return new InvokeResult(false, null, "PARSE", "响应无法解析: " + e.getMessage());
        }
    }

    /** invokeTool 结果（纯数据）：ok / 成功 data / 失败 code+msg */
    public static class InvokeResult {
        public final boolean ok;
        public final JSONObject data;
        public final String errorCode;
        public final String errorMsg;
        public InvokeResult(boolean ok, JSONObject data, String errorCode, String errorMsg) {
            this.ok = ok; this.data = data; this.errorCode = errorCode; this.errorMsg = errorMsg;
        }
    }

    /** GET /task/{id} 状态结构（纯数据） */
    public static class TaskResult {
        public final String status;
        public final String output;
        public final String error;
        public TaskResult(String status, String output, String error) {
            this.status = status; this.output = output; this.error = error;
        }
        public boolean isTerminal() {
            return STATUS_DONE.equals(status) || STATUS_FAILED.equals(status)
                    || STATUS_CANCELLED.equals(status);
        }
    }

    // ==================== Android HTTP（OkHttp，阻塞调用） ====================

    private final OkHttpClient http;
    private final String token;

    public HermesClient(String token) {
        this.token = token;
        this.http = new OkHttpClient.Builder()
                .connectTimeout(3, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .callTimeout(20, TimeUnit.SECONDS)
                .build();
    }

    /** healthz-on-call：200 且 ok=true → serve 存活（每调用前检查，便宜） */
    public boolean healthz(long timeoutMs) {
        try {
            Request req = new Request.Builder().url(BASE_URL + "/healthz").get().build();
            try (Response r = http.newCall(req).execute()) {
                if (!r.isSuccessful() || r.body() == null) return false;
                JSONObject o = new JSONObject(r.body().string());
                return o.optBoolean("ok", false);
            }
        } catch (Exception e) {
            return false;
        }
    }

    /** 懒启动后轮询 healthz（最多 waitMs） */
    public boolean waitHealthy(long waitMs) {
        long deadline = System.currentTimeMillis() + waitMs;
        while (System.currentTimeMillis() < deadline) {
            if (healthz(1000)) return true;
            try { Thread.sleep(300); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
        }
        return false;
    }

    /** POST /task → task_id；失败抛 IOException（带 mapError 文案） */
    public String submitTask(String instruction, boolean network, int timeoutSec, int maxTokens)
            throws java.io.IOException {
        Request req = new Request.Builder()
                .url(BASE_URL + "/task")
                .header(HEADER_AUTH, token)
                .post(RequestBody.create(buildTaskPayload(instruction, network, timeoutSec, maxTokens), JSON))
                .build();
        try (Response r = http.newCall(req).execute()) {
            String body = r.body() != null ? r.body().string() : "";
            if (r.code() == 200) {
                String id = parseTaskId(body);
                if (id == null) throw new java.io.IOException("serve 响应无 task_id: " + body);
                return id;
            }
            throw new java.io.IOException(mapError(r.code(), body));
        }
    }

    /** GET /task/{id} → 状态 */
    public TaskResult getTask(String taskId) throws java.io.IOException {
        Request req = new Request.Builder()
                .url(BASE_URL + "/task/" + taskId)
                .header(HEADER_AUTH, token)
                .get().build();
        try (Response r = http.newCall(req).execute()) {
            String body = r.body() != null ? r.body().string() : "";
            if (r.code() == 200) return parseTaskStatus(body);
            throw new java.io.IOException(mapError(r.code(), body));
        }
    }

    /** POST /task/{id}/cancel → 是否已提交取消请求 */
    public boolean cancelTask(String taskId) {
        try {
            Request req = new Request.Builder()
                    .url(BASE_URL + "/task/" + taskId + "/cancel")
                    .header(HEADER_AUTH, token)
                    .post(RequestBody.create("{}", JSON))
                    .build();
            try (Response r = http.newCall(req).execute()) {
                return r.code() == 200;
            }
        } catch (Exception e) {
            return false;
        }
    }

    /** 阶段3 A2: 调用 MOV 入站监听执行工具（统一路径，走 MOV 统一闸）。
        调 MOV A0 (127.0.0.1:8388) /tools/{name}/invoke；信封 {ok,data}/{ok,error}。 */
    public InvokeResult invokeTool(String name, JSONObject params) {
        try {
            Request req = new Request.Builder()
                    .url(MOV_A0_URL + "/tools/" + name + "/invoke")
                    .header(HEADER_AUTH, token)
                    .post(RequestBody.create(buildInvokePayload(params), JSON))
                    .build();
            try (Response r = http.newCall(req).execute()) {
                String body = r.body() != null ? r.body().string() : "";
                if (r.code() == 200) return parseInvokeResult(body);
                return new InvokeResult(false, null, "HTTP_" + r.code(), mapError(r.code(), body));
            }
        } catch (Exception e) {
            return new InvokeResult(false, null, "CONNECT",
                    "MOV A0 不可达: " + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName()));
        }
    }
}
