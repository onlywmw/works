/* ── MOV · MCP 市场（工单25 幕一：能逛不能买）──
   设置二级页 id 'market'：newface.js renderSubPage('market') → MovMarket.render()，
   渲染后 afterSubPage → MovMarket.bind()（动态行不拼 onclick，data 属性 + addEventListener）。
   桥契约（BridgeKernel 信封，Java 侧另一工位施工，不加新 @JavascriptInterface）：
     query  {q:'mcp.list'}                         → {ok, data:{servers:[{id,name,url,enabled,origin,tools}]}}
     postCmd{cmd:'mcp.add',    url, token, origin} origin ∈ 'market' | 'manual'
     postCmd{cmd:'mcp.test',   id}
     postCmd{cmd:'mcp.enable', id, enabled}
     postCmd{cmd:'mcp.remove', id}
   桥不可用 → MOCK 降级：显示示例数据并标注「示例」，写操作只落在本地示例列表。 */
window.MovMarket = (function() {

  var _tab = 'free';        /* free=本地 | paid=市场 */
  var _cat = 'all';         /* 市场分类过滤：all | db | net | home | efficiency | dev */
  var _detailId = null;     /* 付费商品详情（null = 货架列表） */
  var _addOpen = false;     /* 手动添加表单展开 */
  var _mockList = null;     /* 桥不可用时的示例列表（会话内可增删改） */

  /* 本地页分类顺序（组内排第一 = 默认，UI 语义与 McpServerStore.defaultForCat 一致） */
  var LCATS = [['db','数据库'],['net','网络'],['file','文件'],['home','家居'],['efficiency','效率'],['dev','开发'],['other','其他']];

  /* 桥不可用时的示例数据（照本地页定稿 demo：分组/默认/黑金开关各态混排） */
  var MOCK_SERVERS = [
    { id:'mock-pb', name:'PocketBase 包', desc:'本地数据库五件套，开箱即用', url:'http://127.0.0.1:8090', enabled:true, origin:'market', cat:'db', paid:true },
    { id:'mock-sqlite', name:'sqlite 直查', desc:'SQL 直查本地库文件', url:'http://127.0.0.1:8316/mcp', enabled:true, origin:'market', cat:'db', paid:true },
    { id:'mock-fetch', name:'fetch 网页抓取', desc:'URL 转成干净正文，自动打码', url:'http://127.0.0.1:8302/mcp', enabled:true, origin:'market', cat:'net', paid:true },
    { id:'mock-rss', name:'rsshub 订阅', desc:'万物皆可订阅', url:'http://192.168.1.12:1200/mcp', enabled:false, origin:'manual', cat:'net', paid:false },
    { id:'mock-fs', name:'filesystem 受控读写', desc:'受控目录读写，越界拒执', url:'http://192.168.1.12:3001/mcp', enabled:false, origin:'manual', cat:'file', paid:false },
    { id:'mock-mijia', name:'米家桥接', desc:'说一句话控米家设备', url:'http://127.0.0.1:8321/mcp', enabled:true, origin:'market', cat:'home', paid:true },
    { id:'mock-ha', name:'HomeAssistant', desc:'HA 全屋设备桥', url:'http://192.168.1.10:8123/mcp', enabled:true, origin:'manual', cat:'home', paid:false },
    { id:'mock-cal', name:'日历直写', desc:'一句话写日历、定提醒', url:'http://127.0.0.1:8331/mcp', enabled:true, origin:'market', cat:'efficiency', paid:true },
    { id:'mock-ledger', name:'记账本', desc:'一句话记账，月度出表', url:'http://127.0.0.1:8332/mcp', enabled:false, origin:'market', cat:'efficiency', paid:true },
    { id:'mock-adb', name:'adb-debug', desc:'ADB/logcat/采样一把梭', url:'http://127.0.0.1:8341/mcp', enabled:true, origin:'market', cat:'dev', paid:true }
  ];

  /* 付费区静态货架（幕一能逛不能买；说明书/质检报告为静态文案）
     v2：cat ∈ db/net/home/efficiency/dev；soldNum 供热销榜排序；icon/color 为列表图标
     幕二+幕三（工单26）：每件补 fen/sellerDeviceId/sellerPubKey（交易数据源 = Java 侧 Shelf，
     JS 仅展示；sellerPubKey 与 Shelf.SELLER_PUB_KEY_B64 一致，施工时生成） */
  var SELLER_PUB = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAkmVKcRqYXSM9JWP44qSBjFSq1IoFnOLpHdnVmQvTRPnUbuR1Ntek5jMiMtkGAlfMsF9+ztJKXlMEUUTNWYv4uiOOEC9gCF0A45PmXLV7m+9JSk9KqASOkB2iRZ74hcuRWu0Hsc5tIvCb072dIbNub8SDYXDWG7xUhUOv3p1uZVpPptjNLzIMlCMwRDuLgweSDuciSUIDi2vUi020lZLmnPysPuh1zCYGm5RmxQd0mkTLNgA9kNumMB+uLOlMM/X0GS9G4tnzNlOWW6i9tpJuQ+nKUcWA9/UvKSioYmdui3UE7J2G3chG5nhvHHu4YSyKSKYZywbjZe9dFZxi0k7hgQIDAQAB';
  var DELIVERY = '微信支付 → 卖家设备自动查单 → <b>A2A 加密通道发货</b> → 本地解密一键安装。钱直达商户，不经任何中间账户。';
  var GOODS = [
    { id:'pb', name:'PocketBase 数据库包', price:'¥9.90', fen:990, type:'配置型', soldNum:0, sold:'即将上架', available:false,
      cat:'db', icon:'🗄', color:'#4a6fd4', sellerDeviceId:'mov-seller', sellerPubKey:SELLER_PUB,
      desc:'平板秒变本地数据库：pb.start/query/create/update/auth 五件全配好，含质检报告。',
      spec:'<b>提供</b>：集合名 + filter → 记录列表<br><b>输入</b>：<code>collection</code> 必填 · <code>filter/sort/perPage</code> 可选<br><b>依赖</b>：pb.start 已启动 · 本地无需联网',
      report:'✓ 8389 真实调用通过 · ✓ 坏件拒收实测 · ✓ 组合调用闭环<br><span style="color:var(--ink-3);font-size:11px">RPT-20260807-010-pb-tools · 2298 测试全绿</span>' },
    { id:'fetch-kit', name:'网页抓取套装', price:'¥6.60', fen:660, type:'工具型', soldNum:0, sold:'即将上架', available:false,
      cat:'net', icon:'🕸', color:'#5d9b4a', sellerDeviceId:'mov-seller', sellerPubKey:SELLER_PUB,
      desc:'抓取 + readability 清洗 + 进记忆三件套，调参完成开箱即用。',
      spec:'<b>提供</b>：URL → 正文 markdown → 写入本机记忆<br><b>输入</b>：<code>url</code> 必填 · <code>selector/maxLen</code> 可选<br><b>依赖</b>：出网内容自动过 PII 打码闸',
      report:'✓ 真实站点抓取回归通过 · ✓ 乱码/坏链拒收实测 · ✓ 清洗入库闭环<br><span style="color:var(--ink-3);font-size:11px">RPT-20260807-011-fetch-kit · 312 测试全绿</span>' },
    { id:'smarthome', name:'智能家居控制包', price:'¥12.00', fen:1200, type:'工具型', soldNum:0, sold:'即将上架', available:false,
      cat:'home', icon:'🏠', color:'#c2682b', sellerDeviceId:'mov-seller', sellerPubKey:SELLER_PUB,
      desc:'米家/HA 桥接，说一句话控全屋。含部署脚本 + 真机查验报告。',
      spec:'<b>提供</b>：灯 / 空调 / 开关 自然语言控制 → 设备动作<br><b>输入</b>：<code>room/action</code> 必填 · <code>value</code> 可选<br><b>依赖</b>：随包部署脚本在本机起桥接服务',
      report:'✓ 米家/HA 双桥真机查验通过 · ✓ 离线指令降级实测 · ✓ 部署脚本一键起服<br><span style="color:var(--ink-3);font-size:11px">RPT-20260807-012-smarthome · 真机查验报告随包</span>' },
    { id:'calendar', name:'日历提醒包', price:'¥3.90', fen:390, type:'配置型', soldNum:0, sold:'即将上架', available:false,
      cat:'efficiency', icon:'📅', color:'#7a5c9e', sellerDeviceId:'mov-seller', sellerPubKey:SELLER_PUB,
      desc:'系统日历直写 + 定时提醒，一句话搞定。',
      spec:'<b>提供</b>：自然语言 → 日历事件 / 定时提醒<br><b>输入</b>：<code>title/time</code> 必填 · <code>remind</code> 可选<br><b>依赖</b>：系统日历权限',
      report:'✓ 日历直写真机查验通过 · ✓ 提醒触发实测<br><span style="color:var(--ink-3);font-size:11px">RPT-20260808-013-calendar</span>' },
    { id:'ledger', name:'记账速查包', price:'¥6.60', fen:660, type:'工具型', soldNum:0, sold:'即将上架', available:false,
      cat:'efficiency', icon:'📊', color:'#3e8b8b', sellerDeviceId:'mov-seller', sellerPubKey:SELLER_PUB,
      desc:'说一句话记账，月度汇总自动出表。',
      spec:'<b>提供</b>：自然语言记账 → 本地账本 + 月度汇总表<br><b>输入</b>：<code>amount/category</code> 必填<br><b>依赖</b>：数据只存本机',
      report:'✓ 记账/汇总/导出回归通过<br><span style="color:var(--ink-3);font-size:11px">RPT-20260808-014-ledger</span>' },
    { id:'devkit', name:'开发者调试包', price:'¥9.90', fen:990, type:'工具型', soldNum:0, sold:'即将上架', available:false,
      cat:'dev', icon:'🔧', color:'#8a8676', sellerDeviceId:'mov-seller', sellerPubKey:SELLER_PUB,
      desc:'ADB / logcat / 性能采样一把梭。',
      spec:'<b>提供</b>：设备调试指令 → ADB/logcat/采样动作<br><b>输入</b>：<code>action</code> 必填<br><b>依赖</b>：本机开发者模式',
      report:'✓ 真机调试链路查验通过<br><span style="color:var(--ink-3);font-size:11px">RPT-20260808-015-devkit</span>' },
    { id:'pkg-accept-001', name:'0.01元验收专用包', price:'¥0.01', fen:1, type:'配置型', soldNum:0, sold:'验收专用',
      cat:'net', icon:'🧪', color:'#2e8b57', sellerDeviceId:'mov-seller', sellerPubKey:SELLER_PUB,
      desc:'验收专用：官方能力包（本机 MOV MCP 端点 8389），装完工具立即可调。',
      spec:'<b>提供</b>：MOV 官方 MCP 工具（mcp.* 全家桶）<br><b>输入</b>：按工具说明<br><b>依赖</b>：本机 MOV 服务（App 启动即在）',
      report:'✓ 真单全链验收专用 · ✓ 0.01 元微信支付 · ✓ 装完即调<br><span style="color:var(--ink-3);font-size:11px">RPT-20260809-001-accept</span>' }
  ];
  var CATS = [['all','推荐'],['db','数据库'],['net','网络'],['home','家居'],['efficiency','效率'],['dev','开发']];

  /* 桥不可用时的示例数据已上移（MOCK_SERVERS，含 cat/paid/desc） */

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }
  function toast(m) { try { if (typeof B !== 'undefined' && B.toast) B.toast(m); } catch(e) {} }
  function hasBridge() { return typeof B !== 'undefined' && B.query && B.postCmd; }
  function refresh() { try { NewFace.redrawSettings(); } catch(e) {} }

  /* 已安装列表：真桥 query mcp.list；失败/不可用 → 示例数据（_mock 标记） */
  function listServers() {
    if (hasBridge()) {
      try {
        var r = B.query({q:'mcp.list'});
        if (r && r.ok && r.data) return { mock:false, servers:(r.data.servers || []) };
      } catch(e) {}
    }
    if (!_mockList) _mockList = MOCK_SERVERS.map(function(s){ var c = {}; for (var k in s) c[k] = s[k]; return c; });
    return { mock:true, servers:_mockList };
  }
  function findMock(id) {
    if (!_mockList) return null;
    for (var i = 0; i < _mockList.length; i++) if (_mockList[i].id === id) return _mockList[i];
    return null;
  }

  /* ── 渲染（静态模板 innerHTML；动态数据一律 esc，用户输入只进 input.value / postCmd JSON） ── */

  function render() {
    if (_detailId) return renderDetail();
    var html = '<div class="mk-tabs">'
      + '<div class="mk-tab' + (_tab === 'free' ? ' on' : '') + '" onclick="MovMarket.tab(\'free\')">本地</div>'
      + '<div class="mk-tab' + (_tab === 'paid' ? ' on' : '') + '" onclick="MovMarket.tab(\'paid\')">市场</div>'
      + '</div>';
    if (_tab === 'free') html += renderFree();
    else html += renderPaid();
    return html;
  }

  /* 本地页（定稿 v-final）：分类组盒；组内第一（启用者）= 默认；行 = 名称+一句话简介+开关（付费黑金）；
     点行 → 操作弹层（测连通/复制信息/删除）；长按行 → 拖动调组内顺序（顺序即默认） */
  function renderFree() {
    return renderMine();
  }

  function renderMine() {
    var res = listServers();
    var html = '';
    if (res.mock) {
      html += '<div class="note">桥不可用（mcp.list 未就绪）· 以下为示例数据，操作不落盘。</div>';
    }
    if (!res.servers.length) {
      html += '<div class="note">还没有接入任何 MCP 服务。</div>';
    }
    /* 按 LCATS 顺序归组；空组不显示 */
    LCATS.forEach(function(c) {
      var group = res.servers.filter(function(s){ return (s.cat || 'other') === c[0]; });
      if (!group.length) return;
      /* 默认标：组内第一个启用的（与 defaultForCat 语义一致） */
      var defId = null;
      for (var i = 0; i < group.length; i++) { if (group[i].enabled) { defId = group[i].id; break; } }
      html += '<div class="mk-cg"><div class="mk-cgh">' + c[1] + '</div><div class="mk-cbox">';
      group.forEach(function(s) {
        var on = !!s.enabled;
        html += '<div class="mk-sr' + (on ? '' : ' dis') + '" data-mk-row="' + esc(s.id) + '" data-mk-cat="' + esc(c[0]) + '">'
          + '<div class="mk-stx">'
          + '<div class="mk-snm">' + esc(s.name || s.url || s.id) + (s.id === defId ? '<span class="mk-dft">默认</span>' : '') + '</div>'
          + '<div class="mk-ssu">' + esc(s.desc || s.url || '') + '</div>'
          + '</div>'
          + '<div class="mk-swx' + (s.paid ? ' vip' : '') + (on ? '' : ' off') + '" data-mk-act="toggle" data-mk-id="' + esc(s.id) + '" data-mk-on="' + (on ? '1' : '0') + '"></div>'
          + '</div>';
      });
      html += '</div></div>';
    });
    html += '<div class="mk-addln" onclick="MovMarket.addToggle()">＋ 手动添加 server</div>';
    if (_addOpen) {
      html += '<div class="set-group"><div class="set-sub" style="padding-top:12px">'
        + '<input id="mkAddUrl" placeholder="server_url（如 http://192.168.1.12:3000/mcp）">'
        + '<input id="mkAddToken" placeholder="server_token（可留空）">'
        + '<span class="dact" onclick="MovMarket.addManual()">保存</span>'
        + '<span class="dact" onclick="MovMarket.addToggle()">取消</span>'
        + '</div></div>';
    }
    return html;
  }

  /* ── 操作弹层（点服务行）：测连通 / 复制信息 / 删除 ── */
  function openOps(id) {
    closeOps();
    var res = listServers();
    var s = null;
    res.servers.forEach(function(x){ if (x.id === id) s = x; });
    if (!s) return;
    var mask = document.createElement('div');
    mask.className = 'mk-ops-mask';
    mask.id = 'mkOpsMask';
    var sheet = document.createElement('div');
    sheet.className = 'mk-ops';
    var title = document.createElement('div');
    title.className = 't';
    title.textContent = (s.name || s.url || s.id);
    sheet.appendChild(title);
    var acts = [['test','测连通'],['copy','复制信息'],['remove','删除']];
    acts.forEach(function(a) {
      var b = document.createElement('div');
      b.className = 'a' + (a[0] === 'remove' ? ' del' : '');
      b.textContent = a[1];
      b.addEventListener('click', function() {
        closeOps();
        if (a[0] === 'test') srvTest(id);
        else if (a[0] === 'remove') srvRemove(id);
        else {
          var info = (s.name || '') + '\n' + (s.url || '') + '\n分类:' + (s.cat || 'other') + (s.paid ? ' · 付费购入' : '') + (s.enabled ? ' · 启用中' : ' · 已停用');
          try { B.postCmd({cmd:'clipboard.write', text:info}); toast('已复制'); } catch(e) { toast('复制失败'); }
        }
      });
      sheet.appendChild(b);
    });
    mask.appendChild(sheet);
    mask.addEventListener('click', function(ev){ if (ev.target === mask) closeOps(); });
    var pane = document.getElementById('settingsPane');
    (pane || document.body).appendChild(mask);
  }
  function closeOps() {
    var m = document.getElementById('mkOpsMask');
    if (m) m.parentNode.removeChild(m);
  }

  /* ── 长按拖动排序（组内；顺序即默认） ── */
  var _drag = null;  /* {id, cat, el, startY, ph} */
  function dragBind() {
    var pane = document.getElementById('settingsPane');
    if (!pane || pane._mkDragBound) return;
    pane._mkDragBound = true;
    var holdTimer = null, sx = 0, sy = 0, cand = null;
    pane.addEventListener('touchstart', function(ev) {
      var row = ev.target && ev.target.closest ? ev.target.closest('.mk-sr') : null;
      if (!row || ev.target.closest('.mk-swx')) return;
      cand = row;
      var pt = ev.touches[0]; sx = pt.clientX; sy = pt.clientY;
      holdTimer = setTimeout(function() {
        holdTimer = null;
        _drag = { id: row.getAttribute('data-mk-row'), cat: row.getAttribute('data-mk-cat'), el: row, lastTo: -1 };
        row.classList.add('dragging');
      }, 500);
    }, {passive:true});
    pane.addEventListener('touchmove', function(ev) {
      var pt = ev.touches[0];
      if (holdTimer) {
        if (Math.abs(pt.clientX - sx) > 10 || Math.abs(pt.clientY - sy) > 10) { clearTimeout(holdTimer); holdTimer = null; cand = null; }
        return;
      }
      if (!_drag) return;
      ev.preventDefault();  /* 拖动时锁滚动 */
      var rows = pane.querySelectorAll('.mk-sr[data-mk-cat="' + _drag.cat + '"]');
      var to = 0;
      for (var i = 0; i < rows.length; i++) {
        var r = rows[i].getBoundingClientRect();
        if (pt.clientY > r.top + r.height / 2) to = i + 1;
      }
      /* 拖动行自身也算在内：目标位相对自身修正 */
      var selfIdx = -1;
      for (var j = 0; j < rows.length; j++) if (rows[j] === _drag.el) selfIdx = j;
      if (selfIdx >= 0 && to > selfIdx) to--;
      if (to !== _drag.lastTo) {
        _drag.lastTo = to;
        /* 视觉：其余行让位指示 */
        for (var k = 0; k < rows.length; k++) rows[k].classList.remove('drophere');
        var targetIdx = to >= rows.length - 1 ? rows.length - 1 : (to >= selfIdx ? to + 1 : to);
        if (rows[targetIdx] && rows[targetIdx] !== _drag.el) rows[targetIdx].classList.add('drophere');
      }
    }, {passive:false});
    pane.addEventListener('touchend', function() {
      if (holdTimer) { clearTimeout(holdTimer); holdTimer = null; cand = null; }
      if (!_drag) return;
      var d = _drag; _drag = null;
      var rows = pane.querySelectorAll('.mk-sr');
      for (var k = 0; k < rows.length; k++) rows[k].classList.remove('drophere');
      d.el.classList.remove('dragging');
      if (d.lastTo >= 0) {
        d.el._mkDragged = true;  /* 吞掉 drag 结束后的合成 click，防误开操作弹层 */
        try { B.postCmd({cmd:'mcp.reorder', id:d.id, to:d.lastTo}); } catch(e) {}
        refresh();
      }
    }, {passive:true});
    pane.addEventListener('touchcancel', function() {
      if (holdTimer) { clearTimeout(holdTimer); holdTimer = null; }
      if (_drag) { _drag.el.classList.remove('dragging'); _drag = null; }
    }, {passive:true});
  }

  /* 市场 tab v2（应用商店风）：分类胶囊过滤 + 热销榜横滑 + 列表行 */
  function renderPaid() {
    var html = '<div class="mk-cats">';
    CATS.forEach(function(c) {
      html += '<div class="mk-cat' + (_cat === c[0] ? ' on' : '') + '" onclick="MovMarket.cat(\'' + c[0] + '\')">' + c[1] + '</div>';
    });
    html += '</div>';
    var list = GOODS.filter(function(g){ return _cat === 'all' || g.cat === _cat; });
    if (_cat === 'all') {
      var top = GOODS.filter(function(g){ return g.available !== false; })
        .slice().sort(function(a, b){ return b.soldNum - a.soldNum; }).slice(0, 3);
      html += '<div class="mk-sec"><div class="n">热销榜</div><div class="m">按付款单数 · 每日更新</div></div><div class="mk-rank">';
      top.forEach(function(g, i) {
        html += '<div class="mk-rcard" onclick="MovMarket.openDetail(\'' + g.id + '\')">'
          + '<div class="rk r' + (i + 1) + '">' + (i + 1) + '</div>'
          + '<div class="ric" style="background:' + g.color + '">' + g.icon + '</div>'
          + '<div class="rn">' + esc(g.name) + '</div><div class="rg">' + esc(g.sold) + '</div>'
          + '<div class="rp">' + esc(g.price) + '</div></div>';
      });
      html += '</div>';
    }
    html += '<div class="mk-sec"><div class="n">全部接入包</div><div class="m">' + list.length + ' 件 · 质检出厂</div></div>';
    list.forEach(function(g) {
      html += '<div class="mk-grow" onclick="MovMarket.openDetail(\'' + g.id + '\')">'
        + '<div class="gic" style="background:' + g.color + '">' + g.icon + '</div>'
        + '<div class="gtx"><div class="gn">' + esc(g.name) + '</div><div class="gd">' + esc(g.desc) + '</div>'
        + '<div class="gb"><span class="mkbadge qc">✓ 质检</span><span class="mkbadge src">' + esc(g.type) + '</span></div></div>'
        + '<div class="gact"><div class="gbtn">' + esc(g.price) + '</div><div class="gp">' + esc(g.sold) + '</div></div></div>';
    });
    return html;
  }

  /* 商品详情（说明书 + 质检报告 + 交付方式静态文案；收款码弹层幕一不做） */
  function renderDetail() {
    var g = null;
    GOODS.forEach(function(x) { if (x.id === _detailId) g = x; });
    if (!g) { _detailId = null; return renderPaid(); }
    return '<div class="set-group"><div class="set-row" onclick="MovMarket.closeDetail()"><div class="t">‹ 返回市场</div></div></div>'
      + '<div class="mk-hero"><div class="dname">' + esc(g.name) + '</div>'
      + '<div class="dprice">' + esc(g.price) + ' <small>买断 · 永久使用 · 随包更新</small></div></div>'
      + '<div class="mk-sec">能力说明书（随包附赠 · 工厂 CapabilitySpec）</div>'
      + '<div class="mk-box">' + g.spec + '</div>'
      + '<div class="mk-sec">质检报告（无报告不出厂）</div>'
      + '<div class="mk-box">' + g.report + '</div>'
      + '<div class="mk-sec">交付方式</div>'
      + '<div class="mk-box">' + DELIVERY + '</div>'
      + '<div class="mk-buybar"><div class="bb ghost" onclick="MovMarket.consult()">咨询店家</div>'
      + (g.available === false
        ? '<div class="bb solid" style="opacity:.5;cursor:not-allowed">即将上架</div>'
        : '<div class="bb solid" onclick="MovMarket.buy(\'' + g.id + '\')">立即购买 ' + esc(g.price) + '</div>')
      + '</div>'
      + '<div id="mkPayCard"></div>';
  }

  /* ── 交互 ── */

  function tab(t) { _tab = t; _detailId = null; stopPayTimer(); refresh(); }
  function cat(c) { _cat = c; _detailId = null; stopPayTimer(); refresh(); }
  function openDetail(id) {
    _detailId = id; refresh();
    setTimeout(function(){ try { var p = document.getElementById('settingsPane'); if (p) p.scrollTop = 0; } catch(e) {} }, 40);
  }
  function closeDetail() { _detailId = null; stopPayTimer(); refresh(); }
  function consult() { toast('店家咨询通道施工中，即将上线'); }

  /* ── 付费（工单26 幕二）：cbId 异步桥 + 收款卡 ── */

  /* cbCall：bridge.js 的 nextCbId/_cbMap 全局复用（无则本地兜底） */
  function cbCall(name, args, cb) {
    var b = (typeof HermesBridge !== 'undefined') ? HermesBridge : null;
    if (!b || !b[name]) { cb({ok:false,error:{code:'BRIDGE_UNAVAILABLE',msg:'桥不可用'}}); return; }
    var id = (typeof nextCbId === 'function') ? nextCbId() : ('cb' + Date.now() + '_' + Math.random());
    if (typeof _cbMap !== 'undefined') _cbMap[id] = cb;
    else window._hermesCbFallback = window._hermesCbFallback || {};
    b[name].apply(b, (args || []).concat([id]));
  }

  var _currentOrder = null;    /* {orderId, codeUrl, fen, name} 当前待支付订单 */
  var _payTimer = null;        /* 状态轮询 setInterval */
  var _countTimer = null;      /* 倒计时 setInterval */
  var _payDeadline = 0;        /* 30min 倒计时截止时间戳 */

  /* 卖家/买家侧状态推送（Java MarketEngine.notifyJs） */
  window._mktEvent = function(ev) {
    try {
      if (!ev || !_currentOrder || ev.orderId !== _currentOrder.orderId) return;
      if (ev.state === 'DELIVERED' || ev.state === 'INSTALLED' || ev.state === 'INSTALL_REJECTED'
          || ev.state === 'EXPIRED' || ev.state === 'MANUAL') {
        stopPayTimer();
        renderPayCard();
      }
    } catch(e) {}
  };

  function buy(productId) {
    var g = null;
    GOODS.forEach(function(x){ if (x.id === productId) g = x; });
    if (!g) { toast('商品不存在'); return; }
    if (g.available === false) { toast('该商品即将上架，敬请期待'); return; }
    cbCall('mktBuy', [g.id], function(r) {
      if (!r || !r.ok) {
        var m = (r && r.error && r.error.msg) ? r.error.msg : '下单失败';
        if (r && r.error && r.error.code === 'USER_REJECTED') m = '已取消购买';
        toast(m);
        return;
      }
      _currentOrder = r.data;
      _payDeadline = Date.now() + 30 * 60 * 1000;
      renderPayCard();
      startPayTimer();
      toast('订单已创建，请去支付');
    });
  }

  /* 收款卡：createElement/textContent（禁 innerHTML 拼用户输入） */
  function renderPayCard() {
    var holder = document.getElementById('mkPayCard');
    if (!holder || !_currentOrder) return;
    holder.innerHTML = '';
    var card = document.createElement('div');
    card.className = 'mk-paycard';
    card.style.cssText = 'border:1px solid rgba(0,0,0,.08);border-radius:12px;padding:14px;margin:12px 0;background:var(--card,#fff)';

    var name = document.createElement('div');
    name.className = 'gn';
    name.textContent = _currentOrder.name || '订单';
    card.appendChild(name);

    var amt = document.createElement('div');
    amt.className = 'dprice';
    amt.style.cssText = 'font-size:20px;font-weight:700;margin:6px 0';
    amt.textContent = '¥' + fenText(_currentOrder.fen);
    card.appendChild(amt);

    var stateRow = document.createElement('div');
    stateRow.id = 'mkPayState';
    stateRow.style.cssText = 'font-size:13px;color:var(--ink-3,#888);margin:6px 0';
    card.appendChild(stateRow);

    var countRow = document.createElement('div');
    countRow.id = 'mkPayCount';
    countRow.style.cssText = 'font-size:12px;color:var(--ink-3,#888);margin:4px 0';
    card.appendChild(countRow);

    var bar = document.createElement('div');
    bar.className = 'mk-buybar';
    bar.style.cssText = 'margin-top:10px;display:flex;gap:8px';
    var payBtn = document.createElement('div');
    payBtn.className = 'bb solid';
    payBtn.style.cssText = 'flex:1;text-align:center;padding:10px 0;border-radius:10px;background:var(--accent,#3b82f6);color:#fff;font-weight:600';
    payBtn.textContent = '去支付';
    payBtn.addEventListener('click', goPay);
    var rebuyBtn = document.createElement('div');
    rebuyBtn.className = 'bb ghost';
    rebuyBtn.style.cssText = 'flex:1;text-align:center;padding:10px 0;border-radius:10px;border:1px solid rgba(0,0,0,.15)';
    rebuyBtn.textContent = '重新购买';
    rebuyBtn.addEventListener('click', function() {
      _currentOrder = null; stopPayTimer();
      var g = findGood(_detailId);
      if (g) buy(g.id);
    });
    bar.appendChild(payBtn);
    bar.appendChild(rebuyBtn);
    card.appendChild(bar);
    holder.appendChild(card);

    updatePayState();
    updatePayCount();
  }

  function updatePayState() {
    var el = document.getElementById('mkPayState');
    if (!el || !_currentOrder) return;
    cbCall('mktOrderStatus', [_currentOrder.orderId], function(r) {
      if (!el || !r || !r.ok || !r.data) return;
      var st = r.data.state || '';
      if (st === 'PAYING') el.textContent = '等待支付…';
      else if (st === 'PAID' || st === 'DELIVERED') el.textContent = '已支付，发货中…';
      else if (st === 'INSTALLED') { el.textContent = '✅ 安装完成'; }
      else if (st === 'EXPIRED') el.textContent = '订单已关闭';
      else if (st === 'MANUAL') el.textContent = '订单异常，请稍后重试';
      if (st === 'INSTALLED') {
        stopPayTimer();
        setTimeout(function() { jumpInstalled(); }, 1200);
      }
    });
  }

  function updatePayCount() {
    var el = document.getElementById('mkPayCount');
    if (!el || !_currentOrder) return;
    var left = Math.max(0, Math.floor((_payDeadline - Date.now()) / 1000));
    var mm = String(Math.floor(left / 60)).padStart(2, '0');
    var ss = String(left % 60).padStart(2, '0');
    el.textContent = '支付剩余 ' + mm + ':' + ss;
  }

  function startPayTimer() {
    stopPayTimer();
    _payTimer = setInterval(updatePayState, 5000);
    _countTimer = setInterval(updatePayCount, 1000);
  }
  function stopPayTimer() {
    if (_payTimer) { clearInterval(_payTimer); _payTimer = null; }
    if (_countTimer) { clearInterval(_countTimer); _countTimer = null; }
  }

  function goPay() {
    if (!_currentOrder) return;
    cbCall('mktGoPay', [_currentOrder.orderId], function(r) {
      if (r && r.ok && r.data && r.data.copied) {
        /* E-14 JSAPI：支付页链接已复制，引导微信内打开 */
        toast('支付链接已复制，请打开微信粘贴给「文件传输助手」并点开');
        return;
      }
      if (!r || !r.ok) {
        var m = (r && r.error && r.error.msg) ? r.error.msg : '拉起支付失败';
        toast(m);
      }
    });
  }

  /* 安装完成 → 跳「本地/已安装」页可见 */
  function jumpInstalled() {
    _currentOrder = null;
    _detailId = null;
    _tab = 'free';
    stopPayTimer();
    refresh();
    toast('安装完成，本地页可见');
  }

  function findGood(id) {
    var g = null;
    GOODS.forEach(function(x){ if (x.id === id) g = x; });
    return g;
  }

  function fenText(fen) {
    return String((fen || 0) / 100).replace(/^0+(\d)/, '$1') + (fen % 100 === 0 ? '.00' : '');
  }

  /* 动态行事件绑定（renderSubPage innerHTML 后由 afterSubPage 调用） */
  function bind() {
    var els = document.querySelectorAll('#settingsPane [data-mk-act]');
    for (var i = 0; i < els.length; i++) {
      (function(el){
        el.addEventListener('click', function(ev) {
          ev.stopPropagation();
          var id = el.getAttribute('data-mk-id');
          var act = el.getAttribute('data-mk-act');
          if (act === 'test') srvTest(id);
          else if (act === 'toggle') srvToggle(id, el.getAttribute('data-mk-on') !== '1');
          else if (act === 'remove') srvRemove(id);
        });
      })(els[i]);
    }
    /* 服务行：点行 → 操作弹层；长按 → 拖动排序（dragBind 一次性委托） */
    var rows = document.querySelectorAll('#settingsPane .mk-sr');
    for (var j = 0; j < rows.length; j++) {
      (function(row){
        row.addEventListener('click', function(ev) {
          if (ev.target.closest('.mk-swx')) return;
          if (row._mkDragged) { row._mkDragged = false; return; }
          openOps(row.getAttribute('data-mk-row'));
        });
      })(rows[j]);
    }
    dragBind();
    /* 工单26：详情页重渲染（refresh → renderSubPage → bind）后恢复收款卡 */
    var pc = document.getElementById('mkPayCard');
    if (pc && _currentOrder) { renderPayCard(); startPayTimer(); }
  }

  function srvTest(id) {
    var res = listServers();
    if (res.mock) { toast('示例数据 · 跳过测连通'); return; }
    toast('测试 MCP 连通…');
    try {
      var r = B.postCmd({cmd:'mcp.test', id:id});
      toast(r && r.ok && r.data && r.data.ok ? 'MCP 连接正常' : 'MCP 连接失败');
    } catch(e) { toast('MCP 连接失败'); }
  }

  function srvToggle(id, enable) {
    var res = listServers();
    if (res.mock) {
      var m = findMock(id); if (m) m.enabled = !!enable;
      toast(enable ? '已启用（示例）' : '已停用（示例）');
      refresh(); return;
    }
    try {
      var r = B.postCmd({cmd:'mcp.enable', id:id, enabled:!!enable});
      toast(r && r.ok ? (enable ? '已启用' : '已停用') : '操作失败');
    } catch(e) { toast('操作失败'); }
    refresh();
  }

  function srvRemove(id) {
    var res = listServers();
    if (res.mock) {
      if (_mockList) _mockList = _mockList.filter(function(s){ return s.id !== id; });
      toast('已删除（示例）');
      refresh(); return;
    }
    try {
      var r = B.postCmd({cmd:'mcp.remove', id:id});
      toast(r && r.ok ? '已删除' : '删除失败');
    } catch(e) { toast('删除失败'); }
    refresh();
  }

  function addToggle() { _addOpen = !_addOpen; refresh(); }
  function addManual() {
    var urlEl = document.getElementById('mkAddUrl');
    var tokenEl = document.getElementById('mkAddToken');
    var url = urlEl ? urlEl.value.trim() : '';
    var token = tokenEl ? tokenEl.value.trim() : '';
    if (!url) { toast('先填 server 地址'); return; }
    if (!hasBridge()) { toast('桥不可用，暂不能添加'); return; }
    try {
      var r = B.postCmd({cmd:'mcp.add', url:url, token:token, origin:'manual'});
      if (r && r.ok) { toast('已添加'); _addOpen = false; }
      else toast('添加失败' + (r && r.error && r.error.msg ? '：' + r.error.msg : ''));
    } catch(e) { toast('添加失败'); }
    refresh();
  }

  return {
    render: render, bind: bind, tab: tab, cat: cat,
    openDetail: openDetail, closeDetail: closeDetail,
    buy: buy, consult: consult,
    addToggle: addToggle, addManual: addManual
  };
})();
