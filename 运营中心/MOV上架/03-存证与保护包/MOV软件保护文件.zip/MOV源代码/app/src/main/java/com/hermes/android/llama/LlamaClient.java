package com.hermes.android.llama;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * llama-server 本地 API 客户端核心（纯 JVM 可单测，零网络）——OpenAI 兼容契约。
 * 契约：POST http://127.0.0.1:8080/v1/chat/completions，Bearer token 鉴权。
 * 桥层（Android，cbId 异步）负责实际 HTTP；本类只做 payload 构造/响应解析/错误映射。
 */
public class LlamaClient {

    public static final String BASE_URL = "http://127.0.0.1:8080";
    public static final String DEFAULT_MODEL = "unlimited-ocr";

    /** OpenAI /v1/chat/completions payload 构造（纯 JVM） */
    public static String buildChatPayload(String model, String userText, int maxTokens) {
        try {
            JSONObject body = new JSONObject();
            body.put("model", model != null ? model : DEFAULT_MODEL);
            body.put("messages", new JSONArray()
                    .put(new JSONObject().put("role", "user").put("content", userText != null ? userText : "")));
            body.put("max_tokens", maxTokens > 0 ? maxTokens : 256);
            return body.toString();
        } catch (Exception e) {
            throw new RuntimeException("buildChatPayload", e);
        }
    }

    /** 工单12 幕四: 视觉 payload 构造(纯 JVM) — 图像 base64 → OpenAI 兼容视觉格式
     *  (messages:[{role:user, content:[{type:text},{type:image_url, image_url:{url:"data:image/jpeg;base64,..."}}]}])。
     *  供 llama-server(mtmd 视觉) /v1/chat/completions。 */
    public static String buildVisionPayload(String model, String userText, String imageBase64, int maxTokens) {
        try {
            JSONArray content = new JSONArray();
            if (userText != null && !userText.isEmpty()) {
                content.put(new JSONObject().put("type", "text").put("text", userText));
            }
            content.put(new JSONObject().put("type", "image_url")
                    .put("image_url", new JSONObject()
                            .put("url", "data:image/jpeg;base64," + (imageBase64 != null ? imageBase64 : ""))));
            JSONObject body = new JSONObject();
            body.put("model", model != null ? model : DEFAULT_MODEL);
            body.put("messages", new JSONArray()
                    .put(new JSONObject().put("role", "user").put("content", content)));
            body.put("max_tokens", maxTokens > 0 ? maxTokens : 512);
            return body.toString();
        } catch (Exception e) {
            throw new RuntimeException("buildVisionPayload", e);
        }
    }

    /** 解析 /v1/chat/completions 响应 → choices[0].message.content；无法解析返回 null */
    public static String parseResponse(String raw) {
        if (raw == null) return null;
        try {
            JSONObject o = new JSONObject(raw);
            JSONArray choices = o.optJSONArray("choices");
            if (choices == null || choices.length() == 0) return null;
            JSONObject msg = choices.optJSONObject(0).optJSONObject("message");
            return msg != null ? msg.optString("content", null) : null;
        } catch (Exception e) {
            return null;
        }
    }

    /** 错误映射 → 诚实卡文案（连接失败/鉴权/服务异常） */
    public static String mapError(int httpCode, String body) {
        if (httpCode <= 0) return "OCR 服务连不上（llama-server 未启动）";
        if (httpCode == 401 || httpCode == 403) return "OCR 服务 token 鉴权失败，检查设置页";
        if (httpCode >= 500) return "OCR 服务异常（" + httpCode + "），稍后再试";
        if (httpCode == 400) return "OCR 请求被拒（400），参数或模型名不对";
        return "OCR 请求失败（" + httpCode + "）";
    }
}
