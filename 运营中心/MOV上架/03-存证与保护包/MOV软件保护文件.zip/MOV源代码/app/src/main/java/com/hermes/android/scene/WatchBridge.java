package com.hermes.android.scene;

import android.util.Log;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * 观看历史桥（ConnectWeb WebView 注入）。
 * afterLoad 脚本调 report(json) → filesDir/watch_history.json（100% 端侧，不上传）。
 */
public class WatchBridge {

    private static final String TAG = "WatchBridge";
    private final File historyFile;

    public WatchBridge(File filesDir) {
        this.historyFile = new File(filesDir, "watch_history.json");
    }

    @JavascriptInterface
    public void report(String json) {
        try {
            JSONObject report = new JSONObject(json);
            String title = report.optString("title", "");
            if (title.isEmpty()) return;

            // 读现有
            Map<String, JSONObject> map = load();

            // 按 title 覆盖更新
            JSONObject existing = map.getOrDefault(title, new JSONObject());
            if (report.has("episode")) existing.put("episode", report.optInt("episode"));
            if (report.has("positionMs")) existing.put("positionMs", report.optLong("positionMs"));
            if (report.has("url")) existing.put("url", report.optString("url"));
            existing.put("title", title);
            existing.put("ts", System.currentTimeMillis());
            map.put(title, existing);

            // 写回
            save(map);
            try { Log.d(TAG, "reported: " + title); } catch (Exception ignored) {}
        } catch (Exception e) {
            try { Log.w(TAG, "report failed: " + e.getMessage()); } catch (Exception ignored) {}
        }
    }

    Map<String, JSONObject> load() {  // package-private for test
        Map<String, JSONObject> map = new HashMap<>();
        if (!historyFile.exists()) return map;
        try (BufferedReader r = new BufferedReader(new FileReader(historyFile))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            JSONObject root = new JSONObject(sb.toString());
            java.util.Iterator<String> keys = root.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                map.put(key, root.getJSONObject(key));
            }
        } catch (Exception e) {
            try { Log.w(TAG, "load failed"); } catch (Exception ignored) {}
        }
        return map;
    }

    private void save(Map<String, JSONObject> map) {
        try {
            JSONObject root = new JSONObject();
            for (Map.Entry<String, JSONObject> e : map.entrySet()) {
                root.put(e.getKey(), e.getValue());
            }
            historyFile.getParentFile().mkdirs();
            try (OutputStreamWriter w = new OutputStreamWriter(
                    new FileOutputStream(historyFile), "UTF-8")) {
                w.write(root.toString());
            }
        } catch (Exception ex) {
            try { Log.w(TAG, "save failed"); } catch (Exception ignored) {}
        }
    }
}
