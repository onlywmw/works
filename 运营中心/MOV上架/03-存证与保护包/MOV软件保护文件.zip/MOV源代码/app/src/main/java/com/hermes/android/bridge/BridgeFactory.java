package com.hermes.android.bridge;

import android.webkit.JavascriptInterface;

import com.hermes.android.HermesActivity;

/**
 * Bridge 聚合工厂 — 唯一注入 WebView 的对象。
 * 所有 @JavascriptInterface 方法委托给子 Bridge。
 * JS 侧接口签名不变 (window.HermesBridge.xxx)。
 */
public class BridgeFactory {

    private final HermesActivity activity;
    public HermesActivity getActivity() { return activity; }
    private final BridgeDevice device;
    private final BridgeAi ai;
    private final BridgeFile file;
    private final BridgeSkill skill;
    private final BridgeModel model;
    private final BridgeKernel kernel;
    private final BridgeA2a a2a;
    private final OcrApiBridge ocr;
    private final BridgeVault vault;
    private final BridgeMarket market;

    public BridgeFactory(HermesActivity activity) {
        this.activity = activity;
        device = new BridgeDevice(activity);
        ai = new BridgeAi(activity);
        file = new BridgeFile(activity);
        skill = new BridgeSkill(activity);
        model = new BridgeModel(activity);
        kernel = new BridgeKernel(activity, ai);
        a2a = new BridgeA2a(activity);
        ocr = new OcrApiBridge(activity);
        vault = new BridgeVault(activity);
        market = new BridgeMarket(activity);
    }

    /** P0: MOV Kernel 新桥 (postCmd/query/_movEvent) */
    public BridgeKernel getKernel() { return kernel; }

    /** 工单26: MCP 市场桥（mkt.* cbId 异步） */
    public BridgeMarket getMarket() { return market; }

    // ==================== Market (工单26, cbId 异步, 网络 IO 不进 BridgeKernel) ====================
    @JavascriptInterface public void mktSaveMerchant(String json, String cbId) { market.mktSaveMerchant(json, cbId); }
    @JavascriptInterface public void mktBuy(String productId, String cbId) { market.mktBuy(productId, cbId); }
    @JavascriptInterface public void mktGoPay(String orderId, String cbId) { market.mktGoPay(orderId, cbId); }
    @JavascriptInterface public void mktOrderStatus(String orderId, String cbId) { market.mktOrderStatus(orderId, cbId); }

    // ==================== Device ====================
    @JavascriptInterface public String parseIntent(String text) { return device.parseIntent(text); }
    @JavascriptInterface public String execCommand(String text) { return device.execCommand(text); }
    @McpExpose
    @JavascriptInterface public String getDeviceInfo() { return device.getDeviceInfo(); }
    @McpExpose
    @JavascriptInterface public String getRuntimeStats() { return device.getRuntimeStats(); }
    @McpExpose
    @JavascriptInterface public String getPermissionState() { return device.getPermissionState(); }
    @McpExpose
    @JavascriptInterface public String getWidgetInfo() { return device.getWidgetInfo(); }
    @JavascriptInterface public void openAppSettings() { device.openAppSettings(); }
    @JavascriptInterface public void openUrl(String url) { device.openUrl(url); }
    @JavascriptInterface public String openDeepLink(String url, String pkg) { try { return device.openDeepLink(url, pkg); } catch (Exception e) { return "{\"ok\":false,\"error\":\"" + e.getClass().getSimpleName() + "\"}"; } }
    @McpExpose
    @JavascriptInterface public String douyinStatus() { try { return device.douyinStatus(); } catch (Exception e) { return "{\"ok\":false}"; } }
    @JavascriptInterface public void openDouyinLogin() { try { device.openDouyinLogin(); } catch (Exception ignored) {} }
    @JavascriptInterface public void openDouyinSearch(String keyword) { try { device.openDouyinSearch(keyword); } catch (Exception ignored) {} }
    @McpExpose
    @JavascriptInterface public String connectStatus(String platform) { try { return device.connectStatus(platform); } catch (Exception e) { return "{\"ok\":false}"; } }
    @JavascriptInterface public String removeCookies(String platform) { try { return device.removeCookies(platform); } catch (Exception e) { return "{\"ok\":false}"; } }
    @JavascriptInterface public void openConnectLogin(String platform) { try { device.openConnectLogin(platform); } catch (Exception ignored) {} }
    @JavascriptInterface public void openConnectSearch(String platform, String keyword) { try { device.openConnectSearch(platform, keyword); } catch (Exception ignored) {} }
    @JavascriptInterface public void openConnectUrl(String url, String title) { try { device.openConnectUrl(url, title); } catch (Exception ignored) {} }
    @JavascriptInterface public String startSTT(String cbId) { try { return device.startSTT(cbId); } catch (Exception e) { return "{\"ok\":false}"; } }
    @JavascriptInterface public void speakText(String text) { try { device.speakText(text); } catch (Exception ignored) {} }
    @JavascriptInterface public void openLocalPlayer(String path, String title) { try { device.openLocalPlayer(path, title); } catch (Exception ignored) {} }
    @JavascriptInterface public void browserAction(String actionJson, String cbId) {
        com.hermes.android.ConnectWebActivity cw = com.hermes.android.ConnectWebActivity.getCurrent();
        if (cw != null) { cw.executeBrowserAction(actionJson, cbId); }
        else { activity.evalJsPublic("window._hermesCb('" + cbId + "',{\"error\":\"browser_not_open\",\"recovery\":\"No ConnectWeb activity active.\"})"); }
    }

    // ==================== AI ====================
    @JavascriptInterface public void aiChatAsync(String text, String cbId) { ai.aiChatAsync(text, cbId); }
    @JavascriptInterface public void aiChatAsync(String text, String cbId, String roomId) { ai.aiChatAsync(text, cbId, roomId); }
    @JavascriptInterface public void intentClassifyAsync(String text, String cbId) { ai.intentClassifyAsync(text, cbId); }
    @JavascriptInterface public void faceSearchDramaAsync(String query, String cbId) { ai.faceSearchDramaAsync(query, cbId); }
    @JavascriptInterface public void aiChatWithModel(String text, String modelId, String cbId) { ai.aiChatWithModel(text, modelId, cbId); }
    @JavascriptInterface public void aiChatWithModel(String text, String modelId, String cbId, String roomId) { ai.aiChatWithModel(text, modelId, cbId, roomId); }
    @JavascriptInterface public void agentStart(String goal, String roomId, String modelIdsJson, String cbId) { ai.agentStart(goal, roomId, modelIdsJson, cbId); }
    @JavascriptInterface public void agentStop(String loopId) { ai.agentStop(loopId); }
    @JavascriptInterface public void agentAnswer(String loopId, String text) { ai.agentAnswer(loopId, text); }
    @JavascriptInterface public void agentPlanRespond(String loopId, boolean approved, String note) { ai.agentPlanRespond(loopId, approved, note); }
    @JavascriptInterface public void agentFileWriteRespond(String loopId, boolean approved) { ai.agentFileWriteRespond(loopId, approved); }
    @JavascriptInterface public void agentShellRespond(String loopId, boolean approved) { ai.agentShellRespond(loopId, approved); }
    @JavascriptInterface public void agentResume(String loopId, boolean approved) { ai.agentResume(loopId, approved); }
    @JavascriptInterface public String aiChat(String text) { return ai.aiChat(text); }
    @McpExpose
    @JavascriptInterface public String getAiInfo() { return ai.getAiInfo(); }

    // ==================== File / Storage ====================
    @McpExpose
    @JavascriptInterface public String listWorkFiles(String roomId) { return file.listWorkFiles(roomId); }
    @JavascriptInterface public String saveWorkFile(String roomId, String path, String content, String author) { return file.saveWorkFile(roomId, path, content, author); }
    @McpExpose
    @JavascriptInterface public String listVersions(String roomId, String path) { return file.listVersions(roomId, path); }
    @JavascriptInterface public String restoreVersion(String roomId, String path, String snapshotName) { return file.restoreVersion(roomId, path, snapshotName); }
    @McpExpose
    @JavascriptInterface public String listInboxFiles(String roomId) { return file.listInboxFiles(roomId); }
    @McpExpose
    @JavascriptInterface public String listArchiveFiles(String roomId) { return file.listArchiveFiles(roomId); }
    @JavascriptInterface public String writeArchive(String roomId, String source, String content) { return file.writeArchive(roomId, source, content); }
    @JavascriptInterface public String deleteWorkFile(String roomId, String path) { return file.deleteWorkFile(roomId, path); }
    @JavascriptInterface public String deleteInboxFile(String roomId, String path) { return file.deleteInboxFile(roomId, path); }
    @JavascriptInterface public String deleteArchiveFile(String roomId, String path) { return file.deleteArchiveFile(roomId, path); }
    @JavascriptInterface public String initRoomStorage(String roomId) { return file.initRoomStorage(roomId); }
    @McpExpose
    @JavascriptInterface public String getRoomMeta(String roomId) { return file.getRoomMeta(roomId); }
    @McpExpose
    @JavascriptInterface public String listNotes() { return file.listNotes(); }
    @JavascriptInterface public String saveNote(String name, String content) { return file.saveNote(name, content); }
    @McpExpose
    @JavascriptInterface public String readNote(String name) { return file.readNote(name); }
    @JavascriptInterface public String deleteNote(String name) { return file.deleteNote(name); }
    @JavascriptInterface public String appendChatMessage(String roomId, String messageJson) { return file.appendChatMessage(roomId, messageJson); }
    @McpExpose
    @JavascriptInterface public String loadChatMessages(String roomId, String date) { return file.loadChatMessages(roomId, date); }
    @JavascriptInterface public String writeFile(String roomId, String path, String content) { return file.writeFile(roomId, path, content); }
    @JavascriptInterface public String readFile(String roomId, String path) { return file.readFile(roomId, path); }
    @JavascriptInterface public String deleteFile(String roomId, String path) { return file.deleteFile(roomId, path); }
    @McpExpose
    @JavascriptInterface public String listRoomFiles(String roomId, String subPath) { return file.listRoomFiles(roomId, subPath); }
    @JavascriptInterface public String initRoom(String roomId, String name, String description, String membersJson) { return file.initRoom(roomId, name, description, membersJson); }
    @JavascriptInterface public void pickFile(String cbId, String roomId) { file.pickFile(cbId, roomId); }
    @JavascriptInterface public String pinFileShortcut(String roomId, String path, String label) { return file.pinFileShortcut(roomId, path, label); }
    /* 打包成应用: 签名耗时, 走 testModel 同款后台线程 + 回调 */
    @JavascriptInterface public void buildApk(String roomId, String path, String appName, String cbId) {
        activity.getAiExecutor().execute(() -> {
            String r = file.buildApk(roomId, path, appName);
            activity.evalJsPublic("window._hermesCb('" + cbId + "'," + r + ")");
        });
    }
    /* 一键安装: 房间产出 APK → 系统安装器 */
    @JavascriptInterface public String installApk(String roomId, String path) { return file.installApk(roomId, path); }

    // ==================== Skill ====================
    @McpExpose
    @JavascriptInterface public String listSkills() { return skill.listSkills(); }
    @JavascriptInterface public String addSkill(String skillJson) { return skill.addSkill(skillJson); }
    @JavascriptInterface public String promoteReadySkills() { return skill.promoteReadySkills(); }
    @JavascriptInterface public String recordSkillUse(String skillId) { return skill.recordSkillUse(skillId); }
    @JavascriptInterface public String deleteSkill(String skillId) { return skill.deleteSkill(skillId); }

    // ==================== Model ====================
    @McpExpose
    @JavascriptInterface public String listModels() { return model.listModels(); }
    @McpExpose
    @JavascriptInterface public String getProviderPresets() { return model.getProviderPresets(); }
    @JavascriptInterface public String addModel(String json) { return model.addModel(json); }
    @JavascriptInterface public String updateModel(String json) { return model.updateModel(json); }
    @JavascriptInterface public String deleteModel(String id) { return model.deleteModel(id); }
    @JavascriptInterface public String setDefaultModel(String id) { return model.setDefaultModel(id); }
    /* TC-M09: 异步两参版 (bridge.js 回调式调用); 替换原一参同步版 — 同名 @JavascriptInterface 不可重载 */
    @JavascriptInterface public void testModel(String json, String cbId) {
        activity.getAiExecutor().execute(() -> {
            String r = model.testModel(json);
            activity.evalJsPublic("window._hermesCb('" + cbId + "'," + r + ")");
        });
    }
    @McpExpose
    @JavascriptInterface public String getEncStatus() { return model.getEncStatus(); }
    @McpExpose
    @JavascriptInterface public String getTokenStats() { return model.getTokenStats(); }

    // ==================== 基础 ====================
    @JavascriptInterface
    public void toast(final String message) {
        activity.runOnUiThread(() ->
            android.widget.Toast.makeText(activity, message, android.widget.Toast.LENGTH_SHORT).show());
    }

    /* 派单№9: openAiSettings 已删 (原生设置页退役, 系统级设置迁新脸抽屉技术区块) */

    /* M3: 打开交互式终端 (内嵌 Ubuntu, rootfs 未就绪时终端内给引导) */
    @JavascriptInterface
    public void openTerminal() {
        activity.runOnUiThread(() ->
            activity.startActivity(new android.content.Intent(activity,
                com.hermes.android.TerminalActivity.class)));
    }

    /* M-ARCH-ENV: 创建房间时真实初始化 Linux 环境 (异步: 预热+工具链实测+写元数据) */
    @JavascriptInterface
    public void prepareRoomEnv(String roomId, String callbackId) {
        new Thread(() -> {
            String result;
            com.hermes.android.linux.RoomEnv.Result r =
                    com.hermes.android.linux.RoomEnv.prepare(activity, roomId);
            try {
                org.json.JSONObject o = new org.json.JSONObject()
                        .put("ok", r.ok)
                        .put("needInstall", r.needInstall)
                        .put("error", r.error)
                        .put("durationMs", r.durationMs);
                if (r.ok) o.put("env", r.env);
                result = o.toString();
            } catch (Exception e) {
                result = "{\"ok\":false,\"error\":\"环境初始化异常\"}";
            }
            activity.evalJsPublic("window._hermesCb('" + callbackId + "'," + result + ")");
        }, "room-env-prep").start();
    }

    /* 读房间环境元数据 (room.json env 段) */
    @JavascriptInterface
    public String getRoomEnv(String roomId) {
        return activity.getStorageManager().readRoomEnv(roomId);
    }

    /* M4: 部署服务器配置 (读[脱敏]/写/测试连接; 密钥加密存储) */
    @JavascriptInterface
    public String getDeployConfig() {
        com.hermes.android.linux.DeployConfig d =
                new com.hermes.android.linux.DeployConfig(activity);
        org.json.JSONObject r = new org.json.JSONObject();
        try {
            r.put("host", d.host).put("port", d.port).put("user", d.user)
             .put("authType", d.authType)
             .put("secretMasked", com.hermes.android.linux.DeployConfig.maskSecret(d.secret))
             .put("configured", d.isConfigured());
        } catch (Exception ignored) {}
        return r.toString();
    }

    @JavascriptInterface
    public String saveDeployConfig(String json) {
        try {
            org.json.JSONObject o = new org.json.JSONObject(json);
            com.hermes.android.linux.DeployConfig d =
                    new com.hermes.android.linux.DeployConfig(activity);
            d.host = o.optString("host", d.host);
            d.port = o.optInt("port", d.port);
            d.user = o.optString("user", d.user);
            d.authType = o.optString("authType", d.authType);
            if (o.has("secret")) d.secret = o.optString("secret");
            d.save(activity);
            return "{\"ok\":true,\"configured\":" + d.isConfigured() + "}";
        } catch (Exception e) {
            return "{\"ok\":false}";
        }
    }

    @JavascriptInterface
    public void testDeployConnection(String callbackId) {
        new Thread(() -> {
            String result;
            com.hermes.android.linux.DeployConfig d =
                    new com.hermes.android.linux.DeployConfig(activity);
            if (!d.isConfigured()) {
                result = "{\"ok\":false,\"content\":\"未配置部署服务器\"}";
            } else if (!com.hermes.android.linux.RootfsManager.isReady(activity)) {
                result = "{\"ok\":false,\"content\":\"Linux 环境未就绪\"}";
            } else {
                com.hermes.android.linux.ProotRunner.ExecResult r =
                        com.hermes.android.linux.ProotRunner.exec(activity,
                                com.hermes.android.linux.DeployConfig.buildTestCmd(), 30);
                boolean ok = r.exitCode == 0 && r.stdout.contains("MOV_SSH_OK");
                try {
                    result = new org.json.JSONObject().put("ok", ok)
                            .put("content", ok ? "连接成功: " + d.user + "@" + d.host
                                    : "exit=" + r.exitCode + " "
                                            + (r.stderr.isEmpty() ? r.stdout : r.stderr)
                                                      .trim()).toString();
                } catch (Exception e) {
                    result = "{\"ok\":false,\"content\":\"测试异常\"}";
                }
            }
            activity.evalJsPublic("window._hermesCb('" + callbackId + "'," + result + ")");
        }).start();
    }

    @JavascriptInterface
    public void setRoomOpen(String roomId) {
        activity.setRoomOpenPublic(roomId != null && !roomId.isEmpty());
    }

    /* 内嵌 Hermes: 触发安装/重装 (与设置页按钮同路径) + 状态查询 */
    @JavascriptInterface
    public String hermesInstall() {
        new com.hermes.android.linux.HermesInstaller(activity).install();
        return "{\"ok\":true}";
    }

    @JavascriptInterface
    public String hermesStatus() {
        com.hermes.android.linux.HermesInstaller h =
                new com.hermes.android.linux.HermesInstaller(activity);
        return "{\"ready\":" + h.isReady() + ",\"state\":\"" + h.getState() + "\"}";
    }

    /** P2 配置入口：MCP 写工具显式开关（默认关闭；补齐 G6 缺口——设置页/调试可调用，写工具才出现 tools/list） */
    @JavascriptInterface
    public void setMcpWriteEnabled(boolean enabled) {
        com.hermes.android.agent.HermesServeConfig.setMcpWriteEnabled(activity, enabled);
    }

    /** P2 配置/调试：返回 serve token（本机鉴权；设置页/真机验收用。serve daemon 未触发时省去 environ 读取） */
    @JavascriptInterface
    public String getServeToken() {
        return com.hermes.android.agent.HermesServeConfig.token(activity);
    }

    /**
     * serve daemon 手动启动（serve 完整链路真机证据：绕过 AgentLoop 编排，直接在内嵌 Linux
     * nohup 启动 hermes mov-serve）。token 经 ProotRunner env 注入（X_MOV_TOKEN），与 HeavyWorker
     * 懒启动同源（HeavyWorker.SERVE_CMD）；失败返回 ok:false + 原因。
     */
    @JavascriptInterface
    public String startServe() {
        String token = com.hermes.android.agent.HermesServeConfig.token(activity);
        String cmd = "kill $(cat /exchange/mov-serve.pid 2>/dev/null) 2>/dev/null; sleep 1; "
                + "~/.hermes-venv/bin/hermes mov-serve";
        try {
            Process p = com.hermes.android.linux.ProotRunner.startDaemon(activity, cmd, token);
            return "{\"started\":" + (p != null) + "}";
        } catch (Exception e) {
            return "{\"ok\":false,\"error\":\"" + e.getMessage() + "\"}";
        }
    }

    @McpExpose
    @JavascriptInterface
    public void log(String message) {
        android.util.Log.d("MOV", message);
    }

    // ==================== Kernel (P0: MOV Kernel 新桥) ====================

    /** P0: JS→Java 命令信号 (CONTRACT: Envelope §2.1) */
    @JavascriptInterface public String postCmd(String json) { String g = BridgeGuard.check("postCmd", json); if(g != null) return g; return kernel.postCmd(json); }

    /** P0: JS→Java 只读查询 (CONTRACT: Envelope §2.2) */
    @McpExpose
    @JavascriptInterface public String query(String json) { String g = BridgeGuard.check("query", json); if(g != null) return g; return kernel.query(json); }

    // ==================== Vault (P5 双副本保险柜, cbId 异步) ====================
    @JavascriptInterface public void vaultList(String cbId) { vault.vaultList(cbId); }
    @JavascriptInterface public void vaultLock(String name, String text, String cbId) { vault.vaultLock(name, text, cbId); }
    @JavascriptInterface public void vaultUnlock(String id, String cbId) { vault.vaultUnlock(id, cbId); }
    @JavascriptInterface public void vaultDelete(String id, String cbId) { vault.vaultDelete(id, cbId); }

    // ==================== A2A ====================
    @McpExpose
    @JavascriptInterface public String a2aDeviceId() { return a2a.getDeviceId(); }
    @McpExpose
    @JavascriptInterface public boolean a2aRegistered() { return a2a.isRegistered(); }
    @JavascriptInterface public void a2aRegister(String deviceId, String name, String cbId) { a2a.a2aRegister(deviceId, name, cbId); }
    @JavascriptInterface public void a2aRegisterPro(String deviceId, String name, String role, String professions, String cbId) { a2a.a2aRegister(deviceId, name, role, professions, cbId); }
    @JavascriptInterface public void a2aQueryPro(String craft, int radiusKm, boolean online, String cbId) { a2a.a2aQueryPro(craft, radiusKm, online, cbId); }
    @JavascriptInterface public void wfRunManual(String workflowId) { com.hermes.android.workflow.Workflows w = com.hermes.android.workflow.Workflows.get(); if (w != null) w.wfRunManual(workflowId); }
    @JavascriptInterface public void ocrChat(String text, String cbId) { ocr.ocrChat(text, cbId); }
    @McpExpose
    @JavascriptInterface public String listLocalModels() { return ocr.listLocalModels(); }
    @JavascriptInterface public String deleteLocalModel(String name) { return ocr.deleteLocalModel(name); }
    @JavascriptInterface public void a2aPairRequest(String cbId) { a2a.a2aPairRequest(cbId); }
    @JavascriptInterface public void a2aPairAccept(String code, String cbId) { a2a.a2aPairAccept(code, cbId); }
    @McpExpose
    @JavascriptInterface public void a2aPeers(String cbId) { a2a.a2aPeers(cbId); }
    @JavascriptInterface public void a2aSend(String toId, String type, String payload, String cbId) { a2a.a2aSend(toId, type, payload, cbId); }
    @JavascriptInterface public void a2aOpenMerchant() { a2a.a2aOpenMerchant(); }
    @McpExpose
    @JavascriptInterface public String a2aGetRelay() { return a2a.getRelayUrl(); }
    @JavascriptInterface public void a2aSetRelay(String url) { a2a.setRelayUrl(url); }
    @JavascriptInterface public void a2aStartPolling() { a2a.a2aStartPolling(); }
    @JavascriptInterface public void a2aStopPolling() { a2a.a2aStopPolling(); }
    @JavascriptInterface public String a2aLoadMenu() { return a2a.a2aLoadMenu(); }
    @JavascriptInterface public String a2aSaveMenu(String json) { return a2a.a2aSaveMenu(json); }
}
