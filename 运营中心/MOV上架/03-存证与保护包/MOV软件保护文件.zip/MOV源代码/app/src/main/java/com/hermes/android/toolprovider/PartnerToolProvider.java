package com.hermes.android.toolprovider;

import android.content.Context;

import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.agent.ToolRegistry.Manifest;
import com.hermes.android.agent.ToolRegistry.ParamDef;
import com.hermes.android.agent.ToolRegistry.Result;
import com.hermes.android.agent.ToolRegistry.Tool;
import com.hermes.android.partner.PartnerClient;
import com.hermes.android.partner.PartnerConfig;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * PartnerToolProvider — 微信支付服务商特约商户进件三工具（DESIGN_WXPAY_APPLYMENT §五）。
 * MOV 只做资料收集与转发，私钥在后端 partner-server；未配置服务器/token 时 NOT_CONFIGURED 拦截。
 * submit 为高风险写入（approval=plan 走计划审批闸 + Manifest risk=high）。
 * 红线：申请单含商户敏感资料，工具返回文本不得回显明文敏感字段；日志/ journal 同禁。
 */
public class PartnerToolProvider implements ToolRegistry.ToolProvider {

    private static Context appContext;

    public static void init(Context ctx) { appContext = ctx.getApplicationContext(); }

    @Override public String id() { return "partner"; }

    /** 可测核心：拿客户端；未配置 → null（单测可注入 fake transport 的 client） */
    PartnerClient clientOrNull() {
        if (appContext == null) return null;
        return new PartnerConfig(appContext).clientOrNull();
    }

    private Result notConfigured() {
        return new Result(false, "进件后端未配置：请先在设置-特约商户进件页填写服务器地址和访问令牌")
                .withReason("NOT_CONFIGURED");
    }

    @Override
    public List<Tool> discover() {
        List<Tool> list = new ArrayList<>();

        // ═══ wxpay.applyment.submit — 提交进件申请单 ═══
        list.add(new Tool("wxpay.applyment.submit",
            "提交微信支付特约商户进件申请单（服务商帮商家入驻）。参数为微信文档六大块完整 JSON"
            + "（business_code/contact_info/subject_info/business_info/settlement_info/bank_account_info），"
            + "敏感字段明文上送自家后端，由后端用微信支付公钥加密。成功后返回 applyment_id",
            null, a -> {
                PartnerClient client = clientOrNull();
                if (client == null) return notConfigured();
                JSONObject applyment = a.optJSONObject("applyment");
                if (applyment == null) return new Result(false, "applyment 对象不能为空");
                PartnerClient.Resp r = client.submitApplyment(applyment);
                if (!r.ok) return new Result(false, "提交失败 [" + r.code + "] " + r.msg);
                long id = r.data != null ? r.data.optLong("applyment_id", -1) : -1;
                return new Result(true, "申请单已提交，微信支付申请单号 applyment_id=" + id
                        + "（可用 wxpay.applyment.query 按 business_code 查询审核状态）");
            }, "native", "write", "plan", false, 60, "exec",
            new ParamDef[]{
                new ParamDef("applyment", "object", true, "微信进件文档六大块结构", "申请单完整 JSON（敏感字段明文，后端加密）"),
            },
            "成功: applyment_id | 失败: [错误码] 原因（PROCESSING=已有进行中申请单）",
            null,
            new String[]{
                "business_code 必须服务商侧唯一，重复提交会报 PROCESSING",
                "图片字段必须先 wxpay.applyment.upload_media 拿 media_id 再填入",
                "不支持个人小微商户进件",
            }, 60000,
            new Manifest("提交进件申请单", "high", "向微信支付提交商家入驻申请（含商户敏感资料）", false, "exec"),
            () -> clientOrNull() == null ? "进件后端未配置" : null));

        // ═══ wxpay.applyment.query — 查询申请单状态 ═══
        list.add(new Tool("wxpay.applyment.query",
            "按 business_code 查询特约商户进件申请单审核状态（APPLYMENT_STATE_EDITING/AUDITING/REJECTED/FINISHED 等）",
            null, a -> {
                PartnerClient client = clientOrNull();
                if (client == null) return notConfigured();
                String code = a.optString("business_code", "").trim();
                if (code.isEmpty()) return new Result(false, "business_code 不能为空");
                PartnerClient.Resp r = client.queryApplyment(code);
                if (!r.ok) return new Result(false, "查询失败 [" + r.code + "] " + r.msg);
                return new Result(true, "申请单状态: " + (r.data == null ? "{}" : r.data.toString()));
            }, "native", "readonly", "always", false, 30, "exec",
            new ParamDef[]{
                new ParamDef("business_code", "string", true, "提交时的业务申请编号", "服务商自定义唯一编号"),
            },
            "申请单状态 JSON（applyment_state / reject_reason / sign_url 等）",
            null, null, 30000,
            new Manifest("查询进件状态", "low", "查询商家入驻申请单审核进度", false, "exec"),
            () -> clientOrNull() == null ? "进件后端未配置" : null));

        // ═══ wxpay.applyment.upload_media — 上传图片拿 media_id ═══
        list.add(new Tool("wxpay.applyment.upload_media",
            "上传进件资料图片（营业执照/证件照/门店照等，JPG/BMP/PNG）到微信支付，返回 media_id 填入申请单对应字段",
            null, a -> {
                PartnerClient client = clientOrNull();
                if (client == null) return notConfigured();
                String path = a.optString("path", "").trim();
                if (path.isEmpty()) return new Result(false, "path 不能为空");
                File f = new File(path);
                PartnerClient.Resp r = client.uploadMedia(f);
                if (!r.ok) return new Result(false, "上传失败 [" + r.code + "] " + r.msg);
                String mediaId = r.data != null ? r.data.optString("media_id", "") : "";
                if (mediaId.isEmpty()) return new Result(false, "上传成功但应答缺 media_id");
                return new Result(true, "已上传，media_id=" + mediaId, mediaId);
            }, "native", "write", "always", false, 60, "media",
            new ParamDef[]{
                new ParamDef("path", "string", true, "本地图片绝对路径", "可先用 camera.capture 拍照拿路径"),
            },
            "成功: media_id | 失败: [错误码] 原因",
            null,
            new String[]{"微信限制图片类型 JPG/BMP/PNG，其他格式会被拒"},
            60000,
            new Manifest("上传进件图片", "low", "上传商户资料图片到微信支付", false, "media"),
            () -> clientOrNull() == null ? "进件后端未配置" : null));

        return list;
    }
}
