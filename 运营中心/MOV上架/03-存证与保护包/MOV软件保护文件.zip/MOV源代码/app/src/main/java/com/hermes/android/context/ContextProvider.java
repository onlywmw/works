package com.hermes.android.context;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.util.Log;

import org.json.JSONObject;

import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 设备情境传感器中枢 — 快照 API + 4 族状态转移事件 + 端侧落盘。
 *
 * <h3>定位（Phase 3 地基）</h3>
 * <pre>{@code
 *   ContextProvider（本轮建）
 *     ├─→ workflows 引擎（v2，trigger/condition 都读它）
 *     ├─→ 支付闸（Phase 3B，用户在场/设备解锁判断）
 *     └─→ AgentLoop 情境注入（后续联合任务）
 * }</pre>
 *
 * <h3>设计原则</h3>
 * <ul>
 *   <li><b>trigger 读时间导数，condition 读瞬时值</b>——共享同一套 SensorSource</li>
 *   <li><b>零消费者 = 零 receiver</b>——电池卫生铁律</li>
 *   <li><b>阈值过渡追踪</b>——battery 只在穿越阈值线时触发，不持续触发</li>
 *   <li><b>100% 端侧</b>——所有数据留在应用私有目录</li>
 * </ul>
 *
 * <h3>使用方式</h3>
 * <pre>{@code
 *   ContextProvider cp = new ContextProvider(ctx, source, persister);
 *   cp.start();
 *   ContextSnapshot snap = cp.snapshot();
 *   cp.subscribe(listener, ContextEventType.WIFI_CONNECTED, ...);
 *   cp.addBatteryListener(listener, 20, false); // BATTERY_BELOW 20%
 *   // ...
 *   cp.stop();
 * }</pre>
 */
public class ContextProvider {

    private final Context appCtx;
    private final SensorSource source;
    private final ContextPersister persister;

    // -- cached state for transition detection ---------------------------------
    private volatile String lastWifiSsid;
    private volatile boolean lastWifiConnected;
    private volatile boolean lastIsCharging;
    private volatile Integer lastBatteryLevel;

    // -- subscriber management -------------------------------------------------
    /** listener → subscribed event types (immutable once set, replaced on re-subscribe) */
    private final Map<TransitionListener, Set<ContextEventType>> listeners = new ConcurrentHashMap<>();
    /** threshold → listeners for BATTERY_BELOW */
    private final Map<Integer, List<TransitionListener>> belowThresholds = new ConcurrentHashMap<>();
    /** threshold → listeners for BATTERY_ABOVE */
    private final Map<Integer, List<TransitionListener>> aboveThresholds = new ConcurrentHashMap<>();

    // -- receiver state --------------------------------------------------------
    private final Object receiverLock = new Object();
    private ConnectivityManager.NetworkCallback wifiCallback;
    private BroadcastReceiver screenReceiver;
    private BroadcastReceiver batteryReceiver;

    // -- lifecycle -------------------------------------------------------------
    private final AtomicBoolean started = new AtomicBoolean(false);
    private ExecutorService executor;

    /**
     * @param appCtx    Application Context。为 null 时不注册 receiver（测试模式）。
     * @param source    传感器数据源（生产：SensorSourceImpl；测试：fake）。
     * @param persister 端侧落盘器。
     */
    public ContextProvider(Context appCtx, SensorSource source, ContextPersister persister) {
        this.appCtx = appCtx != null ? appCtx.getApplicationContext() : null;
        this.source = source;
        this.persister = persister;
    }

    // -- lifecycle -------------------------------------------------------------

    /** 启动传感器层：采集初始快照、落盘、恢复缓存状态 */
    public void start() {
        if (!started.compareAndSet(false, true)) return;
        executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "ContextProvider");
            t.setDaemon(true);
            return t;
        });
        // 采集初始快照
        ContextSnapshot initial = capture();
        this.snap = initial;
        persister.writeSnapshot(initial);
        lastWifiSsid = initial.wifiSsid;
        lastWifiConnected = initial.wifiSsid != null;
        lastIsCharging = initial.isCharging;
        lastBatteryLevel = initial.batteryLevel;
        // 按现有订阅决定是否注册 receiver
        reconcileReceivers();
    }

    /** 停止传感器层：注销所有 receiver、flush 落盘、释放线程池 */
    public void stop() {
        if (!started.compareAndSet(true, false)) return;
        unregisterAllReceivers();
        if (executor != null) {
            executor.shutdown();
            executor = null;
        }
    }

    // -- snapshot API ----------------------------------------------------------

    /** 采集当前设备情境快照（同步读 SensorSource，可随时调用） */
    public ContextSnapshot snapshot() {
        return capture();
    }

    // -- subscription API ------------------------------------------------------

    /**
     * 订阅转移事件。可多次调用以追加类型（合并，非替换）。
     * 当第一个订阅者注册某族事件时，自动注册对应 BroadcastReceiver。
     */
    public void subscribe(TransitionListener listener, ContextEventType first,
                          ContextEventType... rest) {
        Set<ContextEventType> types = listeners.computeIfAbsent(listener,
                k -> EnumSet.noneOf(ContextEventType.class));
        types.add(first);
        for (ContextEventType t : rest) types.add(t);
        reconcileReceivers();
    }

    /**
     * 订阅电量阈值转移事件。
     * @param listener  回调
     * @param threshold 阈值百分比 1..100
     * @param above     true=BATTERY_ABOVE（升穿），false=BATTERY_BELOW（降穿）
     */
    public void addBatteryListener(TransitionListener listener, int threshold, boolean above) {
        Map<Integer, List<TransitionListener>> map = above ? aboveThresholds : belowThresholds;
        map.computeIfAbsent(threshold, k -> new CopyOnWriteArrayList<>()).add(listener);
        reconcileReceivers();
    }

    /** 移除指定监听器的所有订阅（含电量阈值订阅）。无订阅时自动注销 receivers。 */
    public void unsubscribe(TransitionListener listener) {
        listeners.remove(listener);
        for (List<TransitionListener> l : belowThresholds.values()) l.remove(listener);
        for (List<TransitionListener> l : aboveThresholds.values()) l.remove(listener);
        reconcileReceivers();
    }

    // -- test injection (package-private, 不走 receiver/executor, 直调生产路径) ---
    // 测试用：fake SensorSource 改了值后调这些方法，触发完整的 on*Changed() →
    // 过渡判断 → fire → listener 回调。变异测试删穿越条件后必须红。

    void injectWifiEvent() {
        ContextSnapshot current = capture();
        // 测试路径从快照推断连/断（fake sensor 保证同步）;
        // 生产路径 callback 直接传 boolean，不靠快照
        onWifiChanged(current, current.wifiSsid != null);
    }

    void injectPowerEvent(boolean connected) {
        ContextSnapshot current = capture();
        handlePowerEvent(current, connected);
    }

    void injectScreenEvent(boolean on) {
        ContextSnapshot current = capture();
        handleScreenEvent(current, on);
    }

    void injectBatteryEvent() {
        ContextSnapshot current = capture();
        onBatteryChanged(current);
    }

    // -- diagnostics -----------------------------------------------------------

    /** 当前活跃的 receiver 数量（用于验收：零消费者时 dumpsys 看不到多余注册） */
    public int getActiveReceiverCount() {
        int count = 0;
        synchronized (receiverLock) {
            if (wifiCallback != null) count++;
            if (screenReceiver != null) count++;
            if (batteryReceiver != null) count++;
        }
        return count;
    }

    /** 当前已订阅的监听器总数（含电量阈值订阅） */
    public int getListenerCount() {
        int count = listeners.size();
        for (List<TransitionListener> l : belowThresholds.values()) count += l.size();
        for (List<TransitionListener> l : aboveThresholds.values()) count += l.size();
        return count;
    }

    // -- internal: snapshot capture --------------------------------------------

    private ContextSnapshot capture() {
        return new ContextSnapshot.Builder()
                .wifiSsid(source.getWifiSsid())
                .batteryLevel(source.getBatteryLevel())
                .isCharging(source.isCharging())
                .screenOn(source.isScreenOn())
                .foregroundApp(source.getForegroundApp())
                .capturedAtMs(System.currentTimeMillis())
                .build();
    }

    // -- internal: receiver reconciliation -------------------------------------

    private void reconcileReceivers() {
        if (!started.get() || appCtx == null) return;

        boolean needWifi = hasAnyType(ContextEventType.WIFI_CONNECTED, ContextEventType.WIFI_DISCONNECTED);
        boolean needScreen = hasAnyType(ContextEventType.SCREEN_ON, ContextEventType.SCREEN_OFF);
        // battery receiver 同时服务阈值过渡和充电状态过渡（POWER_CONNECTED/DISCONNECTED）
        boolean needBattery = !belowThresholds.isEmpty() || !aboveThresholds.isEmpty()
                || hasAnyType(ContextEventType.POWER_CONNECTED, ContextEventType.POWER_DISCONNECTED);

        synchronized (receiverLock) {
            reconcileWifi(needWifi);
            reconcileScreen(needScreen);
            reconcileBattery(needBattery);
        }
    }

    private boolean hasAnyType(ContextEventType... types) {
        for (ContextEventType t : types) {
            for (Set<ContextEventType> s : listeners.values()) {
                if (s.contains(t)) return true;
            }
        }
        return false;
    }

    // -- wifi family (ConnectivityManager.NetworkCallback, callback 自带语义判连/断) ---

    private void reconcileWifi(boolean need) {
        if (need && wifiCallback == null) {
            wifiCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    logd("wifi: onAvailable");
                    ContextSnapshot snap = capture();
                    executor.execute(() -> onWifiChanged(snap, true));
                }
                @Override
                public void onLost(Network network) {
                    logd("wifi: onLost");
                    ContextSnapshot snap = capture();
                    executor.execute(() -> onWifiChanged(snap, false));
                }
            };
            ConnectivityManager cm = (ConnectivityManager) appCtx.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkRequest request = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .build();
            cm.registerNetworkCallback(request, wifiCallback);
            logd("wifi: NetworkCallback registered");
        } else if (!need && wifiCallback != null) {
            ConnectivityManager cm = (ConnectivityManager) appCtx.getSystemService(Context.CONNECTIVITY_SERVICE);
            cm.unregisterNetworkCallback(wifiCallback);
            wifiCallback = null;
            logd("wifi: NetworkCallback unregistered");
        }
    }

    /** @param connected callback 自带语义——onAvailable=true/onLost=false，不靠 capture().wifiSsid */
    private void onWifiChanged(ContextSnapshot current, boolean connected) {
        this.snap = current;
        if (connected && !lastWifiConnected) {
            ContextSnapshot before = this.snap.derive().wifiSsid(lastWifiSsid).capturedAtMs(System.currentTimeMillis()).build();
            fire(ContextEventType.WIFI_CONNECTED, before, current, null);
            logd("wifi: fired CONNECTED ssid=" + current.wifiSsid);
        } else if (!connected && lastWifiConnected) {
            ContextSnapshot before = this.snap.derive().wifiSsid(lastWifiSsid).capturedAtMs(System.currentTimeMillis()).build();
            fire(ContextEventType.WIFI_DISCONNECTED, before, current, null);
            logd("wifi: fired DISCONNECTED (was " + lastWifiSsid + ")");
        }
        lastWifiConnected = connected;
        if (current.wifiSsid != null) lastWifiSsid = current.wifiSsid;
    }

    // -- power family (并入 battery receiver, 靠 isCharging 过渡追踪, 不靠 ACTION_POWER_*) ---
    // dumpsys battery set 在某些 ROM 上不发 ACTION_POWER_CONNECTED/DISCONNECTED,
    // 改走 BATTERY_CHANGED 的充电状态过渡——与 battery 阈值同 receiver, 不会死信。

    void handlePowerEvent(ContextSnapshot current, boolean connected) {
        this.snap = current;
        if (connected && !lastIsCharging) {
            ContextSnapshot before = current.derive().isCharging(false).capturedAtMs(System.currentTimeMillis()).build();
            fire(ContextEventType.POWER_CONNECTED, before, current, null);
            lastIsCharging = true;
            logd("power: fired CONNECTED");
        } else if (!connected && lastIsCharging) {
            ContextSnapshot before = current.derive().isCharging(true).capturedAtMs(System.currentTimeMillis()).build();
            fire(ContextEventType.POWER_DISCONNECTED, before, current, null);
            lastIsCharging = false;
            logd("power: fired DISCONNECTED");
        }
    }

    // -- screen family ----------------------------------------------------------

    private void reconcileScreen(boolean need) {
        if (need && screenReceiver == null) {
            screenReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context ctx, Intent intent) {
                    ContextSnapshot snap = capture();
                    executor.execute(() -> onScreenChanged(snap, intent));
                }
            };
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_SCREEN_ON);
            f.addAction(Intent.ACTION_SCREEN_OFF);
            // screen 族只能运行时注册（manifest 不投递）
            int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                    ? Context.RECEIVER_NOT_EXPORTED : 0;
            appCtx.registerReceiver(screenReceiver, f, flags);
        } else if (!need && screenReceiver != null) {
            appCtx.unregisterReceiver(screenReceiver);
            screenReceiver = null;
        }
    }

    private void onScreenChanged(ContextSnapshot current, Intent intent) {
        boolean isOn = Intent.ACTION_SCREEN_ON.equals(intent.getAction());
        handleScreenEvent(current, isOn);
    }

    void handleScreenEvent(ContextSnapshot current, boolean on) {
        this.snap = current;
        if (on) {
            ContextSnapshot before = current.derive().screenOn(false).capturedAtMs(System.currentTimeMillis()).build();
            fire(ContextEventType.SCREEN_ON, before, current, null);
        } else {
            ContextSnapshot before = current.derive().screenOn(true).capturedAtMs(System.currentTimeMillis()).build();
            fire(ContextEventType.SCREEN_OFF, before, current, null);
        }
    }

    // -- battery family (threshold transition tracking) -------------------------

    private void reconcileBattery(boolean need) {
        if (need && batteryReceiver == null) {
            batteryReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context ctx, Intent intent) {
                    ContextSnapshot snap = capture();
                    executor.execute(() -> onBatteryChanged(snap));
                }
            };
            // Android 14+ 要求 RECEIVER_NOT_EXPORTED（系统 sticky 广播，不导出给其他 App）
            int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                    ? Context.RECEIVER_NOT_EXPORTED : 0;
            appCtx.registerReceiver(batteryReceiver,
                    new IntentFilter(Intent.ACTION_BATTERY_CHANGED), flags);
            logd("battery: receiver registered");
        } else if (!need && batteryReceiver != null) {
            appCtx.unregisterReceiver(batteryReceiver);
            batteryReceiver = null;
            logd("battery: receiver unregistered");
        }
    }

    private void onBatteryChanged(ContextSnapshot current) {
        this.snap = current;
        Integer currentLevel = current.batteryLevel;
        Integer prevLevel = lastBatteryLevel;
        boolean currentCharging = current.isCharging;
        boolean prevCharging = lastIsCharging;
        logd("battery: level=" + currentLevel + " charging=" + currentCharging
                + " (was " + prevLevel + "/" + prevCharging + ")");
        lastBatteryLevel = currentLevel;
        // lastIsCharging 暂不更新——handlePowerEvent 读旧值做去重, 更新在 handlePowerEvent 里

        // -- 电量阈值过渡追踪 --
        if (prevLevel != null && currentLevel != null) {
            for (Map.Entry<Integer, List<TransitionListener>> e : belowThresholds.entrySet()) {
                int t = e.getKey();
                // ★ 阈值过渡追踪（笔记 Q3 答过的坑）：
                //   只有穿越才触发——prevLevel >= threshold 且 currentLevel < threshold
                if (prevLevel >= t && currentLevel < t) {
                    ContextSnapshot before = current.derive().batteryLevel(prevLevel).capturedAtMs(System.currentTimeMillis()).build();
                    JSONObject meta = new JSONObject();
                    try { meta.put("threshold", t); } catch (Exception ignored) {}
                    fireBattery(ContextEventType.BATTERY_BELOW, before, current, meta, e.getValue());
                }
            }
            for (Map.Entry<Integer, List<TransitionListener>> e : aboveThresholds.entrySet()) {
                int t = e.getKey();
                if (prevLevel < t && currentLevel >= t) {
                    ContextSnapshot before = current.derive().batteryLevel(prevLevel).capturedAtMs(System.currentTimeMillis()).build();
                    JSONObject meta = new JSONObject();
                    try { meta.put("threshold", t); } catch (Exception ignored) {}
                    fireBattery(ContextEventType.BATTERY_ABOVE, before, current, meta, e.getValue());
                }
            }
        }

        // -- 充电状态过渡追踪（替代 ACTION_POWER_CONNECTED/DISCONNECTED） --
        // dumpsys battery set 在某些 ROM 上不发 ACTION_POWER_* 广播,
        // 但 BATTERY_CHANGED 的 isCharging 字段一定会变——复用同一个 receiver。
        // 过渡判断在此，handlePowerEvent 只负责 fire+去重。
        if (currentCharging && !prevCharging) {
            handlePowerEvent(current, true);
        } else if (!currentCharging && prevCharging) {
            handlePowerEvent(current, false);
        }
    }

    // -- internal: fire helpers -------------------------------------------------

    private void fire(ContextEventType type, ContextSnapshot before,
                      ContextSnapshot after, JSONObject metadata) {
        ContextEvent event = ContextEvent.of(type, before, after, metadata);
        persister.appendEvent(event);
        persister.writeSnapshot(after);
        notifyListeners(type, event);
    }

    private void fireBattery(ContextEventType type, ContextSnapshot before,
                             ContextSnapshot after, JSONObject metadata,
                             List<TransitionListener> targets) {
        ContextEvent event = ContextEvent.of(type, before, after, metadata);
        persister.appendEvent(event);
        persister.writeSnapshot(after);
        for (TransitionListener l : targets) {
            notifySafely(l, event);
        }
    }

    private void notifyListeners(ContextEventType type, ContextEvent event) {
        for (Map.Entry<TransitionListener, Set<ContextEventType>> e : listeners.entrySet()) {
            if (e.getValue().contains(type)) {
                notifySafely(e.getKey(), event);
            }
        }
    }

    private void notifySafely(TransitionListener l, ContextEvent event) {
        try {
            l.onTransition(event);
        } catch (Exception ex) {
            Log.w(TAG, "listener threw: " + ex.getMessage());
        }
    }

    // -- internal: cleanup ------------------------------------------------------

    private void unregisterAllReceivers() {
        synchronized (receiverLock) {
            unregisterWifiCallback(); wifiCallback = null;
            unregister(screenReceiver); screenReceiver = null;
            unregister(batteryReceiver); batteryReceiver = null;
        }
    }

    private void unregisterWifiCallback() {
        if (wifiCallback != null && appCtx != null) {
            try {
                ConnectivityManager cm = (ConnectivityManager) appCtx.getSystemService(Context.CONNECTIVITY_SERVICE);
                cm.unregisterNetworkCallback(wifiCallback);
            } catch (IllegalArgumentException ignored) { /* already unregistered */ }
        }
    }

    private void unregister(BroadcastReceiver r) {
        if (r != null && appCtx != null) {
            try { appCtx.unregisterReceiver(r); } catch (IllegalArgumentException ignored) {
                // already unregistered — race with system, ignore
            }
        }
    }

    // -- snapshot cache for derive() --------------------------------------------

    /** 最后采集的快照（供 derive() 用），volatile 保证跨线程可见 */
    private volatile ContextSnapshot snap = new ContextSnapshot.Builder()
            .batteryLevel(null).isCharging(false).screenOn(false)
            .wifiSsid(null).foregroundApp(null).capturedAtMs(0).build();

    // -- debug logging (JVM 单测兼容: Log.d 在 android.jar stub 中未 mock) --------

    private static void logd(String msg) {
        try { Log.d(TAG, msg); } catch (RuntimeException ignored) { /* JVM test — Log.d not mocked */ }
    }

    private static final String TAG = "ContextProvider";
}
