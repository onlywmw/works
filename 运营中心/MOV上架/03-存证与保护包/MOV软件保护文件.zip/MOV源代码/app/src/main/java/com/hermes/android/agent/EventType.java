package com.hermes.android.agent;

/**
 * EventType — 事件类型注册表 (CONTRACT: Envelope v1.0)。
 *
 * 所有 journal 事件类型集中定义。加新功能 = 加新常量，不改现有逻辑。
 * 内部元事件以 _ 前缀 (MovRender 自动过滤)。
 */
public final class EventType {

    private EventType() {} // 不可实例化

    // ---- 用户交互 ----
    public static final String USER_INPUT = "user_input";

    // ---- Agent 生命周期 ----
    public static final String PHASE     = "phase";
    public static final String PLAN      = "plan";
    public static final String GATE      = "gate";
    public static final String NOTE      = "note";
    public static final String REVIEW    = "review";
    public static final String DELIVER   = "deliver";
    public static final String FAIL      = "fail";
    public static final String STOPPED   = "stopped";
    public static final String PAUSED    = "paused";
    public static final String RESUMED   = "resumed";
    public static final String SUMMARY   = "summary";
    public static final String UNDERSTAND = "understand";

    // ---- 工具执行 ----
    public static final String TOOL_CALL   = "tool_call";
    public static final String TOOL_RESULT = "tool_result";

    // ---- 数据管理 ----
    public static final String TOMBSTONE = "tombstone";

    // ---- 社交/反馈 (P7) ----
    public static final String REACTION = "reaction";

    // ---- 内部元事件 (_ 前缀不进 UI) ----
    public static final String TELEMETRY = "_telemetry";
    public static final String HEADER    = "_header";

    /**
     * 是否为内部元事件 (不进 UI 渲染)。
     */
    public static boolean isInternal(String type) {
        return type != null && type.startsWith("_");
    }
}
