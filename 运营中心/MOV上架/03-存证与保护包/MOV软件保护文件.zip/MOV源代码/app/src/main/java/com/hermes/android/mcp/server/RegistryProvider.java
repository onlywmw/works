package com.hermes.android.mcp.server;

import android.content.Context;
import android.util.Log;

import com.hermes.android.StorageManager;
import com.hermes.android.agent.AgentLoop;
import com.hermes.android.agent.ToolRegistry;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * ToolRegistry 统一构建源 — consolidate（合并 serve/ToolManifest 与 serve/MovInboundServer
 * 里重复的 buildRegistry 副本）。三个消费者共享同一构建逻辑：
 *  - serve/ToolManifest.writeToExchange（清单推送 daemon）
 *  - serve/MovInboundServer.buildServerRegistry（8388 入站）
 *  - mcp/server/MovMcpServer（8389 MCP 暴露，只读工具集）
 *
 * 语义：房间无关（roomId=""）、上下文无关（context-only）——只读工具与房间解耦。
 */
public final class RegistryProvider {

    private static final String TAG = "RegistryProvider";

    private RegistryProvider() {}

    /** 统一构建（与 serve/ToolManifest#buildRegistry 原实现同构，仅位置收敛）。P1 兼容：空房间 + 空白名单。 */
    public static ToolRegistry build(Context ctx) {
        return build(ctx, "", new HashSet<>());
    }

    /**
     * 统一构建（工单 P5：MCP P2 扩展）— 指定 roomId + 共享 allowedPaths。
     * @param roomId  写工具落房间（MCP 侧固定 MCP_ROOM；其他消费者仍传 ""）
     * @param sharedAllowedPaths  共享路径白名单集（MCP 审批闸批准后注入，file.write 既有闸读取；可空）
     */
    public static ToolRegistry build(Context ctx, String roomId, Set<String> sharedAllowedPaths) {
        final StorageManager sm = new StorageManager(ctx);
        final Set<String> paths = sharedAllowedPaths != null ? sharedAllowedPaths : new HashSet<>();
        AgentLoop.Tools tools = new AgentLoop.Tools() {
            @Override public String fileList(String roomId) { return sm.listRoomFiles(roomId, "files/work"); }
            @Override public String fileRead(String roomId, String path) {
                try {
                    JSONObject r = new JSONObject(sm.readFile(roomId, "files/work/" + path));
                    return r.optBoolean("ok") ? r.optString("content") : "ERROR: " + r.optString("error");
                } catch (Exception e) { return "ERROR: " + e.getMessage(); }
            }
            @Override public String fileWrite(String roomId, String path, String content) {
                try {
                    JSONObject r = new JSONObject(sm.saveWorkFile(roomId, path, content, "AI"));
                    return r.optBoolean("ok") ? "OK: 已写入" : "ERR: " + r.optString("error");
                } catch (Exception e) { return "ERR: " + e.getMessage(); }
            }
            @Override public String capabilityOf(String text) { return ""; }
            @Override public String deviceCmd(String text) { return "ERROR: 环境无设备工具"; }
            @Override public String packageApk(String roomId, String path, String appName) {
                return "{\"ok\":false,\"error\":\"环境无打包工具\"}";
            }
            @Override public String shellExec(String cmd, int timeoutSec) {
                com.hermes.android.linux.ProotRunner.ExecResult r =
                        com.hermes.android.linux.ProotRunner.exec(ctx, cmd, timeoutSec);
                return r.format();
            }
            @Override public String hermesTask(String goal, int timeoutSec) {
                /* 工单20: MCP 侧 hermes.task — 同 HeavyWorker serve 通路 */
                if (!com.hermes.android.linux.RootfsManager.isReady(ctx)) {
                    return "{\"ok\":false,\"error\":\"Linux 环境未就绪\"}";
                }
                try {
                    com.hermes.android.agent.HeavyWorker hw = new com.hermes.android.agent.HeavyWorker(
                            ctx, new java.io.File(ctx.getFilesDir(), "linux/tmp"));
                    com.hermes.android.agent.Worker.WorkerTask task =
                            new com.hermes.android.agent.Worker.WorkerTask(
                                    "hermes-task-mcp-" + System.currentTimeMillis(), 1,
                                    goal, new JSONObject(),
                                    timeoutSec > 0 ? timeoutSec : 600, true, 32000);
                    com.hermes.android.agent.Worker.WorkerResult wr = hw.run(task);
                    JSONObject out = new JSONObject();
                    if (wr != null && wr.ok) {
                        out.put("ok", true);
                        out.put("output", wr.text != null ? wr.text : "");
                        if (wr.files != null && wr.files.length > 0) out.put("file", wr.files[0]);
                    } else {
                        out.put("ok", false);
                        out.put("error", wr != null && wr.errorMsg != null ? wr.errorMsg
                                : (wr != null && wr.text != null ? wr.text : "Hermes 任务失败"));
                    }
                    return out.toString();
                } catch (Exception e) {
                    return "{\"ok\":false,\"error\":\"" + (e.getMessage() != null
                            ? e.getMessage().replace("\"", "'") : "hermes.task 异常") + "\"}";
                }
            }
            @Override public String filePush(String roomId, String path) { return "{\"ok\":false}"; }
            @Override public String filePull(String roomId, String name) { return "{\"ok\":false}"; }
        };
        ToolRegistry registry = ToolRegistry.build(tools, roomId, () -> paths,
                ToolRegistry.DevicePolicy.probe(ctx),
                com.hermes.android.linux.RootfsManager.isReady(ctx));
        /* 工单9 幕一 单表化: 8388/8389 统一构建源激活内置技能(与 BridgeAi 主表同源 assets/skills)。
           skill.echo / wb.* 经 8388 可调(工单4 批2 缺口①销账);技能 access 分级不变(wb.* 非 readonly 不混 8389 只读集)。
           经接缝 activateBuiltinSkills 走资产读取器, 行为可测(打回修复)。 */
        activateBuiltinSkills(registry,
                () -> {
                    try { return ctx.getAssets().list("skills"); }
                    catch (Exception e) { Log.w(TAG, "技能清单读取失败: " + e.getMessage()); return null; }
                },
                name -> {
                    try (java.io.InputStream is = ctx.getAssets().open("skills/" + name)) {
                        byte[] buf = new byte[Math.max(1, is.available())];
                        int off = 0, n;
                        while ((n = is.read(buf, off, buf.length - off)) > 0) off += n;
                        return buf;
                    } catch (Exception e) {
                        Log.w(TAG, "技能读取失败 " + name + ": " + e.getMessage());
                        return null;
                    }
                });
        return registry;
    }

    /**
     * 工单9 幕一 单表化——内置技能激活接缝(行为可测, 打回修复):
     * nameProvider 给技能名称列表, reader 按名取「名称→字节」skill JSON, 逐个 SkillActivator.activate。
     * 生产路径传 assets 读取器(见 build); 测试喂假读取器验证激活行为(禁 mock, 测真激活)。
     * public 供 serve 包行为测试串起 invoke 验证(见 RegistryProviderSkillBehaviorTest)。
     * @return 激活的技能工具数
     */
    public static int activateBuiltinSkills(ToolRegistry registry,
            java.util.function.Supplier<String[]> nameProvider,
            java.util.function.Function<String, byte[]> reader) {
        String[] skills = nameProvider != null ? nameProvider.get() : null;
        if (skills == null) return 0;
        int total = 0;
        for (String s : skills) {
            byte[] buf = reader != null ? reader.apply(s) : null;
            if (buf == null || buf.length == 0) continue;
            try {
                total += com.hermes.android.skill.SkillActivator.activate(registry,
                        new String(buf, 0, buf.length, "UTF-8"));
            } catch (Exception e) {
                Log.w(TAG, "技能激活失败 " + s + ": " + e.getMessage());
            }
        }
        return total;
    }

    /** 只读工具集：access==readonly 且 checkFn 当前可用（P1 MCP 暴露门槛，含 tool.describe/file.read 等）。 */
    public static List<ToolRegistry.Tool> readonlyTools(ToolRegistry registry) {
        List<ToolRegistry.Tool> out = new ArrayList<>();
        for (ToolRegistry.Tool t : registry.allTools()) {
            if (!"readonly".equals(t.access)) continue;
            if (t.checkFn != null) {
                try { if (t.checkFn.check() != null) continue; } catch (Exception e) { continue; }
            }
            out.add(t);
        }
        return out;
    }

    /**
     * DANGEROUS 判定（工单 P5 安全红线）：设备控制 / 任意命令执行 / 无条件高风险 —— 永不对 MCP 暴露。
     * 命中其一即危险：approval==always（device.cmd 等无条件放行）；manifest.risk==high（shell.exec 等）；
     * manifest.category==device（手机硬件）。
     */
    public static boolean isDangerous(ToolRegistry.Tool t) {
        if ("always".equals(t.approval)) return true;
        ToolRegistry.Manifest m = t.manifest;
        if (m == null) return false;
        return "high".equals(m.risk) || "device".equals(m.category);
    }

    /** write 工具集（P2 可审批暴露）：access==write 且非 DANGEROUS 且 checkFn 当前可用。 */
    public static List<ToolRegistry.Tool> writeTools(ToolRegistry registry) {
        List<ToolRegistry.Tool> out = new ArrayList<>();
        for (ToolRegistry.Tool t : registry.allTools()) {
            if (!"write".equals(t.access)) continue;
            if (isDangerous(t)) continue;
            if (t.checkFn != null) {
                try { if (t.checkFn.check() != null) continue; } catch (Exception e) { continue; }
            }
            out.add(t);
        }
        return out;
    }

    /**
     * 暴露给 MCP 的工具集：enableWrite=false → 只读集（P1 行为）；=true → 只读 + 非 DANGEROUS write。
     * 写工具默认不出现在 tools/list——显式开启（HermesServeConfig.isMcpWriteEnabled）才纳入。
     */
    public static List<ToolRegistry.Tool> exposedTools(ToolRegistry registry, boolean enableWrite) {
        List<ToolRegistry.Tool> out = new ArrayList<>(readonlyTools(registry));
        if (enableWrite) out.addAll(writeTools(registry));
        return out;
    }
}
