/* ============================================================
   mov_connect.js — ConnectWeb debug 接口 (协议 §6/§8)
   window.MovConnect = { getText, diffSnapshot, _readabilityReady }
   ============================================================ */

(function() {
  if (window.MovConnect) return; // 幂等：只注入一次
  var _readabilityLoaded = false;
  var _lastSnapshot = '';

  /* ── 正文提取（三级降级）── */
  function getText(maxChars) {
    maxChars = maxChars || 8000;
    try {
      // L1: selector (暂未实现，留给 agent 调用时传)
      // L2: Readability
      if (_readabilityLoaded && typeof Readability !== 'undefined') {
        try {
          var clone = document.cloneNode(true);  // Readability 构造接受 document 对象，非 Element
          var reader = new Readability(clone);
          var article = reader.parse();
          if (article && article.textContent && article.textContent.length >= 200) {
            return clipText(article.textContent, maxChars);
          }
        } catch(e) {}
      }
      // L3: body.innerText
      return clipText((document.body || document.documentElement).innerText || '', maxChars);
    } catch(e) {
      return '';
    }
  }

  /* ── Diff 快照 ── */
  function diffSnapshot() {
    try {
      var current = (document.body || document.documentElement).innerText || '';
      var before = _lastSnapshot;
      _lastSnapshot = current;
      // 回传前后两份快照供 Java 侧 BrowserDiffHelper.diff()
      return JSON.stringify({ before: before, after: current });
    } catch(e) {
      return JSON.stringify({ before: '', after: '', error: String(e) });
    }
  }

  function clipText(text, maxChars) {
    if (!text) return '';
    return text.length > maxChars ? text.substring(0, maxChars) : text;
  }

  function findMainScroller() {
    var best = null, bestArea = 0;
    document.querySelectorAll('*').forEach(function(el) {
      if (el.scrollHeight > el.clientHeight + 5 && el.clientHeight <= window.innerHeight) {
        var area = el.clientWidth * el.clientHeight;
        if (area > bestArea) { best = el; bestArea = area; }
      }
    });
    return best;
  }

  /* ── wait_for（四态轮询，协议 §1）── */
  function waitFor(selector, state, containsText, timeoutMs) {
    var start = Date.now();
    timeoutMs = timeoutMs || 10000;
    return new Promise(function(resolve) {
      function check() {
        try {
          var el = document.querySelector(selector);
          var found = false;
          if (!el) { found = state === 'detached'; }
          else {
            var cs = window.getComputedStyle(el);
            var visible = cs.visibility !== 'hidden' && cs.display !== 'none' && cs.opacity !== '0'
                       && el.getBoundingClientRect().height > 0;
            switch (state || 'visible') {
              case 'attached': found = true; break;
              case 'detached': found = false; break;
              case 'visible': found = visible; break;
              case 'hidden': found = !visible; break;
            }
            if (found && containsText) {
              var all = document.querySelectorAll(selector);
              found = Array.prototype.some.call(all, function(e) {
                return (e.textContent || '').indexOf(containsText) >= 0;
              });
            }
          }
          if (found) {
            resolve(JSON.stringify({found: true, elapsed_ms: Date.now() - start}));
            return;
          }
        } catch(e) {}
        if (Date.now() - start > timeoutMs) {
          resolve(JSON.stringify({found: false, timeout: true, elapsed_ms: timeoutMs,
            recovery: 'Selector not found within ' + timeoutMs + 'ms. Try snapshot() to verify.'}));
          return;
        }
        setTimeout(check, 200);
      }
      check();
    });
  }

  /* ── 元素编号快照（协议 §4）── */
  function snapshot() {
    try {
      var selectors = 'a,button,input,select,[onclick],[role=button],[role=link],.btn,[data-action]';
      var els = document.querySelectorAll(selectors);
      var results = [];
      var limit = Math.min(els.length, 100);
      // 先清旧 eid
      document.querySelectorAll('[data-mov-eid]').forEach(function(el) { el.removeAttribute('data-mov-eid'); });
      for (var i = 0; i < limit; i++) {
        var el = els[i];
        // 可见性过滤
        var rect = el.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) continue;
        if (rect.top < -200 || rect.top > window.innerHeight + 200) continue;
        var cs = window.getComputedStyle(el);
        if (cs.visibility === 'hidden' || cs.display === 'none' || cs.opacity === '0') continue;
        var eid = results.length;
        el.setAttribute('data-mov-eid', String(eid));
        var text = (el.textContent || el.value || el.getAttribute('aria-label') || el.title || el.placeholder || '').trim();
        if (text.length > 40) text = text.substring(0, 37) + '...';
        results.push({
          eid: eid,
          tag: el.tagName.toLowerCase(),
          text: text,
          role: el.getAttribute('role') || ''
        });
      }
      return JSON.stringify(results);
    } catch(e) {
      return JSON.stringify([]);
    }
  }

  /* ── 执行写动作 ── */
  function executeAction(action) {
    try {
      var target = null;
      if (action.eid !== undefined && action.eid !== null) {
        target = document.querySelector('[data-mov-eid="' + action.eid + '"]');
      } else if (action.selector) {
        target = document.querySelector(action.selector);
      }
      var before = (document.body || document.documentElement).innerText || '';

      switch (action.type) {
        case 'click':
          if (!target) return JSON.stringify({error:'selector_not_found', recovery:'Call MovConnect.snapshot() to get fresh element ids.'});
          // pointer 事件（SPA 如抖音只认 pointer, target.click() 无效）
          var r = target.getBoundingClientRect();
          var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
          target.dispatchEvent(new PointerEvent('pointerdown', {bubbles:true, cancelable:true, clientX:cx, clientY:cy}));
          setTimeout(function() {
            target.dispatchEvent(new PointerEvent('pointerup', {bubbles:true, cancelable:true, clientX:cx, clientY:cy}));
          }, 60);
          break;
        case 'type':
          if (!target) return JSON.stringify({error:'selector_not_found', recovery:'Call MovConnect.snapshot() to get fresh element ids.'});
          if (action.text !== undefined) {
            // React 受控组件：必须走原生 setter，直接 .value= 会被框架忽略
            var nativeSetter = Object.getOwnPropertyDescriptor(
              target.tagName === 'TEXTAREA'
                ? window.HTMLTextAreaElement.prototype
                : window.HTMLInputElement.prototype, 'value').set;
            if (action.clear !== false) nativeSetter.call(target, '');
            target.focus();
            nativeSetter.call(target, (target.value || '') + action.text);
            target.dispatchEvent(new Event('input', {bubbles:true}));
            target.dispatchEvent(new Event('change', {bubbles:true}));
          }
          break;
        case 'scroll':
          var amount = action.amount || 600;
          // 找最大可滚动元素（桌面版抖音内容在主容器里，window.scrollBy 恒 0）
          var sc = findMainScroller();
          if (sc && sc !== document.scrollingElement) {
            sc.scrollBy({top: amount, behavior: 'instant'});
            return JSON.stringify({scroll_y: sc.scrollTop});
          }
          window.scrollBy({top: amount, behavior: 'instant'});
          return JSON.stringify({scroll_y: window.scrollY});
        case 'submit':
          if (!target) return JSON.stringify({error:'selector_not_found', recovery:'Call MovConnect.snapshot() to get fresh element ids.'});
          if (target.form) { target.form.submit(); }
          else if (target.tagName === 'FORM') { target.submit(); }
          else { target.closest('form') && target.closest('form').submit(); }
          break;
        case 'wait_for':
          return JSON.stringify({error:'wait_for_sync', recovery:'Use Java-side polling loop for wait_for, not executeAction.'});
      }

      // 写动作后 eid 失效
      document.querySelectorAll('[data-mov-eid]').forEach(function(el) { el.removeAttribute('data-mov-eid'); });

      // paint settle (600ms) 后取 after 快照 — 治「点了搜索回 unchanged」
      var settleMs = action._settleMs || 600;
      return JSON.stringify({_async: true, settleMs: settleMs, before: before});
    } catch(e) {
      return JSON.stringify({error:'js_failed', recovery:e.message});
    }
  }

  /* ── 暴露 debug 接口 ── */
  window.MovConnect = {
    getText: getText,
    diffSnapshot: diffSnapshot,
    snapshot: snapshot,
    executeAction: executeAction,
    waitFor: waitFor,
    _readabilityReady: function() { return _readabilityLoaded; }
  };

  /* ── Readability sentinel ── */
  if (typeof Readability !== 'undefined') {
    _readabilityLoaded = true;
  }
})();
