package com.hermes.android.scene;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 本地视频库 — MediaStore 扫描 + 文件名清洗 + 匹配。
 * 隐私：索引只读本地不上传，READ_MEDIA_VIDEO 运行时权限。
 */
public class LocalVideoLibrary {

    private static final String TAG = "LocalVideoLib";
    private static final String[] PROJECTION = {
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_MODIFIED,
    };

    private final Context ctx;
    private List<LocalVideo> cache;
    private long lastScanMtime;

    public LocalVideoLibrary(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    public static class LocalVideo {
        public final String title;       // 清洗后的剧名
        public final String episode;     // 集数标记 (如 "S01E01" / "01")
        public final String path;        // 文件绝对路径
        public final long durationMs;
        public final long size;
        public final long mtime;

        LocalVideo(String title, String episode, String path, long durationMs, long size, long mtime) {
            this.title = title;
            this.episode = episode;
            this.path = path;
            this.durationMs = durationMs;
            this.size = size;
            this.mtime = mtime;
        }

        public JSONObject toJSON() {
            JSONObject o = new JSONObject();
            try {
                o.put("title", title != null ? title : "");
                o.put("episode", episode != null ? episode : "");
                o.put("path", path != null ? path : "");
                o.put("duration", durationMs);
                o.put("size", size);
                o.put("source", "local");
                o.put("viewType", "local_player");
            } catch (Exception ignored) {}
            return o;
        }
    }

    /** 搜索本地视频（关键词匹配标题） */
    public List<LocalVideo> search(String query) {
        refresh();
        if (cache == null || query == null || query.trim().isEmpty()) return Collections.emptyList();
        List<LocalVideo> results = new ArrayList<>();
        String q = query.toLowerCase();
        for (LocalVideo v : cache) {
            if (v.title != null && v.title.toLowerCase().contains(q)) {
                results.add(v);
            }
        }
        return results;
    }

    /** 增量刷新索引（首次全扫，后续 mtime > lastScanMtime 增量） */
    private synchronized void refresh() {
        long now = System.currentTimeMillis();
        // 30s 缓存
        if (cache != null && now - lastScanMtime < 30000) return;

        try {
            Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
            String selection = MediaStore.Video.Media.DATE_MODIFIED + " > ?";
            String[] args = new String[]{String.valueOf(lastScanMtime / 1000)};
            if (lastScanMtime == 0) { selection = null; args = null; } // 首次全扫

            Cursor c = ctx.getContentResolver().query(uri, PROJECTION, selection, args,
                    MediaStore.Video.Media.DATE_MODIFIED + " DESC");
            if (c == null) return;

            if (cache == null) cache = new ArrayList<>();
            while (c.moveToNext()) {
                String displayName = c.getString(c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME));
                String data = c.getString(c.getColumnIndexOrThrow(MediaStore.Video.Media.DATA));
                long duration = c.getLong(c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION));
                long size = c.getLong(c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE));
                long mtime = c.getLong(c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)) * 1000L;

                // 文件名清洗
                String baseName = displayName;
                int dot = baseName.lastIndexOf('.');
                if (dot > 0) baseName = baseName.substring(0, dot);

                // 去噪标记
                String cleaned = baseName
                        .replaceAll("\\[.*?\\]", "")       // [1080p] [4K] [HEVC]
                        .replaceAll("\\(.*?\\)", "")        // (B-Global) (CHS)
                        .replaceAll("(?i)(1080p|720p|4k|HD|hevc|x264|x265|avc|aac)", "")
                        .replaceAll("(?i)(WEB-DL|BDrip|BDRip|DVDRip)", "")
                        .replaceAll("(?i)(CHS|ENG|JP|GB|BIG5|简|繁|双语|中字|内嵌|内封)", "")
                        .replaceAll("(?i)(E\\d{2,3})", "") // E01 E02
                        .replaceAll("[-_.\\s]{2,}", " ")    // 连续分隔符
                        .replaceAll("(?i)(字幕组|压制|发布|压制组)", "")
                        .trim();

                // 提取集数
                String episode = "";
                java.util.regex.Matcher em = java.util.regex.Pattern.compile(
                        "(?i)S(\\d{1,2})[Ee](\\d{1,3})|(\\d{1,2})[-_.](\\d{1,3})|第\\s*(\\d+)\\s*[集话期]|(\\d{2,3})\\s*(?:\\.|$)")
                        .matcher(baseName);
                if (em.find()) {
                    for (int g = 1; g <= em.groupCount(); g++) {
                        if (em.group(g) != null) {
                            episode = em.group(g);
                            if (episode.length() <= 2) episode = "S01E" + episode;
                            break;
                        }
                    }
                }

                if (cleaned.isEmpty()) cleaned = baseName;
                cache.add(new LocalVideo(cleaned, episode, data, duration, size, mtime));
            }
            c.close();
            lastScanMtime = now;
            Log.d(TAG, "Indexed " + cache.size() + " local videos");
        } catch (Exception e) {
            Log.w(TAG, "scan failed: " + e.getMessage());
        }
    }

    /** 是否有权限 */
    public boolean hasPermission() {
        return android.os.Build.VERSION.SDK_INT < 33
                || ctx.checkSelfPermission(android.Manifest.permission.READ_MEDIA_VIDEO)
                   == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    /** 视频数量 */
    public int count() {
        refresh();
        return cache != null ? cache.size() : 0;
    }
}
