package com.hermes.android.causal;

import org.json.JSONObject;

/**
 * API 归因封装（DESIGN_CAUSAL_APIFACT §三）：复用 MOV 现有 Brain 通道（DeepSeek/AiClient），不新增外部 API。
 * 输入脱敏叙事，输出 JSON 补丁 {hidden_variables, probability_change, patch_rule}。
 * 错误处理：非 JSON / 解析失败 / 网络失败 → 静默返回 null（不打断；下次触发重试）。
 */
public class CausalOracle {

    /** Brain 注入（生产 = AiClient 适配；测试 = fake 返回固定 JSON）。 */
    public interface Brain {
        String chat(String systemPrompt, String userText);
    }

    /** 归因分析：narrative → JSON 补丁。失败/非预期 → null（静默）。
     *  出网前最后关口（隐私审计 2026-08-05）：narrative 经 PiiScrubber 确定性脱敏后才交给 brain，
     *  任何未来改动只要走 analyze 就绕不过这道打码。 */
    public static JSONObject analyze(Brain brain, String narrative) {
        if (brain == null || narrative == null || narrative.isEmpty()) return null;
        narrative = PiiScrubber.scrub(narrative);   // 最后关口：手机号/证件/邮箱/卡号/金额/URL 不出网
        String system = "你是个人因果分析专家。我会给你一段完全脱敏的个人生活事件模式描述，"
                + "所有实体用抽象标签（实体A/实体B/事件类型X），不含真实个人信息。\n"
                + "请：1) 从最终不良结果逆向找缺失/薄弱因果环节（隐变量）；"
                + "2) 估计加入这些环节后结果改变的概率变化；"
                + "3) 生成一条可执行的逻辑补丁规则。\n"
                + "严格按 JSON 返回，键：hidden_variables(字符串数组), probability_change(字符串), "
                + "patch_rule(必须是JSON对象，含 condition[字符串], action[字符串,如\"INSERT_NODE\"], "
                + "new_node[对象,含 type/suggested_trigger], confidence_boost[数字])。"
                + "patch_rule 不能是字符串或缺失。";
        try {
            String content = brain.chat(system, narrative);
            if (content == null) return null;
            String c = content.trim();
            // 剥 markdown 围栏
            if (c.startsWith("```")) {
                int nl = c.indexOf('\n');
                int end = c.lastIndexOf("```");
                if (nl >= 0 && end > nl) c = c.substring(nl + 1, end).trim();
            }
            JSONObject o = new JSONObject(c);
            // 补丁编译必需 patch_rule 且必须是 JSON 对象（真机发现：DeepSeek 曾返回字符串 → 编译失败）
            JSONObject pr = o.optJSONObject("patch_rule");
            if (pr == null) return null;
            return o;
        } catch (Exception e) {
            return null;   // 非 JSON / 网络失败 → 静默
        }
    }
}
