package com.hermes.android.bridge;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * MCP 工具暴露注解（旧 McpServer allowlist，R7 安全整治）：
 * 只有标注此注解的 @JavascriptInterface 方法才被反射注册成 MCP 工具。
 *
 * 默认不上网——新增桥方法须显式标注，根治「新桥方法自动上网」的默认危险模式
 * （此前 getServeToken 等敏感方法因反射扫描被二次暴露）。
 *
 * 安全红线：写/执行/敏感方法一律不标；旧 McpServer（127.0.0.1:10000-20000，无鉴权面）
 * 只暴露只读安全查询方法。
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface McpExpose {
}
