package com.hermes.android.bridge;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;

import com.hermes.android.HermesActivity;
import com.hermes.android.pay.MarketEngine;

import org.json.JSONObject;

/**
 * MCP 市场桥（工单26 M2-1）——全部 cbId 异步（网络 IO 红线，不加同步 case 进 BridgeKernel）。
 *
 * mkt.saveMerchant / mkt.buy / mkt.goPay / mkt.orderStatus；
 * 统一错误信封 {ok, data?, error:{code,msg}}，try-catch 禁向 JS 抛异常。
 */
public class BridgeMarket extends BaseBridge {

    private final MarketEngine engine;

    public BridgeMarket(HermesActivity activity) {
        super(activity);
        this.engine = new MarketEngine(activity);
    }

    public MarketEngine engine() { return engine; }

    /** 商户四证 + AppID + 卖家签名私钥入保险柜（appid 非机密明文存 prefs，其余进 vault） */
    @JavascriptInterface
    public void mktSaveMerchant(String json, String cbId) {
        activity.getAiExecutor().execute(() -> {
            try {
                JSONObject req = new JSONObject(json);
                engine.saveMerchant(req.optString("mchid", ""), req.optString("serial", ""),
                        req.optString("apiv3Key", ""), req.optString("pem", ""),
                        req.optString("appid", ""), req.optString("sellerPem", ""));
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":true})");
            } catch (Exception e) {
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":{"
                        + "\"code\":\"SAVE_FAIL\",\"msg\":\"" + esc(e.getMessage()) + "\"}})");
            }
        });
    }

    /** 立即购买（E-8 去锁屏闸：点购买直达出单）→ 卖家回订单卡后回调 {orderId, codeUrl, fen, name} */
    @JavascriptInterface
    public void mktBuy(String productId, String cbId) {
        try {
            engine.buy(productId, cbId);
        } catch (Exception e) {
            evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":{"
                    + "\"code\":\"BUY_FAIL\",\"msg\":\"" + esc(e.getMessage()) + "\"}})");
        }
    }

    /** 去支付：Intent 拉起微信支付确认页（weixin:// code_url 直跳）；未装微信 → WECHAT_NOT_INSTALLED */
    @JavascriptInterface
    public void mktGoPay(String orderId, String cbId) {
        try {
            JSONObject v = engine.orderView(orderId);
            if (v == null) {
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":{"
                        + "\"code\":\"ORDER_NOT_FOUND\",\"msg\":\"订单不存在\"}})");
                return;
            }
            String codeUrl = v.optString("codeUrl", "");
            if (codeUrl.isEmpty()) {
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":{"
                        + "\"code\":\"NO_CODE_URL\",\"msg\":\"支付链接缺失\"}})");
                return;
            }
            /* 工单26 E-14：JSAPI 链路 codeUrl 是 https 支付页——浏览器打开调不起 chooseWXPay，
               复制到剪贴板引导用户微信内打开（v2 改公众号客服消息直推） */
            if (codeUrl.startsWith("http")) {
                android.content.ClipboardManager cm = (android.content.ClipboardManager)
                        activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(android.content.ClipData.newPlainText("pay_url", codeUrl));
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":true,\"data\":{\"copied\":true}})");
                return;
            }
            Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(codeUrl));
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(it);
            evalJs("window._hermesCb('" + cbId + "',{\"ok\":true})");
        } catch (ActivityNotFoundException e) {
            evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":{"
                    + "\"code\":\"WECHAT_NOT_INSTALLED\",\"msg\":\"未安装微信，无法拉起支付\"}})");
        } catch (Exception e) {
            evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":{"
                    + "\"code\":\"GO_PAY\",\"msg\":\"" + esc(e.getMessage()) + "\"}})");
        }
    }

    /** 订单投影（买家收款卡轮询） */
    @JavascriptInterface
    public void mktOrderStatus(String orderId, String cbId) {
        try {
            JSONObject v = engine.orderView(orderId);
            if (v == null) {
                evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":{"
                        + "\"code\":\"ORDER_NOT_FOUND\",\"msg\":\"订单不存在\"}})");
                return;
            }
            evalJs("window._hermesCb('" + cbId + "',{\"ok\":true,\"data\":" + v + "})");
        } catch (Exception e) {
            evalJs("window._hermesCb('" + cbId + "',{\"ok\":false,\"error\":{"
                    + "\"code\":\"ORDER_STATUS\",\"msg\":\"" + esc(e.getMessage()) + "\"}})");
        }
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }
}
