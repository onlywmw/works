package com.hermes.android.scene;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 12306 数据源 + 解析引擎（对齐 12306-mcp get-tickets / get-interline-tickets / get-train-route-stations）。
 *
 * HTTP 走 MOV 本体 Java HttpURLConnection（同 TrainSource/AiClient），属于应用自身出网通道，
 * 不受 serve 子进程禁网约束。动线：init 铸 cookie + 动态取查询路径 → queryG 查车次 → 竖线串解析。
 *
 * 单测零网络：所有解析方法是 static/package-private 纯逻辑，注入站表 + fixture 喂数据。
 */
public class Ticket12306Source {

    public static final String API_BASE = "https://kyfw.12306.cn";
    public static final String SEARCH_API_BASE = "https://search.12306.cn";

    // ── TicketDataKeys 关键索引（权威对齐 types.ts，前 57 字段） ──
    public static final int IDX_TRAIN_NO = 2;
    public static final int IDX_TRAIN_CODE = 3;          // station_train_code (G103)
    public static final int IDX_FROM_TELECODE = 6;
    public static final int IDX_TO_TELECODE = 7;
    public static final int IDX_START_TIME = 8;
    public static final int IDX_ARRIVE_TIME = 9;
    public static final int IDX_LISHI = 10;
    public static final int IDX_START_DATE = 13;         // start_train_date yyyyMMdd
    public static final int IDX_YP_INFO_NEW = 39;
    public static final int IDX_DW_FLAG = 46;
    public static final int IDX_SEAT_DISCOUNT = 54;

    private final Ticket12306Stations stations;

    // ══════════ 内部类型 ══════════

    /** 竖线串一条记录（57 字段，索引见 IDX_* 常量）。 */
    public static class TicketData {
        public final String[] f;
        TicketData(String[] f) { this.f = f; }
        String get(int i) { return i < f.length && f[i] != null ? f[i] : ""; }
    }

    /** 席别票价。 */
    public static class Price {
        public final String seatName, shortCode, seatTypeCode, num;
        public final double price;
        public final Integer discount;   // null = 无折扣
        Price(String seatName, String shortCode, String seatTypeCode, String num, double price, Integer discount) {
            this.seatName = seatName; this.shortCode = shortCode; this.seatTypeCode = seatTypeCode;
            this.num = num; this.price = price; this.discount = discount;
        }
    }

    /** 过滤/排序所需的公共时间字段（TicketInfo 与 InterlineInfo 共实现）。 */
    public interface TrainTrip {
        String tripTrainCode();
        String tripStartDate();
        String tripStartTime();
        String tripArriveDate();
        String tripArriveTime();
        String tripLishi();
        List<String> tripDwFlags();
    }

    /** 解析后的车票信息（含票价 + 中文站名）。 */
    public static class TicketInfo implements TrainTrip {
        public final String trainNo, startTrainCode, startDate, startTime;
        public final String arriveDate, arriveTime, lishi;
        public final String fromStation, toStation, fromTelecode, toTelecode;
        public final List<Price> prices;
        public final List<String> dwFlags;
        TicketInfo(String trainNo, String startTrainCode, String startDate, String startTime,
                   String arriveDate, String arriveTime, String lishi,
                   String fromStation, String toStation, String fromTelecode, String toTelecode,
                   List<Price> prices, List<String> dwFlags) {
            this.trainNo = trainNo; this.startTrainCode = startTrainCode;
            this.startDate = startDate; this.startTime = startTime;
            this.arriveDate = arriveDate; this.arriveTime = arriveTime; this.lishi = lishi;
            this.fromStation = fromStation; this.toStation = toStation;
            this.fromTelecode = fromTelecode; this.toTelecode = toTelecode;
            this.prices = prices; this.dwFlags = dwFlags;
        }
        @Override public String tripTrainCode() { return startTrainCode; }
        @Override public String tripStartDate() { return startDate; }
        @Override public String tripStartTime() { return startTime; }
        @Override public String tripArriveDate() { return arriveDate; }
        @Override public String tripArriveTime() { return arriveTime; }
        @Override public String tripLishi() { return lishi; }
        @Override public List<String> tripDwFlags() { return dwFlags; }
    }

    /** 中转查询原始数据（middleList 一条）。 */
    public static class InterlineData {
        public final String allLishi, startTime, trainDate, middleDate, arriveDate, arriveTime;
        public final String fromCode, fromName, middleCode, middleName, endCode, endName;
        public final String firstTrainNo, secondTrainNo, waitTime;
        public final int trainCount;
        public final String sameStation, sameTrain;   // '0'/'Y' 判定
        public final List<InterlineTicketData> fullList;
        InterlineData(JSONObject o, List<InterlineTicketData> fullList) {
            this.allLishi = o.optString("all_lishi");
            this.startTime = o.optString("start_time");
            this.trainDate = o.optString("train_date");
            this.middleDate = o.optString("middle_date");
            this.arriveDate = o.optString("arrive_date");
            this.arriveTime = o.optString("arrive_time");
            this.fromCode = o.optString("from_station_code");
            this.fromName = o.optString("from_station_name");
            this.middleCode = o.optString("middle_station_code");
            this.middleName = o.optString("middle_station_name");
            this.endCode = o.optString("end_station_code");
            this.endName = o.optString("end_station_name");
            this.firstTrainNo = o.optString("first_train_no");
            this.secondTrainNo = o.optString("second_train_no");
            this.waitTime = o.optString("wait_time");
            this.trainCount = o.optInt("train_count", 0);
            this.sameStation = o.optString("same_station");
            this.sameTrain = o.optString("same_train");
            this.fullList = fullList;
        }
    }

    /** 中转票（fullList 一条，竖线字段名对齐 InterlineTicketData）。 */
    public static class InterlineTicketData {
        public final String trainNo, startTrainCode, startDate, startTime, arriveTime, lishi;
        public final String fromName, toName, fromTelecode, toTelecode;
        public final String ypInfo, seatDiscount, dwFlag;
        InterlineTicketData(JSONObject o) {
            this.trainNo = o.optString("train_no");
            this.startTrainCode = o.optString("station_train_code");
            this.startDate = o.optString("start_train_date");
            this.startTime = o.optString("start_time");
            this.arriveTime = o.optString("arrive_time");
            this.lishi = o.optString("lishi");
            this.fromName = o.optString("from_station_name");
            this.toName = o.optString("to_station_name");
            this.fromTelecode = o.optString("from_station_telecode");
            this.toTelecode = o.optString("to_station_telecode");
            this.ypInfo = o.optString("yp_info");
            this.seatDiscount = o.optString("seat_discount_info");
            this.dwFlag = o.optString("dw_flag");
        }
    }

    /** 解析后的中转方案。 */
    public static class InterlineInfo implements TrainTrip {
        public final String lishi, startTime, startDate, middleDate, arriveDate, arriveTime;
        public final String fromName, middleName, endName;
        public final String startTrainCode, firstTrainNo, secondTrainNo, waitTime;
        public final boolean sameStation, sameTrain;
        public final List<TicketInfo> ticketList;
        InterlineInfo(String lishi, String startTime, String startDate, String middleDate,
                      String arriveDate, String arriveTime, String fromName, String middleName,
                      String endName, String startTrainCode, String firstTrainNo, String secondTrainNo,
                      boolean sameStation, boolean sameTrain, String waitTime, List<TicketInfo> ticketList) {
            this.lishi = lishi; this.startTime = startTime; this.startDate = startDate;
            this.middleDate = middleDate; this.arriveDate = arriveDate; this.arriveTime = arriveTime;
            this.fromName = fromName; this.middleName = middleName; this.endName = endName;
            this.startTrainCode = startTrainCode; this.firstTrainNo = firstTrainNo; this.secondTrainNo = secondTrainNo;
            this.sameStation = sameStation; this.sameTrain = sameTrain;
            this.waitTime = waitTime; this.ticketList = ticketList;
        }
        @Override public String tripTrainCode() { return startTrainCode; }
        @Override public String tripStartDate() { return startDate; }
        @Override public String tripStartTime() { return startTime; }
        @Override public String tripArriveDate() { return arriveDate; }
        @Override public String tripArriveTime() { return arriveTime; }
        @Override public String tripLishi() { return lishi; }
        @Override public List<String> tripDwFlags() {
            if (ticketList != null && !ticketList.isEmpty()) return ticketList.get(0).dwFlags;
            return new ArrayList<>();
        }
    }

    /** 经停站。 */
    public static class RouteStationInfo {
        public final String trainClassName, serviceType, endStationName, stationName;
        public final String stationTrainCode, arriveTime, startTime, lishi, arriveDayStr;
        RouteStationInfo(String trainClassName, String serviceType, String endStationName,
                         String stationName, String stationTrainCode, String arriveTime,
                         String startTime, String lishi, String arriveDayStr) {
            this.trainClassName = trainClassName; this.serviceType = serviceType;
            this.endStationName = endStationName; this.stationName = stationName;
            this.stationTrainCode = stationTrainCode; this.arriveTime = arriveTime;
            this.startTime = startTime; this.lishi = lishi; this.arriveDayStr = arriveDayStr;
        }
    }

    /** 查询选项（get-tickets 与 get-interline-tickets 共用）。 */
    public static class QueryOptions {
        public String date, fromStation, toStation;
        public String middleStation = "";
        public boolean showWZ = false;
        public String trainFilterFlags = "";
        public int earliestStartTime = 0;
        public int latestStartTime = 24;
        public String sortFlag = "";
        public boolean sortReverse = false;
        public int limitedNum = 0;
        public String format = "text";
    }

    /** 查询结果：成功文本 + 原始列表。 */
    public static class QueryResult {
        public final String text;
        public final List<?> items;
        QueryResult(String text, List<?> items) { this.text = text; this.items = items; }
    }

    // ══════════ 构造 ══════════

    public Ticket12306Source(Ticket12306Stations stations) { this.stations = stations; }

    /** 真实构造：铸 cookie + 取站表。失败抛异常。 */
    public Ticket12306Source() throws Exception {
        this.stations = Ticket12306Stations.get();
    }

    // ══════════ 网络层 ══════════

    /** 铸会话 cookie：GET init 页收集 Set-Cookie。 */
    public String forgeCookie() throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(API_BASE + "/otn/leftTicket/init").openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(8000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0");
        StringBuilder ck = new StringBuilder();
        java.util.Map<String, List<String>> headers = c.getHeaderFields();
        for (java.util.Map.Entry<String, List<String>> e : headers.entrySet()) {
            if ("Set-Cookie".equalsIgnoreCase(e.getKey())) {
                for (String v : e.getValue()) {
                    String[] parts = v.split(";");
                    if (parts.length > 0) ck.append(parts[0]).append("; ");
                }
            }
        }
        c.disconnect();
        if (ck.length() == 0) throw new Exception("get cookie failed");
        return ck.toString();
    }

    /** 动态取余票查询路径（init 页正则 CLeftTicketUrl，不硬编码 queryG）。 */
    public String queryPath() throws Exception {
        String html = httpGet(API_BASE + "/otn/leftTicket/init", null);
        if (html == null) throw new Exception("get init page failed");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("var CLeftTicketUrl = '(.+?)'").matcher(html);
        if (!m.find()) throw new Exception("get ticket query path failed");
        return m.group(1);
    }

    /** 动态取中转查询路径（init 页正则 lc_search_url）。 */
    public String lcQueryPath() throws Exception {
        String html = httpGet(API_BASE + "/otn/lcQuery/init", null);
        if (html == null) throw new Exception("get lcQuery init page failed");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("var lc_search_url = '(.+?)'").matcher(html);
        if (!m.find()) throw new Exception("get lc query path failed");
        return m.group(1);
    }

    static String httpGet(String urlStr, String cookie) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
            c.setConnectTimeout(8000); c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
            int code = c.getResponseCode();
            if (code != 200) return null;
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close(); c.disconnect();
            return sb.toString();
        } catch (Exception e) { return null; }
    }

    static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; }
    }

    // ══════════ 查询入口 ══════════

    /** 查余票：网络 → 解析 → 过滤 → 格式化。 */
    public QueryResult search(QueryOptions o) throws Exception {
        if (!checkDate(o.date)) throw new IllegalArgumentException("日期不能早于今天");
        String fromCode = stations.resolveCode(o.fromStation);
        String toCode = stations.resolveCode(o.toStation);
        if (fromCode == null || toCode == null)
            throw new IllegalArgumentException("未知车站: " + o.fromStation + "/" + o.toStation);

        String path = queryPath();
        String cookie = forgeCookie();
        String url = API_BASE + path
            + "?leftTicketDTO.train_date=" + enc(o.date)
            + "&leftTicketDTO.from_station=" + enc(fromCode)
            + "&leftTicketDTO.to_station=" + enc(toCode)
            + "&purpose_codes=ADULT";
        String body = httpGet(url, cookie);
        if (body == null) throw new Exception("get tickets data failed");
        JSONObject resp = new JSONObject(body);
        JSONObject data = resp.optJSONObject("data");
        if (data == null) throw new Exception("tickets data empty");

        // c_url 端点轮换：换端点重试一次
        String cUrl = data.optString("c_url", "");
        if (!cUrl.isEmpty()) {
            String url2 = (cUrl.startsWith("http") ? cUrl : API_BASE + cUrl)
                + "?leftTicketDTO.train_date=" + enc(o.date)
                + "&leftTicketDTO.from_station=" + enc(fromCode)
                + "&leftTicketDTO.to_station=" + enc(toCode)
                + "&purpose_codes=ADULT";
            String body2 = httpGet(url2, cookie);
            if (body2 != null) {
                JSONObject resp2 = new JSONObject(body2);
                if (resp2.optJSONObject("data") != null) { resp = resp2; data = resp2.optJSONObject("data"); }
            }
        }

        JSONArray result = data.optJSONArray("result");
        JSONObject map = data.optJSONObject("map");
        if (result == null || map == null) throw new Exception("result/map missing (parse drift)");
        List<TicketData> ticketsData = parseTicketsData(result);
        List<TicketInfo> infos = parseTicketsInfo(ticketsData, map);
        if (infos.isEmpty()) throw new Exception("zero valid tickets (parse drift)");
        List<TicketInfo> filtered = filterTicketsInfo(infos, o);
        String text = format(filtered, o.format);
        return new QueryResult(text, filtered);
    }

    /** 查中转余票。 */
    public QueryResult searchInterline(QueryOptions o) throws Exception {
        if (!checkDate(o.date)) throw new IllegalArgumentException("日期不能早于今天");
        String fromCode = stations.resolveCode(o.fromStation);
        String toCode = stations.resolveCode(o.toStation);
        String middleCode = o.middleStation.isEmpty() ? null : stations.resolveCode(o.middleStation);
        if (fromCode == null || toCode == null || (o.middleStation != null && !o.middleStation.isEmpty() && middleCode == null))
            throw new IllegalArgumentException("未知车站");

        String path = lcQueryPath();
        String cookie = forgeCookie();
        List<InterlineData> interlineData = new ArrayList<>();
        int resultIndex = 0;
        boolean canQuery = true;
        int guard = 0;
        while (interlineData.size() < (o.limitedNum > 0 ? o.limitedNum : 10) && canQuery && guard++ < 20) {
            String url = API_BASE + path
                + "?train_date=" + enc(o.date)
                + "&from_station_telecode=" + enc(fromCode)
                + "&to_station_telecode=" + enc(toCode)
                + "&middle_station=" + (middleCode == null ? "" : enc(middleCode))
                + "&result_index=" + resultIndex
                + "&can_query=Y"
                + "&isShowWZ=" + (o.showWZ ? "Y" : "N")
                + "&purpose_codes=00"
                + "&channel=E";
            String body = httpGet(url, cookie);
            if (body == null) throw new Exception("request interline tickets data failed");
            JSONObject resp = new JSONObject(body);
            Object d = resp.opt("data");
            if (d instanceof String) throw new Exception("未查到相关中转车次 (" + resp.optString("errorMsg") + ")");
            JSONObject data = resp.optJSONObject("data");
            if (data == null) throw new Exception("interline data missing");
            JSONArray middleList = data.optJSONArray("middleList");
            if (middleList != null) {
                for (int i = 0; i < middleList.length(); i++) {
                    JSONObject oi = middleList.optJSONObject(i);
                    if (oi == null) continue;
                    List<InterlineTicketData> fullList = new ArrayList<>();
                    JSONArray fl = oi.optJSONArray("fullList");
                    if (fl != null) {
                        for (int j = 0; j < fl.length(); j++) {
                            JSONObject fj = fl.optJSONObject(j);
                            if (fj != null) fullList.add(new InterlineTicketData(fj));
                        }
                    }
                    interlineData.add(new InterlineData(oi, fullList));
                }
            }
            canQuery = !"N".equals(data.optString("can_query"));
            resultIndex = data.optInt("result_index", resultIndex);
        }
        List<InterlineInfo> infos = parseInterlinesInfo(interlineData);
        if (infos.isEmpty()) throw new Exception("interline parse empty");
        List<InterlineInfo> filtered = filterInterlinesInfo(infos, o);
        String text = formatInterlines(filtered, o.format);
        return new QueryResult(text, filtered);
    }

    /** 查车次经停站。 */
    public QueryResult trainRoute(String trainCode, String departDate, String format) throws Exception {
        String searchUrl = SEARCH_API_BASE + "/search/v1/train/search?keyword=" + enc(trainCode)
            + "&date=" + departDate.replace("-", "");
        String searchBody = httpGet(searchUrl, null);
        if (searchBody == null) throw new Exception("search train failed");
        JSONObject sr = new JSONObject(searchBody);
        JSONArray sData = sr.optJSONArray("data");
        if (sData == null || sData.length() == 0) throw new Exception("未查询到对应车次");
        String trainNo = sData.optJSONObject(0).optString("train_no");

        String cookie = forgeCookie();
        String url = API_BASE + "/otn/queryTrainInfo/query"
            + "?leftTicketDTO.train_no=" + enc(trainNo)
            + "&leftTicketDTO.train_date=" + enc(departDate)
            + "&rand_code=";
        String body = httpGet(url, cookie);
        if (body == null) throw new Exception("get train route stations failed");
        JSONObject resp = new JSONObject(body);
        JSONObject d = resp.optJSONObject("data");
        JSONArray stationsArr = d != null ? d.optJSONArray("data") : null;
        if (stationsArr == null) throw new Exception("route stations empty");
        List<RouteStationInfo> infos = parseRouteStationsInfo(stationsArr);
        if (infos.isEmpty()) throw new Exception("未查询到相关车次信息");
        String text = "json".equalsIgnoreCase(format)
            ? routeStationsToJson(infos).toString(2)
            : formatRouteStations(infos);
        return new QueryResult(text, infos);
    }

    // ══════════ 纯解析（单测入口） ══════════

    /** 竖线串 result → TicketData 列表。 */
    static List<TicketData> parseTicketsData(JSONArray result) {
        List<TicketData> out = new ArrayList<>();
        for (int i = 0; i < result.length(); i++) {
            String raw = result.optString(i);
            String decoded = java.net.URLDecoder.decode(raw, java.nio.charset.StandardCharsets.UTF_8);
            String[] parts = decoded.split("\\|");
            // 补齐到 57 字段（index 安全）
            String[] f = new String[57];
            System.arraycopy(parts, 0, f, 0, Math.min(parts.length, 57));
            out.add(new TicketData(f));
        }
        return out;
    }

    /** TicketData + data.map → TicketInfo（中文站名 + 票价 + dw_flag）。 */
    static List<TicketInfo> parseTicketsInfo(List<TicketData> ticketsData, JSONObject map) {
        List<TicketInfo> out = new ArrayList<>();
        for (TicketData t : ticketsData) {
            String trainNo = t.get(IDX_TRAIN_NO);
            if (trainNo.isEmpty()) continue;
            String startDate = normalizeDate(t.get(IDX_START_DATE));
            String arriveDate = computeArriveDate(startDate, t.get(IDX_START_TIME), t.get(IDX_LISHI));
            String fromTele = t.get(IDX_FROM_TELECODE);
            String toTele = t.get(IDX_TO_TELECODE);
            List<Price> prices = extractPrices(t.get(IDX_YP_INFO_NEW), t.get(IDX_SEAT_DISCOUNT), t.f);
            List<String> dw = extractDWFlags(t.get(IDX_DW_FLAG));
            out.add(new TicketInfo(
                trainNo, t.get(IDX_TRAIN_CODE), startDate, t.get(IDX_START_TIME),
                arriveDate, t.get(IDX_ARRIVE_TIME), t.get(IDX_LISHI),
                map.optString(fromTele, fromTele), map.optString(toTele, toTele),
                fromTele, toTele, prices, dw));
        }
        return out;
    }

    /** 票价解析：yp_info_new 每 10 字符段 + seat_discount_info 每 5 字符段。 */
    static List<Price> extractPrices(String ypInfoNew, String seatDiscount, String[] ticketFields) {
        List<Price> prices = new ArrayList<>();
        if (ypInfoNew == null || ypInfoNew.isEmpty()) return prices;
        java.util.Map<String, Integer> discounts = new java.util.HashMap<>();
        if (seatDiscount != null) {
            for (int i = 0; i + 5 <= seatDiscount.length(); i += 5) {
                String seg = seatDiscount.substring(i, i + 5);
                if (seg.length() >= 2) {
                    try { discounts.put(String.valueOf(seg.charAt(0)), Integer.parseInt(seg.substring(1))); }
                    catch (Exception ignored) {}
                }
            }
        }
        final int SEG = 10;
        for (int i = 0; i + SEG <= ypInfoNew.length(); i += SEG) {
            String seg = ypInfoNew.substring(i, i + SEG);
            String seatCode;
            try {
                seatCode = Integer.parseInt(seg.substring(6, 10)) >= 3000 ? "W"
                    : (!SEAT_TYPES.containsKey(seg.substring(0, 1)) ? "H" : seg.substring(0, 1));
            } catch (Exception e) { seatCode = "H"; }
            String[] seatMeta = SEAT_TYPES.get(seatCode);
            if (seatMeta == null) continue;
            double price;
            try { price = Double.parseDouble(seg.substring(1, 6)) / 10.0; }
            catch (Exception e) { price = 0; }
            String num = "";
            if (ticketFields != null) {
                String shortCode = seatMeta[1];
                // 找该席别数量字段（如 ze_num）——映射到 TicketDataKeys 索引
                Integer idx = SEAT_NUM_INDEX.get(shortCode);
                if (idx != null && idx < ticketFields.length) num = ticketFields[idx];
            }
            Integer discount = discounts.containsKey(seatCode) ? discounts.get(seatCode) : null;
            prices.add(new Price(seatMeta[0], seatMeta[1], seatCode, num, price, discount));
        }
        return prices;
    }

    static List<String> extractDWFlags(String dwFlag) {
        List<String> out = new ArrayList<>();
        if (dwFlag == null || dwFlag.isEmpty()) return out;
        String[] parts = dwFlag.split("#");
        if (parts.length > 0 && "5".equals(parts[0])) out.add("智能动车组");
        if (parts.length > 1 && "1".equals(parts[1])) out.add("复兴号");
        if (parts.length > 2) {
            String c = parts[2];
            if (c.startsWith("Q")) out.add("静音车厢");
            else if (c.startsWith("R")) out.add("温馨动卧");
        }
        if (parts.length > 5 && "D".equals(parts[5])) out.add("动感号");
        if (parts.length > 6 && !"z".equals(parts[6])) out.add("支持选铺");
        if (parts.length > 7 && !"z".equals(parts[7])) out.add("老年优惠");
        return out;
    }

    /** 过滤 + 排序 + 限量（车次标志 OR 语义 / 发时窗口 / sort / slice）。 */
    @SuppressWarnings("unchecked")
    static <T extends TrainTrip> List<T> filterTicketsInfo(List<T> infos, QueryOptions o) {
        List<T> result = new ArrayList<>();
        String flags = o.trainFilterFlags == null ? "" : o.trainFilterFlags;
        for (T info : infos) {
            if (flags.isEmpty()) { result.add(info); continue; }
            for (int i = 0; i < flags.length(); i++) {
                if (trainFilterMatch(String.valueOf(flags.charAt(i)), info)) { result.add(info); break; }
            }
        }
        // 发时窗口
        result.removeIf(info -> {
            int hour = Integer.parseInt(info.tripStartTime().split(":")[0]);
            return hour < o.earliestStartTime || hour >= o.latestStartTime;
        });
        // 排序
        if (o.sortFlag != null && !o.sortFlag.isEmpty()) {
            Comparator<TrainTrip> cmp = timeComparator(o.sortFlag);
            if (cmp != null) {
                result.sort((a, b) -> cmp.compare(a, b));
                if (o.sortReverse) java.util.Collections.reverse(result);
            }
        }
        if (o.limitedNum > 0 && result.size() > o.limitedNum)
            return new ArrayList<>(result.subList(0, o.limitedNum));
        return result;
    }

    private static boolean trainFilterMatch(String flag, TrainTrip info) {
        String code = info.tripTrainCode();
        if (code == null) return false;
        switch (flag) {
            case "G": return code.startsWith("G") || code.startsWith("C");
            case "D": return code.startsWith("D");
            case "Z": return code.startsWith("Z");
            case "T": return code.startsWith("T");
            case "K": return code.startsWith("K");
            case "O": return !(code.startsWith("G") || code.startsWith("C") || code.startsWith("D")
                || code.startsWith("Z") || code.startsWith("T") || code.startsWith("K"));
            case "F": return info.tripDwFlags().contains("复兴号");
            case "S": return info.tripDwFlags().contains("智能动车组");
            default: return false;
        }
    }

    private static Comparator<TrainTrip> timeComparator(String sortFlag) {
        switch (sortFlag == null ? "" : sortFlag) {
            case "startTime":
                return Comparator.comparing(TrainTrip::tripStartDate)
                    .thenComparing(TrainTrip::tripStartTime);
            case "arriveTime":
                return Comparator.comparing(TrainTrip::tripArriveDate)
                    .thenComparing(TrainTrip::tripArriveTime);
            case "duration":
                return Comparator.comparing(TrainTrip::tripLishi);
            default:
                return null;
        }
    }

    private static List<InterlineInfo> filterInterlinesInfo(List<InterlineInfo> infos, QueryOptions o) {
        return filterTicketsInfo(infos, o);
    }

    // ══════════ 中转解析 ══════════

    static List<InterlineInfo> parseInterlinesInfo(List<InterlineData> interlineData) {
        List<InterlineInfo> out = new ArrayList<>();
        for (InterlineData t : interlineData) {
            List<TicketInfo> ticketList = parseInterlinesTicketInfo(t.fullList);
            if (ticketList.isEmpty()) continue;
            String lishi = extractLishi(t.allLishi);
            out.add(new InterlineInfo(
                lishi, t.startTime, t.trainDate, t.middleDate, t.arriveDate, t.arriveTime,
                t.fromName, t.middleName, t.endName,
                ticketList.get(0).startTrainCode, t.firstTrainNo, t.secondTrainNo,
                "0".equals(t.sameStation), "Y".equals(t.sameTrain), t.waitTime, ticketList));
        }
        return out;
    }

    static List<TicketInfo> parseInterlinesTicketInfo(List<InterlineTicketData> fullList) {
        List<TicketInfo> out = new ArrayList<>();
        for (InterlineTicketData d : fullList) {
            String startDate = normalizeDate(d.startDate);
            String arriveDate = computeArriveDate(startDate, d.startTime, d.lishi);
            List<Price> prices = extractPrices(d.ypInfo, d.seatDiscount, null);
            out.add(new TicketInfo(
                d.trainNo, d.startTrainCode, startDate, d.startTime,
                arriveDate, d.arriveTime, d.lishi,
                d.fromName, d.toName, d.fromTelecode, d.toTelecode, prices, extractDWFlags(d.dwFlag)));
        }
        return out;
    }

    /** "H小时M分钟" / "M分钟" → "hh:mm"。 */
    static String extractLishi(String allLishi) {
        if (allLishi == null) return "00:00";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?:(\\d+)小时)?(\\d+?)分钟").matcher(allLishi);
        if (!m.find()) return "00:00";
        String minutes = m.group(2);
        if (m.group(1) == null) return "00:" + minutes;
        return String.format("%02d", Integer.parseInt(m.group(1))) + ":" + minutes;
    }

    // ══════════ 经停站解析 ══════════

    static List<RouteStationInfo> parseRouteStationsInfo(JSONArray rawData) {
        List<RouteStationInfo> out = new ArrayList<>();
        for (int i = 0; i < rawData.length(); i++) {
            JSONObject o = rawData.optJSONObject(i);
            if (o == null) continue;
            String trainClassName = i == 0 ? o.optString("train_class_name") : null;
            String serviceType = i == 0 ? o.optString("service_type") : null;
            String endStationName = i == 0 ? o.optString("end_station_name") : null;
            out.add(new RouteStationInfo(
                trainClassName, serviceType, endStationName,
                o.optString("station_name"), o.optString("station_train_code"),
                o.optString("arrive_time"), o.optString("start_time"),
                o.optString("running_time"), o.optString("arrive_day_str")));
        }
        return out;
    }

    // ══════════ 格式化 ══════════

    static String format(List<TicketInfo> infos, String fmt) {
        if (infos.isEmpty()) return "没有查询到相关车次信息";
        if ("csv".equalsIgnoreCase(fmt)) return formatCsv(infos);
        if ("json".equalsIgnoreCase(fmt)) {
            try { return formatJson(infos).toString(2); } catch (Exception e) { return "JSON 序列化失败"; }
        }
        return formatText(infos);
    }

    static String formatText(List<TicketInfo> infos) {
        if (infos.isEmpty()) return "没有查询到相关车次信息";
        StringBuilder sb = new StringBuilder("车次|出发站 -> 到达站|出发时间 -> 到达时间|历时\n");
        for (TicketInfo t : infos) {
            sb.append(t.startTrainCode).append(" ").append(t.fromStation)
              .append("(telecode:").append(t.fromTelecode).append(") -> ")
              .append(t.toStation).append("(telecode:").append(t.toTelecode).append(") ")
              .append(t.startTime).append(" -> ").append(t.arriveTime)
              .append(" 历时：").append(t.lishi);
            for (Price p : t.prices) {
                sb.append("\n- ").append(p.seatName).append(": ").append(formatTicketStatus(p.num))
                  .append(" ").append(p.price).append("元");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    static String formatCsv(List<TicketInfo> infos) {
        StringBuilder sb = new StringBuilder("车次,出发站,到达站,出发时间,到达时间,历时,票价,特色标签\n");
        for (TicketInfo t : infos) {
            sb.append(t.startTrainCode).append(",").append(t.fromStation)
              .append("(telecode:").append(t.fromTelecode).append("),")
              .append(t.toStation).append("(telecode:").append(t.toTelecode).append("),")
              .append(t.startTime).append(",").append(t.arriveTime).append(",").append(t.lishi).append(",[");
            for (Price p : t.prices) {
                sb.append(p.seatName).append(": ").append(formatTicketStatus(p.num)).append(p.price).append("元,");
            }
            sb.append("],").append(t.dwFlags.isEmpty() ? "/" : String.join("&", t.dwFlags)).append("\n");
        }
        return sb.toString();
    }

    static JSONArray formatJson(List<TicketInfo> infos) {
        JSONArray arr = new JSONArray();
        for (TicketInfo t : infos) {
            try {
                JSONArray prices = new JSONArray();
                for (Price p : t.prices) {
                    prices.put(new JSONObject()
                        .put("seat_name", p.seatName).put("short", p.shortCode)
                        .put("seat_type_code", p.seatTypeCode).put("num", p.num)
                        .put("price", p.price)
                        .put("discount", p.discount == null ? JSONObject.NULL : p.discount));
                }
                arr.put(new JSONObject()
                    .put("train_no", t.trainNo).put("start_train_code", t.startTrainCode)
                    .put("start_date", t.startDate).put("start_time", t.startTime)
                    .put("arrive_date", t.arriveDate).put("arrive_time", t.arriveTime)
                    .put("lishi", t.lishi)
                    .put("from_station", t.fromStation).put("to_station", t.toStation)
                    .put("from_station_telecode", t.fromTelecode).put("to_station_telecode", t.toTelecode)
                    .put("prices", prices).put("dw_flag", new JSONArray(t.dwFlags)));
            } catch (Exception ignored) {}
        }
        return arr;
    }

    static String formatInterlines(List<InterlineInfo> infos, String fmt) {
        if (infos.isEmpty()) return "没有查询到相关车次信息";
        if ("json".equalsIgnoreCase(fmt)) {
            try { return interlinesToJson(infos).toString(2); } catch (Exception e) { return "JSON 序列化失败"; }
        }
        StringBuilder sb = new StringBuilder("出发时间 -> 到达时间 | 出发车站 -> 中转车站 -> 到达车站 | 换乘标志 | 换乘等待时间 | 总历时\n\n");
        for (InterlineInfo t : infos) {
            sb.append(t.startDate).append(" ").append(t.startTime).append(" -> ")
              .append(t.arriveDate).append(" ").append(t.arriveTime).append(" | ")
              .append(t.fromName).append(" -> ").append(t.middleName).append(" -> ").append(t.endName).append(" | ")
              .append(t.sameTrain ? "同车换乘" : t.sameStation ? "同站换乘" : "换站换乘")
              .append(" | ").append(t.waitTime).append(" | ").append(t.lishi).append("\n\n");
            String sub = formatText(t.ticketList).replace("\n", "\n\t");
            sb.append("\t").append(sub).append("\n");
        }
        return sb.toString();
    }

    private static JSONArray interlinesToJson(List<InterlineInfo> infos) {
        JSONArray arr = new JSONArray();
        for (InterlineInfo t : infos) {
            try {
                arr.put(new JSONObject()
                    .put("lishi", t.lishi).put("start_time", t.startTime)
                    .put("start_date", t.startDate).put("middle_date", t.middleDate)
                    .put("arrive_date", t.arriveDate).put("arrive_time", t.arriveTime)
                    .put("from_station_name", t.fromName).put("middle_station_name", t.middleName)
                    .put("end_station_name", t.endName)
                    .put("start_train_code", t.startTrainCode)
                    .put("first_train_no", t.firstTrainNo).put("second_train_no", t.secondTrainNo)
                    .put("same_station", t.sameStation).put("same_train", t.sameTrain)
                    .put("wait_time", t.waitTime)
                    .put("ticket_list", formatJson(t.ticketList)));
            } catch (Exception ignored) {}
        }
        return arr;
    }

    static String formatRouteStations(List<RouteStationInfo> infos) {
        RouteStationInfo head = infos.get(0);
        StringBuilder sb = new StringBuilder(head.stationTrainCode + "次列车（"
            + (head.trainClassName != null ? head.trainClassName : "") + " "
            + ("0".equals(head.serviceType) ? "无空调" : "有空调") + "）\n");
        sb.append("站序|车站|车次|到达时间|出发时间|历时\n");
        for (int i = 0; i < infos.size(); i++) {
            RouteStationInfo r = infos.get(i);
            sb.append(i + 1).append("|").append(r.stationName).append("|").append(r.stationTrainCode)
              .append("|").append(r.arriveTime).append("|").append(r.startTime)
              .append("|").append(r.arriveDayStr).append(" ").append(r.lishi).append("\n");
        }
        return sb.toString();
    }

    static JSONArray routeStationsToJson(List<RouteStationInfo> infos) {
        JSONArray arr = new JSONArray();
        for (RouteStationInfo r : infos) {
            try {
                JSONObject o = new JSONObject()
                    .put("station_name", r.stationName)
                    .put("station_train_code", r.stationTrainCode)
                    .put("arrive_time", r.arriveTime).put("start_time", r.startTime)
                    .put("lishi", r.lishi).put("arrive_day_str", r.arriveDayStr);
                if (r.trainClassName != null) o.put("train_class_name", r.trainClassName);
                if (r.serviceType != null) o.put("service_type", r.serviceType);
                if (r.endStationName != null) o.put("end_station_name", r.endStationName);
                arr.put(o);
            } catch (Exception ignored) {}
        }
        return arr;
    }

    // ══════════ 工具函数 ══════════

    static String formatTicketStatus(String num) {
        if (num != null && num.matches("\\d+")) {
            int count = Integer.parseInt(num);
            return count == 0 ? "无票" : "剩余" + count + "张票";
        }
        if ("有".equals(num) || "充足".equals(num)) return "有票";
        if ("无".equals(num) || "--".equals(num) || num == null || num.isEmpty()) return "无票";
        if ("候补".equals(num)) return "无票需候补";
        return num + "票";
    }

    /** 上海时区当前日期 yyyy-MM-dd。 */
    public static String currentDateShanghai() {
        return LocalDate.now(ZoneId.of("Asia/Shanghai")).format(DateTimeFormatter.ISO_LOCAL_DATE);
    }

    /** 日期不能早于今天（上海时区）。 */
    public static boolean checkDate(String date) {
        try {
            LocalDate input = LocalDate.parse(date, DateTimeFormatter.ISO_LOCAL_DATE);
            LocalDate today = LocalDate.now(ZoneId.of("Asia/Shanghai"));
            return !input.isBefore(today);
        } catch (Exception e) { return false; }
    }

    /** yyyyMMdd → yyyy-MM-dd（容忍已带 -）。 */
    static String normalizeDate(String d) {
        if (d == null || d.isEmpty()) return "";
        if (d.matches("\\d{4}-\\d{2}-\\d{2}")) return d;
        if (d.matches("\\d{8}")) return d.substring(0, 4) + "-" + d.substring(4, 6) + "-" + d.substring(6, 8);
        return d;
    }

    /** 到达日期 = 出发日期 + 历时（跨天处理）。 */
    static String computeArriveDate(String startDate, String startTime, String lishi) {
        try {
            if (startDate.isEmpty() || startTime.isEmpty() || lishi.isEmpty()) return startDate;
            String[] st = startTime.split(":");
            String[] ls = lishi.split(":");
            int totalMin = Integer.parseInt(st[0]) * 60 + Integer.parseInt(st[1])
                + Integer.parseInt(ls[0]) * 60 + Integer.parseInt(ls[1]);
            LocalDate d = LocalDate.parse(normalizeDate(startDate), DateTimeFormatter.ISO_LOCAL_DATE);
            d = d.plusDays(totalMin / 1440);
            return d.format(DateTimeFormatter.ISO_LOCAL_DATE);
        } catch (Exception e) { return startDate; }
    }

    // ── 席位类型映射（对齐 12306-mcp SEAT_TYPES） ──
    static final java.util.Map<String, String[]> SEAT_TYPES = new java.util.LinkedHashMap<>();
    static final java.util.Map<String, Integer> SEAT_NUM_INDEX = new java.util.HashMap<>();
    static {
        SEAT_TYPES.put("9", new String[]{"商务座", "swz"});
        SEAT_TYPES.put("P", new String[]{"特等座", "tz"});
        SEAT_TYPES.put("M", new String[]{"一等座", "zy"});
        SEAT_TYPES.put("D", new String[]{"优选一等座", "zy"});
        SEAT_TYPES.put("O", new String[]{"二等座", "ze"});
        SEAT_TYPES.put("S", new String[]{"二等包座", "ze"});
        SEAT_TYPES.put("6", new String[]{"高级软卧", "gr"});
        SEAT_TYPES.put("A", new String[]{"高级动卧", "gr"});
        SEAT_TYPES.put("4", new String[]{"软卧", "rw"});
        SEAT_TYPES.put("I", new String[]{"一等卧", "rw"});
        SEAT_TYPES.put("F", new String[]{"动卧", "rw"});
        SEAT_TYPES.put("3", new String[]{"硬卧", "yw"});
        SEAT_TYPES.put("J", new String[]{"二等卧", "yw"});
        SEAT_TYPES.put("2", new String[]{"软座", "rz"});
        SEAT_TYPES.put("1", new String[]{"硬座", "yz"});
        SEAT_TYPES.put("W", new String[]{"无座", "wz"});
        SEAT_TYPES.put("H", new String[]{"其他", "qt"});
        // 席别数量字段 → TicketDataKeys 索引（types.ts）
        // gg_num=20 gr_num=21 qt_num=22 rw_num=23 rz_num=24 tz_num=25 wz_num=26 yb_num=27
        // yw_num=28 yz_num=29 ze_num=30 zy_num=31 swz_num=32 srrb_num=33
        SEAT_NUM_INDEX.put("swz", 32);
        SEAT_NUM_INDEX.put("tz", 25);
        SEAT_NUM_INDEX.put("zy", 31);
        SEAT_NUM_INDEX.put("ze", 30);
        SEAT_NUM_INDEX.put("gr", 21);
        SEAT_NUM_INDEX.put("rw", 23);
        SEAT_NUM_INDEX.put("yw", 28);
        SEAT_NUM_INDEX.put("rz", 24);
        SEAT_NUM_INDEX.put("yz", 29);
        SEAT_NUM_INDEX.put("wz", 26);
        SEAT_NUM_INDEX.put("qt", 22);
    }
}
