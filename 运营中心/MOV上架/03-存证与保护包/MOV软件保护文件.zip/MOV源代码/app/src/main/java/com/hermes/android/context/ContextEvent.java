package com.hermes.android.context;

import org.json.JSONObject;

import java.util.Objects;

/**
 * 一次情境转移事件 — 触发 → 快照对比 → 通知消费者 → 落盘。
 *
 * <p>before/after 记录转移前后的完整设备快照，消费者可据此计算差量。
 * 对于 battery_below/above，metadata 携带触发阈值。
 */
public final class ContextEvent {

    /** 事件类型 */
    public final ContextEventType type;
    /** 转移前的设备快照 */
    public final ContextSnapshot before;
    /** 转移后的设备快照 */
    public final ContextSnapshot after;
    /** 事件时间戳 ms */
    public final long timestampMs;
    /** 额外元数据（如 battery threshold 值） */
    public final JSONObject metadata;

    private ContextEvent(ContextEventType type, ContextSnapshot before,
                         ContextSnapshot after, JSONObject metadata) {
        this.type = type;
        this.before = before;
        this.after = after;
        this.timestampMs = after.capturedAtMs;
        this.metadata = metadata != null ? metadata : new JSONObject();
    }

    public static ContextEvent of(ContextEventType type, ContextSnapshot before,
                                   ContextSnapshot after) {
        return new ContextEvent(type, before, after, null);
    }

    public static ContextEvent of(ContextEventType type, ContextSnapshot before,
                                   ContextSnapshot after, JSONObject metadata) {
        return new ContextEvent(type, before, after, metadata);
    }

    /** 序列化为 JSONL 的一行 */
    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("type", type.name());
            o.put("timestamp_ms", timestampMs);
            o.put("before", before.toJson());
            o.put("after", after.toJson());
            if (metadata.length() > 0) o.put("metadata", metadata);
        } catch (org.json.JSONException ignored) {
        }
        return o;
    }

    /** 从元数据中读取 threshold 值（battery 事件专用） */
    public int getThreshold() {
        return metadata.optInt("threshold", -1);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ContextEvent)) return false;
        ContextEvent that = (ContextEvent) o;
        return type == that.type
                && timestampMs == that.timestampMs
                && Objects.equals(before, that.before)
                && Objects.equals(after, that.after);
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, before, after, timestampMs);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("ContextEvent{");
        sb.append(type.name());
        if (type == ContextEventType.BATTERY_BELOW || type == ContextEventType.BATTERY_ABOVE) {
            sb.append("(").append(getThreshold()).append("%)");
        }
        sb.append(" @").append(timestampMs).append("}");
        return sb.toString();
    }
}
