package com.hermes.android;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * RulesManager — 规则任务级热加载 (评审修正版)。
 *
 * 安全铁律: 本地文件不可信。红线硬编码, 永不从 JSON 读。
 * 并发策略: volatile + 任务开始时加载, 执行期间不变。
 * 不加 FileObserver: 避免后台线程修改规则导致 AgentLoop 读到脏数据。
 *
 * 三级规则:
 *   红线 — Java static final, 不可覆盖 (rm -rf, mkfs, shutdown...)
 *   黄线 — JSON 可配, 默认值兜底 (curl, pip, 受保护路径...)
 *   绿线 — JSON 可配, 默认值兜底 (max_steps, timeout...)
 */
public class RulesManager {

    private static final String TAG = "RulesManager";
    private static final String RULES_PATH = "rules/rules.json";

    // ==================== 红线 — 硬编码, 永不从 JSON 读 ====================

    /** 破坏性命令: 任何情况下都必须拦截, JSON 里写什么都没用 */
    public static final Set<String> REDLINE_SHELL = Collections.unmodifiableSet(
            new HashSet<>(java.util.Arrays.asList(
                    "rm -rf /", "rm -rf /*", "rm -r /", "rm -fr /",
                    "mkfs.", "mkfs ", "dd if=", "> /dev/sda", "> /dev/mmc",
                    "chmod 777 /", "chmod -R 777 /",
                    "shutdown", "reboot", "poweroff", "halt",
                    "init 0", "init 6",
                    ":(){ :|:& };:",  // fork bomb
                    "chown -R", "chown root"
            )));

    /** 红线检查: cmd 是否包含破坏性模式 */
    public static boolean isRedline(String cmd) {
        if (cmd == null) return false;
        String lower = cmd.toLowerCase().trim();
        for (String p : REDLINE_SHELL) {
            if (lower.contains(p.toLowerCase())) return true;
        }
        return false;
    }

    // ==================== 实例 ====================

    private static volatile RulesManager instance;
    private final File rulesFile;
    private volatile RulesConfig current;
    private long lastModified;

    private RulesManager(Context ctx) {
        this.rulesFile = new File(ctx.getApplicationContext().getFilesDir(), RULES_PATH);
    }

    /** Application.onCreate 调用一次 */
    public static void init(Context ctx) {
        if (instance != null) return;
        synchronized (RulesManager.class) {
            if (instance != null) return;
            instance = new RulesManager(ctx);
            instance.current = instance.load();
        }
    }

    /** 取当前规则 (各处随时调用, volatile 保证可见) */
    public static RulesConfig get() {
        RulesManager m = instance;
        if (m == null || m.current == null) return RulesConfig.DEFAULTS;
        return m.current;
    }

    /** agent_start 时调用: 文件有变化才重读, 解析失败保持旧值 */
    public static void loadIfChanged() {
        RulesManager m = instance;
        if (m == null) return;
        long now = m.rulesFile.lastModified();
        if (now != m.lastModified) {
            m.lastModified = now;
            m.current = m.load();
        }
    }

    // ==================== 文件读写 ====================

    private RulesConfig load() {
        ensureDir();
        if (!rulesFile.exists()) {
            writeDefaults();
            return RulesConfig.DEFAULTS;
        }
        try {
            byte[] raw = java.nio.file.Files.readAllBytes(rulesFile.toPath());
            String json = new String(raw, StandardCharsets.UTF_8);
            RulesConfig parsed = RulesConfig.fromJson(new JSONObject(json));
            Log.i(TAG, "规则已加载: maxSteps=" + parsed.maxSteps
                    + " confirmPatterns=" + parsed.shellRequireConfirmPatterns.size()
                    + " protectedPaths=" + parsed.fileProtectedPaths.size());
            return parsed;
        } catch (Exception e) {
            Log.w(TAG, "规则解析失败, 保持旧值: " + e.getMessage());
            return current != null ? current : RulesConfig.DEFAULTS;
        }
    }

    private void ensureDir() {
        File dir = rulesFile.getParentFile();
        if (dir != null && !dir.exists()) dir.mkdirs();
    }

    private void writeDefaults() {
        ensureDir();
        try (OutputStreamWriter w = new OutputStreamWriter(
                new FileOutputStream(rulesFile), StandardCharsets.UTF_8)) {
            w.write(RulesConfig.DEFAULTS.toJson().toString(2));
        } catch (Exception e) {
            Log.w(TAG, "写默认规则失败: " + e.getMessage());
        }
    }

    // ==================== 规则配置 (只有黄线和绿线) ====================

    public static class RulesConfig {
        public final int version;
        public final int maxSteps;
        public final long maxExecMs;
        /** 黄线: 需弹确认的命令模式 (如 curl, pip install) */
        public final Set<String> shellRequireConfirmPatterns;
        public final int shellMaxTimeoutSec;
        /** 黄线: 受保护的文件路径 (如 .git, *.key) */
        public final Set<String> fileProtectedPaths;
        public final long fileMaxWriteSizeBytes;
        /** 黄线: 禁用的设备能力 */
        public final Set<String> deviceDisabledCapabilities;
        public final Set<String> deviceRequireConfirm;
        /** 绿线: 自动审批的工具 */
        public final Set<String> agentAutoApproveTools;

        RulesConfig(int version, int maxSteps, long maxExecMs,
                    Set<String> shellRequireConfirmPatterns, int shellMaxTimeoutSec,
                    Set<String> fileProtectedPaths, long fileMaxWriteSizeBytes,
                    Set<String> deviceDisabledCapabilities, Set<String> deviceRequireConfirm,
                    Set<String> agentAutoApproveTools) {
            this.version = version; this.maxSteps = maxSteps; this.maxExecMs = maxExecMs;
            this.shellRequireConfirmPatterns = shellRequireConfirmPatterns;
            this.shellMaxTimeoutSec = shellMaxTimeoutSec;
            this.fileProtectedPaths = fileProtectedPaths;
            this.fileMaxWriteSizeBytes = fileMaxWriteSizeBytes;
            this.deviceDisabledCapabilities = deviceDisabledCapabilities;
            this.deviceRequireConfirm = deviceRequireConfirm;
            this.agentAutoApproveTools = agentAutoApproveTools;
        }

        public boolean isShellConfirmRequired(String cmd) {
            if (cmd == null) return false;
            String lower = cmd.toLowerCase().trim();
            for (String p : shellRequireConfirmPatterns) {
                if (lower.contains(p.toLowerCase())) return true;
            }
            return false;
        }
        public boolean isFilePathProtected(String path) {
            if (path == null) return false;
            for (String p : fileProtectedPaths) {
                if (path.contains(p)) return true;
                if (p.startsWith("*.") && path.endsWith(p.substring(1))) return true;
            }
            return false;
        }
        public boolean isCapabilityDisabled(String cap) {
            return deviceDisabledCapabilities.contains(cap);
        }
        public boolean isCapabilityConfirmRequired(String cap) {
            return deviceRequireConfirm.contains(cap);
        }
        public boolean isAutoApproved(String toolName) {
            return agentAutoApproveTools.contains(toolName);
        }

        JSONObject toJson() {
            try {
                JSONObject o = new JSONObject();
                o.put("version", version);
                o.put("shell", new JSONObject()
                        .put("require_confirm_patterns", new JSONArray(shellRequireConfirmPatterns))
                        .put("max_timeout_sec", shellMaxTimeoutSec));
                o.put("file", new JSONObject()
                        .put("protected_paths", new JSONArray(fileProtectedPaths))
                        .put("max_write_size_bytes", fileMaxWriteSizeBytes));
                o.put("device", new JSONObject()
                        .put("disabled_capabilities", new JSONArray(deviceDisabledCapabilities))
                        .put("require_confirm", new JSONArray(deviceRequireConfirm)));
                o.put("agent", new JSONObject()
                        .put("max_steps", maxSteps)
                        .put("max_exec_ms", maxExecMs)
                        .put("auto_approve_tools", new JSONArray(agentAutoApproveTools)));
                return o;
            } catch (Exception e) { return new JSONObject(); }
        }

        static RulesConfig fromJson(JSONObject o) {
            JSONObject shell = o.optJSONObject("shell");
            JSONObject file = o.optJSONObject("file");
            JSONObject device = o.optJSONObject("device");
            JSONObject agent = o.optJSONObject("agent");
            return new RulesConfig(
                    o.optInt("version", 1),
                    agent != null ? agent.optInt("max_steps", 12) : 12,
                    agent != null ? agent.optLong("max_exec_ms", 600000) : 600000,
                    jsonArrayToSet(shell != null ? shell.optJSONArray("require_confirm_patterns") : null),
                    shell != null ? shell.optInt("max_timeout_sec", 600) : 600,
                    jsonArrayToSet(file != null ? file.optJSONArray("protected_paths") : null),
                    file != null ? file.optLong("max_write_size_bytes", 1048576) : 1048576,
                    jsonArrayToSet(device != null ? device.optJSONArray("disabled_capabilities") : null),
                    jsonArrayToSet(device != null ? device.optJSONArray("require_confirm") : null),
                    jsonArrayToSet(agent != null ? agent.optJSONArray("auto_approve_tools") : null)
            );
        }

        private static Set<String> jsonArrayToSet(JSONArray arr) {
            Set<String> s = new HashSet<>();
            if (arr != null) for (int i = 0; i < arr.length(); i++) {
                String v = arr.optString(i);
                if (v != null && !v.isEmpty()) s.add(v);
            }
            return s;
        }

        static final RulesConfig DEFAULTS = new RulesConfig(1, 12, 600000,
                new HashSet<>(java.util.Arrays.asList("curl", "wget", "pip install", "npm install -g", "apt-get install")),
                600,
                new HashSet<>(java.util.Arrays.asList(".git", "secret", ".env", "*.key", "*.pem", "*.keystore")),
                1048576,
                new HashSet<>(java.util.Arrays.asList("sms.send", "contact.write")),
                new HashSet<>(java.util.Arrays.asList("app.install", "camera.capture")),
                new HashSet<>(java.util.Arrays.asList("file.read", "file.list", "system.info"))
        );
    }
}
