package com.hermes.android.browser;

import org.json.JSONObject;

/**
 * 批3: 真实浏览器控制工具（mov-webbridge skill）——工具参数 → CDP 命令映射（纯逻辑可单测）。
 * 执行走 CdpClient（静态单例）；未连接时 send 抛错 → 工具返回"未配置浏览器"归因。
 */
public class MovWebBridge {

    /** 工具 → CDP 命令：返回 {method, params}；未识别工具返回 null */
    public static JSONObject cdpCommand(String toolName, JSONObject args) throws Exception {
        JSONObject params = new JSONObject();
        switch (toolName == null ? "" : toolName) {
            case "wb.navigate":
                params.put("url", args.optString("url", ""));
                return cmd("Page.navigate", params);
            case "wb.evaluate":
                params.put("expression", args.optString("expression", ""));
                params.put("returnByValue", true);
                return cmd("Runtime.evaluate", params);
            case "wb.snapshot":
                params.put("expression", snapshotExpr());
                params.put("returnByValue", true);
                return cmd("Runtime.evaluate", params);
            case "wb.click":
                params.put("expression", clickExpr(args.optString("selector", "")));
                params.put("returnByValue", true);
                return cmd("Runtime.evaluate", params);
            case "wb.fill":
                params.put("expression", fillExpr(args.optString("selector", ""), args.optString("value", "")));
                params.put("returnByValue", true);
                return cmd("Runtime.evaluate", params);
            case "wb.screenshot":
                params.put("format", "png");
                return cmd("Page.captureScreenshot", params);
            default:
                return null;
        }
    }

    private static JSONObject cmd(String method, JSONObject params) throws Exception {
        return new JSONObject().put("method", method).put("params", params);
    }

    private static String snapshotExpr() {
        return "(()=>{const r={url:location.href,title:document.title,"
                + "text:document.body.innerText.slice(0,8000)};return JSON.stringify(r)})()";
    }

    private static String clickExpr(String selector) {
        return "(()=>{const el=document.querySelector('" + jsEscape(selector)
                + "');if(!el)return 'not-found';el.click();return 'ok'})()";
    }

    private static String fillExpr(String selector, String value) {
        return "(()=>{const el=document.querySelector('" + jsEscape(selector)
                + "');if(!el)return 'not-found';el.value='" + jsEscape(value)
                + "';el.dispatchEvent(new Event('input',{bubbles:true}));return 'ok'})()";
    }

    /** JS 字符串转义（selector/value 注入 JS 表达式） */
    static String jsEscape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n");
    }
}
