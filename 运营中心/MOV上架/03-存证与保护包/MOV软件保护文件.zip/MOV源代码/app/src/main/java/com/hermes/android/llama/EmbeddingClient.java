package com.hermes.android.llama;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/**
 * llama-server 本地 embedding API 客户端核心（纯 JVM 可单测，零网络）——OpenAI 兼容契约。
 * 契约：POST http://127.0.0.1:8081/v1/embeddings，Bearer token 鉴权。
 * 桥层（Android，cbId 异步）负责实际 HTTP；本类只做 payload 构造/响应解析/余弦相似度/错误映射。
 * 配套：EmbeddingServerManager（8081 实例，跑 bge-small-zh-v1.5，见 DESIGN_SEMANTIC_RECALL_2026-08-09.md）。
 */
public class EmbeddingClient {

    public static final String BASE_URL = "http://127.0.0.1:8081";
    public static final String DEFAULT_MODEL = "bge-small-zh-v1.5";

    /** OpenAI /v1/embeddings payload 构造（纯 JVM）。texts 为空返回 null。 */
    public static String buildEmbeddingPayload(String model, List<String> texts) {
        if (texts == null || texts.isEmpty()) return null;
        try {
            JSONObject body = new JSONObject();
            body.put("model", model != null ? model : DEFAULT_MODEL);
            JSONArray input = new JSONArray();
            for (String t : texts) {
                input.put(t != null ? t : "");
            }
            body.put("input", input);
            return body.toString();
        } catch (Exception e) {
            throw new RuntimeException("buildEmbeddingPayload", e);
        }
    }

    /** 解析 /v1/embeddings 响应 → data[].embedding（按 index 排序）。
     *  返回 float[][]，第 i 行 = 请求第 i 个文本的向量；无法解析返回 null。 */
    public static float[][] parseResponse(String raw) {
        if (raw == null) return null;
        try {
            JSONObject o = new JSONObject(raw);
            JSONArray data = o.optJSONArray("data");
            if (data == null || data.length() == 0) return null;
            int n = data.length();
            float[][] out = new float[n][];
            for (int i = 0; i < n; i++) {
                JSONObject item = data.optJSONObject(i);
                if (item == null) return null;
                int idx = item.optInt("index", i);
                if (idx < 0 || idx >= n) idx = i;   // 防御越界，llama.cpp 正常 0..n-1
                JSONArray emb = item.optJSONArray("embedding");
                if (emb == null) return null;
                float[] v = new float[emb.length()];
                for (int j = 0; j < emb.length(); j++) v[j] = (float) emb.optDouble(j, 0.0);
                out[idx] = v;
            }
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    /** 余弦相似度（纯 JVM）。null / 维度不一致 / 零向量返回 0。 */
    public static double cosine(float[] a, float[] b) {
        if (a == null || b == null || a.length == 0 || a.length != b.length) return 0.0;
        double dot = 0, na = 0, nb = 0;
        for (int i = 0; i < a.length; i++) {
            dot += a[i] * b[i];
            na += a[i] * a[i];
            nb += b[i] * b[i];
        }
        if (na == 0 || nb == 0) return 0.0;
        return dot / (Math.sqrt(na) * Math.sqrt(nb));
    }

    /** 错误映射 → 诚实卡文案（连接失败/鉴权/服务异常） */
    public static String mapError(int httpCode, String body) {
        if (httpCode <= 0) return "语义召回服务连不上（embedding llama-server 未启动）";
        if (httpCode == 401 || httpCode == 403) return "语义召回服务 token 鉴权失败，检查设置页";
        if (httpCode >= 500) return "语义召回服务异常（" + httpCode + "），稍后再试";
        if (httpCode == 400) return "语义召回请求被拒（400），参数或模型名不对";
        return "语义召回请求失败（" + httpCode + "）";
    }
}
