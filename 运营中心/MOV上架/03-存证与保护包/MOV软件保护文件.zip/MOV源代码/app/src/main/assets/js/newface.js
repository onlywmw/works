/* ============================================================
   newface.js — MOV 新脸 Phase 1 (静态 Demo, debug 包)
   ============================================================ */

window.NewFace = (function() {
  /* 第三幕清场: 老底导航已删, 无需同步隐藏 */

  /* ── Mock 数据（Phase 1 专用，debug 包） ── */
  var MOCK = {
    historyChats: [
      { text: '帮我查《庆余年》第三季什么时候播', time: '今天 14:22' },
      { text: '订一张明天去上海的火车票', time: '昨天 09:15' },
      { text: '帮我写一个贪吃蛇游戏', time: '7月28日' }
    ],
    myItems: [
      { type: 'apk', name: 'snake.apk', desc: '任务产出', time: '昨天' },
      { type: 'file', name: 'report.html', desc: '数据分析报告', time: '7月28日' }
    ]
  };

  /* ── 场景数据（W3: 演示卡下线, 只留 drama 供 startFlow 展示标题; flight/shop 走真链路） ── */
  var FLOWS = {
    drama: {
      utter: '我要追剧',
      understanding: '理解：继续你最近在追的剧',
      ctx: '情境图谱（本地）：《漫长的季节》看到第 8 集 21:14',
      options: [
        {poster:['linear-gradient(135deg,#3d4a5c,#7a5c48)','漫长的季节'],main:'继续第 8 集',price:'',sub:'腾讯视频 · 从 21:14 接着看 · 还剩 31 分钟',tags:[['ctx','接着上次'],['plat','腾讯视频']],action:'player'},
        {poster:['linear-gradient(135deg,#54483d,#8d7a5c)','繁花'],main:'繁花 · 第 22 集',price:'',sub:'爱奇艺 · 你标记过「想看」· 今晚更新',tags:[['plat','爱奇艺']],action:'player'},
        {poster:['linear-gradient(135deg,#3d5c4e,#5c8d7a)','我的阿勒泰'],main:'我的阿勒泰 · 全 8 集',price:'',sub:'B站 · 评分 9.2 · 朋友最近在看',tags:[['plat','B站']],action:'player'}
      ]
    }
  };

  /* ── 视图切换 ── */
  function showFace() {
    document.querySelectorAll('.view').forEach(function(v){ v.classList.remove('act'); });
    document.getElementById('view-face').classList.add('act');
    // 专家新脸化: 回 home 隐藏专家面板, 恢复封面, 防 journal 误渲染旧容器
    _faceMode = 'home';
    if (typeof expertClosePreview === 'function') expertClosePreview();   // 关掉可能开着的预览 overlay
    var pane = document.getElementById('expertPane'); if (pane) pane.style.display = 'none';
    var cover = document.getElementById('faceCover'); if (cover) cover.style.display = '';
    if (window.MovRender) MovRender.setRoom(null);
    // FUSION F5: 回到新脸时若有最近慢脑交付 → 回脸交付卡
    renderFaceDelivery();
  }

  /* ── FUSION F5: 结果回脸 — 监听慢脑 deliver 事件，交付卡回流 newface ── */

  function initMovListener() {
    try {
      if (window._movOn) {
        window._movOn('journal', function(roomId, ev) {
          if (ev && ev.type === 'deliver') onDelivery(roomId, ev);
          expertOnJournal(roomId, ev);
        });
      }
    } catch(e) {}
  }
  /* 专家会话 taskbar: journal 事件驱动运行状态 (不造假进度, 只显示阶段) */
  function expertOnJournal(roomId, ev) {
    if (!ev || _faceMode !== 'room' || roomId !== curRoomId) return;
    if (ev.type === 'plan' || ev.type === 'gate' || ev.type === 'step' || ev.type === 'tool_result') {
      expertTaskbarShow('任务执行中');
    } else if (ev.type === 'deliver') {
      expertTaskbarDone('任务完成 · 交付物已就绪');
    } else if (ev.type === 'fail' || ev.type === 'stopped') {
      expertTaskbarHide();
    }
  }

  function onDelivery(roomId, ev) {
    // 存最近交付（跨视图：专家模式跑完回新脸也能显示）——roomId 供「去查看」落所属房间（工单19）
    try {
      var card = NewFaceDelivery.toCardData(ev);
      card.roomId = roomId || '';
      localStorage.setItem('mv:lastDel', JSON.stringify(card));
    } catch(e) {}
    var face = document.getElementById('view-face');
    if (face && face.classList.contains('act')) renderFaceDelivery();
  }

  function renderFaceDelivery() {
    var cover = document.getElementById('faceCover');
    if (!cover) return;
    var raw = null;
    try { raw = localStorage.getItem('mv:lastDel'); } catch(e) {}
    if (!raw) return;
    var d = null;
    try { d = JSON.parse(raw); } catch(e) { return; }
    var existing = document.getElementById('faceDeliveryCard');
    if (existing) existing.remove();
    /* №8 规格: 首页交付卡 — 结论 prose (提炼 summary), 元数据下沿小灰字, 进 CSS 类 (去✨机器标题/inline) */
    var fdTxt = window.NewFaceExpert ? (NewFaceExpert.extractConclusion(d.summary || '') || '完成') : (d.summary || '完成');
    var card = el('<div id="faceDeliveryCard" class="face-delivery">'
      + '<div class="fd-txt">' + escHtml(fdTxt) + '</div>'
      + (d.filesN ? '<div class="deliver-meta">' + d.filesN + ' 个产物 · 点按查看</div>' : '')
      + '<span class="dact" onclick="NewFace.gotoDelivery()">去查看</span></div>');
    cover.insertBefore(card, cover.firstChild);
    scrollCover();
  }

  /** 交付卡「去查看」→ 落所属房间（工单19：叙事是回任务现场，不是切模式） */
  function gotoDelivery() {
    var raw = null;
    try { raw = localStorage.getItem('mv:lastDel'); } catch(e) {}
    var d = null;
    try { d = JSON.parse(raw); } catch(e) {}
    if (d && d.roomId) {
      /* 落房间 + 切到文件/交付区（expertGoFiles 用 curRoomId，expertOpenRoom 已置） */
      expertOpenRoom(d.roomId);
      setTimeout(function(){ try { NewFace.expertGoFiles(); } catch(e){} }, 300);
      return;
    }
    /* 无 roomId 兜底：进房间列表（自动承接语义） */
    switchToExpert();
  }

  /** 工单19 打回③修法：面板显示公共序列（激活 view-face + 隐藏 cover + 显示 expertPane）。
   *  switchToExpert 与 expertOpenRoom 共用——所有进房入口（历史条目/交付卡/房卡点按）先显示面板再进房 */
  function showExpertPane() {
    if (typeof closeDrawer === 'function') closeDrawer();   // 防残留抽屉(z-index 20)盖住 expertPane(8)
    buildExpertPane();
    document.querySelectorAll('.view').forEach(function(v){ v.classList.remove('act'); });
    var face = document.getElementById('view-face'); if (face) face.classList.add('act');
    var cover = document.getElementById('faceCover'); if (cover) cover.style.display = 'none';
    var pane = document.getElementById('expertPane'); if (pane) pane.style.display = 'flex';
  }

  function switchToExpert(contextText) {
    // 专家新脸化: 切到新脸专家房间列表视图 (不再激活老房间视图, 不显示老底导航)
    _faceHandoffCtx = contextText || null;
    showExpertPane();
    _faceMode = 'rooms';
    _paneShow('expertRoomsView', true);
    _paneShow('expertRoomView', false);
    _paneShow('expertRunView', false);
    _paneShow('expertFilesView', false);
    renderExpertRooms();
    if (_faceHandoffCtx) {
      setTimeout(function() {
        var input = document.getElementById('expertPillInput');
        if (input) { input.value = _faceHandoffCtx; input.focus(); }
      }, 200);
    }
  }

  /* ============ 专家模式新脸化 (第一幕: 房间列表 + 会话, 照 mockup 屏①②) ============ */
  var _faceMode = 'home';        /* 'home' | 'rooms' | 'room' | 'run' | 'files' */
  var _faceHandoffCtx = null;    /* 待交接上下文 (新脸 → 专家模式, 预填输入框) */
  /* 第三幕: 专家子视图显隐 helper (替代 inline style, 卡片 DOM 契约) */
  function _paneShow(id, on) {
    var e = document.getElementById(id); if (!e) return;
    if (on) e.classList.add('on'); else e.classList.remove('on');
  }

  function buildExpertPane() {
    var pane = document.getElementById('expertPane');
    if (!pane || pane.innerHTML) return;
    pane.innerHTML =
      '<div id="expertRoomsView" class="expert-pane on">'
      + '<div class="topbar"><div class="tbtn" onclick="NewFace.expertExit()">‹</div>'
      + '<div class="ttitle">任 务</div>'
      + '<div class="tbtn" onclick="NewFace.expertNewRoom()">＋</div></div>'
      + '<div class="face-body"><div class="face-cover" id="expertRoomsScroll">'
      + '<div class="dateline">任务中心</div>'
      + '<div class="sitem" onclick="NewFace.expertGoRun()">'
      + '<div class="ic">⏵</div><div class="tx"><div class="t1">后台任务</div>'
      + '<div class="t2" id="expertRunSummary">运行中 · 今日完成</div></div><div class="go">›</div></div>'
      + '<div class="sitem" onclick="NewFace.expertGoFiles()">'
      + '<div class="ic">📦</div><div class="tx"><div class="t1">交付物</div>'
      + '<div class="t2" id="expertFilesSummary">文件与版本</div></div><div class="go">›</div></div>'
      + '<div class="dateline">任务 · 每个任务都有专人负责</div>'
      + '<div id="expertRoomList"></div>'
      + '<div id="expertHandoffZone"></div>'
      + '</div></div>'
      + '<div class="composer"><div class="pill">'
      + '<input id="expertPillInput" placeholder="开个新房间，说你要做什么…" enterkeyhint="send">'
      + '<button class="send" onclick="NewFace.expertSend()">↑</button>'
      + '</div><div class="expert-link" onclick="NewFace.expertExit()">返 回 首 页</div></div>'
      + '</div>'
      + '<div id="expertRoomView" class="expert-pane">'
      + '<div class="topbar"><div class="tbtn" onclick="NewFace.expertBack()">‹</div>'
      + '<div class="ttitle" id="expertTitle">房 间</div>'
      + '<div class="tbtn"></div></div>'
      + '<div class="face-body">'
      + '<div id="expertTaskbar" class="taskbar is-hidden"></div>'
      /* 派单№5: 思考条移植进专家会话 (thinking.js attach; 老 #think 删后 token 流不丢) */
      + '<div class="think" id="expertThink">'
      + '<div class="think-head"><span class="tl"><span class="live"></span><span class="proc">等待输入</span></span>'
      + '<span class="cnt"><b id="thinkTok">0</b> tok · <b id="thinkSec">0.0</b>s</span>'
      + '<span class="fold" id="thinkFold">收起 ▾</span></div>'
      + '<div class="think-body"></div>'
      + '<div class="think-status"><span class="st" id="thinkSt">等待输入</span>'
      + '<svg class="mflow indet" viewBox="0 0 292 18" preserveAspectRatio="none">'
      + '<path class="mflow-base" d="M2 3 L10 15 L18 3 L26 15 L34 3 L42 15 L50 3"/>'
      + '<path class="mflow-fill" d="M2 3 L10 15 L18 3 L26 15 L34 3 L42 15 L50 3"/>'
      + '<path class="mflow-pulse" d="M2 3 L10 15 L18 3 L26 15 L34 3 L42 15 L50 3"/></svg>'
      + '<span id="thinkTps"></span></div>'
      + '</div>'
      + '<div class="face-cover" id="expertRoomScroll"><div class="card-pane" id="expertCardPane"></div></div>'
      + '</div>'
      + '<div class="composer"><div class="pill">'
      + '<input id="expertRoomInput" placeholder="追问一句…" enterkeyhint="send">'
      + '<button class="send" onclick="NewFace.expertSend()">↑</button>'
      + '</div><div class="expert-link" onclick="NewFace.expertExit()">识 别 内 容 不 出 设 备</div></div>'
      + '</div>'
      /* 第二幕: 运行页 (屏③) */
      + '<div id="expertRunView" class="expert-pane">'
      + '<div class="topbar"><div class="tbtn" onclick="NewFace.expertBackToRooms()">‹</div>'
      + '<div class="ttitle">运 行</div><div class="tbtn"></div></div>'
      + '<div class="face-body"><div class="face-cover" id="expertRunScroll">'
      + '<div class="dateline">后台任务 · 可收起可续跑</div>'
      + '<div id="expertRunStats"></div>'
      + '<div id="expertRunList"></div>'
      + '</div></div>'
      + '<div class="composer"><div class="pill"><span class="ph">问一句「跑到哪了」…</span><div class="send">↑</div></div>'
      + '<div class="expert-link" onclick="NewFace.expertBackToRooms()">返 回 房 间</div></div>'
      + '</div>'
      /* 第二幕: 文件页 (屏④) */
      + '<div id="expertFilesView" class="expert-pane">'
      + '<div class="topbar"><div class="tbtn" onclick="NewFace.expertBackToRooms()">‹</div>'
      + '<div class="ttitle">文 件</div><div class="tbtn"></div></div>'
      + '<div class="face-body"><div class="face-cover" id="expertFilesScroll">'
      + '<div class="dateline">交付物 · 版本都在</div>'
      + '<div id="expertFileList"></div>'
      + '</div></div>'
      + '<div class="composer"><div class="pill"><span class="ph">找找以前的交付物…</span><div class="send">↑</div></div>'
      + '<div class="expert-link" onclick="NewFace.expertBackToRooms()">返 回 房 间</div></div>'
      + '</div>';
    /* 预览 overlay 挂 #view-face 直接子级 (home 与专家视图共用) */
    ensureExpertOverlay();
    var p = document.getElementById('expertPillInput');
    if (p) p.addEventListener('keydown', function(e){ if (e.key === 'Enter') expertSend(); });
    var ri = document.getElementById('expertRoomInput');
    if (ri) ri.addEventListener('keydown', function(e){ if (e.key === 'Enter') expertSend(); });
  }

  /* 房间列表渲染 (照 mockup 屏①: sitem 卡 + badge + 交接区; 长按房卡 → ops) */
  function renderExpertRooms() {
    var list = document.getElementById('expertRoomList'); if (!list) return;
    var active = ROOMS.filter(function(r){ return r.phase !== '已归档'; });
    var html = '';
    active.forEach(function(r){ html += expertRoomCard(r); });
    list.innerHTML = html;
    list.querySelectorAll('.room-card').forEach(function(card){ bindExpertRoomLongPress(card); });
    renderExpertHandoff();
  }
  function expertRoomCard(r) {
    var badge = expertRoomBadge(r);
    return '<div class="sitem room-card" data-room="' + esc(r.id) + '" onclick="NewFace.expertOpenRoom(\'' + r.id + '\')">'
      + '<div class="ic">' + expertRoomIcon(r.name) + '</div>'
      + '<div class="tx"><div class="t1">' + esc(r.name) + '</div>'
      + '<div class="t2">' + esc(r.last || '') + '</div></div>'
      + (badge ? '<span class="badge' + (badge.cls ? ' ' + badge.cls : '') + '">' + badge.label + '</span>' : '')
      + '<div class="go">›</div></div>';
  }
  /* 长按房卡 (500ms, 移动>10px 取消) → 底部黑条 ops (CLAUDE.md 长按=右键菜单) */
  var _expertLp = false;   // 长按触发后抑制随后的 click 进房
  function bindExpertRoomLongPress(card) {
    var t = null, sx = 0, sy = 0;
    card.addEventListener('touchstart', function(e){
      var tc = e.touches && e.touches[0]; if (!tc) return;
      sx = tc.clientX; sy = tc.clientY;
      t = setTimeout(function(){
        t = null;
        _expertLp = true;
        setTimeout(function(){ _expertLp = false; }, 400);
        expertRoomOps(card.getAttribute('data-room'));
      }, 500);
    });
    card.addEventListener('touchmove', function(e){
      var tc = e.touches && e.touches[0]; if (!tc) return;
      var dx = tc.clientX - sx, dy = tc.clientY - sy;
      if (t && dx * dx + dy * dy > 100) { clearTimeout(t); t = null; }
    });
    card.addEventListener('touchend', function(){ if (t) { clearTimeout(t); t = null; } });
  }
  /* 房卡 ops 黑条: 重命名/归档/清空/删除 */
  function expertRoomOps(roomId) {
    var room = ROOMS.find(function(r){ return r.id === roomId; });
    if (!room) return;
    var bar = document.getElementById('expertOpsBar');
    if (!bar) {
      bar = el('<div id="expertOpsBar" class="expert-opsbar is-hidden"></div>');
      var face = document.getElementById('view-face');
      if (face) face.appendChild(bar);
    }
    if (!bar) return;
    bar.innerHTML = '<div class="ops-title">' + esc(room.name) + '</div>'
      + '<div class="ops-item" onclick="NewFace.expertOpsRename(\'' + roomId + '\')">✏️ 重命名</div>'
      + '<div class="ops-item" onclick="NewFace.expertOpsArchive(\'' + roomId + '\')">🗂 归档</div>'
      + '<div class="ops-item" onclick="NewFace.expertOpsClear(\'' + roomId + '\')">🧹 清空记录</div>'
      + '<div class="ops-item" onclick="NewFace.expertOpsDelete(\'' + roomId + '\')">🗑 删除房间</div>'
      + '<div class="ops-item ops-close" onclick="NewFace.expertOpsClose()">取消</div>';
    bar.style.display = 'block';
  }
  function expertOpsClose() {
    var bar = document.getElementById('expertOpsBar'); if (bar) bar.style.display = 'none';
  }
  function expertOpsRename(roomId) {
    expertOpsClose();
    var room = ROOMS.find(function(r){ return r.id === roomId; });
    if (!room) return;
    var overlay = document.getElementById('expertPreviewOverlay'); if (!overlay) return;
    document.getElementById('expertPreviewTitle').textContent = '重命名房间';
    document.getElementById('expertPreviewMeta').textContent = '';
    var body = document.getElementById('expertPreviewBody');
    body.innerHTML = '<input id="opsRenameInput" class="sheet-input lg" value="' + esc(room.name) + '">';
    document.getElementById('expertPreviewActs').innerHTML =
      '<div class="abtn save" onclick="NewFace.expertOpsRenameOk(\'' + roomId + '\')">✓ 确定</div>'
      + '<div class="abtn" onclick="NewFace.expertClosePreview()">取消</div>';
    overlay.style.display = 'flex';
    setTimeout(function(){ var i = document.getElementById('opsRenameInput'); if (i) i.focus(); }, 120);
  }
  function expertOpsRenameOk(roomId) {
    var room = ROOMS.find(function(r){ return r.id === roomId; });
    var input = document.getElementById('opsRenameInput');
    var newName = input ? input.value.trim() : '';
    if (room && newName) { room.name = newName; renderRooms(); persistRooms(); renderExpertRooms(); }
    expertClosePreview();
  }
  function expertOpsArchive(roomId) {
    expertOpsClose();
    var room = ROOMS.find(function(r){ return r.id === roomId; });
    if (room) { room.phase = '已归档'; if (typeof setPhase === 'function') setPhase(room.id, '已归档'); B.toast('已归档'); renderRooms(); persistRooms(); renderExpertRooms(); }
  }
  function expertOpsClear(roomId) {
    expertOpsClose();
    expertConfirm(roomId, '清空所有聊天记录？不可撤销。', function(){
      B.roomDestroy(roomId);
      clearRoomHistory(roomId);
      renderExpertRooms();
    });
  }
  function expertOpsDelete(roomId) {
    expertOpsClose();
    expertConfirm(roomId, '删除此房间？不可撤销。', function(){
      B.roomDestroy(roomId);
      var room = ROOMS.find(function(r){ return r.id === roomId; });
      if (room) { var idx = ROOMS.indexOf(room); if (idx >= 0) ROOMS.splice(idx, 1); }
      genCounter++; curRoomId = null;
      try { if (window.HermesBridge) HermesBridge.setRoomOpen(''); } catch(e){}
      renderRooms(); persistRooms(); renderExpertRooms();
    });
  }
  /* 预览 overlay 懒建（抽公共）：原只在进专家模式时创建，home 左侧栏长按删除
     过确认 sheet 时 overlay 不存在 → expertConfirm 静默 return（2026-08-07 真机实证「删除不了」根因） */
  function ensureExpertOverlay() {
    var face = document.getElementById('view-face');
    if (face && !document.getElementById('expertPreviewOverlay')) {
      var ol = el('<div class="expert-overlay is-hidden" id="expertPreviewOverlay" onclick="NewFace.expertClosePreview()">'
        + '<div class="expert-sheet" onclick="event.stopPropagation()">'
        + '<div class="grab"></div>'
        + '<div class="stitle" id="expertPreviewTitle"></div>'
        + '<div class="smeta" id="expertPreviewMeta"></div>'
        + '<div class="sbody" id="expertPreviewBody"></div>'
        + '<div class="sactions" id="expertPreviewActs"></div>'
        + '</div></div>');
      face.appendChild(ol);
    }
  }
  /* 确认 sheet (替代 confirm(), CLAUDE.md 规则5) */
  var _expertConfirmFn = null;
  function expertConfirm(roomId, text, okFn) {
    ensureExpertOverlay();
    var overlay = document.getElementById('expertPreviewOverlay'); if (!overlay) return;
    document.getElementById('expertPreviewTitle').textContent = '确认';
    document.getElementById('expertPreviewMeta').textContent = '';
    document.getElementById('expertPreviewBody').innerHTML =
      '<div class="confirm-txt">' + esc(text) + '</div>';
    document.getElementById('expertPreviewActs').innerHTML =
      '<div class="abtn pri" onclick="NewFace._expertConfirmOk()">确定</div>'
      + '<div class="abtn" onclick="NewFace.expertClosePreview()">取消</div>';
    _expertConfirmFn = okFn;
    overlay.style.display = 'flex';
  }
  function _expertConfirmOk() {
    var fn = _expertConfirmFn; _expertConfirmFn = null;
    expertClosePreview();
    if (fn) fn();
  }
  /* 房间图标/badge: 委托 NewFaceExpert 纯逻辑 (node 单测覆盖, 见 newface-expert.test.js) */
  function expertRoomIcon(name) { return NewFaceExpert.roomIcon(name); }
  function expertRoomBadge(r) { return NewFaceExpert.roomBadge(r); }
  /* 交接区: 有待交接上下文才显示 */
  function renderExpertHandoff() {
    var zone = document.getElementById('expertHandoffZone'); if (!zone) return;
    if (!_faceHandoffCtx) { zone.innerHTML = ''; return; }
    var t = _faceHandoffCtx;
    zone.innerHTML = '<div class="dateline">交接</div>'
      + '<div class="sitem handoff" onclick="NewFace.expertSend()">'
      + '<div class="ic">↗</div>'
      + '<div class="tx"><div class="t1">首页带过来的事</div>'
      + '<div class="t2">' + esc(NewFaceExpert.handoffText(t, 40)) + ' · 已预填到输入框</div></div>'
      + '<div class="go">›</div></div>';
  }

  /* 进会话: 复用老 enterRoom 链路 (journal 迁移/回放/MovRender), noView 不切老视图 */
  function expertOpenRoom(id) {
    if (_expertLp) return;   // 长按房卡 ops 后抑制随后的 click 进房
    /* 工单19 打回③修法：先显示面板（view-face act + cover 隐藏 + pane flex），再切房内子视图 */
    showExpertPane();
    _faceMode = 'room';
    _paneShow('expertRoomsView', false);
    _paneShow('expertRoomView', true);
    _paneShow('expertRunView', false);
    _paneShow('expertFilesView', false);
    enterRoom(id, {cardId:'expertCardPane', parentId:'expertRoomScroll', scrollId:'expertRoomScroll',
                   titleId:'expertTitle', subId:'expertSub', pathId:'expertSub', noView:true});
    /* 让专家继续 / 交接上下文: 预填到会话输入框 */
    if (_faceHandoffCtx) {
      var input = document.getElementById('expertRoomInput');
      if (input) { input.value = _faceHandoffCtx; _faceHandoffCtx = null; }
    }
    /* 派单№5: 思考条挂载专家会话容器 (token 数据流 _movToken→MovThinking.feed) */
    if (window.MovThinking && MovThinking.attach) MovThinking.attach('expertThink');
    expertTaskbarCheck();
  }
  function expertBack() {
    _faceMode = 'rooms';
    if (window.MovRender) MovRender.setRoom(null);   // 防切回后 journal 误渲染旧容器
    expertTaskbarHide();
    _paneShow('expertRoomsView', true);
    _paneShow('expertRoomView', false);
    _paneShow('expertRunView', false);
    _paneShow('expertFilesView', false);
    renderExpertRooms();
  }
  function expertExit() { showFace(); }

  /* ══ 第二幕: 运行/文件页 (照 mockup 屏③④) ══ */

  /* 导航: rooms ⇄ run/files */
  function expertGoRun() {
    buildExpertPane();
    _faceMode = 'run';
    _paneShow('expertRoomsView', false);
    _paneShow('expertRoomView', false);
    _paneShow('expertRunView', true);
    _paneShow('expertFilesView', false);
    renderExpertRun();
  }
  function expertGoFiles() {
    buildExpertPane();
    _faceMode = 'files';
    _paneShow('expertRoomsView', false);
    _paneShow('expertRoomView', false);
    _paneShow('expertRunView', false);
    _paneShow('expertFilesView', true);
    renderExpertFiles();
  }
  function expertBackToRooms() {
    _faceMode = 'rooms';
    expertTaskbarHide();
    _paneShow('expertRoomsView', true);
    _paneShow('expertRoomView', false);
    _paneShow('expertRunView', false);
    _paneShow('expertFilesView', false);
    renderExpertRooms();
  }
  /* 派单№5: expertGoSysModel 已删 (老运行页删除, 设置归一新脸抽屉: TOKEN/模型/外观/终端) */

  /* 运行页: 统计格 + 任务卡 (可中断可续) + 今日完成/失败 (journal 聚合) */
  function renderExpertRun() {
    var statsEl = document.getElementById('expertRunStats'); if (!statsEl) return;
    var list = document.getElementById('expertRunList'); if (!list) return;
    /* 运行中: 全局活跃 agent_state */
    var running = null;
    try { var st = B.query({q:'agent_state'}); if (st && st.ok && st.data && st.data.active) running = st.data; } catch(e){}
    /* 今日完成/失败: 逐活跃房 journal_index 聚合 */
    var todayKey = NewFaceExpert.dayKey(Date.now());
    var entries = [];
    ROOMS.forEach(function(r){
      if (r.phase === '已归档') return;
      try {
        var idx = B.query({q:'journal_index', roomId:r.id});
        if (idx && idx.ok && idx.data && idx.data.entries) {
          idx.data.entries.forEach(function(en){
            entries.push({roomId:r.id, type:en.type, ts:en.ts, summary:en.summary || ''});
          });
        }
      } catch(e){}
    });
    var agg = NewFaceExpert.aggDaily(entries, todayKey);
    /* 统计格 (statsEl) */
    statsEl.innerHTML = '<div class="stat">'
      + '<div class="cell"><div class="n">' + (running ? 1 : 0) + '</div><div class="l">运行中</div></div>'
      + '<div class="cell"><div class="n">' + agg.done.length + '</div><div class="l">今日完成</div></div>'
      + '<div class="cell"><div class="n">' + agg.failed.length + '</div><div class="l">失败</div></div>'
      + '</div>';
    /* 任务卡列表 (list) */
    list.innerHTML = runListCards(agg, running);
    /* 更新 rooms 视图入口摘要 */
    var summ = document.getElementById('expertRunSummary');
    if (summ) summ.textContent = (running ? '运行中' : '空闲') + ' · 今日完成 ' + agg.done.length;
  }

  /* 运行页任务卡列表 (拆出方便维护; 不含统计格) */
  function runListCards(agg, running) {
    var html = '';
    if (running) {
      var room = ROOMS.find(function(x){ return x.id === running.roomId; });
      var phaseLabel = NewFaceExpert.agentPhaseLabel(running.phase);
      html += '<div class="runitem"><div class="r1">' + esc(room ? room.name : (running.roomId || ''))
        + '<span class="st doing">● ' + esc(phaseLabel) + '</span></div>'
        + '<div class="bar"><i class="w30"></i></div>'
        + '<div class="r2">' + esc(running.goal || '') + ' · 已完成 ' + (running.stepsDone || 0) + ' 步 · <b>可中断可续</b></div>'
        + '<div class="run-acts"><button class="pri" onclick="NewFace.expertStopTask(\'' + running.loopId + '\')">■ 停止</button></div></div>';
    }
    agg.done.forEach(function(d){
      var room = ROOMS.find(function(x){ return x.id === d.roomId; });
      html += '<div class="runitem done"><div class="r1">' + esc(room ? room.name : d.roomId)
        + '<span class="st done">✓ 完成</span></div>'
        + '<div class="bar"><i class="w100"></i></div>'
        + '<div class="r2">' + esc(d.summary || '交付物已就绪') + '</div></div>';
    });
    agg.failed.forEach(function(d){
      var room = ROOMS.find(function(x){ return x.id === d.roomId; });
      html += '<div class="runitem"><div class="r1">' + esc(room ? room.name : d.roomId)
        + '<span class="st fail">✗ 失败</span></div>'
        + '<div class="r2">' + esc(d.summary || '任务失败') + '</div></div>';
    });
    if (!running && agg.done.length === 0 && agg.failed.length === 0) {
      html += '<div class="empty-note">暂无任务记录<br><small>发起一个任务后，这里会显示运行状态与交付。</small></div>';
    }
    return html;
  }
  function expertStopTask(loopId) {
    B.postCmd({cmd:'stop_task', taskId:loopId});
    B.toast('已发送停止指令');
    setTimeout(function(){ renderExpertRun(); }, 900);
  }

  /* 文件页: 交付物列表 (跨房聚合) + 版本徽章 + 保险柜 (P5 契约) */
  function renderExpertFiles() {
    var list = document.getElementById('expertFileList'); if (!list) return;
    var files = [];
    ROOMS.forEach(function(r){
      if (r.phase === '已归档') return;
      try {
        var lw = B.listWorkFiles(r.id);
        if (lw && lw.ok && lw.files) {
          lw.files.forEach(function(f){
            if (f.isDir) return;
            files.push({roomId:r.id, roomName:r.name, name:f.name, size:f.size, modified:f.modified});
          });
        }
      } catch(e){}
    });
    files.sort(function(a,b){ return (b.modified || 0) - (a.modified || 0); });
    var html = '';
    files.forEach(function(f){
      html += '<div class="fitem" onclick="NewFace.expertPreviewFile(\'' + f.roomId + '\',\'' + f.name + '\')">'
        + '<div class="fi">' + expertFileIcon(f.name) + '</div>'
        + '<div class="ft"><div class="f1">' + esc(f.name) + '</div>'
        + '<div class="f2">' + esc(f.roomName) + ' · ' + NewFaceExpert.fileSize(f.size) + '</div></div>'
        + '<div class="fv">' + esc(expertFileVersion(f.roomId, f.name)) + '</div></div>';
    });
    if (files.length === 0) {
      html = '<div class="empty-note">还没有交付物<br><small>任务完成后，产出文件会出现在这里，可预览 / 版本 / 继续。</small></div>';
    }
    /* 保险柜条目 (视图占位 + P5 接口对齐: 桥未就绪 → 诚实卡) */
    html += '<div class="dateline">隐私</div>'
      + '<div class="fitem" onclick="NewFace.expertVaultOpen()">'
      + '<div class="fi lock">🔒</div>'
      + '<div class="ft"><div class="f1">隐私保险柜</div>'
      + '<div class="f2">指纹可见 · 上锁内容不出现</div></div>'
      + '<div class="fv lock">锁</div></div>';
    list.innerHTML = html;
    var summ = document.getElementById('expertFilesSummary');
    if (summ) summ.textContent = files.length + ' 个文件 · 版本都在';
  }
  function expertFileIcon(name) {
    var n = name || '';
    if (/\.apk$/i.test(n)) return '📱';
    if (/\.(md|markdown)$/i.test(n)) return '📝';
    if (/\.(png|jpe?g|gif|webp)$/i.test(n)) return '🖼️';
    if (/\.(pdf|docx?|txt)$/i.test(n)) return '📃';
    if (/\.(html?|js|css|json|xml)$/i.test(n)) return '📄';
    return '📄';
  }
  function expertFileVersion(roomId, name) {
    try {
      var v = B.listVersions(roomId, 'files/work/' + name);
      if (v && v.ok && v.versions && v.versions.length > 0) return 'v' + (v.versions.length + 1);
    } catch(e){}
    return 'v1';
  }

  /* 保险柜: P5 桥已就绪 — 文件页 🔒 入口 → 设置页保险柜二级页（工单14） */
  function expertVaultOpen() {
    openSettings('vault');
  }

  /* 预览 overlay (mockup 屏④ sheet): 编辑 / 导出 / 让专家继续 */
  var _previewRoom = null, _previewName = null;
  function expertPreviewFile(roomId, name) {
    buildExpertPane();
    _previewRoom = roomId; _previewName = name;
    var overlay = document.getElementById('expertPreviewOverlay'); if (!overlay) return;
    var title = document.getElementById('expertPreviewTitle');
    var meta = document.getElementById('expertPreviewMeta');
    var body = document.getElementById('expertPreviewBody');
    var acts = document.getElementById('expertPreviewActs');
    var room = ROOMS.find(function(x){ return x.id === roomId; });
    if (title) title.textContent = name;
    if (meta) meta.textContent = (room ? room.name : roomId);
    if (body) { body.textContent = ''; body.textContent = '读取中…'; }
    var isApk = /\.apk$/i.test(name || '');
    if (acts) {
      if (isApk) {
        acts.innerHTML = '<div class="abtn pri" onclick="NewFace.expertInstallPreview()">📲 安装</div>'
          + '<div class="abtn" onclick="NewFace.expertClosePreview()">关闭</div>';
      } else {
        acts.innerHTML = '<div class="abtn" onclick="NewFace.expertEditPreview()">✏️ 编辑</div>'
          + '<div class="abtn" onclick="NewFace.expertVersionsPreview()">📚 版本</div>'
          + '<div class="abtn" onclick="NewFace.expertExportPreview()">↗ 导出</div>'
          + '<div class="abtn pri" onclick="NewFace.expertContinuePreview()">让专家继续</div>';
      }
    }
    overlay.style.display = 'flex';
    var res = B.readFile(roomId, 'files/work/' + name);
    if (res && res.ok && res.content !== undefined) {
      if (body) { body.textContent = ''; body.textContent = res.content; }
    } else {
      if (body) body.innerHTML = '<h4>无法预览</h4>该文件可能是二进制（如 APK）或已移动。试试「导出」查看。';
    }
  }
  /* 版本恢复 (第三幕必迁: 复用 B.listVersions/B.restoreVersion, files.js 老 overlay 删后新脸接管) */
  function expertVersionsPreview() {
    if (!_previewRoom || !_previewName) return;
    var v = B.listVersions(_previewRoom, 'files/work/' + _previewName);
    var versions = (v && v.versions) ? v.versions.slice() : [];
    versions.sort(function(a, b){ return String(b.timestamp || '').localeCompare(String(a.timestamp || '')); });
    var overlay = document.getElementById('expertPreviewOverlay'); if (!overlay) return;
    document.getElementById('expertPreviewTitle').textContent = _previewName + ' · 版本';
    document.getElementById('expertPreviewMeta').textContent = '点按历史版本可恢复';
    var body = document.getElementById('expertPreviewBody');
    if (versions.length === 0) {
      body.innerHTML = '<div class="empty-note flat">暂无历史版本<br><small>保存编辑后自动留版本。</small></div>';
    } else {
      var html = '';
      versions.forEach(function(ver){
        html += '<div class="ver-item" onclick="NewFace.expertRestoreVersion(\'' + esc(String(ver.name || '')) + '\')">'
          + '<div class="f-grow">' + esc(String(ver.timestamp || '').replace('_', ' · ')) + '</div>'
          + '<div class="ver-restore">恢复</div></div>';
      });
      body.innerHTML = html;
    }
    document.getElementById('expertPreviewActs').innerHTML =
      '<div class="abtn" onclick="NewFace.expertBackFromVersions()">← 返回</div>'
      + '<div class="abtn" onclick="NewFace.expertClosePreview()">关闭</div>';
  }
  function expertBackFromVersions() {
    if (_previewRoom && _previewName) expertPreviewFile(_previewRoom, _previewName);
    else expertClosePreview();
  }
  function expertRestoreVersion(snap) {
    if (!_previewRoom || !_previewName) return;
    var r = B.restoreVersion(_previewRoom, 'files/work/' + _previewName, snap);
    if (r && r.ok) { B.toast('已恢复版本'); expertClosePreview(); setTimeout(renderExpertFiles, 400); }
    else B.toast((r && r.error) || '恢复失败');
  }
  function expertInstallPreview() {
    if (!_previewRoom || !_previewName) return;
    var r = B.installApk(_previewRoom, 'files/work/' + _previewName);
    if (r && r.ok) B.toast('已调起系统安装器');
    else B.toast('安装不可用，试试「导出」');
    expertClosePreview();
  }
  function expertClosePreview() {
    var overlay = document.getElementById('expertPreviewOverlay'); if (overlay) overlay.style.display = 'none';
  }
  function expertEditPreview() {
    if (!_previewRoom || !_previewName) return;
    var body = document.getElementById('expertPreviewBody');
    var acts = document.getElementById('expertPreviewActs');
    var res = B.readFile(_previewRoom, 'files/work/' + _previewName);
    var content = (res && res.ok && res.content !== undefined) ? res.content : '';
    if (body) body.innerHTML = '<textarea>' + esc(content) + '</textarea>';
    if (acts) acts.innerHTML = '<div class="abtn save" onclick="NewFace.expertSavePreview()">💾 保存</div>'
      + '<div class="abtn" onclick="NewFace.expertClosePreview()">取消</div>';
  }
  function expertSavePreview() {
    var body = document.getElementById('expertPreviewBody');
    var ta = body ? body.querySelector('textarea') : null;
    if (!ta || !_previewRoom || !_previewName) return;
    B.saveWorkFile(_previewRoom, _previewName, ta.value, 'you');
    B.toast('已保存（自动留版本）');
    expertClosePreview();
    setTimeout(renderExpertFiles, 400);
  }
  function expertExportPreview() {
    if (!_previewRoom || !_previewName) return;
    var r = B.pinFileShortcut(_previewRoom, 'files/work/' + _previewName, _previewName);
    if (r && r.ok) B.toast('已发送到桌面');
    else B.toast('导出暂不可用，试试「继续这个任务」');
  }
  function expertContinuePreview() {
    if (!_previewRoom || !_previewName) return;
    expertClosePreview();
    _faceHandoffCtx = '继续处理 ' + _previewName + ': ';
    expertOpenRoom(_previewRoom);
  }

  /* pill 发送: 会话 → sendExpertMsg; 房间列表 → 建房 + 进会话发送 */
  function expertSend() {
    if (_faceMode === 'room') {
      var ri = document.getElementById('expertRoomInput'); if (!ri) return;
      var text = ri.value.trim(); ri.value = '';
      if (text) sendExpertMsg(curRoomId, text);
      return;
    }
    var pi = document.getElementById('expertPillInput'); if (!pi) return;
    var text = pi.value.trim(); pi.value = '';
    if (text) expertCreateRoom(text);
  }
  /* ＋ 新建: 聚焦 pill (让用户输入任务) */
  function expertNewRoom() {
    var pi = document.getElementById('expertPillInput'); if (pi) pi.focus();
  }
  /* 建房 (复用 app-room 核心: initRoomStorage/initRoom/prepareRoomEnv), 然后进会话发消息 */
  /* 工单17: 同房派活 — 首页自动交接链路复用当前首页房间，不再每句开新房 */
  var _homeRoomId = null;     // 首页会话当前房间（resetFace 回封面 = 新会话时清空）
  var _homeHandoff = false;   // 本条来自首页自动交接（autoHandoff 链路标记）

  function expertCreateRoom(text) {
    text = (text || '').trim();
    /* 同房派活：首页连续派活复用当前房间（用户决策 2026-08-07） */
    if (_homeHandoff && _homeRoomId && ROOMS.some(function(r){ return r.id === _homeRoomId; })) {
      _homeHandoff = false;
      expertOpenRoom(_homeRoomId);
      if (text) setTimeout(function(){ sendExpertMsg(_homeRoomId, text); }, 400);
      return;
    }
    _homeHandoff = false;
    _faceHandoffCtx = null;   // 交接文本已转为本条任务消息发出——进房不再预填输入框（否则流里一条 + 输入框一条，用户报障 2026-08-01）
    var roomName = text.length > 12 ? text.slice(0, 12) + '…' : (text || '新房间');
    var ai = (typeof _nrSel !== 'undefined' && _nrSel) ? _nrSel.slice() : [];
    var id = 'r' + Date.now();
    _homeRoomId = id;   // 记录为首页会话房间（供下一句派活复用）
    ROOMS.splice(1, 0, {id:id, name:roomName, mode:'council',
      members:{human:[{who:'you',role:'owner'}],ai:ai},
      phase:'已交付', last:'MOV 已就绪', time:'现在', unread:0, played:false, msgs:[],
      seed:[{t:'agent',who:'mov',h:'我是 MOV。直接下达任务, 我会拆解计划给你确认, 然后执行并交付结果。'}]});
    B.initRoomStorage(id);
    B.initRoom(id, roomName, '', ai);
    renderRooms(); persistRooms();
    expertOpenRoom(id);
    if (text) setTimeout(function(){ sendExpertMsg(id, text); }, 400);
    /* 环境初始化 (失败不阻塞进房) */
    B.prepareRoomEnv(id, function(res){
      if (res && res.needInstall) B.toast('Linux 环境未就绪, 请先到 设置 → Linux 环境 安装');
    });
  }

  /* taskbar: 运行状态嵌会话流 (mockup 屏②), 不造假进度 */
  function expertTaskbarShow(text) {
    var tb = document.getElementById('expertTaskbar'); if (!tb) return;
    tb.style.display = 'flex';
    tb.classList.remove('done');   /* 派单№6: done 态走 .taskbar.done 类, 去 inline */
    tb.innerHTML = '<div class="dot"></div><div class="tt"><b>运行中</b> · ' + esc(text) + '</div><div class="pct"></div>';
  }
  function expertTaskbarDone(text) {
    var tb = document.getElementById('expertTaskbar'); if (!tb) return;
    tb.style.display = 'flex';
    tb.classList.add('done');
    tb.innerHTML = '<div class="dot"></div><div class="tt"><b>完成</b> · ' + esc(text) + '</div><div class="pct"></div>';
  }
  function expertTaskbarHide() {
    var tb = document.getElementById('expertTaskbar'); if (tb) tb.style.display = 'none';
  }
  function expertTaskbarCheck() {
    if (_agentLoop && _agentLoop.roomId === curRoomId && _agentExecuting) {
      expertTaskbarShow(_agentLoop.awaiting ? ('等待你回应 · ' + _agentLoop.awaiting) : '任务执行中');
    } else {
      expertTaskbarHide();
    }
  }

  /* ── 对话流引擎 ── */
  var currentFlow = null;
  var _lastDramaQuery = '';   // 最近一次追剧的剧名（抖音卡用）
  function el(html) { var d = document.createElement('div'); d.innerHTML = html; return d.firstElementChild; }
  function scrollCover() { var c = document.getElementById('faceCover'); if (c) c.scrollTo({top: c.scrollHeight, behavior: 'smooth'}); }

  function slotHTML(f) {
    if (!f.slots) return f.understanding;
    var parts = f.understanding.match(/：(.+)/)[1].split(' · ');
    return '理解：' + parts.map(function(p, i) {
      return '<span class="slot" data-si="' + i + '" data-vi="0" onclick="NewFace.cycleSlot(this,' + i + ')">' + p + '</span>';
    }).join(' · ');
  }
  function cycleSlot(elm, si) {
    var f = FLOWS[currentFlow]; if (!f || !f.slots) return;
    var vi = (+elm.dataset.vi + 1) % f.slots[si].length;
    elm.dataset.vi = vi; elm.textContent = f.slots[si][vi];
    elm.classList.remove('bump'); void elm.offsetWidth; elm.classList.add('bump');
  }

  function renderOptions(f) {
    var cover = document.getElementById('faceCover');
    f.options.forEach(function(o, i) {
      var poster = o.poster ? '<div class="poster" style="background:' + o.poster[0] + '"><span>' + o.poster[1] + '</span></div>' : '';
      var tags = (o.tags || []).map(function(t) { return '<span class="tag ' + t[0] + '">' + t[1] + '</span>'; }).join('');
      var card = el('<div class="opt" style="animation-delay:' + (i * 0.14) + 's">' + poster
        + '<div class="top"><span class="main">' + o.main + '</span><span class="price">' + o.price + '</span></div>'
        + '<div class="sub">' + o.sub + '</div>' + (tags ? '<div class="tags">' + tags + '</div>' : '') + '</div>');
      card.onclick = (function(key, opt, c) { return function() { pickOption(key, opt, c); }; })(currentFlow, o, card);
      cover.appendChild(card);
    });
    scrollCover();
  }

  function pickOption(key, o, card) {
    var all = document.querySelectorAll('#view-face .opt');
    all.forEach(function(c) { c.classList.remove('sel'); });
    card.classList.add('sel');
    if (o.action === 'player') { openPlayer(o); return; }
    var flow = FLOWS[key];
    if (flow && flow.pay) openPaySheet(flow.pay, function() { showDone(flow.done); });
  }

  var _lastUtterance = '';  // 用户原话穿透（drama 搜索用）

  /* ── 工单17: 对话流（视觉连续）— faceCover 即对话流，
     首轮 say 清屏（新会话），之后追加；显式动作（resetFace/showEmpty/replayConversation）重置 ── */
  var _chatStreamOn = false;   // 对话流是否已启动（false = 下次 say 重新清屏初始化）

  function ensureStream() {
    var cover = document.getElementById('faceCover');
    if (!cover) return null;
    if (!_chatStreamOn) {
      cover.innerHTML = '';   // 仅新会话后首次 say 清屏（hero/封面元素不残留）
      _chatStreamOn = true;
    }
    return cover;
  }

  /** utter 防重：say 已渲染过本句时不再重复追加（各路由分支用） */
  function streamHasUtter() {
    var cover = document.getElementById('faceCover');
    return !!(cover && cover.querySelector('.utter'));
  }

  function say(text) {
    var hero = document.getElementById('faceHero');
    var mwave = document.getElementById('faceMwave');
    if (!document.getElementById('faceCover')) return;
    if (hero) hero.style.display = 'none';
    _lastUtterance = text;

    // 追加式渲染：utter 累积成对话流（不再整体清屏）
    var cover = ensureStream();
    if (cover) {
      cover.appendChild(el('<div class="utter"><span>' + escHtml(text) + '</span></div>'));
      scrollCover();
    }
    if (mwave) mwave.classList.add('thinking');
    var u = el('<div class="understanding"><span class="u-dot"></span><span>理解中…</span></div>');
    if (cover) cover.appendChild(u); scrollCover();

    // 意图路由模式（DESIGN_SETTINGS ①）：regex 仅快速通道（省 token），不调 LLM
    if (getRoutingMode() === 'regex') {
      if (mwave) mwave.classList.remove('thinking');
      routeByKeyword(text, mwave);
      return;
    }
    // 异步 IntentEngine（aiExecutor 线程跑，不冻结 UI）
    if (typeof B !== 'undefined' && B.intentClassifyAsync) {
      B.intentClassifyAsync(text, function(resp) {
        if (mwave) mwave.classList.remove('thinking');
        if (resp && resp.ok && resp.data) {
          routeByIntent(text, resp.data, mwave);
        } else {
          routeByKeyword(text, mwave);
        }
      });
    } else {
      // 桥不可用 → 立即降级（不等超时）
      if (mwave) mwave.classList.remove('thinking');
      routeByKeyword(text, mwave);
    }
  }

  /** IntentEngine 路由 */
  function routeByIntent(text, data, mwave) {
    // 工单17: 追加式——清掉 thinking 行，utter 已由 say() 渲染进对话流，不再清屏/重复追加
    var cover = document.getElementById('faceCover');
    if (cover) {
      var old = cover.querySelector('.understanding');
      if (old && old.parentNode) old.parentNode.removeChild(old);
    }

    // 路由决策抽纯函数（newface-router.js，node 可测）——正则快速通道→LLM intent 权威判→domain 兼容兜底
    var route = NewFaceRouter.resolve(text, data);
    if (route === 'music') { startMusicSearch(text); return; }
    if (route === 'train') { startTrainSearch(text); return; }
    if (route === 'drama') { startFlow('drama', mwave); return; }
    if (route === 'a2a') { startA2A(text); return; }
    if (route === 'browser') { autoHandoff(text, data); return; }   // P1 B: 网页搜索 → agent 浏览器链路（browser.open platform+keyword）
    if (route === 'handoff') { autoHandoff(text, data); return; }
    if (route === 'chat') { showInlineChat(text); return; }
    // route === 'none'：静态 Flow（flight/shop 等）或开放对话兜底（接 DeepSeek，替代固定诚实卡）
    var key = matchFlowKey(text);
    if (key) startFlow(key, mwave);
    else {
      showInlineChat(text);   // 未命中任何场景 → 当作开放对话，走 DeepSeek 回复
    }
  }

  /** 关键词降级路由（桥不可用时） */
  function routeByKeyword(text, mwave) {
    if (isMusicIntent(text)) { startMusicSearch(text); return; }
    if (isTrainIntent(text)) { startTrainSearch(text); return; }
    if (isA2AIntent(text)) { startA2A(text); return; }
    if (/写|做|生成|开发|app|网页|代码|程序|报告|ppt|文档/.test(text.toLowerCase())) {
      showHandoff(text, {type:'creation', domain:'development', slots:{}, confidence:0.7}); return;
    }
    /* W4: regex 模式也覆盖 drama/shop/flight (matchFlowKey 兜底: drama 真/shop 真/flight 诚实) */
    var mk = matchFlowKey(text);
    if (mk) { startFlow(mk, mwave); return; }
    // 关键词不匹配 → 开放对话兜底（走 DeepSeek 回复，替代固定诚实卡）
    showInlineChat(text);
  }

  function isMusicIntent(text) {
    return /我要听|播放.*歌|来一首|我想听|听.*的歌|放.*歌|唱.*歌/.test(text);
  }

  function isTrainIntent(text) {
    // P1-3: 排除机票——「订去北京的机票」不得命中。「的」后必须紧邻票/或火车/高铁/动车+票
    return /火车票|高铁|动车|去.*的.*火车|订.*去.*的(火车|高铁|动车)?票/.test(text);
  }

  function isA2AIntent(text) {
    return /来一份|来碗|来份|我要吃|我想吃|想吃|盖浇饭|点餐|点单|下单.*吃|叫.*外卖|来.*个.*菜|买.*菜|下.*单.*菜|点.*个.*菜/.test(text);
  }

  /* ── 网易云音乐 ── */
  function startMusicSearch(text) {
    /* 工单17: 追加式——对话流容器（utter 已由 say 渲染，防重） */
    var cover = ensureStream();
    var hero = document.getElementById('faceHero');
    if (hero) hero.style.display = 'none';
    if (cover && !streamHasUtter()) {
      cover.appendChild(el('<div class="utter"><span>' + escHtml(text) + '</span></div>'));
      scrollCover();
    }
    // 剥词：去触发词取歌名
    var kw = text.replace(/我要听|播放|来一首|我想听|听.*的歌|放|唱|的歌/g, '').trim();
    if (!kw) kw = text;
    cover.appendChild(el('<div class="understanding"><span>搜索: ' + escHtml(kw) + '</span></div>'));
    scrollCover();

    if (typeof B !== 'undefined' && B.query) {
      var resp = null;
      var linkFailed = false;
      try {
        resp = B.query({q:'music_search', keyword: kw});
        if (resp && resp.ok && resp.data && resp.data.songs) {
          var songs = resp.data.songs;
          if (songs.length > 0) {
            songs.forEach(function(s) {
              var isVip = !s.playable;
              var card = el('<div class="opt" style="animation-delay:0.1s;' + (isVip ? 'opacity:.4' : '') + '">'
                + '<div class="top"><span class="main">' + escHtml(s.name) + (isVip ? ' 👑VIP' : '') + '</span>'
                + '<span class="price">' + (s.durationMs ? formatMusicDuration(s.durationMs) : '') + '</span></div>'
                + '<div class="sub">' + escHtml(s.artist) + ' · ' + escHtml(s.album||'') + '</div></div>');
              if (!isVip) {
                card.addEventListener('click', function() {
                  musicPlay(s.id, s.name, s.artist);
                });
              }
              cover.appendChild(card);
            });
            scrollCover();
            return;
          }
        }
      } catch(e) { linkFailed = true; }
    }
    // 错误区分：链路失败 vs 真没结果
    var errMsg = (linkFailed || (resp && !resp.ok)) ? '音乐服务连不上 · 请稍后重试' : '没有找到 · 换个说法试试';
    cover.appendChild(el('<div class="face-empty">' + errMsg + '</div>'));
    scrollCover();
  }

  function formatMusicDuration(ms) {
    var s = Math.round(ms / 1000);
    return Math.floor(s/60) + ':' + ('0' + (s%60)).slice(-2);
  }

  var _musicPlayer = null;
  function musicPlay(id, title, artist) {
    // 停旧播新
    if (_musicPlayer) { try { _musicPlayer.pause(); _musicPlayer.src = ''; _musicPlayer.load(); } catch(e) {} }
    var url = 'https://music.163.com/song/media/outer/url?id=' + id + '.mp3';
    _musicPlayer = new Audio(url);
    _musicPlayer.play().catch(function(){});
    // 迷你播放卡
    var existing = document.getElementById('faceMusicMini');
    if (existing) existing.remove();
    var card = el('<div id="faceMusicMini" class="music-mini">'
      + '<div class="f-row"><div class="f-grow"><b>' + escHtml(title) + '</b><br><span class="meta">' + escHtml(artist) + '</span></div>'
      + '<span class="music-ctl" onclick="NewFace._musicToggle()">⏯️</span>'
      + '<span class="music-ctl stop" onclick="NewFace._musicStop()">✕</span></div>'
      + '<input type="range" id="faceMusicSeek" min="0" max="100" value="0" class="music-seek" oninput="NewFace._musicSeek(this.value)">'
      + '</div>');
    // 进度条轮询
    var seekTimer = setInterval(function() {
      if (!_musicPlayer || _musicPlayer.paused) return;
      var pct = _musicPlayer.duration ? (_musicPlayer.currentTime / _musicPlayer.duration * 100) : 0;
      var seek = document.getElementById('faceMusicSeek');
      if (seek) seek.value = pct;
    }, 1000);
    document.body.appendChild(card);
  }

  function _musicToggle() {
    if (!_musicPlayer) return;
    if (_musicPlayer.paused) _musicPlayer.play().catch(function(){});
    else _musicPlayer.pause();
  }

  function _musicSeek(pct) {
    if (!_musicPlayer || !_musicPlayer.duration) return;
    _musicPlayer.currentTime = _musicPlayer.duration * pct / 100;
  }

  var _musicSeekTimer = null;
  function _musicStop() {
    if (_musicSeekTimer) { clearInterval(_musicSeekTimer); _musicSeekTimer = null; }
    if (_musicPlayer) { try { _musicPlayer.pause(); _musicPlayer.src = ''; _musicPlayer.load(); } catch(e) {} _musicPlayer = null; }
    var m = document.getElementById('faceMusicMini'); if (m) m.remove();
  }

  /* ── 12306 火车票 ── */
  function startTrainSearch(text) {
    /* 工单17: 追加式——对话流容器（utter 已由 say 渲染，防重） */
    var cover = ensureStream();
    var hero = document.getElementById('faceHero');
    if (hero) hero.style.display = 'none';
    if (cover && !streamHasUtter()) {
      cover.appendChild(el('<div class="utter"><span>' + escHtml(text) + '</span></div>'));
      scrollCover();
    }
    // 解析出发/到达/日期
    var from = '上海', to = '北京';
    var mFrom = text.match(/从(\S+?)(?:到|去)/);
    var mTo = text.match(/(?:到|去)(\S+?)(?=[\s的]|火车|高铁|票|$)/);
    if (mFrom) from = mFrom[1];
    if (mTo) to = mTo[1];
    // 城市名标准化
    if (/北京/.test(from)) from = '北京';
    if (/北京/.test(to)) to = '北京';
    if (/上海/.test(from)) from = '上海';
    if (/上海/.test(to)) to = '上海';
    if (/广州/.test(from)) from = '广州';
    if (/广州/.test(to)) to = '广州';
    if (/深圳/.test(from)) from = '深圳';
    if (/深圳/.test(to)) to = '深圳';
    if (/杭州/.test(from)) from = '杭州';
    if (/杭州/.test(to)) to = '杭州';
    if (/南京/.test(from)) from = '南京';
    if (/南京/.test(to)) to = '南京';
    var date = '明天';
    if (/后天/.test(text)) date = '后天';
    else if (/(\d+)月(\d+)日/.test(text)) date = text.match(/(\d+)月(\d+)日/)[0];

    cover.appendChild(el('<div class="understanding"><span>' + escHtml(from) + ' → ' + escHtml(to) + ' · ' + escHtml(date) + '</span></div>'));
    scrollCover();

    if (typeof B !== 'undefined' && B.query) {
      var resp = B.query({q:'train_search', from: from, to: to, date: date});
      if (resp && resp.ok && resp.data && resp.data.trains) {
        var trains = resp.data.trains;
        if (trains.length > 0) {
          trains.forEach(function(t) {
            var card = el('<div class="opt" style="animation-delay:0.1s">'
              + '<div class="top"><span class="main">' + escHtml(t.trainNo) + '</span><span class="price">' + escHtml(t.remaining) + '</span></div>'
              + '<div class="sub">' + escHtml(t.depart) + ' → ' + escHtml(t.arrive) + ' · 历时 ' + escHtml(t.duration) + '</div>'
              + '<div class="tags"><span class="tag">' + escHtml(t.seatType) + '</span></div></div>');
            card.addEventListener('click', function() {
              var url = 'https://kyfw.12306.cn/otn/leftTicket/init';
              try { if (typeof B !== 'undefined' && B.openConnectUrl) B.openConnectUrl(url, '12306'); } catch(e) {}
            });
            cover.appendChild(card);
          });
          scrollCover();
          return;
        }
      }
    }
    cover.appendChild(el('<div class="face-empty">未找到车次 · 请换个日期试试</div>'));
    scrollCover();
  }

  function matchFlowKey(text) {
    if (/剧|追剧|看|电影|视频|综艺|繁花|庆余年|漫长的季节/.test(text)) return 'drama';
    if (/买|牛奶|购|下单/.test(text)) return 'shop';   /* W3: 购物走 shop_search 真链路 */
    /* W3: 机票无真源 → flight 走诚实提示 (不下演示卡) */
    if (/机票|飞|航班/.test(text)) return 'flight';
    return null;
  }

  /** 适合专家模式的任务：自动转（用户口径 2026-08-01「没必要点击」）——告知一行后自动交接 */
  function autoHandoff(text, data) {
    /* 工单17: 标记为首页自动交接链路（expertCreateRoom 同房复用判断用） */
    _homeHandoff = true;
    /* 工单17: 追加式——对话流容器（utter 已由 say 渲染，防重） */
    var cover = ensureStream();
    if (cover && !streamHasUtter()) {
      cover.appendChild(el('<div class="utter"><span>' + escHtml(text) + '</span></div>'));
      scrollCover();
    }
    if (cover) {
      cover.appendChild(el('<div class="understanding"><span class="u-dot"></span>这个交给我们，正在为你安排…</div>'));
      scrollCover();
    }
    var slotsStr = '{}';
    try { if (data.slots && typeof data.slots === 'object') slotsStr = JSON.stringify(data.slots); } catch(e) {}
    setTimeout(function() {
      handoffToExpert(text, slotsStr);
      /* 用户口径：转过去就直接开工——预填后自动提交（建房+发消息+Agent 起计划），零点击 */
      setTimeout(function() {
        var pi = document.getElementById('expertPillInput');
        if (pi && pi.value.trim()) expertSend();
      }, 800);
    }, 900);
  }

  /** 升级通道交接卡 */
  function showHandoff(text, data) {
    /* 工单17: 追加式——交接卡插入对话流末尾 */
    var cover = ensureStream();
    var slotsStr = '{}';
    try { if (data.slots && typeof data.slots === 'object') slotsStr = JSON.stringify(data.slots); } catch(e) {}
    var slotsObj = {};
    try { slotsObj = JSON.parse(slotsStr); } catch(e) {}
    var slotKeys = Object.keys(slotsObj);
    var ctxHtml = '';
    if (slotKeys.length > 0) {
      ctxHtml = slotKeys.map(function(k) { return k + ': ' + slotsObj[k]; }).join(' · ');
    } else {
      ctxHtml = '已理解你的意图';
    }

    var card = el('<div class="handoff">'
      + '<div class="ho-icon"><svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg></div>'
      + '<h3>这个要动真格的</h3>'
      + '<div class="ho-sub">这个任务需要完整执行环境——工具、记录、版本都在</div>'
      + '<div class="ho-ctx">' + escHtml(ctxHtml) + '</div>'
      + '<div class="ho-btn" id="faceHandoffBtn">→ 开始执行</div>'
      + '<div class="ho-cancel" id="faceHandoffCancel">留在首页</div>'
      + '</div>');
    // addEventListener 替代 onclick 拼接（避免双引号截断；ONBOARD 红线 2）
    var btn = card.querySelector('#faceHandoffBtn');
    var cancel = card.querySelector('#faceHandoffCancel');
    if (btn) btn.addEventListener('click', function() { handoffToExpert(text, slotsStr); });
    if (cancel) cancel.addEventListener('click', function() { resetFace(); });
    cover.appendChild(card);
    scrollCover();
  }

  function showInlineChat(text) {
    /* 工单17: 追加式——对话流容器（utter 已由 say 渲染，此处只加思考中） */
    var cover = ensureStream();
    if (!cover) return;
    var thinking = el('<div class="understanding"><span class="u-dot"></span><span>思考中…</span></div>');
    cover.appendChild(thinking); scrollCover();
    if (typeof B !== 'undefined' && B.aiAsync) {
      B.aiAsync(text, function(resp) {
        // 新 say 已重置对话流时（thinking 不在 DOM）→ 丢弃旧回复，防刷屏串扰
        if (!thinking.parentNode) return;
        if (thinking.parentNode) thinking.parentNode.removeChild(thinking);
        var content = resp && resp.ok ? resp.content : '（回复失败：' + (resp ? resp.content : '模型未配置') + '）';
        var bubble = el('<div class="utter bot prewrap">' + escHtml(content) + '</div>');
        cover.appendChild(bubble); scrollCover();
      });
    } else {
      // 桥不可用兜底
      if (thinking.parentNode) thinking.parentNode.removeChild(thinking);
      cover.appendChild(el('<div class="face-honest">对话暂不可用<br><span>试试说：我要听小苹果 / 订明天去北京的火车票 / 我要追剧</span></div>'));
      scrollCover();
    }
  }

  /** 交接 → 专家模式，带上下文 */
  /** 工单17 §六补充条款：升级必带情境——拼 ctx 时读 watch_history 当前在看条目注入
   *  「[当前情境：在看《X》第 N 话]」；读失败静默（不阻塞交接） */
  function currentWatchingContext() {
    try {
      var r = (typeof B !== 'undefined' && B.query) ? B.query({q:'watch_history'}) : null;
      if (!r || !r.ok || !r.data) return '';
      var best = null, bestTs = 0;
      for (var k in r.data) {
        var it = r.data[k];
        if (!it) continue;
        var ts = it.ts || 0;
        if (ts >= bestTs) { best = it; bestTs = ts; }
      }
      if (!best) return '';
      var title = best.title || '';
      var ep = best.episode || best.ep || 0;
      var parts = [];
      if (title) parts.push('在看《' + title + '》');
      if (ep) parts.push('第 ' + ep + ' 话');
      return parts.length ? ' [当前情境：' + parts.join(' · ') + ']' : '';
    } catch(e) { return ''; }
  }

  function handoffToExpert(text, slotsJson) {
    var ctx = text;
    try {
      var slots = JSON.parse(slotsJson || '{}');
      var keys = Object.keys(slots);
      if (keys.length > 0) {
        ctx += ' [' + keys.map(function(k) { return k + ': ' + slots[k]; }).join(', ') + ']';
      }
    } catch(e) {}
    /* 工单17 §六：升级必带情境（短→长开房注入当前短任务现场） */
    ctx += currentWatchingContext();
    switchToExpert(ctx);
  }

  function voice() { alert('Phase 2 接 speech.recognize，当前 Demo'); }

  function startFlow(key, mwave) {
    currentFlow = key;
    var f = FLOWS[key];
    /* 工单17: 追加式——对话流容器（utter 已由 say 渲染，防重） */
    var cover = ensureStream();
    /* W3: 机票无真源 → 诚实提示 (不下演示卡), 推荐火车票真链路 */
    if (key === 'flight' || !f) {
      _flightHonest(cover);
      return;
    }
    // 用用户原话（say() 可能已渲染过，去重）
    var utterance = _lastUtterance || f.utter;
    if (!cover.querySelector('.utter')) {
      cover.appendChild(el('<div class="utter"><span>' + escHtml(utterance) + '</span></div>'));
      scrollCover();
    }
    scrollCover();
    var mw = mwave || document.getElementById('faceMwave');
    if (mw) mw.classList.add('thinking');
    var u = el('<div class="understanding"><span class="u-dot"></span><span>理解中…</span></div>');
    cover.appendChild(u); scrollCover();
    setTimeout(function() {
      u.querySelector('span:last-child').innerHTML = slotHTML(f);
      setTimeout(function() {
        if (mw) mw.classList.remove('thinking');
        if (f.ctx && key !== 'drama') { cover.appendChild(el('<div class="ctxline"><b>◆</b><span>' + f.ctx + '</span></div>')); scrollCover(); }
        // drama 流走真实搜索; shop 走 shop_search 真链路 (W3: 演示卡下线)
        if (key === 'drama') {
          renderDramaOptions(utterance, f);
        } else if (key === 'shop') {
          startShopSearch(utterance, mw);
        } else {
          setTimeout(function() { renderOptions(f); }, 350);
        }
      }, 500);
    }, 900);
  }
  /* W3: 机票诚实提示 — 无真实数据源, 推荐火车票真链路 (反假菜单红线) */
  function _flightHonest(cover) {
    if (!cover.querySelector('.utter') && _lastUtterance) {
      cover.appendChild(el('<div class="utter"><span>' + escHtml(_lastUtterance) + '</span></div>'));
    }
    var card = el('<div class="failcard"><div class="ft"><span class="fi">✈️</span>机票预订暂不可用</div>'
      + '<div class="freason">航班数据没有可靠实时来源，不给你看假的。火车票是真实可查的——试试「查明天去北京的火车票」。</div>'
      + '<div class="factions"><button onclick="NewFace.startTrainSearch(\'帮我查明天去北京的火车票\')">🚄 查火车票</button></div></div>');
    cover.appendChild(card);
    scrollCover();
  }

  /* W3: 京东购物搜索真链路 (shop_search 桥 → 真商品卡 → 打开京东落地页) */
  function startShopSearch(text, mwave) {
    var cover = document.getElementById('faceCover');
    var kw = (text || '').replace(/帮我买|帮我|买|搜|一下|吧|牛奶|东西|商品/g, '').trim();
    if (!kw) kw = '牛奶';
    var mw = mwave || document.getElementById('faceMwave');
    if (mw) mw.classList.add('thinking');
    cover.appendChild(el('<div class="understanding"><span class="u-dot"></span><span>正在京东搜「' + escHtml(kw) + '」…</span></div>'));
    scrollCover();
    if (typeof B !== 'undefined' && B.query) {
      var resp = B.query({q:'shop_search', keyword: kw});
      if (mw) mw.classList.remove('thinking');
      if (resp && resp.ok && resp.data && resp.data.items && resp.data.items.length > 0) {
        resp.data.items.forEach(function(it) {
          var card = el('<div class="opt" style="animation-delay:0.1s">'
            + '<div class="top"><span class="main">' + escHtml(it.name) + '</span>'
            + (it.price ? '<span class="price">¥' + escHtml(it.price) + '</span>' : '') + '</div>'
            + '<div class="sub">京东 · 点按打开商品页</div></div>');
          card.addEventListener('click', function() {
            var url = it.url ? ('https:' + it.url) : ('https://so.m.jd.com/ware/search.action?keyword=' + encodeURIComponent(kw));
            try { if (typeof B !== 'undefined' && B.openConnectUrl) B.openConnectUrl(url, '京东'); } catch(e) {}
          });
          cover.appendChild(card);
        });
      } else {
        cover.appendChild(el('<div class="failcard"><div class="ft"><span class="fi">🛒</span>京东搜索暂不可用</div>'
          + '<div class="freason">' + escHtml(((resp && resp.error && resp.error.msg) || '京东反爬或网络异常，稍后再试')) + '</div></div>'));
      }
    } else {
      if (mw) mw.classList.remove('thinking');
      cover.appendChild(el('<div class="failcard"><div class="ft"><span class="fi">🛒</span>桥不可用</div></div>'));
    }
    scrollCover();
  }

  /** 从用户原话提取剧名（去触发词） */
  var CN_NUM = { '一':1,'二':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'十':10,
    '百':100,'千':1000,'零':0,'两':2 };
  function cnToInt(s) {
    if (!s) return 0;
    if (/^\d+$/.test(s)) return parseInt(s);
    var r = 0, tmp = 0;
    for (var i = 0; i < s.length; i++) {
      var c = s.charAt(i);
      var v = CN_NUM[c];
      if (v === undefined) return parseInt(s) || 0;
      if (v >= 10) { tmp = (tmp || 1) * v; r += tmp; tmp = 0; }
      else tmp = v;
    }
    return r + tmp;
  }

  function extractEpisode(text) {
    var m = (text||'').match(/第\s*([\d一二三四五六七八九十百千零两]+)\s*[集话期]/);
    return m ? cnToInt(m[1]) : 0;
  }

  function isLatestIntent(text) {
    return /最新.*[集话期]|[集话期].*最新/.test(text);
  }

  function extractDramaName(text) {
    // 先去集数标记再剥触发词
    var t = (text || '').replace(/第\s*\d+\s*[集话期]/g, '');
    t = t.replace(/我要追|我要看|我想追|我想看|追剧|追|看/g, '').trim();
    t = t.replace(/[ 的啦吗呢吧]$/, '').trim();
    if (t.length < 2) return '';
    return t;
  }

  /** 追剧真数据：B.faceSearchDramaAsync → 真实选项卡 / 失败卡 */
  function renderDramaOptions(utterance, f) {
    var query = extractDramaName(utterance);
    _lastDramaQuery = query;
    if (!query) { showPersonalizedDramaHome(); return; }
    var cover = document.getElementById('faceCover');
    // 任务K·续播推理：指名集数优先 → 历史进度次之
    var explicitEp = extractEpisode(utterance);
    var latestWanted = isLatestIntent(utterance);
    var history = loadWatchProgress();
    var historyHit = !explicitEp && history && history.title && NewFaceMatch.fuzzyScore(query, history.title) >= 0.6 && history.url;
    // 最新的一集 → 查站点 latestEpisode → 直达
    if (latestWanted) {
      try {
        var latestResp = (typeof B !== 'undefined' && B.query) ? B.query({q:'mayi_latest', title: query}) : null;
        if (latestResp && latestResp.ok && latestResp.data && latestResp.data.latestEp > 0) {
          var lep = latestResp.data.latestEp;
          var lurl = latestResp.data.playUrl || ('https://91mayitv.com/vodplay/' + encodeURIComponent(query) + '-1-' + lep + '.html');
          _openConnectUrl(lurl);
          return;
        }
      } catch(e) {}
      // 失败降级搜索
    }
    // 指名集数 → 零中间页直达播放（任务I'）
    if (explicitEp > 0) {
      var openUrl = '';
      if (history && history.url) {
        var dm = history.url.match(/voddetail\/(\d+)\.html/);
        if (dm) openUrl = 'https://91mayitv.com/vodplay/' + dm[1] + '-1-' + explicitEp + '.html';
        else openUrl = history.url.replace(/-(\d+)-(\d+)\.html/, '-' + explicitEp + '-$2.html');
      }
      if (!openUrl) openUrl = 'https://91mayitv.com/vodplay/' + encodeURIComponent(query) + '-1-' + explicitEp + '.html';
      _openConnectUrl(openUrl);
      return;
    }
    // 历史进度 → 顶卡续播
    if (historyHit) {
      var targetEp = (history.episode || 0) + 1;
      var label = '第' + targetEp + '集 · 接着看';
      var openUrl = '';
      if (history && history.url) {
        var detailMatch = history.url.match(/voddetail\/(\d+)\.html/);
        if (detailMatch) openUrl = 'https://91mayitv.com/vodplay/' + detailMatch[1] + '-1-' + targetEp + '.html';
        else openUrl = history.url.replace(/-(\d+)-(\d+)\.html/, '-' + targetEp + '-$2.html');
      }
      if (!openUrl) openUrl = 'https://91mayitv.com/vodplay/' + encodeURIComponent(query) + '-1-' + targetEp + '.html';
      var sub = label;
      if (history.positionMs && history.positionMs > 30000) sub += ' · ' + formatPosition(history.positionMs);
      var card = el('<div class="a2a-card cont"><h3>📺 继续看</h3>'
        + '<div class="a2a-sub">' + escHtml(query) + ' · ' + sub + '</div>'
        + '<button class="a2a-btn" id="cwPlayBtn">' + label + ' · 一键观看</button>'
        + '<div class="a2a-cancel" id="cwSearchBtn">没有？搜全部版本 »</div></div>');
      // 卡片本体可点击直接播放（不只按钮）；内部按钮/取消 stopPropagation 防双触发
      card.addEventListener('click', function() { _openConnectUrl(openUrl); });
      var pb = card.querySelector('#cwPlayBtn');
      if (pb) pb.addEventListener('click', function(e) { e.stopPropagation(); _openConnectUrl(openUrl); });
      var sb = card.querySelector('#cwSearchBtn');
      if (sb) sb.addEventListener('click', function(e) { e.stopPropagation(); _continueSearch(query); });
      cover.appendChild(card);
      scrollCover();
      return;
    }
    // 无进度 → 搜索流
    _continueSearch(query);
  }

  function _continueSearch(query) {
    var cover = document.getElementById('faceCover');
    var cc = cover.querySelector('.a2a-card');
    if (cc) cc.remove();
    if (typeof B !== 'undefined' && B.faceSearchDramaAsync) {
      B.faceSearchDramaAsync(query, function(resp) {
        if (resp && resp.ok && resp.data && resp.data.items && resp.data.items.length > 0) {
          renderRealDramaCards(resp.data.items);
        } else {
          // 搜索无结果 / 失败 → 失败卡
          showDramaFailCard();
        }
      });
    } else {
      // 桥不可用 → 降级 mock
      setTimeout(function() { renderOptions(f); }, 350);
    }
  }

  /** 渲染真实搜索结果选项卡 */
  function renderRealDramaCards(items) {
    var cover = document.getElementById('faceCover');
    // 任务N·屏蔽过滤
    try {
      var mem = (typeof B !== 'undefined' && B.query) ? B.query({q:'drama_memory'}) : null;
      var blocks = (mem && mem.ok && mem.data && mem.data.blocks) ? mem.data.blocks : [];
      items = items.filter(function(it) {
        return !blocks.some(function(b) { return b.title === it.title && (b.source === it.source || !b.source); });
      });
    } catch(e) {}
    items.forEach(function(item, i) {
      var posterHtml = '';
      if (item.poster) {
        posterHtml = '<div class="poster" style="background:linear-gradient(135deg,#3d4a5c,#7a5c48)"><span>' + escHtml(item.title) + '</span></div>';
      }
      var isEmbed = item.viewType === 'embed';
      var isLocal = item.viewType === 'local_player';
      var tags = [];
      if (isLocal) {
        tags.push('<span class="tag ctx">本地 · 本机文件</span>');
        if (item.episode) tags.push('<span class="tag">' + escHtml(item.episode) + '</span>');
      } else if (isEmbed) {
        tags.push('<span class="tag plat">可看 · 内嵌播放</span>');
        if (item.duration) tags.push('<span class="tag">' + escHtml(item.duration) + '</span>');
        if (item.playCount) tags.push('<span class="tag">' + escHtml(item.playCount) + ' 播放</span>');
      } else {
        if (item.platform) tags.push('<span class="tag plat">' + escHtml(item.platform === 'tencent' ? '正片 · 腾讯视频' : item.platform === 'bilibili' ? 'B站' : item.platform === 'iqiyi' ? '正片 · 爱奇艺' : item.platform) + '</span>');
        tags.push('<span class="tag ctx">来源：' + escHtml(item.source) + '</span>');
        if (item.year) tags.push('<span class="tag">' + escHtml(item.year) + '</span>');
      }
      var card = el('<div class="opt" style="animation-delay:' + (i * 0.14) + 's">' + posterHtml
        + '<div class="top"><span class="main">' + escHtml(item.title) + '</span></div>'
        + '<div class="sub">' + (isLocal ? '本地文件 · 内嵌播放 · 不用网' : isEmbed ? 'B站 · 内嵌播放 · 免登录' : escHtml(item.url || '')) + '</div>'
        + '<div class="tags">' + tags.join('') + '</div></div>');
      // 闭包存 item，避免 onclick 拼接
      // 长按菜单（任务M/N）
      var longTimer;
      card.addEventListener('pointerdown', function() {
        longTimer = setTimeout(function() { showDramaLongMenu(item); }, 500);
      });
      card.addEventListener('pointerup', function() { clearTimeout(longTimer); });
      card.addEventListener('pointerleave', function() { clearTimeout(longTimer); });
      card.addEventListener('click', (function(it) { return function() {
        clearTimeout(longTimer);
        pickDramaOption(it);
        // 记录源偏好 signal
        try { B.query({q:'drama_memory', op:'signal', source:it.source||''}); } catch(e) {}
      }; })(item));
      cover.appendChild(card);
    });
    // 抖音通道卡：登录一次永久免登录，正片生态
    if (_lastDramaQuery) {
      var dyc = el('<div class="opt dashed" style="animation-delay:.5s">'
        + '<div class="top"><span class="main">在抖音搜「' + escHtml(_lastDramaQuery) + '」</span></div>'
        + '<div class="sub">抖音 · 正片生态 · 登录一次永久免登录</div></div>');
      dyc.addEventListener('click', function() { openDouyin(_lastDramaQuery); });
      cover.appendChild(dyc);
    }
    scrollCover();
  }

  /** 平台 deep link scheme 映射（L2 剧集级跳转） */
  var DRAMA_SCHEMES = {
    tencent:  { scheme: 'tenvideo2', pkg: 'com.tencent.qqlive' },
    bilibili: { scheme: 'bilibili',  pkg: 'tv.danmaku.bili' },
    iqiyi:    { scheme: 'iqiyi',     pkg: 'com.qiyi.video' }
  };

  /** 点击真实追剧选项卡 → 三级降级: scheme剧集页 → 拉起App首页 → 网页 */
  function pickDramaOption(item) {
    // 本地视频：viewType=local_player → 系统播放器
    if (item.viewType === 'local_player' && item.path) {
      if (typeof B !== 'undefined' && B.cmd) {
        B.openLocalPlayer(item.path, item.title || '');
      }
      return;
    }
    // 蚂蚁影视：ConnectWeb 内嵌打开详情页（个人源, 免登录）
    if (item.platform === 'mayi91' && item.url && typeof B !== 'undefined' && B.openConnectUrl) {
      saveWatchProgress(item);
      try { B.openConnectUrl(item.url, '蚂蚁影视'); return; } catch(e) {}
    }
    // B站内嵌播放：viewType=embed → iframe overlay
    if (item.viewType === 'embed' && item.url) {
      openEmbedPlayer(item);
      return;
    }
    // 2C.5: 点击即记观看进度（必须在降级链 return 之前——成功跳转恰恰是最该记的场景）
    saveWatchProgress(item);
    var platform = item.platform || '';
    var conf = DRAMA_SCHEMES[platform];
    var title = item.title || '';
    // L2: scheme 剧集级 deep link
    if (conf && title && typeof B !== 'undefined' && B.openDeepLink) {
      try {
        var url = conf.scheme + '://search?keyword=' + encodeURIComponent(title);
        var r = B.openDeepLink(url, conf.pkg);
        if (r && r.ok) return;
      } catch(e) {}
    }
    // L1: 拉起 App 首页
    if (conf && typeof B !== 'undefined' && B.cmd) {
      try {
        var r1 = B.cmd('app.launch --package ' + conf.pkg);
        if (r1 && r1.indexOf('已启动') >= 0) return;
      } catch(e) {}
    }
    // L0: 降级 HTTPS 网页
    if (item.url) {
      if (typeof B !== 'undefined' && B.openUrl) { B.openUrl(item.url); }
      else { window.open(item.url, '_blank'); }
    } else if (typeof B !== 'undefined' && B.toast) {
      B.toast('未找到可播放的链接');
    }
  }

  /* ── 2C.5 接着上次看 ── */
  var WATCH_KEY = 'mov_face_watch';

  function saveWatchProgress(item) {
    try {
      var progress = { title: item.title || '', platform: item.platform || '',
        url: item.url || '', poster: item.poster || '', ts: Date.now() };
      localStorage.setItem(WATCH_KEY, JSON.stringify(progress));
    } catch(e) {}
  }

  function loadWatchProgress() {
    try {
      var raw = localStorage.getItem(WATCH_KEY);
      if (!raw) return null;
      var p = JSON.parse(raw);
      if (!p.title) return null;
      if (Date.now() - p.ts > 7 * 86400000) { localStorage.removeItem(WATCH_KEY); return null; }
      // 补齐 WatchBridge 数据（episode + positionMs）
      try {
        var wh = (typeof B !== 'undefined' && B.watchHistory) ? B.watchHistory() : {};
        var whItem = wh[p.title];
        if (whItem) {
          if (whItem.episode) p.episode = whItem.episode;
          if (whItem.positionMs) p.positionMs = whItem.positionMs;
          if (whItem.url && whItem.url.length > 5) p.url = whItem.url;
          p.ts = whItem.ts || p.ts;
        }
      } catch(e) {}
      return p;
    } catch(e) { return null; }
  }

  function formatPosition(ms) {
    if (!ms || ms < 1000) return '';
    var s = Math.round(ms / 1000);
    var m = Math.floor(s / 60);
    var sec = s % 60;
    return (m < 10 ? '0' : '') + m + ':' + (sec < 10 ? '0' : '') + sec;
  }

  /** 在封面情境卡顶部注入"接着上次看" */
  function injectContinueWatching() {
    var progress = loadWatchProgress();
    if (!progress) return;
    var sugg = document.querySelector('#view-face .sugg');
    if (!sugg) return;
    if (document.getElementById('faceContinueWatching')) return;
    var elapsed = Math.round((Date.now() - progress.ts) / 60000);
    var sub = elapsed < 60 ? '刚刚在看 · 接着看？'
            : elapsed < 1440 ? Math.round(elapsed / 60) + ' 小时前在看'
            : Math.round(elapsed / 1440) + ' 天前在看';
    if (progress.episode) sub = '第' + progress.episode + '话' + (progress.positionMs ? ' · ' + formatPosition(progress.positionMs) : '') + ' · ' + sub;
    var onclick = progress.url && progress.url.indexOf('http') === 0
      ? "NewFace._openConnectUrl('" + escHtml(progress.url) + "')"
      : "NewFace.say('我要看" + escHtml(progress.title) + "')";
    var card = el('<div class="sitem hl" id="faceContinueWatching" onclick="' + onclick + '">'
      + '<div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="#4a6fd4" stroke-width="1.8"><rect x="3" y="5" width="18" height="13" rx="2"/><path d="M10 9.5v4l3.5-2z" fill="#4a6fd4" stroke="none"/></svg></div>'
      + '<div class="tx"><div class="t1">' + escHtml(progress.title) + '</div><div class="t2">' + sub + '</div></div>'
      + '<span class="go">›</span></div>');
    var first = sugg.querySelector('.sitem');
    if (first) { sugg.insertBefore(card, first); }
    else { sugg.appendChild(card); }
  }

  /* ── 任务L·更新雷达 ── */
  function scanDramaUpdates() {
    try {
      var resp = (typeof B !== 'undefined' && B.query) ? B.query({q:'check_drama_updates'}) : null;
      if (!resp || !resp.ok || !resp.data || !resp.data.watching) return;
      var watching = resp.data.watching;
      if (!watching.length) return;
      var sugg = document.querySelector('#view-face .sugg');
      if (!sugg || document.getElementById('faceUpdateRadar')) return;
      var h = '<div class="sitem hl-green" id="faceUpdateRadar" onclick="NewFace.say(\'我要看' + escHtml(watching[0].title) + '\')">'
        + '<div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="#5d9b4a" stroke-width="1.8"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/></svg></div>'
        + '<div class="tx"><div class="t1">' + escHtml(watching.length) + ' 部剧在追</div><div class="t2">说「我要看XXX」继续追</div></div>'
        + '<span class="go">›</span></div>';
      var first = sugg.querySelector('.sitem');
      if (first) { sugg.insertBefore(el(h), first); }
      else { sugg.appendChild(el(h)); }
    } catch(e) {}
  }

  /* ── 任务M/N·长按菜单 ── */
  function showDramaLongMenu(item) {
    // 简单底部弹窗
    var existing = document.getElementById('faceDramaMenu');
    if (existing) existing.remove();
    var menu = el('<div id="faceDramaMenu" class="drama-menu">'
      + '<div class="dm-title">' + escHtml(item.title||'') + '</div>'
      + '<div class="a2a-row" onclick="NewFace._dramaFav(\'' + escHtml(item.title||'') + '\',\'' + escHtml(item.url||'') + '\',\'' + escHtml(item.poster||'') + '\')">⭐ 收藏</div>'
      + '<div class="a2a-row" onclick="NewFace._dramaBlock(\'' + escHtml(item.title||'') + '\',\'' + escHtml(item.source||'') + '\')">🚫 不喜欢 · 不再出现</div>'
      + '<div class="dm-cancel" onclick="document.getElementById(\'faceDramaMenu\').remove()">取消</div>'
      + '</div>');
    document.body.appendChild(menu);
  }

  function _dramaFav(title, url, poster) {
    try { B.query({q:'drama_memory', op:'add_fav', title:title, url:url, poster:poster}); } catch(e) {}
    var m = document.getElementById('faceDramaMenu'); if (m) m.remove();
    if (typeof B !== 'undefined' && B.toast) B.toast('⭐ 已收藏 ' + title);
  }

  function _dramaBlock(title, source) {
    try { B.query({q:'drama_memory', op:'add_block', title:title, source:source}); } catch(e) {}
    var m = document.getElementById('faceDramaMenu'); if (m) m.remove();
    // 移除页面上的对应卡片
    var cards = document.querySelectorAll('#view-face .opt');
    cards.forEach(function(c) {
      var t = (c.querySelector('.main')||{}).textContent;
      if (t === title) c.remove();
    });
    if (typeof B !== 'undefined' && B.toast) B.toast('🚫 已屏蔽 ' + title);
  }

  /* ── 任务O·个性化追剧首页（无剧名时说"我要追剧"） ── */
  function showPersonalizedDramaHome() {
    var cover = document.getElementById('faceCover');
    var history = loadWatchProgress();
    var mem = null;
    try { mem = (typeof B !== 'undefined' && B.query) ? B.query({q:'drama_memory'}) : null; } catch(e) {}
    var favs = (mem && mem.ok && mem.data && mem.data.favs) ? mem.data.favs : [];
    var blocks = (mem && mem.ok && mem.data && mem.data.blocks) ? mem.data.blocks : [];

    // 三层聚合
    var h = '<div class="a2a-card"><h3>📺 接着看</h3>';
    if (history && history.title && history.url) {
      h += '<div class="a2a-sub">' + escHtml(history.title) + ' · 第' + ((history.episode||0)+1) + '集'
        + (history.positionMs > 30000 ? ' · ' + formatPosition(history.positionMs) : '') + '</div>'
        + '<button class="a2a-btn" onclick="NewFace._openConnectUrl(\'' + escHtml(history.url) + '\')">一键观看</button>';
    } else if (favs.length > 0) {
      var f = favs[0];
      h += '<div class="a2a-sub">' + escHtml(f.title) + '</div>'
        + '<button class="a2a-btn" onclick="NewFace.say(\'我要看' + escHtml(f.title) + '\')">继续追</button>';
    } else {
      h += '<div class="a2a-sub">说个剧名试试</div>';
    }
    // 书架
    if (favs.length > 0) {
      h += '<div class="favs-title"><b>📚 书架 (' + favs.length + ')</b></div>';
      favs.forEach(function(f) {
        h += '<div class="a2a-row" onclick="NewFace.say(\'我要看' + escHtml(f.title) + '\')">⭐ ' + escHtml(f.title) + '<span>›</span></div>';
      });
    }
    // 屏蔽计数
    if (blocks.length > 0) {
      h += '<div class="meta mt8">🚫 已屏蔽 ' + blocks.length + ' 条</div>';
    }
    h += '</div>';
    cover.appendChild(el(h));
    scrollCover();
  }

  /** 空剧名兜底：内嵌气泡询问 */
  function showDramaAskBubble() {
    var cover = document.getElementById('faceCover');
    cover.appendChild(el('<div class="ask-bubble">'
      + '想追哪部剧？<br><small>比如：漫长的季节、繁花、我的阿勒泰</small>'
      + '</div>'));
    scrollCover();
  }

  /* ══════════════════════════════════════════════════════
     A2A 买家侧卡片流（五卡状态机）
     ══════════════════════════════════════════════════════ */
  var _a2a = { state: 'idle', peer: null, cart: [], confirm: null, orderId: null, pollTimer: null, pollMsgs: [] };

  /* ── _a2aMsg 回调: BridgeA2a.a2aStartPolling 推送的消息 ── */
  window._a2aMsg = function(ev) {
    if (!_a2a || _a2a.state === 'idle') return;
    _a2a.pollMsgs.push(ev);
    // 自动推进卡片流
    if (ev.msgType === 'menu' && _a2a.state === 'menu_wait') {
      _a2a.state = 'menu';
      refreshA2ACard();
    } else if (ev.msgType === 'confirm' && (_a2a.state === 'order_wait' || _a2a.state === 'payment')) {
      _a2a.confirm = ev.payload || {};
      _a2a.state = 'payment';
      refreshA2ACard();
    } else if (ev.msgType === 'status' && _a2a.state === 'status') {
      _a2a.confirm = ev.payload || {};
      refreshA2ACard();
    }
  };

  function refreshA2ACard() {
    var cards = document.querySelectorAll('#view-face .a2a-card');
    for (var i = cards.length - 1; i >= 0; i--) cards[i].remove();
    var ctxlines = document.querySelectorAll('#view-face .ctxline');
    for (var j = ctxlines.length - 1; j >= 0; j--) ctxlines[j].remove();
    switch (_a2a.state) {
      case 'menu': renderA2AMenu(); break;
      case 'payment': renderA2APayment(); break;
      case 'status': renderA2AStatus(); break;
    }
  }

  function startA2A(text) {
    /* 工单17: 追加式——对话流容器（utter 已由 say 渲染，防重） */
    var cover = ensureStream();
    var hero = document.getElementById('faceHero');
    if (hero) hero.style.display = 'none';
    _a2a = { state: 'peer_select', peer: null, cart: [], confirm: null, orderId: null, pollTimer: null, pollMsgs: [] };
    if (cover && !streamHasUtter()) {
      cover.appendChild(el('<div class="utter"><span>' + escHtml(text) + '</span></div>'));
      scrollCover();
    }
    // 首次注册
    if (typeof B !== 'undefined' && B.a2aRegistered && !B.a2aRegistered()) {
      var did = 'buyer_' + Date.now().toString(36);
      try { if (typeof B !== 'undefined' && B.a2aRegister) B.a2aRegister(did, '买家' + did.slice(-4), function(r) {
        if (r && r.ok) { try { if (typeof B !== 'undefined' && B.a2aStartPolling) B.a2aStartPolling(); } catch(e) {} }
      }); } catch(e) {}
    } else {
      try { if (typeof B !== 'undefined' && B.a2aStartPolling) B.a2aStartPolling(); } catch(e) {}
    }
    // 提取菜名
    var dish = extractDishName(text);
    if (dish) {
      renderA2APeerSelectWithDish(dish);
    } else {
      renderA2APeerSelect();
    }
  }

  function extractDishName(text) {
    var m = text.match(/(?:来一份|来碗|来份|我要吃|我想吃|想吃|点.*个)\s*(.+)/);
    if (m) return m[1].replace(/[，。！？,!?]/g, '').trim();
    return '';
  }

  function renderA2APeerSelect() {
    var cover = document.getElementById('faceCover');
    // 异步获取 peers 后再渲染
    if (typeof B !== 'undefined' && B.a2aPeers) {
      B.a2aPeers(function(peers) {
        renderA2APeerList(peers || []);
      });
    } else {
      renderA2APeerList([]);
    }
  }

  /* ── 菜名优先动线 ── */
  function renderA2APeerSelectWithDish(dish) {
    var cover = document.getElementById('faceCover');
    // 显示等待
    cover.appendChild(el('<div class="a2a-card"><h3>找菜中</h3><div class="a2a-sub">正在附近的商家找「' + escHtml(dish) + '」…</div>'
      + '<div class="mwave thinking mwave-gap"><svg width="60" height="18" viewBox="0 0 60 18"><path class="base" d="M2 3 L11 15 L20 3 L29 15 L38 3 L47 15 L56 3" stroke-linejoin="round"/><path class="flow" d="M2 3 L11 15 L20 3 L29 15 L38 3 L47 15 L56 3" stroke-linejoin="round"/></svg></div>'
      + '<div class="a2a-cancel" onclick="NewFace.resetFace()">取消</div></div>'));
    scrollCover();
    // 并发拉菜单
    if (typeof B !== 'undefined' && B.a2aPeers) {
      B.a2aPeers(function(peers) {
        if (!peers || !peers.length) {
          renderA2APeerList([]); return;
        }
        var limit = Math.min(peers.length, 5);
        var results = [];
        var done = 0;
        peers.slice(0, limit).forEach(function(p) {
          if (typeof B !== 'undefined' && B.a2aGetMenu) {
            B.a2aGetMenu(p.deviceId, function(r) { done++; });
          }
          // mock: use sync for now, real poll will fill pollMsgs
          if (window.__A2A_MOCK && typeof B !== 'undefined' && B.a2aGetMenu) {
            try { var m = B.a2aGetMenu(p.deviceId); if (m && m.items) {
              m.items.forEach(function(item) {
                var s = NewFaceMatch.fuzzyScore(dish, item.name);
                if (s > 0.4) results.push({ peer: p, item: item, score: s, menu: m });
              });
            }} catch(e) {}
          }
        });
        // mock 路径：直接渲染结果
        if (window.__A2A_MOCK) {
          renderDishMatchResults(dish, results, peers.slice(0, limit));
          return;
        }
        // 真路径：等 pollMsgs 积累（最多等 6s）
        var waited = 0;
        var waitTimer = setInterval(function() {
          waited += 500;
          // 从 pollMsgs 提取 menu 消息
          _a2a.pollMsgs.forEach(function(msg) {
            if (msg.msgType === 'menu' && msg.payload) {
              var menu = typeof msg.payload === 'string' ? JSON.parse(msg.payload) : msg.payload;
              var p = peers.find(function(x) { return x.deviceId === msg.fromId; });
              if (p && menu && menu.items) {
                menu.items.forEach(function(item) {
                  var s = NewFaceMatch.fuzzyScore(dish, item.name);
                  if (s > 0.4) results.push({ peer: p, item: item, score: s, menu: menu });
                });
              }
            }
          });
          if (done >= limit || waited >= 6000) {
            clearInterval(waitTimer);
            renderDishMatchResults(dish, results, peers.slice(0, limit));
          }
        }, 500);
      });
    } else {
      renderA2APeerList([]);
    }
  }

  function renderDishMatchResults(dish, results, allPeers) {
    var cover = document.getElementById('faceCover');
    // 去重+排序
    var seen = {};
    var unique = [];
    results.forEach(function(r) {
      var k = r.peer.deviceId + '|' + r.item.name;
      if (!seen[k]) { seen[k] = true; unique.push(r); }
    });
    unique.sort(function(a, b) { return b.score - a.score; });

    var h = '<div class="a2a-card"><h3>' + escHtml(dish) + '</h3>';
    if (unique.length > 0) {
      unique.forEach(function(r, i) {
        var badge = NewFaceMatch.badgeFor(i, r.score);
        h += '<div class="a2a-row" onclick="NewFace._a2aSelectPeer(\'' + escHtml(r.peer.deviceId) + '\',\'' + escHtml(r.peer.name) + '\')">'
          + '<div class="a2a-menu-info"><b>' + escHtml(r.peer.name) + '</b> · ' + escHtml(r.item.name) + ' ¥' + (r.item.price||'?')
          + (badge ? '<br><span class="meta lime">' + badge + '</span>' : '') + '</div>'
          + '<span>›</span></div>';
      });
    } else {
      h += '<div class="a2a-empty">没人做「' + escHtml(dish) + '」<br><span>看看各家招牌菜</span></div>';
      // 展示各商家首个菜作为推荐
      allPeers.forEach(function(p) {
        h += '<div class="a2a-row" onclick="NewFace._a2aSelectPeer(\'' + escHtml(p.deviceId) + '\',\'' + escHtml(p.name) + '\')">'
          + '<b>' + escHtml(p.name) + '</b><span>›</span></div>';
      });
    }
    h += '<div class="a2a-divider">或浏览所有商家</div></div>';
    cover.appendChild(el(h));
    // 追加完整 peer 列表
    renderA2APeerList(allPeers);
  }

  function renderA2APeerList(peers) {
    var cover = document.getElementById('faceCover');
    var h = '<div class="a2a-card">'
      + '<h3>选择商家</h3>'
      + '<div class="a2a-sub">附近已上架的 MOV 商家</div>';
    if (peers.length > 0) {
      peers.forEach(function(p) {
        h += '<div class="a2a-row" onclick="NewFace._a2aSelectPeer(\'' + escHtml(p.deviceId) + '\',\'' + escHtml(p.name) + '\')">'
          + '<b>' + escHtml(p.name) + '</b><span>›</span></div>';
      });
    } else {
      h += '<div class="a2a-empty">附近暂无商家<br><span>让商家也装 MOV 并上架菜单</span></div>';
    }
    h += '<div class="a2a-divider">配对入口在 设置 → 高级 → 设备协作</div>'
      + '<div class="a2a-cancel" onclick="NewFace.resetFace()">取消</div></div>';
    cover.appendChild(el(h));
    scrollCover();
  }

  function _a2aSelectPeer(id, name) {
    if (_a2a.state === 'menu_wait' || _a2a.state === 'menu') return; // 防重入（pair回调+点击可能双触发）
    _a2a.peer = { deviceId: id, name: name };
    _a2a.state = 'menu_wait';
    var cover = document.getElementById('faceCover');
    cover.appendChild(el('<div class="ctxline"><b>◆</b><span>' + escHtml(name) + '</span></div>'));
    // 真世界: 发 get_menu → poll 等 menu 回复（仅发一次）
    try { if (typeof B !== 'undefined' && B.a2aGetMenu) B.a2aGetMenu(id, function(r) {}); } catch(e) {}
    cover.appendChild(el('<div class="a2a-card"><h3>菜单</h3><div class="a2a-sub">正在获取 ' + escHtml(name) + ' 的菜单…</div>'
      + '<div class="mwave thinking mwave-gap"><svg width="60" height="18" viewBox="0 0 60 18"><path class="base" d="M2 3 L11 15 L20 3 L29 15 L38 3 L47 15 L56 3" stroke-linejoin="round"/><path class="flow" d="M2 3 L11 15 L20 3 L29 15 L38 3 L47 15 L56 3" stroke-linejoin="round"/></svg></div>'
      + '<div class="a2a-cancel" onclick="NewFace.resetFace()">取消</div></div>'));
    scrollCover();
  }

  function _a2aPair() {
    var input = document.getElementById('a2aPairInput');
    var code = (input && input.value) ? input.value.trim() : '';
    if (code.length < 6) return;
    try {
      if (typeof B !== 'undefined' && B.a2aPairAccept) {
        B.a2aPairAccept(code, function(r) {
          if (r && r.peer) { closeDrawer(); _a2aSelectPeer(r.peer.deviceId, r.peer.name); }  // 配对成功关抽屉回对话流
          else { var t=el('<div class="ctxline"><b>◆</b><span>配对失败，请检查配对码</span></div>'); document.getElementById('faceCover').appendChild(t); scrollCover(); }
        });
      }
    } catch(e) {}
  }

  function renderA2AMenu() {
    var cover = document.getElementById('faceCover');
    // 真路径: 菜单来自 _a2aMsg poll; mock → sync a2aPoll
    var menu = { items: [] };
    try { if (window.__A2A_MOCK && typeof B !== 'undefined' && B.a2aGetMenu) menu = B.a2aGetMenu(_a2a.peer.deviceId); } catch(e) {}
    // 从 pollMsgs 中找 menu 消息（真路径）
    if (!menu || !menu.items || !menu.items.length) {
      for (var i = 0; i < _a2a.pollMsgs.length; i++) {
        if (_a2a.pollMsgs[i].msgType === 'menu' && _a2a.pollMsgs[i].payload) {
          var pl = _a2a.pollMsgs[i].payload;
          menu = typeof pl === 'string' ? JSON.parse(pl) : pl;
          if (menu.items) break;
        }
      }
    }
    menu = menu || { items: [] };
    if (!menu.items) menu.items = [];
    var cart = _a2a.cart;
    var h = '<div class="a2a-card"><h3>菜单</h3><div class="a2a-sub">' + escHtml(_a2a.peer.name) + '</div>';
    (menu.items || []).forEach(function(item) {
      var qty = 0;
      var ci = cart.findIndex(function(c) { return c.id === item.id; });
      if (ci >= 0) qty = cart[ci].qty || 0;
      h += '<div class="a2a-row menu-item">'
        + '<div class="a2a-menu-info"><b>' + escHtml(item.name) + '</b><span class="meta">¥' + item.price + ' · 库存 ' + (item.stock||0) + '</span></div>'
        + '<div class="a2a-qty"><span onclick="NewFace._a2aCartChange(\'' + escHtml(item.id) + '\',' + (qty-1) + ',' + item.price + ')">−</span>'
        + '<b>' + qty + '</b>'
        + '<span onclick="NewFace._a2aCartChange(\'' + escHtml(item.id) + '\',' + (qty+1) + ',' + item.price + ')">+</span></div></div>';
    });
    h += '<div class="mt12"><input id="a2aNote" class="sheet-input" placeholder="备注（选填）"></div>';
    var total = cart.reduce(function(s, c) { return s + (c.qty||0) * (c.price||0); }, 0);
    if (total > 0) h += '<div class="a2a-total">¥' + total + '</div>';
    h += '<button class="a2a-btn" ' + (total>0?'':'disabled') + ' onclick="NewFace._a2aSubmitOrder()">下单</button>'
      + '<div class="a2a-cancel" onclick="NewFace.resetFace()">取消</div></div>';
    cover.appendChild(el(h));
    scrollCover();
  }

  function _a2aCartChange(id, qty, price) {
    if (qty < 0) qty = 0;
    var idx = _a2a.cart.findIndex(function(c) { return c.id === id; });
    if (qty === 0) { if (idx >= 0) _a2a.cart.splice(idx, 1); }
    else if (idx >= 0) { _a2a.cart[idx].qty = qty; }
    else { _a2a.cart.push({id: id, qty: qty, price: price}); }
    // 刷新菜单卡
    var cards = document.querySelectorAll('#view-face .a2a-card');
    for (var i = cards.length - 1; i >= 0; i--) cards[i].remove();
    renderA2AMenu();
  }

  function _a2aSubmitOrder() {
    var cover = document.getElementById('faceCover');
    var note = (document.getElementById('a2aNote') && document.getElementById('a2aNote').value) || '';
    _a2a.state = 'order_wait';
    try {
      if (typeof B !== 'undefined' && B.a2aOrder) {
        B.a2aOrder(_a2a.peer.deviceId, _a2a.cart, note, function(r) {
          if (r && r.status) {
            _a2a.orderId = r.orderId;
            _a2a.state = 'payment';
            cover.appendChild(el('<div class="ctxline"><b>◆</b><span>已下单 · 等待商家确认</span></div>'));
            // 显示等待卡
            cover.appendChild(el('<div class="a2a-card"><h3>等待商家确认</h3><div class="a2a-sub">已向 ' + escHtml(_a2a.peer.name) + ' 发送订单</div>'
              + '<div class="mwave thinking mwave-gap"><svg width="60" height="18" viewBox="0 0 60 18"><path class="base" d="M2 3 L11 15 L20 3 L29 15 L38 3 L47 15 L56 3" stroke-linejoin="round"/><path class="flow" d="M2 3 L11 15 L20 3 L29 15 L38 3 L47 15 L56 3" stroke-linejoin="round"/></svg></div>'
              + '<div class="a2a-cancel" onclick="NewFace.resetFace()">取消等待</div></div>'));
            scrollCover();
          } else {
            cover.appendChild(el('<div class="pay-err">下单失败，请重试</div>'));
            scrollCover();
          }
        });
        return;
      }
    } catch(e) {}
    cover.appendChild(el('<div class="pay-err">下单失败，请重试</div>'));
    scrollCover();
  }

  function renderA2APayment() {
    var cover = document.getElementById('faceCover');
    // 真路径: confirm 来自 _a2aMsg poll
    var confirm = _a2a.confirm;
    // mock 回退: sync a2aPoll
    if (!confirm || !confirm.pay_link) {
      try { if (window.__A2A_MOCK && typeof B !== 'undefined' && B.a2aPoll) {
        var poll = B.a2aPoll(_a2a.peer.deviceId) || [];
        for (var i = 0; i < poll.length; i++) {
          if (poll[i].type === 'confirm') { confirm = poll[i].payload; _a2a.confirm = confirm; break; }
        }
      }} catch(e) {}
    }
    if (!confirm || !confirm.pay_link) {
      // 还没收到确认 → 等待中
      cover.appendChild(el('<div class="a2a-card"><h3>等待商家确认</h3><div class="a2a-sub">已向 ' + escHtml(_a2a.peer.name) + ' 发送订单</div>'
        + '<div class="mwave thinking mwave-gap"><svg width="60" height="18" viewBox="0 0 60 18"><path class="base" d="M2 3 L11 15 L20 3 L29 15 L38 3 L47 15 L56 3" stroke-linejoin="round"/><path class="flow" d="M2 3 L11 15 L20 3 L29 15 L38 3 L47 15 L56 3" stroke-linejoin="round"/></svg></div>'
        + '<div class="a2a-cancel" onclick="NewFace.resetFace()">取消等待</div></div>'));
      scrollCover();
      return;
    }
    _a2a.state = 'payment';
    var payInfo = confirm.pay_link || '';
    var isUrl = payInfo.indexOf('http') === 0;
    var noteId = (_a2a.orderId || '').slice(-6);
    var h = '<div class="a2a-card"><h3>请付款</h3>'
      + '<div class="a2a-sub">' + escHtml(_a2a.peer.name) + ' · ¥' + (confirm.total || '?') + '</div>'
      + '<div class="a2a-pay-warn">⚠️ 请在微信中完成付款<br>MOV 不碰钱，资金直接到商家</div>'
      + '<div class="a2a-compact cp" onclick="NewFace._a2aCopyNote(\'' + escHtml(noteId) + '\')">💳 付款请备注 A2A-' + escHtml(noteId) + ' · 点击复制</div>';
    if (confirm.pay_qr_base64) {
      h += '<button class="a2a-btn" onclick="NewFace._a2aWechatScan(\'' + escHtml(noteId) + '\')">📷 去微信扫一扫付款</button>';
    } else if (isUrl) {
      h += '<button class="a2a-btn" onclick="NewFace._a2aOpenPayLink(\'' + escHtml(payInfo) + '\')">打开收款链接</button>';
    } else if (payInfo) {
      h += '<div class="a2a-compact">' + escHtml(payInfo) + '</div>';
    }
    h += '<button class="a2a-btn green" onclick="NewFace._a2aIPaid()">我已付款</button>'
      + '<div class="a2a-cancel" onclick="NewFace.resetFace()">取消订单</div></div>';
    cover.appendChild(el(h));
    scrollCover();
  }

  function _a2aCopyNote(noteId) {
    var text = 'A2A-' + noteId;
    try {
      if (typeof B !== 'undefined' && B.cmd) B.cmd('clipboard.write ' + text);
      if (typeof B !== 'undefined' && B.toast) B.toast('已复制：' + text);
    } catch(e) {}
  }

  /** 内嵌打开 URL（ConnectWeb 容器，非系统浏览器） */
  function _openConnectUrl(url) {
    try { if (typeof B !== 'undefined' && B.openConnectUrl) B.openConnectUrl(url); }
    catch(e) { if (typeof B !== 'undefined' && B.openUrl) B.openUrl(url); }
  }

  function _a2aOpenPayLink(url) {
    if (typeof B !== 'undefined' && B.openUrl) { B.openUrl(url); }
    else { window.open(url, '_blank'); }
  }

  function _a2aWechatScan(noteId) {
    // 1. 保存 pay_qr_base64 到相册（桥方法异步）
    try {
      if (typeof B !== 'undefined' && B.saveImageBase64 && _a2a.confirm && _a2a.confirm.pay_qr_base64) {
        B.saveImageBase64(_a2a.confirm.pay_qr_base64);
        if (typeof B !== 'undefined' && B.toast) B.toast('收款码已存相册 · 请到微信扫一扫选取');
      }
    } catch(e) {}
    // 2. 尝试起微信扫一扫（显式 setPackage，失败降级文案）
    try {
      if (typeof B !== 'undefined' && B.openDeepLink) {
        var r = B.openDeepLink('weixin://scanqrcode', 'com.tencent.mm');
        if (!r || !r.ok) {
          if (typeof B !== 'undefined' && B.toast) B.toast('未安装微信 · 请手动打开微信扫一扫');
        }
        return;
      }
    } catch(e) {}
    if (typeof B !== 'undefined' && B.toast) B.toast('请打开微信 → 扫一扫 → 从相册选取收款码');
  }

  function _a2aIPaid() {
    try {
      if (typeof B !== 'undefined' && B.a2aSend) {
        B.a2aSend(_a2a.peer.deviceId, 'paid_notice', {orderId: _a2a.orderId}, function(r) {
          if (r && r.ok) {
            _a2a.state = 'status';
            var cover = document.getElementById('faceCover');
            cover.appendChild(el('<div class="ctxline"><b>◆</b><span>已通知商家 · 等待出餐</span></div>'));
            renderA2AStatus();
          } else {
            if (typeof B !== 'undefined' && B.toast) B.toast('发送失败 · 请重试');
          }
        });
        return;
      }
    } catch(e) {}
    var cover = document.getElementById('faceCover');
    cover.appendChild(el('<div class="ctxline"><b>◆</b><span>已通知商家 · 等待出餐</span></div>'));
    renderA2AStatus();
  }

  function renderA2AStatus() {
    var cover = document.getElementById('faceCover');
    var poll = [];
    try { if (typeof B !== 'undefined' && B.a2aPoll) poll = B.a2aPoll(_a2a.peer.deviceId); } catch(e) {}
    var status = null;
    for (var i = 0; i < poll.length; i++) {
      if (poll[i].type === 'status') { status = poll[i].payload; break; }
    }
    var state = (status && status.state) || 'making';
    var labels = { making: '制作中…', ready: '可取餐 ✅', delivering: '配送中' };
    var label = labels[state] || state;
    var isReady = state === 'ready';
    var h = '<div class="a2a-card' + (isReady ? ' done' : '') + '"><h3>' + (isReady ? '✅ ' : '') + label + '</h3>'
      + '<div class="a2a-sub">' + escHtml(_a2a.peer.name) + ' · ' + escHtml(label) + '</div>';
    if (isReady) {
      h += '<div class="a2a-compact">请到 ' + escHtml(_a2a.peer.name) + ' 取餐</div>';
      // W1 第二幕：随机抽评卡（确定性抽签 reviewDrawn，抽中才出现；已评过不再出，防纠缠）
      var oid = _a2a.orderId || '';
      var reviewed = false;
      try { reviewed = !!localStorage.getItem('a2a_reviewed_' + oid); } catch(e) {}
      if (oid && !reviewed && NewFaceMatch.reviewDrawn(oid, a2aTodaySalt())) {
        h += '<div class="a2a-card review-card"><h3>吃完了？点个评价</h3>'
          + '<div class="a2a-sub">匿名评价 · 商家看不到你是谁</div>'
          + '<div class="review-stars" id="reviewStars">'
          + '<span data-s="1">★</span><span data-s="2">★</span><span data-s="3">★</span><span data-s="4">★</span><span data-s="5">★</span></div>'
          + '<input id="reviewText" class="review-text" maxlength="140" placeholder="想说点啥（可选，≤140字）">'
          + '<button class="a2a-btn" onclick="NewFace._a2aSubmitReview()">提交评价</button></div>';
      }
    }
    h += '<button class="a2a-btn" onclick="NewFace.resetFace()">完成</button></div>';
    cover.appendChild(el(h));
    // 星标交互（事件委托，免重复绑定）
    var stars = document.getElementById('reviewStars');
    if (stars) stars.onclick = function(e) {
      var t = e.target;
      if (t && t.tagName === 'SPAN' && t.getAttribute('data-s')) {
        var s = parseInt(t.getAttribute('data-s'), 10);
        var spans = stars.querySelectorAll('span');
        for (var i = 0; i < spans.length; i++) spans[i].style.color = (i < s) ? '#ffd700' : '';
        stars.setAttribute('data-picked', String(s));
      }
    };
    scrollCover();
  }

  /** 当日日期盐（抽评抽签用，YYYY-MM-DD） */
  function a2aTodaySalt() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }

  /** 提交评价：relay review 消息 + 本地 journal a2a_review + 标记已评（不可改，防纠缠） */
  function _a2aSubmitReview() {
    var oid = _a2a.orderId || '';
    if (!oid) return;
    var starsEl = document.getElementById('reviewStars');
    var s = starsEl ? parseInt(starsEl.getAttribute('data-picked') || '0', 10) : 0;
    if (s < 1) { try { if (typeof B !== 'undefined' && B.toast) B.toast('先点个星再提交'); } catch(e) {} return; }
    var textEl = document.getElementById('reviewText');
    var text = (textEl ? textEl.value : '').trim().slice(0, 140);
    var ts = Date.now();
    // relay review 消息（验收人需先在 relay 白名单加 review 类，一行）
    try { if (typeof B !== 'undefined' && B.a2aSend) B.a2aSend(_a2a.peer.deviceId, 'review', {order_id: oid, stars: s, text: text, ts: ts}, function(){}); } catch(e) {}
    // 本地 journal 同记 a2a_review
    try {
      if (typeof B !== 'undefined' && B.postCmd) B.postCmd({cmd:'append_event', roomId:'desk', type:'a2a_review', actor:'user', payload:{order_id: oid, stars: s, text: text}});
    } catch(e) {}
    // 不可改：标记已评 + 移除评价卡
    try { localStorage.setItem('a2a_reviewed_' + oid, '1'); } catch(e) {}
    var rc = document.querySelector('#view-face .review-card');
    if (rc) rc.remove();
    try { if (typeof B !== 'undefined' && B.toast) B.toast('评价已发出'); } catch(e) {}
  }

  function _a2aStartPoll() {
    if (_a2a.pollTimer) clearInterval(_a2a.pollTimer);
    _a2a.pollTimer = setInterval(function() {
      if (_a2a.state === 'payment') {
        var cards = document.querySelectorAll('#view-face .a2a-card');
        for (var i = cards.length - 1; i >= 0; i--) cards[i].remove();
        renderA2APayment();
      } else if (_a2a.state === 'status') {
        // status 卡不自动刷新（顶卡常驻）
      } else {
        clearInterval(_a2a.pollTimer);
      }
    }, 3000);
  }

  /** 追剧搜索失败卡 */
  function showDramaFailCard(f) {
    var cover = document.getElementById('faceCover');
    var fc = el('<div class="failcard">'
      + '<div class="ft"><span class="fi"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#c2402b" stroke-width="2.2" stroke-linecap="round"><path d="M12 7v6M12 16.6v.4"/><circle cx="12" cy="12" r="9.2"/></svg></span>没找到相关剧集</div>'
      + '<div class="freason">没搜到相关结果。可能是网络问题，也可能是搜索词需要调整。</div>'
      + '<div class="factions">'
      + '<button class="pri" onclick="NewFace.say(\'我要追剧\')">重试一下</button>'
      + '<button onclick="NewFace.resetFace()">换个说法</button>'
      + '</div></div>');
    cover.appendChild(fc);
    scrollCover();
  }

  /* ── 支付闸 ── */
  var payCb = null, payTimer = null, payProg = 0;
  function openPaySheet(pay, cb) {
    payCb = cb;
    var vf = document.getElementById('view-face');
    // 动态创建支付层
    var mask = document.getElementById('facePaymask');
    var sheet = document.getElementById('facePaysheet');
    if (!mask) { mask = document.createElement('div'); mask.id = 'facePaymask'; mask.className = 'paymask'; mask.onclick = closePaySheet; vf.appendChild(mask); }
    if (!sheet) { sheet = document.createElement('div'); sheet.id = 'facePaysheet'; sheet.className = 'paysheet'; vf.appendChild(sheet); }
    sheet.innerHTML = '<div class="grab"></div><div class="stitle">' + pay.kicker + '</div>'
      + pay.rows.map(function(r) { return '<div class="srow"><span>' + r[0] + '</span><span>' + r[1] + '</span></div>'; }).join('')
      + '<div class="srow big"><span>合计</span><b><i>¥</i>' + pay.total.replace('¥','') + '</b></div>'
      + '<div class="gate-note"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>支付闸 · 由你本人确认，MOV 不经手资金</div>'
      + '<div class="payhold" id="facePayhold"><div class="fillb" id="faceFillb"></div><div class="lb"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 11c1.7 0 3 1.3 3 3 0 2.2-1.3 4-3 4s-3-1.8-3-4c0-1.7 1.3-3 3-3Z"/><path d="M6.5 12.5c0-3 2.5-5.5 5.5-5.5s5.5 2.4 5.5 5.5c0 3.5-2 6.5-4.5 7.5" opacity=".55"/><path d="M9 12.5c0-1.7 1.3-3 3-3" opacity=".55"/></svg>按住确认支付</div></div>';
    mask.classList.add('on'); sheet.classList.add('on');
    // 绑定按住确认
    setTimeout(function() {
      var ph = document.getElementById('facePayhold');
      var fb = document.getElementById('faceFillb');
      if (!ph || !fb) return;
      payProg = 0;
      function start(e) { e.preventDefault(); payProg = 0;
        payTimer = setInterval(function() { payProg += 4; fb.style.width = payProg + '%'; ph.classList.add('holding');
          if (payProg >= 100) { stop(); ph.classList.add('done');
            setTimeout(function() { closePaySheet(); ph.classList.remove('done'); fb.style.width = '0%'; payProg = 0; if (payCb) payCb(); }, 220); }
        }, 24);
      }
      function stop() { clearInterval(payTimer); if (payProg < 100) { payProg = 0; fb.style.width = '0%'; ph.classList.remove('holding'); } }
      ph.addEventListener('pointerdown', start);
      ph.addEventListener('pointerup', stop); ph.addEventListener('pointerleave', stop);
    }, 300);
  }
  function closePaySheet() {
    var mask = document.getElementById('facePaymask');
    var sheet = document.getElementById('facePaysheet');
    if (mask) mask.classList.remove('on');
    if (sheet) sheet.classList.remove('on');
  }

  /* ── 成功页 + 学习时刻 ── */
  function showDone(d) {
    var vf = document.getElementById('view-face');
    var host = document.getElementById('faceDoneHost');
    if (!host) { host = document.createElement('div'); host.id = 'faceDoneHost'; vf.appendChild(host); }
    host.innerHTML = '<div class="done-wrap"><div class="ring"><svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="#3e7d4f" stroke-width="2.6" stroke-linecap="round"><path d="M4 12.5 9.5 18 20 6.5"/></svg></div>'
      + '<h3>' + d.title + '</h3><p>' + d.desc + '</p>'
      + '<div class="ticket">' + d.ticket.map(function(t) { return '<div class="tr"><b>' + t[0] + '</b><span>' + t[1] + '</span></div>'; }).join('') + '</div>'
      + (d.learn ? '<div class="learn" id="faceLearnCard"><div class="lq">' + d.learn.q + '</div><div class="lsub">' + d.learn.sub + '</div><div class="lbtns"><button class="yes" onclick="NewFace.learnAnswer(true)">记住</button><button onclick="NewFace.learnAnswer(false)">不用了</button></div></div>' : '')
      + '<button class="again" onclick="NewFace.resetFace()">再说一句</button></div>';
  }
  function learnAnswer(yes) {
    var c = document.getElementById('faceLearnCard'); if (!c) return;
    c.innerHTML = yes
      ? '<div class="ldone"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#3e7d4f" stroke-width="2.6" stroke-linecap="round"><path d="M4 12.5 9.5 18 20 6.5"/></svg>已记住 · 仅本机 · 随时可让我忘掉</div>'
      : '<div class="ldone no">好，不会记住。这次的选择仅本次有效。</div>';
  }

  /* ── 失败态 ── */
  function startFail(key) {
    currentFlow = key;
    var f = FLOWS[key];
    /* 工单17: 追加式——对话流容器（utter 已由 say 渲染，防重） */
    var cover = ensureStream();
    var hero = document.getElementById('faceHero');
    if (hero) hero.style.display = 'none';
    if (cover && !streamHasUtter()) {
      cover.appendChild(el('<div class="utter"><span>' + f.utter + '</span></div>'));
      scrollCover();
    }
    var mw = document.getElementById('faceMwave'); if (mw) mw.classList.add('thinking');
    var u = el('<div class="understanding"><span class="u-dot"></span><span>理解中…</span></div>');
    cover.appendChild(u); scrollCover();
    setTimeout(function() {
      u.querySelector('span:last-child').innerHTML = slotHTML(f);
      setTimeout(function() {
        if (mw) mw.classList.remove('thinking');
        var fc = el('<div class="failcard"><div class="ft"><span class="fi"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#c2402b" stroke-width="2.2" stroke-linecap="round"><path d="M12 7v6M12 16.6v.4"/><circle cx="12" cy="12" r="9.2"/></svg></span>没查到明天的机票</div><div class="freason">航旅数据服务超时（已自动重试 2 次）。你的网络和账号都正常，是服务方暂时不可用。</div><div class="factions"><button class="pri" onclick="NewFace.failRetry()">重试一下</button><button onclick="NewFace.failAlt(\'train\')">换高铁看看（同天有票）</button><button onclick="NewFace.failAlt(\'later\')">改到后天再查</button></div></div>');
        cover.appendChild(fc); scrollCover();
      }, 1200);
    }, 900);
  }
  function failRetry() {
    var fc = document.querySelector('#view-face .failcard'); if (fc) fc.remove();
    var f = FLOWS[currentFlow]; var cover = document.getElementById('faceCover');
    if (f && f.ctx) cover.appendChild(el('<div class="ctxline"><b>◆</b><span>' + f.ctx + '</span></div>'));
    if (f) renderOptions(f);
  }
  function failAlt(kind) {
    var fc = document.querySelector('#view-face .failcard'); if (fc) fc.remove();
    var cover = document.getElementById('faceCover');
    if (kind === 'train') {
      cover.appendChild(el('<div class="ctxline"><b>◆</b><span>已切换：高铁 · 同天有票</span></div>'));
      var slots = document.querySelectorAll('#view-face .slot');
      if (slots.length > 0) { var s = slots[0]; s.dataset.vi = '1'; s.textContent = '后天'; s.classList.add('bump'); }
      failRetry();
    } else {
      var slots = document.querySelectorAll('#view-face .slot');
      if (slots.length > 0) { var s = slots[0]; s.dataset.vi = '1'; s.textContent = FLOWS[currentFlow].slots[0][1]; s.classList.add('bump'); }
      failRetry();
    }
  }

  /* ── 播放器 ── */
  function openPlayer(o) {
    var vf = document.getElementById('view-face');
    var host = document.getElementById('facePlayerHost');
    if (!host) { host = document.createElement('div'); host.id = 'facePlayerHost'; vf.appendChild(host); }
    host.innerHTML = '<div class="player"><div class="close" onclick="NewFace.closePlayer()">✕</div>'
      + '<div class="screen"><div class="glow" style="background:' + (o.poster ? o.poster[0].match(/#\w+/)[0] : '#4a6fd4') + '"></div>'
      + '<div class="play-btn"><svg width="26" height="26" viewBox="0 0 24 24" fill="#eee"><path d="M8 5v14l11-7z"/></svg></div></div>'
      + '<div class="meta"><h3>' + (o.poster ? o.poster[1] : o.main) + ' · ' + o.main.replace('继续','') + '</h3><p>' + o.sub + ' · 已为你打开（deep link 到达态模拟）</p></div>'
      + '<div class="bar"><i></i></div><div class="times"><span>21:14</span><span>-31:00</span></div></div>';
  }
  function closePlayer() {
    var host = document.getElementById('facePlayerHost');
    if (host) host.innerHTML = '';
  }

  /* ── B站内嵌播放器 ── */
  var _embedFrame = null;
  function openEmbedPlayer(item) {
    closeEmbedPlayer(); // 先销毁旧 iframe
    var vf = document.getElementById('view-face');
    var host = document.getElementById('facePlayerHost');
    if (!host) { host = document.createElement('div'); host.id = 'facePlayerHost'; vf.appendChild(host); }
    _embedFrame = document.createElement('iframe');
    _embedFrame.src = item.url;
    _embedFrame.setAttribute('allow', 'autoplay; fullscreen');
    _embedFrame.setAttribute('allowfullscreen', 'true');
    _embedFrame.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;border:none;z-index:22;background:#0e0f11';
    host.innerHTML = '';
    host.appendChild(_embedFrame);
    // ✕ 关闭按钮
    var closeBtn = document.createElement('div');
    closeBtn.textContent = '✕';
    closeBtn.style.cssText = 'position:absolute;top:52px;right:22px;width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,.1);color:#eee;display:flex;align-items:center;justify-content:center;font-size:14px;cursor:pointer;z-index:23;border:1px solid rgba(255,255,255,.15)';
    closeBtn.onclick = function() { closeEmbedPlayer(); };
    host.appendChild(closeBtn);
    // iframe 加载异常 → 降级 B.openUrl
    _embedFrame.onerror = function() {
      closeEmbedPlayer();
      if (typeof B !== 'undefined' && B.openUrl) B.openUrl(item.url);
    };
    saveWatchProgress(item);
  }

  function closeEmbedPlayer() {
    if (_embedFrame) {
      _embedFrame.src = 'about:blank';
      _embedFrame.parentNode && _embedFrame.parentNode.removeChild(_embedFrame);
      _embedFrame = null;
    }
    var host = document.getElementById('facePlayerHost');
    if (host) host.innerHTML = '';
  }
  function showEmpty() {
    var cover = document.getElementById('faceCover');
    var hero = document.getElementById('faceHero');
    if (hero) hero.style.display = 'none';
    if (cover) cover.innerHTML = '';
    _chatStreamOn = false;   // 工单17: 新会话引导页 = 显式重置对话流
    var d = new Date(), wk = '日一二三四五六'[d.getDay()];
    var html = '<div class="hero"><div class="dateline">' + (d.getMonth()+1) + '月' + d.getDate() + '日 周' + wk + ' · 本地</div>'
      + '<div class="sugg"><div class="slabel"><b>◆</b>开始</div>'
      + '<div class="empty-note">说一句话，服务就到了。<small>订机票、追剧、买东西——意图 → 选项 → 你确认。<br>用得越多，这个封面越懂你。所有记忆只存在这台手机，哪也不去。</small></div>'
      + '<div class="sitem" style="animation-delay:.1s" onclick="NewFace.say(\'帮我查明天去北京的火车票\')"><div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="#5c574e" stroke-width="1.8"><path d="M3.5 13.5 21 6.5l-6.5 13-2.8-5.7-8.2-.3Z"/><path d="M11.7 13.8 21 6.5"/></svg></div><div class="tx"><div class="t1">试着说：帮我查明天去北京的火车票</div><div class="t2">出行 · 真实车次实时查</div></div><span class="go">›</span></div>'
      + '<div class="sitem" style="animation-delay:.22s" onclick="NewFace.say(\'我要追剧\')"><div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="#5c574e" stroke-width="1.8"><rect x="3" y="5" width="18" height="13" rx="2"/><path d="M10 9.5v4l3.5-2z" fill="#5c574e" stroke="none"/></svg></div><div class="tx"><div class="t1">试着说：我要追剧</div><div class="t2">内容 · 直接到播放界面</div></div><span class="go">›</span></div>'
      + '<div class="sitem" style="animation-delay:.34s" onclick="NewFace.say(\'帮我买一箱牛奶\')"><div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="#5c574e" stroke-width="1.8"><path d="M6 8h12l-1.2 12.2a2 2 0 0 1-2 1.8H9.2a2 2 0 0 1-2-1.8L6 8Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/></svg></div><div class="tx"><div class="t1">试着说：帮我买一箱牛奶</div><div class="t2">零售 · 选项到支付两步</div></div><span class="go">›</span></div></div></div>';
    if (cover) cover.innerHTML = html;
  }

  /* ── 抽屉 ── */
  function openDrawer(tab) {
    var mask = document.getElementById('faceDmask');
    var drawer = document.getElementById('faceDrawer');
    var content = document.getElementById('faceDrawerContent');
    if (!mask || !drawer || !content) return;
    mask.classList.add('on');
    drawer.classList.add('on');

    if (tab === 'history') {
      // 优先走 face_history 真数据
      var html = '';
      try {
        if (typeof B !== 'undefined' && B.query) {
          var resp = B.query({q:'face_history'});
          if (resp && resp.ok && resp.data && resp.data.groups) {
            var groups = resp.data.groups;
            for (var g = 0; g < groups.length; g++) {
              html += '<div class="dgroup">' + escHtml(groups[g].label) + '</div>';
              var items = groups[g].items || [];
              for (var i = 0; i < items.length; i++) {
                var item = items[i];
                html += '<div class="ditem" data-hroom="' + escHtml(item.roomId) + '" onclick="NewFace.openRoomFromHistory(\'' + escHtml(item.roomId) + '\',\'' + escHtml(item.text) + '\')">'
                  + escHtml(item.text)
                  + '<div class="meta">' + formatTs(item.ts) + '</div></div>';
              }
            }
          }
        }
      } catch(e) { /* fall through */ }
      // 真数据为空 → MOCK 降级
      if (!html) {
        html = '<div class="dgroup">对话</div>';
        MOCK.historyChats.forEach(function(c){ html += '<div class="ditem">'+escHtml(c.text)+'<div class="meta">'+c.time+'</div></div>'; });
      }
      // 空态
      if (html.indexOf('ditem') < 0) {
        html += '<div class="t12 center">还没有对话记录。<br><span class="t11">说一句话开始吧——追剧、订票、买东西。</span></div>';
      }
      content.innerHTML = html;
      bindHistoryLongPress(content);
    } else if (tab === 'settings') {
      /* 工单14: 设置改为全屏一级页+二级页，抽屉只留历史/我的 */
      openSettings();
    } else {
      // 优先走 face_mine 真数据
      var html = '<div class="dgroup">我的</div>';
      var hasItems = false;
      try {
        if (typeof B !== 'undefined' && B.query) {
          var resp = B.query({q:'face_mine'});
          if (resp && resp.ok && resp.data && resp.data.items) {
            var items = resp.data.items;
            for (var i = 0; i < items.length; i++) {
              var item = items[i];
              html += '<div class="ditem" onclick="NewFace.previewMine(\'' + escHtml(item.roomId) + '\',\'' + escHtml(item.name) + '\')">'
                + item.type.toUpperCase() + ' ' + escHtml(item.name)
                + '<div class="meta">' + formatTs(item.ts) + ' · ' + formatSize(item.size) + '</div></div>';
              hasItems = true;
            }
          }
        }
      } catch(e) {}
      if (!hasItems) {
        html += '<div class="t12 center">还没有交付物。<br><span class="t11">任务完成后，产出会出现在这里。</span></div>';
      }
      content.innerHTML = html;
    }
  }

  function formatTs(ts) {
    if (!ts) return '';
    var d = new Date(ts);
    var now = new Date();
    if (d.toDateString() === now.toDateString()) {
      return '今天 ' + d.getHours().toString().padStart(2,'0') + ':' + d.getMinutes().toString().padStart(2,'0');
    }
    var yesterday = new Date(now - 86400000);
    if (d.toDateString() === yesterday.toDateString()) return '昨天';
    return (d.getMonth()+1) + '月' + d.getDate() + '日';
  }

  function formatSize(bytes) {
    if (!bytes || bytes < 1024) return (bytes||0) + ' B';
    if (bytes < 1048576) return (bytes/1024).toFixed(1) + ' KB';
    return (bytes/1048576).toFixed(1) + ' MB';
  }

  /* 左侧栏历史对话长按删除（用户报障 2026-08-07：历史条目原只有点按回放，无删除入口）。
     长按 500ms（移动>10px 取消，同专家房卡手感）→ 确认 sheet → 走专家同款删房链路：
     room_destroy 拆磁盘房间目录 → face_history 扫描源消失，列表自然不再出现。 */
  var _histLp = false;   // 长按触发后抑制随后的 click 回放
  function bindHistoryLongPress(container) {
    var items = container.querySelectorAll('.ditem[data-hroom]');
    for (var i = 0; i < items.length; i++) {
      (function(node){
        var t = null, sx = 0, sy = 0;
        node.addEventListener('touchstart', function(e){
          var tc = e.touches && e.touches[0]; if (!tc) return;
          sx = tc.clientX; sy = tc.clientY;
          t = setTimeout(function(){
            t = null;
            _histLp = true;
            setTimeout(function(){ _histLp = false; }, 400);
            historyRoomDelete(node.getAttribute('data-hroom'));
          }, 500);
        });
        node.addEventListener('touchmove', function(e){
          var tc = e.touches && e.touches[0]; if (!tc) return;
          var dx = tc.clientX - sx, dy = tc.clientY - sy;
          if (t && dx * dx + dy * dy > 100) { clearTimeout(t); t = null; }
        });
        node.addEventListener('touchend', function(){ if (t) { clearTimeout(t); t = null; } });
      })(items[i]);
    }
  }
  function historyRoomDelete(roomId) {
    if (!roomId) return;
    closeDrawer();   /* 抽屉 z-20 会盖住确认 sheet（真机实证）——先关抽屉再弹确认 */
    expertConfirm(roomId, '删除这条对话？房间与记录一并删除，不可撤销。', function(){
      B.roomDestroy(roomId);
      var room = ROOMS.find(function(r){ return r.id === roomId; });
      if (room) { var idx = ROOMS.indexOf(room); if (idx >= 0) ROOMS.splice(idx, 1); }
      genCounter++;
      if (curRoomId === roomId) { curRoomId = null; try { if (window.HermesBridge) HermesBridge.setRoomOpen(''); } catch(e){} }
      renderRooms(); persistRooms(); renderExpertRooms();
      openDrawer('history');   // 重拉 face_history 真数据，被删条目即时消失
      B.toast('已删除');
    });
  }

  /** 工单19: 历史条目点按 → 进房（非只读回放）。房间不在 ROOMS（localStorage）时兜底补建记录，
   *  长按删除手势（bindHistoryLongPress）不变，分工：点按=进房，长按=删除 */
  function openRoomFromHistory(roomId, text) {
    if (_histLp) return;   // 长按删除后抑制随后的 click 进房
    closeDrawer();
    var r = ROOMS.find(function(x){ return x.id === roomId; });
    if (!r) {
      var name = (text || '任务').length > 12 ? (text || '任务').slice(0, 12) + '…' : (text || '任务');
      r = {id:roomId, name:name, mode:'council',
        members:{human:[{who:'you',role:'owner'}],ai:[]},
        phase:'进行中', last:text || '', time:'', unread:0, played:false, msgs:[]};
      ROOMS.push(r);
      persistRooms(); renderRooms();
    }
    expertOpenRoom(roomId);
  }

  /** 点击历史对话 → 进房（工单19 前为 journal_replay 只读回放，退役） */
  function replayConversation(roomId) {
    if (_histLp) return;   // 长按删除后抑制随后的 click 回放
    openRoomFromHistory(roomId, '');
  }

  /** 连接区卡片: 抖音会话状态 + 一键连接/已连接 */
  /* ── 设置页（工单14: 用户视角重做 — 全屏一级页 + 二级页导航，参考 DeepSeek 形态） ── */

  /* 版本号：桥接口零新增，无查询桥 → JS 常量与 app/build.gradle versionName 同步 */
  var MOV_APP_VERSION = '3.3.0';

  /* 设置页导航栈（全屏页，不再走抽屉；抽屉只留历史/我的） */
  var _setStack = [];
  var _setCur = 'main';
  var _a2aPeerCache = null;   // 设备协作 summary 缓存（a2aPeers 异步）

  function ensureSettingsPane() {
    var face = document.getElementById('view-face');
    if (face && !document.getElementById('settingsPane')) {
      var p = el('<div class="settings-pane" id="settingsPane"></div>');
      face.appendChild(p);
      bindSettingsLongCopy(p);
    }
    return document.getElementById('settingsPane');
  }

  /* 工单25 增补：设置页（含 MCP 市场）长按复制——触屏按住 600ms（scrcpy 镜像=按住鼠标左键）
     整段文字直写系统剪贴板，桌面 Ctrl+V 即取（scrcpy 剪贴板同步）。
     原生 WebView 长按选择在本机不触发（实证），故走自实现；输入框/按钮等交互件不动。 */
  function bindSettingsLongCopy(p) {
    var timer = null, sx = 0, sy = 0, target = null;
    p.addEventListener('touchstart', function(ev) {
      var t = ev.target && ev.target.closest ? ev.target.closest('.set-row,.mcard,.srv,.d-box,.note,.set-sub,.mk-hero,.mk-box,.mk-grow,.mk-rcard') : null;
      if (!t) return;
      if (ev.target.closest('input,textarea,.dact,[data-mk-act],.switch,.adv-head,.mk-buybar')) return;
      var pt = ev.touches[0]; sx = pt.clientX; sy = pt.clientY; target = t;
      timer = setTimeout(function() {
        timer = null;
        var txt = (target.innerText || '').trim();
        if (!txt) return;
        try { B.postCmd({cmd:'clipboard.write', text:txt}); } catch(e) {}
        try { B.toast('已复制：' + (txt.length > 18 ? txt.slice(0, 18) + '…' : txt)); } catch(e) {}
      }, 600);
    }, {passive:true});
    p.addEventListener('touchmove', function(ev) {
      if (!timer) return;
      var pt = ev.touches[0];
      if (Math.abs(pt.clientX - sx) > 10 || Math.abs(pt.clientY - sy) > 10) { clearTimeout(timer); timer = null; }
    }, {passive:true});
    p.addEventListener('touchend', function(){ if (timer) { clearTimeout(timer); timer = null; } }, {passive:true});
    p.addEventListener('touchcancel', function(){ if (timer) { clearTimeout(timer); timer = null; } }, {passive:true});
  }

  function openSettings(pageId) {
    closeDrawer();   /* 齿轮在抽屉底部，开全屏设置页前先收起抽屉 */
    ensureSettingsPane();
    _setStack = [];
    _setCur = pageId || 'main';
    renderSettingsPage(_setCur);
    /* 旧折叠树 key 退役清理（brain/connect/scenes/a2a/caps/privacy/tech/adv） */
    try {
      ['brain','connect','scenes','a2a','caps','privacy','tech','adv'].forEach(function(k){ localStorage.removeItem('mv:set:' + k); });
    } catch(e) {}
    var pane = document.getElementById('settingsPane');
    if (pane) pane.classList.add('on');
    /* 异步 summary（设备协作已配对数） */
    setTimeout(function(){ try { refreshA2aCache(); } catch(e){} }, 60);
  }

  function closeSettings() {
    var pane = document.getElementById('settingsPane');
    if (pane) pane.classList.remove('on');
  }

  function settingsGo(id) {
    _setStack.push(_setCur);
    _setCur = id;
    renderSettingsPage(id);
  }

  function settingsBack() {
    if (_setStack.length) { _setCur = _setStack.pop(); renderSettingsPage(_setCur); }
    else closeSettings();
  }

  function renderSettingsPage(id) {
    var pane = ensureSettingsPane();
    if (!pane) return;
    var html = '';
    if (id === 'main') html = renderSettingsTree();
    else html = renderSubPage(id);
    pane.innerHTML = html;
    /* 二级页异步数据（保险柜/设备协作/系统状态）渲染后填充 */
    if (id !== 'main') setTimeout(function(){ try { afterSubPage(id); } catch(e){} }, 30);
  }

  function afterSubPage(id) {
    if (id === 'vault') loadVaultEntries();
    else if (id === 'device') refreshA2aBlock();
    else if (id === 'system') _renderSysStatus();
    else if (id === 'applyment' && window.MovApplyment) MovApplyment.after();
    else if (id === 'account' && window.MovApplyment) MovApplyment.after();
    else if (id === 'verify' && window.MovApplyment) MovApplyment.after();
    else if (id === 'ability' && window.MovGig) MovGig.after();
    else if (id === 'market' && window.MovMarket && window.MovMarket.bind) window.MovMarket.bind();
  }

  function settingsTopbar(title) {
    return '<div class="set-topbar"><span class="set-back" onclick="NewFace.settingsBack()">‹</span>'
      + '<span class="set-ttl">' + escHtml(title) + '</span></div>';
  }

  /* ── 二级页分发 ── */
  var _SUB_TITLES = {
    account:'账户管理', market:'MCP 市场', merchant:'商户收款', verify:'身份认证', ability:'我的能力',
    theme:'外观', model:'AI 模型', vault:'信息管理', feedback:'更新反馈', adv:'高级',
    understand:'理解方式', device:'设备协作', scene:'快捷场景', perm:'权限与功能',
    service:'服务连接', system:'系统', applyment:'特约商户进件'
  };
  function renderSubPage(id) {
    var title = _SUB_TITLES[id] || '设置';
    var body = '';
    if (id === 'merchant') body = renderMerchantPage();
    else if (id === 'market') body = (window.MovMarket && window.MovMarket.render) ? window.MovMarket.render() : '<div class="note">市场模块未加载</div>';
    else if (id === 'theme') body = renderThemePage();
    else if (id === 'model') body = renderModelPage();
    else if (id === 'vault') body = renderVaultPage();
    else if (id === 'feedback') body = renderFeedbackPage();
    else if (id === 'adv') body = renderAdvPage();
    else if (id === 'understand') body = renderUnderstandPage();
    else if (id === 'device') body = renderDevicePage();
    else if (id === 'scene') body = renderScenePage();
    else if (id === 'perm') body = renderPermPage();
    else if (id === 'service') body = renderServicePage();
    else if (id === 'system') body = renderSystemPage();
    else if (id === 'applyment') body = window.MovApplyment ? MovApplyment.renderForm() : '';
    else if (id === 'account') body = window.MovApplyment ? MovApplyment.renderAccount() : '';
    else if (id === 'verify') body = window.MovApplyment ? MovApplyment.renderVerify() : '';
    else if (id === 'ability') body = (window.MovGig && window.MovGig.renderAbility) ? window.MovGig.renderAbility() : '<div class="note">我的能力模块未加载</div>';
    return settingsTopbar(title) + '<div class="set-page">' + body + '</div>';
  }

  /* 商户收款二级页（工单26 M0-1）：四证 + AppID + 卖家签名私钥 → SecureVault，prefs 只存 vault id + appid 明文 */
  function renderMerchantPage() {
    return '<div class="set-group">'
      + '<div class="set-sub" style="padding-top:12px">商户四证（微信支付直连）</div>'
      + '<input id="mkMchid" placeholder="商户号 mchid">'
      + '<input id="mkAppid" placeholder="公众号/应用 AppID（非机密，明文存）">'
      + '<input id="mkSerial" placeholder="API 证书序列号">'
      + '<input id="mkApiv3" type="password" placeholder="APIv3 密钥">'
      + '<textarea id="mkPem" rows="5" placeholder="API 证书私钥 pem（整段粘贴）" style="width:100%;border:1px solid rgba(0,0,0,.1);border-radius:8px;padding:8px;font-size:11px;font-family:monospace;box-sizing:border-box"></textarea>'
      + '<div class="set-sub" style="padding-top:12px">卖家发货签名（可选，卖家身份发货用）</div>'
      + '<textarea id="mkSellerPem" rows="4" placeholder="卖家 RSA 私钥 pem（整段粘贴）" style="width:100%;border:1px solid rgba(0,0,0,.1);border-radius:8px;padding:8px;font-size:11px;font-family:monospace;box-sizing:border-box"></textarea>'
      + '<div class="note">私钥只进本机保险柜（SecureVault 加密存储），不落 journal / 日志 / 明文存储。</div>'
      + '<div class="mk-buybar" style="margin-top:10px"><span class="dact" onclick="NewFace.merchantSave()">保存到保险柜</span></div>'
      + '</div>';
  }

  /* 保存四证 + AppID + 卖家私钥（cbId 异步桥 mktSaveMerchant） */
  function merchantSave() {
    var mchid = v('mkMchid'), appid = v('mkAppid'), serial = v('mkSerial'), apiv3 = v('mkApiv3'),
        pem = v('mkPem'), sellerPem = v('mkSellerPem');
    if (!mchid || !appid || !serial || !apiv3 || !pem) { B.toast('请填全商户四证 + AppID'); return; }
    if (!window.HermesBridge || !window.HermesBridge.mktSaveMerchant) { B.toast('市场桥未就绪'); return; }
    var id = (typeof nextCbId === 'function') ? nextCbId() : ('cb' + Date.now());
    if (typeof _cbMap !== 'undefined') _cbMap[id] = function(r) {
      if (r && r.ok) { B.toast('已存入保险柜'); emptyMerchantInputs(); }
      else B.toast((r && r.error && r.error.msg) ? ('保存失败：' + r.error.msg) : '保存失败');
    };
    window.HermesBridge.mktSaveMerchant(JSON.stringify({
      mchid: mchid, appid: appid, serial: serial, apiv3Key: apiv3, pem: pem, sellerPem: sellerPem
    }), id);
  }
  function v(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; }
  function emptyMerchantInputs() {
    ['mkMchid','mkAppid','mkSerial','mkApiv3','mkPem','mkSellerPem'].forEach(function(id) {
      var el = document.getElementById(id); if (el) el.value = '';
    });
  }

  /* 高级二级页（工单25：原一级页折叠组改二级页，六行入口不变） */
  function renderAdvPage() {
    return '<div class="set-group">'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'understand\')"><div class="t">理解方式</div><div class="v">' + escHtml(understandSummary()) + '</div><div class="chev">›</div></div>'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'device\')"><div class="t">设备协作</div><div class="v">' + escHtml(deviceSummary()) + '</div><div class="chev">›</div></div>'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'scene\')"><div class="t">快捷场景</div><div class="v">' + escHtml(sceneSummary()) + '</div><div class="chev">›</div></div>'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'perm\')"><div class="t">权限与功能</div><div class="v perm-warn">' + escHtml(permSummary()) + '</div><div class="chev">›</div></div>'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'service\')"><div class="t">服务连接</div><div class="v">' + escHtml(serviceSummary()) + '</div><div class="chev">›</div></div>'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'system\')"><div class="t">系统</div><div class="chev">›</div></div>'
      + '</div>';
  }

  /* 外观二级页：浅色/深色/跟随系统 打勾单选（mov_theme: light/dark/auto） */
  function renderThemePage() {
    var cur = getThemeMode();
    var opts = [['light','浅色'],['dark','深色'],['auto','跟随系统']];
    var out = '<div class="set-group">';
    opts.forEach(function(o) {
      out += '<div class="set-row" onclick="NewFace.setThemeMode(\'' + o[0] + '\')"><div class="t">' + o[1] + '</div>'
        + '<div class="check' + (cur === o[0] ? '' : ' ghost') + '">✓</div></div>';
    });
    out += '</div>';
    return out;
  }

  /* 更新反馈二级页（工单25：检查更新行 + 原意见反馈表单合并） */
  function renderFeedbackPage() {
    return '<div class="set-group">'
      + '<div class="set-row" onclick="NewFace.checkUpdate()"><div class="t">检查更新</div><div class="v">v' + escHtml(MOV_APP_VERSION) + '</div><div class="chev">›</div></div>'
      + '</div>'
      + '<div class="set-group fb-group"><textarea id="fbText" placeholder="说说哪里不好用…"></textarea></div>'
      + '<div class="set-group">'
      + '<div class="set-row static"><div class="t">附带诊断日志</div>'
      + '<div class="switch on" id="fbDiag" onclick="NewFace._fbToggleDiag()"></div></div>'
      + '</div>'
      + '<div class="note">日志只含运行状态，不含对话内容和密钥。</div>'
      + '<div class="set-group"><div class="add-model" onclick="NewFace._fbSubmit()">提交</div></div>';
  }
  function _fbToggleDiag() {
    var sw = document.getElementById('fbDiag');
    if (sw) sw.classList.toggle('on');
  }
  function _fbSubmit() {
    var t = document.getElementById('fbText');
    var txt = (t && t.value) ? t.value.trim() : '';
    if (!txt) { B.toast('先写点反馈内容'); return; }
    var sw = document.getElementById('fbDiag');
    if (sw && sw.classList.contains('on')) {
      try { B.postCmd({cmd:'diagnostics.export'}); } catch(e) {}
    }
    B.toast('已提交，感谢反馈');
    redrawSettings();
  }

  /* 理解方式二级页：更准/更快 单选，各带代价说明（原意图路由，localStorage mv:routing 兼容） */
  function renderUnderstandPage() {
    var cur = getRoutingMode();
    var opts = [
      ['llm','更准','先让 AI 理解你的意思再行动，复杂任务更可靠，用量略高'],
      ['regex','更快','常用指令直接执行，响应快、省用量']
    ];
    var out = '<div class="set-group">';
    opts.forEach(function(o) {
      out += '<div class="set-row" onclick="NewFace.setRoutingMode(\'' + o[0] + '\')"><div class="t-col"><div class="t">' + o[1] + '</div>'
        + '<div class="sub">' + o[2] + '</div></div>'
        + '<div class="check' + (cur === o[0] ? '' : ' ghost') + '">✓</div></div>';
    });
    out += '</div>';
    return out;
  }

  /* 检查更新：读 MOV_APP_VERSION 展示（无网络更新逻辑，桥零新增） */
  function checkUpdate() {
    B.toast('当前已是最新版本 v' + MOV_APP_VERSION);
  }

  /** 一级页（工单25 定稿）：账户管理 → MCP 市场 → AI 模型 → 信息管理 → 高级 › → 外观 → 更新反馈 */
  function renderSettingsTree() {
    var html = settingsTopbar('设置');
    html += '<div class="set-page">';
    html += '<div class="set-group" style="margin-top:6px">'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'account\')"><div class="t">账户管理</div><div class="v">本地用户</div><div class="chev">›</div></div>'
      + '</div>';
    html += '<div class="set-group">'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'market\')"><div class="t">MCP 市场</div><div class="chev">›</div></div>'
      + '</div>';
    html += '<div class="set-group">'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'model\')"><div class="t">AI 模型</div><div class="v">' + escHtml(modelSummary()) + '</div><div class="chev">›</div></div>'
      + '</div>';
    html += '<div class="set-group">'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'account\')"><div class="t">账户管理</div><div class="v">身份认证 · 我的能力</div><div class="chev">›</div></div>'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'vault\')"><div class="t">信息管理</div><div class="chev">›</div></div>'
      + '</div>';
    html += '<div class="set-group">'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'adv\')"><div class="t">高级</div><div class="chev">›</div></div>'
      + '</div>';
    html += '<div class="set-group">'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'theme\')"><div class="t">外观</div><div class="v">' + escHtml(themeSummary()) + '</div><div class="chev">›</div></div>'
      + '</div>';
    html += '<div class="set-group">'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'feedback\')"><div class="t">更新反馈</div><div class="chev">›</div></div>'
      + '</div>';
    html += '</div>';
    return html;
  }

  /* ── 一级页 summary 值（状态收进二级页，一级只露名称/简短值） ── */

  function themeSummary() {
    var m = getThemeMode();
    return m === 'dark' ? '深色' : (m === 'auto' ? '跟随系统' : '浅色');
  }

  function modelSummary() {
    try {
      var models = (typeof B !== 'undefined' && B.listModels) ? B.listModels() : [];
      for (var i = 0; i < models.length; i++) if (models[i].isDefault) return (models[i].name || '模型');
      return models.length ? (models[0].name || '模型') : '未配置';
    } catch(e) { return '未配置'; }
  }

  function understandSummary() {
    return getRoutingMode() === 'regex' ? '更快' : '更准';
  }

  function deviceSummary() {
    if (_a2aPeerCache && _a2aPeerCache.length) return _a2aPeerCache.length + ' 台已配对';
    return '未连接';
  }

  function sceneSummary() {
    var n = 0;
    try {
      var resp = (typeof B !== 'undefined' && B.query) ? B.query({q:'tool_manifest'}) : null;
      var tools = (resp && resp.ok && resp.data && resp.data.tools) ? resp.data.tools : [];
      for (var i = 0; i < tools.length; i++) if (tools[i].level === 'FAST') n++;
    } catch(e) {}
    return n ? n + ' 个可用' : '暂无';
  }

  function permSummary() {
    var n = 0;
    try {
      var perms = (typeof B !== 'undefined' && B.permState) ? B.permState() : {};
      var names = {CAMERA:1, LOCATION:1, CONTACTS:1, SMS:1, CALL:1, NOTIFY:1, SETTINGS:1};
      for (var k in perms) { if (names[k] && !perms[k]) n++; }
    } catch(e) {}
    return n ? n + ' 项待开启' : '已全部开启';
  }

  function serviceSummary() {
    var on = [];
    try {
      var resp = (typeof B !== 'undefined' && B.query) ? B.query({q:'web_sites'}) : null;
      var sites = (resp && resp.ok && resp.data && resp.data.sites) ? resp.data.sites : [];
      sites.forEach(function(s) {
        if (!(s.auth && s.auth.loginUrl)) return;
        var id = s.site.replace('.com','');
        try { if ((typeof B !== 'undefined' && B.connectStatus) && B.connectStatus(id).connected) on.push(s.name || id); } catch(e) {}
      });
    } catch(e) {}
    return on.length ? on.join(' · ') : '未登录';
  }

  function refreshA2aCache() {
    try {
      if (typeof B !== 'undefined' && B.a2aPeers) {
        B.a2aPeers(function(peers) {
          _a2aPeerCache = (peers && peers.length) ? peers : [];
          if (_setCur === 'main') renderSettingsPage('main');
        });
      }
    } catch(e) {}
  }

  /* ── AI 模型二级页（工单14：模型卡 + 添加 + 本月用量条 + 本地模型底部） ── */
  var _mState = {opsId:null, formOpen:false, editId:null, presets:[], provider:'deepseek', fields:{key:'',base:'',model:'',name:''}};
  function _mfv(id){ var e = document.getElementById(id); return e ? e.value.trim() : ''; }

  function renderModelPage() {
    var out = '';
    /* 模型卡列表（测连接/编辑/设为默认/删除，删除过确认 sheet） */
    try {
      var models = (typeof B !== 'undefined' && B.listModels) ? B.listModels() : [];
      models.forEach(function(m){
        var defTag = m.isDefault ? '<span class="deftag"> · 默认</span>' : '';
        out += '<div class="model-card">'
          + '<div class="mname">' + escHtml(m.name || _pvName(m.provider)) + defTag + '</div>'
          + '<div class="msub">' + escHtml(modelStatusText(m)) + '</div>'
          + '<div class="macts">'
          + '<div class="btn" onclick="NewFace._mtest(\'' + escHtml(m.id) + '\')">测连接</div>'
          + '<div class="btn" onclick="NewFace._medit(\'' + escHtml(m.id) + '\')">编辑</div>'
          + (m.isDefault ? '' : '<div class="btn" onclick="NewFace._msetDefault(\'' + escHtml(m.id) + '\')">设为默认</div>')
          + '<div class="btn" onclick="NewFace._mdelete(\'' + escHtml(m.id) + '\')">删除</div>'
          + '</div></div>';
      });
      if (!models.length) {
        out += '<div class="model-card"><div class="mname">未配置模型</div>'
          + '<div class="msub">先添加一个模型才能开始派活</div></div>';
      }
      out += '<div class="set-group"><div class="add-model" onclick="NewFace._mform()">＋ 添加模型</div></div>';
      if (_mState.formOpen) out += _mformHtml();
    } catch(e) {}
    /* 本月用量约 N%（原 TOKEN 仪表盘收进此处，超 80% 才上浮一级警告） */
    try {
      var ts = (typeof B !== 'undefined' && B.tokenStats) ? B.tokenStats() : {today:0,month:0,quota:0};
      var pct = (ts.quota > 0) ? Math.min(100, Math.round((ts.month || 0) / ts.quota * 100)) : 0;
      out += '<div class="set-group"><div class="usage">本月用量约 ' + pct + '%'
        + '<div class="dsub">今日 ' + NewFaceExpert.tokFmt(ts.today) + ' · 本月 ' + NewFaceExpert.tokFmt(ts.month) + ' / ' + NewFaceExpert.tokFmt(ts.quota) + '</div>'
        + '</div><div class="ubar"><i style="width:' + pct + '%"></i></div></div>';
    } catch(e) {}
    /* 本地模型（OCR，施工决策：放 AI 模型页底部，用户按「模型」找得到） */
    try {
      var lm = (typeof B !== 'undefined' && B.listLocalModels) ? B.listLocalModels() : {ok:true,models:[]};
      var lmodels = (lm && lm.models) ? lm.models : [];
      if (lmodels.length) {
        lmodels.forEach(function(m) {
          out += '<div class="set-group"><div class="set-row" onclick="NewFace.deleteLocalModel(\'' + escHtml(m.name) + '\')"><div class="t">OCR 模型</div>'
            + '<div class="v">' + escHtml(m.name) + ' · ' + (m.sizeMB || 0) + ' MB · 点按删除</div><div class="chev">›</div></div></div>';
        });
      } else {
        out += '<div class="set-group"><div class="set-row static"><div class="t">OCR 模型</div>'
          + '<div class="v">未下载 · 约 2GB（识别图片/文档文字）</div></div></div>';
      }
    } catch(e) {}
    out += '<div class="note">API Key 只存本机，支持 DeepSeek / Kimi / 通义 / OpenAI 兼容接口。</div>';
    return out;
  }

  /* 添加/编辑表单 (二级页内联) */
  function _mformHtml() {
    var opts = '';
    _mState.presets.forEach(function(p){ opts += '<option value="' + escHtml(p.key) + '"' + (p.key === _mState.provider ? ' selected' : '') + '>' + escHtml(p.displayName) + '</option>'; });
    if (!opts) opts = '<option value="">无预设</option>';
    return '<div class="mform">'
      + '<div class="mform-label">厂商</div><select id="mfProvider" onchange="NewFace._mfProvider(this.value)">' + opts + '</select>'
      + '<div class="mform-label">API Key</div><input id="mfKey" placeholder="sk-..." value="' + escHtml(_mState.fields.key) + '">'
      + '<div class="mform-label">Base URL</div><input id="mfBase" placeholder="https://..." value="' + escHtml(_mState.fields.base) + '">'
      + '<div class="mform-label">模型名</div><input id="mfModel" placeholder="gpt-4o" value="' + escHtml(_mState.fields.model) + '">'
      + '<div class="mform-label">显示名</div><input id="mfName" placeholder="我的模型" value="' + escHtml(_mState.fields.name) + '">'
      + '<div class="mform-acts">'
      + '<div class="ditem pulse" onclick="NewFace._msave()">保存</div>'
      + '<div class="ditem" onclick="NewFace._mtestForm()">测连接</div>'
      + '<div class="ditem" onclick="NewFace._mformCancel()">取消</div></div></div>';
  }
  function _mops(id) { _mState.opsId = (id === _mState.opsId) ? null : id; _mState.formOpen = false; redrawSettings(); }
  function _mopsClose() { _mState.opsId = null; redrawSettings(); }
  function _msetDefault(id) { try { if (B.setDefaultModel) B.setDefaultModel(id); B.toast('已设为默认'); } catch(e){} _mState.opsId = null; redrawSettings(); }
  function _mtest(id) {
    try {
      var m = B.listModels().find(function(x){ return x.id === id; });
      if (!m) return;
      B.toast('测连接中…');
      B.aiChatWithModel('只回复两个字: 收到', id, function(res){ B.toast(res && res.ok ? '连接正常' : '连接失败'); });
    } catch(e){}
  }
  function _medit(id) {
    try {
      var m = B.listModels().find(function(x){ return x.id === id; });
      if (!m) return;
      _mState.editId = id; _mState.formOpen = true; _mState.opsId = null;
      _mState.provider = m.provider || 'deepseek';
      _mState.fields = {key:'', base:m.baseUrl || '', model:m.model || '', name:m.name || ''};
      redrawSettings();
    } catch(e){}
  }
  function _mdelete(id) {
    /* 删除模型 = 破坏性操作，过确认 sheet（红线） */
    try {
      var m = B.listModels().find(function(x){ return x.id === id; });
      var label = m ? (m.name || '该模型') : '该模型';
      expertConfirm(null, '删除模型「' + esc(label) + '」？删除后不可恢复。', function(){
        try { if (B.deleteModel) B.deleteModel(id); B.toast('已删除'); } catch(e){ B.toast('删除失败（最后一个不能删）'); }
        _mState.opsId = null; redrawSettings();
      });
    } catch(e){}
  }
  function _mform() {
    if (_mState.presets.length === 0) try { _mState.presets = B.providerPresets() || []; } catch(e){}
    _mState.formOpen = !_mState.formOpen; _mState.opsId = null; _mState.editId = null;
    if (_mState.formOpen) _mState.fields = {key:'', base:'', model:'', name:''};
    redrawSettings();
  }
  function _mfProvider(p) {
    _mState.fields = {key:_mfv('mfKey'), base:_mfv('mfBase'), model:_mfv('mfModel'), name:_mfv('mfName')};
    _mState.provider = p || 'deepseek';
    redrawSettings();
  }
  function _mformCancel() { _mState.formOpen = false; _mState.editId = null; redrawSettings(); }
  function _collectMForm() {
    var pres = null;
    _mState.presets.forEach(function(p){ if (p.key === _mState.provider) pres = p; });
    return {
      provider: _mState.provider,
      apiKey: _mfv('mfKey'),
      baseUrl: _mfv('mfBase'),
      model: _mfv('mfModel'),
      name: _mfv('mfName') || (pres ? pres.displayName : _mState.provider),
      role: '通用',
      color: _pvColor(_mState.provider),
      enabled: true,
      isDefault: false
    };
  }
  function _msave() {
    try {
      var o = _collectMForm();
      /* 工单13: 新建模型必须填 key(与测连接同校验); 编辑时 key 留空=不改(服务端 mergeOnUpdate 保留) */
      if (!_mState.editId && _mState.provider !== 'ollama' && !o.apiKey) { B.toast('先填 API Key'); return; }
      if (_mState.editId) o.id = _mState.editId;
      var res = _mState.editId ? B.updateModel(o) : B.addModel(o);
      if (res && res.ok) { B.toast('已保存'); _mState.formOpen = false; _mState.editId = null; redrawSettings(); }
      else B.toast((res && res.error) || '保存失败');
    } catch(e){ B.toast('保存失败'); }
  }
  function _mtestForm() {
    try {
      var o = _collectMForm();
      if (_mState.provider !== 'ollama' && !o.apiKey) { B.toast('先填 API Key'); return; }
      B.toast('测连接中…');
      B.testModel(o, function(res){ B.toast(res && res.ok ? '连接正常' : '连接失败' + (res && res.error ? ': ' + res.error : '')); });
    } catch(e){}
  }
  function redrawSettings() { renderSettingsPage(_setCur); }

  /** 删除本地模型文件（AI 模型二级页点按） */
  function deleteLocalModel(name) {
    try { if (typeof B !== 'undefined' && B.deleteLocalModel) B.deleteLocalModel(name); } catch(e) {}
    redrawSettings();
  }

  function getRoutingMode() {
    try { return localStorage.getItem('mv:routing') === 'regex' ? 'regex' : 'llm'; } catch(e) { return 'llm'; }
  }
  /** 理解方式：更准 = llm 优先，更快 = 仅快速通道（原意图路由，文案重做） */
  function setRoutingMode(mode) {
    try { localStorage.setItem('mv:routing', mode === 'regex' ? 'regex' : 'llm'); } catch(e) {}
    redrawSettings();
  }

  /* ── 服务连接二级页（工单14：点名服务行，原「连接」区块收此） ── */

  /** 从 web_sites 注册表读可连接站点（有 auth 配置的），兜底 douyin/tencent */
  function connectPlatforms() {
    var platforms = [];
    try {
      var resp = (typeof B !== 'undefined' && B.query) ? B.query({q:'web_sites'}) : null;
      var sites = (resp && resp.ok && resp.data && resp.data.sites) ? resp.data.sites : [];
      sites.forEach(function(s) {
        if (s.auth && s.auth.loginUrl) platforms.push({id: s.site.replace('.com',''), label: s.name||s.site, sub: '登录一次 · 会话只存本机'});
      });
    } catch(e) {}
    if (!platforms.length) platforms = [
      {id:'douyin', label:'抖音', sub:'搜剧看片免登录 · 会话只存本机'},
      {id:'tencent', label:'腾讯视频', sub:'H5搜索免登录 · 直接看片'}
    ];
    return platforms;
  }

  function renderServicePage() {
    var out = '<div class="set-group">';
    connectPlatforms().forEach(function(p) {
      var connected = false;
      try { if (typeof B !== 'undefined' && B.connectStatus) connected = !!B.connectStatus(p.id).connected; } catch(e) {}
      out += '<div class="set-row" onclick="NewFace.openConnect(\'' + escHtml(p.id) + '\')"><div class="t">' + escHtml(p.label) + '</div>'
        + '<div class="v">' + (connected ? '已连接' : '未登录') + '</div><div class="chev">›</div></div>';
      if (connected) {
        out += '<div class="set-sub"><span class="dact" onclick="NewFace.clearConnect(\'' + escHtml(p.id) + '\')">清除登态</span>'
          + '<span class="dact" onclick="NewFace.openConnect(\'' + escHtml(p.id) + '\')">去使用</span></div>';
      }
    });
    out += '</div>';
    out += '<div class="note">登录态保存在本机，用于订票、点外卖等真实下单场景。</div>';
    return out;
  }

  /** 清除平台登态（CookieManager 关键键过期）并刷新设置页 */
  function clearConnect(platform) {
    try { if (typeof B !== 'undefined' && B.removeCookies) B.removeCookies(platform); } catch(e) {}
    redrawSettings();
  }

  /* ── 快捷场景二级页（工单14：FAST 卡清单 + 视频源收编底部） ── */

  function renderScenePage() {
    var out = '<div class="set-group">';
    try {
      var resp = (typeof B !== 'undefined' && B.query) ? B.query({q:'tool_manifest'}) : null;
      var tools = (resp && resp.ok && resp.data && resp.data.tools) ? resp.data.tools : [];
      var any = false;
      for (var i = 0; i < tools.length; i++) {
        if (tools[i].level !== 'FAST') continue;
        any = true;
        var t = tools[i];
        var ex = (t.examples && t.examples.length) ? '例: ' + t.examples[0] : '';
        out += '<div class="set-row static"><div class="t">' + escHtml(t.name) + '</div>'
          + '<div class="v">' + escHtml(t.toolset) + '</div></div>'
          + (ex ? '<div class="set-sub">' + escHtml(ex) + '</div>' : '');
      }
      if (!any) out += '<div class="set-row static"><div class="t">暂无可用场景</div>'
        + '<div class="v">先运行一次任务，注册表加载后自动出现</div></div>';
    } catch(e) {}
    out += '</div>';
    out += '<div class="note">快捷场景是一句话直达的服务入口，在首页直接说出需求即可触发，无需在此配置。</div>';
    /* 视频源开关（施工决策：原场景卡区块内容，收编本页底部，不丢功能） */
    out += renderSourcesSection();
    return out;
  }

  /* ── 设备协作二级页（工单14：配对码/已配对设备/Relay；原 A2A 区块收此） ── */

  function renderDevicePage() {
    var out = '<div class="set-group">';
    /* 状态 + 连接另一台设备（配对码） */
    out += '<div class="set-row static"><div class="t">状态</div><div class="v">' + escHtml(deviceSummary()) + '</div></div>';
    out += '<div class="set-row" onclick="NewFace.genA2aPairCode()"><div class="t">连接另一台设备</div>'
      + '<div class="v" id="a2aMyCode">生成配对码</div><div class="chev">›</div></div>';
    /* 输入配对码（自对话流 renderA2APeerList 收编） */
    out += '<div class="set-sub"><input id="a2aPairInput" class="sheet-input flex lg" placeholder="6 位配对码" maxlength="6">'
      + '<button class="a2a-btn small" onclick="NewFace._a2aPair()">连接</button></div>';
    /* 已配对设备列表（异步） */
    out += '<div class="set-sub"><div class="set-mini-label">已配对设备</div>'
      + '<div id="a2aPeerList" class="dsub meta pad6">加载中…</div></div>';
    /* relay 服务器地址编辑 */
    out += '<div class="set-sub"><div class="set-mini-label">Relay 服务器</div>'
      + '<div class="f-gap"><input id="a2aRelayInput" class="sheet-input flex" placeholder="https://mow.kim">'
      + '<button class="a2a-btn small" onclick="NewFace.saveA2aRelay()">保存</button></div></div>';
    out += '</div>';
    out += '<div class="note">连接后两台设备可在同一个房间里协作，任务可互相转交。</div>';
    /* 异步填充：设备列表 + relay 当前值（渲染后 DOM 就绪） */
    setTimeout(function() { refreshA2aBlock(); }, 50);
    return out;
  }

  /** 生成我的配对码（a2aPairRequest 异步回调写入） */
  function genA2aPairCode() {
    try {
      if (typeof B !== 'undefined' && B.a2aPairRequest) {
        B.a2aPairRequest(function(r) {
          var el = document.getElementById('a2aMyCode');
          if (el && r && r.pairCode) el.innerHTML = '配对码: <b class="pair-code">' + escHtml(r.pairCode) + '</b>（5 分钟内有效）';
          else if (el) el.innerHTML = '生成失败，请重试';
        });
      }
    } catch(e) {}
  }

  /** 异步填充已配对设备列表 + relay 当前值 */
  function refreshA2aBlock() {
    try {
      if (typeof B !== 'undefined' && B.a2aPeers) {
        B.a2aPeers(function(peers) {
          _a2aPeerCache = (peers && peers.length) ? peers : [];
          var box = document.getElementById('a2aPeerList');
          if (!box) return;
          if (peers && peers.length) {
            var h = '';
            peers.forEach(function(p) {
              h += '<div class="peer-item">· ' + escHtml(p.name)
                + ' <span class="peer-id">' + escHtml(p.deviceId) + '</span></div>';
            });
            box.innerHTML = h;
          } else {
            box.innerHTML = '暂无已配对设备';
          }
        });
      }
    } catch(e) {}
    try {
      if (typeof B !== 'undefined' && B.a2aGetRelay) {
        var url = B.a2aGetRelay();
        var inp = document.getElementById('a2aRelayInput');
        if (inp && url) inp.value = url;
      }
    } catch(e) {}
  }

  /** 保存 relay 地址（A2aClient 校验 http/https）并刷新 */
  function saveA2aRelay() {
    var inp = document.getElementById('a2aRelayInput');
    var url = (inp && inp.value) ? inp.value.trim() : '';
    try { if (typeof B !== 'undefined' && B.a2aSetRelay) B.a2aSetRelay(url); } catch(e) {}
    redrawSettings();
  }

  /* ── 权限与功能二级页（工单14：待开启组带用途 + 已开启组 + 健康行 + 工具组） ── */

  function renderPermPage() {
    var out = '';
    try {
      /* 权限分组：待开启（未授权，带用途文案）+ 已开启 */
      var perms = (typeof B !== 'undefined' && B.permState) ? B.permState() : {};
      var names = {
        NOTIFY:['通知','任务完成提醒'], CAMERA:['相机','拍照识别'], LOCATION:['位置','出行提醒'],
        CONTACTS:['通讯录','联系人协作'], SMS:['短信','验证码读取'], CALL:['电话','通话服务'],
        SETTINGS:['写系统设置','深色模式等系统功能']
      };
      var pending = [], granted = [];
      var keys = Object.keys(perms);
      keys.forEach(function(k) {
        if (!names[k]) return;
        if (perms[k]) granted.push(k); else pending.push(k);
      });
      if (!keys.length) {
        out += '<div class="dsub meta pad4">权限状态不可用（桥查询失败）</div>';
      } else {
        if (pending.length) {
          out += '<div class="set-mini-label">待开启 · 开启后对应功能才可用</div><div class="set-group">';
          pending.forEach(function(k) {
            out += '<div class="set-row" onclick="NewFace.openNativePerm()"><div class="t">' + names[k][0] + '</div>'
              + '<div class="v">' + names[k][1] + '</div><div class="chev">›</div></div>';
          });
          out += '</div>';
        }
        if (granted.length) {
          out += '<div class="set-mini-label">已开启</div><div class="set-group">';
          granted.forEach(function(k) {
            out += '<div class="set-row static"><div class="t">' + names[k][0] + '</div>'
              + '<div class="v ok">已开启</div></div>';
          });
          out += '</div>';
        }
        out += '<div class="dact perm-dact" onclick="NewFace.openNativePerm()">打开系统权限设置</div>';
      }
      /* H2 健康行 — 照 {id, category, status(ok/warn/down), reason} 渲染每源一行, 点按重测 */
      try {
        var h = (typeof B !== 'undefined' && B.query) ? B.query({q:'health'}) : null;
        var items = (h && h.ok && h.data && h.data.items) ? h.data.items : [];
        if (items.length) {
          out += '<div class="set-mini-label">功能健康</div><div class="set-group">';
          items.forEach(function(it) {
            var st = it.status || 'ok';
            var color = st === 'ok' ? 'var(--ok)' : (st === 'down' ? '#c2402b' : '#c08552');
            var label = {ok:'正常', warn:'异常', down:'故障'}[st] || st;
            var reason = it.detail || it.reason || '';
            out += '<div class="set-row" onclick="NewFace._healthRetest(\'' + escHtml(it.id) + '\')"><div class="t">' + escHtml(it.id) + '</div>'
              + '<div class="v" style="color:' + color + '">' + label
              + (st !== 'ok' && reason ? ' · ' + escHtml(reason) : '') + '</div>'
              + (st !== 'ok' ? '<div class="chev">重测</div>' : '') + '</div>';
          });
          out += '</div>';
        }
      } catch(e){}
      /* 工具组（tool_manifest 分组投影，保持能力区块健康行收此） */
      var resp = (typeof B !== 'undefined' && B.query) ? B.query({q:'tool_manifest'}) : null;
      var tools = (resp && resp.ok && resp.data && resp.data.tools) ? resp.data.tools : [];
      var groups = {};
      for (var i = 0; i < tools.length; i++) {
        var t = tools[i];
        var g = t.toolset || 'other';
        if (!groups[g]) groups[g] = [];
        groups[g].push(t);
      }
      var gkeys = Object.keys(groups);
      if (gkeys.length) {
        out += '<div class="set-mini-label">已开启功能（工具）</div><div class="set-group">';
        gkeys.forEach(function(g) {
          var label = {media:'媒体', travel:'出行', memory:'记忆', web:'网页', system:'系统',
                       device:'设备', file:'文件', shell:'命令行', message:'消息'}[g] || g;
          groups[g].forEach(function(t) {
            var ok = t.check == null;
            var badge = ok ? '可用' : (String(t.check).slice(0, 18) || '需授权');
            out += '<div class="set-row static"><div class="t">' + escHtml(t.name) + '</div>'
              + '<div class="v" style="color:' + (ok ? 'var(--ok)' : 'var(--ink-3)') + '">'
              + escHtml(badge) + '</div></div>';
          });
        });
        out += '</div>';
      } else {
        out += '<div class="dsub meta pad6">暂无工具清单（先运行一次慢脑任务，注册表加载后此处自动投影）</div>';
      }
    } catch(e) {}
    return out;
  }
  /* H2 件二: 健康行点按重测 → 重渲染权限页 */
  function _healthRetest(id) {
    try { if (typeof B !== 'undefined' && B.query) B.query({q:'health', op:'retest', id:id}); } catch(e){}
    B.toast('已重测 ' + id);
    setTimeout(function(){ try { redrawSettings(); } catch(e){} }, 1500);
  }

  function openNativePerm() {
    try { if (typeof B !== 'undefined' && B.openAppSettings) B.openAppSettings(); } catch(e) {}
  }

  /* ── 保险柜二级页 + 一级「清除对话记录」确认 sheet（工单14） ── */

  function renderVaultPage() {
    var out = '';
    /* 状态 + 解锁查看（P5 功能迁入，锁屏闸不变） */
    out += '<div class="set-group">'
      + '<div class="set-row static"><div class="t">状态</div><div class="v">已锁定</div></div>'
      + '<div class="set-row" onclick="NewFace.loadVaultEntries()"><div class="t">解锁查看</div><div class="chev">›</div></div>'
      + '</div>';
    /* 条目列表（vaultList 异步投影） */
    out += '<div class="set-group"><div id="vaultEntries"><div class="set-row static"><div class="t">加载中…</div></div></div></div>';
    /* 清除对话记录（工单25：从一级页收进信息管理二级页，行为不变仍走 clearRecordsSheet） */
    out += '<div class="set-group">'
      + '<div class="set-row danger" onclick="NewFace.clearRecordsSheet()"><div class="t">清除对话记录</div></div>'
      + '</div>';
    /* 数据说明（原隐私区块数据说明迁此） */
    out += '<div class="note">保险柜内容经本机硬件密钥加密，解锁需验证锁屏密码。原文永不离开本机。对话 / 追剧 / 观看记录全部只存在这台手机，不上传云端。</div>';
    setTimeout(function(){ try { loadVaultEntries(); } catch(e){} }, 30);
    return out;
  }

  /** 一级「清除对话记录」→ 确认 sheet 内并列选项（施工决策：观看历史/追剧记忆/全部对话记录） */
  function clearRecordsSheet() {
    ensureExpertOverlay();
    var overlay = document.getElementById('expertPreviewOverlay'); if (!overlay) return;
    document.getElementById('expertPreviewTitle').textContent = '清除对话记录';
    document.getElementById('expertPreviewMeta').textContent = '以下内容清除后不可恢复';
    var whCount = 0, dmCount = 0;
    try {
      var r1 = (typeof B !== 'undefined' && B.query) ? B.query({q:'watch_history'}) : null;
      if (r1 && r1.ok && r1.data) whCount = Object.keys(r1.data).length;
      var r2 = (typeof B !== 'undefined' && B.query) ? B.query({q:'drama_memory'}) : null;
      if (r2 && r2.ok && r2.data && r2.data.favs) dmCount = r2.data.favs.length;
    } catch(e) {}
    document.getElementById('expertPreviewBody').innerHTML =
      '<div class="confirm-txt">' + esc('观看历史（' + whCount + ' 部记录）') + '</div>'
      + '<div class="abtn" onclick="NewFace._clearRec(\'watch\')">清空观看历史</div>'
      + '<div class="confirm-txt">' + esc('追剧记忆（' + dmCount + ' 部收藏）') + '</div>'
      + '<div class="abtn" onclick="NewFace._clearRec(\'drama\')">清空追剧记忆</div>'
      + '<div class="confirm-txt">' + esc('全部对话记录（所有房间）') + '</div>'
      + '<div class="abtn danger" onclick="NewFace._clearRec(\'all\')">清空全部对话记录</div>';
    document.getElementById('expertPreviewActs').innerHTML =
      '<div class="abtn" onclick="NewFace.expertClosePreview()">取消</div>';
    overlay.style.display = 'flex';
  }

  function _clearRec(which) {
    try {
      if (which === 'watch') { if (B.query) B.query({q:'watch_history', op:'clear'}); B.toast('观看历史已清空'); }
      else if (which === 'drama') { if (B.query) B.query({q:'drama_memory', op:'clear'}); B.toast('追剧记忆已清空'); }
      else if (which === 'all') {
        /* 全部对话记录：遍历 face_history 房间逐个销毁（room_destroy 删磁盘房） */
        var resp = (typeof B !== 'undefined' && B.query) ? B.query({q:'face_history'}) : null;
        var groups = (resp && resp.ok && resp.data && resp.data.groups) ? resp.data.groups : [];
        var n = 0;
        groups.forEach(function(g) {
          (g.items || []).forEach(function(it) { if (it.roomId) { try { B.roomDestroy(it.roomId); n++; } catch(e){} } });
        });
        B.toast(n ? ('已清空 ' + n + ' 个对话') : '没有可清空的对话');
      }
    } catch(e) { B.toast('操作失败'); }
    expertClosePreview();
    redrawSettings();
  }

  /* ── ⑥ 保险柜（P5 双副本保险柜 · 设置页「隐私」区块条目：列表/解锁查看/删除，屏④ 🔒 形态） ── */
  var _vaultEntries = [];
  var _vaultPendingDelete = -1;

  function loadVaultEntries() {
    var box = document.getElementById('vaultEntries'); if (!box) return;
    if (typeof B === 'undefined' || !B.vaultList) {
      box.innerHTML = '<div class="ditem"><div class="dsub">保险柜桥未就绪</div></div>';
      return;
    }
    B.vaultList(function(res){
      if (!res || !res.ok) {
        var em = (res && res.error && res.error.msg) || '保险柜不可用';
        box.innerHTML = '<div class="ditem"><div class="dsub">' + escHtml(em) + '</div></div>';
        return;
      }
      var entries = (res.data && res.data.entries) || [];
      _vaultEntries = entries;
      if (!entries.length) {
        box.innerHTML = '<div class="ditem"><div class="dsub">空 · 敏感内容会在这里上锁</div></div>';
        return;
      }
      var html = '';
      for (var i = 0; i < entries.length; i++) {
        var e = entries[i];
        html += '<div class="ditem" onclick="NewFace.vaultShowEntry(' + i + ')">🔒 ' + escHtml(e.name)
          + '<div class="dsub">' + formatSize(e.sizeBytes) + ' · ' + formatTs(e.createdAtMs) + ' · 点按解锁查看</div></div>';
        if (_vaultPendingDelete === i) {
          html += '<div class="ditem warn-bold" onclick="NewFace.vaultDeleteEntry(' + i + ')">再点一次确认删除「' + escHtml(e.name) + '」'
            + '<div class="dsub">不可恢复</div></div>';
        } else {
          html += '<div class="ditem warn" onclick="NewFace.vaultDeleteEntry(' + i + ')">删除'
            + '<div class="dsub">' + escHtml(e.name) + ' · 点按两次删除</div></div>';
        }
      }
      box.innerHTML = html;
    });
  }

  /* 解锁查看：过 Keyguard 闸（桥内弹系统指纹/PIN/图案）→ 展示内容 */
  function vaultShowEntry(i) {
    var e = _vaultEntries[i]; if (!e) return;
    B.vaultUnlock(e.id, function(res){
      if (!res || !res.ok) {
        var em = (res && res.error && res.error.msg) || '无法解锁';
        B.toast(em);
        return;
      }
      showVaultSheet(e.name, (res.data && res.data.content) || '');
    });
  }

  /* 删除：两次点按确认（不用 confirm()，守「Sheet 替代弹窗」规则） */
  function vaultDeleteEntry(i) {
    if (_vaultPendingDelete !== i) {
      _vaultPendingDelete = i;
      loadVaultEntries();
      return;
    }
    var e = _vaultEntries[i]; if (!e) return;
    B.vaultDelete(e.id, function(res){
      _vaultPendingDelete = -1;
      if (res && res.ok) { B.toast('已从保险柜删除'); }
      else { B.toast((res && res.error && res.error.msg) || '删除失败'); }
      loadVaultEntries();
    });
  }

  /* 展示解锁内容：独立 fixed sheet（内联样式，textContent 防注入；不走 confirm/prompt） */
  function showVaultSheet(name, content) {
    var old = document.getElementById('vaultSheet');
    if (old && old.parentNode) old.parentNode.removeChild(old);
    var sheet = document.createElement('div');
    sheet.id = 'vaultSheet';
    sheet.style.cssText = 'position:fixed;inset:0;background:rgba(28,26,22,.4);display:flex;align-items:flex-end;z-index:999;';
    var panel = document.createElement('div');
    panel.style.cssText = 'width:100%;max-height:78%;background:#fefcf9;border-radius:24px 24px 0 0;padding:18px 22px;box-sizing:border-box;display:flex;flex-direction:column;color:#1c1a16;';
    var title = document.createElement('div');
    title.textContent = '🔒 ' + (name || '保险柜条目');
    title.style.cssText = 'font-size:17px;font-weight:700;margin-bottom:4px;';
    var meta = document.createElement('div');
    meta.textContent = '保险柜解锁 · 仅本机可见';
    meta.style.cssText = 'font-size:10px;color:#9a938a;margin-bottom:12px;';
    var body = document.createElement('div');
    body.style.cssText = 'flex:1;overflow-y:auto;font-size:12.5px;line-height:2.1;color:#5c574e;white-space:pre-wrap;word-break:break-word;';
    body.textContent = content;
    var acts = document.createElement('div');
    acts.style.cssText = 'display:flex;gap:10px;margin-top:14px;';
    var close = document.createElement('div');
    close.textContent = '关闭';
    close.style.cssText = 'flex:1;text-align:center;padding:10px 0;border-radius:99px;font-size:12px;border:1px solid rgba(28,26,22,.09);color:#5c574e;cursor:pointer;';
    close.onclick = function(){ var p = document.getElementById('vaultSheet'); if (p) p.parentNode.removeChild(p); };
    acts.appendChild(close);
    panel.appendChild(title); panel.appendChild(meta); panel.appendChild(body); panel.appendChild(acts);
    sheet.appendChild(panel);
    document.body.appendChild(sheet);
    sheet.addEventListener('click', function(ev){
      if (ev.target === sheet) { var p = document.getElementById('vaultSheet'); if (p) p.parentNode.removeChild(p); }
    });
  }

  /* ── ⑦ 技术区块（入口归位，功能仍在原生设置页原样保留） ── */

  /* ── 派单№5: 技术区块 — 外观(主题) + 终端 (老运行页入口迁入) ── */
  /* ── 系统二级页（工单14：终端/Linux/Hermes/MCP/SSH/诊断/重置 + 工单15 清理残留房间） ── */
  function renderSystemPage() {
    var out = '';
    out += '<div class="set-group">';
    out += '<div class="set-row" onclick="NewFace.openTerminalFromSettings()"><div class="t">终端</div>'
      + '<div class="v">内嵌 Ubuntu</div><div class="chev">›</div></div>';
    out += '<div class="set-row static"><div class="t">Linux 环境</div><div class="v" id="sysLinuxVal">…</div></div>';
    out += '<div class="set-row static"><div class="t">Hermes 服务</div><div class="v" id="sysHermesVal">…</div></div>';
    out += '</div>';
    out += '<div class="set-group">';
    out += '<div class="set-row"><div class="t">MCP</div><div class="v">server_url / token</div></div>'
      + '<div class="set-sub"><input id="mcpUrl" placeholder="server_url"><input id="mcpToken" placeholder="server_token">'
      + '<div class="sysacts"><span class="dact" onclick="NewFace._mcpSave()">保存</span>'
      + '<span class="dact" onclick="NewFace._mcpTest()">测连通</span></div></div>';
    out += '<div class="set-row"><div class="t">SSH（部署服务器）</div><div class="v" id="sysSshSub">…</div></div>'
      + '<div class="set-sub"><div class="sysacts"><span class="dact" onclick="NewFace._sshEdit()">配置</span>'
      + '<span class="dact" onclick="NewFace._sshTest()">测连接</span></div></div>';
    out += '</div>';
    out += '<div class="set-group">';
    out += '<div class="set-row"><div class="t">导出诊断</div><div class="v">日志 / 状态摘要</div></div>'
      + '<div class="set-sub"><div class="sysacts"><span class="dact" onclick="NewFace._diagExport()">导出</span>'
      + '<span class="dact" onclick="NewFace._diagClear()">清空</span></div></div>';
    out += '<div class="set-row" onclick="NewFace.cleanupRooms()"><div class="t">清理残留房间</div>'
      + '<div class="v" id="sysOrphanVal">检查</div><div class="chev">›</div></div>';
    out += '</div>';
    out += '<div class="set-group">';
    out += '<div class="set-row danger" onclick="NewFace.resetSystemConfirm()"><div class="t">重置系统</div></div>';
    out += '</div>';
    setTimeout(function(){ try { _renderSysStatus(); } catch(e){} }, 30);
    return out;
  }

  /* 外观三态（浅色/深色/跟随系统）：mov_theme = light | dark | auto */
  function getThemeMode() {
    try { var m = localStorage.getItem('mov_theme'); return (m === 'dark' || m === 'auto') ? m : 'light'; } catch(e) { return 'light'; }
  }
  function applyTheme(mode) {
    var dark = (mode === 'dark') || (mode === 'auto' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.classList.toggle('dark', !!dark);
  }
  function setThemeMode(mode) {
    try { localStorage.setItem('mov_theme', (mode === 'dark' || mode === 'auto') ? mode : 'light'); } catch(e) {}
    applyTheme(getThemeMode());
    redrawSettings();
  }
  function toggleTheme() { setThemeMode(getThemeMode() === 'dark' ? 'light' : 'dark'); }
  function openTerminalFromSettings() {
    closeDrawer();
    try { if (typeof B !== 'undefined' && B.openTerminal) B.openTerminal(); } catch(e){}
  }

  /* 系统级状态拉取 (Kernel query) + 安装进度轮询 (无感工作态) */
  function _sysQuery(q) { try { return B.query(q); } catch(e){ return null; } }
  function _fv(id) { var e = document.getElementById(id); return e ? e.value.trim() : ''; }
  function _renderSysStatus() {
    var murl = document.getElementById('mcpUrl');
    if (murl && !murl.value) {
      var m = _sysQuery({q:'mcp.get'});
      if (m && m.ok && m.data) {
        murl.value = m.data.server_url || '';
        var mt = document.getElementById('mcpToken'); if (mt) mt.value = m.data.server_token || '';
      }
    }
    var ssh = (typeof B !== 'undefined' && B.getDeployConfig) ? B.getDeployConfig() : null;
    var ss = document.getElementById('sysSshSub');
    if (ss && ssh && ssh.configured) ss.textContent = ssh.host + (ssh.port ? ':' + ssh.port : '') + ' · ' + (ssh.user || '');
    /* Linux 环境 / Hermes 服务状态行 */
    try {
      var ls = _sysQuery({q:'linuxStatus'});
      var le = document.getElementById('sysLinuxVal');
      if (le) {
        var okL = ls && ls.ok && ls.data && ls.data.installed;
        le.textContent = okL ? '已安装' : '未安装';
      }
    } catch(e) {}
    try {
      var hs = (typeof B !== 'undefined' && B.hermesStatus) ? B.hermesStatus() : null;
      var he = document.getElementById('sysHermesVal');
      if (he) he.textContent = (hs && hs.ready) ? '运行中' : '未运行';
    } catch(e) {}
  }

  /** 重置系统：两步确认 → resetSystem（破坏性操作，红线确认闸） */
  function resetSystemConfirm() {
    expertConfirm(null, '重置系统将清除全部数据并恢复初始状态，不可恢复。确定继续？', function(){
      expertConfirm(null, '再次确认：清除全部数据并恢复初始状态？', function(){
        try { B.postCmd({cmd:'resetSystem'}); B.toast('已重置'); } catch(e){ B.toast('重置失败'); }
        redrawSettings();
      });
    });
  }

  /** 清理残留房间（工单15：rooms.orphan 查询 → 确认 → rooms.cleanup 执行） */
  function cleanupRooms() {
    try {
      var r = B.postCmd({cmd:'rooms.orphan'});
      var list = (r && r.ok && r.data && r.data.orphans) ? r.data.orphans : [];
      var val = document.getElementById('sysOrphanVal');
      if (val) val.textContent = list.length ? (list.length + ' 个') : '无残留';
      if (!list.length) { B.toast('没有残留房间'); return; }
      expertConfirm(null, '清理 ' + list.length + ' 个残留房间目录？删除后不可恢复。', function(){
        try { B.postCmd({cmd:'rooms.cleanup'}); B.toast('已清理'); } catch(e){ B.toast('清理失败'); }
        redrawSettings();
      });
    } catch(e) { B.toast('检查失败'); }
  }
  function _mcpSave() {
    try { B.postCmd({cmd:'mcp.set', server_url:_fv('mcpUrl'), server_token:_fv('mcpToken')}); } catch(e){}
    B.toast('MCP 配置已保存');
  }
  function _mcpTest() {
    B.toast('测试 MCP 连通…');
    var r = B.postCmd({cmd:'mcp.test', server_url:_fv('mcpUrl'), server_token:_fv('mcpToken')});
    B.toast(r && r.ok && r.data && r.data.ok ? 'MCP 连接正常' : 'MCP 连接失败');
  }
  function _sshEdit() {
    var cfg = (typeof B !== 'undefined' && B.getDeployConfig) ? B.getDeployConfig() : {};
    var overlay = document.getElementById('expertPreviewOverlay'); if (!overlay) return;
    document.getElementById('expertPreviewTitle').textContent = 'SSH 部署服务器';
    document.getElementById('expertPreviewMeta').textContent = '';
    var body = document.getElementById('expertPreviewBody');
    body.innerHTML = '<div class="mform-label">Host</div><input id="sshHost" value="' + escHtml(cfg.host || '') + '">'
      + '<div class="mform-label">Port</div><input id="sshPort" value="' + escHtml(cfg.port || '22') + '">'
      + '<div class="mform-label">User</div><input id="sshUser" value="' + escHtml(cfg.user || '') + '">'
      + '<div class="mform-label">Secret</div><input id="sshSecret" value="' + escHtml(cfg.secret || '') + '">';
    document.getElementById('expertPreviewActs').innerHTML =
      '<div class="abtn save" onclick="NewFace._sshSave()">保存</div>'
      + '<div class="abtn" onclick="NewFace.expertClosePreview()">取消</div>';
    overlay.style.display = 'flex';
  }
  function _sshSave() {
    var o = {host:_fv('sshHost'), port:_fv('sshPort'), user:_fv('sshUser'), auth:'key', secret:_fv('sshSecret')};
    var r = B.saveDeployConfig(o);
    B.toast(r && r.ok ? 'SSH 已保存' : 'SSH 保存失败');
    expertClosePreview();
    setTimeout(function(){ try { _renderSysStatus(); } catch(e){} }, 500);
  }
  function _sshTest() {
    B.toast('测试 SSH 连接…');
    if (typeof B.testDeployConnection === 'function') B.testDeployConnection(function(res){ B.toast(res && res.ok ? 'SSH 连接正常' : 'SSH 连接失败'); });
  }
  function _diagExport() { try { B.postCmd({cmd:'diagnostics.export'}); } catch(e){} B.toast('已导出诊断日志'); }
  function _diagClear() { try { B.postCmd({cmd:'diagnostics.clear'}); } catch(e){} B.toast('已清空日志'); }

  /** 通用连接入口: 已连接→搜, 未连接→登录 */

  /** 通用连接入口: 已连接→搜, 未连接→登录 */
  function openConnect(platform) {
    closeDrawer();
    var connected = false;
    try { if (typeof B !== 'undefined' && B.connectStatus) connected = !!B.connectStatus(platform).connected; } catch(e) {}
    if (connected) {
      var t = el('<div class="ctxline"><b>◆</b><span>' + (platform === 'douyin' ? '抖音' : '腾讯视频') + '已连接 · 直接说「我要追xx」就能看</span></div>');
      document.getElementById('faceCover').appendChild(t);
      setTimeout(function(){ if (t.parentNode) t.parentNode.removeChild(t); }, 2400);
      return;
    }
    if (typeof B !== 'undefined' && B.openConnectLogin) B.openConnectLogin(platform);
  }

  /** 视频源注册表区块: 只显示可用源; blocked/已关的不出现(注册表 JSON 留档) */
  function renderSourcesSection() {
    var out = '<div class="dgroup">视频源</div>';
    try {
      var resp = B.query({q:'video_sources'});
      var list = (resp && resp.ok && resp.sources) ? resp.sources : [];
      var DOT = {good:'#5d9b4a', session:'#4a6fd4', limited:'#c8a13a', blocked:'#b8b2a8'};
      var hidden = 0;
      list.forEach(function(s) {
        if (s.status === 'blocked' || !s.enabled) { hidden++; return; }  // 下架/已关不显示
        out += '<div class="ditem src-row" onclick="NewFace.toggleSource(\'' + escHtml(s.id) + '\',false)">'
          + '<span class="src-dot" style="background:' + (DOT[s.status] || '#b8b2a8') + '"></span>'
          + '<span class="f-grow"><span class="src-name">' + escHtml(s.name) + '</span>'
          + '<span class="meta ml6">' + escHtml(s.scope) + '</span>'
          + '<div class="meta mt2">' + escHtml(s.note) + '</div></span>'
          + '<span class="src-on">启用</span></div>';
      });
      if (hidden > 0) {
        out += '<div class="meta pad6">' + hidden + ' 个源已下架（注册表留档，不再出现）</div>';
      }
    } catch(e) {}
    return out;
  }

  /** 切换视频源开关并刷新设置页 */
  function toggleSource(id, enabled) {
    try { B.query({q:'video_sources', action:'toggle', id:id, enabled:enabled}); } catch(e) {}
    redrawSettings();
  }


  function openDouyin(query) {
    closeDrawer();
    var connected = false;
    try { if (typeof B !== 'undefined' && B.connectStatus) connected = !!B.connectStatus('douyin').connected; } catch(e) {}
    if (connected) {
      if (query) { if (typeof B !== 'undefined' && B.openConnectSearch) B.openConnectSearch('douyin', query); return; }
      var t = el('<div class="ctxline"><b>◆</b><span>抖音已连接 · 直接说「我要追xx」就能看</span></div>');
      document.getElementById('faceCover').appendChild(t);
      setTimeout(function(){ if (t.parentNode) t.parentNode.removeChild(t); }, 2400);
      return;
    }
    if (typeof B !== 'undefined' && B.openConnectLogin) B.openConnectLogin('douyin');
  }


  function previewMine(roomId, fileName) {
    closeDrawer();
    /* 第二幕: 文件预览统一走新脸 overlay 体系 (home 与专家共用 expertPreviewOverlay), 不再 faceCover 全屏 */
    expertPreviewFile(roomId, fileName);
  }

  function closeDrawer() {
    var mask = document.getElementById('faceDmask');
    var drawer = document.getElementById('faceDrawer');
    if (mask) mask.classList.remove('on');
    if (drawer) drawer.classList.remove('on');
  }

  function resetFace() {
    // 清理所有 overlay
    closePaySheet(); closePlayer(); closeEmbedPlayer();
    var dh = document.getElementById('faceDoneHost'); if (dh) dh.innerHTML = '';
    var ph = document.getElementById('facePlayerHost'); if (ph) ph.innerHTML = '';
    // 清理 A2A 状态
    if (_a2a && _a2a.pollTimer) { clearInterval(_a2a.pollTimer); _a2a.pollTimer = null; }
    try { if (typeof B !== 'undefined' && B.a2aStopPolling) B.a2aStopPolling(); } catch(e) {}
    _a2a = { state: 'idle', peer: null, cart: [], confirm: null, orderId: null, pollTimer: null, pollMsgs: [] };
    // 恢复封面
    var cover = document.getElementById('faceCover');
    if (cover && _heroHTML) cover.innerHTML = _heroHTML;
    _chatStreamOn = false;   // 工单17: 恢复封面 = 新会话，下次 say 重新初始化对话流
    _homeRoomId = null;      // 工单17: 回封面 = 新会话，下次派活开新房
    var hero = document.getElementById('faceHero');
    if (hero) hero.style.display = '';
    // 2C.5: 恢复封面后重新注入"接着上次看"（_heroHTML 快照不含注入卡）
    injectContinueWatching();
    // FUSION F5: 恢复封面后若有最近慢脑交付 → 回脸交付卡
    renderFaceDelivery();
  }


  function submitIntent() {
    var input = document.getElementById('faceInput');
    if (!input) return;
    var v = input.value.trim();
    if (!v) return;
    input.value = '';
    say(v);
  }

  function bindMic() {
    var mic = document.getElementById('faceMic');
    var pill = document.getElementById('facePill');
    var input = document.getElementById('faceInput');
    if (!mic || !pill || !input) return;
    /* W4: 真语音 — 按住 → B.startSTT(系统 RecognizerIntent) → HermesActivity 9002 回 _movStt → input + submitIntent */
    window._movStt = function(res) {
      pill.classList.remove('listening'); input.classList.remove('listen-hint');
      if (res && res.ok && res.text) {
        input.placeholder = '说一句话…';
        input.value = res.text;
        submitIntent();
      } else {
        input.placeholder = (res && res.error === 'speech_cancelled') ? '说一句话…' : '语音不可用 · 请打字';
      }
    };
    var listening = false;
    mic.addEventListener('pointerdown', function(e) {
      e.preventDefault(); listening = true;
      pill.classList.add('listening');
      input.value = ''; input.placeholder = '正在听…松开结束';
      input.classList.add('listen-hint');
      try { if (typeof B !== 'undefined' && B.startSTT) B.startSTT(); } catch(err) {}
    });
    mic.addEventListener('pointerup', function() { listening = false; });
    mic.addEventListener('pointerleave', function() {
      if (listening) { listening = false; pill.classList.remove('listening'); input.classList.remove('listen-hint'); input.placeholder = '说一句话…'; }
    });
  }

  function escHtml(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  /* ── 初始化 ── */
  var _heroHTML = '';

  function init() {
    var el = document.getElementById('view-face');
    if (!el) return;
    // 快照封面 HTML（say() 会替换，resetFace() 恢复用）
    var cover = document.getElementById('faceCover');
    if (cover) _heroHTML = cover.innerHTML;
    // 日期行
    var dl = document.getElementById('faceDateline');
    if (dl) { var d = new Date(), wk = '日一二三四五六'[d.getDay()]; dl.textContent = (d.getMonth()+1) + '月' + d.getDate() + '日 周' + wk + ' · 本地'; }
    // 默认显示新脸（debug 包）
    if (typeof curTab !== 'undefined') curTab = 'face';
    showFace();
    // 2C.5: 注入"接着上次看"情境卡
    setTimeout(function() { injectContinueWatching(); scanDramaUpdates(); }, 300);
    // 更新雷达每 6h 重扫
    setInterval(function() { scanDramaUpdates(); }, 21600000);
    // 绑定输入 Enter
    var input = document.getElementById('faceInput');
    if (input) input.addEventListener('keydown', function(e) { if (e.key === 'Enter') submitIntent(); });
    bindMic();
  }

  document.addEventListener('DOMContentLoaded', init);
  // FUSION F5: 加载即注册慢脑 deliver 事件监听（bridge.js 先于本文件加载，_movOn 已就绪）
  initMovListener();
  return {
    showFace: showFace, switchToExpert: switchToExpert,
    /* mov-verify 兼容: 暴露真实进房路径（expertOpenRoom 原为新脸 IIFE 局部，mov-verify room 命令复用） */
    openRoom: expertOpenRoom,
    say: say, voice: voice,
    openDrawer: openDrawer, closeDrawer: closeDrawer,
    resetFace: resetFace, openSettings: openSettings,
    closeSettings: closeSettings, settingsGo: settingsGo, settingsBack: settingsBack,
    redrawSettings: redrawSettings, checkUpdate: checkUpdate,
    merchantSave: merchantSave,
    setThemeMode: setThemeMode, setRoutingMode: setRoutingMode,
    clearRecordsSheet: clearRecordsSheet, _clearRec: _clearRec,
    _fbToggleDiag: _fbToggleDiag, _fbSubmit: _fbSubmit,
    resetSystemConfirm: resetSystemConfirm, cleanupRooms: cleanupRooms,
    clearConnect: clearConnect,
    openNativePerm: openNativePerm, gotoDelivery: gotoDelivery,
    genA2aPairCode: genA2aPairCode, saveA2aRelay: saveA2aRelay,
    deleteLocalModel: deleteLocalModel,
    submitIntent: submitIntent, showEmpty: showEmpty,
    cycleSlot: cycleSlot, learnAnswer: learnAnswer,
    failRetry: failRetry, failAlt: failAlt,
    closePlayer: closePlayer, startFail: startFail,
    handoffToExpert: handoffToExpert,
    _a2aSelectPeer: _a2aSelectPeer, _a2aPair: _a2aPair,
    _a2aCartChange: _a2aCartChange, _a2aSubmitOrder: _a2aSubmitOrder,
    _a2aIPaid: _a2aIPaid, _a2aOpenPayLink: _a2aOpenPayLink,
    _a2aCopyNote: _a2aCopyNote, _a2aWechatScan: _a2aWechatScan,
    _a2aSubmitReview: _a2aSubmitReview,   // W1 第二幕：随机抽评提交
    _continueSearch: _continueSearch,
    _musicToggle: _musicToggle, _musicStop: _musicStop, _musicSeek: _musicSeek,
    _dramaFav: _dramaFav, _dramaBlock: _dramaBlock,
    _openConnectUrl: _openConnectUrl,
    openDouyin: openDouyin,
    openConnect: openConnect,
    toggleSource: toggleSource,
    replayConversation: replayConversation, openRoomFromHistory: openRoomFromHistory, previewMine: previewMine,
    expertOpenRoom: expertOpenRoom, expertBack: expertBack,
    expertSend: expertSend, expertNewRoom: expertNewRoom, expertExit: expertExit,
    expertGoRun: expertGoRun, expertGoFiles: expertGoFiles, expertBackToRooms: expertBackToRooms,
    expertStopTask: expertStopTask,
    expertPreviewFile: expertPreviewFile, expertClosePreview: expertClosePreview,
    expertEditPreview: expertEditPreview, expertSavePreview: expertSavePreview,
    expertExportPreview: expertExportPreview, expertContinuePreview: expertContinuePreview,
    expertInstallPreview: expertInstallPreview, expertVaultOpen: expertVaultOpen,
    loadVaultEntries: loadVaultEntries, vaultShowEntry: vaultShowEntry, vaultDeleteEntry: vaultDeleteEntry,
    expertRoomOps: expertRoomOps, expertOpsClose: expertOpsClose,
    expertOpsRename: expertOpsRename, expertOpsRenameOk: expertOpsRenameOk,
    expertOpsArchive: expertOpsArchive, expertOpsClear: expertOpsClear, expertOpsDelete: expertOpsDelete,
    _expertConfirmOk: _expertConfirmOk,
    expertVersionsPreview: expertVersionsPreview, expertBackFromVersions: expertBackFromVersions,
    expertRestoreVersion: expertRestoreVersion,
    _mops: _mops, _mopsClose: _mopsClose, _msetDefault: _msetDefault, _mtest: _mtest,
    _medit: _medit, _mdelete: _mdelete, _mform: _mform, _mfProvider: _mfProvider,
    _mformCancel: _mformCancel, _msave: _msave, _mtestForm: _mtestForm,
    toggleTheme: toggleTheme, openTerminalFromSettings: openTerminalFromSettings,
    _mcpSave: _mcpSave, _mcpTest: _mcpTest,
    _sshEdit: _sshEdit, _sshSave: _sshSave, _sshTest: _sshTest,
    _diagExport: _diagExport, _diagClear: _diagClear, _healthRetest: _healthRetest,
    startShopSearch: startShopSearch
  };
})();
