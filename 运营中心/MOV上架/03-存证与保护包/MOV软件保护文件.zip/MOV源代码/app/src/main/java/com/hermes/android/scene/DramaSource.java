package com.hermes.android.scene;

import android.util.Log;
import com.hermes.android.agent.VideoSourceRegistry;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * DramaSource — 追剧内容适配器（Phase 2C.1）。
 *
 * 降级链：豆瓣 subject_suggest → DuckDuckGo → 空列表（触发失败卡）。
 * 约束：每源 ≤5s 超时；豆瓣调用 ≥1s 间隔 + 失败指数退避。
 */
public class DramaSource {

    private static final String TAG = "DramaSource";
    private static final String DOUBAN_SUGGEST = "https://movie.douban.com/j/subject_suggest?q=";
    private static final String BILI_SEARCH = "https://api.bilibili.com/x/web-interface/search/type?search_type=video&keyword=";
    private static final String DDG_API = "https://api.duckduckgo.com/?format=json&q=";
    private static final int TIMEOUT_CONNECT_MS = 3000;
    private static final int TIMEOUT_READ_MS = 5000;
    static final long DOUBAN_INTERVAL_MS = 1000;   // package-private for test
    private static final long DOUBAN_BACKOFF_BASE_MS = 2000;

    long lastDoubanCall;           // package-private for test
    long doubanBackoffUntil;       // package-private for test
    int doubanConsecutiveFailures;  // package-private for test

    private VideoSourceRegistry registry;   // 视频源注册表（抽屉可开关, 可选注入）
    public void setRegistry(VideoSourceRegistry r) { this.registry = r; }

    /** 单条追剧结果 */
    public static class DramaItem {
        public final String title;       // 剧名
        public final String year;        // 年份
        public final String poster;      // 海报 URL
        public final String url;         // 豆瓣详情页 URL
        public final String platform;    // 推测平台：bilibili / tencent / iqiyi / youku / ""
        public final String source;      // 数据来源：douban / bilibili / ddg
        public final String duration;    // 时长（如 "29:31"）
        public final String playCount;   // 播放量（如 "203.4万"）
        public final String viewType;    // "link"（外部链接/deep link）/ "embed"（内嵌播放）

        public DramaItem(String title, String year, String poster, String url,
                         String platform, String source, String duration,
                         String playCount, String viewType) {
            this.title = title;
            this.year = year;
            this.poster = poster;
            this.url = url;
            this.platform = platform;
            this.source = source;
            this.duration = duration;
            this.playCount = playCount;
            this.viewType = viewType;
        }

        // 兼容旧构造
        public DramaItem(String title, String year, String poster, String url,
                         String platform, String source) {
            this(title, year, poster, url, platform, source, "", "", "link");
        }

        public JSONObject toJSON() {
            JSONObject o = new JSONObject();
            try {
                o.put("title", title != null ? title : "");
                o.put("year", year != null ? year : "");
                o.put("poster", poster != null ? poster : "");
                o.put("url", url != null ? url : "");
                o.put("platform", platform != null ? platform : "");
                o.put("source", source != null ? source : "");
                o.put("duration", duration != null ? duration : "");
                o.put("playCount", playCount != null ? playCount : "");
                o.put("viewType", viewType != null ? viewType : "link");
            } catch (Exception ignored) {}
            return o;
        }
    }

    /**
     * 搜索追剧内容。
     *
     * @param query 搜索词（如 "漫长的季节"、"繁花"、"追剧"）
     * @return 结果列表（空列表 = 全部源失败，触发失败卡）
     */
    public List<DramaItem> search(String query) {
        if (query == null || query.trim().isEmpty()) return Collections.emptyList();

        // 注册表过滤: blocked/disabled 的源直接跳过（西瓜/咪咕/乐视已下架, DDG 默认关）
        boolean doubanOn = registry == null || registry.isUsable("douban");
        boolean biliOn = registry == null || registry.isUsable("bilibili");
        boolean mayiOn = registry != null && registry.isUsable("mayi91");
        boolean ddgOn = registry != null && registry.isUsable("ddg");

        List<DramaItem> allResults = new ArrayList<>();

        // 0. 蚂蚁影视（个人主力源：免费免登录, 片库全）
        if (mayiOn) {
            List<DramaItem> mayi = tryMayi(query);
            if (!mayi.isEmpty()) {
                allResults.addAll(mayi);
            }
        }

        // 1. 豆瓣 + B站并行（都搜，合并结果）
        if (doubanOn) {
            List<DramaItem> douban = tryDouban(query);
            if (!douban.isEmpty()) {
                doubanConsecutiveFailures = 0;
                allResults.addAll(douban);
            }
        }
        if (biliOn) {
            List<DramaItem> bili = tryBilibili(query);
            if (!bili.isEmpty()) {
                allResults.addAll(bili);
            }
        }

        if (!allResults.isEmpty()) return allResults;

        // 2. DuckDuckGo（降级, 注册表默认关）
        if (ddgOn) {
            List<DramaItem> ddg = tryDDG(query);
            if (!ddg.isEmpty()) return ddg;
        }

        // 3. 全挂 → 空列表
        Log.w(TAG, "全源挂，query=" + query);
        return Collections.emptyList();
    }

    // ==================== 豆瓣 ====================

    List<DramaItem> tryDouban(String query) {  // package-private for test
        // 频率保护
        long now = System.currentTimeMillis();
        if (now < doubanBackoffUntil) {
            Log.d(TAG, "豆瓣退避中，跳过 (剩余 " + (doubanBackoffUntil - now) + "ms)");
            return Collections.emptyList();
        }
        long sinceLast = now - lastDoubanCall;
        if (sinceLast < DOUBAN_INTERVAL_MS) {
            try { Thread.sleep(DOUBAN_INTERVAL_MS - sinceLast); } catch (InterruptedException ignored) {}
        }

        HttpURLConnection conn = null;
        try {
            String encoded = URLEncoder.encode(query, "UTF-8");
            URL url = new URL(DOUBAN_SUGGEST + encoded);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(TIMEOUT_CONNECT_MS);
            conn.setReadTimeout(TIMEOUT_READ_MS);
            conn.setRequestProperty("User-Agent", "MOV/3.0 (Android)");
            conn.setRequestProperty("Accept", "application/json");
            lastDoubanCall = System.currentTimeMillis();

            int code = conn.getResponseCode();
            if (code != 200) {
                Log.w(TAG, "豆瓣返回 " + code);
                onDoubanFail();
                return Collections.emptyList();
            }

            BufferedReader r = new BufferedReader(new InputStreamReader(
                    conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();

            JSONArray arr = new JSONArray(sb.toString());
            List<DramaItem> results = new ArrayList<>();
            int limit = Math.min(arr.length(), 4); // 最多 4 条
            for (int i = 0; i < limit; i++) {
                JSONObject item = arr.getJSONObject(i);
                String title = item.optString("title", "");
                String year = item.optString("year", "");
                String poster = "";
                JSONObject pic = item.optJSONObject("pic");
                if (pic != null) poster = pic.optString("normal", "");
                String itemUrl = item.optString("url", "");
                String type = item.optString("type", ""); // "tv" / "movie"
                // 只取电视剧/电影
                if (!"tv".equals(type) && !"movie".equals(type)) continue;
                String platform = inferPlatform(title);
                results.add(new DramaItem(title, year, poster, itemUrl, platform, "douban"));
            }
            return results;

        } catch (Exception e) {
            Log.w(TAG, "豆瓣异常: " + e.getMessage());
            onDoubanFail();
            return Collections.emptyList();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    void onDoubanFail() {  // package-private for test
        doubanConsecutiveFailures++;
        long backoff = DOUBAN_BACKOFF_BASE_MS * (1L << Math.min(doubanConsecutiveFailures - 1, 4));
        doubanBackoffUntil = System.currentTimeMillis() + backoff;
        Log.w(TAG, "豆瓣退避 " + backoff + "ms (连续失败 " + doubanConsecutiveFailures + " 次)");
    }

    // ==================== B站 ====================

    List<DramaItem> tryBilibili(String query) {
        HttpURLConnection conn = null;
        try {
            /* api.bilibili.com 已被风控 412 全面拦截（含官方浏览器），
               改抓搜索页 HTML 内嵌的 __INITIAL_STATE__ JSON：bvid→title 同块顺序提取 */
            String encoded = URLEncoder.encode(query, "UTF-8");
            URL url = new URL("https://search.bilibili.com/all?keyword=" + encoded);
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(TIMEOUT_CONNECT_MS);
            conn.setReadTimeout(TIMEOUT_READ_MS);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml");
            conn.setRequestProperty("Referer", "https://www.bilibili.com/");

            int code = conn.getResponseCode();
            if (code != 200) {
                Log.w(TAG, "B站返回 " + code);
                return Collections.emptyList();
            }

            BufferedReader r = new BufferedReader(new InputStreamReader(
                    conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            return parseBilibiliHtml(sb.toString());

        } catch (Exception e) {
            Log.w(TAG, "B站异常: " + e.getMessage());
            return Collections.emptyList();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    /** 解析 B站搜索页 HTML（__INITIAL_STATE__ 内嵌 JSON）。分离出来供测试注入。 */
    List<DramaItem> parseBilibiliHtml(String html) {
        List<DramaItem> results = new ArrayList<>();
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                "\"bvid\":\"(BV[0-9A-Za-z]+)\"[^}]{0,500}?\"title\":\"((?:\\\\.|[^\"\\\\])*)\"[^}]{0,200}?\"duration\":(\\d+)");
        java.util.regex.Matcher m = p.matcher(html);
        while (m.find() && results.size() < 4) {
            String bvid = m.group(1);
            String title = unescapeJson(m.group(2)).replaceAll("<[^>]+>", "");
            int secs = Integer.parseInt(m.group(3));
            String dur = (secs / 60) + ":" + String.format("%02d", secs % 60);
            String embedUrl = "https://player.bilibili.com/player.html?bvid=" + bvid + "&autoplay=1&danmaku=0";
            results.add(new DramaItem(title, "", "", embedUrl, "bilibili", "bilibili",
                    dur, "", "embed"));
        }
        return results;
    }

    List<DramaItem> tryMayi(String query) {
        HttpURLConnection conn = null;
        try {
            // 蚂蚁影视（个人主力源）: maccms 搜索页, 验收人实测有效
            String encoded = URLEncoder.encode(query, "UTF-8");
            URL url = new URL("https://www.91mayitv.com/vodsearch/" + encoded + "-------------.html");
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(TIMEOUT_CONNECT_MS);
            conn.setReadTimeout(TIMEOUT_READ_MS);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml");

            int code = conn.getResponseCode();
            if (code != 200) {
                Log.w(TAG, "蚂蚁返回 " + code);
                return Collections.emptyList();
            }
            BufferedReader r = new BufferedReader(new InputStreamReader(
                    conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            return parseMayiHtml(sb.toString(), query);
        } catch (Exception e) {
            Log.w(TAG, "蚂蚁异常: " + e.getMessage());
            return Collections.emptyList();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    /** 解析蚂蚁搜索页 HTML（voddetail 卡片）。分离出来供测试注入。 */
    List<DramaItem> parseMayiHtml(String html, String query) {
        java.util.LinkedHashMap<String, DramaItem> dedup = new java.util.LinkedHashMap<>();
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                "href=\"/voddetail/(\\d+)\\.html\" title=\"([^\"]+)\" data-original=\"([^\"]*)\"[^>]*>"
                + "(?:.*?pic-text[^>]*>([^<]+)<)?",
                java.util.regex.Pattern.DOTALL);
        java.util.regex.Matcher m = p.matcher(html);
        while (m.find() && dedup.size() < 5) {
            String id = m.group(1);
            String title = m.group(2).trim();
            // 过滤：与查询词无中文字符重叠的条目（「猜你喜欢」推荐区污染, 如搜凡人修仙传出狂飙）
            if (!hasCharOverlap(title, query)) continue;
            String poster = m.group(3);
            String picText = m.group(4) != null ? m.group(4).trim() : "";
            String detailUrl = "https://www.91mayitv.com/voddetail/" + id + ".html";
            // 按标题去重：同剧多条记录（如 131298/245865 同为凡人修仙传）只留第一条
            dedup.putIfAbsent(title, new DramaItem(title, "", poster, detailUrl, "mayi91", "mayi91",
                    "", picText, "link"));
        }
        return new ArrayList<>(dedup.values());
    }

    /** 中文逐字重叠检测：title 与 query 至少共享一个中文字符（英文/数字标题按包含判断） */
    static boolean hasCharOverlap(String title, String query) {
        if (title == null || query == null || query.isEmpty()) return true;
        if (title.contains(query) || query.contains(title)) return true;
        for (int i = 0; i < query.length(); i++) {
            char c = query.charAt(i);
            if (c >= 0x4e00 && c <= 0x9fff && title.indexOf(c) >= 0) return true;
        }
        return false;
    }

    /** JSON 字符串转义还原（\\uXXXX/\\"/\\\\/\\/） */
    private static String unescapeJson(String s) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(i + 1);
                if (n == 'u' && i + 5 < s.length()) {
                    out.append((char) Integer.parseInt(s.substring(i + 2, i + 6), 16));
                    i += 5;
                } else {
                    out.append(n);
                    i += 1;
                }
            } else {
                out.append(c);
            }
        }
        return out.toString();
    }

    /** 解析豆瓣 JSON 响应（分离 HTTP 供测试注入） */
    List<DramaItem> parseDoubanResponse(String json) throws Exception {
        JSONArray arr = new JSONArray(json);
        List<DramaItem> results = new ArrayList<>();
        int limit = Math.min(arr.length(), 4);
        for (int i = 0; i < limit; i++) {
            JSONObject item = arr.getJSONObject(i);
            String title = item.optString("title", "");
            String year = item.optString("year", "");
            String poster = "";
            JSONObject pic = item.optJSONObject("pic");
            if (pic != null) poster = pic.optString("normal", "");
            String itemUrl = item.optString("url", "");
            String type = item.optString("type", "");
            if (!"tv".equals(type) && !"movie".equals(type)) continue;
            String platform = inferPlatform(title);
            results.add(new DramaItem(title, year, poster, itemUrl, platform, "douban"));
        }
        return results;
    }

    /** 解析 DDG JSON 响应（分离 HTTP 供测试注入） */
    List<DramaItem> parseDDGResponse(String json) throws Exception {
        JSONObject resp = new JSONObject(json);
        List<DramaItem> results = new ArrayList<>();
        String abstractText = resp.optString("Abstract", "");
        String abstractUrl = resp.optString("AbstractURL", "");
        if (!abstractText.isEmpty() && abstractText.length() > 10) {
            String title = abstractText.length() > 40
                    ? abstractText.substring(0, 37) + "..." : abstractText;
            results.add(new DramaItem(title, "", "", abstractUrl, "", "ddg"));
        }
        JSONArray topics = resp.optJSONArray("RelatedTopics");
        if (topics != null) {
            int limit = Math.min(topics.length(), 3);
            for (int i = 0; i < limit; i++) {
                JSONObject topic = topics.optJSONObject(i);
                if (topic == null) continue;
                String text = topic.optString("Text", "");
                String turl = topic.optString("FirstURL", "");
                if (text.isEmpty()) continue;
                String title;
                int dash = text.indexOf(" — ");
                if (dash > 0) title = text.substring(0, dash);
                else title = text.length() > 40 ? text.substring(0, 37) + "..." : text;
                results.add(new DramaItem(title, "", "", turl, "", "ddg"));
            }
        }
        return results;
    }

    // ==================== DDG ====================

    List<DramaItem> tryDDG(String query) {  // package-private for test
        HttpURLConnection conn = null;
        try {
            String encoded = URLEncoder.encode(query + " 电视剧", "UTF-8");
            URL url = new URL(DDG_API + encoded);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(TIMEOUT_CONNECT_MS);
            conn.setReadTimeout(TIMEOUT_READ_MS);
            conn.setRequestProperty("User-Agent", "MOV/3.0 (Android)");
            conn.setRequestProperty("Accept", "application/json");

            int code = conn.getResponseCode();
            if (code != 200) {
                Log.w(TAG, "DDG 返回 " + code);
                return Collections.emptyList();
            }

            BufferedReader r = new BufferedReader(new InputStreamReader(
                    conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();

            JSONObject resp = new JSONObject(sb.toString());
            List<DramaItem> results = new ArrayList<>();

            // DDG Abstract: 可以作为一条结果
            String abstractText = resp.optString("Abstract", "");
            String abstractUrl = resp.optString("AbstractURL", "");
            if (!abstractText.isEmpty() && abstractText.length() > 10) {
                String title = abstractText.length() > 40
                        ? abstractText.substring(0, 37) + "..." : abstractText;
                results.add(new DramaItem(title, "", "", abstractUrl, "", "ddg"));
            }

            // RelatedTopics: 最多取 3 条
            JSONArray topics = resp.optJSONArray("RelatedTopics");
            if (topics != null) {
                int limit = Math.min(topics.length(), 3);
                for (int i = 0; i < limit; i++) {
                    JSONObject topic = topics.optJSONObject(i);
                    if (topic == null) continue;
                    String text = topic.optString("Text", "");
                    String turl = topic.optString("FirstURL", "");
                    if (text.isEmpty()) continue;
                    // DDG Text 格式："Title — Description"
                    String title;
                    int dash = text.indexOf(" — ");
                    if (dash > 0) title = text.substring(0, dash);
                    else title = text.length() > 40 ? text.substring(0, 37) + "..." : text;
                    results.add(new DramaItem(title, "", "", turl, "", "ddg"));
                }
            }
            return results;

        } catch (Exception e) {
            Log.w(TAG, "DDG 异常: " + e.getMessage());
            return Collections.emptyList();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    // ==================== 平台推测 ====================

    /**
     * 从剧名推测可能平台（Phase 2C 用简单关键词，后续可接真实平台数据库）。
     * 返回包名映射：bilibili / tencent / iqiyi / youku / ""（未知）
     */
    String inferPlatform(String title) {  // package-private for test
        if (title == null) return "";
        // B站 独播/热门（关键词列表来自 MOV 策略文档）
        if (title.contains("阿勒泰") || title.contains("三体") || title.contains("凡人")
                || title.contains("时光代理人") || title.contains("灵笼"))
            return "bilibili";
        // 腾讯视频
        if (title.contains("漫长的季节") || title.contains("庆余年") || title.contains("繁花")
                || title.contains("长相思") || title.contains("玉骨遥") || title.contains("西出玉门"))
            return "tencent";
        // 爱奇艺
        if (title.contains("狂飙") || title.contains("莲花楼") || title.contains("宁安如梦")
                || title.contains("长风渡") || title.contains("云之羽"))
            return "iqiyi";
        return "";
    }

    // ==================== 平台 deep link scheme ====================

    /** 平台 → Android package name */
    public static String platformToPackage(String platform) {
        if (platform == null) return null;
        switch (platform) {
            case "bilibili": return "tv.danmaku.bili";
            case "tencent":  return "com.tencent.qqlive";
            case "iqiyi":    return "com.qiyi.video";
            case "youku":    return "com.youku.phone";
            default:         return null;
        }
    }

    /** 平台 → HTTPS 降级 URL */
    public static String platformToWebUrl(String platform, String keyword) {
        if (keyword == null) keyword = "";
        String q = keyword.replace(" ", "+");
        switch (platform != null ? platform : "") {
            case "bilibili": return "https://search.bilibili.com/all?keyword=" + q;
            case "tencent":  return "https://v.qq.com/x/search/?q=" + q;
            case "iqiyi":    return "https://so.iqiyi.com/so/q_" + q;
            case "youku":    return "https://so.youku.com/search_video/q_" + q;
            default:         return "https://www.baidu.com/s?wd=" + q + "+电视剧";
        }
    }
}
