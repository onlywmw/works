/* ── MOV · 微信支付特约商户进件（工单 TASKS_WXPAY_APPLYMENT_M1）
   入口：设置 › 账户管理（renderAccount）→ 身份认证（renderVerify）→ 特约商户进件（renderForm 六步向导）
   桥契约（BridgeKernel，Java 侧已就绪）：
     query   {q:'partner.config.get'}                     → {ok,data:{baseUrl,hasToken,configured}}
     postCmd {cmd:'partner.config.set', baseUrl, token}   → {ok,data:{configured}}（同步；token 空串=清除）
     postCmd {cmd:'partner.applyment.submit', cbId, applyment}  → 异步 _hermesCb(cbId, envelope)
     postCmd {cmd:'partner.applyment.query', cbId, business_code} → 异步 _hermesCb(cbId, envelope)
     postCmd {cmd:'partner.applyment.uploadMedia', cbId, path}   → 异步 _hermesCb(cbId, {ok,data:{media_id}})
     B.pickFile(cb, 'r_applyment')                        → cb({roomPath,...}) 图片选择（已带 roomPath）
   红线：敏感值（身份证/银行卡/手机/邮箱/姓名）只存 S.F 内存，提交成功或退出后清空；
        禁 localStorage/journal/console.log；渲染用户值必须 esc()。 */
window.MovApplyment = (function() {

  /* ═══ 工具 ═══ */

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }
  function toast(m) { try { if (typeof B !== 'undefined' && B.toast) B.toast(m); } catch(e) {} }
  /* 同修⑤：真桥判 B.present（演示模式 b=null → present 为 null，避免 submit 卡死） */
  function hasBridge() { return typeof B !== 'undefined' && !!B.present; }
  function refresh() { try { NewFace.redrawSettings(); } catch(e) {} }
  function val(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; }
  function setVal(id, v) { var el = document.getElementById(id); if (el) el.value = v == null ? '' : v; }
  function checked(id) { var el = document.getElementById(id); return !!(el && el.checked); }
  function radioVal(name) {
    var els = document.querySelectorAll('input[name="' + name + '"]:checked');
    return els.length ? els[0].value : '';
  }

  /* ═══ 状态（敏感字段只进内存，红线） ═══ */

  var S = {
    cfg: { baseUrl:'', hasToken:false, configured:false },
    step: 0,          // 0..6
    F: {},            // 扁平字段值，key = 微信 JSON dot-path
    img: {},          // path → {name, status:'uploading'|'ok'|'fail', media_id, err}
    scenes: [],       // 经营场景多选
    submitting: false,
    result: null,
    qRes: null,
    rec: null         // localStorage 'mv:applyment:rec'（非敏感：business_code/applyment_id/state/submittedAt）
  };
  var REC_KEY = 'mv:applyment:rec';

  function loadRec() {
    try {
      var raw = localStorage.getItem(REC_KEY);
      S.rec = raw ? JSON.parse(raw) : null;
    } catch(e) { S.rec = null; }
  }
  function saveRec(o) {
    try { localStorage.setItem(REC_KEY, JSON.stringify(o)); S.rec = o; } catch(e) {}
  }

  /* ═══ 桥（cbId 异步，照 bridge.js nextCbId/_cbMap 全局） ═══ */

  function _call(obj, cb) {
    var id = nextCbId(); _cbMap[id] = cb; obj.cbId = id; B.postCmd(obj);
  }
  function _queryCfg() {
    try {
      var r = B.query({q:'partner.config.get'});
      if (r && r.ok && r.data) S.cfg = { baseUrl:r.data.baseUrl||'', hasToken:!!r.data.hasToken, configured:!!r.data.configured };
    } catch(e) { S.cfg = { baseUrl:'', hasToken:false, configured:false }; }
  }

  /* ═══ 渲染：账户管理 ═══ */

  function renderAccount() {
    var html = '';   /* 外层 settingsTopbar 已提供标题栏（双标题修复） */
    html += '<div class="set-group">'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'verify\')"><div class="t">身份认证</div>'
      + '<div class="v">' + verifySummary() + '</div><div class="chev">›</div></div>'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'merchant\')"><div class="t">商户收款</div><div class="v">微信支付直连</div><div class="chev">›</div></div>'
      + '<div class="set-row" onclick="NewFace.settingsGo(\'ability\')"><div class="t">我的能力</div>'
      + '<div class="v">' + (window.MovGig ? window.MovGig.summary() : '未开通') + '</div><div class="chev">›</div></div>'
      + '<div class="set-row static"><div class="t">账户类型</div><div class="v">本地用户</div></div>'
      + '</div>'
      + '<div class="note">账号体系施工中：当前为本机单用户，对话 / 追剧 / 文件全部只存本机，不上传云端。</div>';
    return html;
  }

  function verifySummary() {
    if (!S.rec) return '商家认证 · 未认证';
    return stateText(S.rec.state);
  }

  /* ═══ 渲染：身份认证（一页两区） ═══ */

  function renderVerify() {
    var html = '';   /* 外层 settingsTopbar 已提供标题栏（双标题修复） */

    /* 区① 个人认证 */
    html += '<div class="set-sub" style="padding-top:12px">个人认证</div>';
    html += '<div class="set-group">'
      + '<div class="set-row static"><div class="t">手机号验证</div><div class="v">即将上线</div></div>'
      + '</div>';

    /* 区② 商家认证 */
    html += '<div class="set-sub" style="padding-top:12px">商家认证 · 微信支付特约商户进件</div>';
    var r = S.rec;
    if (r) {
      html += '<div class="set-group">'
        + '<div class="set-row static"><div class="t">① 提交进件资料</div><div class="v">✓ 已提交</div></div>'
        + '<div class="set-row static"><div class="t">② 微信支付审核</div><div class="v">' + stateText(r.state) + '</div></div>'
        + '<div class="set-row static"><div class="t">③ 签约开通</div><div class="v">' + signText(r) + '</div></div>'
        + (r.state === 'REJECTED' && r.reject_reason
            ? '<div class="set-row static"><div class="t">驳回原因</div><div class="v" style="color:#c0392b">' + esc(r.reject_reason) + '</div></div>' : '')
        + '<div class="set-row static"><div class="t">申请单号</div><div class="v" style="font-size:11px">' + esc(r.business_code || '') + '</div></div>'
        + '<div class="set-row" onclick="MovApplyment.gotoForm()"><div class="t">' + (r.state === 'EDITING' ? '继续填写申请单' : '新建申请单') + '</div><div class="chev">›</div></div>'
        + '</div>'
        + '<div class="mk-buybar" style="margin-top:10px"><span class="dact" onclick="MovApplyment.queryStatus()">刷新状态</span></div>'
        + '<div id="mvQRes" style="margin-top:8px"></div>';
    } else {
      html += '<div class="set-group">'
        + '<div class="set-row static"><div class="t">① 提交进件资料</div><div class="v">未提交</div></div>'
        + '<div class="set-row static"><div class="t">② 微信支付审核</div><div class="v">—</div></div>'
        + '<div class="set-row static"><div class="t">③ 签约开通</div><div class="v">—</div></div>'
        + '</div>'
        + '<div class="mk-buybar" style="margin-top:10px"><span class="dact" onclick="MovApplyment.gotoForm()">新建/继续填写申请单</span></div>';
    }
    html += '<div class="note">个人职业人无执照请走小微商户进件，非本接口（v1 不覆盖）。</div>';
    return html;
  }

  function stateText(st) {
    if (st === 'FINISHED') return '✓ 通过';
    if (st === 'APPLYMENT_STATE_AUDITING') return '审核中…';
    if (st === 'REJECTED') return '已驳回';
    if (st === 'CANCELED') return '已作废';
    return '待提交';
  }
  function signText(r) {
    if (r.state === 'FINISHED') return r.sign_url ? '待签约（见审核通过提示）' : '待签约';
    if (r.state === 'APPLYMENT_STATE_AUDITING') return '待审核通过';
    return '—';
  }

  function gotoForm() { S.step = 0; S.result = null; NewFace.settingsGo('applyment'); }

  /** 刷新状态（有记录时）：query → 更新 rec + 重渲染 */
  function queryStatus() {
    if (!S.rec) return;
    if (!hasBridge()) { toast('桥不可用'); return; }
    var box = document.getElementById('mvQRes');
    if (box) box.innerHTML = '<div class="note">查询中…</div>';
    _call({cmd:'partner.applyment.query', business_code:S.rec.business_code}, function(r) {
      if (!box) return;
      if (r && r.ok && r.data) {
        var d = r.data;
        saveRec({ business_code:S.rec.business_code, applyment_id:d.applyment_id || S.rec.applyment_id,
          state:d.applyment_state || S.rec.state, submittedAt:S.rec.submittedAt,
          reject_reason:d.reject_reason || '', sign_url:d.sign_url || '' });
        box.innerHTML = '<div class="note" style="color:var(--ok,#2e8b57)">状态：' + esc(stateText(S.rec.state)) + '</div>';
        setTimeout(refresh, 600);
      } else {
        var m = (r && r.error && r.error.msg) ? r.error.msg : '查询失败';
        box.innerHTML = '<div class="note" style="color:#c0392b">' + esc(m) + '</div>';
      }
    });
  }

  /* ═══ 渲染：六步表单（顶部配置卡 + 向导） ═══ */

  var STEP_TITLES = ['主体类型','超级管理员','主体+法人证件','经营资料','结算','银行账户','预览提交'];

  function renderForm() {
    var html = '';   /* 外层 settingsTopbar 已提供标题栏（双标题修复） */

    /* 顶部后端配置卡 */
    html += '<div class="set-group">'
      + '<div class="set-row static"><div class="t">进件后端</div>'
      + '<div class="v">' + (S.cfg.configured ? '已配置 ✓' : '未配置') + '</div></div>'
      + '<div id="mvCfgBody">'
      + (S.cfg.configured
          ? ''
          : '<div class="set-row" onclick="MovApplyment.cfgToggle()"><div class="t">配置服务器地址 + 令牌</div><div class="chev">›</div></div>')
      + '</div>'
      + '<div id="mvCfgEdit" style="display:none;padding:0 12px 12px">'
      + '<input id="mvCfgUrl" placeholder="后端地址（如 https://mow.kim:8390）">'
      + '<input id="mvCfgToken" type="password" placeholder="访问令牌（传空串 = 清除）">'
      + '<div class="mk-buybar" style="margin-top:8px"><span class="dact" onclick="MovApplyment.cfgSave()">保存配置</span></div>'
      + '</div>'
      + '</div>';

    /* 错误条 */
    if (S.result && !S.result.ok) {
      html += '<div id="mvErr" class="note" style="color:#c0392b;background:rgba(192,57,43,.08);padding:10px;border-radius:8px;margin:10px 0">'
        + esc(S.result.error && S.result.error.code ? ('[' + S.result.error.code + '] ') : '')
        + esc(S.result.error && S.result.error.msg ? S.result.error.msg : '提交失败') + '</div>';
    }

    /* 步骤指示 */
    html += '<div class="set-sub" style="padding-top:12px">第 ' + (S.step + 1) + ' / 7 步 · ' + STEP_TITLES[S.step] + '</div>';

    /* 当前步 */
    html += '<div class="set-group">' + renderStep(S.step) + '</div>';

    /* 步进按钮 */
    html += '<div class="mk-buybar" style="margin-top:10px;display:flex;gap:8px">';
    if (S.step > 0) {
      html += '<span class="bb ghost" style="flex:1;text-align:center;padding:10px 0;border-radius:10px;border:1px solid rgba(0,0,0,.15)" onclick="MovApplyment.prevStep()">上一步</span>';
    }
    if (S.step < 6) {
      html += '<span class="bb solid" style="flex:2;text-align:center;padding:10px 0;border-radius:10px;background:var(--accent,#3b82f6);color:#fff;font-weight:600" onclick="MovApplyment.nextStep()">下一步</span>';
    } else {
      html += '<span id="mvSubmitBtn" class="bb solid" style="flex:2;text-align:center;padding:10px 0;border-radius:10px;background:var(--accent,#3b82f6);color:#fff;font-weight:600" onclick="MovApplyment.submit()">确认提交</span>';
    }
    html += '</div>';

    /* v1 不做备注 */
    html += '<div class="note" style="margin-top:8px">v1 暂不支持：企业多受益人（ubo_info_list）、补充材料（addition_info）、金融机构许可证、非法人证件类型、小微进件。</div>';
    return html;
  }

  /* ═══ 渲染：单步 ═══ */

  function renderStep(n) {
    switch (n) {
      case 0: return renderStep0();
      case 1: return renderStep1();
      case 2: return renderStep2();
      case 3: return renderStep3();
      case 4: return renderStep4();
      case 5: return renderStep5();
      case 6: return renderStep6();
    }
    return '<div class="note">未知步骤</div>';
  }

  /* 步0 主体类型 */
  function renderStep0() {
    var t = S.F['subject_info.subject_type'] || 'INDIVIDUAL';
    var types = [['INDIVIDUAL','个体户'],['ENTERPRISE','企业'],['GOVERNMENT','政府机关'],['INSTITUTIONS','事业单位'],['OTHERS','社会组织']];
    var html = '';
    types.forEach(function(pair) {
      html += '<div class="set-row" onclick="MovApplyment.pickSubjectType(\'' + pair[0] + '\')">'
        + '<div class="t">' + pair[1] + '</div>'
        + '<div class="v">' + (t === pair[0] ? '●' : '○') + '</div></div>';
    });
    html += '<div class="set-row" onclick="MovApplyment.toggleFinance()"><div class="t">金融机构</div>'
      + '<div class="v"><span class="switch' + (S.F['subject_info.finance_institution'] ? ' on' : '') + '" id="mvFin"></span></div></div>';
    return html;
  }

  /* 步1 超级管理员 */
  function renderStep1() {
    var ct = S.F['contact_info.contact_type'] || 'LEGAL';
    var html = '';
    html += '<div class="set-row" onclick="MovApplyment.pickContactType(\'LEGAL\')"><div class="t">经营者/法定代表人</div><div class="v">' + (ct === 'LEGAL' ? '●' : '○') + '</div></div>';
    html += '<div class="set-row" onclick="MovApplyment.pickContactType(\'SUPER\')"><div class="t">经办人</div><div class="v">' + (ct === 'SUPER' ? '●' : '○') + '</div></div>';
    html += textField('contact_info.contact_name', '姓名', true);
    html += textField('contact_info.mobile_phone', '手机号', true);
    html += textField('contact_info.contact_email', '邮箱', true);
    if (ct === 'SUPER') {
      html += '<div class="set-sub" style="padding-top:8px">经办人证件（SUPER 必填）</div>';
      html += selectField('contact_info.contact_id_doc_type', '证件类型', [
        ['IDENTIFICATION_TYPE_MAINLAND_IDCARD','大陆身份证'],['IDENTIFICATION_TYPE_OVERSEA_PASSPORT','护照'],
        ['IDENTIFICATION_TYPE_HONGKONG','港澳通行证'],['IDENTIFICATION_TYPE_MACAO','澳门通行证'],
        ['IDENTIFICATION_TYPE_TAIWAN','台湾通行证'],['IDENTIFICATION_TYPE_FOREIGN_RESIDENT','外国居民身份证'],
        ['IDENTIFICATION_TYPE_HOME_VISIT','回乡证'],['IDENTIFICATION_TYPE_OTHER','其他']]);
      html += textField('contact_info.contact_id_number', '证件号码', true);
      html += imgField('contact_info.contact_id_doc_copy', '证件正面照', true);
      html += imgField('contact_info.contact_id_doc_copy_back', '证件反面照', true);
      html += textField('contact_info.contact_period_begin', '证件开始日期', false, 'yyyy-MM-dd');
      html += textField('contact_info.contact_period_end', '证件结束日期', false, 'yyyy-MM-dd，长期填"长期"');
    }
    return html;
  }

  /* 步2 主体+法人证件 */
  function renderStep2() {
    var subj = S.F['subject_info.subject_type'] || 'INDIVIDUAL';
    var bizLike = (subj === 'INDIVIDUAL' || subj === 'ENTERPRISE');
    var html = '';
    if (bizLike) {
      html += '<div class="set-sub" style="padding-top:8px">营业执照</div>';
      html += imgField('subject_info.business_license_info.license_copy', '营业执照照片', true);
      html += textField('subject_info.business_license_info.license_number', '营业执照注册号', true);
      html += textField('subject_info.business_license_info.merchant_name', '商户名称', true);
      html += textField('subject_info.business_license_info.legal_person', '经营者/法定代表人', true);
      html += textField('subject_info.business_license_info.license_address', '注册地址', false);
      html += textField('subject_info.business_license_info.period_begin', '营业开始日期', false, 'yyyy-MM-dd');
      html += textField('subject_info.business_license_info.period_end', '营业结束日期', false, 'yyyy-MM-dd，长期填"长期"');
    } else {
      html += '<div class="set-sub" style="padding-top:8px">登记证书</div>';
      html += imgField('subject_info.certificate_info.cert_copy', '登记证书照片', true);
      html += selectField('subject_info.certificate_info.cert_type', '证书类型', [
        ['2388','统一社会信用代码证书'],['2389','事业单位法人证书'],['2394','社会团体法人登记证书'],
        ['2395','民办非企业单位登记证书'],['2396','基金会法人登记证书'],['2520','政府机关'],['2521','机关非法人'],
        ['2522','机关法人'],['2399','其他'],['2400','宗教活动场所登记证']]);
      html += textField('subject_info.certificate_info.cert_number', '证书编号', true);
      html += textField('subject_info.certificate_info.merchant_name', '商户名称', true);
      html += textField('subject_info.certificate_info.company_address', '单位地址', true);
      html += textField('subject_info.certificate_info.legal_person', '法定代表人', true);
      html += textField('subject_info.certificate_info.period_begin', '有效期开始', true, 'yyyy-MM-dd');
      html += textField('subject_info.certificate_info.period_end', '有效期结束', true, 'yyyy-MM-dd，长期填"长期"');
    }
    html += '<div class="set-sub" style="padding-top:8px">法人/经办人身份证（v1 仅大陆身份证）</div>';
    html += imgField('subject_info.identity_info.id_card_info.id_card_copy', '身份证人像面', true);
    html += imgField('subject_info.identity_info.id_card_info.id_card_national', '身份证国徽面', true);
    html += textField('subject_info.identity_info.id_card_info.id_card_name', '姓名', true);
    html += textField('subject_info.identity_info.id_card_info.id_card_number', '身份证号', true);
    html += textField('subject_info.identity_info.id_card_info.card_period_begin', '身份证开始日期', true, 'yyyy-MM-dd');
    html += textField('subject_info.identity_info.id_card_info.card_period_end', '身份证结束日期', true, 'yyyy-MM-dd，长期填"长期"');
    if (subj === 'ENTERPRISE') {
      html += textField('subject_info.identity_info.id_card_info.id_card_address', '身份证地址', true);
    }
    return html;
  }

  /* 步3 经营资料 */
  function renderStep3() {
    var html = '';
    html += textField('business_info.merchant_shortname', '商户简称', true, '在支付账单中展示的名称');
    html += textField('business_info.service_phone', '客服电话', true);
    html += '<div class="set-sub" style="padding-top:8px">经营场景（可多选）</div>';
    var scenes = [['STORE','线下门店'],['MP','公众号'],['MINI_PROGRAM','小程序'],['WEB','网站'],['APP','APP'],['WEWORK','企业微信']];
    scenes.forEach(function(pair) {
      var on = S.scenes.indexOf(pair[0]) >= 0;
      html += '<div class="set-row" onclick="MovApplyment.toggleScene(\'' + pair[0] + '\')">'
        + '<div class="t">' + pair[1] + '</div><div class="v">' + (on ? '☑' : '☐') + '</div></div>';
    });
    S.scenes.forEach(function(sc) {
      if (sc === 'STORE') {
        html += '<div class="set-sub" style="padding-top:8px">线下门店</div>';
        html += textField('business_info.sales_info.biz_store_info.biz_store_name', '门店名称', true);
        html += textField('business_info.sales_info.biz_store_info.biz_address_code', '门店省市编码', true, '6 位地区码，如 440300');
        html += textField('business_info.sales_info.biz_store_info.biz_store_address', '门店详细地址', true);
        html += imgField('business_info.sales_info.biz_store_info.store_entrance_pic', '门店门口照片', true);
        html += imgField('business_info.sales_info.biz_store_info.indoor_pic', '门店内景照片', true);
        html += textField('business_info.sales_info.biz_store_info.biz_sub_appid', '门店子商户 AppID', false);
      } else if (sc === 'MP') {
        html += '<div class="set-sub" style="padding-top:8px">公众号</div>';
        html += textField('business_info.sales_info.mp_info.mp_appid', '公众号 AppID', false, '与 mp_sub_appid 二选一');
        html += textField('business_info.sales_info.mp_info.mp_sub_appid', '公众号子商户 AppID', false);
        html += imgField('business_info.sales_info.mp_info.mp_pics', '公众号截图', true);
      } else if (sc === 'MINI_PROGRAM') {
        html += '<div class="set-sub" style="padding-top:8px">小程序</div>';
        html += textField('business_info.sales_info.mini_program_info.mini_program_appid', '小程序 AppID', false, '与 _sub_appid 二选一');
        html += textField('business_info.sales_info.mini_program_info.mini_program_sub_appid', '小程序子商户 AppID', false);
        html += imgField('business_info.sales_info.mini_program_info.mini_program_pics', '小程序截图', false);
      } else if (sc === 'WEB') {
        html += '<div class="set-sub" style="padding-top:8px">网站</div>';
        html += textField('business_info.sales_info.web_info.domain', '网站域名', true);
        html += imgField('business_info.sales_info.web_info.web_authorisation', '网站授权书', false);
        html += textField('business_info.sales_info.web_info.web_appid', '网站 AppID', false);
      } else if (sc === 'APP') {
        html += '<div class="set-sub" style="padding-top:8px">APP</div>';
        html += textField('business_info.sales_info.app_info.app_appid', 'APP AppID', false, '与 app_sub_appid 二选一');
        html += textField('business_info.sales_info.app_info.app_sub_appid', 'APP 子商户 AppID', false);
        html += imgField('business_info.sales_info.app_info.app_pics', 'APP 截图', true, '首页/尾页/应用内/支付页各 1 张（v1 逐张添加）');
      } else if (sc === 'WEWORK') {
        html += '<div class="set-sub" style="padding-top:8px">企业微信</div>';
        html += textField('business_info.sales_info.wework_info.sub_corp_id', '企业微信 CorpID', true);
        html += imgField('business_info.sales_info.wework_info.wework_pics', '企业微信截图', true);
      }
    });
    return html;
  }

  /* 步4 结算 */
  function renderStep4() {
    var html = '';
    html += textField('settlement_info.settlement_id', '结算规则 ID', true, '商户平台结算规则 ID');
    html += textField('settlement_info.qualification_type', '结算资质类型', true, '如 86-餐饮，见微信文档');
    html += imgField('settlement_info.qualifications', '结算资质证明', false);
    html += textField('settlement_info.activities_id', '经营许可证 ID', false);
    return html;
  }

  /* 步5 银行账户 */
  function renderStep5() {
    var at = S.F['bank_account_info.bank_account_type'] || 'CORPORATE';
    var html = '';
    html += '<div class="set-row" onclick="MovApplyment.pickBankType(\'CORPORATE\')"><div class="t">对公账户</div><div class="v">' + (at === 'CORPORATE' ? '●' : '○') + '</div></div>';
    html += '<div class="set-row" onclick="MovApplyment.pickBankType(\'PERSONAL\')"><div class="t">经营者个人卡（个体户）</div><div class="v">' + (at === 'PERSONAL' ? '●' : '○') + '</div></div>';
    html += textField('bank_account_info.account_name', '开户名称', true);
    html += textField('bank_account_info.account_bank', '开户银行', true, '如 中国工商银行');
    html += textField('bank_account_info.bank_name', '开户支行（选填）', false);
    html += textField('bank_account_info.account_number', '银行账号', true);
    return html;
  }

  /* 步6 预览提交（掩码汇总） */
  function renderStep6() {
    var html = '<div class="note" style="margin-bottom:8px">提交前请核对（敏感字段已掩码）：</div>';
    html += maskRow('主体类型', subjText());
    html += maskRow('经营者/法人', maskName(S.F['contact_info.contact_name']));
    html += maskRow('手机号', maskPhone(S.F['contact_info.mobile_phone']));
    html += maskRow('邮箱', maskEmail(S.F['contact_info.contact_email']));
    html += maskRow('商户名称', esc(S.F['business_info.merchant_shortname'] || S.F['subject_info.business_license_info.merchant_name'] || S.F['subject_info.certificate_info.merchant_name']));
    html += maskRow('证件号', maskId(S.F['subject_info.identity_info.id_card_info.id_card_number'] || S.F['contact_info.contact_id_number']));
    html += maskRow('银行账号', maskBank(S.F['bank_account_info.account_number']));
    html += maskRow('结算规则', esc(S.F['settlement_info.settlement_id']));
    html += maskRow('经营场景', S.scenes.join('、') || '—');
    return html;
  }
  /* 必修③：掩码输出过 esc()（姓名填 <x> 不得注入） */
  function maskRow(k, v) {
    return '<div class="set-row static"><div class="t">' + esc(k) + '</div><div class="v" style="font-size:12px">' + (v || '—') + '</div></div>';
  }
  function subjText() {
    var map = { INDIVIDUAL:'个体户', ENTERPRISE:'企业', GOVERNMENT:'政府机关', INSTITUTIONS:'事业单位', OTHERS:'社会组织' };
    return map[S.F['subject_info.subject_type']] || '—';
  }
  function maskName(s) { return s ? esc(s.slice(0,1) + '**' + s.slice(-1)) : ''; }
  function maskPhone(s) { return s ? esc(s.slice(0,3) + '****' + s.slice(-4)) : ''; }
  function maskEmail(s) { if (!s) return ''; var i = s.indexOf('@'); return i > 0 ? esc(s.slice(0,1) + '***' + s.slice(i-1)) : '***'; }
  function maskId(s) { return s ? esc(s.slice(0,4) + '**********' + s.slice(-4)) : ''; }
  function maskBank(s) { return s ? esc(s.slice(0,4) + '****' + s.slice(-4)) : ''; }

  /* ═══ 表单控件 ═══ */

  function textField(path, label, req, hint) {
    return '<div class="set-row static"><div class="t">' + label + (req ? ' <span style="color:#c0392b">*</span>' : '')
      + (hint ? '<div class="sub">' + esc(hint) + '</div>' : '') + '</div>'
      + '<div class="v"><input data-p="' + path + '" value="' + esc(S.F[path] || '') + '" style="width:140px;border:1px solid rgba(0,0,0,.12);border-radius:6px;padding:6px 8px;font-size:12px"></div></div>';
  }

  function selectField(path, label, opts) {
    var v = S.F[path] || '';
    var html = '<div class="set-row static"><div class="t">' + esc(label) + ' <span style="color:#c0392b">*</span></div>'
      + '<div class="v"><select data-p="' + path + '" style="border:1px solid rgba(0,0,0,.12);border-radius:6px;padding:6px;font-size:12px">';
    html += '<option value="">请选择</option>';
    opts.forEach(function(p) { html += '<option value="' + p[0] + '"' + (v === p[0] ? ' selected' : '') + '>' + esc(p[1]) + '</option>'; });
    html += '</select></div></div>';
    return html;
  }

  function imgField(path, label, req, hint) {
    var im = S.img[path];
    var st = '';
    if (im) {
      st = im.status === 'uploading' ? '<span style="color:#888">上传中…</span>'
        : im.status === 'ok' ? '<span style="color:#2e8b57">✓ ' + esc(im.name) + '</span>'
        : '<span style="color:#c0392b">上传失败 ' + esc(im.err || '') + '</span>';
    }
    return '<div class="set-row static" data-img="1" data-p="' + path + '"><div class="t">' + esc(label) + (req ? ' <span style="color:#c0392b">*</span>' : '')
      + (hint ? '<div class="sub">' + esc(hint) + '</div>' : '') + '</div>'
      + '<div class="v"><span>' + st + '</span>'
      + ' <span class="dact" onclick="MovApplyment.pickImg(\'' + path + '\')">选择图片</span></div></div>';
  }

  /* ═══ 动作 ═══ */

  function pickSubjectType(t) { S.F['subject_info.subject_type'] = t; refresh(); }
  function toggleFinance() {
    S.F['subject_info.finance_institution'] = !S.F['subject_info.finance_institution'];
    refresh();
  }
  function pickContactType(t) { S.F['contact_info.contact_type'] = t; refresh(); }
  function pickBankType(t) { S.F['bank_account_info.bank_account_type'] = t; refresh(); }
  function toggleScene(sc) {
    var i = S.scenes.indexOf(sc);
    if (i >= 0) S.scenes.splice(i, 1); else S.scenes.push(sc);
    refresh();
  }

  /** 图片选择 + 上传（B.pickFile 带 roomPath → uploadMedia → media_id） */
  function pickImg(path) {
    if (!hasBridge() || !B.pickFile) { toast('图片选择不可用'); return; }
    S.img[path] = { name:'选择中…', status:'uploading' };
    refresh();
    B.pickFile(function(info) {
      if (!info || !info.roomPath) {
        S.img[path] = { name:'', status:'fail', err: info && info.error ? info.error : '未取到文件' };
        refresh();
        return;
      }
      S.img[path] = { name: info.name || '图片', status:'uploading' };
      refresh();
      _call({cmd:'partner.applyment.uploadMedia', path:info.roomPath}, function(r) {
        if (r && r.ok && r.data && r.data.media_id) {
          S.img[path].status = 'ok';
          S.img[path].media_id = r.data.media_id;
        } else {
          S.img[path].status = 'fail';
          S.img[path].err = (r && r.error && r.error.msg) ? r.error.msg : '上传失败';
        }
        refresh();
      });
    }, 'r_applyment');
  }

  /* ═══ 表单收集 + 校验 ═══ */

  /** 从 DOM 收集当前步输入（必修①：data-p 属性直读路径，删 id 编解码） */
  function collect() {
    var els = document.querySelectorAll('#settingsPane [data-p]');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      var p = el.getAttribute('data-p');
      if (!p) continue;
      if (el.tagName === 'INPUT' || el.tagName === 'SELECT') {
        S.F[p] = el.value.trim();
      }
      /* 图片行（data-img）不读值：状态在 S.img */
    }
  }

  /* 每步必填校验：当前步渲染的可见字段 + 图片 */
  var STEP_REQ = [
    [],  // 步0：主体类型单选恒有值
    ['contact_info.contact_name','contact_info.mobile_phone','contact_info.contact_email'],
    [],  // 步2 按主体类型动态
    ['business_info.merchant_shortname','business_info.service_phone'],
    ['settlement_info.settlement_id','settlement_info.qualification_type'],
    ['bank_account_info.account_name','bank_account_info.account_bank','bank_account_info.account_number'],
    []   // 步6 提交
  ];

  function requiredOf(step) {
    var list = [];
    function add(p) {
      /* 必修①：data-p 属性直查元素（当前步可见才存在） */
      var el = document.querySelector('#settingsPane [data-p="' + p + '"]');
      if (el) list.push(p);
    }
    /* 必修②：图片必填直接查 S.img[path].status，不走 DOM */
    function addImg(p) {
      list.push('img:' + p);
    }
    (STEP_REQ[step] || []).forEach(add);
    if (step === 1 && S.F['contact_info.contact_type'] === 'SUPER') {
      ['contact_info.contact_id_doc_type','contact_info.contact_id_number'].forEach(add);
      addImg('contact_info.contact_id_doc_copy');
      addImg('contact_info.contact_id_doc_copy_back');
    }
    if (step === 2) {
      var subj = S.F['subject_info.subject_type'] || 'INDIVIDUAL';
      if (subj === 'INDIVIDUAL' || subj === 'ENTERPRISE') {
        ['subject_info.business_license_info.license_copy','subject_info.business_license_info.license_number',
         'subject_info.business_license_info.merchant_name','subject_info.business_license_info.legal_person'].forEach(add);
        addImg('subject_info.business_license_info.license_copy');
      } else {
        ['subject_info.certificate_info.cert_copy','subject_info.certificate_info.cert_type',
         'subject_info.certificate_info.cert_number','subject_info.certificate_info.merchant_name',
         'subject_info.certificate_info.company_address','subject_info.certificate_info.legal_person',
         'subject_info.certificate_info.period_begin','subject_info.certificate_info.period_end'].forEach(add);
        addImg('subject_info.certificate_info.cert_copy');
      }
      ['subject_info.identity_info.id_card_info.id_card_copy','subject_info.identity_info.id_card_info.id_card_national',
       'subject_info.identity_info.id_card_info.id_card_name','subject_info.identity_info.id_card_info.id_card_number',
       'subject_info.identity_info.id_card_info.card_period_begin','subject_info.identity_info.id_card_info.card_period_end'].forEach(add);
      addImg('subject_info.identity_info.id_card_info.id_card_copy');
      addImg('subject_info.identity_info.id_card_info.id_card_national');
      if (subj === 'ENTERPRISE') add('subject_info.identity_info.id_card_info.id_card_address');
    }
    if (step === 3) {
      S.scenes.forEach(function(sc) {
        if (sc === 'STORE') { ['business_info.sales_info.biz_store_info.biz_store_name','business_info.sales_info.biz_store_info.biz_address_code','business_info.sales_info.biz_store_info.biz_store_address'].forEach(add);
          addImg('business_info.sales_info.biz_store_info.store_entrance_pic'); addImg('business_info.sales_info.biz_store_info.indoor_pic'); }
        else if (sc === 'MP') { addImg('business_info.sales_info.mp_info.mp_pics'); }
        else if (sc === 'MINI_PROGRAM') { /* mini_program_pics 选填 */ }
        else if (sc === 'WEB') { add('business_info.sales_info.web_info.domain'); }
        else if (sc === 'APP') { addImg('business_info.sales_info.app_info.app_pics'); }
        else if (sc === 'WEWORK') { add('business_info.sales_info.wework_info.sub_corp_id'); addImg('business_info.sales_info.wework_info.wework_pics'); }
      });
    }
    return list;
  }

  function nextStep() {
    collect();
    var miss = [];
    requiredOf(S.step).forEach(function(p) {
      if (p.indexOf('img:') === 0) {
        var im = S.img[p.slice(4)];
        if (!im || im.status !== 'ok') miss.push(p.slice(4));
      } else {
        if (!S.F[p]) miss.push(p);
      }
    });
    if (miss.length) {
      toast('请补全必填项：' + miss.join('、'));
      return;
    }
    S.step++;
    S.result = null;
    refresh();
  }
  function prevStep() {
    collect();
    if (S.step > 0) S.step--;
    S.result = null;
    refresh();
  }

  /* ═══ 组装 + 提交 ═══ */

  /** setPath：'a.b.c' → {a:{b:{c:v}}} */
  function setPath(root, path, v) {
    var parts = path.split('.');
    var cur = root;
    for (var i = 0; i < parts.length - 1; i++) {
      if (!cur[parts[i]] || typeof cur[parts[i]] !== 'object') cur[parts[i]] = {};
      cur = cur[parts[i]];
    }
    cur[parts[parts.length - 1]] = v;
  }

  function assemble() {
    collect();
    var root = {};
    Object.keys(S.F).forEach(function(p) {
      var v = S.F[p];
      if (v === '' || v == null) return;   // 空值不上送
      setPath(root, p, v);                 // 布尔（finance_institution）原样上送
    });
    /* 图片字段：media_id 替换 */
    Object.keys(S.img).forEach(function(p) {
      var im = S.img[p];
      if (im && im.status === 'ok' && im.media_id) {
        setPath(root, p, [im.media_id]);   // 数组型图片输出 [media_id]
      }
    });
    /* 经营场景数组 */
    if (S.scenes.length) setPath(root, 'sales_info.sales_scenes_type', S.scenes.slice());
    return root;
  }

  function submit() {
    if (S.submitting) return;   // 提交中禁重复点击
    collect();
    /* 必修②：全链图片检查——所有渲染过的必填图片（S.img 中任何非 ok 项 + 未选即缺失） */
    var miss = [];
    Object.keys(S.img).forEach(function(p) {
      if (S.img[p].status !== 'ok') miss.push(p);
    });
    if (miss.length) { toast('有图片未上传完成：' + miss.join('、')); return; }
    if (!hasBridge()) { toast('桥不可用'); return; }
    S.submitting = true;
    var btn = document.getElementById('mvSubmitBtn');
    if (btn) btn.textContent = '提交中…';
    var applyment = assemble();
    /* business_code 放 applyment 根对象（后端从 applyment JSON 读取，2026-08-09 实测） */
    applyment.business_code = 'MOV_' + Date.now();
    _call({cmd:'partner.applyment.submit', applyment:applyment}, function(r) {
      S.submitting = false;
      if (btn) btn.textContent = '确认提交';
      if (r && r.ok && r.data && r.data.applyment_id) {
        saveRec({ business_code:applyment.business_code, applyment_id:r.data.applyment_id,
          state:'APPLYMENT_STATE_AUDITING', submittedAt:Date.now() });
        /* 提交成功：清空内存敏感字段 + 图片 + 场景，跳回身份认证页 */
        S.F = {}; S.img = {}; S.scenes = []; S.step = 0; S.result = null;
        toast('进件已提交，等待微信审核');
        NewFace.settingsGo('verify');
        setTimeout(refresh, 300);
      } else {
        var code = r && r.error && r.error.code ? r.error.code : '';
        var msg = r && r.error && r.error.msg ? r.error.msg : '提交失败';
        S.result = { ok:false, error:{ code:code, msg:msg } };
        if (code === 'PROCESSING') {
          S.result.error.msg = '已有进行中申请单，可去身份认证页刷新状态';
        }
        refresh();
      }
    });
  }

  /* ═══ 配置卡 ═══ */

  function cfgToggle() {
    var el = document.getElementById('mvCfgEdit');
    if (el) { el.style.display = el.style.display === 'none' ? 'block' : 'none'; }
  }
  function cfgSave() {
    if (!hasBridge()) { toast('桥不可用'); return; }
    var url = val('mvCfgUrl');
    var token = val('mvCfgToken');
    var r;
    try { r = B.postCmd({cmd:'partner.config.set', baseUrl:url, token:token}); } catch(e) { r = null; }
    if (r && r.ok && r.data) {
      S.cfg.configured = !!r.data.configured;
      _queryCfg();
      toast(S.cfg.configured ? '配置已保存' : '配置已清除');
      var edit = document.getElementById('mvCfgEdit');
      if (edit) edit.style.display = 'none';
      setVal('mvCfgUrl', ''); setVal('mvCfgToken', '');
      refresh();
    } else {
      toast((r && r.error && r.error.msg) ? r.error.msg : '保存失败');
    }
  }

  /* ═══ after：载入配置 + 记录（同修④：模块加载即 loadRec，查询后刷新） ═══ */

  loadRec();   // 首入 verify 页前状态已就位

  function after() {
    if (hasBridge()) _queryCfg();
    loadRec();
    if (S.rec && document.getElementById('mvQRes')) {
      /* 有记录 → 顺手查一次状态（幂等）；新状态落盘后必须 refresh（同修④） */
      _call({cmd:'partner.applyment.query', business_code:S.rec.business_code}, function(r) {
        if (r && r.ok && r.data && r.data.applyment_state) {
          saveRec({ business_code:S.rec.business_code, applyment_id:r.data.applyment_id || S.rec.applyment_id,
            state:r.data.applyment_state, submittedAt:S.rec.submittedAt,
            reject_reason:r.data.reject_reason || '', sign_url:r.data.sign_url || '' });
          refresh();
        }
      });
    }
  }

  /* ═══ 导出 ═══ */

  return {
    renderAccount: renderAccount, renderVerify: renderVerify, renderForm: renderForm,
    after: after,
    gotoForm: gotoForm, queryStatus: queryStatus,
    cfgToggle: cfgToggle, cfgSave: cfgSave,
    pickSubjectType: pickSubjectType, toggleFinance: toggleFinance,
    pickContactType: pickContactType, pickBankType: pickBankType, toggleScene: toggleScene,
    pickImg: pickImg, nextStep: nextStep, prevStep: prevStep, submit: submit
  };
})();
