package com.hermes.android.workflow;


/**
 * ConnectWeb 页面事件源 — 把 WebView 页面事件注入触发器引擎（PAGE_LOAD/URL_CHANGE/TICK）。
 * 纯逻辑（无 Android），ConnectWeb 侧在 onPageFinished 调用 + Handler 定时 tick。
 *
 * v1 快照只带 url/now；text/element 条件需 JS 页面查询（v2），当前 element 视为不存在（条件不通过）。
 */
public class WorkflowEventSource {

    private final WorkflowEngine engine;
    private String lastUrl;
    /** 条件快照 v2：页面真实状态（ConnectWeb JS 查询回填），element/text 条件据此评估 */
    private String lastText;
    private final java.util.Set<String> presentElements = new java.util.HashSet<>();
    /** 二次打回修复：条件数据拉取式——snapshot() 时刻现查系统，与 receiver 触发家族完全解耦 */
    private com.hermes.android.workflow.DeviceStateProvider deviceState;

    public WorkflowEventSource(WorkflowEngine engine) {
        this.engine = engine;
    }

    /** ConnectWeb 页面状态查询回填（innerText + 存在的 selector），后续 fire 的条件评估用真实快照 */
    public void setPageSnapshot(String text, java.util.List<String> presentSelectors) {
        lastText = text;
        presentElements.clear();
        if (presentSelectors != null) presentElements.addAll(presentSelectors);
    }

    /** 注入设备状态拉取器（Workflows 注入 DeviceStateReader）；null = 条件缺省 FAIL */
    public void setDeviceStateProvider(com.hermes.android.workflow.DeviceStateProvider p) {
        this.deviceState = p;
    }

    /** ConnectWeb.onPageFinished 调用：PAGE_LOAD 事件 + URL 变化时追加 URL_CHANGE 事件（合并 fire 结果） */
    public WorkflowEngine.FireResult onPageFinished(String url, long now) {
        if (url == null) {
            return new WorkflowEngine.FireResult(new java.util.ArrayList<>(), new java.util.ArrayList<>());
        }
        boolean changed = lastUrl != null && !url.equals(lastUrl);   // 首次（无上次 URL）不算变化
        lastUrl = url;
        WorkflowEngine.FireResult r1 = engine.fire(WorkflowEvent.pageLoad(url, now), snapshot(url, now));
        if (changed) {
            WorkflowEngine.FireResult r2 = engine.fire(WorkflowEvent.urlChange(url, now), snapshot(url, now));
            java.util.List<String> fired = new java.util.ArrayList<>(r1.fired);
            fired.addAll(r2.fired);
            java.util.List<String> skipped = new java.util.ArrayList<>(r1.skipped);
            skipped.addAll(r2.skipped);
            return new WorkflowEngine.FireResult(fired, skipped);
        }
        return r1;
    }

    /** 定时心跳：interval 触发器（由调用方 Handler 按节拍调） */
    public WorkflowEngine.FireResult tick(long now) {
        return engine.fire(WorkflowEvent.of(WorkflowEvent.Type.TICK, now), snapshot(lastUrl, now));
    }

    /** element_appear 检测命中（ConnectWeb JS 轮询回调） */
    public WorkflowEngine.FireResult onElementAppear(String selector, String url, long now) {
        if (selector == null || selector.isEmpty()) {
            return new WorkflowEngine.FireResult(new java.util.ArrayList<>(), new java.util.ArrayList<>());
        }
        return engine.fire(WorkflowEvent.elementAppear(selector, url != null ? url : lastUrl, now),
                snapshot(url != null ? url : lastUrl, now));
    }

    /** text_match 检测命中（ConnectWeb JS 轮询回调） */
    public WorkflowEngine.FireResult onTextMatch(String text, String url, long now) {
        if (text == null || text.isEmpty()) {
            return new WorkflowEngine.FireResult(new java.util.ArrayList<>(), new java.util.ArrayList<>());
        }
        return engine.fire(WorkflowEvent.textMatch(text, url != null ? url : lastUrl, now),
                snapshot(url != null ? url : lastUrl, now));
    }

    /** 设备事件命中（DeviceTriggerManager receiver → 引擎，纯 JVM 可测） */
    public WorkflowEngine.FireResult onDeviceEvent(WorkflowEvent.Type type, long now) {
        if (type == null) {
            return new WorkflowEngine.FireResult(new java.util.ArrayList<>(), new java.util.ArrayList<>());
        }
        return engine.fire(WorkflowEvent.device(type, now), snapshot(lastUrl, now));
    }

    /** manual 触发（Run now 桥）：精确触发指定 workflow（跳过 trigger 匹配，走 cooldown/cap/条件/动作） */
    public WorkflowEngine.FireResult onManual(String workflowId, long now) {
        return engine.fire(WorkflowEvent.of(WorkflowEvent.Type.MANUAL, now), snapshot(lastUrl, now), workflowId);
    }

    /** boot_completed 触发（BootReceiver） */
    public WorkflowEngine.FireResult onBoot(long now) {
        return engine.fire(WorkflowEvent.of(WorkflowEvent.Type.BOOT_COMPLETED, now), snapshot(null, now));
    }

    private Snapshot snapshot(String url, long now) {
        // 拉取式：设备状态 snapshot 时刻现查（provider.read()，与 receiver 注册解耦）；无 provider 缺省 FAIL
        int bl = -1; boolean ch = false; boolean so = false; String nt = null;
        if (deviceState != null) {
            com.hermes.android.workflow.DeviceStateProvider.DeviceState ds = deviceState.read();
            bl = ds.batteryLevel; ch = ds.charging; so = ds.screenOn; nt = ds.networkType;
        }
        return new Snapshot(now, url, lastText, 0, presentElements::contains,
                bl, ch, so, nt, null, 0, null, null);
    }
}
