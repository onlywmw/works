package com.hermes.android.agent;

import com.hermes.android.agent.ToolRegistry.*;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * ToolDescribe — tool.describe 处理器。
 * 精确按名查找工具，返回完整签名（params/returns/example/pitfalls）。
 * 不支持模糊匹配，强制 AI 从菜单选名。
 */
public class ToolDescribe {

    /** 生成 tool.describe 的 handler，lambda 捕获 registry 引用 */
    public static ToolRegistry.Handler handler(ToolRegistry registry) {
        return a -> {
            String name = a.optString("name", "").trim();
            if (name.isEmpty()) return new Result(false, "name 不能为空，请从上方菜单中选取工具名");

            Tool t = registry.find(name);
            if (t == null) return new Result(false,
                "未找到工具 '" + name + "'。请检查拼写，确保和菜单中的名称完全一致。用 tool.describe 前先在菜单中确认工具名。");

            // 检查可用性
            String unavail = registry.checkAvailability(t);
            if (unavail != null) return new Result(false,
                "工具 '" + name + "' 当前不可用: " + unavail);

            JSONObject obj = new JSONObject();
            try {
                obj.put("name", t.name);
                obj.put("desc", t.desc);
                if (t.toolset != null) obj.put("toolset", t.toolset);
                if (t.executor != null) obj.put("executor", t.executor);
                if (t.access != null) obj.put("access", t.access);
                if (t.approval != null) obj.put("approval", t.approval);
                if (!t.idempotent) obj.put("idempotent", false);
                if (t.params != null && t.params.length > 0) {
                    JSONArray pa = new JSONArray();
                    for (ToolRegistry.ParamDef p : t.params) {
                        JSONObject pj = new JSONObject();
                        pj.put("name", p.name);
                        pj.put("type", p.type);
                        pj.put("required", p.required);
                        pj.put("description", p.description);
                        if (p.constraint != null && !p.constraint.isEmpty())
                            pj.put("constraint", p.constraint);
                        pa.put(pj);
                    }
                    obj.put("params", pa);
                }
                if (t.returns != null) obj.put("returns", t.returns);
                if (t.examples != null && t.examples.length > 0)
                    obj.put("example", t.examples[0]);
                if (t.pitfalls != null && t.pitfalls.length > 0) {
                    JSONArray pi = new JSONArray();
                    for (String p : t.pitfalls) pi.put(p);
                    obj.put("pitfalls", pi);
                }
                if (t.timeoutSec > 30) obj.put("timeoutSec", t.timeoutSec);
            } catch (Exception e) {
                return new Result(false, "序列化失败: " + e.getMessage());
            }
            return new Result(true, obj.toString(2));
        };
    }
}
