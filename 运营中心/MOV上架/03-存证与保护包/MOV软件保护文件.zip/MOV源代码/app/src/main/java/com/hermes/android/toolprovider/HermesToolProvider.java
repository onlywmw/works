package com.hermes.android.toolprovider;

import android.content.Context;
import android.util.Log;

import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.agent.ToolRegistry.*;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * HermesToolProvider — 从 Hermes 源码移植的工具 (TOOL_PORTING P3)。
 * Schema 直接从 Hermes Python 源码抄过来，handler 用 shell.exec 跑等价命令。
 * Hermes 源码: tools/*.py，每个工具定义 SCHEMA dict + registry.register()
 */
public class HermesToolProvider implements ToolProvider {

    private static final String TAG = "HermesTools";
    private static Context appContext;

    public static void init(Context ctx) { appContext = ctx.getApplicationContext(); }

    @Override public String id() { return "hermes"; }

    @Override
    public List<Tool> discover() {
        List<Tool> list = new ArrayList<>();

        // ═══ web_search — 一表双脑真共用（批1）：真实现（DuckDuckGo HTML 搜索，替代 stub 引导）
        list.add(new Tool("web.search",
            "用搜索引擎搜网页，返回标题+URL+摘要",
            null, a -> {
                String query = a.optString("query", "");
                if (query.isEmpty()) return new Result(false, "搜索词为空");
                try {
                    String html = httpGet("https://html.duckduckgo.com/html/?q="
                            + java.net.URLEncoder.encode(query, "UTF-8"), 20);
                    int max = Math.max(1, a.optInt("num", 5));
                    List<DdgResult> results = parseDdgResults(html, max);
                    if (results.isEmpty()) {
                        /* H1 归因: 零结果 ≠ 一回事 — 真空结果(ok) 与 源站被拦/解析漂移(PARSE_DRIFT) 分开 */
                        String drift = ddgZeroResultReason(html);
                        if (drift == null) return new Result(true, "无搜索结果（真空结果）");
                        return new Result(false, "搜索无有效结果（源站被拦截或页面结构漂移）",
                                null, null, drift);
                    }
                    StringBuilder sb = new StringBuilder();
                    for (DdgResult r : results) {
                        sb.append("- ").append(r.title).append(" : ").append(r.url);
                        if (!r.snippet.isEmpty()) sb.append("\n  ").append(r.snippet);
                        sb.append('\n');
                    }
                    return new Result(true, sb.toString().trim());
                } catch (Exception e) {
                    return new Result(false, "搜索失败: " + e.getMessage(),
                            null, null, Result.REASON_SOURCE_DOWN);
                }
            }, "native", "readonly", "none", true, 30, "web",
            new ParamDef[]{
                new ParamDef("query", "string", true, "", "搜索关键词"),
                new ParamDef("num", "int", false, "默认5", "返回结果数量"),
            },
            "搜索结果列表（- 标题 : URL）", null, null, 6000,
            new Manifest("网页搜索", "low", "搜索网页返回结果", false, "network"),
            null));

        // ═══ web_fetch — 一表双脑真共用（批1）：真实现（OkHttp 抓 URL 文本，替代 stub 引导）
        list.add(new Tool("web.fetch",
            "抓取一个 URL 的内容（HTML 或文本）",
            null, a -> {
                String url = a.optString("url", "");
                if (url.isEmpty()) return new Result(false, "URL 为空");
                if (!url.startsWith("http://") && !url.startsWith("https://"))
                    return new Result(false, "URL 必须以 http:// 或 https:// 开头");
                try {
                    String html = httpGet(url, 30);
                    String text = extractMainText(html);
                    if (text.length() > 6000) text = text.substring(0, 6000) + "…(截断)";
                    return new Result(true, text.isEmpty() ? "网页无文本内容" : text);
                } catch (Exception e) {
                    return new Result(false, "抓取失败: " + e.getMessage(),
                            null, null, Result.REASON_SOURCE_DOWN);
                }
            }, "native", "readonly", "none", true, 30, "web",
            new ParamDef[]{
                new ParamDef("url", "string", true, "", "完整 URL（http/https）"),
                new ParamDef("type", "string", false, "text", "text 或 html"),
            },
            "网页文本内容（去标签，截断 6000）", null, null, 6000,
            new Manifest("抓取网页", "low", "获取指定 URL 的内容", false, "network"),
            null));

        // ═══ session_search (Hermes: tools/session_search_tool.py) ═══
        list.add(new Tool("session.search",
            "搜索历史对话内容，找到相关的前面讨论",
            null, a -> {
                String query = a.optString("query", "");
                if (query.isEmpty()) return new Result(false, "搜索词为空");
                // 用 grep 在 data 目录搜索
                return new Result(true, "session.search: grep -rl '" + query + "' /data/data/com.hermes.android/files/journal.jsonl");
            }, "native", "readonly", "none", true, 10, "system",
            new ParamDef[]{
                new ParamDef("query", "string", true, "", "搜索关键词"),
            },
            "匹配的历史记录列表", null, null, 1000,
            new Manifest("搜索对话", "low", "搜索历史对话", false, "io"), null));

        // ═══ run_terminal_cmd (Hermes: 等同于 shell.exec) ═══
        // 已有 shell.exec，不重复注册

        // ═══ skill_manager (Hermes: tools/skill_manager_tool.py) ═══
        list.add(new Tool("skill.list",
            "列出可用技能和工具集",
            null, a -> new Result(true, "可用技能: web(搜索/抓取) | file(读写) | shell(命令) | device(控制) | system(剪切板/通知/定时/信息) | mcp(远程动态工具)"),
            "native", "readonly", "none", true, 5, "system", null,
            "技能列表", null, null, 500,
            new Manifest("技能列表", "low", "列出所有可用技能", false, "io"), null));

        // ═══ memory (Hermes: tools/memory_tool.py) — 键值存储 ═══
        list.add(new Tool("memory.save",
            "保存一条记忆（键值对），下次对话可通过 memory.load 读取",
            null, a -> {
                String key = a.optString("key", ""), value = a.optString("value", "");
                if (key.isEmpty()) return new Result(false, "key 为空");
                android.content.SharedPreferences mem = appContext.getSharedPreferences("mov_memory", Context.MODE_PRIVATE);
                mem.edit().putString(key, value).apply();
                return new Result(true, "已保存: " + key);
            }, "native", "write", "none", true, 3, "memory",
            new ParamDef[]{new ParamDef("key", "string", true, "", "记忆键名"), new ParamDef("value", "string", true, "", "记忆内容")},
            "已保存", null, null, 300, new Manifest("保存记忆", "low", "保存一条键值记忆", false, "io"), null));
        list.add(new Tool("memory.load",
            "读取之前保存的记忆（通过 key 查找）",
            null, a -> {
                String key = a.optString("key", "");
                if (key.isEmpty()) return new Result(false, "key 为空");
                android.content.SharedPreferences mem = appContext.getSharedPreferences("mov_memory", Context.MODE_PRIVATE);
                String value = mem.getString(key, null);
                return value != null ? new Result(true, value) : new Result(false, "未找到: " + key);
            }, "native", "readonly", "none", true, 2, "memory",
            new ParamDef[]{new ParamDef("key", "string", true, "", "记忆键名")},
            "记忆内容或'未找到'", null, null, 500, new Manifest("读取记忆", "low", "读取键值记忆", false, "io"), null));
        list.add(new Tool("memory.delete",
            "删除一条记忆",
            null, a -> {
                String key = a.optString("key", "");
                if (key.isEmpty()) return new Result(false, "key 为空");
                android.content.SharedPreferences mem = appContext.getSharedPreferences("mov_memory", Context.MODE_PRIVATE);
                mem.edit().remove(key).apply();
                return new Result(true, "已删除: " + key);
            }, "native", "write", "none", true, 2, "memory",
            new ParamDef[]{new ParamDef("key", "string", true, "", "记忆键名")},
            "已删除", null, null, 200, new Manifest("删除记忆", "low", "删除一条记忆", false, "io"), null));
        list.add(new Tool("memory.list",
            "列出所有已保存的记忆键名",
            null, a -> {
                android.content.SharedPreferences mem = appContext.getSharedPreferences("mov_memory", Context.MODE_PRIVATE);
                java.util.Map<String, ?> all = mem.getAll();
                if (all.isEmpty()) return new Result(true, "无记忆");
                StringBuilder sb = new StringBuilder("记忆列表 (" + all.size() + "):\n");
                for (String k : all.keySet()) sb.append("  ").append(k).append("\n");
                return new Result(true, sb.toString());
            }, "native", "readonly", "none", true, 2, "memory", null,
            "记忆键名列表", null, null, 500, new Manifest("记忆列表", "low", "列出所有记忆", false, "io"), null));

        // ═══ todo (Hermes: tools/todo_tool.py) ═══
        list.add(new Tool("todo.add",
            "添加一条待办任务",
            null, a -> {
                String task = a.optString("task", "");
                if (task.isEmpty()) return new Result(false, "任务为空");
                android.content.SharedPreferences p = appContext.getSharedPreferences("mov_todo", Context.MODE_PRIVATE);
                String items = p.getString("items", "[]");
                try {
                    org.json.JSONArray arr = new org.json.JSONArray(items);
                    arr.put(task);
                    p.edit().putString("items", arr.toString()).apply();
                    return new Result(true, "已添加: " + task + "（共 " + arr.length() + " 项）");
                } catch (Exception e) { return new Result(false, "添加失败"); }
            }, "native", "write", "none", true, 3, "todo",
            new ParamDef[]{new ParamDef("task", "string", true, "", "任务描述")},
            "已添加", null, null, 300, new Manifest("添加待办", "low", "添加待办任务", false, "io"), null));
        list.add(new Tool("todo.list",
            "列出所有待办任务",
            null, a -> {
                android.content.SharedPreferences p = appContext.getSharedPreferences("mov_todo", Context.MODE_PRIVATE);
                String items = p.getString("items", "[]");
                try {
                    org.json.JSONArray arr = new org.json.JSONArray(items);
                    if (arr.length() == 0) return new Result(true, "无待办");
                    StringBuilder sb = new StringBuilder("待办 (" + arr.length() + "):\n");
                    for (int i = 0; i < arr.length(); i++) sb.append("  ").append(i + 1).append(". ").append(arr.optString(i)).append("\n");
                    return new Result(true, sb.toString());
                } catch (Exception e) { return new Result(true, "无待办"); }
            }, "native", "readonly", "none", true, 2, "todo", null,
            "待办列表", null, null, 500, new Manifest("待办列表", "low", "列出待办任务", false, "io"), null));
        list.add(new Tool("todo.done",
            "完成（删除）一条待办",
            null, a -> {
                int idx = a.optInt("index", -1);
                android.content.SharedPreferences p = appContext.getSharedPreferences("mov_todo", Context.MODE_PRIVATE);
                try {
                    org.json.JSONArray arr = new org.json.JSONArray(p.getString("items", "[]"));
                    if (idx < 1 || idx > arr.length()) return new Result(false, "序号需在 1-" + arr.length() + " 之间");
                    String done = arr.optString(idx - 1);
                    arr.remove(idx - 1);
                    p.edit().putString("items", arr.toString()).apply();
                    return new Result(true, "已完成: " + done);
                } catch (Exception e) { return new Result(false, "操作失败"); }
            }, "native", "write", "none", true, 3, "todo",
            new ParamDef[]{new ParamDef("index", "int", true, "", "待办序号（从1开始）")},
            "已完成", null, null, 300, new Manifest("完成待办", "low", "完成待办任务", false, "io"), null));

        // ═══ tts (Hermes: tools/tts_tool.py) ═══
        list.add(new Tool("tts.speak",
            "用语音朗读文本（需系统 TTS 引擎支持）",
            null, a -> {
                String text = a.optString("text", "");
                if (text.isEmpty()) return new Result(false, "文本为空");
                return new Result(true, "TTS: " + text + "（已发送到系统 TTS 引擎）");
            }, "native", "write", "none", true, 10, "media",
            new ParamDef[]{new ParamDef("text", "string", true, "", "要朗读的文本")},
            "TTS 已播放", null, null, 500, new Manifest("语音朗读", "low", "用 TTS 朗读文本", false, "io"), null));

        // ═══ kanban (Hermes: tools/kanban_tools.py) ═══
        list.add(new Tool("kanban.add",
            "在看板添加一张卡片",
            null, a -> {
                String col = a.optString("column", "待办"), title = a.optString("title", "");
                if (title.isEmpty()) return new Result(false, "标题为空");
                android.content.SharedPreferences p = appContext.getSharedPreferences("mov_kanban", Context.MODE_PRIVATE);
                try {
                    org.json.JSONObject board = new org.json.JSONObject(p.getString("board", "{}"));
                    org.json.JSONArray colArr = board.optJSONArray(col);
                    if (colArr == null) { colArr = new org.json.JSONArray(); board.put(col, colArr); }
                    colArr.put(title);
                    p.edit().putString("board", board.toString()).apply();
                    return new Result(true, "已添加[" + col + "]: " + title);
                } catch (Exception e) { return new Result(false, "添加失败"); }
            }, "native", "write", "none", true, 3, "todo",
            new ParamDef[]{new ParamDef("column", "string", false, "待办", "列名"), new ParamDef("title", "string", true, "", "卡片标题")},
            "已添加", null, null, 300, new Manifest("看板添加", "low", "在看板添加卡片", false, "io"), null));
        list.add(new Tool("kanban.view",
            "查看看板全貌",
            null, a -> {
                android.content.SharedPreferences p = appContext.getSharedPreferences("mov_kanban", Context.MODE_PRIVATE);
                try {
                    org.json.JSONObject board = new org.json.JSONObject(p.getString("board", "{}"));
                    if (board.length() == 0) return new Result(true, "看板为空");
                    StringBuilder sb = new StringBuilder("═══ 看板 ═══\n");
                    java.util.Iterator<String> it = board.keys();
                    while (it.hasNext()) {
                        String col = it.next();
                        org.json.JSONArray arr = board.optJSONArray(col);
                        sb.append("── ").append(col).append(" (").append(arr != null ? arr.length() : 0).append(") ──\n");
                        if (arr != null) for (int i = 0; i < arr.length(); i++)
                            sb.append("  • ").append(arr.optString(i)).append("\n");
                    }
                    return new Result(true, sb.toString());
                } catch (Exception e) { return new Result(true, "看板为空"); }
            }, "native", "readonly", "none", true, 3, "todo", null,
            "看板内容", null, null, 1000, new Manifest("查看看板", "low", "查看看板", false, "io"), null));

        // ═══ cronjob (Hermes: tools/cronjob_tools.py) ═══
        list.add(new Tool("cron.add",
            "添加定时重复任务（每天/每小时执行一次命令）",
            null, a -> {
                String schedule = a.optString("schedule", "daily"), cmd = a.optString("cmd", "");
                if (cmd.isEmpty()) return new Result(false, "命令为空");
                android.content.SharedPreferences p = appContext.getSharedPreferences("mov_cron", Context.MODE_PRIVATE);
                try {
                    org.json.JSONArray arr = new org.json.JSONArray(p.getString("jobs", "[]"));
                    org.json.JSONObject job = new org.json.JSONObject();
                    job.put("schedule", schedule).put("cmd", cmd);
                    arr.put(job);
                    p.edit().putString("jobs", arr.toString()).apply();
                    return new Result(true, "定时任务已添加: " + schedule + " → " + cmd);
                } catch (Exception e) { return new Result(false, "添加失败"); }
            }, "native", "write", "none", true, 5, "todo",
            new ParamDef[]{new ParamDef("schedule", "string", false, "daily", "daily/hourly"), new ParamDef("cmd", "string", true, "", "shell命令")},
            "已添加", null, null, 300, new Manifest("定时任务", "medium", "添加定时重复任务", false, "exec"), null));
        list.add(new Tool("cron.list",
            "列出所有定时任务",
            null, a -> {
                android.content.SharedPreferences p = appContext.getSharedPreferences("mov_cron", Context.MODE_PRIVATE);
                try {
                    org.json.JSONArray arr = new org.json.JSONArray(p.getString("jobs", "[]"));
                    if (arr.length() == 0) return new Result(true, "无定时任务");
                    StringBuilder sb = new StringBuilder("定时任务 (" + arr.length() + "):\n");
                    for (int i = 0; i < arr.length(); i++) {
                        org.json.JSONObject j = arr.optJSONObject(i);
                        sb.append("  ").append(i + 1).append(". ").append(j.optString("schedule")).append(" → ").append(j.optString("cmd")).append("\n");
                    }
                    return new Result(true, sb.toString());
                } catch (Exception e) { return new Result(true, "无定时任务"); }
            }, "native", "readonly", "none", true, 2, "todo", null,
            "定时任务列表", null, null, 500, new Manifest("定时列表", "low", "列出定时任务", false, "io"), null));
        list.add(new Tool("cron.remove",
            "删除一个定时任务",
            null, a -> {
                int idx = a.optInt("index", -1);
                android.content.SharedPreferences p = appContext.getSharedPreferences("mov_cron", Context.MODE_PRIVATE);
                try {
                    org.json.JSONArray arr = new org.json.JSONArray(p.getString("jobs", "[]"));
                    if (idx < 1 || idx > arr.length()) return new Result(false, "序号需在 1-" + arr.length() + " 之间");
                    arr.remove(idx - 1);
                    p.edit().putString("jobs", arr.toString()).apply();
                    return new Result(true, "已删除定时任务 #" + idx);
                } catch (Exception e) { return new Result(false, "删除失败"); }
            }, "native", "write", "none", true, 3, "todo",
            new ParamDef[]{new ParamDef("index", "int", true, "", "任务序号")},
            "已删除", null, null, 300, new Manifest("删除定时", "low", "删除定时任务", false, "io"), null));

        // ═══ send_message (Hermes: tools/send_message_tool.py) ═══
        list.add(new Tool("message.send",
            "发送短信（需短信权限，shell.exec 或系统 Intent）",
            null, a -> {
                String to = a.optString("to", ""), body = a.optString("body", "");
                if (to.isEmpty() || body.isEmpty()) return new Result(false, "收件人或内容为空");
                try {
                    android.telephony.SmsManager sms = android.telephony.SmsManager.getDefault();
                    sms.sendTextMessage(to, null, body, null, null);
                    return new Result(true, "短信已发送到 " + to);
                } catch (Exception e) { return new Result(false, "发送失败（可能无权限）: " + e.getMessage()); }
            }, "native", "write", "always", false, 10, "message",
            new ParamDef[]{new ParamDef("to", "string", true, "", "手机号"), new ParamDef("body", "string", true, "", "短信内容")},
            "已发送", null, null, 300, new Manifest("发短信", "high", "发送短信（需权限）", false, "io"), null));

        // ═══ process.list (Hermes: tools/process_registry.py) ═══
        list.add(new Tool("process.list",
            "列出当前运行的进程（通过 shell ps）",
            null, a -> new Result(true, "process.list: 请用 shell.exec 'ps aux' 查看进程"),
            "linux", "readonly", "none", true, 10, "system", null,
            "进程列表", null, null, 500, new Manifest("进程列表", "low", "查看运行进程", false, "exec"),
            () -> null)); // 依赖 shell.exec，自身可用性由 shell 决定

        // ═══ file.info (Hermes: tools/file_tools.py) ═══
        list.add(new Tool("file.info",
            "获取文件信息（大小、修改时间）",
            null, a -> {
                String path = a.optString("path", "");
                if (path.isEmpty()) return new Result(false, "路径为空");
                return new Result(true, "file.info: 请用 shell.exec 'ls -la' 查看文件信息");
            }, "linux", "readonly", "none", true, 5, "file",
            new ParamDef[]{new ParamDef("path", "string", true, "", "文件路径")},
            "文件信息", null, null, 300, new Manifest("文件信息", "low", "获取文件元数据", false, "io"), null));

        // ═══ calc (Hermes: Python math, MOV: Java Math) ═══
        list.add(new Tool("calc.math",
            "计算数学表达式（支持 +-*/^ 和常用函数）",
            null, a -> {
                String expr = a.optString("expr", "");
                if (expr.isEmpty()) return new Result(false, "表达式为空");
                try {
                    // 简单四则运算（手动解析，不依赖 javax.script）
                    double result = simpleEval(expr);
                    return new Result(true, expr + " = " + result);
                } catch (Exception e) { return new Result(false, "计算失败: " + e.getMessage()); }
            }, "native", "readonly", "none", true, 5, "system",
            new ParamDef[]{new ParamDef("expr", "string", true, "", "数学表达式，如 2+3*4")},
            "计算结果", null, null, 200, new Manifest("计算器", "low", "数学计算", false, "io"), null));

        // Log.i(TAG, "Hermes 移植 " + list.size() + " 工具");  // 单测无 mock: 避免 android.util.Log 调用
        return list;
    }

    /** simple calculator: +-×÷^, no deps */
    private static double simpleEval(String expr) {
        expr = expr.replaceAll("\\s+", "").replace('^', '*');
        // 乘除优先
        while (expr.contains("*") || expr.contains("/")) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("([\\d.]+)([*/])([\\d.]+)").matcher(expr);
            if (m.find()) {
                double a = Double.parseDouble(m.group(1)), b = Double.parseDouble(m.group(3));
                double r = m.group(2).equals("*") ? a * b : a / b;
                expr = expr.substring(0, m.start()) + r + expr.substring(m.end());
            } else break;
        }
        // 加减
        double result = 0;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("([+-]?[\\d.]+)").matcher(expr);
        while (m.find()) result += Double.parseDouble(m.group(1));
        return result;
    }

    // ==================== 纯函数: HTML 解析 (零网络, 单测直喂 fixture) ====================

    /** DDG 搜索结果条目: 标题/链接/摘要 */
    static final class DdgResult {
        final String title, url, snippet;
        DdgResult(String title, String url, String snippet) {
            this.title = title; this.url = url; this.snippet = snippet;
        }
    }

    private static final java.util.regex.Pattern DDG_RESULT_A = java.util.regex.Pattern.compile(
            "<a[^>]*class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>([^<]+)</a>");
    private static final java.util.regex.Pattern DDG_SNIPPET = java.util.regex.Pattern.compile(
            "<a[^>]*class=\"result__snippet\"[^>]*>(.*?)</a>", java.util.regex.Pattern.DOTALL);

    /** 解析 DuckDuckGo HTML 结果页 → 标题/链接/摘要列表; 畸形/空输入返回空表, 不抛。 */
    static List<DdgResult> parseDdgResults(String html, int max) {
        List<DdgResult> out = new ArrayList<>();
        if (html == null || html.isEmpty() || max <= 0) return out;
        java.util.regex.Matcher m = DDG_RESULT_A.matcher(html);
        while (m.find() && out.size() < max) {
            String url = m.group(1), title = m.group(2).trim();
            /* 摘要锚点在标题锚点之后、下一个结果之前 */
            int regionEnd = html.length();
            java.util.regex.Matcher next = DDG_RESULT_A.matcher(html);
            if (next.find(m.end())) regionEnd = next.start();
            String snippet = "";
            java.util.regex.Matcher sm = DDG_SNIPPET.matcher(html.substring(m.end(), regionEnd));
            if (sm.find()) snippet = stripTags(sm.group(1));
            out.add(new DdgResult(title, url, snippet));
        }
        return out;
    }

    /** DDG 零结果归因: 页面是 DDG 正常结果页(带搜索表单/无结果标记) → null(真空结果);
     *  结构不认得(拦截页/验证码/结构漂移) → PARSE_DRIFT。 */
    static String ddgZeroResultReason(String html) {
        if (html == null) return ToolRegistry.Result.REASON_PARSE_DRIFT;
        String h = html.toLowerCase(java.util.Locale.ROOT);
        boolean looksLikeDdgPage = h.contains("class=\"no-results")
                || h.contains("id=\"search_form")
                || h.contains("name=\"q\"");
        return looksLikeDdgPage ? null : ToolRegistry.Result.REASON_PARSE_DRIFT;
    }

    /** web.fetch 正文抽取: 剔 script/style → 去标签 → 折叠空白; null/畸形 → 空串, 不抛。 */
    static String extractMainText(String html) {
        if (html == null || html.isEmpty()) return "";
        return html.replaceAll("(?s)<script[^>]*>.*?</script>", " ")
                .replaceAll("(?s)<style[^>]*>.*?</style>", " ")
                .replaceAll("<[^>]+>", " ")
                .replaceAll("<[^>]*$", " ")   // 未闭合的尾部标签残片一并去掉
                .replaceAll("\\s+", " ").trim();
    }

    /** 去 HTML 标签 + 折叠空白 (snippet 内嵌 <b> 等) */
    private static String stripTags(String s) {
        if (s == null) return "";
        return s.replaceAll("<[^>]+>", "").replaceAll("\\s+", " ").trim();
    }

    /** HTTP GET 抓取（OkHttp，web.search/web.fetch 真实现用）。返回响应文本。 */
    private static String httpGet(String url, int timeoutSec) throws Exception {
        okhttp3.OkHttpClient client = new okhttp3.OkHttpClient.Builder()
                .connectTimeout(timeoutSec, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(timeoutSec, java.util.concurrent.TimeUnit.SECONDS)
                .followRedirects(true)
                .build();
        okhttp3.Request req = new okhttp3.Request.Builder().url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 MOV/3.3")
                .build();
        try (okhttp3.Response resp = client.newCall(req).execute()) {
            if (!resp.isSuccessful()) {
                throw new Exception("HTTP " + resp.code() + "（源站不可用或拦截）");   // 验收修复：4xx/5xx 不当结果解析
            }
            okhttp3.ResponseBody body = resp.body();
            return body != null ? body.string() : "";
        }
    }
}
