package com.hermes.android.context;

/**
 * 情境转移事件回调。
 *
 * <p>ContextProvider 在检测到状态转移时，按订阅的事件类型分发给所有
 * 匹配的监听器。回调在 ContextProvider 的内部线程上执行——实现方负责
 * 必要时切线程。
 */
public interface TransitionListener {
    /** 收到一次状态转移事件。{@link ContextEvent#type} 标识转移类型。 */
    void onTransition(ContextEvent event);
}
