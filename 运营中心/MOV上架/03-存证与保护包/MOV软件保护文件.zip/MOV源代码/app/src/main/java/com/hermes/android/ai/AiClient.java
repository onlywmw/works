package com.hermes.android.ai;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

/**
 * Minimal OpenAI-compatible chat client.
 * Works with OpenAI, DeepSeek, Qwen (compatible-mode), Ollama (/v1/chat/completions).
 */
public class AiClient {

    public static class Message {
        public final String role;
        public final String content;

        public Message(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }

    public static class AiResponse {
        public final boolean success;
        public final String content;
        /** DESIGN_AGENT_LOOP 计量: prompt/completion tokens; 无 usage 时为字符数÷4 估算 */
        public final int promptTokens;
        public final int completionTokens;
        public final boolean tokensEstimated;

        public AiResponse(boolean success, String content) {
            this(success, content, -1, -1, false);
        }

        public AiResponse(boolean success, String content,
                          int promptTokens, int completionTokens, boolean tokensEstimated) {
            this(success, content, promptTokens, completionTokens, tokensEstimated,
                    StreamWatchdog.ErrorClass.RUNTIME, 0, false);
        }

        public AiResponse(boolean success, String content,
                          int promptTokens, int completionTokens, boolean tokensEstimated,
                          StreamWatchdog.ErrorClass errorClass, int stallCount, boolean cancelled) {
            this.success = success;
            this.content = content;
            this.promptTokens = promptTokens;
            this.completionTokens = completionTokens;
            this.tokensEstimated = tokensEstimated;
            this.errorClass = errorClass;
            this.stallCount = stallCount;
            this.cancelled = cancelled;
        }

        /** 错误分类 (CONTRACT_STREAMING 2.4): CONNECTION/RATE_LIMIT 可暂停续跑 */
        public final StreamWatchdog.ErrorClass errorClass;
        /** 本次调用累计停滞次数 (熔断计数, 连续 5 次熔断由 AiClient 内处理) */
        public final int stallCount;
        /** 用户/看门狗主动取消 (取消不重试, 红线) */
        public final boolean cancelled;
    }

    /** 流式 token 回调 (仅显示用; agent 动作解析仍等完整响应) */
    public interface TokenListener {
        void onToken(String delta);
    }

    private final AiProviderConfig config;
    private final com.hermes.android.model.ModelConfig modelConfig;

    /** 临时覆盖 system prompt（仅本次实例，不持久化）。
     *  用于 Council 等多角色场景，避免并发写 SharedPreferences。 */
    private String overrideSystemPrompt = null;

    public AiClient(AiProviderConfig config) {
        this.config = config;
        this.modelConfig = null;
    }

    /** 构造时指定临时 system prompt，不修改 SharedPreferences */
    public AiClient(AiProviderConfig config, String systemPrompt) {
        this.config = config;
        this.modelConfig = null;
        this.overrideSystemPrompt = systemPrompt;
    }

    /** 从 ModelConfig 构造 (多模型场景, 不依赖全局 AiProviderConfig) */
    public AiClient(com.hermes.android.model.ModelConfig mc) {
        this.config = null;
        this.modelConfig = mc;
    }

    /** 从 ModelConfig 构造 + 临时 system prompt */
    public AiClient(com.hermes.android.model.ModelConfig mc, String systemPrompt) {
        this.config = null;
        this.modelConfig = mc;
        this.overrideSystemPrompt = systemPrompt;
    }

    private String getBaseUrl() {
        return modelConfig != null ? modelConfig.getEffectiveBaseUrl() : config.getBaseUrl();
    }

    private String getApiKey() {
        return modelConfig != null ? modelConfig.apiKey : config.getApiKey();
    }

    private String getModelName() {
        return modelConfig != null ? modelConfig.getEffectiveModel() : config.getModel();
    }

    private String getProvider() {
        return modelConfig != null ? modelConfig.provider
                : (config != null ? config.getProvider() : "");
    }

    /** Anthropic Messages 协议（/v1/messages + content[] 响应 + SSE 事件） */
    private boolean isAnthropic() {
        return "anthropic".equals(getProvider());
    }

    private String getSystemPrompt() {
        if (overrideSystemPrompt != null) return overrideSystemPrompt;
        if (modelConfig != null && modelConfig.systemPrompt != null
                && !modelConfig.systemPrompt.trim().isEmpty()) return modelConfig.systemPrompt;
        if (config != null) return config.getSystemPrompt();
        return "你是 MOV，一个运行在 Android 平板上的多模型协作工作台。回答用中文。";
    }

    public AiResponse chat(String userText) {
        return chat(userText, new ArrayList<>());
    }

    /** 带超时控制的 chat 变体（connect/read 毫秒），供 IntentEngine 等快速分类场景。 */
    public AiResponse chat(String userText, int connectTimeoutMs, int readTimeoutMs) {
        return chat(userText, new ArrayList<>(), connectTimeoutMs, readTimeoutMs);
    }

    /**
     * Send user text with optional recent history (user/assistant messages).
     */
    public AiResponse chat(String userText, List<Message> history) {
        return chat(userText, history, 15000, 120000);
    }

    private AiResponse chat(String userText, List<Message> history, int connectTimeoutMs, int readTimeoutMs) {
        HttpURLConnection conn = null;
        try {
            String baseUrl = normalizeBaseUrl(getBaseUrl());
            URL url = new URL(baseUrl + (isAnthropic() ? "/v1/messages" : "/chat/completions"));
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(connectTimeoutMs);
            conn.setReadTimeout(readTimeoutMs);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");

            String apiKey = getApiKey();
            if (apiKey != null && !apiKey.trim().isEmpty()) {
                conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
            }

            JSONObject body = buildBody(userText, history, false);

            byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload);
                os.flush();
            }

            int code = conn.getResponseCode();
            String responseBody;
            if (code >= 200 && code < 300) {
                responseBody = readStream(conn);
            } else {
                String err = readErrorStream(conn);
                return new AiResponse(false, "AI 请求失败 (" + code + "): " + friendlyError(code, err));
            }

            JSONObject json = new JSONObject(responseBody);
            String content;
            if (isAnthropic()) {
                content = extractAnthropicContent(json);
            } else {
                JSONArray choices = json.optJSONArray("choices");
                if (choices == null || choices.length() == 0) {
                    return new AiResponse(false, "AI 返回为空");
                }
                // OpenAI 格式: choices[0].message.content
                JSONObject choice = choices.optJSONObject(0);
                if (choice == null) return new AiResponse(false, "AI 返回格式错误");
                JSONObject msgObj = choice.optJSONObject("message");
                if (msgObj == null) return new AiResponse(false, "AI 返回缺少 message 字段");
                content = msgObj.optString("content", "").trim();
                // 兼容 reasoning 模型（deepseek-reasoner 等）：content 可能为空但有 reasoning_content
                if (content.isEmpty()) {
                    content = msgObj.optString("reasoning_content", "").trim();
                }
            }
            if (content.isEmpty()) return new AiResponse(false, "AI 没有返回内容");
            // DESIGN_AGENT_LOOP: 计量 — 优先 usage 字段, 缺失按字符数÷4 估算
            int pt = -1, ct = -1;
            boolean estimated = false;
            JSONObject usage = json.optJSONObject("usage");
            if (usage != null) {
                // anthropic: input/output_tokens; openai: prompt/completion_tokens
                pt = isAnthropic() ? usage.optInt("input_tokens", -1) : usage.optInt("prompt_tokens", -1);
                ct = isAnthropic() ? usage.optInt("output_tokens", -1) : usage.optInt("completion_tokens", -1);
            }
            if (pt < 0) { pt = body.toString().length() / 4; estimated = true; }
            if (ct < 0) { ct = content.length() / 4; estimated = true; }
            // V5: 全局计量 (运行页仪表盘); 失败/异常永不阻断
            try {
                String providerKey = modelConfig != null ? modelConfig.provider
                        : (config != null ? config.getProvider() : "");
                com.hermes.android.TokenMeter.record(pt, ct, providerKey);
            } catch (Exception ignored) {}
            return new AiResponse(true, content, pt, ct, estimated);
        } catch (java.net.SocketTimeoutException e) {
            return new AiResponse(false, "AI 请求超时，请检查网络或 API 地址");
        } catch (Exception e) {
            return new AiResponse(false, "AI 调用异常: " + e.getMessage());
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    // ==================== SSE 流式 (CONTRACT_STREAMING) ====================

    /** 输出 token 上限: deepseek 计划阶段元思考失控 (5万+字符) 致 AgentLoop 计划卡死,
        限制输出截断元思考; 计划 JSON 与学习页 HTML (≈2k tokens) 足够 (2026-08-05) */
    private static final int MAX_OUTPUT_TOKENS = 4096;

    /** 共享看门狗调度器 (复用, 不为动效新增线程; 每流一个 1s 检查任务, 流完即清) */
    private static final ScheduledExecutorService WATCHDOG_EXEC =
            Executors.newSingleThreadScheduledExecutor(new ThreadFactory() {
                @Override
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "sse-watchdog");
                    t.setDaemon(true);
                    return t;
                }
            });

    private volatile boolean cancelled = false;

    /** 在途连接注册表 (断网秒级中止用, HermesActivity 网络监听调 cancelAllActive) */
    private static final java.util.Set<HttpURLConnection> ACTIVE_CONNS =
            java.util.concurrent.ConcurrentHashMap.newKeySet();

    /** 断网瞬间中止全部在途请求 (CONTRACT_STREAMING 2.5) */
    public static void cancelAllActive() {
        for (HttpURLConnection c : ACTIVE_CONNS) {
            try { c.disconnect(); } catch (Exception ignored) {}
        }
    }
    private volatile HttpURLConnection activeConn = null;

    /** 用户取消: 先置标志再杀流 (红线: 取消不重试) */
    public void cancel() {
        cancelled = true;
        HttpURLConnection c = activeConn;
        if (c != null) {
            try { c.disconnect(); } catch (Exception ignored) {}
        }
    }

    /** 单发流式 (无重试编排; 内部含看门狗) */
    public AiResponse chatStream(String userText, TokenListener listener) {
        return chatStream(userText, new ArrayList<>(), listener, StreamWatchdog.Mode.STREAM);
    }

    /**
     * SSE 流式 + 停滞看门狗 + 双速退避 (合同 2.1-2.3)。
     * 取消/熔断/失败诊断缓冲: 成功静默, 全部失败才回报完整死因。
     */
    public AiResponse chatStream(String userText, List<Message> history,
                                 TokenListener listener, StreamWatchdog.Mode mode) {
        StreamWatchdog watchdog = new StreamWatchdog(mode);
        StringBuilder deaths = new StringBuilder();
        StreamWatchdog.ErrorClass lastClass = StreamWatchdog.ErrorClass.RUNTIME;
        int pt = -1, ct = -1;
        int fastAttempt = 0, rateAttempt = 0, connAttempt = 0;  // BUG-1: 计数器移到主循环，跨迭代保留
        for (int attempt = 0; ; attempt++) {
            if (cancelled) {
                return new AiResponse(false, "已取消", -1, -1, false,
                        StreamWatchdog.ErrorClass.RUNTIME, watchdog.getStallCount(), true);
            }
            Attempt a = attemptOnce(userText, history, listener, watchdog, mode);
            if (a.content != null) {
                /* 成功: 静默 (诊断缓冲不展示) */
                try {
                    String providerKey = modelConfig != null ? modelConfig.provider
                            : (config != null ? config.getProvider() : "");
                    com.hermes.android.TokenMeter.record(a.pt, a.ct, providerKey);
                } catch (Exception ignored) {}
                return new AiResponse(true, a.content, a.pt, a.ct, a.estimated,
                        StreamWatchdog.ErrorClass.RUNTIME, watchdog.getStallCount(), false);
            }
            lastClass = a.errorClass;   // 终态分类以最后一次死因为准 (TC-SSE-06 暂停续跑判定)
            deaths.append('[').append(a.errorClass).append("] ").append(a.error).append('\n');
            if (cancelled || a.cancelled) {
                return new AiResponse(false, "已取消", -1, -1, false,
                        a.errorClass, watchdog.getStallCount(), true);
            }
            /* 停滞: 看门狗已杀流, 计入停滞重试 (换连接重发) */
            if (a.stalled) {
                if (watchdog.isCircuitBroken()) {
                    return new AiResponse(false,
                            "provider 持续无响应 (连续停滞 " + watchdog.getStallCount() + " 次)",
                            -1, -1, false, a.errorClass, watchdog.getStallCount(), false);
                }
                continue;   // 换连接立即重发
            }
            /* 429/限流: 尊重 Retry-After (上限 600s), 无头长退避 */
            if (a.errorClass == StreamWatchdog.ErrorClass.RATE_LIMIT) {
                long delay = StreamWatchdog.rateLimitBackoffMs(rateAttempt++, a.retryAfterSec);
                if (delay < 0) break;
                sleepMs(delay);
                continue;
            }
            /* 快退避: 连接抖动/5xx (最多 3 次) */
            if (a.errorClass == StreamWatchdog.ErrorClass.PROVIDER_CONNECTION
                    || a.errorClass == StreamWatchdog.ErrorClass.PROVIDER_API) {
                if (++connAttempt >= StreamWatchdog.MAX_STALLS) break;  // BUG-1: 连续连接失败熔断
                long delay = StreamWatchdog.fastBackoffMs(fastAttempt++, 0.0);
                if (delay < 0) break;
                sleepMs(delay);
                continue;
            }
            /* AUTH/MODEL_CONFIG/RUNTIME: 直达失败, 不重试 */
            break;
        }
        return new AiResponse(false,
                "AI 调用失败, 已重试多次:\n" + deaths.toString().trim(),
                pt, ct, false, lastClass,
                watchdog.getStallCount(), false);
    }

    private static void sleepMs(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    private static class Attempt {
        String content;
        String error = "";
        StreamWatchdog.ErrorClass errorClass = StreamWatchdog.ErrorClass.RUNTIME;
        boolean stalled = false;
        boolean cancelled = false;
        int retryAfterSec = 0;
        int pt = -1, ct = -1;
        boolean estimated = false;
    }

    /** 单次流式尝试: 建立 SSE, 看门狗 1s 检查停滞 (真实 chunk 才重置) */
    private Attempt attemptOnce(String userText, List<Message> history,
                                TokenListener listener, StreamWatchdog watchdog,
                                StreamWatchdog.Mode mode) {
        Attempt a = new Attempt();
        HttpURLConnection conn = null;
        ScheduledFuture<?> stallCheck = null;
        try {
            String baseUrl = normalizeBaseUrl(getBaseUrl());
            conn = (HttpURLConnection) new URL(baseUrl + (isAnthropic() ? "/v1/messages" : "/chat/completions")).openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(10_000);                          /* 合同: connect 10s */
            conn.setReadTimeout(StreamWatchdog.readTimeoutMs(mode)); /* ≥ 阈值+30s, 看门狗先开火 */
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setRequestProperty("Accept", "text/event-stream");
            String apiKey = getApiKey();
            if (apiKey != null && !apiKey.trim().isEmpty()) {
                conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
            }
            JSONObject body = buildBody(userText, history, true);
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                os.flush();
            }
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) {
                a.errorClass = StreamWatchdog.classifyHttp(code);
                a.retryAfterSec = parseRetryAfter(conn.getHeaderField("Retry-After"));
                a.error = "AI 请求失败 (" + code + "): " + friendlyError(code, readErrorStream(conn));
                return a;
            }
            ACTIVE_CONNS.add(conn);
            /* 看门狗: 1s 周期检查, 停滞 → 杀流 (断开连接) */
            watchdog.reset();
            final HttpURLConnection fc = conn;
            final boolean[] stallKilled = {false};
            stallCheck = WATCHDOG_EXEC.scheduleWithFixedDelay(() -> {
                if (watchdog.isStalled()) {
                    stallKilled[0] = true;
                    watchdog.noteStall();
                    try { fc.disconnect(); } catch (Exception ignored) {}
                }
            }, 1, 1, TimeUnit.SECONDS);

            SseParser parser = new SseParser();
            StringBuilder content = new StringBuilder();
            String ctype = conn.getContentType() != null ? conn.getContentType() : "";
            boolean isSse = ctype.contains("event-stream");
            activeConn = conn;
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                if (isSse) {
                    String line;
                    while ((line = br.readLine()) != null && !cancelled && !stallKilled[0]) {
                        for (SseParser.Event ev : parser.feed(line + "\n")) {
                            if (ev.token != null) {
                                content.append(ev.token);
                                watchdog.recordChunk();          /* 只有真实 chunk 重置 (红线) */
                                if (listener != null) listener.onToken(ev.token);
                            }
                        }
                    }
                    for (SseParser.Event ev : parser.flush()) {
                        if (ev.token != null) {
                            content.append(ev.token);
                            if (listener != null) listener.onToken(ev.token);
                        }
                    }
                } else {
                    /* provider 不支持 SSE → 本会话降级非流式 (看门狗切 90s 档由调用方 mode 决定) */
                    StringBuilder all = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null && !cancelled) all.append(line);
                    JSONObject json = new JSONObject(all.toString());
                    String c = extractContent(json);
                    if (c.isEmpty()) {
                        a.error = "AI 没有返回内容";
                        return a;
                    }
                    content.append(c);
                    if (listener != null) listener.onToken(c);
                }
            } finally {
                activeConn = null;
                if (stallCheck != null) stallCheck.cancel(false);
            }
            if (stallKilled[0]) {
                a.stalled = true;
                a.errorClass = StreamWatchdog.ErrorClass.PROVIDER_CONNECTION;
                a.error = "停滞 " + StreamWatchdog.stallThresholdMs(mode) / 1000 + "s 无响应, 已断流重连";
                return a;
            }
            if (cancelled) {
                a.cancelled = true;
                return a;
            }
            String text = content.toString().trim();
            if (text.isEmpty()) {
                a.error = "AI 返回为空";
                return a;
            }
            a.content = text;
            a.pt = body.toString().length() / 4;
            a.ct = text.length() / 4;
            a.estimated = true;
            return a;
        } catch (java.net.SocketTimeoutException e) {
            a.errorClass = StreamWatchdog.ErrorClass.PROVIDER_CONNECTION;
            a.error = "连接/读取超时";
            return a;
        } catch (Exception e) {
            a.errorClass = StreamWatchdog.classifyError(e);
            a.error = "AI 调用异常: " + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName());
            return a;
        } finally {
            if (conn != null) conn.disconnect();
            ACTIVE_CONNS.remove(conn);
            if (stallCheck != null) stallCheck.cancel(false);
            activeConn = null;
        }
    }

    JSONObject buildBody(String userText, List<Message> history, boolean stream) throws Exception {  // 包级便于单测
        if (isAnthropic()) return buildAnthropicBody(userText, history, stream);
        JSONObject body = new JSONObject();
        body.put("model", getModelName());
        body.put("stream", stream);
        /* 限制输出 token 上限 (见 MAX_OUTPUT_TOKENS 注释) */
        body.put("max_tokens", MAX_OUTPUT_TOKENS);
        JSONArray messages = new JSONArray();
        messages.put(new JSONObject().put("role", "system").put("content", getSystemPrompt()));
        if (history != null) {
            for (Message m : history) {
                if (m == null || m.content == null) continue;
                if (!"user".equals(m.role) && !"assistant".equals(m.role)) continue;
                messages.put(new JSONObject().put("role", m.role).put("content", m.content));
            }
        }
        messages.put(new JSONObject().put("role", "user").put("content", userText));
        body.put("messages", messages);
        return body;
    }

    /** Anthropic Messages 请求体: {model, max_tokens, system, messages[], stream} */
    JSONObject buildAnthropicBody(String userText, List<Message> history, boolean stream) throws Exception {  // 包级便于单测
        JSONObject body = new JSONObject();
        body.put("model", getModelName());
        body.put("max_tokens", MAX_OUTPUT_TOKENS);
        body.put("system", getSystemPrompt());
        body.put("stream", stream);
        JSONArray messages = new JSONArray();
        if (history != null) {
            for (Message m : history) {
                if (m == null || m.content == null) continue;
                if (!"user".equals(m.role) && !"assistant".equals(m.role)) continue;
                messages.put(new JSONObject().put("role", m.role).put("content", m.content));
            }
        }
        messages.put(new JSONObject().put("role", "user").put("content", userText));
        body.put("messages", messages);
        return body;
    }

    /** Anthropic 非流式响应解析: content[] 数组拼 text（tool_use 块记录不执行, v1 计划模式不依赖） */
    static String extractAnthropicContent(JSONObject json) {
        JSONArray content = json.optJSONArray("content");
        if (content == null || content.length() == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < content.length(); i++) {
            JSONObject block = content.optJSONObject(i);
            if (block == null) continue;
            if ("text".equals(block.optString("type"))) {
                sb.append(block.optString("text", ""));
            }
        }
        return sb.toString().trim();
    }

    static String extractContent(JSONObject json) {
        JSONArray choices = json.optJSONArray("choices");
        if (choices == null || choices.length() == 0) return "";
        JSONObject choice = choices.optJSONObject(0);
        if (choice == null) return "";
        JSONObject msgObj = choice.optJSONObject("message");
        if (msgObj == null) return "";
        String content = msgObj.optString("content", "").trim();
        if (content.isEmpty()) content = msgObj.optString("reasoning_content", "").trim();
        return content;
    }

    private static int parseRetryAfter(String v) {
        if (v == null) return 0;
        try { return Integer.parseInt(v.trim()); } catch (Exception e) { return 0; }
    }

    private String normalizeBaseUrl(String baseUrl) {        if (baseUrl == null) return "";
        String s = baseUrl.trim();
        while (s.endsWith("/")) {
            s = s.substring(0, s.length() - 1);
        }
        return s;
    }

    private String readStream(HttpURLConnection conn) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
        }
        return sb.toString();
    }

    private String readErrorStream(HttpURLConnection conn) {
        try {
            if (conn.getErrorStream() == null) return "";
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private static String firstLine(String text) {
        if (text == null || text.trim().isEmpty()) return "无详细信息";
        int idx = text.indexOf('\n');
        if (idx > 0) return text.substring(0, idx).trim();
        return text.trim();
    }

    /**
     * HTTP 错误友好化: 常见状态码给中文提示, 并尽量带上服务端 error.message。
     * 包级 static 以便单测。
     */
    static String friendlyError(int code, String errBody) {
        String hint;
        switch (code) {
            case 400: hint = "请求参数错误"; break;
            case 401: hint = "API Key 无效或已过期"; break;
            case 402: hint = "余额不足，请充值后重试"; break;
            case 403: hint = "无权限访问该模型或接口"; break;
            case 404: hint = "模型不存在或接口地址错误"; break;
            case 429: hint = "请求过于频繁，请稍后再试"; break;
            default:  hint = null;
        }
        String server = extractServerMessage(errBody);
        if (hint != null) {
            // 服务端 message 与提示不重复时附上, 便于定位 (如具体欠费说明)
            return (server != null && !server.isEmpty() && !hint.contains(server))
                    ? hint + " · " + server : hint;
        }
        if (server != null && !server.isEmpty()) return server;
        return firstLine(errBody);
    }

    /** 从 OpenAI 兼容错误体提取 error.message / message, 失败返回 "" */
    static String extractServerMessage(String errBody) {
        try {
            JSONObject j = new JSONObject(errBody);
            JSONObject err = j.optJSONObject("error");
            if (err != null) return err.optString("message", "");
            return j.optString("message", "");
        } catch (Exception e) {
            return "";
        }
    }
}
