package com.hermes.android.vault;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Log;

import java.security.Key;
import java.security.KeyStore;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

/**
 * 生产 CryptoEngine — AndroidKeyStore 持有 AES-256-GCM 主密钥（不可导出、不落磁盘）。
 *
 * 加密本体委托 AesGcm（与 JVM 测试共用同一核心）；本类只负责在 AndroidKeyStore
 * 里取/生成密钥。密钥泄露路径 = 系统 keystore 自身，非 App 磁盘。
 *
 * v1.1 钥匙轮换/别名升级：别名版本化（mov_vault_key_v{N}）。`install -r` 保留旧别名
 * 的旧 spec 钥匙（加密修复对已装机不生效的根因）→ 升 KEY_VERSION 时新别名起新 key，
 * 旧 key 保留作 legacy（decryptLegacy 迁移回退），旧条目访问时经 SecureVault 重加密到新 key。
 */
public class KeystoreCrypto implements SecureVault.CryptoEngine {

    private static final String TAG = "KeystoreCrypto";
    private static final String KEYSTORE = "AndroidKeyStore";
    private static final String ALIAS_V1 = "mov_vault_key";
    /** 当前 key 版本：升版 = 换新别名 key，旧 key 自动变 legacy（迁移用） */
    private static final int KEY_VERSION = 2;

    // 安全决策：必须允许调用方 IV（RANDOMIZED_ENCRYPTION_REQUIRED=false）。
    // AesGcm 用 GCMParameterSpec 自管 IV（SecureRandom 每次随机），而 AndroidKeyStore 默认
    // 强制随机加密（要求 Keystore 自生成 IV）→ 真机 vaultLock 报 "Caller-provided IV not permitted"。
    // 此处显式关闭并做成常量：KeystoreCryptoTest 断言其为 false（任何回退立刻红）。
    static final boolean RANDOMIZED_ENCRYPTION_REQUIRED = false;

    /** 别名随版本：v1=mov_vault_key，v2+=mov_vault_key_v{N}（旧 key 保留供迁移） */
    static String aliasFor(int version) {
        return version <= 1 ? ALIAS_V1 : ALIAS_V1 + "_v" + version;
    }

    private final SecretKey key;
    private final SecretKey legacyKey;   // 旧别名 key（迁移用，可能无）

    public KeystoreCrypto() {
        try {
            this.key = getOrCreateKey(aliasFor(KEY_VERSION));
            this.legacyKey = loadKeyIfExists(aliasFor(KEY_VERSION - 1));
        } catch (Exception e) {
            Log.e(TAG, "AndroidKeyStore 初始化失败: " + e.getMessage());
            throw new VaultException("KEYSTORE_UNAVAILABLE", "保险柜加密不可用");
        }
    }

    private static SecretKey getOrCreateKey(String alias) throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        Key k = ks.getKey(alias, null);
        if (k instanceof SecretKey) return (SecretKey) k;
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
        kg.init(new KeyGenParameterSpec.Builder(alias,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(RANDOMIZED_ENCRYPTION_REQUIRED)
                .setKeySize(256)
                .build());
        return kg.generateKey();
    }

    /** 取指定别名已有 key；不存在返回 null（不新建——legacy 迁移只读旧 key） */
    private static SecretKey loadKeyIfExists(String alias) {
        if (alias == null) return null;
        try {
            KeyStore ks = KeyStore.getInstance(KEYSTORE);
            ks.load(null);
            Key k = ks.getKey(alias, null);
            return k instanceof SecretKey ? (SecretKey) k : null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override public byte[] encrypt(byte[] plaintext) throws Exception {
        return AesGcm.encrypt(key, plaintext);
    }

    @Override public byte[] decrypt(byte[] data) throws Exception {
        return AesGcm.decrypt(key, data);
    }

    /** v1.1: 尝试旧别名 key 解密（条目是升级前加密的）；非旧 key 加密返回 null */
    @Override public byte[] decryptLegacy(byte[] data) {
        if (legacyKey == null) return null;
        try {
            return AesGcm.decrypt(legacyKey, data);
        } catch (Exception e) {
            return null;
        }
    }
}
