/* ============================================================
   mov-mock.js — 模拟事件流生成器 (P1.5)
   大神终审 #2: 新渲染器用模拟事件流跑通, 不接真数据。
   含 typing/stream/瞬态交错, 验证投影顺序/去重/瞬态消亡。
   调用: MovMock.run(roomId) 或 MovMock.runSequence(roomId, events)
   ============================================================ */
var MovMock = (function(){
  var _seq = 0;
  var _timers = [];

  function nextSeq() { return ++_seq; }

  function emit(roomId, channel, event) {
    window._movEvent({ roomId: roomId, channel: channel, event: event });
  }

  function journalEvent(roomId, type, actor, payload, taskId) {
    var ev = { seq: nextSeq(), ts: Date.now(), actor: actor, type: type, taskId: taskId || null, payload: payload };
    emit(roomId, 'journal', ev);
    return ev;
  }

  function transientEvent(roomId, type, taskId, extra) {
    var ev = { type: type, taskId: taskId || '_mock' };
    if (extra) Object.keys(extra).forEach(function(k){ ev[k] = extra[k]; });
    emit(roomId, 'transient', ev);
  }

  /* 完整模拟: 一个任务从 user_input 到 deliver 的全流程 */
  function run(roomId, opts) {
    opts = opts || {};
    var taskId = 'mock' + Date.now();
    var delay = opts.delay || 200;
    var t = 0;

    function at(ms, fn) {
      var id = setTimeout(fn, ms);
      _timers.push(id);
    }

    /* 1. 用户输入 */
    at(t, function(){ journalEvent(roomId, 'user_input', 'user', { text: opts.goal || '做一个计算器' }); });
    t += delay;

    /* 2. typing 瞬态 */
    at(t, function(){ transientEvent(roomId, 'typing', taskId); });
    t += delay;

    /* 3. 阶段: 讨论中 */
    at(t, function(){ journalEvent(roomId, 'phase', 'kernel', { phase: '讨论中' }, taskId); });
    t += delay;

    /* 4. 流式 token (打字机) */
    var tokens = (opts.tokens || '让我分析一下需求，然后制定计划。').split('');
    tokens.forEach(function(tk, i) {
      at(t + i * 60, function(){ transientEvent(roomId, 'token', taskId, { text: tk }); });
    });
    t += tokens.length * 60 + delay;

    /* 5. 理解 */
    at(t, function(){ journalEvent(roomId, 'understand', 'brain', { summary: '用户需要一个带历史记录的计算器', audience: '普通用户', features: ['基础运算','历史记录'], acceptance: '可运行的单文件 HTML', defaults: ['深色主题'] }, taskId); });
    t += delay;

    /* 6. 计划 */
    at(t, function(){ journalEvent(roomId, 'plan', 'brain', { steps: [ { step: 1, action: 'file.write', path: 'calc.html', desc: '创建计算器主文件' }, { step: 2, action: 'file.write', path: 'style.css', desc: '样式' }, { step: 3, action: 'app.package', desc: '打包 APK' } ], estTokens: 12000, estSeconds: 60 }, taskId); });
    t += delay;

    /* 7. 闸: 计划确认 */
    at(t, function(){ journalEvent(roomId, 'gate', 'brain', { gate: 'plan', state: 'open' }, taskId); });
    t += delay;
    at(t, function(){ journalEvent(roomId, 'gate', 'user', { gate: 'plan', state: 'approved' }, taskId); });
    t += delay;

    /* 8. 阶段: 执行中 */
    at(t, function(){ journalEvent(roomId, 'phase', 'kernel', { phase: '执行中' }, taskId); });
    t += delay;

    /* 9. tool_call + tool_result */
    at(t, function(){ journalEvent(roomId, 'tool_call', 'worker', { name: 'file.write', args: { path: 'calc.html' }, idempotent: true, worker: 'native' }, taskId); });
    t += delay;
    at(t, function(){ journalEvent(roomId, 'tool_result', 'worker', { ok: true, durMs: 342, summary: 'OK: 已写入 calc.html (4.2KB)' }, taskId); });
    t += delay;

    at(t, function(){ journalEvent(roomId, 'tool_call', 'worker', { name: 'file.write', args: { path: 'style.css' }, idempotent: true, worker: 'native' }, taskId); });
    t += delay;
    at(t, function(){ journalEvent(roomId, 'tool_result', 'worker', { ok: true, durMs: 128, summary: 'OK: 已写入 style.css (1.1KB)' }, taskId); });
    t += delay;

    /* 10. 一个失败的工具调用 */
    at(t, function(){ journalEvent(roomId, 'tool_call', 'worker', { name: 'shell.exec', args: { cmd: 'npm test' }, idempotent: false, worker: 'linux' }, taskId); });
    t += delay;
    at(t, function(){ journalEvent(roomId, 'tool_result', 'worker', { ok: false, durMs: 2100, summary: 'exit=1\nError: no test specified', error: 'exit=1' }, taskId); });
    t += delay;

    /* 11. note */
    at(t, function(){ journalEvent(roomId, 'note', 'kernel', { text: '测试未配置, 跳过' }, taskId); });
    t += delay;

    /* 12. 交付 (终态 → 清瞬态; 2026-07-30 评审机制移除, mock 不再发 review 事件) */
    at(t, function(){
      journalEvent(roomId, 'deliver', 'kernel', {
        summary: '计算器已完成，支持基础四则运算和历史记录。',
        files: ['calc.html', 'style.css'],
        standard: '上线级',
        metrics: { promptTokens: 8200, completionTokens: 3100, estTokens: 12000, elapsedSec: 45 }
      }, taskId);
    });
    t += delay;

    /* 13. 阶段: 已交付 */
    at(t, function(){ journalEvent(roomId, 'phase', 'kernel', { phase: '已交付' }, taskId); });

    return { taskId: taskId, totalMs: t };
  }

  /* 自定义事件序列 (验收用: 精确控制顺序/去重/瞬态交错) */
  function runSequence(roomId, events, interval) {
    interval = interval || 100;
    events.forEach(function(item, i) {
      var id = setTimeout(function() {
        emit(roomId, item.channel || 'journal', item.event);
      }, i * interval);
      _timers.push(id);
    });
  }

  /* 重复 seq 事件 (去重测试) */
  function runDuplicateTest(roomId) {
    var ev1 = { seq: 901, ts: Date.now(), actor: 'user', type: 'user_input', taskId: null, payload: { text: '第一条' } };
    var ev2 = { seq: 901, ts: Date.now(), actor: 'user', type: 'user_input', taskId: null, payload: { text: '重复的!' } };
    var ev3 = { seq: 902, ts: Date.now(), actor: 'kernel', type: 'note', taskId: null, payload: { text: '第二条' } };
    emit(roomId, 'journal', ev1);
    emit(roomId, 'journal', ev2); /* 同 seq, 应被去重 */
    emit(roomId, 'journal', ev3);
  }

  /* 瞬态消亡测试: token 流 → 终态 → 迟到 token 不复活 */
  function runTransientDeathTest(roomId, taskId) {
    taskId = taskId || 'death-test';
    transientEvent(roomId, 'token', taskId, { text: '部分' });
    transientEvent(roomId, 'token', taskId, { text: '文本' });
    /* 终态: 清瞬态 */
    journalEvent(roomId, 'deliver', 'kernel', { summary: '完成', files: [], metrics: {} }, taskId);
    /* 迟到 token: 不应复活 */
    transientEvent(roomId, 'token', taskId, { text: '迟到' });
  }

  function stop() {
    _timers.forEach(function(id) { clearTimeout(id); });
    _timers = [];
  }

  function resetSeq() { _seq = 0; }

  return {
    run: run,
    runSequence: runSequence,
    runDuplicateTest: runDuplicateTest,
    runTransientDeathTest: runTransientDeathTest,
    stop: stop,
    resetSeq: resetSeq,
    emit: emit,
    journalEvent: journalEvent,
    transientEvent: transientEvent
  };
})();
