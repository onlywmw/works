package com.hermes.android.toolprovider;

import android.content.Context;

import com.hermes.android.agent.ToolRegistry;
import com.hermes.android.agent.ToolRegistry.*;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;

/**
 * FileOpsProvider — 文件操作工具 (Dyad 对标: file_ops 系列)。
 * file.rename / file.delete / file.copy / search.replace
 */
public class FileOpsProvider implements ToolProvider {

    private static Context appContext;
    public static void init(Context ctx) { appContext = ctx.getApplicationContext(); }

    @Override public String id() { return "file-ops"; }

    /** 安全解析房间内的文件路径，拒绝 ../ 逃逸 */
    private static File resolveRoomFile(File roomDir, String path) {
        File f = new File(roomDir, path);
        try {
            if (!f.getCanonicalPath().startsWith(roomDir.getCanonicalPath() + File.separator)
                && !f.getCanonicalPath().equals(roomDir.getCanonicalPath()))
                return null;
        } catch (IOException e) { return null; }
        return f;
    }

    @Override
    public List<Tool> discover() {
        List<Tool> list = new ArrayList<>();
        if (appContext == null) return list;

        // ═══ file.rename — 重命名 ═══
        list.add(new Tool("file.rename",
            "重命名房间内的文件或文件夹。不能跨目录移动，仅改名",
            null, a -> {
                String from = a.optString("from", "");
                String to = a.optString("to", "");
                if (from.isEmpty() || to.isEmpty()) return new Result(false, "参数 from/to 不能为空");
                try {
                    File roomDir = new File(appContext.getFilesDir(), "rooms/work");
                    File src = resolveRoomFile(roomDir, from);
                    File dst = resolveRoomFile(roomDir, to);
                    if (src == null || dst == null) return new Result(false, "路径无效（不允许 ../ 逃逸）");
                    if (!src.exists()) return new Result(false, "源文件不存在: " + from);
                    if (dst.exists()) return new Result(false, "目标已存在: " + to);
                    if (!src.getParentFile().equals(dst.getParentFile()))
                        return new Result(false, "不允许跨目录移动，只能在同目录内改名。用 shell.exec mv 跨目录");
                    if (src.renameTo(dst)) return new Result(true, from + " → " + to);
                    return new Result(false, "重命名失败（可能权限不足或文件被占用）");
                } catch (Exception e) {
                    return new Result(false, "重命名失败: " + e.getMessage());
                }
            }, "native", "write", "plan", false, 5, "file",
            new ParamDef[]{
                new ParamDef("from", "string", true, "", "源文件路径（相对房间根目录）"),
                new ParamDef("to", "string", true, "", "目标文件名（仅改名，不能跨目录）"),
            },
            "成功: from → to | 失败: 错误原因",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"file.rename\",\"args\":{\"from\":\"old.html\",\"to\":\"new.html\"}}"},
            new String[]{"仅限同目录内改名", "跨目录请用 shell.exec mv", "目标已存在会报错"},
            1000,
            new ToolRegistry.Manifest("重命名", "medium", "重命名文件", false, "io"),
            null));

        // ═══ file.delete — 删除 ═══
        list.add(new Tool("file.delete",
            "删除房间内的文件或空文件夹",
            null, a -> {
                String path = a.optString("path", "");
                if (path.isEmpty()) return new Result(false, "path 不能为空");
                try {
                    File roomDir = new File(appContext.getFilesDir(), "rooms/work");
                    File f = resolveRoomFile(roomDir, path);
                    if (f == null) return new Result(false, "路径无效（不允许 ../ 逃逸）");
                    if (!f.exists()) return new Result(false, "文件不存在: " + path);
                    if (f.isDirectory()) {
                        String[] children = f.list();
                        if (children != null && children.length > 0)
                            return new Result(false, "文件夹非空（含 " + children.length + " 个文件），用 shell.exec rm -rf 强制删除");
                    }
                    if (f.delete()) return new Result(true, "已删除: " + path);
                    return new Result(false, "删除失败（可能权限不足或文件被占用）");
                } catch (Exception e) {
                    return new Result(false, "删除失败: " + e.getMessage());
                }
            }, "native", "write", "always", false, 5, "file",
            new ParamDef[]{
                new ParamDef("path", "string", true, "", "要删除的文件路径（相对房间根目录）"),
            },
            "成功: 已删除 + 路径 | 失败: 错误原因",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"file.delete\",\"args\":{\"path\":\"temp.txt\"}}"},
            new String[]{"不可恢复！确认前检查", "非空文件夹拒绝删除（安全保护）", "空文件夹可以删除"},
            1000,
            new ToolRegistry.Manifest("删除文件", "high", "永久删除文件", false, "io"),
            null));

        // ═══ file.copy — 复制 ═══
        list.add(new Tool("file.copy",
            "复制文件到同房间另一个位置",
            null, a -> {
                String from = a.optString("from", "");
                String to = a.optString("to", "");
                if (from.isEmpty() || to.isEmpty()) return new Result(false, "参数 from/to 不能为空");
                try {
                    File roomDir = new File(appContext.getFilesDir(), "rooms/work");
                    File src = resolveRoomFile(roomDir, from);
                    File dst = resolveRoomFile(roomDir, to);
                    if (src == null || dst == null) return new Result(false, "路径无效（不允许 ../ 逃逸）");
                    if (!src.exists()) return new Result(false, "源文件不存在: " + from);
                    if (src.isDirectory()) return new Result(false, "不支持复制文件夹，用 shell.exec cp -r");
                    if (dst.exists() && !a.optBoolean("overwrite", false))
                        return new Result(false, "目标已存在: " + to + "（传 overwrite:true 覆盖）");
                    dst.getParentFile().mkdirs();
                    try (FileInputStream fis = new FileInputStream(src);
                         FileOutputStream fos = new FileOutputStream(dst);
                         FileChannel in = fis.getChannel();
                         FileChannel out = fos.getChannel()) {
                        in.transferTo(0, in.size(), out);
                    }
                    long size = dst.length();
                    String sz = size >= 1000 ? (size/1000) + "KB" : size + "B";
                    return new Result(true, from + " → " + to + " (" + sz + ")", to);
                } catch (Exception e) {
                    return new Result(false, "复制失败: " + e.getMessage());
                }
            }, "native", "write", "plan", false, 30, "file",
            new ParamDef[]{
                new ParamDef("from", "string", true, "", "源文件路径"),
                new ParamDef("to", "string", true, "", "目标路径"),
                new ParamDef("overwrite", "boolean", false, "默认 false", "是否覆盖已存在文件"),
            },
            "成功: 路径 + 大小 | 失败: 错误原因",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"file.copy\",\"args\":{\"from\":\"a.html\",\"to\":\"backup/a.html\"}}"},
            new String[]{"只支持文件（非文件夹）", "大文件（>10MB）建议用 shell.exec cp", "目标目录不存在会自动创建"},
            2000,
            new ToolRegistry.Manifest("复制文件", "low", "复制文件", false, "io"),
            null));

        // ═══ search.replace — 精确搜索替换 ═══
        list.add(new Tool("search.replace",
            "精确搜索替换文件中的文本片段（old→new）。只替换第一次出现。改一行不用传全文，省 token",
            null, a -> {
                String path = a.optString("path", "");
                String oldStr = a.optString("old", "");
                String newStr = a.optString("new", "");
                if (path.isEmpty() || oldStr.isEmpty()) return new Result(false, "path 和 old 不能为空");
                try {
                    File roomDir = new File(appContext.getFilesDir(), "rooms/work");
                    File f = resolveRoomFile(roomDir, path);
                    if (f == null) return new Result(false, "路径无效");
                    if (!f.exists()) return new Result(false, "文件不存在: " + path);
                    if (f.length() > 500_000) return new Result(false, "文件过大（>" + (f.length()/1000) + "KB），用 shell.exec sed");
                    String content = new String(java.nio.file.Files.readAllBytes(f.toPath()), "UTF-8");
                    int idx = content.indexOf(oldStr);
                    if (idx < 0) {
                        // 尝试宽松匹配：去掉首尾空白
                        String trimmed = oldStr.trim();
                        idx = content.indexOf(trimmed);
                        if (idx < 0) return new Result(false, "未找到匹配文本。检查 old 是否和文件中完全一致（含缩进/换行）。提示: 先用 file.read 确认内容");
                    }
                    String replaced = content.substring(0, idx) + newStr + content.substring(idx + oldStr.length());
                    java.nio.file.Files.write(f.toPath(), replaced.getBytes("UTF-8"));
                    int linesBefore = content.substring(0, idx).split("\n").length;
                    return new Result(true, "第 " + linesBefore + " 行已替换 (" + oldStr.length() + "→" + newStr.length() + " 字符)", path);
                } catch (Exception e) {
                    return new Result(false, "替换失败: " + e.getMessage());
                }
            }, "native", "write", "plan", false, 15, "file",
            new ParamDef[]{
                new ParamDef("path", "string", true, "", "要修改的文件路径"),
                new ParamDef("old", "string", true, "", "要替换的原文（必须和文件中完全一致）"),
                new ParamDef("new", "string", false, "默认 \"\"", "替换后的文本（空字符串=删除）"),
            },
            "成功: 第 N 行已替换 (old长度→new长度) | 失败: 未找到匹配/错误",
            new String[]{"{\"action\":\"tool.execute\",\"name\":\"search.replace\",\"args\":{\"path\":\"index.html\",\"old\":\"<title>OLD</title>\",\"new\":\"<title>NEW</title>\"}}"},
            new String[]{"仅替换第一次出现", "文件 >500KB 拒绝（用 shell.exec sed）", "old 必须和文件中完全一致（含空格/换行）", "先 file.read 确认后再替换"},
            5000,
            new ToolRegistry.Manifest("搜索替换", "medium", "精确替换文本片段", true, "io"),
            null));

        return list;
    }
}
