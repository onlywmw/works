# Hermes「强化记忆」真相与改造建议

> 状态：✅ P6 派单№3 完成（只读探索 + 设计建议，未动 hermes-agent）
> 日期：2026-08-02
> 依据：docs/TASKS_P6_HERMES_MEMORY_2026-08-02.md；分析对象 = hermes-agent（.ocr_p0/hermes_anatomy/ 解压副本）
> 结论一句话：**「越用越聪明」真实存在但边界严格**——真持久的是「策展记忆（MEMORY.md/USER.md）+ 技能落盘（SKILL.md）+ 间隔触发的后台 review fork」三件组合；**不是**「用一次就学会一个技能」「记住一切」；`learning_graph.py` 只画图不学习（名字误导）；记忆压缩是纯会话内 token 管理。
> 纪律：引用带 文件:行号；验收人抽查 4 处已自验（memory 字符上限、background_review fork、技能索引注入、system_prompt 记忆注入）。

---

## 一、真相：四机制逐条定性（传闻 vs 实况）

### 1.1 会话状态 —— 持久存档，不是自动记忆

**是什么**：`hermes_state.py` SQLite（`state.db`，DEFAULT_DB_PATH = `get_hermes_home()/state.db`，hermes_state.py:153）。`sessions`/`messages` 表，每次 agent 使用自动建行。
**生命周期**：跨进程持久（重启不删）。`create_session` 是 upsert（hermes_state.py:1974-2009），`append_message` 每次 INSERT（:4152），`end_session` 只打 ended_at 标记（:2359-2375）——从不删除记录。
**关键定性：是「存档」不是「自动记忆」**：
- 写入是**懒触发**（run_agent.py:614 `_ensure_db_session`，首次使用才建）
- 恢复是**显式**的：`/resume` 用 `get_messages_as_conversation` 塞回历史（cli_agent_setup_mixin.py:497-502）；跨会话检索是 `session_search` 工具**主动调** `search_messages`（hermes_state.py:5443，FTS5）才拿得到
- **历史不会自己进 system prompt**——agent 不会「自动记得上次」，须用户 `/resume` 或 agent 主动 search

### 1.2 技能/经验积累 —— 真持久，但「用一次会一个」是夸大

**learning_graph.py 是纯可视化**：docstring 明说「Assemble the learning-made-visible graph for desktop」（learning_graph.py:1-13）。`build_skill_nodes`(:125) 只扫描磁盘上已有 SKILL.md，`build_edges`(:156) 只读 frontmatter 的 related_skills，**它不产生任何技能**。`learning_mutations.py` 只是把图上节点映射回磁盘文件做用户 edit/delete。**名字最误导的模块**。

**技能的来源**（三通道）：
1. **预设/安装**：仓库自带 skills/apple、skills/software-development 等整目录（learning_graph.py:248-251 区分 base=repo 与 profile=~/.hermes/skills）；`hermes skills install` 走 skills_hub.py
2. **agent 主动存**：system prompt 注入 SKILLS_GUIDANCE，指示模型复杂任务后自动 `skill_manage` 存技能（prompt_builder.py:189-195，注入点 system_prompt.py:227-228）——但 create **要求 LLM 手写完整 SKILL.md**（skill_manager_tool.py:1340,1374-1377），不是系统自动蒸馏
3. **后台 review fork（自动通道）**：每轮对话后 `background_review.py` fork 受限 agent 回放会话问「该存记忆/建技能吗」（:1-8,956-981）。**间隔门控**：技能每 10 次工具迭代（agent_init.py:1530-1533，turn_finalizer.py:577-581）、记忆每 10 轮（agent_init.py:1437）才触发一次。**best-effort**（turn_finalizer.py:600-601 try/except pass）。评审 prompt 明确禁止建「一次会话一个」的窄技能（background_review.py:236-241）

**定性：真持久（SKILL.md 跨会话复用），但「用一次会一个」是夸大**——技能绝大多数预设/安装，自动生成是间隔触发 + best-effort + LLM 手写。

### 1.3 记忆压缩 —— 纯会话内 token 管理，不产出长期记忆

**是什么**：`ContextCompressor.compress`（context_compressor.py:3312）把中间轮次替换成一条 LLM 摘要消息，保留头部+尾部 ~20K token（docstring :3322-3340，算法 :3392-3425）。
**生产在用**：run_agent.py:158 import，:652/:762/:799/:3470 多处调用。
**关键定性：会话内，不是跨会话记忆**：
- `on_session_end`（context_compressor.py:900-930）**只重置内部状态**，docstring 明说「Clear all per-session compaction state」——不提取、不写记忆、不持久化
- 压缩分裂 SQLite 会话（旧 session end_reason="compression"，conversation_compression.py:1266；新子 session parent_session_id=旧 id，:1268,1294-1299），旧转录存档可被 FTS5 搜（hermes_state.py:5475-5480）——这是**存档连续性**，不是记忆
- trajectory_compressor.py（解剖确认）是 dev/RL 脚本，非生产

### 1.4 prompt 记忆注入 —— 真跨会话，但「策展 + 限量 + 冻结快照」

**是什么**：system_prompt 三档（stable/context/volatile，system_prompt.py:147）。volatile tier（:480-518）注入：
- 记忆快照 `_memory_store.format_for_system_prompt("memory")`（:483-487）
- USER.md 画像（:489-492）
- 外部 memory provider 块（:495-501）

**MemoryStore**（tools/memory_tool.py:123）：
- 持久化到 `HERMES_HOME/memories/MEMORY.md` + `USER.md`（:55-57,319-322），原子写 + 文件锁（:253-288）
- **字符上限：memory 2200 / user 1375**（:140-146,814-815）
- **冻结快照**：`load_from_disk` 固化进 `_system_prompt_snapshot`（:178-215），`format_for_system_prompt` 只返回快照（:625-636）——**会话中途写入立即落盘但不改本会话 prompt，下个会话才注入**
- 不读会话态（memory_tool.py 搜 create_session/search_messages 0 处）——独立于 state.db

**定性：真跨会话持久记忆，但是「策展 + 限量 + 冻结」**——只存 agent/review fork 主动写的高信号条目，有字符上限，注入的是会话开始时的冻结快照。

### 1.5 传闻 vs 实况对照表

| 常见说法 | 实况（诚实版） | 行号证据 |
|---|---|---|
| **越用越聪明（持久学习）** | **半真**。持久通道真实存在，但 =「策展记忆（限量）+ 间隔触发 review fork 建技能 + 显式恢复的存档」三件拼成。不是每次对话自动生效；review 默认间隔 + best-effort | background_review.py:1-8,956-981；agent_init.py:1437,1530-1533；memory_tool.py:140-146 |
| **自动学技能（用一次会一个）** | **否**。技能绝大多数预设/安装。skill_manage create 要求 LLM 手写完整 SKILL.md；唯一「自动」是间隔触发 review fork，且禁止建窄技能 | skill_manager_tool.py:1340,1374-1377；background_review.py:236-241；learning_graph.py:248-251 |
| **记住一切（完整记忆）** | **否**。内置记忆策展+限量（MEMORY 2200/USER 1375 字符），只存主动写的高信号条目；历史转录只存档，须 /resume 或 session_search 显式取回 | memory_tool.py:140-146,625-636；hermes_state.py:5443 |
| **记忆压缩省 token** | **属实但仅会话内**。压缩保头保尾 ~20K，分裂会话存档；on_session_end 只清状态不产出记忆 | context_compressor.py:3312,900-930；conversation_compression.py:1266 |
| **learning_graph = 学习** | **否**。纯可视化，扫描已有 SKILL.md 画图，不产生技能 | learning_graph.py:1-13,125,156 |
| **会话状态持久（重启不丢）** | **属实但只是存档**。state.db 持久；/resume 显式续跑（含压缩祖先世系）；agent 不会自动记得 | hermes_state.py:153,2011,2359,4152,4505,5020 |

---

## 二、与 MOV journal 的统一评估

MOV 已有：journal（append-only 事件溯源，F3 记忆工具包，唯一事件源）+ BridgeAi（LLM）+ ToolRegistry（工具）+ 保险柜（隐私）。评估 hermes 记忆机制：

| hermes 机制 | 搬 / 砍 / 保留 | 理由 | 统一路径 |
|---|---|---|---|
| **memory_tool（MEMORY.md/USER.md 策展记忆）** | **值得搬（改造后）** | 这是 hermes 最接近「强化记忆」的真持久件。MOV journal 是事件流，缺「高信号策展条目」层——把 memory 条目作为 journal 的**特殊事件类型**（`_memory_event`），带字符上限/策展纪律 | 写入经 serve → journal `_memory_event`；读取经 journal 回放投影 |
| **技能体系（SKILL.md 落盘 + 索引注入）** | **值得搬（保留核心）** | SKILL.md 跨会话复用是真资产。MOV 有技能体系（AgentLoop skills）——统一 SKILL.md 格式，注入 MOV 技能索引 | skills 目录经 /exchange 文件交换，或 journal 记录技能创建事件 |
| **background_review fork** | **保留但收敛** | 间隔触发 + best-effort 的自动学习是好的，但「fork 重放会话」重（token）。MOV 可轻量化为「session 结束钩子」提炼 | serve 在 session end 触发提炼，写入 journal |
| **context_compressor（会话内压缩）** | **砍（MOV 已覆盖）** | 纯会话内 token 管理，MOV 慢脑有自己的上下文策略；且分裂会话存档（parent_session 链）与 journal 单一事件源冲突 | 砍掉，MOV 用自己的压缩 |
| **learning_graph / learning_mutations** | **砍（重复建设）** | 纯可视化 + 手动 edit，MOV 有更好的 UI（journal 回放投影） | 砍 |
| **hermes_state（SQLite 会话存档）** | **砍（journal 取代）** | MOV journal 是唯一事件源；hermes_state 的 session/messages 表是重复存档 | 砍，会话事件全进 journal |
| **session_search / memory 的 FTS5 检索** | **MOV journal 替代** | journal 事件流天然可检索 | MOV 实现 |

**统一读写路径结论**：经 **journal**（唯一事件源）——hermes serve 模式的记忆读写改走 journal 事件；skills/ 等文件资产经 /exchange 文件交换。不再维护 hermes_state.db 的独立存档。

---

## 三、验收人五能力改造建议（落 hermes 具体文件/机制）

> 参照系 = 验收人工作方式（验证驱动/状态外化/时间盒/打回式修正/诚实边界）。每条：现状 → 改造点 → 预期收益。

### 3.1 验证回路（完成前自验，不信自述）

**现状**：hermes 工具执行后直接返回结果给 LLM（tools/registry.py:614 dispatch → handler(args)），无独立验证回路。`skill_manager_tool._create_skill`（:842-847）写完 SKILL.md 直接返回成功，不校验内容有效性。工具 handler 对「命令跑完但 exit≠0」等失败是否如实上报，取决于单个 handler。

**改造点**：
- `skill_manager_tool._create_skill`（:842）写完落盘前加 `_validate_skill_md()`：解析 frontmatter 必需字段（name/description）、body 非空、引用文件存在——**校验失败拒绝落盘并返回「SKILL_MD_INVALID + 具体问题」**
- `tools/registry.py:614` dispatch 的归一化处：handler 返回加 `verified` 字段（执行侧自验结果，如 terminal exit code、文件写入后读回校验），LLM 看到 verified=false 不把结果当成功
- `tools/terminal_tool.py`（140KB）命令执行后：exit code ≠ 0 时结果标 `{ok:false, exit_code:N, stderr}`，而不是只给 stdout

**预期收益**：杜绝「执行了但失败」被 LLM 当成功继续往下编——把验收人「不信自报」落到工具层。

### 3.2 状态外化（工作记忆落盘，断点续跑）

**现状**：hermes 工作记忆在 context（volatile tier），会话间靠 memory 工具**显式**写策展条目（memory_tool.py:625-636 冻结快照）。**进行中的任务状态（当前计划/已完成/下一步）没有落盘**——context 一压缩/会话一断，进行中状态丢失。

**改造点**：
- `agent/conversation_loop.py:588` run_conversation 主循环每轮结束，把「当前 plan + 已完成步 + 下一步 + 关键结论」写入 `HERMES_HOME/state/work.md`（或 journal 事件 `_task_state`）
- `run_agent` resume 路径（cli_agent_setup_mixin.py:497 /resume）注入 work.md 的「下一步」，实现断点续跑
- 周期性（每 N 轮或压缩前）同步，不等会话结束

**预期收益**：会话中断/压缩/进程重启后，agent 能接着干（验收人 TASKBOARD/任务文档全落盘同理）。

### 3.3 时间盒 + 方法栈（卡壳换方法，不闷头重试）

**现状**：hermes 重试是 `agent/retry_utils.py` jittered_backoff（指数退避）+ tenacity（chat_completion_helpers 的重试装饰）。**没有「重试 N 次后换方法」机制**——重试耗尽只报「请求失败」，不引导换策略。

**改造点**：
- `chat_completion_helpers.interruptible_api_call`（:4844）重试耗尽后，错误消息带 **FailoverReason 分类**（复用 agent/error_classifier.py）——「已重试 N 次，错误类型 X，建议换方法 Y」
- `run_agent` 收到带 FailoverReason 的错误时，system prompt 指示「同方法重试上限 N 次，之后必须换策略（换 provider/改提示/拆步骤）」——把时间盒写进 agent 行为
- `agent/tool_result_classification.py` 对工具失败同样分类反馈

**预期收益**：卡壳不烧 token 死磕（验收人 llmexport 2h、int8 半天的时间盒同理）。

### 3.4 打回式修正（失败产出「根因 + 修法」）

**现状**：`agent/error_classifier.py` 分类错误（FailoverReason），`tools/registry.py:614` dispatch 异常归一化（tool_result/tool_error）。但错误反馈是「异常堆栈 + 消息」，**没有「根因 + 建议修法」**——LLM 常盲试。

**改造点**：
- `tools/registry.py:614` dispatch 的异常处理处：错误归一化时附加 `root_cause`（分类）+ `suggested_fix`（基于 FailoverReason 的修法提示），如「文件不存在 → 先 list 确认路径」
- `agent/tool_result_classification.py` 同样给「根因分类 + 修法」双字段
- system prompt 指示：收到带 root_cause 的错误，先按修法调整再重试，不原样重发

**预期收益**：错误 → 一次修正（验收人「文件:行号 + 修法」同理），减少盲试循环。

### 3.5 诚实边界（缺数据明说，不编）

**现状**：hermes 无强制诚实边界。工具返回空（如搜索无结果）时，归一化成空 ok，LLM 可能基于「无数据」编造；API 错误被 tenacity 吞掉后 LLM 可能臆测原因。

**改造点**：
- `tools/registry.py` 工具结果归一化：data 为空/查询无命中 → 显式 `{ok:false, reason:NO_DATA}`（而非空 ok），让 LLM 明说「无法确认」
- `chat_completion_helpers` 的失败分支：错误消息带「实际发生了什么 + 未确认项」，禁止 LLM 猜原因
- system_prompt 或 prompt_builder.py 加诚实边界指令：「缺数据/不确定时输出『无法确认』并说明缺什么，不编造」

**预期收益**：缺数据=FAIL（验收人 rootfs 被清时如实挂起同理），防幻觉之源。

---

## 四、结论与阶段 3 落地优先级

1. **真相**：hermes「越用越聪明」= 策展记忆（限量）+ 间隔 review fork 建技能 + 显式恢复存档，**真持久但边界严格**；learning_graph 误导、压缩是会话内。
2. **评估**：memory_tool + 技能体系值得搬（journal 事件类型 + SKILL.md 统一）；hermes_state/learning_graph/context_compressor 砍（journal 取代/重复建设）。
3. **改造**：五能力都落到具体文件——验证回路（skill_manager/registry dispatch/terminal_tool）、状态外化（conversation_loop + work.md）、时间盒（retry 耗尽带 FailoverReason 换方法）、打回修正（registry 错误归一化带 root_cause+suggested_fix）、诚实边界（NO_DATA 显式 + prompt 指令）。
4. **优先级建议**：先 3.1 验证回路 + 3.5 诚实边界（正确性底线）→ 3.4 打回修正（效率）→ 3.2 状态外化（长任务）→ 3.3 时间盒（防烧 token）。

## 验收自验（抽查 4 处）

| 论断 | 证据（已实测） |
|---|---|
| memory 字符上限 2200/1375 | tools/memory_tool.py:140-142 `__init__(memory_char_limit=2200, user_char_limit=1375)` |
| 后台 review fork | agent/background_review.py:1-10 「fork the agent to evaluate the turn...replays the conversation snapshot」 |
| 技能索引注入 | agent/prompt_builder.py:1747 `<available_skills>` + index_lines |
| 记忆注入 volatile tier | agent/system_prompt.py:483-492 `_memory_store.format_for_system_prompt("memory")` |
