# 视觉编码器 MNN 移植（P1）交付

> 状态：✅ P1 完成（SAM-ViT-B + CLIP-L → ONNX → MNN，base 模式）
> 日期：2026-08-01
> 判据：docs/DESIGN_OCR_MOBILE.md P1 —— 同一测试图，MNN 输出与 PyTorch 参考**余弦相似度 ≥0.99**
> 结果：**3 张黄金图全部 PASS（0.999891 ~ 0.999982）**

## 1. 验收结果（3 张黄金图，base 模式 1024×1024 → 273 token）

| 黄金图 | COSINE 相似度 | content[0:256] | newline[256:272] | sep[272] |
|---|---|---|---|---|
| golden1_doc_chinese | **0.999961** | 0.999959 | 0.999988 | 1.000000 |
| golden2_paper | **0.999891** | 0.999886 | 0.999989 | 1.000000 |
| golden3_receipt | **0.999982** | 0.999982 | 0.999997 | 1.000000 |

> 计算方式：MNN 输出张量（273×1280）与 PyTorch fp32 参考逐元素余弦相似度（对整段 reshape 到 1-D 计算）。视觉编码器输出是 fp32（导出时视觉子模块转 fp32），参考同为 fp32。
> 全管线在平板 CPU 耗时：SAM ≈18.6s + CLIP+proj ≈4.9s ≈ 23.5s（P4 上 Adreno GPU 后目标是 ≤2s）。

## 2. 导出结构（分图方案）

视觉编码器完整 DAG 一次性 ONNX 导出在 TorchScript 追踪时 OOM（36 层 transformer + 窗口注意力的追踪 IR 爆炸）。**拆两图**：

| MNN 模型 | 输入 | 输出 | 大小 | SHA256 |
|---|---|---|---|---|
| `sam.mnn` | image (1,3,1024,1024) | f1 (1,1024,16,16) | 383MB | `a450360a...85263f` |
| `clip_proj.mnn` | f1 (1,1024,16,16) | feats (273,1280) | 1221MB | `fef8a90d...f5119e` |

计算链（与 PyTorch 参考逐位对应）：
```
image → SAM-ViT-B (patch16 + 12层 + neck + net_2/net_3 两级stride2下采样 64→16)
      → f1 (1024,16,16)
      → CLIP-L (patch_embeds=f1, class_embed + 绝对位置插值 + 24层 transformer)
      → f2 (257,1024)  → cat(f2[1:], f1.flatten) → (256,2048)
      → projector (linear 2048→1280) → (256,1280)
      → token 布局: +image_newline 16行 → (272,1280) + view_seperator → (273,1280)
```
- **base 模式**（无 crop），token 布局折叠进 clip_proj.mnn（image_newline/view_seperator 为图中常量）
- CLIP 的 `pixel_values` 仅用于取 `batch_size`，导出时以常量 dummy 提供（batch=1 固化）
- 位置嵌入在 base 尺寸下 src==tgt，无 bicubic 插值（`get_abs_pos`/`get_abs_pos_sam` 走直通分支）

## 3. 复现

```bash
# ① 导出 ONNX + PyTorch fp32 参考 (平板 proot, 需先下载模型)
python3 ocr/scripts/export_vision_onnx.py --model /path/model \
    --image golden1_doc_chinese.png --out vision/          # 出 sam.onnx + clip_proj.onnx + ref_*.npy
# ② ONNX → MNN
python3 -m MNN.tools.mnnconvert -f ONNX --modelFile vision/sam.onnx       --MNNModel vision/sam.mnn
python3 -m MNN.tools.mnnconvert -f ONNX --modelFile vision/clip_proj.onnx --MNNModel vision/clip_proj.mnn
# ③ 余弦验证 (MNN vs PyTorch)
python3 ocr/scripts/verify_vision_mnn.py --dir vision/ --image golden1_doc_chinese.png
#    → COSINE_SIM ≥0.99 即过
```

> 注：`.mnn` 为派生产物（~1.6GB），**不进 git**——脚本可重生成，SHA256 见上表作校验。

## 4. 环境依赖与坑（P1 实录）

- MNN：`pip install MNN`（3.6.1，aarch64 有 wheel）；转换器 `python -m MNN.tools.mnnconvert -f ONNX`
- torch.onnx.export 需 `dynamo=False`（legacy 导出器）：torch 2.13 默认新 Dynamo 导出器对窗口注意力的数据相关 reshape 报错
- **OOM**：整模型（含 bf16 解码器 6.2GB）占内存导致追踪 OOM → 导出前 `del model.model.layers; del model; gc.collect()` 只留视觉 fp32 子模块 + 分图
- **MNN Python API**（关键）：
  - 输入用 `input_tensor.copyFromHostTensor(MNN.Tensor(shape, type, numpy, Caffe))`——`copyFrom`（无 Host）会静默全零
  - 输出用 `out_tensor.getNumpyData()`，**必须 `np.array(...)` 拷贝**——`interp/session` 是函数局部，返回后 GC 释放内部缓冲，视图悬垂会 segfault
  - `MNN.Tensor.fromNumpy()` 在当前绑定有 bug（descriptor 报错），用构造器传 numpy 数组

## 5. 交付物

| 文件 | 说明 |
|---|---|
| `ocr/scripts/export_vision_onnx.py` | 分图 ONNX 导出 + PyTorch fp32 参考（--skip-export 只算参考） |
| `ocr/scripts/verify_vision_mnn.py` | MNN sam→clip 管线 + 余弦验证 |
| `docs/OCR_VISION_MNN.md` | 本交付报告 |

**边界**：仅新增 `ocr/` 脚本与 `docs/OCR_*`；未碰 newface/bridge/agent/设置页。

## 6. 下一步衔接（P2 输入）

- 视觉 token 布局：MNN 侧可复用 clip_proj.mnn 输出的 (273,1280)，P2 解码器直接消费
- 内存现状：视觉 .mnn fp32 1.6GB 加载后 RSS 大（P1 未量化）。**P4 int8 硬约束（rss 7GB→≤3.5GB）需对 sam/clip .mnn 也做 int8 量化**（MNN 的 mnnquant），P2/P3 先以 fp32 跑通正确性
- 解码器 ONNX 导出将复用本次经验（分图、dynamo=False、OOM 规避、MNN API 模式）
