# MOV 分发规范（RELEASE_PROCESS）

> 工单13-4。版本发布全流程：签名 APK 构建 → changelog → GitHub Release 上传 → mow.kim 下载页更新。
> 本文件只定义流程规范；执行上传需有 GitHub 写权限 + mow.kim 站点维护权限。
> 关联：`docs/UPGRADE_DATA_CHECKLIST.md`（发布前升级回归单，每次发布必跑）。

## 1. 版本号规范

- **versionName**（用户可见）：语义化版本 `MAJOR.MINOR.PATCH`（如 `3.3.0`）。
  - MAJOR：不兼容变更/大功能里程碑
  - MINOR：向后兼容的新功能
  - PATCH：缺陷修复
  - 预发布可加后缀（`3.3.0-rc1`），正式 Release 不带后缀
- **versionCode**（安装系统判定，必须单调递增）：规则 `MAJOR*10000 + MINOR*100 + PATCH`
  （如 3.3.0 → 30300；当前基线 versionCode=3 是历史遗留，从 v3.3.1 起按新规则
  `30301` 起跳，**只增不减**，否则旧版本无法覆盖安装）
- 修改位置：`app/build.gradle` 的 `versionCode` / `versionName`（两处同 commit）

## 2. 签名 APK 构建

### 2.1 首次配置 keystore（一次性）

```bash
keytool -genkeypair -v -keystore mov-release.jks -alias mov -keyalg RSA \
  -keysize 2048 -validity 10000 -storepass <强密码>
```

- 产物 `mov-release.jks` **不入 git**（`.gitignore` 已有 `*.jks`；密码入环境变量或 CI secret）
- 泄漏即作废：一旦 keystore 泄露，必须换新 keystore（旧安装无法覆盖，需用户卸载重装）

### 2.2 signingConfig（app/build.gradle）

```groovy
android {
  signingConfigs {
    release {
      storeFile file(System.getenv("MOV_KEYSTORE") ?: "mov-release.jks")
      storePassword System.getenv("MOV_KEYSTORE_PASS")
      keyAlias "mov"
      keyPassword System.getenv("MOV_KEYSTORE_PASS")
    }
  }
  buildTypes {
    release {
      signingConfig signingConfigs.release   // 缺省不签名（现状），发布必须显式配置
      minifyEnabled false
      proguardFiles getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro"
    }
  }
}
```

### 2.3 构建与校验

```bash
export JAVA_HOME="/c/Program Files/Android/Android Studio/jbr"
./gradlew assembleRelease
# 校验签名:
jarsigner -verify -certs app/build/outputs/apk/release/app-release.apk | grep -i mov
# 产物: app/build/outputs/apk/release/app-release.apk (~458MB, 含 arm64-v8a + 种子 rootfs)
```

## 3. changelog 规范

- 文件：仓库根 `CHANGELOG.md`，**倒序**（新版本在上），每个版本一节：

```markdown
## [3.3.1] - 2026-08-07

### 修复
- 大脑报错透传具体原因（API Key 无效不再笼统「服务不可用」）
- 编辑模型不再清空 API Key / 丢失默认大脑

### 新增
- 崩溃恢复后任务状态如实显示「已中断」

### 变更
- （无）
```

- 条目要求：
  - 面向用户写（**不写内部代号/工单号**，如「ticket13-1」不出现）
  - 每条一行，动词开头（修复/新增/变更/移除）
  - 来源：本仓库 commit 历史（`git log --oneline <上个tag>..HEAD` 逐条转写）
- 与版本号/versionCode 同一次 commit 更新

## 4. GitHub Release 上传

1. 打 tag（版本 commit 之后）：

```bash
git tag -a v3.3.1 -m "v3.3.1: 新人路径修复 + 崩溃恢复状态如实"
git push origin v3.3.1
```

2. GitHub Release 页（`https://github.com/onlywmw/MOV-APP/releases/new`）：
   - **Tag**: `v3.3.1`（与 versionName 一致，前导 v）
   - **标题**: `v3.3.1`（可加一句概括）
   - **正文**: 直接引用 `CHANGELOG.md` 对应节内容（不重复编写）
   - **Assets**: 上传 `app-release.apk`（签名版）；同时上传 `app-debug.apk` 标注
     「调试版（免签名，仅供测试）」——**正式分发只发签名版**
   - 勾选 **Set as the latest release**（除非同时维护多个支持版本线）
3. 上传前在真机抽验（引用 `UPGRADE_DATA_CHECKLIST.md` 全项 + 本次变更点人工回归）

## 5. mow.kim 下载页更新要点

- 下载页位置：`https://mow.kim`（官网；mow.kim 也是 A2A 配对服务器
  `A2aClient.DEFAULT_BASE_URL`，发布时确认服务不受影响）
- 更新项：
  1. **版本号 + 日期**：与 versionName/发布日一致
  2. **下载链接**：指向 GitHub Release 资产直链
     `https://github.com/onlywmw/MOV-APP/releases/download/v3.3.1/app-release.apk`
     （禁止直接放私有存储链接）
  3. **changelog 摘要**：同步 CHANGELOG.md 本节（用户读官网先于 Release 页）
  4. **安装说明**：保持「覆盖安装不丢数据」承诺（引用回归单结论），
     注明 minSdk 26 / arm64 设备要求（proot 种子仅 arm64-v8a）
- 发布后校验：官网页面可访问 + 下载链接 302 到 GitHub + 下载产物 sha256 与本地一致

## 6. 发布前强制检查（gate）

1. `./gradlew testDebugUnitTest` 全绿（1093+ 例）
2. JS 回归：`app/src/test/js/*.test.js` 全过（node）
3. `UPGRADE_DATA_CHECKLIST.md` 真机抽验全过（install -r 数据不丢）
4. 变更点真机人工回归（本次改了什么就验什么）
5. changelog/versionCode/versionName 同 commit
6. 签名 APK `jarsigner -verify` 通过

任一不过 → 不得发布（补修重来）。

## 变更记录

- 2026-08-07 工单13-4 建立（v0.1 发布前置；keystore/签名/Release 从零规范）
