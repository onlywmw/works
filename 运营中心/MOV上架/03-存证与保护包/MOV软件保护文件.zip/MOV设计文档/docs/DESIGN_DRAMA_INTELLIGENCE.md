# 追剧智能两层架构 — 2026-07-31（用户拍板：半智能→真智能）

> 用户原话：要理解这个网站的架构是怎么样的，然后加上 ai 的理解，这样才足够智能。现在就是半智能。
> 诊断：现状是「字符串手术」（正则切 HTML + URL 拼接）——浅、脆、只会背写死的路径。
> 站点事实：91mayitv = maccms 架构，公开采集 API 已关闭（实测 /api.php/provide/vod 返回 closed）——只能 HTML 建模，但要建成**领域模型**而不是散正则。

## 第一层：站点模型层 `MayiSite`（理解网站架构）

把站点抽象成领域对象，一处建模全局复用（DramaSource/雷达/续播/指名集数全从这取，不再各自正则）：

```java
class MayiSite {
    // 站点架构知识（maccms 模型，全部集中在这一个类）
    Show       search(String query);          // /vodsearch/{q}-------------.html → 剧列表
    ShowDetail detail(String vodId);          // /voddetail/{id}.html → 元数据+资源线+选集
    int        latestEpisode(String vodId);   // 选集最大 nid（「最新的一集」的数据源）
    String     playUrl(String vodId, int nid, int sid);  // /vodplay/{id}-{sid}-{nid}.html
    // 站点变更哨兵：解析连续失败 → 标记站点结构变了，降级并报警（不再静默空结果）
}
```

- Show：id/title/poster/year/status（更新至N集）
- SourceLine：sid/name（红牛/非凡/暴风…）/可用性（死线自动跳过换线）
- Episode：nid/title/playUrl
- **一处改全站改**：蚂蚁改版只动 MayiSite，不再满世界找正则

## 第二层：AI 理解层（IntentEngine drama 推理模式）

drama 意图从「剥词路由」升级为「LLM 生成执行计划」：

```
用户：「我要看仙逆最新的一集」
  ↓ IntentEngine（LLM，带工具说明的 prompt）
  → 计划：{action:"latest", show:"仙逆"}
  ↓ MayiSite.latestEpisode → 184
  → 顶卡「第184集 · 最新 · 一键观看」→ 直达播放

用户：「我要看仙逆第三集」
  → 计划：{action:"episode", show:"仙逆", nid:3} → 直达（现有路径保留）

用户：「我要看仙逆」
  → 计划：{action:"continue", show:"仙逆"} → 查记忆 150 → 151（现有路径保留）
```

- v1 计划类型四个即可：continue / episode / latest / search（模糊找剧）
- LLM 失败降级：回现有规则链（剥词）——规则是安全网不是主路径
- prompt 里给 LLM 的是 MayiSite 能力说明（可latest/可episode/可search），让它选动作不是编答案

## 施工（P1，按序）

1. MayiSite 类（含 latestEpisode + 变更哨兵）+ 单测（fixture HTML 注入）
2. DramaSource/雷达/续播迁移到 MayiSite（删散正则）
3. IntentEngine drama 推理模式（四动作计划 + 规则降级）
4. 验收三句：「最新的一集」→ 184 直达；「第三集」→ 3 直达；「我要看仙逆」→ 续播
