# CONTRACT+DESIGN: DeliveryGate — 理解闸 · 交付基线 · 委派守门员
> **2026-07-30 变更：多模型评审机制已移除**（评审团/交付评审投票/返工循环）。
> 本文涉及的 DELIV_REVIEW 评审投票环节不再存在；ComplianceScanner 基线扫描与
> 功能自检清单保留并继续进 deliver 事件。

版本: v1.1（按大神二轮评审修订：零假设原则 / 委派按文件类型分流 / 扫描器降级为评级 / onRoomDestroy 生命周期钩子 / Hermes 安全沙箱）
日期: 2026-07-25
status: design-ready
交付对象: 后端 + 前端程序员
前置: AgentLoop v1.1 已落地（计划闸/评审团/熔断）、CONTRACT_STREAMING 已实施（单测 237 绿，真机验收待定）
关联: KNOWN_ISSUES KI-000~004（桥无协议地基病，本文 §生命周期钩子 修 KI-001）
分期: **v1 = 理解闸 + 交付基线；v2 = 委派守门员（代码层强制，无 prompt 过渡版）**

---

## 规则红线（合同篇，落地后不可违反）

1. **Prompt 是建议，代码才是法律。** 一切关键纪律（委派触发/格式校验/交付基线）必须有
   Java 代码层守门员，禁只靠 prompt 约束模型惰性。
2. **功夫下在前面**：理解不透不开工。需求澄清做在拆计划之前，不在跑岔之后。
3. **零假设原则**：除非用户明确提及，大脑禁止在 defaults 填充任何主观配置
   （颜色/字体/主题/存储方式）。瞎猜不是负责任，是制造返工。（大神二轮 #1）
4. **默认基线 = 能上线的成品**，且必须过代码层 Checklist 扫描。
5. **失败经济学：产物不抹杀。** 扫描缺陷 → 先给自我修复机会；修复失败 → 带瑕疵交付，
   产物保留。99% 的产出因一句 TODO 全灭，是对 token 和用户耐心的最大浪费。（大神二轮 #3）
6. **用户参与点在前期**：用户管「要什么、到什么标准」；执行路线系统内部调度，
   禁把路线选择抛给用户。
7. **能力不足即停止，严禁伪交付**：明知会截断/残缺还硬干 = 制造修不了的垃圾。
8. **委派不开安全后门**：Hermes 默认禁网 + 任务描述 sanitize + 产物回写校验，
   不得成为绕过 App 安全闸门的通道。（大神二轮 #5）
9. **等待不是问题，黑箱才是**：等待期间活性反馈由 CONTRACT_STREAMING 管；本文管方向。

---

## 背景与目标

三个真问题（均真机实证）：

1. **没搞懂就开工**：任务进来直接拆计划，需求理解靠大脑猜，跑岔了再纠——纠偏成本远高于事前问清。
2. **demo 充成品**：大脑默默把「做个微信复刻版」降格成「能跑的玩具」，交货即一坨屎。
   雪上加霜的是大脑默认廉价 flash 模型 + 无 max_tokens（DeepSeek 默认 4096 截断），
   大产物天然残缺（诊断报告已实证）。
3. **Hermes 白装**：委派只在 prompt 里提了一句（AgentLoop.java:877），无触发纪律，
   大脑什么活都自己硬扛，Hermes 装了等于没装。

用户原话（设计第一依据）：

> 「一开始要明白用户到底要的是什么。基本大家都是要做到能上线的版本，
> 很少是要做个玩具和 demo。不是运行起来再让用户去选择，前面的工作做细致点。
> 用户不怕等待，怕的是你上面都不说，交货的时候给出一坨屎。」

目标：**方向对齐前置（理解闸）+ 交货标准不虚（基线）+ 重活必外包（委派守门员）**。

## 决策记录

| 问题 | 决策 |
|------|------|
| 理解闸位置 | 拆计划**之前**：UNDERSTAND_GATE 确认后才允许进 PLANNING |
| defaults 填充 | **零假设**：只许填用户明确提及的配置 + 系统约束声明（如产物落房间 work 目录）；禁主观假设。defaults 常态为空 → 一行确认是常态（大神二轮 #1） |
| 理解卡压缩 | defaults 为空 → 一行确认；非空 → 完整卡。JS 按 defaults.length 判定 |
| 委派触发 | **按文件类型分流**：逻辑代码（.py/.js/.ts/.go/.java/.sh）≥2000 token 委派；标记语言（.html/.md/.json/.xml/.css）豁免或 ≥5000 token 且可分步写入（大神二轮 #2） |
| 委派执行 | **代码层守门员强制拦截**（ActionInterceptor），大脑无「直接输出」机会 |
| 委派回退 | Hermes 不可用 + 命中委派条件 → 直接 FAILED 报错，禁自干产出截断代码 |
| 委派安全 | hermes -z 默认禁网（任务明确需要联网除外）+ 任务描述 sanitize + 产物回写 canonical 校验（大神二轮 #5） |
| 扫描器判定 | **修复优先，评级交付**：缺陷 → 大脑自我修复一轮（返工预算）→ 仍缺陷 → 带瑕疵交付（产物保留，交付卡标注缺项）。禁止直接 FAILED 抹杀（大神二轮 #3） |
| 幽灵 loop | BridgeAi 新增 `onRoomDestroy(roomId)`：删除房间/清空记录入口销毁 DOM 前**必须**调用（同修 KI-001）；闸超时维持 10 分钟（有钩子兜底，1 分钟太短误伤读卡用户）（大神二轮 #4） |
| 做不到上线级 | 中途停下上报（差距+选项），禁默默降格交货 |
| 降格 | demo/原型必须用户明示同意；交付卡强制标注实际达到的标准 |
| 理解 JSON 容错 | 格式修正重试不占用户纠正轮次；连续 2 次非法 JSON → FAILED 建议换模型 |
| 适用范围 | 只改 council 房 agentic 任务；单聊房设备指令不经过理解闸 |

## 状态机修订（在 AgentLoop v1.1 状态机上前插/内嵌）

```
UNDERSTANDING     大脑拿目标 → 输出理解陈述 JSON (零假设: defaults 常态为空)
  ↳ UNDERSTANDING_RETRY  JSON 解析失败 → 系统自动发"格式修正"指令重试 (≤2 次, 不占用户纠正轮次)
                         连续 2 次失败 → FAILED「模型能力不足, 建议切换模型」
UNDERSTAND_GATE   理解确认卡 (defaults 空=一行, 非空=完整) → 用户: 确认开工 / 补充纠正
  ↳ onRoomDestroy / 房间删除 / 清空记录 → 立即 requestStop (KI-001 修复钩子)
PLANNING          (同 v1.1，不变)
PLAN_GATE         计划卡 → 批准 / 驳回+补充
EXECUTING         循环 ≤12 步;
                  ┌─ 委派守门员 (ActionInterceptor, 代码层):
                  │   逻辑代码 file.write ≥2000 token 或命中工具链特征 → 强制改道 hermes -z
                  │   (默认禁网+sanitize); 标记语言豁免/高阈值; Hermes 不可用 → FAILED
                  │   产物回写后 canonical 校验在 /room 内
                  └─ 交付扫描器 (ComplianceScanner, 代码层): 缺陷 → 自我修复一轮
                      (复用返工预算) → 仍缺陷 → 带瑕疵交付 (产物保留, 禁抹杀)
[DELIV_REVIEW]    评审投票 (同 v1.1)
DONE / FAILED / STOPPED
```

- UNDERSTAND_GATE 复用 gateLock 闸模式（`respondUnderstand(approved, note)`），
  超时 10 分钟未确认 → 自动停止。
- 用户纠正熔断：**理解纠正 ≤3 轮**；格式重试独立计数。

## 理解确认卡协议（工作日志新增第 6 类）

| 类型 | 内容 | 渲染 |
|------|------|------|
| understand | 理解陈述 JSON：`{summary, audience, features[], acceptance, defaults[]}` | 理解确认卡（置于计划卡之前） |

- **零假设原则（大神二轮 #1）**：defaults 只允许两类内容——
  ① 用户原话明确提及的配置；② 系统约束声明（如「产物落房间 work 目录」）。
  禁止主观配置假设（颜色/字体/主题/存储方式）。违规 = prompt 明令禁止 + 评审时可打回。
- **卡型**：`defaults` 为空（常态）→ 一行卡：「理解：xxx · [确认开工][补充纠正]」，
  一句话开工不啰嗦；非空 → 完整卡，假设区置顶警示。JS 按 `defaults.length` 判定，与大脑意愿无关。
- 设备指令类（IntentParser 命中 capability）不进 agentic 循环，自然无此卡。

## Prompt 设计（UNDERSTAND_RULES，置于 PLAN_RULES 之前）

```
【理解闸 — 拆计划前必须完成】
1. 先输出理解陈述 JSON（不要输出计划，不要输出 markdown 围栏外的废话）:
   {"understand":{"summary":"...","audience":"...","features":["..."],"acceptance":"...","defaults":["..."]}}
2. 默认交付标准 = 能上线的成品。除非你被明确告知做 demo/原型，acceptance 必须写上线标准。
3. 【零假设】除非用户明确提到，否则不得在 defaults 中列出任何主观配置
   （颜色、字体、主题、布局偏好等），否则视为违规。defaults 只许写:
   用户说过的 + 系统约束（如产物位置）。没话说就留空 []。
4. 用户纠正后重述理解再确认，禁直接跳去拆计划。
【交付基线 — 代码扫描器会逐项核验】
- 零占位符/TODO/FIXME/示例数据充数；真实数据路径；错误处理；边界覆盖。
- 每个 >500 行的产物文件，头部必须带 Compliance Check 注释块。
- 中途判断做不到上线级 → 输出 report_gap 动作（差距+选项），禁默默降格。
- finish 时 summary 必须含「达到标准: 上线级/带瑕疵/原型/demo」。
```

## 委派守门员（ActionInterceptor，代码层 — v2 核心）

**位置**：`AgentLoop.executeSteps()` 内，`ActionParser.parse` 之后、动作执行之前。
**本质**：大脑只能"提议"，守门员决定"谁干"。大脑没有绕过的路径。

### 拦截规则（按文件类型分流，大神二轮 #2）

| 产物类型 | 扩展名 | 阈值（字符÷4） | 命中后 |
|---|---|---|---|
| 逻辑代码 | .py .js .ts .go .java .sh .kt | ≥2000 token | **强制委派 hermes -z** |
| 标记/数据 | .html .md .json .xml .css | <5000 token | 豁免，大脑自干（允许分步写入） |
| 标记/数据 | 同上 | ≥5000 token | 委派 |
| 工具链特征 | 任意 | 文本命中 python/git/apt/部署/多步自动化/深度调研 | 委派（无视阈值） |

- HTML 生成体验优先：HTML 是文本不需要 Linux 工具链，大脑直接生成「秒级」，
  委派要付 ~50s 启动开销——一刀切会搞死体验（大神二轮 #2 场景：烧烤摊 App）。
- 标记语言截断风险用**分步写入**消化（file.write 支持分段续写），不委派的代价可控。
- Anti-Bypass：批准计划时 Java 静态扫描计划文本，同一路径多步写入**聚合预估**，
  防拆多次小 write 绕过单步阈值。

### 改道执行（含安全沙箱，大神二轮 #5）

- 重写为 `shell.exec`：`~/.hermes-venv/bin/hermes -z '<任务描述+写入 /room/<path>>'`
  （M-ARCH：房间 work 目录已 bind 为 guest `/room`，Hermes 直写产物，零搬运）。
- **网络沙箱**：委派默认禁用 Hermes 联网（环境变量/配置注入禁网络工具）；
  仅当计划明确声明「需要联网抓取」且计划闸批准时放行。
  （技术可行性 v2 实施时验证：proot 用户态完全断网手段有限，降级方案 =
  hermes 工具白名单禁 curl/wget 类 + 委派 prompt 明令禁网。）
- **任务描述 sanitize**：委派文本经注入扫描（rm -rf/curl 外发/sudo 类模式），
  命中即拒并回报「任务描述含危险指令」——防恶意 prompt 借 Hermes 之手搞破坏。
- **产物回写校验**：hermes 返回后，file.list 确认产物存在且非空 +
  **canonical 路径必须在房间 /room 目录内**（双重保险，防绕过 bind 写别处）+
  ComplianceScanner 过一遍。
- 步骤日志：「已委派 Hermes · 预计 N 分钟」（透明，不需用户批准）。

### 回退（能力不足即停止，严禁伪交付）

- Hermes 不可用（RootfsManager ≠ READY 或 HermesInstaller ≠ READY）且命中拦截 →
  **整个任务 FAILED**，报错文案：
  「此任务需要长文本生成能力，当前环境未检测到 Hermes。为防止产出残废代码，任务已中止。
   请到 设置 → Linux 环境 安装 Hermes，或简化需求后重试。」
- 代码里**不存在**「自干 + 声明截断风险」分支。

## 交付基线（Compliance Check + 扫描器，代码层；修复优先不抹杀，大神二轮 #3）

### 上线 Checklist（硬编码进 prompt，逐任务裁剪）

```
[ ] 网络错误处理 (超时/断网/非 200)
[ ] 空数据/首启占位 (列表为空、首次启动)
[ ] 权限拒绝逻辑 (拒绝后不崩, 有引导)
[ ] 输入校验 (空输入/超长/非法字符)
[ ] 边界值 (0/负数/极大值/并发点击)
[ ] 资源释放 (定时器/监听器/流关闭)
[ ] 弱网/降级路径
```

### 强制产出

- 每个 >500 行的产物文件，头部必须有注释块：

```
// Compliance Check
// [x] 网络错误处理 — fetch 全 try/catch + 超时 AbortController
// [x] 空数据占位 — renderEmpty()
// [n/a] 权限拒绝 — 本产物无权限调用
```

### 扫描器（ComplianceScanner.java，纯逻辑可单测）+ 三级判定

- 规则：
  1. 产物全文扫描 `TODO|FIXME|XXX|占位|placeholder|lorem`（不区分大小写）→ 命中即缺陷；
  2. >500 行产物缺 `Compliance Check` 注释块 → 缺陷；
  3. 注释块内无 `[x]`/`[n/a]` 逐项标记 → 缺陷。
- **判定（修复优先，禁抹杀）**：
  - 无缺陷 → 「上线级」进交付卡；
  - 有缺陷 → **回灌大脑自我修复一轮**（复用 DELIV_REVIEW 返工预算 6 步：
    TODO 转具体实现 / 补 Compliance 头）→ 复扫无缺陷 → 「上线级」；
  - 修复后仍有缺陷 → **带瑕疵交付**：产物保留落盘，交付卡标「带瑕疵」+ 缺项清单，
    评级进入「达到标准」行。禁止直接 FAILED、禁止删产物。

## 交付卡修订

- 「达到标准: 上线级 / 带瑕疵 / 原型 / demo」；带瑕疵必须附缺项清单；
  原型/demo 必须附用户同意记录（哪条消息同意的）。
- 「Compliance: 7 项通过 / N 项 n/a」（扫描器结果）。
- 中途上报卡（report_gap）：差距清单 + 选项（调整范围 / 委派 Hermes 补强 / 按现状交付并标注降格）。

## 生命周期钩子（修 KI-001，防幽灵 loop，大神二轮 #4）

- BridgeAi 新增 **`onRoomDestroy(roomId)`**：该房间有活跃 loop → `requestStop()` +
  唤醒所有闸（gateLock.notifyAll），loop 走 stopped 终态正常清理（触发 maybeStartQueued）。
- **强制调用点**（前端销毁 DOM 前必须调）：
  `clearRoomHistory`（chat.js:818）、删除房间确认（app-room.js:214）、多选删除。
- 闸超时维持 10 分钟：有 onRoomDestroy 兜底后幽灵 loop 的主路径已封死；
  1 分钟超时太短，用户读理解卡/计划卡被打断体验差（对大神 #4 建议的工程修正）。
- 进程死亡场景：static `AgentLoop.current` 随进程消失，天然无残留（KI-001 已述）。

## 阶段徽章映射（增量）

| 状态机 | 徽章 |
|--------|------|
| UNDERSTANDING / UNDERSTAND_GATE | 待确认（与 PLAN_GATE 同徽章，卡型不同） |

## 计量（增量）

- 理解阶段 token 计入总消耗，交付卡不单独列（占比小，避免噪音）。
- 委派 Hermes 的消耗单列一行小字（guest 侧按 hermes 返回 usage 或字符估算）。

## 验收测试用例

### TC-UND-01：模糊需求先出理解卡
```
Given: council 房, 默认模型已配置
When: 用户发"做一个微信复刻版"
Then:
  1. 首先出现理解确认卡 (summary/features/acceptance=上线标准)
  2. 未确认前: 无计划卡, 无任何文件写入
  3. 点[确认开工] → 才进 PLANNING 出计划卡
```

### TC-UND-02：补充纠正回灌
```
When: 理解卡出现 → 用户点[补充纠正]并输入"只要聊天和通讯录两个模块"
Then: 纠正回灌 → 新理解卡重述（功能集=2 个模块）→ 确认后才拆计划; 纠正轮次计 1
```

### TC-UND-03：零假设 + 卡型判定（大神二轮 #1）
```
When: 用户发"做个贪吃蛇"（无配置偏好提及）
Then:
  1. 大脑 defaults=[]（塞"深色模式"等主观假设 = prompt 违规）
  2. JS 判定一行卡: 「理解: 浏览器贪吃蛇游戏 · [确认开工]」——一句话开工
When: 大脑违规产出非空 defaults
Then: JS 强制完整卡, 假设区置顶警示, 用户过目才可确认
```

### TC-UND-04：默认上线基线 + 扫描器
```
When: 任务完成交付
Then: 产物过 ComplianceScanner; 交付卡含「达到标准: 上线级」+「Compliance: N 项通过」
```

### TC-UND-05：中途做不到上线级 → 上报
```
When: 执行中大脑判断能力/资源不够达到上线级
Then: 循环挂起出 report_gap 卡（差距+选项）; 不默默交付 demo
```

### TC-UND-06：委派按文件类型分流（大神二轮 #2）
```
When: 大脑对 .py 产物输出 file.write 预估 ≥2000 token
Then: ActionInterceptor 强制改道 hermes -z (默认禁网); 大脑无自干机会
When: 大脑对 .html 产物输出 file.write 预估 3000 token (<5000)
Then: 不拦截, 大脑自干 (允许分步写入), 无 50s 启动开销
```

### TC-UND-07：Hermes 未装 → 停止报错
```
Given: HermesInstaller 状态 ≠ READY
When: 命中委派拦截规则
Then: 任务 FAILED, 报错含「安装 Hermes 或简化需求」指引; 无任何 file.write 落盘
```

### TC-UND-08：理解纠正熔断
```
When: 用户连续 3 次[补充纠正]仍对不齐
Then: 循环停止, 如实汇报"理解对不齐", 徽章=已停止
```

### TC-UND-09：理解 JSON 容错
```
When: 大脑输出 markdown 围栏包裹/带废话的理解陈述
Then: ActionParser 容错提取成功 → 正常进 UNDERSTAND_GATE
When: 连续 2 次输出完全非 JSON
Then: 格式修正重试不消耗用户纠正轮次; 第 2 次失败 → FAILED「模型能力不足, 建议切换模型」
```

### TC-UND-10：扫描器修复优先，禁抹杀（大神二轮 #3）
```
When: 产物含 "// TODO: 优化动画" 或 >500 行缺 Compliance 块
Then:
  1. 不 FAILED; 回灌大脑自我修复一轮 (返工预算 6 步)
  2. 修复后复扫无缺陷 → 「上线级」正常交付
  3. 修复后仍有缺陷 → 「带瑕疵」交付: 产物保留落盘, 交付卡附缺项清单
  4. 任何情况下产物不被删除
```

### TC-UND-11：onRoomDestroy 停止幽灵 loop（大神二轮 #4 + KI-001）
```
When: 任务在 UNDERSTAND_GATE/PLAN_GATE/EXECUTING/PAUSED 任一状态, 用户删除该房间
Then:
  1. 前端销毁 DOM 前调 B.onRoomDestroy(roomId)
  2. Java 侧 loop requestStop + 闸唤醒 → 走 stopped 终态 → 全局锁释放
  3. 之后新任务正常启动, 不出现「还在执行上一个任务」
```

### TC-UND-12：委派安全沙箱（大神二轮 #5）
```
When: 任务被委派 hermes -z
Then:
  1. 委派调用默认注入禁网配置 (除非计划明确声明联网且计划闸已批准)
  2. 任务描述含 "rm -rf" / "curl http" 类模式 → 拒绝委派并报「危险指令」
  3. 产物 canonical 路径不在房间目录内 → 判定异常, 产物不纳入交付
```

## 实现约束（不可违反）

1. **理解闸由代码强制**：`state == UNDERSTAND_GATE` 未收到确认前，PLANNING 不得开始。
2. **委派守门员由代码强制**：ActionInterceptor 在 parse 后执行前拦截，大脑无绕过路径；
   分流按扩展名表执行，阈值常量可调；Anti-Bypass 按计划聚合预估。
3. **委派安全三件套由代码强制**：禁网注入 / sanitize / canonical 回写校验，
   任何一环不过 = 不交付该产物。
4. **扫描器判定只有三态**：上线级 / 自我修复 / 带瑕疵交付；代码里不存在
   「扫描缺陷 → 直接 FAILED + 不交付」分支。
5. **defaults 卡型由 JS 判定**：`defaults.length > 0` 强制完整卡。
6. **onRoomDestroy 是硬钩子**：三个删除/清空入口不调它不允许销毁 DOM（code review 检查点）。
7. **回退只有停止一条路**：Hermes 不可用 + 命中拦截 = FAILED。
8. **设备指令豁免由架构保证**：理解闸只在 agentic 循环入口内。
9. **降格必须留痕**：非上线级必须能指回缺项清单或用户同意记录。
10. **理解格式重试不占用户轮次**：双独立计数器。
11. **与存量文档同步修订**：本设计落地时，DESIGN_AGENT_LOOP.md 状态机图同一 commit 更新。

## 改动清单

| 文件 | 改动 | 分期 |
|------|------|------|
| `agent/AgentLoop.java` | UNDERSTANDING/UNDERSTAND_GATE/UNDERSTANDING_RETRY 三状态 + respondUnderstand 闸 + 双计数器 ~150 行 | v1 |
| `agent/AgentLoop.java` prompt | UNDERSTAND_RULES（零假设条款）+ 交付基线 Checklist 条款 | v1 |
| `agent/ComplianceScanner.java`（新） | 交付扫描器三规则 + 三级判定（通过/修复/带瑕疵），纯逻辑可单测 ~100 行 | v1 |
| `agent/ActionInterceptor.java`（新） | 委派守门员：文件类型分流表/聚合 Anti-Bypass/禁网+sanitize+回写校验 ~150 行 | v2 |
| `bridge/BridgeAi.java` / `BridgeFactory.java` | agentUnderstand 桥方法 + **onRoomDestroy(roomId)** | v1 |
| `js/chat.js` | 理解确认卡交互 + defaults.length 卡型判定 + clearRoomHistory 调 onRoomDestroy | v1 |
| `js/app-room.js` | 删除房间/多选删除入口调 onRoomDestroy | v1 |
| `js/render.js` | understand 卡型（一行/完整两态）+ 交付卡「达到标准」「Compliance」行 + report_gap 卡 + 带瑕疵样式 | v1 |
| `js/i18n.js` | 全部新文案 | v1 |
| `AgentLoopTest.java` | 理解闸状态机/双计数器/闸超时/onRoomDestroy 单测 | v1 |
| `ComplianceScannerTest.java`（新） | 三规则 + 三级判定单测 | v1 |
| `ActionInterceptorTest.java`（新） | 分流表/Anti-Bypass/回退停止/沙箱校验单测 | v2 |
| `DESIGN_AGENT_LOOP.md` 状态机图 | 同步修订 | v1 |

## 明确不做（YAGNI）

- 理解闸的语音/多轮对话式澄清（v1 用卡片+纠正回灌，够用）
- 委派的 token 预算硬上限（v2 靠 shell.exec timeoutSec 300-600 兜底）
- 单聊房理解闸（设备指令不需要）
- 理解陈述的持久化（随 loop 生命周期，app 杀后接受丢失）
- Hermes 委派进度的细颗粒度流式回显（v2 只回最终产物；增量回显留给桥协议化项目）

## 开放问题（大神两轮已裁决 10 项，剩余 3 项）

已裁决并入本文：①委派硬触发→代码层 ②defaults 不压缩→零假设 ③上线 Checklist 强制
④JSON 容错独立计数 ⑤回退即停止 ⑥委派按文件类型分流 ⑦扫描器修复优先不抹杀
⑧onRoomDestroy 生命周期钩子 ⑨委派安全沙箱 ⑩闸超时维持 10 分钟（钩子兜底）。

1. **两卡是否合并**：理解确认卡 → 计划卡连发是两次点击；合并省一次交互但违反
   「先对齐方向再谈步骤」——倾向不合并，仍待裁决。
2. **委派预算**：Hermes 调用要不要设 token/时长预算防烧钱？目前只有 timeoutSec 兜底。
3. **Hermes 禁网技术方案**：proot 用户态完全断网手段有限（unshare/iptables 需真 root），
   降级方案（工具白名单+prompt 禁网）是否可接受？需 v2 实施前验证。
