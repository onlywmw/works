# MOV 检测验收台账（Acceptance Tracker）

status: active

> **用途**：记录每次验收/检测的完整过程——用了什么方法、检测路径怎么走、该件处于架构什么位置、结论、bug 与优点、后续建议。
> **目的**：换审查员能快速接手；出问题能回溯"当时怎么验的、验到哪一步"。
> **与 ACCEPTANCE_LOG.md 的关系**：LOG = 结论档案（谁验、结果）；本台账 = **检测过程台账**（怎么验、路径、发现）。两者配套。
> **铁律**：不信自报，信实物（ACCEPTANCE_PLAYBOOK.md）。每条结论必须能在台账的"检测路径"里找到实证。

---

## 记录格式（每次验收/检测填一段）

| 字段 | 内容 |
|---|---|
| 日期 / 任务 / commit | 本次验的什么 |
| 定级 | L1/L2/L3（拿不准往高定） |
| 检测方法 | diff 精读 / 单测计数 / 变异测试 / 全量 / 真机 curl / logcat / CDP-UI / 截图 |
| 检测路径 | 一步步可复跑的操作路径（含命令） |
| 架构位置 | 该件在整体架构中的位置（上游/下游、依赖谁） |
| 结论 | ✅ 通过 / ❌ 打回 / ⚠️ 待补 |
| Bug / 缺陷 | 实测发现的问题（含潜在/观察项） |
| 优点 | 做得好的（可复用模式） |
| 建议 | 后续动作（派单、口径、加固） |
| 证据位置 | 截图/logcat/测试报告文件路径 |

**空模板（复制填写，每次验收一段）**：

```markdown
### YYYY-MM-DD <任务名>（L 级）

| 字段 | 内容 |
|---|---|
| 日期 / 任务 / commit |  |
| 定级 | L1/L2/L3 |
| 检测方法 |  |
| 检测路径 | ① ... ② ... ③ ... |
| 架构位置 |  |
| 结论 | ✅ / ❌ / ⚠️ |
| Bug / 缺陷 |  |
| 优点 |  |
| 建议 |  |
| 证据位置 | 截图 / 文本 / 代码 |
```

---

## 检测方法速查（换审查员照做）

| 方法 | 何时用 | 操作要点 |
|---|---|---|
| diff 精读 | 所有验收 | `git show <hash>` 精读生产/测试改动；对照验收标准逐条核对 |
| 单测计数 | L1+ | `./gradlew :app:testDebugUnitTest --tests <类>`；确认输出含真实 `N tests completed`，别只看 BUILD SUCCESSFUL |
| 变异测试 | L2+ | 无变异绿 → 注入最小变异（删被测核心一行）→ 必须红（含 `XxxTest > yyy FAILED`）→ 还原绿；BUILD FAILED ≠ 测试红 |
| 全量四数 | 所有 | `./gradlew :app:testDebugUnitTest` 后聚合 XML，报 tests/skipped/failures/errors 四数 |
| 真机 curl | 网络端点 | `adb -s <序列号> forward tcp:8388 tcp:8388` → curl 127.0.0.1:8388/...；Token 从 serve 进程 env 取 |
| logcat | 可观测性 | `adb logcat -d -v time -s <Tag>`；grep 防自匹配加 `-v ShellService` |
| CDP-UI | WebView 层 | `tools/e2e/mov-verify.js <say/shot/cover/logcat/forward>`（WebView 内容 uiautomator 看不到） |
| 截图 + OCR | 真机证据 | `screencap` → pull → 桌面 RapidOCR（Python312）识图出文本；截图必须看得到断言的那件事 |
| 设备识别 | 真机 | 先查 `tools/device_accept.sh` / `adb devices`（设备序列号 ≠ commit hash，勿误判打回） |

---

## 台账记录

### 2026-08-04 一表双脑真共用三批（L2）

| 字段 | 内容 |
|---|---|
| 日期 / 任务 / commit | 2026-08-04 ／ 一表双脑真共用三批（工具重定向/记忆桥接/技能共享） ／ `8d40e9b` + `78f2784` + `acbb539` |
| 定级 | **L2**（跨端工具映射 + 记忆语义 + 技能共享） |
| 检测方法 | diff 精读（三批）+ 全量四数 + 单测计数（curated +3） |
| 检测路径 | ① `git show 8d40e9b` HermesToolProvider web.search/fetch **真实现**（DDG HTML 解析 / OkHttp 抓 URL 去标签，替代 stub 引导） ② `git show 78f2784` Journal curated 层（memoryRemove tombstone / memoryReplace / memoryCurated §分隔 + tombstone 排除） ③ `git show acbb539` SkillStore.parseSkill 解析 SKILL.md frontmatter（name/description） ④ `./gradlew :app:testDebugUnitTest` 全量聚合 = **886/18/0/0**（含 curated 3 单测：tombstone 排除/replace/§分隔） |
| 架构位置 | Hermes serve（8387，proot 内）↔ MOV ToolRegistry/Journal/SkillStore 桥接；memory/skills 收编 MOV 唯一事件源 |
| 结论 | ✅ **通过**（全量 886 绿 + diff 精读三批均为真实现，非 stub/假覆盖）；⚠️ 真机端到端待补（serve 在 proot 内 adb 不可达，交付自认，留后续触发 Hermes 任务验证 logcat 链路） |
| Bug / 缺陷 | 无（观察项：web.search 依赖 DDG 可达性；curated 语义对齐 Hermes MEMORY.md） |
| 优点 | 三批边界清晰（工具映射/记忆语义/技能共享），zip 重打包可部署，MOV 唯一事件源贯彻 |
| 建议 | 真机触发一次 Hermes 任务（session_search/web_search/memory）看 logcat 链路后收尾 |
| 证据位置 | ACCEPTANCE_TRACKER A25-A27 + 全量 886/18/0/0 XML |

### 2026-08-03 阶段3 B：LLM 收编 `/infer` 走 MOV BridgeAi（L3）

| 字段 | 内容 |
|---|---|
| 日期 / 任务 / commit | 2026-08-03 ／ 阶段3 B（B1 /infer 实装 + B2/B3 边界实证） ／ `0d7e1d7`（交付+打回修复） + `b6ec581`（任务板） |
| 定级 | **L3**（网络协议/新增 HTTP 端点） |
| 检测方法 | diff 精读 + 单测计数（MovInboundServerTest 15 + JournalMemoryDraftTest 22）+ **变异测试** + 全量四数 + 真机 curl + logcat + 截图 OCR + UI 触发 |
| 检测路径 | ① `git show 0d7e1d7` 精读生产/测试 diff（splitInferMessages 纯函数 + 4 单测 + 弱断言） ② `MovInboundServerTest` 无变异 **15/15 绿**；`JournalMemoryDraftTest` 22/22 绿 ③ `./gradlew :app:testDebugUnitTest` 全量聚合 = **758/18/0/0** ④ `adb -s 21770d7d forward tcp:8388 tcp:8388` → `curl -X POST http://127.0.0.1:8388/infer -H "X-Mov-Token:…" -d '{"messages":[{"role":"user","content":"12*4=?"}]}'` → **`{"ok":true,"data":{"content":"48"}}`** ⑤ `adb logcat -d -s MovInboundServer` → **`MOV 推理 model=deepseek-v4-flash`** ⑥ **变异亲杀**：注入 prompt 解析变异（splitInferMessages 末条 user 不写 prompt）→ **15 tests, 2 failed**（splitMessages_lastUserIsPrompt_othersHistory + splitMessages_emptyContentSkipped）→ 还原 **15/15 绿** ⑦ `node mov-verify.js say` + shot 截图 |
| 架构位置 | serve 反向通道：MOV A0 入站监听 **127.0.0.1:8388**（MovInboundServer）→ `/infer` → ModelRegistry 默认模型 → AiClient.chat（OpenAI 兼容）→ LLM；serve daemon（8387）代理。即"serve 侧推理收编到 MOV BridgeAi" |
| 结论 | ✅ **修复复核通过**（查验表全项：diff 精读 / 单测 15+22 / **变异亲杀** / 全量 758 / 真机 curl 回包 48 + MOV 推理 logcat / 截图 OCR） |
| Bug / 缺陷 | 打回期：① 证据 hash `21770d7d` 实为**平板 adb 设备序列号**（device_accept.sh），非 commit——审核员一度误判打回（自我纠错，见下） ② 原单测仅测 null context 错误分支，B1 核心解析零覆盖（已修：splitInferMessages 纯函数） ③ 观察项：/infer 在 serve 线程内同步等 LLM，daemon 侧超时须 > 模型 readTimeout |
| 优点 | splitInferMessages 抽纯函数（可测性好）；`MOV 推理 model=` logcat 可观测性（证据链直接）；B2/B3 硬约束诚实入册（AiClient 无 function calling）；禁网两条腿分开实证 |
| 建议 | ① AiClient 扩展 function calling 需**用户拍板独立派单**（B2 完整换路的前提） ② B3 真裁点（DeepSeek 配置收编）依赖 B2 可行 ③ 真机 UI 层推理（app 内 AiClient）与 serve /infer（8388）是两条腿，验收分开测 |
| 证据位置 | **截图**：`docs/device-acceptance/2026-08-03/b1-ui.png`（3048×2032；像素统计 avg=(248,246,242) 非黑屏；**RapidOCR 已验证内容** = MOV app 新脸首页「凡人修仙传追剧卡/出行提示/日常补货/输入框'说一句话'」，OCR 文本见 `b1-ui-ocr.txt`）、`b1-infer-verify.png` ｜ **文本证据**：`b1-logcat.txt`（MOV 推理 logcat 原文）、`b1-curl-response.txt`（curl 命令 + 回包）、`b1-ui-ocr.txt`（截图 OCR 文本） ｜ **代码证据**：`MovInboundServer.java:278`（infer）、`:310`（splitInferMessages）、`MovInboundServerTest.java:137/153`（弱断言 + 4 单测）、测试 XML `app/build/test-results/testDebugUnitTest/TEST-com.hermes.android.serve.MovInboundServerTest.xml` |

**自我纠错（验收人）**：打回项①「证据 hash 21770d7d 在仓库不存在」系误判——21770d7d 是平板 adb 序列号（见 tools/device_accept.sh），P2 引用无误。教训：认设备前先查 device_accept.sh / adb devices。该纠错已记录，不影响其余打回项（②验收结论归属 ③单测零覆盖 ④弱断言）成立。

---

### 2026-08-03 记忆层 v2：读取时按需覆盖 memoryCover（L1）

| 字段 | 内容 |
|---|---|
| 日期 / 任务 / commit | 2026-08-03 ／ 记忆层 v2 读取时按需覆盖（P1） ／ `bdb3593` |
| 定级 | **L1**（纯 JVM 纯函数 + Kernel 只读查询，无网络/状态机） |
| 检测方法 | diff 精读 + 变异测试亲杀 + 单测计数 + 全量聚合 |
| 检测路径 | ① `git show bdb3593` 精读（Journal.memoryCover + coverVerbatim + BridgeKernel memory.cover） ② `./gradlew :app:testDebugUnitTest --tests …JournalMemoryDraftTest` 无变异 = 22/22 绿 ③ 注入变异 `collapsedN=0`（Journal.java:700）→ 22 tests 2 failed（coverKeepsOriginalInJournal + coverOverBudgetCollapsesOld） ④ 还原 → 22/22 绿 ⑤ 全量聚合 = **758/18/0/0** |
| 架构位置 | Journal（journal.jsonl append-only 事件溯源）的记忆草案读取视图：memoryCover 按预算选块（预算内逐字/超预算旧稿塌缩摘要），输出即 L3「读取视图」；BridgeKernel `query memory.cover` 是新能力入口 |
| 结论 | ✅ **通过**（变异亲杀 + 全量绿；四数口径统一 758/18/0/0） |
| Bug / 缺陷 | 观察项：① `coverVerbatim(null)` 对 null 元素会 NPE（当前 memoryDrafts 数据源自构造，风险低） ② `budget=0` 被钳制为 1，「全摘要」语义不可表达（设计未要求） |
| 优点 | 纯算法可测（前台可跑、无模型调用）；原文不丢只影响"读到什么"（修正③）；摘要为确定性占位（needsCompress 待 L3）；Kernel 入口统一信封 |
| 建议 | ① needsCompress=true 的 **L3 模型提炼**（摘要懒生成、空闲补齐）单独派单 ② 计数报告统一四数 tests/skipped/failures/errors（P1 早期报 754 = 首次全量轮测试集，入库后 758，+4） ③ file.search（场景库未落地项）可作 backlog |
| 证据位置 | **代码证据**：`Journal.java:691`（memoryCover）、`:730`（coverVerbatim）、`:683`（COVER_BUDGET_DEFAULT）、`BridgeKernel.java:771`（memory.cover case）、`JournalMemoryDraftTest.java:190-237`（5 个 cover 用例） ｜ **测试结果**：`app/build/test-results/testDebugUnitTest/TEST-com.hermes.android.agent.JournalMemoryDraftTest.xml`（tests=22 failures=0 errors=0） ｜ **变异实证**：`collapsedN=0` 注入（Journal.java:700）→ 22 tests 2 failed → 还原（见检测路径） |

---

### 2026-08-03 阶段3 C：记忆统一（C1 `/memory` + C2 journal 检索）（L3）

| 字段 | 内容 |
|---|---|
| 日期 / 任务 / commit | 2026-08-03 ／ 阶段3 C（记忆统一） ／ `415d17e`（交付） + `5f5514b`（任务板） |
| 定级 | **L3**（网络端点 + 持久化检索语义） |
| 检测方法 | diff 精读 + 单测计数 + 变异测试 + 全量四数 + 真机 curl |
| 检测路径 | ① `git show 415d17e` 精读（Journal.search + searchableText + MovInboundServer.memory） ② `JournalTest` 无变异 **25/25 绿** ③ 变异：注入 search 匹配逻辑失效 → **25 tests, 3 failed**（search_positiveMatch_findsEvent + search_caseInsensitive + search_archiveCovered）→ 还原 **25/25 绿** ④ 全量聚合 = **775/18/0/0**（含 P1 在制品 +11） ⑤ 真机 `adb forward 8388` → curl `/memory`：write seq=2 → read 读回 → search 正例 'acceptance' 命中（大小写不敏感）→ 反例 0 命中 → 无 token **HTTP 401** |
| 架构位置 | MOV A0 `/memory`（journal 唯一事件源：read=replay / write=append / search=C2 检索）；Journal.search 全文检索（journal+archive，大小写不敏感子串，ts 倒序，limit≤50） |
| 结论 | ✅ **通过**（diff 精读 + 变异亲杀 + 全量 775 + 真机 C1/C2/401 亲验） |
| Bug / 缺陷 | 观察：① 真机 curl 中文 body 在 Windows 命令行编码乱码（GBK）→ 用 ASCII 重验 C2；② C3 边界：hermes state.db（会话/FTS5）vs journal（房间事件流）语义不 1:1，整库换路需独立设计/派单（同 B2 型硬约束，已入册） |
| 优点 | searchableText 纯函数可测；/memory 只调 journal 公共 API（append/replay/search）不破 append-only；C2 覆盖滚动归档（archive）；snippet 截断 120 字防爆 |
| 建议 | ① C3 语义映射层（会话↔房间）独立派单 ② C4（删平行库）依赖 C3 可行，纪律守死 ③ D（裁剪收尾）可派 |
| 证据位置 | 真机 curl 输出（write seq=2 / search 命中 / 401，本会话）；`JournalTest.xml`（25/0/0）；`415d17e` diff |

---

### 2026-08-03 阶段3 D：裁剪收尾（serve 闭包 32→9）+ flaky 修复（L2/L3）

| 字段 | 内容 |
|---|---|
| 日期 / 任务 / commit | 2026-08-03 ／ 阶段3 D（serve 裁剪收尾） + P2#10 flaky 修复 ／ `aadf5bb` + `8cb9d08` |
| 定级 | **L2/L3**（serve 裁剪架构变更 + Java 排序确定性） |
| 检测方法 | diff 精读 + 单测（flaky 修复）+ 全量四数 + 真机 M1 剧本 |
| 检测路径 | ① `git show aadf5bb`（serve 闭包 32→9 + _SERVE_EXCLUDE 白名单恢复 + import os） ② `git show 8cb9d08`（Journal.search sort 加 seq 次级键） ③ `JournalTest` **强制重跑 25/25 绿**（flaky 修复非缓存） ④ 全量 775（P3 onboarding 独立确认 775/18/0/0） ⑤ 真机 M1 剧本：healthz `{"ok":true}` → /infer `6×7=42` → 无 token **HTTP 401** |
| 架构位置 | serve 闭包：hermes-agent 32→9 模块（HERMES_SERVE_TOOLS=1 白名单生效，CliExecutor 设）；Journal.search 排序加 seq 次级键（同 ts 确定性） |
| 结论 | ✅ **通过**（M1 剧本真机 + JournalTest 25 + 全量 775） |
| Bug / 缺陷 | ① A4 重建 zip 曾覆盖 registry.py 白名单（本件加回 + import os） ② C 回归 flaky：search 同 ts 无 seq 次级键 → 偶发红（已修 `8cb9d08`） ③ 观察：serve 裁剪在 zip 二进制，Java 侧无独立变异点 |
| 优点 | 白名单恢复 + 扩展裁剪 32→9（<10 达标）；flaky 一行修复（seq 次级键）；M1 剧本不回归 |
| 建议 | ① 阶段3（A0/A/B/C/D）全部收官 ② **P1 W2 可 commit**（全量已绿） ③ P3 onboarding 通过，可接轻量任务 |
| 证据位置 | 真机 M1 curl（healthz/推理 42/401，本会话）；`JournalTest.xml`（25/0/0）；`aadf5bb`/`8cb9d08` diff |

---

### 2026-08-03 P3 新接入 Onboarding（L1）

| 字段 | 内容 |
|---|---|
| 日期 / 任务 / commit | 2026-08-03 ／ P3 新接入熟悉环境 ／ 无代码（只读 + 环境确认） |
| 定级 | **L1**（只读文档 + 环境确认，无代码改动） |
| 检测方法 | 复核 P3 环境确认报告（构建/全量/设备/架构理解） |
| 检测路径 | 审 `TASKS_P3_ONBOARD_2026-08-03.md`「环境确认报告」：① `assembleDebug` BUILD SUCCESSFUL（3m54s） ② 全量四数 **775/18/0/0**（71 测试类，P3 独立跑） ③ `adb devices` 21770d7d + 型号 24018RPACC 三方一致 ④ 架构理解：一表两脑 / journal 真理源 / serve 8388 / 验收流程（抽查准确） |
| 架构位置 | 新接入 P3 环境就绪（无代码） |
| 结论 | ✅ **通过**（P3 环境就绪，可接轻量任务） |
| Bug / 缺陷 | 无代码；环境观察：Windows 文件锁（app/build/tmp output.bin，ACCEPTANCE_PLAYBOOK 药方已收录，`--stop`+删锁解决） |
| 优点 | 报告含架构理解（抽查正确）+ 环境药方对照（非代码问题） |
| 建议 | P3 下一任务从轻量小活开始（如 ocr_accept.sh rootfs 路径修正，OCR 区待认领） |
| 证据位置 | `TASKS_P3_ONBOARD_2026-08-03.md` 环境确认报告 |

### 2026-08-03 W2 ConnectWeb 全量工具化（A+C 修复）（L3）

| 字段 | 内容 |
|---|---|
| 日期 / 任务 / commit | 2026-08-03 ／ W2 ConnectWeb 工具化（A+C 修复） ／ `da761a7`（初版）+ `33abd71`（A+C） |
| 定级 | **L3**（浏览器工具 + 真机行为） |
| 检测方法 | diff 精读 + 单测 + 全量四数 + 真机（am start + OCR） |
| 检测路径 | ① `git show da761a7/33abd71` 精读（三个根因修复 + browser.open platform+keyword + executeOpen searchTemplate） ② 相关测试全绿：BrowserToolProviderTest 9 / RunTest 6 / ToolRuntimeLimits 9 / ToolRegistry 18 / AgentLoop 33 ③ 全量 **777/18/0/0** ④ 真机：`am start ConnectWebActivity --es platform douyin --es keyword 庆余年` → ConnectWebActivity 启动 + WebView 加载抖音搜索页（logcat douyin-pc-search）+ **OCR 证实"庆余年"搜索结果页**（w2-douyin-search.png） |
| 架构位置 | `browser.open` 工具（platform+keyword 参数 → ConnectWeb `executeOpen` 用 `searchTemplate` 构造搜索 URL，LLM 免构造 URL）；自动拉起链路（launchConnectWeb + BrowserExecutor 接缝） |
| 结论 | ✅ **通过**（JVM 全过 + 真机 ConnectWeb executeOpen 生效） |
| Bug / 缺陷 | ① agent 端到端（LLM 调 browser.open）：mov-verify 专家房间命令 DOM 兼容问题（TypeError）阻塞 CLI 触发——**工具问题非代码缺陷**，待 mov-verify room 修复后复验 ② B（意图路由 browser/search 类）后续独立任务 |
| 优点 | LLM 免构造 URL（platform+keyword 接口）；ConnectWeb searchTemplate 复用（与 openConnectSearch 同源）；可测试接缝（BrowserExecutor/ConnectWebSource） |
| 建议 | ① mov-verify room 命令修复后复验 agent 端到端（「在抖音搜庆余年的评价」→ 计划卡 → 自动拉起 → 检索） ② B 意图路由派单 ③ W3 场景扩展可派 |
| 证据位置 | `device-acceptance/2026-08-03/w2-douyin-search.png` + `w2-douyin-search-ocr.txt`（OCR 证实）；测试 XML；全量 777 |

---

## 汇总一览

> 每次验收完成后在此表加一行（日期/任务/定级/方法/结论/关键点），便于换审查员快速扫描定位。

| 日期 | 任务 | 定级 | 方法 | 结论 | 关键 bug/优点 |
|---|---|---|---|---|---|
| 2026-08-03 | 阶段3 B /infer | L3 | diff+全量+真机 curl+logcat+UI | ✅ | bug：证据 hash 误判（自纠）/观察同步阻塞；优点：纯函数+可观测日志+诚实边界 |
| 2026-08-03 | 记忆层 memoryCover | L1 | diff+变异亲杀+全量 | ✅ | bug：coverVerbatim(null) NPE 观察；优点：纯算法可测+原文不丢 |
| 2026-08-03 | 阶段3 C 记忆统一 | L3 | diff+变异亲杀+全量+真机curl | ✅ | bug：curl 中文编码观察/C3 硬约束入册；优点：纯函数+只调公共API+archive覆盖 |
| 2026-08-03 | 阶段3 D 裁剪收尾 + flaky 修复 | L2/L3 | diff+单测+全量+真机M1 | ✅ | bug：白名单回归修复/flaky 一行修；优点：serve 闭包 32→9 + M1 不回归 |
| 2026-08-03 | P3 onboarding | L1 | 报告复核 | ✅ | 无代码；环境就绪（构建/全量/设备/架构理解） |
| 2026-08-03 | W2 ConnectWeb 工具化（A+C） | L3 | diff+单测+全量+真机OCR | ✅ | bug：mov-verify room 兼容待修/B 后续；优点：LLM 免构造 URL + searchTemplate 复用 |
| 2026-08-03 | W1 三幕（badge/抽评/契约） | L2 | diff+JS测试+relay部署 | ✅ | bug：relay review 白名单待加（已部署）；优点：reviewDrawn 确定性 + 契约地基 |
| 2026-08-03 | AgentLoop 崩溃修复 + mov-verify/accept_judge | L2/L3 | diff+单测+真机 | ✅ | bug：PLAN_GATE→FAILED 崩溃（已修）；优点：状态机健壮 + 工具兼容 |
| 2026-08-03 | P3 ocr_accept.sh | L1/L2 | diff+平板验证 | ✅ | bug：判读器《提取误报（已派 P2#12）；优点：实机核对 PYLIB |

---

## 仓库测验文件索引（2026-08-03 整理）

> 整个仓库验收/检测相关文件登记——换审查员、找证据按此定位。

### A. 验收文档（docs/）

| 文件 | 用途 |
|---|---|
| `ACCEPTANCE_LOG.md` | 验收结论档案（验收员唯一产出落点） |
| `ACCEPTANCE_TRACKER.md` | 检测验收台账（本表） |
| `ACCEPTANCE_PLAYBOOK.md` | 验收手册：五招 / 假覆盖四形态 / 变异测试 / 环境药方 |
| `ACCEPTANCE_GUIDE_DEVICE.md` | 平板验收员操作手册（4 测试 7 检查点 + movTest 进阶，2026-08-03 从散落文件整理入档） |
| `DEVICE_ACCEPTANCE.md` | 真机验收 DV 清单 |
| `LLM_TEST_PLAYBOOK.md` / `OCR_PLAYBOOK.md` | LLM / OCR 测试手册 |
| `TASKS_VERIFY_CLI_2026-07-31.md` | mov-verify CLI 验收基建 |
| `TASKS_P2_FIRST_VERIFY_2026-07-31.md` | 初验员职责 |
| `TASKBOARD.md`「待验收人处理」区 | 巡检 #2-#61 历史验收结论 |
| `docs/TASKS_*.md`「验收结论」区 | 各任务逐条验收结论 |
| `REPORT_HERMES_SLIM_PHASE3_PLAN_2026-08-03.md` | 阶段3 规划验收准备（每动作→证据→依据，供审查员核对） |
| `tools/e2e/reports/TEST_REPORT_2026-07-22.md` | 全按钮遍历测试报告（CDP 方法，2026-07-22） |

> 注：`tools/perf/PERF-REPORT.md`、`NULL-BUG-REPORT.md` 为性能/内存 bug 分析，**非验收结论**，不入表。

### B. 真机验收证据（docs/device-acceptance/，79 文件）

| 目录 | 数量 | 内容 |
|---|---|---|
| `2026-08-01/` | 53 | DV-10 全链、保险柜（vault-*）、设置页、OCR golden（历史已上 github） |
| `2026-08-02/` | 21 | 记忆三层、环境地图、H2 健康、M5 安全、房间视觉 |
| `2026-08-03/` | 5 | B1 /infer（b1-ui.png + OCR 文本 + logcat + curl 回包） |

### C. 验证工具（tools/）

| 工具 | 用途 |
|---|---|
| `tools/device_accept.sh` | 真机验收辅助（装包/唤醒/截图/DV 剧本），adb 序列号见此处 |
| `tools/e2e/mov-verify.js` | CDP 驱动 CLI（say/shot/cover/logcat/forward） |
| `tools/e2e/*.js`（52） | 各任务验收脚本（expert-* / vault-* / agent-* 等） |

### D. 测试代码

| 位置 | 数量 | 说明 |
|---|---|---|
| `app/src/test/java` | 70 Java | JUnit 4，全量 758/18/0/0 |
| `hermes-agent/**/test_*.py` | — | serve pytest（mov-serve pytest 31 全绿） |

### E. 测验数据分布（2026-08-03 最终）

- `main`（`f1dc3d7`）：**无验收数据**（已清 64 个历史截图，仅保留验收方法/工具文档）
- `acceptance-data`（`9180f96`）：全部 79 个 device-acceptance 证据 + `ACCEPTANCE_LOG`/`TRACKER`/`GUIDE_DEVICE` 验收文档

---

## 验收数据追溯清单（序号化）

> 每条验收数据：位置 → 对应 commit → 代码位置 → 验收结论，完整追溯链路。
> 追溯方法：验收数据（截图/日志）→ `git show <commit>` 看改动 → 定位文件:行号 → 对应功能 → 结论在 ACCEPTANCE_LOG / TASKBOARD 巡检 / 任务文档。

| 序号 | 验收主题 | 验收数据位置 | 对应 commit | 代码位置 | 结论 |
|---|---|---|---|---|---|
| A01 | 阶段3 B `/infer` 走 MOV BridgeAi | `device-acceptance/2026-08-03/b1-*`（截图/OCR/logcat/curl 回包 48） | `0d7e1d7` | `MovInboundServer.java:278`（infer）、`:310`（splitInferMessages）、`MovInboundServerTest.java:137/153` | ✅ 打回修复复核 |
| A02 | 记忆层 v2 memoryCover | `JournalMemoryDraftTest.xml`（22 tests 变异亲杀） | `bdb3593` | `Journal.java:691`（memoryCover）、`:730`（coverVerbatim）、`BridgeKernel.java:771` | ✅ |
| A03 | DV-10 ConnectWeb 真机终验 | `device-acceptance/2026-08-01/DV-10-*.png`（~25 张全链） | `d01d87d`（fire 后台线程修复） | `browser/`（BrowserAction*、SiteRuleEngine） | ✅ 巡检#10/#15 |
| A04 | 双副本保险柜 vault | `device-acceptance/2026-08-01/vault-keyguard*.png` | `3781c36`（v1.1 自愈/钥匙轮换） | `vault/`（SecureVault/KeyguardGate/DualWriter） | ✅ 巡检#29/#51 |
| A05 | 环境地图 EnvMap | 验收结论见 `TASKS_P3_ENVMAP_2026-08-02.md` + 巡检#46 | `5b7cb5c` | `EnvMap.snapshot`（五类快照）+ env.* Kernel | ✅ 巡检#46（三洞全消） |
| A06 | H2 工具健康 | `device-acceptance/2026-08-02/h2-caps-open.png`、`health-caps.png` | `7414172`（周期探测）、`c797a25`（健康行） | `HealthMonitor`、health schema | ✅ 巡检#59/#60 |
| A07 | M5 安全验收 | `device-acceptance/2026-08-02/m5-security-acceptance.md` | `c9f5b51` | serve 禁网 LD_PRELOAD / sanitize / 产物校验 | ✅ 巡检#57 |
| A08 | 无感工作态 | `device-acceptance/2026-08-02/calm-room.png` | `e2937c2` | newface 技能卡/思考一行态 | ✅ 巡检#41 |
| A09 | 系统设置新脸化 | `device-acceptance/2026-08-02/syssettings-drawer.png` | `d7e00aa` | 设置页 Kernel 桥（linuxStatus/hermesStatus 等） | ✅ 巡检#44 |
| A10 | OCR 40 页长文档 | `device-acceptance/2026-08-02/longdoc_40page.*` | `07e1792` | ocr/ 四指标（KV 恒定/末段不崩） | ✅ 巡检#56 |
| A11 | llama-server+Kernel 对联 | `device-acceptance/2026-08-02/hermes-*.png` | `967fe8d` | ocr.* Kernel 信封、桥门禁 | ✅ 巡检#40 |
| A12 | 专家模式新脸化 | `device-acceptance/2026-08-01/expert-room-flow*.png`、`act3-t2ops.png` | `fdea3b7`（三幕收官） | newface 专家模式、老视图清场 | ✅ 巡检#30 |
| A13 | 设置页重组 | `device-acceptance/2026-08-01/settings-*.png` | `5832f38` / `0e7ba74` | 设置折叠树、能力区块（tool_manifest） | ✅ 巡检#33 前后 |
| A14 | 阶段3 C 记忆统一 | /memory 端点（serve 层，真机 curl 证据本会话） | `415d17e` | `Journal.java:334`（search）、`:369`（searchableText）、`MovInboundServer.java:327+`（memory） | ✅ 变异亲杀 + 真机 C1/C2/401 |
| A15 | 阶段3 D 裁剪收尾 | serve 闭包 32→9（hermes-agent zip）+ M1 剧本 | `aadf5bb` | hermes-agent serve 模块清单 + `_SERVE_EXCLUDE` 白名单 | ✅ M1 真机 healthz/推理42/401 + 全量 775 |
| A16 | Journal.search 排序 flaky 修复 | JournalTest 强制重跑 25/25 | `8cb9d08` | `Journal.java:359`（sort 加 seq 次级键） | ✅ 修复后单次+3连跑稳定 |
| A17 | P3 新接入 onboarding | `TASKS_P3_ONBOARD` 环境确认报告 | 无代码 | — | ✅ 构建/全量/设备/架构理解 |
| A18 | W2 ConnectWeb 工具化（A+C） | `w2-douyin-search.png`（抖音搜索页 OCR） | `da761a7` / `33abd71` | `BrowserToolProvider.java`（browser.open platform+keyword）、`ConnectWebActivity.executeOpen` | ✅ 全量 777 + 真机抖音搜索页 |
| A19 | W1 第一幕 badgeFor + 第二幕随机抽评 | newface-match.test.js（JS 断言过） | `0b2a4d3`/`fc35e1e`/`83b5733` | newface-match.js（badgeFor/reviewDrawn）、newface.js（评价卡 UI） | ✅ JS 测试过 + relay review 白名单已部署 mow.kim |
| A20 | W1 第三幕第一批（DOM 契约+清理） | CARD_DOM_CONTRACT.md + newface.css | `b6f3988`/`2dea21f` | newface.css、newface.js（诚实卡/空态 inline→CSS 类） | ✅ 契约地基 + 清理 123→117 |
| A21 | AgentLoop 状态机崩溃修复 | 真机 send 浏览器指令 bubbles:5 不再崩溃 | `54df83e` | `AgentLoop.java:198-199`（PLAN_GATE 加 FAILED） | ✅ 崩溃解除（agent 自动 browser.open 待增强） |
| A22 | mov-verify room+send 兼容 | 真机 fit→房间名 + send bubbles:5 | `d65c560`/`6f94ff5` | mov-verify.js（cmd_room/cmd_send）、newface.js（openRoom） | ✅ 专家房间进房+发消息 |
| A23 | accept_judge 提取修复 | 合成 golden2 日志 sim 0→0.27 | `6f94ff5` | ocr/scripts/accept_judge.py（DECODE 行提取 + stdout 兜底） | ✅ |
| A24 | P3 ocr_accept.sh rootfs 修正 | golden1 380/380 四指标 | `900cd52` | ocr/scripts/ocr_accept.sh（R/PYLIB 改 tmp rootfs） | ✅ 平板验证 |
| A25 | 一表双脑批1 工具重定向 | HermesToolProvider web.search/fetch 真实现（DDG 搜索/OkHttp 抓取）+ registry.py _MOV_TOOL_MAP | `8d40e9b` | HermesToolProvider.java、hermes-agent.zip | ✅ 全量 886 + diff 精读（真实现） |
| A26 | 一表双脑批2 记忆桥接 curated | JournalMemoryDraftTest +3（tombstone 排除/replace/§分隔） | `78f2784` | Journal.java（curated 层）、MovInboundServer /memory、MemoryToolProvider | ✅ 全量 886 + curated 单测 |
| A27 | 一表双脑批3 技能共享 SKILL.md | SkillStore.parseSkill frontmatter 解析 | `acbb539` | SkillStore.java（SKILL.md→技能）、serve skills_tool 放行 | ✅ 全量 886 + diff 精读 |

**追溯链路示例（A01）**：
`b1-curl-response.txt`（{"content":"48"}）→ `git show 0d7e1d7`（/infer 实现）→ `MovInboundServer.java:278` infer() → 走 ModelRegistry 默认模型 + AiClient → 功能「serve 推理收编到 MOV BridgeAi」→ 结论在 ACCEPTANCE_LOG「2026-08-03 阶段3 B」。

**设备/环境锚点**：平板序列号 `21770d7d`（见 `tools/device_accept.sh`）；MOV 入站 127.0.0.1:8388；serve daemon 8387。
