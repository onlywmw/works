# PLAN_BACKLOG_EXECUTION —— 欠账清扫执行计划（2026-08-10）

> **给谁看**：程序员（按队列顺序施工）。查验员派单制：每项先读对应工单/设计，完工报 hash + 证据。
> **范围**：除支付线（E-15/App 唤起/进件端到端，另有队列）外的全部未完成任务。
> **纪律**：BRANCH_RULES v3（换会话必留交接物/分支不过夜/验收不过周）；全量绿才报 hash；新代码配新测试；编译被 feat/semantic-recall 未提交文件挡住时用 stash 让路（勿删勿提交）。

---

## 队列一：本周清完（小颗粒、高确定性）

### ① 阶段2 八项真机验收收尾（查验员主导，程序员配合修）
- **剩 4 项**：№6 房间视觉（653d7e53）/ №8 回复呈现（8a32e412）/ DISTILLATION（f5f56153）/ 工单24 资产转化层（0f97001f）
- **已采证据**：№5/№7/№9/W3 共 17 张（`docs/device-acceptance/2026-08-09/stage2/`），先回看补结论
- 验收口径：TASKBOARD 待验收区各项「待验收」备注（断言↔截图一一对应，L2 证据链）；做不了记阻塞不许假绿
- 产出：`stage2/REPORT.md` 八项逐项定论 + TASKBOARD 关单/打回
- 量级：一次真机会话（半天）

### ② 工单28 语义召回 M4 收尾（feat/semantic-recall 分支，与现施工会话交接）
- **M4 前置**：bge-small-zh-v1.5 GGUF（int8 ~24MB）**桌面下载 → adb push** 到平板 `filesDir/models/embedding/`（A7 方案，半小时）
- 真机验收（照 PLAN_SEMANTIC_RECALL §七 M4）：正例「凌晨三点才睡」搜「睡眠不足」命中 / 反例不误召回 / 保底路径逐字节一致 / logcat 见 embedding 调用与回退
- **工作区归位**：未提交的 `HermesApplication.java`（SemanticReranker 装配）随 M4 一并提交——先与原会话确认归属，避免抢交
- 验收过 → ff-only 合 main → 删支
- 量级：半天（不含验收）

### ③ 阶段3 六项烂尾正式化（**等用户拍板**，程序员只负责把决定落成板面文字）
| # | 项 | 待用户决定 |
|---|---|---|
| 3.1 | 健身竖闭环幕三/幕四（工单12） | 续（派单）/ 搁置（写边界+重启条件）/ 砍 |
| 3.2 | P1#4 场景扩展真链路 | 同上 |
| 3.3 | P1#7 追剧卡内嵌播放 | 同上 |
| 3.4 | OCR R-SWA（⏸️ 被阻塞） | 正式搁置：重启条件 = 长文档需求出现 |
| 3.5 | 因果记忆·模型融合近/远档 | 正式暂缓：重启条件写明（近档=DeepSeek 抽取器排期；远档=GPU/数据投入立项） |
| 3.6 | 平板联网控制（疑 MIUI 封网） | 用户本人查证后销账 |

## 队列二：本周必须动（职业体系地基 + 长审批前置）

### ④ G0 已派单（`20734953`，docs/TASKS_GIG_G0_2026-08-10.md）
- relay devices 扩展 + gig 消息型白名单一次部署 + 小微进件核实
- **用户配合**：商户平台「服务商功能 › 小微商户」入口截图
- G0 关单 → 顺序派 G1a（角色开通）/ G1b（即时任务流+抢单原子性）

### ⑤ 个人认证短信通道（G1 前置闸，审批周期 1-7 天，越早提交越好）
- relay 加短信通道：partner-server 加 `/v1/sms`（发送+校验，Bearer fail-closed，频控防轰炸）
- 运营商侧：短信签名+模板申请（**用户平台操作**，阿里云/腾讯云）
- 端侧：身份认证页个人区接通（手机号+验证码；档案只存手机号哈希+时间，明文不出端——DESIGN_GIG_PLATFORM §七）
- 降级在案：短信未就绪时 G1 以「本地声明」跑主链（三档徽章：未认证/已声明/已验证）

## 队列三：技术欠账（挑空档，按序还）

### ⑥ Journal 单例收敛（seq 重号竞态）
- 现状：全仓 5 处 `new Journal(...)`（BridgeKernel/AgentLoop×2/CausalEngine/McpProvider/MovMcpServer），`synchronized` 实例锁挡不住跨实例 `nextSeq` 读-改-写竞态（实证 seq 6,6 重号，证据 `device-acceptance/2026-08-07/t13-2-crash-recovery/02-crash-journal.jsonl`）
- 修法方向：每房间 Journal 单例（注册表式 `Journal.forRoom(dir)`）或 seq 分配改文件级锁；改动面小、影响面大——**先出 DESIGN 小稿再动手**
- 验收：并发 append 压测用例（多实例同房间并发写 → seq 唯一递增）+ 变异（锁去掉 → 重号 → 用例必红）+ 全量不回归

### ⑦ serve 完整任务链（proot 内 Hermes agent 直连 LLM Connection error）
- 现状：proot 内 agent 出网直连 LLM 失败（工单4 实证在案）；设计上 infer 应走 MOV 侧 BridgeAi（/infer 已通），任务工具网络走 LD_PRELOAD 规则
- 动作：先诊断补全（proot 内 curl 外网/DNS/代理三测），再定修法（走 /infer 转发 or 修网络）
- 验收：proot 内 hermes 任务链端到端真机证据（或诚实降级结论落档）

### ⑧ MCP 市场挂账两件（非支付核心）
- **货架 6 件接真 Shelf**：现仅 pkg-accept-001 一件真数据，其余 6 件点购买必 PRODUCT_NOT_FOUND——接真数据或标「即将上架」诚实文案（不许静态「已售 N」虚构文案继续挂）
- **OrderStore journal 滚动 snapshot 重建**（超 500 条重建机制，交付文档 §四.3 自认欠账）

---

## 汇报与关单
- 每项完工：报 hash + 证据 → 查验员验收 → TASKBOARD 更新（✅/打回附精确修法）
- 本计划执行进展登记进 TASKBOARD 变更日志（一条即可，别逐条刷板）
