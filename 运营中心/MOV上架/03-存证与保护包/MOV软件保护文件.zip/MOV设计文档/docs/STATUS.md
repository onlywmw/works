# MOV 项目状态总览

> **⚠️ 历史快照（2026-08-08 标注）**：最后更新 2026-08-01，文中测试数（453）、「下一步」队列均为当时状态，**已过时**。
> 当前状态唯一权威 = [TASKBOARD.md](TASKBOARD.md)（工单14+ 登记区 + 后续队列）；交付/验收记录 = [ACCEPTANCE_LOG.md](ACCEPTANCE_LOG.md)。

---

## 一、当前主线

**FUSION 融合架构（F1-F6）已收官** — 一表两脑统一注册表落地（DESIGN_FUSION.md）。

| 步 | 内容 | commit |
|---|---|---|
| F1+F2 | 注册表建表 + 场景卡收编（FastSceneProvider 8 卡） | `18f513c` |
| F3 | 记忆收编（MemoryToolProvider：watch_history/drama_memory/face_history/face_mine） | `1574da0` |
| F4 | 意图层吃工具清单（intentPromptText） | `1715a0f` |
| F5 | 结果回脸（deliver 交付卡回流 newface） | `e6aaa2d` |
| F6 | 晋升统计（ToolStats journal 工具频次） | `6547048` |

配套：正确性四修（`2427c7e`）、缓存两修（`d560206`）、设置页重组两 commit（`5832f38`/`0e7ba74`）。

## 二、已完成

| 域 | 内容 | 状态 |
|---|---|---|
| UI 迁移 | 5 期全部完成（CSS tokens / 思考区 / 计划卡 / 输入胶囊 / 删死 CSS） | ✅ |
| 架构债 | #0-#5, #8 完成（错误信封/桥守卫/JS 测试/流式校验/PromptLoader 缓存/history 分桶） | ✅ |
| Kernel | P0-P6 全过（journal 地基/信号化/回放/tool.execute/Worker/全房间 journal 化/遥测） | ✅ |
| 新脸 | 场景卡体系：音乐/火车票/追剧/蚂蚁影视/A2A/支付接力 + LLM 意图路由 | ✅ |
| 设置页 | 重组为折叠树（大脑/连接/场景卡/能力/隐私/技术），只做投影不另建数据源 | ✅ |
| 任务 G | 蚂蚁影视搜索适配（DramaSource/MayiParser）+ docs 批量入档 | ✅ |
| 官网 | mow.kim 上线（site/index.html，Live + 两店徽章 + /healthz） | ✅ |

## 三、测试

- **453 tests 全绿**（0 failures / 0 errors），BUILD SUCCESSFUL
- node 回归：`newface-router`（含 P1-3 机票向量 + regex 模式）、`newface-delivery`（交付卡数据）

## 四、真机待验（平板装新构建后）

1. 断网说「我要听小苹果」→ 报「音乐服务连不上」（打回 1）
2. LLM 意图路由「来点轻音乐」→ 走音乐卡（打回 2）
3. 设置页折叠树展开/收起、连接清除登态、能力区块渲染
4. 意图路由开关（LLM 优先 / 仅快速通道省 token）
5. F5 交付卡回流：handoff → 慢脑跑完 → 回新脸看交付卡

## 五、下一步

- P1 队列：W2（ConnectWeb 全量工具化 browser_*）/ W3（场景扩展真链路）/ W4（语音输入+冷启动+回归脚本化）
- P2/P3 队列待认领（browser_* 挂载 / workflows 触发器 / 情境图谱 / 支付闸 L1.5）
- OCR 专线 P4 并行（docs/DESIGN_OCR_MOBILE.md，文件边界见 ONBOARD 分工表）
- 真机自验清单（见上）
