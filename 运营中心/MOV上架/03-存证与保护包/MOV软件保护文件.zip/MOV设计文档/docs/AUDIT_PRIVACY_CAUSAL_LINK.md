# AUDIT：NarrativeBuilder→DeepSeek 链路 PII 审计 — 2026-08-05

> **范围**：`causal.reflect` 用户主动归因 → NarrativeBuilder 合成叙事 → CausalOracle 出网 → DeepSeek 归因 → PatchCompiler 写回本地规则，全链路 PII 泄漏面审计 + 出网前确定性脱敏。
> **结论**：审计发现 4 个泄漏面，已用 3 道闸门 + 1 个确定性脱敏器闭环；测试零网络全覆盖，变异亲杀 4 点必红。
> **关联**：`docs/DESIGN_CAUSAL_APIFACT.md`（原设计）、`docs/ACCEPTANCE_PLAYBOOK.md`（禁假覆盖四形态）。

---

## 一、链路与数据流

```
causal.reflect (CausalToolProvider)
  → NarrativeBuilder.narrate(engine, room)   # 语义级脱敏：实体→实体A/B/C，金额不输出 meta
  → CausalOracle.analyze(brain, narrative)   # 唯一出网点
      → PiiScrubber.scrub(narrative)         # ① 出网前确定性脱敏（正则兜底）
      → brain.chat(system, narrative)        # AiClient → DeepSeek（HTTP）
  → PatchCompiler.compile(engine, room, patch)
      → PiiScrubber.containsPii(...)         # ③ 入站写回闸门（拒绝 PII 原文落库）
```

用户数据离开设备的**唯一出口**是 `CausalOracle.analyze` 里的 `brain.chat`（`CausalToolProvider.buildOracleBrain` 只经 analyze 调用，无旁路）。

## 二、审计方法

- 代码追踪：从 `causal.reflect` 入口到 `AiClient.chat` 出网点逐行追，找所有可出网数据字段
- 数据字段分类：哪些字段可能含 PII（自由文本 vs 结构化）
- 测试验证：spy/fake 注入捕获出网 payload 断言无 PII；变异亲杀确认测试真覆盖

## 三、泄漏面清单（审计发现）

| 编号 | 泄漏面 | 严重度 | 处置 |
|---|---|---|---|
| L1 | `CausalOracle.analyze` 是唯一出网点，原实现把 narrative 直接交给 brain，**无正则兜底**——任何下游漏网 PII 都出网 | 高 | 出网闸门：`analyze` 内 `PiiScrubber.scrub(narrative)` 收口 |
| L2 | `NarrativeBuilder` 的「高频关系类型」段把 **predicate 原样输出**。predicate 是用户 `causal.record` 自由文本（如 `"电话13800138000催款8000元"`），可整体夹带手机号/金额/邮箱 | 高 | 叙事闸门：谓词拼接前 `PiiScrubber.scrub` |
| L3 | 实体 label 虽编号化为 实体A/B/C（安全），但编号 map 的 key 是原始 label——若 label 是邮箱/手机号等 PII 字符串，编号逻辑不崩溃但依赖 L1 兜底 | 中 | 依赖出网闸门 L1 覆盖 |
| L4 | **入站回声**：DeepSeek 若在返回补丁里鹦鹉学舌复述收到的原文（condition/suggested_trigger/hidden_variables 含手机号/金额），PatchCompiler 会把 PII **写回本地规则**并展示给用户 | 高 | 入站闸门：`containsPii` 命中 → 拒绝落库 |

**已覆盖（原设计）**：NarrativeBuilder 实体编号、meta 金额不输出（只统计 outcome）→ 语义级脱敏保留。
**审计结论**：语义级脱敏挡不住「自由文本内嵌 PII」，必须正则级兜底。

## 四、确定性脱敏器（PiiScrubber）

- **位置**：`causal/PiiScrubber.java`，纯 JVM、零 android 依赖、零网络、零模型
- **确定性**：同输入必同输出（纯正则替换，无随机盐）；应用顺序固定：URL → 邮箱 → 身份证 → 银行卡 → 手机号 → 金额（长串优先，防短模式啃掉长串）
- **规则**：URL / 邮箱 / 身份证 18 位（末位 X）+15 位 / 银行卡 13~19 位 / 手机号 `1[3-9]\d{9}`（前后数字边界）/ 金额（`¥|￥` 前缀 或 数字+`元|块钱|块|万|万元`）
- **误伤控制**：裸数字、百分比（`60%`）、计数（`3 条`）不命中——叙事分析语义原样通过（测试 `scrub_cleanText_unchanged` 固化）
- **API**：`scrub(String)` 打码 / `containsPii(String)` 检测（供入站闸门）

## 五、三道闸门

| 闸门 | 位置 | 时机 | 行为 |
|---|---|---|---|
| ① 出网 | `CausalOracle.analyze` | `brain.chat` 前 | narrative 全量 scrub，任何改动只要走 analyze 就绕不开 |
| ② 叙事 | `NarrativeBuilder` 高频关系段 | 谓词拼接前 | predicate（自由文本主泄露路径）单独 scrub |
| ③ 入站 | `PatchCompiler.compile` | 落库前 | condition/suggested_trigger/hidden_variables 任一含 PII → 拒绝落库，返回 `{ok:false, error:"补丁含未脱敏原文（PII）"}` |

## 六、测试（零网络）

| 测试类 | 用例 | 防假覆盖断言 |
|---|---|---|
| `PiiScrubberTest` | 9：手机/身份证18/身份证15/邮箱/银行卡/金额/URL/混合/干净文本/null | 每用例断言「原文消失 + 占位符出现」+ 干净文本原样 |
| `CausalOracleTest.analyze_scrubsPiiBeforeSending` | fake Brain spy 捕获出网 payload | 出网文本断言无手机号/身份证/邮箱/金额 + 含 `[手机号]` |
| `NarrativeBuilderTest.narrate_predicatePii_scrubbed` | 谓词夹带手机号/金额 | 叙事无 PII 原文 + 含 `[手机号]` |
| `PatchCompilerTest.compile_piiWriteBack_rejected` | 云端补丁含 PII 原文 | 拒绝落库 + `rules` 无 `patch_` 规则残留 |

全部 fake/spy 注入，零网络零模型。

## 七、变异亲杀（4 点，必红清单）

| 变异 | 恒空/恒回位置 | 必红测试 |
|---|---|---|
| 手机号规则恒空 | `PiiScrubber` PHONE 替换 | `scrub_phone_masked` |
| 出网闸门去掉 | `CausalOracle.analyze` 去掉 scrub 行 | `analyze_scrubsPiiBeforeSending` |
| 谓词不 scrub | `NarrativeBuilder` 高频关系段改原样 | `narrate_predicatePii_scrubbed` |
| 入站闸门恒放行 | `PatchCompiler` containsPii 恒 false | `compile_piiWriteBack_rejected` |

## 八、残余风险与边界（诚实声明）

1. **人名/地名不脱敏**：PiiScrubber 不做姓名启发式（词典不可靠，误伤大于收益）；姓名由 NarrativeBuilder 实体抽象（实体A/B/C）处理。若谓词内嵌姓名（如 `"借给张三5000元"`），PiiScrubber 盖金额不盖「张三」——姓名仍可能出网。**缓解**：谓词通常是动词短语，姓名走实体编号；真名兜底列为后续治理项。
2. **语义推断**：脱敏后「实体A 与 实体B 有往来关联（强度 60%）+ 高频关系类型：欠款」仍可被推断人物关系类型。DeepSeek 无状态一次性分析 + system prompt 明示脱敏，风险可接受。
3. **双脱敏组件重叠**：`security/PiiMasker`（保险柜副本净化，含姓名启发式）与 `causal/PiiScrubber`（出网前哨，含 URL/邮箱/金额/containsPii）规则部分重叠。**治理项**：后续考虑收敛为单一脱敏器（低优先，动保险柜核心件风险高，暂缓）。
4. **金额阈值无敏感度分级**：`99 元` 与 `5000 元` 同打码（确定性优先，不做阈值判断）。

## 九、验收对照

| 任务要求 | 交付 |
|---|---|
| NarrativeBuilder→DeepSeek 链路 PII 审计 | 本文件 §三 泄漏面清单 + §八 残余风险 |
| 出网前确定性脱敏器（手机号/身份证/邮箱/金额） | `PiiScrubber` §四（含 URL/银行卡 超集） |
| 零网络测试 | §六 全 fake/spy，变异亲杀 §七 |
