# DESIGN_WXPAY_APPLYMENT —— 微信支付服务商特约商户进件

> 版本 v1 · 2026-08-09 · 分支 feat/wxpay-applyment
> 依据：微信支付合作伙伴文档《提交申请单_特约商户进件》（2025.03.26 更新）
> 定位：MOV 用户是微信支付**普通服务商**，本功能让 MOV 帮商家收集进件资料并提交入驻。

## 一、总体架构

**MOV 端做资料收集，后端持私钥调微信支付 APIv3。** 私钥不出服务端，MOV 端零接触。

```
MOV（Android 平板）
  ├─ mov-applyment.js   分步表单（六大块资料收集 + 图片选择/拍照）
  ├─ partner/PartnerClient.java   HTTPS 调后端（cbId 异步，错误信封）
  └─ toolprovider/PartnerToolProvider.java   wxpay.applyment.* 三工具（agent 可用）
        │  HTTPS + Bearer token
        ▼
partner-server（FastAPI，部署 mow.kim，与现有 relay 同机）
  ├─ POST /v1/applyment          → 微信 POST /v3/applyment4sub/applyment/
  ├─ GET  /v1/applyment/{code}   → 微信 GET  /v3/applyment4sub/applyment/business-code/{code}
  └─ POST /v1/media              → 微信文件上传 API（multipart → media_id）
        │  服务商 API 私钥签名 + 微信支付公钥加密敏感字段
        ▼
  api.mch.weixin.qq.com（APIv3）
```

## 二、红线解禁点（明示范围，超范围 = 越线）

1. 「支付永久不碰」解禁范围：**仅限特约商户进件资料收集与状态查询**。不含任何支付/代扣/退款/分账等资金操作；收款码直达、无资金池原则不变。
2. 商户敏感资料（身份证/银行卡/联系方式）：MOV 端**不落盘明文、不入 journal、不进 logcat**；内存持有，提交成功/取消后清除；草稿如需保存走 SecureVault 加密。
3. 服务商 API 私钥 / APIv3 密钥 / 微信支付公钥ID：**只存后端**；配置走 env/本地文件，不进 git（partner-server/.env 已 .gitignore）。
4. MOV↔后端：HTTPS + 共享 Bearer token（MOV 侧经 SecureVault 存）；后端未配置 token 时 fail-closed 全 401（同 serve 纪律）。
5. 复用既有安全件：PII 显示脱敏走 `security/PiiMasker`；提交动作走 PaymentGate 风格锁屏确认闸；审计 append-only JSONL 不落敏感明文。

## 三、进件字段映射（微信六大块 → 表单分步）

| 微信字段块 | 表单步 | 必填 | 要点 |
|---|---|---|---|
| business_code | 自动生成 `{mchid}_{ts}` | ✅ | 服务商侧唯一，幂等键 |
| contact_info | ② 超级管理员 | ✅ | LEGAL/SUPER；SUPER 需补证件信息；姓名/手机/邮箱/证件号敏感加密 |
| subject_info | ① 主体类型 + ③ 主体证件 | ✅ | 个体户/企业→business_license_info；政府/事业/社会组织→certificate_info；identity_info 恒必填；金融机构加 finance_institution_info；企业/社会组织多受益人加 ubo_info_list |
| business_info | ④ 经营资料 | ✅ | 简称/客服电话 + sales_info 场景（按勾选场景展开对应子表单） |
| settlement_info | ⑤ 结算规则 | ✅ | settlement_id + qualification_type（费率结算规则对照表） |
| bank_account_info | ⑥ 银行账户 | ✅ | 个体户可对私经营者卡，其余对公；户名/卡号敏感加密 |
| addition_info | 补充材料 | 选填 | 驳回后补件场景 |

敏感字段清单（后端用微信支付公钥加密后才上送）：contact_name/contact_id_number/mobile_phone/contact_email、证件姓名/号码/地址（含 UBO）、account_name/account_number。

## 四、后端 partner-server 契约

- `POST /v1/applyment` body=完整申请单 JSON（明文敏感字段）→ 后端公钥加密 + 签名上送 → `{applyment_id}`；微信错误码透传映射（PROCESSING/PARAM_ERROR…）
- `GET /v1/applyment/{business_code}` → `{applyment_state, ...}` 状态查询
- `POST /v1/media` multipart 图片 → `{media_id}`
- `GET /healthz` 免鉴权；其余 Bearer token fail-closed
- 审计 `applyment_audit.jsonl`：时间/动作/business_code/结果码，**不落敏感明文**
- 测试：pytest，mock 微信 HTTP 层，零真实网络、零真实密钥（测试自生成 RSA 对）

## 五、MOV 端落点

- `partner/PartnerClient.java`：OkHttp + HttpTransport 接口化（照 pay/WxPayClient 模式），单测零网络；回调 Cb<T>，桥侧 cbId 异步（网络 IO 禁同步桥）
- `partner/PartnerConfig.java`：服务器地址 prefs；token 经 SecureVault
- `toolprovider/PartnerToolProvider.java`：
  - `wxpay.applyment.submit`（DANGEROUS，锁屏确认闸）
  - `wxpay.applyment.query` / `wxpay.applyment.upload_media`（write 级）
- 前端 `js/mov-applyment.js`：设置二级页 id `'applyment'`（照 mov-market.js 挂 newface.js renderSubPage）；图片走 copyFileToRoom / camera.capture → upload_media → media_id 回填；createElement+textContent，中文 only

## 六、错误码处理

| 微信码 | 处理 |
|---|---|
| PROCESSING | 提示已有进行中申请单，引导查询状态或换 business_code |
| PARAM_ERROR | 透传微信错误描述，定位到表单字段 |
| NO_AUTH | 提示服务商权限未开通 |
| RATE_LIMITED | 指数退避重试 |
| 401（自家后端） | 提示 token 未配置/失效 |

## 七、不做

- 不做支付/退款/分账等资金接口
- 不做个人小微商户进件（接口本身不支持）
- 私钥/证书不上 MOV 端、不进 git
- 不改 hermes-agent、不动现有 pay/ 市场链路
