# MOV agent 浏览器工具协议 v1 — 2026-07-30

> 取经自 `ExTV/rikkahub-agent` browser 模块（精读报告见本文 §7），按 MOV 架构纪律改造：
> Java + 系统 WebView + cbId 异步桥（网络/IO 禁同步桥）+ 支付永远停在用户本人确认。
> 状态：草案 v1，待 ConnectWeb 落地（R3-3）时作为施工图纸。关联：DESIGN_EMBEDDED_BROWSER.md。

## 0. 设计原点

agent 驱动浏览器的本质矛盾：**让 LLM 操作页面，又不把整页 HTML 塞进上下文**。
RikkaHub 的答案是三层省钱设计（正文提取 + diff 回传 + 错误自恢复），我们全盘接收并按桥机制改造。

## 1. 工具集（16 个，三级门控）

门控原则（原样搬）：**读默认开、写默认关；逐工具开关；关闭即不注册**（不出现在 LLM 工具列表，比 prompt 约束强）。

### Read（默认启用，免审批）

| 工具 | 参数 | 说明 |
|---|---|---|
| `browser_open` | `url*` | scheme 白名单：仅 http/https（禁 file://，防读应用私有文件） |
| `browser_get_text` | `selector?, max_chars=8000, extract_mode=auto/readability/raw` | 三级降级：selector > Readability > body.innerText；Readability <200 字符判垃圾提取自动降级 |
| `browser_get_dom` | `selector=body, max_chars=4000` | 剥 script/style/noscript |
| `browser_get_links` | `selector?` | ≤100 条 {href,text} |
| `browser_snapshot` | — | **MOV 独有**（见 §4 元素编号） |
| `browser_current_url` / `browser_back` / `browser_forward` | — | |
| `browser_wait_for` | `selector*, timeout_ms, contains_text?, state=attached/detached/visible/hidden` | 等 SPA 渲染的标准姿势 |
| `browser_screenshot` | — | 喂视觉模型时才是图，否则文本占位；描述里劝模型"只要文字就先 get_text" |

### Write（默认关闭，开必审批）

| 工具 | 参数 | 说明 |
|---|---|---|
| `browser_click` | `target*`（eid 序号或 selector） | 成功后默认回 diff |
| `browser_type` | `target*, text*, clear?` | focus + set value + dispatch input/change |
| `browser_scroll` | `direction*, amount=600` | 不走 diff（innerText 不变），回 `scroll_y` |
| `browser_submit` / `browser_select` / `browser_press_key` | … | |
| `browser_click_and_read` | `target*, extract_mode?, max_chars?` | **复合工具**：click→ready→read 一次 cbId 往返，异步桥天然契合，重点推 |
| `browser_eval_js` | `code*` | **最高危面**：NO_ALWAYS_ALLOW（永远逐次确认）+ HARDLINE 正则地板（拦 `document.cookie=`/`eval(`/`new Function(`/字符串 setTimeout） |

### Loop 控制

| `browser_done` | `summary*, result_url?` | 关闭任务窗口（见 §3 双超时） |

## 2. 统一错误 envelope（教 LLM 自救，不抛异常）

```json
{"error":"browser_not_open","recovery":"Call browser_open with a URL first."}
{"error":"browser_task_timeout","recovery":"Call browser_done with a summary..."}
{"error":"browser_busy","recovery":"Another conversation is driving the browser. Wait and retry."}
{"error":"selector_not_found","recovery":"Call browser_snapshot to get fresh element ids."}
```

错误码表：not_open / task_timeout / session_lost / busy / selector_not_found / js_failed / scheme_blocked。

## 3. 双超时（runaway loop 成本封顶）

- **per-tool 硬超时** 30s（可调）
- **单任务窗口** 5min：`browser_open` 开窗、`browser_done` 关窗；窗尽后所有工具只回 task_timeout envelope
- 与 AgentLoop 的 PLAN_GATE 对称，落地时并进 ToolRuntimeLimits

## 4. MOV 独有改进：元素编号快照（治 selector 漂移）

RikkaHub 最大痛点：LLM 靠 get_dom 猜 CSS selector，SPA 重渲染后 selector 漂移 → 重试循环烧 token。
我们有常驻 JS 桥（不用每次重注入），可以做 browser-use 式编号：

- `browser_snapshot`：注入脚本给可见可交互元素（a/button/input/select/[onclick]）打 `data-mov-eid="N"`，回传 `[{eid, tag, text, role}]`（≤100 条，文本截 40 字）
- 写工具的 `target` 参数接受 `"eid:12"` 或 CSS selector，优先 eid
- 每次写动作后 eid 失效，下次 snapshot 重编（envelope 里提示）

## 5. diff-after-action（全仓库 ROI 最高单点，91 行可移植）

- 快照 = `document.body.innerText`（whitespace 折叠防 reflow 噪声）
- diff = **行集合差**（LinkedHashSet，不算 Myers——模型要的是"新出现了什么"）
- 回传 `{added, removed, truncated}`，每侧硬夹 2000 字符；无变化 `{unchanged:true}`（模型据此判断"点了没反应"）
- scroll 特例：不走 diff，回 scroll_y
- Java 移植成本极低，落地第一周就做

## 6. 正文提取（Readability.js）

- assets 打包 Mozilla Readability.js（Apache-2.0，license 干净）
- **cloneNode(true) 后再 parse**——Readability 会原地改写 DOM，不克隆会把活页面洗掉
- 我们可以"注入一次 + sentinel 检查"（RikkaHub 每次重注入 90KB 是因为页面跳转后 JS context 重置；同城页面可不重注）
- 超时 4s，失败降级 body.innerText

## 7. 安全闸（对照 MOV 既有纪律）

| 闸 | 规则 |
|---|---|
| scheme 白名单 | browser_open 仅 http/https + WebViewClient.shouldOverrideUrlLoading 拦 http→file 跳转（两处缺一不可，隐性不变量写进代码注释） |
| 审批分层 | 写工具默认逐次确认；会话级"本次允许"；持久白名单；eval_js 永远逐次（NO_ALWAYS_ALLOW）+ HARDLINE 正则地板 |
| 支付闸 | **支付永远停在用户本人确认**（MOV 铁律）——浏览器内金额/订单页面动作进 Phase 3B BiometricPrompt 闸，协议预留 `domain_policies` 字段 |
| 敏感嗅探 | URL query 里 JWT/卡号形状 → envelope 附 warning 叫模型别回显 |
| cookie 边界 | 浏览器带用户会话，任何改状态动作必须过闸（=RikkaHub 注释原意，与 MOV 支付铁律同源） |

## 8. 异步桥改造要点（cbId 纪律）

1. 所有工具走 cbId 异步：JS 侧注册回调 → 主线程 Handler 分发到 ConnectWebActivity → evaluateJavascript 结果经 `_hermesCb` 回传。**禁对 unattached WebView 用 view.post()**（永不 attach 永不执行——RikkaHub 踩过的坑，无头模式同理走主线程 Handler）
2. 只在碰 WebView API 时切主线程；diff 计算/envelope 组装/PNG 编码全在工作线程（RikkaHub 把 PNG 编码放主线程，1080×1920 ≈8MB 掉帧，不抄这个懒）
3. headless 模式 v1 不做（Telegram/cron 远程浏览无需求）——砍掉 SessionPool/截图流 40% 复杂度，只保留 Foreground + 动作轨迹流（最近 20 条，驱动底部状态条，可验收性）
4. 中断语义（抄）：agent 循环持久化时，"执行了但没拿到结果"的工具调用标 `interrupted_unknown_outcome`，提示模型"副作用可能已发生，先验证再重试"——cbId 架构同样有 mid-execute 死亡窗口

## 9. 明确不做（v1）

- 多会话并发浏览器（全局单槽，busy 拒绝）——架构简单，够用
- workflows 触发器引擎——设计已留档（19 触发器/14 条件清单、按需注册 receiver、debounce resync、Room 单表 canonical JSON），归 Phase 3 情境图谱专项，存储用单 JSON 文件不引 Room
- full_page 截图（viewport 够用）

## 10. 落地顺序（R3-3 施工时）

1. browser_open/get_text/wait_for/done + 错误 envelope + 双超时（骨架）
2. diff-after-action（91 行，当周见效）
3. Readability 注入 + 三级降级
4. 写工具 + 审批闸 + scheme 白名单
5. browser_snapshot 元素编号（MOV 独有差异化）
6. browser_click_and_read 复合工具

---

## 附：RikkaHub browser 模块精读要点（探索代理报告摘要）

- 模块：`me/rerere/rikkahub/browser/`（2700 行）+ `data/ai/tools/local/BrowserTools.kt`（1380 行，17 工具）
- 渲染：系统 WebView 双模式（Foreground / Headless 挂 unattached LinearLayout 手动 layout 1080×1920）
- headless 技巧：SOFTWARE layer 才能 draw canvas；注入 visibilityState=visible 骗 Page Visibility API；UA 去 `; wv)` 防 bot 嗅探
- 工具注册门控：`LocalTools.getTools` 按用户开关决定注册，关闭的工具 LLM 根本看不见
- 截图流：30s 同 URL 去重窗口 + 600ms paint settle（readyState=complete ≠ 首帧渲染完）
- 审批：8 个写工具默认 ALWAYS_ASK；eval_js NO_ALWAYS_ALLOW + HARDLINE 正则；三级豁免（会话/持久/YOLO）
- workflows：19 触发器（time_cron/wifi/bt/耳机/电源/电池阈值/地理围栏/App 启动关闭/通知/开机/屏幕亮灭/manual）+ 14 条件（AND+invert）；按需注册 receiver（零启用=零 receiver）；time 族走 WorkManager；存储 Room 单表 canonical JSON + 投影列
- 粗糙处（不抄）：主线程 PNG 编码；eval_js 正则地板拦不住混淆；diff 只比文本（图加载报 unchanged）；全局单槽；selector 漂移无元素编号

> 修订（2026-07-30 验收人）：scroll 豁免审批——不改页面状态只改视口。审批组 = click/type/submit/select/press_key/eval_js/click_and_read。
