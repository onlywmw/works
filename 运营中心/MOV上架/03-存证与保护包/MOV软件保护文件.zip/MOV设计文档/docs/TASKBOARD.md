# MOV 任务板（TASKBOARD）— 人机协同协议 v2（AI 刻度队列制）

> **给程序员（P1/P2）**：你的任务在这里领取，报告写在这里。不需要等人类传话。
> **规则**：
> 1. 认领：在你的队列取**第一项**，开工前把状态改成 🔨
> 2. 完成：commit 后把状态改成 ✅ 写 hash + 一句话交付说明，**立即拉取队列下一项**（不等验收）
> 3. 验收：**按需手动触发**（提交后人工请验）——读 commit → 按 L 级验收（ACCEPTANCE_PLAYBOOK.md）→ 结论写 docs/ACCEPTANCE_LOG.md + 更新本板（不再自动巡检）
> 4. 打回：验收结论出现在任务文档后，**优先于队列下一项**——先修完再继续
> 5. 纪律沿用：ENV_SETUP.md（构建/装机/固定四步）、ACCEPTANCE_PLAYBOOK.md（验收标准）
> 6. **AI 刻度**：无日历门禁，里程碑制，干完即续。颗粒按功能域不按功能点。

> **防复发三规矩（2026-08-09 收尾计划阶段4）**：
> ① **换会话必留交接物**：任何「移交新会话」先写 `TASKS_*` 工单文档 + 本板登记，否则不许停手
> ② **分支不过夜**：验收通过 48h 内 `merge --ff-only` 合 main；超前 5 commit 未合亮红灯
> ③ **验收不过周**：🔨 待验收挂 7 天无人验 → 自动升级用户裁决（验/降级/砍）

## 队列

### P1（新脸/ConnectWeb/买家侧）
| # | 任务 | 文档 | 状态 |
|---|---|---|---|
| 0 | **DV-10 打回两修 + 职业注册表开工** | docs/TASKS_P1_WF_FIX_REGISTRY_2026-08-01.md | ✅ 全部过（巡检#15：修复1 `bc8eef1` 复跑全绿） |
| 1 | W1 三幕：菜名优先/随机抽评/卡片 DOM 契约 | docs/TASKS_P1_DISH_FIRST_2026-07-31.md | 🔨 第一幕✅ `0b2a4d3`；第二幕✅ `fc35e1e`+`83b5733`（reviewDrawn JS 测试过 + relay review 白名单已部署 mow.kim；真机评价待 A2A 场景）；第三幕✅ 第一批 `b6f3988`+`2dea21f`（CARD_DOM_CONTRACT.md + 评价卡样式 + 诚实卡/空态清理 123→117，剩 117 处留新会话分批） |
| 2 | **workflows 扩展包（四幕）** | docs/TASKS_P1_WF_EXPAND_2026-08-01.md | ✅ **四幕全部收官**（巡检#21：第三幕过；随行一行修正 is_charging plugged 合取） |
| 2.5 | **OCR 集成前置包（五件）** | docs/TASKS_P1_OCR_PREP_2026-08-01.md | ✅ 全过（S1 接线 `5f801f7` 巡检#17 验过） |
| 2.6 | **专家模式新脸化（A 档用户拍板，三幕；视图欠账视图还，业务逻辑不动）** | docs/TASKS_P1_EXPERT_NEWFACE_2026-08-01.md | ✅ 三幕收官 `fdea3b7`（第一幕 `88e1507`+轻打回 `bb8fe38` / 第二幕 `98e4f9a` 巡检#25 过 / 第三幕撤底导航删老视图，grep 清零，610 tests 绿，待真机复验必迁三项） |
| 2.7 | **老脸设置迁移（view-run 清场，设置归一）** | docs/TASKS_P1_SETTINGS_MIGRATE_2026-08-01.md | ✅ 过（巡检#33） |
| 2.8 | **房间会话视觉对齐 mockup 屏②（思考面板瘦身/气泡黑白/老卡换新；用户报障）** | docs/TASKS_P1_ROOM_VISUAL_2026-08-02.md | ✅ 过（巡检#36）+ 轻打回已修 `08f07912`（存量种子 replay 白卡） |
| 2.9 | **无感工作态（Kimi PC 参照：思考一行态/技能调用卡/消灭清单）** | docs/TASKS_P1_KIMI_STYLE_2026-08-02.md | ✅ 过（巡检#41） |
| 2.10 | **AI 回复呈现层清理（答案卡/提问卡/计划卡/失败卡/数字格式/提炼层）** | docs/TASKS_P1_REPLY_PRESENT_2026-08-02.md | 🔨 已交付 `8a32e412`（六条+提炼层，652 tests 绿，待真机截图对照） |
| 2.11 | **系统级设置新脸化（Linux/Hermes/MCP/SSH/诊断/重置迁抽屉，原生页退役）** | docs/TASKS_P1_SYSSETTINGS_NEWFACE_2026-08-02.md | 🔨 已交付 `b115e4d9`（6 卡+Kernel 桥+原生页退役，652 tests 绿，待真机安装全流程复验） |
| 3 | ConnectWeb 全量工具化（browser_* 接 AgentLoop，联合 P2）——**分级定义已就绪**（DESIGN_PAYMENT_GATE §三：读=READONLY/写=ACTION/execute=DANGEROUS），代码收编此任务做 | PROGRAM_P1_NEWARENA_2026-08.md W2 | ✅ `33abd71` 验收通过（A+C：browser.open platform+keyword + 真机 ConnectWeb 抖音搜索页 OCR 证实 + 全量 777；agent 端到端待 mov-verify room 兼容修复后复验） |
| 3.5 | **意图路由加 browser/search 类**（B：新脸首页「搜评价」路由到浏览器搜索） | TASKS_P1_CONNECTWEB_TOOL_2026-08-03.md §B | ✅ 交付 `88d2bb3`（browser 意图类 + 正则防误归 drama，777/18/0/0 绿，node 断言过；真机待验） |
| 4 | 场景扩展：订票/购物真链路（演示卡下线） | 同上 W3 | ⏸️ |
| 5 | 语音输入+冷启动+回归套件 | 同上 W4 | ✅（巡检#58；语音待人肉补验） |
| 6 | **AgentLoop 状态机 PLAN_GATE→FAILED 崩溃修复**（W2 端到端复验发现：计划阶段 failMov 非法转换 → IllegalStateException 崩溃） | app/src/main/java/com/hermes/android/agent/AgentLoop.java | ✅ `54df83e` 复核通过（矩阵加 FAILED + 测试同步；真机 send 浏览器指令 bubbles:5 不再崩溃；agent 自动 browser.open 驱动待后续引导增强） |
| 7 | **追剧卡内嵌播放体验**（追剧播放页强制 app 内 + 卡片点击播放 + 集数横向选择） | 派单 2026-08-03 | ⏸️ **暂缓**（2026-08-03 用户判定小问题留待后续）：第1项启动层修复 ✅（`ede8132`+`843bc3d`+`28a4681`）；91mayitv 反 WebView 跳外部（方案 C iframe）留新会话；第2项卡片点击 `aa29c20`✅；第4项集数横向行待做 |

### P2（传输层/债/初验员）
| # | 任务 | 文档 | 状态 |
|---|---|---|---|
| 1 | **mov-verify CLI**（验收基建，最高优先） | docs/TASKS_VERIFY_CLI_2026-07-31.md | ✅ `f269f18` 14命令CLI+README |
| 2 | AgentLoop 侧 browser_* 挂载（配 P1 W2） | PROGRAM W2 | ✅ `53dace8` 复核通过（BrowserAgentLoopMountTest：8 工具可达 + ACTION 分级 + 超时对齐；全量 779/0/0） |
| 3 | ~~workflows 触发器引擎（联合 P3）~~ 已并入 P1 #2 扩展包（单一主建防撞车） | DESIGN_BROWSER_PROTOCOL 附录 | ✅ 转派 |
| 4 | A2aClient BASE_URL 迁移 https://mow.kim（含真机回归） | DESIGN_A2A「relay TLS 上线」节 | ✅ `659eb17` TLS通+merchant脚本验证 |
| 5 | **阶段3 A0：MOV 入站监听 127.0.0.1:8388 地基**（鉴权 fail-closed + 路由分发 ToolRegistry + 单测变异） | docs/TASKS_P2_HERMES_SLIM_A0_2026-08-03.md | ✅ `ea3139a` 五证齐+变异亲杀，739 tests 绿 |
| 6 | **阶段3 A：工具统一**（serve /tools/invoke + HermesClient.invokeTool + A4 拆三步） | docs/TASKS_P2_HERMES_SLIM_A_2026-08-03.md | ✅ `35b66f5` A1/A2/A3 + A4 换路实证（MOV logcat 执行证据 + M1 不回归），749 tests 绿 |
| 7 | **阶段3 B：LLM 收编**（/infer 走 MOV BridgeAi + B2 换路 + model_tools 裁） | docs/TASKS_P2_HERMES_SLIM_B_2026-08-03.md | ✅ `0d7e1d7` 复核通过（打回四项修复 + 变异亲杀 15 tests 2 failed 还原绿 + 真机 B1 curl 回包 48/logcat；查验表 ACCEPTANCE_TRACKER A01） |
| 8 | **阶段3 C：记忆统一**（journal 唯一事件源，/memory 路由 + C2 检索不退化） | docs/TASKS_P6_HERMES_SLIM_C_2026-08-03.md | ✅ `415d17e` 复核通过（变异亲杀 25 tests 3 failed 还原绿 + 真机 C1 写读/C2 正反例/401 亲验 + 全量 775；查验表 A14） |
| 9 | **阶段3 D：裁剪收尾**（依赖 A/B/C） | docs/TASKS_P6_HERMES_SLIM_D_2026-08-03.md | ✅ `aadf5bb` 复核通过（serve 闭包 32→9 + M1 剧本真机 healthz/推理42/401 + 全量 775；查验表 A15） |
| 10 | **Journal.search 排序 flaky 修复**（C 回归：ts 相同无 seq 次级键 → 偶发红） | docs/TASKS_P2_SEARCH_SORT_FLAKY_2026-08-03.md | ✅ `8cb9d08` 复核通过（sort 加 seq 次级键，JournalTest 强制重跑 25/25 + P2 3 连跑稳定） |
| 11 | **mov-verify `room`+`send` 命令兼容修复**（room ✅ 复核过：openRoom 暴露 + 真机 fit→房间名；**send 同类问题**：老脸 `#msgInput` vs 专家 `#expertRoomInput`） | tools/e2e/mov-verify.js | ✅ `d65c560` 复核通过（room + send 真机 bubbles:5 进专家房间；agent 崩溃为 P1#6 已修） |
| 12 | **判读器 accept_judge.py 提取 bug 修复**（`raw.find('《')` 硬编码，golden2/3 输出 `<|det|>` 开头 → sim=0 误判；P3 报告） | ocr/scripts/accept_judge.py | ✅ 复核通过（DECODE 行提取 + stdout 兜底，合成日志 sim 0→0.27） |
| — | 初验员职责：P1/P3 的 L1/L2 commit 初验（验收人复核） | TASKS_P2_FIRST_VERIFY_2026-07-31.md | 常态化 |

### OCR（原 P4 专线，当前执行人报 P2）
| # | 任务 | 文档 | 状态 |
|---|---|---|---|
| 1 | **方法 3 llama.cpp + R-SWA**：✅ **四指标全绿，P2+P3 关门**（巡检#31）；遗留 40 页长文档验证 | docs/OCR_DECODER_MNN.md §9-19 | ✅ |
| 2 | P3 R-SWA（依赖解码器跑通） | docs/OCR_RSWA_ANALYSIS.md | ⏸️ 被 #1 阻塞 |

### P3（新接入 2026-08-03，熟悉环境起步）
| # | 任务 | 文档 | 状态 |
|---|---|---|---|
| 1 | **新接入熟悉环境（Onboarding）**——读手册/跑通构建/全量测试/设备确认，不写代码 | docs/TASKS_P3_ONBOARD_2026-08-03.md | ✅ 复核通过（2026-08-03：构建/全量 775/设备 21770d7d/架构理解，环境报告验收人已复核） |
| 2 | M5 安全验收练手首单（禁网/sanitize/产物校验逐项实证） | docs/TASKS_P2_HERMES_SERVE_M5_2026-08-02.md | ✅ `c9f5b51` 三件实证全过（禁网 LD_PRELOAD 真生效/sanitize 加固/产物越界拒收+401），721 tests 绿 |
| 3 | **ocr_accept.sh rootfs 路径修正**（app rootfs→/data/local/tmp/rootfs，小活） | docs/TASKS_P3_OCR_ACCEPT_FIX_2026-08-03.md | ✅ 复核通过 `900cd52`（路径修正 3 处 + golden1 380/380 四指标 + golden2/3 识别正确；判读 bug 报告 OCR 线） |
| 4 | 接班备位（P1/P2 任一超 1M 上下文下线即接线） | 各线 TASKBOARD 区 | 备位 |

### P5（安全/保险柜）— **已下线 2026-08-02**
| # | 任务 | 文档 | 状态 |
|---|---|---|---|
| 1 | **双副本保险柜 v1（四件）** | docs/TASKS_P5_VAULT_2026-08-01.md | ✅ **v1 交付**（巡检#29 全流实证） |

### OCR（原 P4 专线 → **P6 接任 2026-08-01 晚**）
| # | 任务 | 文档 | 状态 |
|---|---|---|---|
| 1 | ~~llmexport/int8~~ → 方法 3 llama.cpp：GGUF/视觉接入/R-SWA | docs/OCR_DECODER_MNN.md | ✅ P2+P3 关门（巡检#28/#31，P4 交付下线） |
| 2 | **40 页长文档验证** | docs/TASKS_P6_OCR_LONGDOC_2026-08-02.md | ✅ 过（巡检#56 归档工件亲验） |
| 3 | ocr_accept.sh rootfs 路径修正（app rootfs→/data/local/tmp/rootfs，MNN 已在 tmp rootfs 装好） | docs/LLM_TEST_PLAYBOOK.md | ⏸️ 待 P1/P2 认领（小活，原 P6 并入） |
| 4 | **llama-server 部署+Kernel 对联（桥门禁首单）** | docs/TASKS_P6_LLAMA_SERVER_2026-08-02.md | ✅ 过（巡检#40） |
| 5 | **环境地图（快照+env 三件套）** | docs/TASKS_P3_ENVMAP_2026-08-02.md | ✅ 过（巡检#46 三洞全消） |
| 6 | **记忆三层 L1+L2** | docs/TASKS_P6_MEMORY_LAYERS_2026-08-02.md | ✅ 过（巡检#49，mutant 亲杀）；L3 策展待派 |
| 7 | **Hermes 阶段3 瘦身两刀** | docs/TASKS_P6_HERMES_SLIM_2026-08-02.md | ✅ 过（巡检#50 不回归实证） |
| 8 | **记忆层 v2 读取时按需覆盖** | docs/TASKS_P6_MEMORY_COVER_2026-08-03.md | ✅ 过（审核员 2026-08-03 验收通过，`bdb3593`；四数 758/18/0/0） |

### P6（OCR 预研，零真机线）— **已下线 2026-08-03，工作并入 P1/P2**
| # | 任务 | 文档 | 状态 |
|---|---|---|---|
| 1 | **R-SWA 预研** | docs/OCR_RSWA_LLAMACPP.md | ✅ 过（巡检#26，3/3 抽查）→ 移交 P4 施工 |
| 2 | **hermes-agent 瘦身盘点** | docs/HERMES_ANATOMY.md | ✅ 过（巡检#34） |
| 3 | **Hermes 强化记忆探索+改造建议** | docs/HERMES_MEMORY.md | ✅ 过（巡检#35） |

### P3（情境/支付/传感器）
| # | 任务 | 文档 | 状态 |
|---|---|---|---|

| 1 | ~~workflows 触发器引擎 v1（19 触发器/14 条件）~~ 已并入 P1 #2 扩展包（引擎是 P1 建的，单一主建防撞车）；通知/地理围栏两个权限重触发器后续单独评估派单 | DESIGN_BROWSER_PROTOCOL 附录 + PHASE3B 笔记 §2 | ✅ 转派 P1 |
| 2 | 情境图谱 v1（ContextProvider→journal 情境卡「晚上推荐/出行提醒」） | DESIGN_TECH_KERNEL | ⏸️ |
| 3 | 支付闸 L1.5（新脸支付 sheet 接闸） | PAYMENT_GATE_SCHEMA §7 | ⏸️ |

## 2026-08-05 欠账清理批次（验收员派单制：单程序员 + R 预审 + 终审合并）

> 流程：验收员派单 → 程序员隔离 worktree 施工报 hash → R 预审员亲手跑数/变异复核/红线精读 → 验收员终审合并推送。记录详见 docs/ACCEPTANCE_LOG.md 当日条目。

| # | 工单 | 分支/commit | 状态 |
|---|---|---|---|
| 1 | McpClient 三处遗留（SSE分帧/sessionId回写/close DELETE） | `2e67eb3` → merge `18bd5e2` | ✅ R3 通过 |
| 2 | 测试盲区（args.path 复活+web.search/fetch 零网络单测+DDG 归因） | `ccdf52c` → merge `1e87479` | ✅ R2 通过 |
| 3 | 因果链路脱敏（PiiScrubber 出网关口+写回闸门） | `8f10314` → merge `eb6f46e` | ✅ R1 通过 |
| 4 | 真机线（proot EPERM 定案自愈 + RootfsManager 线程堆叠 + HTTP 字节读 + 证据链） | `37a2624`+`312371d`+`9b00187` → merge `1118be5` | ✅ R4 打回复验后通过 |
| 5 | L3 记忆模型提炼（摘要懒生成+冻结注入+归因） | `7faedef` → merge `3086d8f` | ✅ R5 通过 |
| 6 | MCP P2 扩展（write 工具审批闸+房间内确认闭环+mov.* 查询） | `491f644`+`2cf6f9d` → merge `6b6098d` | ✅ R6 通过 |
| 7 | MCP 真机证据链 + 去重 normalize + 旧 McpServer 敏感桥方法 denylist | `474497a`+`4476416`+`161b5c7` → merge `ebd1589` | ✅ R7 打回（反射面泄 token）复验后通过 |
| 8 | 旧 McpServer 存量安全面整治（@McpExpose allowlist+token 鉴权 fail-closed+CORS+脱敏） | `bf24b63` → merge `a378c74` | ✅ R8 通过 |
| 9 | 收尾四小修（注解位置/socket 401 集成测试/死 case/注释） | `3094599` | 🔨 待 R9 预审 |

### 后续队列（目标 eecfbbf6：全清后放完工音乐）
- serve 完整任务链真机证据（绕过 deepseek 澄清卡壳）——工单4 实证形态：proot 内 Hermes agent 直连 LLM Connection error（详见证据）
- ~~dual-brain 三批真机端到端~~ **工单4 验收 2026-08-06**（验收员独立实证，证据 docs/device-acceptance/2026-08-06/ticket4-dual-brain-e2e.md）：**批1 ✅** Anthropic 协议真机真实推理（POST /v1/messages 铁证 + DeepSeek 真实生成 pong + 双协议对照）；**批2 ⚠️** 技能注册 144 工具含 7 技能 + 单测绿，执行链路受双重阻塞如实记录（8388 静态 registry 不含动态技能 + AgentLoop 卡 PLANNING）；**批3 ⚠️** CdpClient/MovWebBridge 代码+单测过、wb.* 已注册，端到端受 connect 无调用点 + 平板无浏览器阻塞；**Hermes 工具/记忆链路 ✅**（8388 infer/memory 写读检索/tools battery.status 全通 + serve 8387 hermes 0.19.0 运行）；**serve 完整任务链 ❌** Connection error（proot 内直连 LLM 网络不通）
- 因果记忆端到端真机（main 侧；P2 d0318e3 已在 feat/mcp-p2-extension 实证 causal 引擎闭环，待并入 main）
- ~~技术债五小项~~ **工单5 清理完成 2026-08-06**：① requestId UUID 前缀防重启重号 + 回归测试 ② @Ignore 全仓清零（AgentLoopTest 复活 34 全绿，@Before 隔离单实例互斥 + 3 测试适配 rescue 降级/shell 分级）③ PiiMasker/PiiScrubber 收敛共享 PiiPatterns 单一来源（行为不变 8+11 绿）④ exportModels 移内部 filesDir 清旧外部明文 ⑤ AndroidHttpServer 固定端口移除自动上移
- ~~W1 第三幕 117 处 inline 清理 + 追剧反 WebView 方案 C~~ **工单6 验收通过 2026-08-06**（`6c1a4d4`）：inline 116→17 动态清零 + 防回归 node 测试（验收员两轮变异亲杀）；方案 C 经真机证据修正为「修一键观看跳外真 bug（_a2aOpenPayLink 误用）+ ConnectWeb 内嵌」，iframe 路径证据否决（XFO SAMEORIGIN + ConnectWeb 直开硬解播放 75s 实证）
- PLAN_SURPASS 批 1 收尾 + 批 2 四支柱
- **Journal 单例收敛（seq 重号欠账，工单13 验收发现 2026-08-07）**：崩溃 journal 原件 seq 6,6 重号——`Journal.append` 是 `synchronized` 实例锁，但全仓 5 处 `new Journal(...)`（BridgeKernel/AgentLoop×2/CausalEngine/McpProvider/MovMcpServer），跨实例并发 append 时 `nextSeq` 读-改-写竞态。当前无实际损害（readAfter/search/roll 均容忍），但「seq 唯一递增」假设不实。修法方向：Journal 收敛单例（或 seq 分配改文件级锁）。详见 ACCEPTANCE_LOG 2026-08-07 工单13 条目；证据 `device-acceptance/2026-08-07/t13-2-crash-recovery/02-crash-journal.jsonl` 行 7/8

## 环境阻塞（优先于一切）

- **2026-08-02 晚 app 用户 proot 失效**：execve EPERM（11:45-17:23 窗口，KSU/SELinux 侧变化嫌疑）。**✅ 2026-08-05 已销**（P4 agent-14）：diagnostics.proot 实测 `classify:OK`（probe exit=0 + exec battery python3.12/git/bash/hermes 全过 + 无 avc denied execute，avc execute 全 granted）——**H1 自愈**，App 重装（新 uid 10394）+ rootfs 重建后恢复。证据：docs/device-acceptance/2026-08-05/p4-proot-diagnosis.md。遗留欠账：~~MCP 完整三连（需 token 方案）~~ **已销 2026-08-05 晚**（getServeToken 配置桥直取，initialize/tools 列表/审批闭环三连真机实证，05-mcp-p2-approval.md）；serve 完整调用链（需 AgentLoop 编排，deepseek 澄清阶段卡壳已知障碍）仍欠。
- **2026-08-01 晚 rootfs 被清**：app 的 files/linux/rootfs 整个缺失（**肇因时间窗纠正**：P6 实证 20:20 前已不存在，非 llmcpp 重编所致，更早原因待查）。**OCR 线已自愈**（MNN 3.6.1+Pillow 装进 /data/local/tmp/rootfs，特征生成/端到端复跑全通，验收人核 MNN+PIL import OK）——OCR 不再依赖 app rootfs。**未恢复**：app rootfs（hermes 终端子系统）——走 app UI：设置→Linux 环境→重装（用户操作；种子 ubuntu-base.tar.gz 384MB 在 /data/media/0/MOV/ 备查）。
- ~~2026-08-01 SSH 部署阻塞~~ **已解**（用户提供 mov.pem 密钥，免扫码；relay v2 已部署 + DV-11 过）
- 无（2026-07-31 10:15 平板网络已恢复，用户重启解决；真机自验挂起，待新构建装机）

## 待验收人处理

- 2026-08-04 本地因果记忆编译器 v1 交付 `75b9d37`（**feat/causal-memory 分支**，未 merge main）：记忆层从存文本升级为存逻辑规则（用户蓝图）——`causal` 引擎纯 Java 长在 journal（铁律③），四元组事件 + SHA-256 哈希索引（O(1) 匹配不存原文）+ IF...THEN 逻辑钩子（cooccur/subjectOf/dateAfter）+ 哈希链认知账本（篡改校验）+ 时间衰减遗忘（freshness exp(-0.1·Δ天)/7天 stale）。新增 5 事件类型、CausalToolProvider 5 工具（record/query/link/forget/rule，全局 room="global"）、BridgeKernel causal.* 5 查询、AgentLoop 冻结注入。**全量 849 tests 绿**（+变异反证 2 处）+ 分支自述 docs/causal-memory/README.md。**❌ 验收打回（2026-08-04 验收人定性）**：单测绿≠融合好——缺模型融合调试（①AgentLoop 注入段模型能否理解利用未验证 ②模型能否正确调 causal 工具未验证 ③文本→四元组抽取等 LoRA 是模型侧欠账）。**已修断点① `99d300d`**：causal 5 工具进 ESSENTIAL_TOOLS，compact 模式模型可见完整参数（融合前提），单测断言 prompt 含 record/rule 完整文档。**初步小实验·真机引擎链路实证 ✅（2026-08-04）**：`CausalSpikeCheck` 平板 21770d7d logcat 全通——1 钩子注册账本块 / 2 record 命中 r_debt+alert / 3 哈希索引原子3关联3 / 4 账本 verified=true 2 区块 / 5 手动关联 0.5 / 6 衰减 swept3+墓碑 / 7 清理后原子0 → LINK OK。**引擎链路真机验证通过；模型融合（注入理解度/工具调用准确率/文本抽取）仍欠账**（模型侧两档已登欠账区，用户暂缓）。

- 2026-08-03 MOV MCP 化 P1 交付 `230c1e0`：**8389/mcp 官方 SDK server 落地**（mcp/server 五类——MovMcpServer 生命周期+token+attach / AndroidHttpServer 纯 Java HTTP 帧层 / AndroidStreamableHttpTransport 实现官方 McpStreamableServerTransportProvider 接入 McpServer.sync / McpToolAdapter Tool↔McpSchema.Tool / RegistryProvider consolidate）+ 只读工具集暴露（access==readonly+checkFn 可用）+ buildRegistry 收敛（ToolManifest/MovInboundServer 删重复副本改调 RegistryProvider）。全量 **800 tests 绿**（0失败18跳过）+ assembleDebug 通过。注：SDK client 直连测试因 android.jar bootclasspath 无 java.net.http 编译不过，改原生 HTTP 帧覆盖协议全路径。**✅ 复核通过（2026-08-03 验收员）：initialize 握手 mov/3.3.0 + 无 token 401 + tools/list 59 只读工具（不含 file.write/device.cmd）+ tools/call file.list 执行/file.write Tool not found；变异亲杀 isReadonly 18 tests 1 failed 还原绿；结论入 ACCEPTANCE_LOG**。

- 2026-08-02 巡检 #61（P2 ToolRuntimeLimits 4950fad）：✅ 过——双超时（per-tool 30s cap + 5min 窗口+task_timeout 信封）diff 精读；7 单测实证绿；728+145 全量绿。已推远端。**P2 队列清零。**

- 2026-08-02 巡检 #60（P1 H2 件二 c797a25）：✅ 过——能力区块健康行真机实证（douyin 异常 HTTP 405/tencent 异常无 URL 带 reason+重测入口）。**H2 全关。** P1 队列空，待派（W2 P2 侧 ToolRuntimeLimits 待 P2；W4 已关）。

- 2026-08-02 巡检 #59（P2 H2 件一 7414172）：✅ 过——health 真值实证（douyin SOURCE_DOWN/tencent NOT_CONFIGURED 非假绿）。**件二（能力区块健康行）派 P1**（health 接口就绪，照 schema 渲染）。

- 2026-08-02 巡检 #58（P1 W4 b63f6c0）：✅ 过——冷启动实测 **first-frame 1061ms**（<1500 达标，logcat MOV-DIAG 实证）；回归套件 scenario drama 退出码 0（真卡）；**验收人顺手修**：scenario 子命令 `evalJs`→`ev` 拼写错误（未跑过就交付的实证，已修入库）。语音 STT 链路代码在案（9002 分支/_movStt 回调/bindMic 真实现），**真机人肉补验：按住 mic 说一句话**——用户 2026-08-02 实测通过 ✅（语音全关）。

- 2026-08-02 巡检 #57（P3 M5 安全验收 c9f5b51）：✅ 过——禁网真实证（LD_PRELOAD，Connection error/对照通）、sanitize 加固、产物拒收、401 亲跑。**Hermes 服务化 M1-M5 全部收官。** P3 练手首单通过。环境新案见阻塞区（app 用户 proot 失效）。

- 2026-08-02 巡检 #56（P6 40 页长文档 07e1792）：✅ **OCR 线全满贯**——归档工件亲验（KV 曲线 11264 封顶恒平/末段章节正确/403.8s 四指标）。另：**proot 环境回归**（17:23 起 execve EPERM+loader 失效，M5 真机禁网实证被卡）——待重启平板或查 P3 清理影响面。

- 2026-08-02 巡检 #55（P1 W2 侧 0f1dc4f）：✅ 过——页面层实证：`MovConnect.snapshot()` 返回 eid JSON（input「牛奶」eid:0/button「搜索」eid:1）、`getText` 返回正文；BrowserActionRouter KNOWN 8→10 + 注册 + prompt 引导在案；LLM 驱动全链挂起（计划路由不确定，首轮计划跑偏已驳回重排）。P2 侧 ToolRuntimeLimits 待 P2。**另：P3 M5（c9f5b51）与 P6 40页脚本（8630540）已交付待验。**

- 2026-08-02 巡检 #54（P6 钳制补测 4ad477c）：✅ 过——验收人 mutant 复杀实证（钳制失效 → curateLimitMutantKilled+curateRespectsDraftLimit 双红，17 tests 2 failed）→ 还原绿。**轻打回关闭，记忆三层彻底收官。**

- 2026-08-02 巡检 #53（P6 记忆 L3 2526655）：✅ **记忆三层全收官**（去重晋升/老化清理/长在 journal）+ 轻打回：CURATE_DRAFT_LIMIT 钳制无测试（mutant 存活），补一条 51 条草案只扫 50 的单测。

- 2026-08-02 巡检 #52（P1 漏网修复 acb4eff）：✅ 过——demo-badge=0/搞定啦绝迹/机票演示入口下线（首页只剩诚实入口：火车票真链路/京东真商品/追剧）；交付卡「完成·去查看」干净。**№8+W3 全关。**

- 2026-08-02 巡检 #51（P2 vault v1.1 3781c36）：✅ 过——GATE_BUSY 自愈真机实证（取消→再用成功）、钥匙轮换白盒 3 项。**保险柜全收官。**

- 2026-08-02 巡检 #47b（№8+W3 补查）：W3 火车票真链路 ✅（G532/G548 等真车次实证）；**但两处漏网打回**：①静态壳 hermes-shell.html:37/42/47 的 demo-badge 机票/牛奶演示卡还在（FLOWS 改了静态没改）②newface.js:93 faceDeliveryCard 仍「✨搞定啦」+整块 inline（№8 漏的交付卡变体）。修法到行号，见任务文档。

- 2026-08-02 巡检 #50（P6 Hermes 瘦身 963a37d）：✅ 过——四文件删净/死依赖移除/白名单部署实证（32→16）/M1 剧本复跑不回归（SSE done）。**阶段3 瘦身两刀完成**；LLM 收编+记忆统一（阶段3 后半）待排。

- 2026-08-02 巡检 #49（P6 记忆三层 L1+L2 bbc6e9f）：✅ 过——单行硬顶 mutant 亲杀（2 红还原绿）、抢救压缩律①在案、晋升修正①在案、长在 journal 无平行库。剩 L3 策展（下一幕）。

- 2026-08-02 巡检 #48（P2 拆包收官 1b7b14b）：✅ 过——根包 52→16 亲数、6 子包就位（capability/scene/browser/toolprovider/security+workflow 归位）、manifest 9 处 FQN 零改动、679+145 实测绿（批5/6 早经巡检#47 歪打正着验证）。**拆包 #1+#2 收官。** 注：P6 记忆三层 L1+L2（bbc6e9f）已交付待验。

- 2026-08-02 巡检 #47（P1 №8 回复呈现层 8a32e412）：✅ **六条全过**（答案卡干净/提问过滤/命令折叠/失败卡无未知原因/整数化/提炼层）。**拆包 6 批全部在 main 且全绿**（批5/6 经巡检#47 全量 679+145 验证）。

- 2026-08-02 巡检 #46（P6 三洞修复 aea2c2e）：✅ **环境地图闭环**——三洞全消（documents 诚实空态/search 命中 watch_history/系统区豁免文案）。P1 岔支提醒**误报更正**（验收人自查）：8a32e412 一直在 main 线性历史（深度 26），是我浅窗口误判，向 P1 致歉；教训：判「不在 main」必须 `merge-base origin/main` 而非看浅 log 窗口。

- 2026-08-02 巡检 #45（P6 环境地图 5b7cb5c）：机制✅（门禁/scan/map/vault 只名/救编译解封批34）——**数据质量 ❌ 打回三洞**：documents 快照混房间内部文件/env.search 搜不到 watch_history 与房间 journal（凡人修仙传实证 miss）//system 豁免显示「空目录」误导。修法见任务文档。

- 2026-08-02 巡检 #44（P1 №9 系统设置新脸化 b115e4d9）：✅ 过——Kernel 状态真值/桥门禁/原生页退役实证；安装闭环截图挂起（用户占用）。轻项：2936 inline 尾巴。

- 2026-08-02 巡检 #43（P2 件②修复 96627ce）：✅ 过——真机全链（起→60s 自动退出→拉起成功），zip 同步链断裂根因准确。**M4 三件全齐，服务化 M1-M4 收官。拆包窗口（#1+#2）条件满足，可开。**

- 2026-08-02 巡检 #42（P2 M4 韧性）：件①杀恢复✅、件③升级重装✅（0.2.0+pidfile 实证）——**件②空闲退出 ❌ 打回**：`cmd_mov_serve` handler 漏传 args.idle_timeout（main.py:13451-13454），60s 加速路径不可达，修法一行+补 CLI 接线测试。

- 2026-08-02 巡检 #41（P1 无感工作态 08f07912）：✅ 过——一行灰字/技能卡真实数据（⚡ shell.exec）/已思考折叠/存量种子白卡全实证，巡检#36 轻打回同关。**无感工作态落地**。

- 2026-08-02 巡检 #40（P6 llama-server+Kernel 对联 967fe8d）：✅ 过——桥门禁首单实证（grep 仅 2 接口）/懒启动 13.8s→常驻 READY/真实模型响应。模板成立。**P2 M4（5069182）交付待验，下一轮。**

- 2026-08-02 巡检 #39（P2 H1 工具健康）：✅ 过——验收人亲跑变异（删 mayi91 必红还原绿）；reason 透出链在案。H2（周期探测+能力区块）与 M4（韧性）均可派。

- 2026-08-02 巡检 #38（P2 M3 SSE）：✅ 过——curl -N 实证 progress→done 流（节流分块）+ 无任务 404 + 628 绿。daemon→UI <1s 计时挂起（自然命中补）。M4（韧性）可派。

- 2026-08-02 用户报障「看凡人修仙传一直思考」→ 验收人定位两 bug 并修复：① **注册表漏 mayi91**（isUsable 找不到 id 返回 false → 主力源从未被调用，全网搜索空转，986e8db 注册表化时漏配）② showDramaFailCard(f) 的 f 在 _continueSearch 作用域外（空结果时 ReferenceError，失败卡永远渲染不出=假卡死）。复验：「我要看凡人修仙传」出真实选项卡（凡人修仙传/重制版/抖音源）。

- 2026-08-02 巡检 #37（P2 Hermes serve M1-M2）：✅ 过——真机全链实证（healthz/鉴权 fail-closed/task done/cancelled）；抓两 bug 修一（writeModelConfig baseUrl `c0b7350` 验收人修），另一随行修正（rootfs 缺 ca-certificates 自检）。app 路径 logcat 计时挂起（自然命中时补）。

- 2026-08-02 巡检 #36（P1 №6 653d7e53）：✅ 过（思考面板单行化+老卡换新实证）+ **轻打回**：存量房间种子（修复前按 user_input 入 journal）仍黑泡，修法 replay 映射 actor≠user→note + [type:] 尾巴剥离。

- 2026-08-02 巡检 #35（P6 记忆探索 7eb11e2）：✅ 过（抽查 4/4 精确到行）。**「越用越聪明」官方答案**：半真——真的部分=策展记忆冻结快照注入+后台 review 偶尔写技能；假的部分=自动学习/学习图谱（纯可视化）。P6 三单（R-SWA/解剖/记忆）全部收官。

- 2026-08-02 巡检 #34（P6 解剖 b66cc2f）：✅ 过（抽查 3/3：batch_runner 零 import/tenacity 死依赖/glob 行号精确）。rootfs 已恢复（Ubuntu 24.04 就绪，用户确认）+ DeepSeek V4 Flash 已配活（testModel+房间任务推理流实证）。

- 2026-08-01/02 巡检 #33（P1 设置迁移+两小任务 ffc3bba2）：✅ 过（TOKEN 真数值/模型管理 UI/外观 dark 切换/grep 清零）。**验收人过失坦承**：P5 测试时全量卸载 app（偏离固定四步），MiMo 配置/观看历史/追剧记忆被清——用户需重新添加模型。思考条/任务卡弱化的真任务目检挂起（LLM 恢复后）。

- 2026-08-01 22:40 巡检 #32（P6 环境恢复）：OCR 线自愈核实过（MNN+PIL import OK，特征 12.7s、e2e 25s/13.7t·s 自报与已验指标一致）。肇因时间窗纠正入档。**P6 放行 40 页长文档验证**（-c ≥11264）。app rootfs 恢复走 app UI（用户）。

- 2026-08-01 22:20 交接：**P4 下线，P6 接任 OCR 线**（R-SWA 预研者，上下文最足）。接任队列：① 40 页长文档验证 ② ocr_accept.sh rootfs 路径修正+ocr-venv 重建 ③ llama-server 形态部署+ocrChat 对联（P5 集成前置）。

- 2026-08-01 22:10 巡检 #31（P4 R-SWA patch 5731004，独立复跑）：✅ **四指标全绿**——单页 31.3s（83.9→31.3）/ decode 14.0 t/s（2.7×）/ golden 380/380 逐字 / RSS 2.14GB；自报与实测一致到小数点。**OCR P2+P3 全部关门**。遗留：40 页长文档验证、rootfs 恢复（见环境阻塞）。

- 2026-08-01 21:40 用户报障三连处理：① 自动交接断链（预填不提交→要再点再输一遍）→ 验收人修（预填+800ms 自动提交建房开工，已实证进房发消息）② thinking.js 空指针（第三幕删 #think 致 agent 启动即崩）→ 验收人临时止血（null 守卫，思考条静默）③ **重复指令观感定性**：第二句=任务卡回显指令原文（非渲染重复）→ **派 P1**：任务卡不重复回显紧邻用户指令（或样式明确区分），思考条移植进专家视图（临时守卫换真件）。

- 2026-08-01 21:00 巡检 #30（P1 第三幕 fdea3b7）：✅ **三幕收官，专家模式全部搬进新脸，老视图清场完毕**——grep 清零亲证/长按 ops 归档实证 3→2/版本恢复/系统模型入口/欠账有名有姓。轻观察：opsBar inline display 尾巴+长按手感人肉补验。

- 2026-08-01 20:40 巡检 #29（P5 件一修复 b0cefbc）：✅ **四件全部过，双副本保险柜 v1 交付**——全流真机实证（lock→密文 grep 零泄漏→unlock 逐字还原）。随行修正两条下批：老钥匙轮换策略（install -r 残留旧 spec 钥匙）、GATE_BUSY 超时自愈。

- 2026-08-01 20:10 巡检 #28（P4 视觉集成 cc4109f，验收人全链独立复跑）：**三硬指标 ✅**（golden 380/380 逐字一致亲证 / RSS 2.14GB / decode 5.1t/s），第④项 83.9s ⚠️ 挂起等 R-SWA patch。发现移交：GGUF 元数据已带 sliding_window=128。**视觉集成主体验收过，P2 阶段关门**。证据入档 device-acceptance。

- 2026-08-02 P1 DESIGN_DISTILLATION 施工 `f5f56153`：提炼契约写入 AgentLoop 系统 prompt（专家侧）——CLARIFY_PROMPT 确认结构化（目标+验收标准两要素）、STEP_RULES 三维精炼（形态/侧重/深度自判不枚举）+ 诚实边界（缺数据明说/不确定项单列/禁「命令完成」当答案）。№8 已落结论先行+呈现层。652 tests 绿。K3 接进零额外活。**待验收**（同任务三种形态抽查 + 换模型行为一致）。

- 2026-08-02 P1 W3 交付 `f56e4ad2`（已推 origin/main）：场景扩展—演示卡下线 + 京东 shop_search 桥 + 12306 配置。SPIKE 诚实结论：12306 查询真链路已具备（待真机）；京东 H5 正向待真机 DOM；机票无真源下线 + 诚实提示；支付最后一厘米交人。FLOWS flight/shop 删、demo-badge 4 处移除、首页改火车票、startShopSearch 真卡、ShopSource 骨架 + Kernel shop_search + site_rules/PLATFORMS 12306。683 tests 绿。**待验收**（真机：火车票真车次/京东真商品/无演示角标/订机票诚实）。

- 2026-08-02 P1 派单№9 交付 `b115e4d9`：系统级设置新脸化（两层皮合一，原生页退役）——技术区块 6 卡（Linux/Hermes/MCP/SSH/诊断/重置，状态全真实）；Kernel 信封桥（query linuxStatus/hermesStatus/mcp.get + postCmd installLinux/installHermes/uninstallLinux/mcp.set/mcp.test/diagnostics.export/clear/resetSystem，不新增 @JavascriptInterface）；安装进度无感工作态轮询 1s；原生 HermesSettingsActivity 退役（manifest 删 + openAiSettings/B.openSettings 删 + grep 清零）。652 tests 绿 + linuxStateText/sysProgressText node 断言。**待验收**（安装全流程新脸内闭环/6 卡状态真实/MCP 保存生效/诊断导出/重置两步/原生页入口消失）。

- 2026-08-02 P1 派单№8 交付 `8a32e412`：AI 回复呈现层清理（六条+提炼层）——答案卡干净（去✨搞定啦/·N步·Ns，summary 提炼结论 prose，元数据下沿小灰字）；提问卡内容修复（占位符/空 question 过滤，Java ask_user 空跳过）；计划卡命令折叠+删预估 tokens；失败卡诚实化（未知原因永禁）；「已思考 250 秒」整数化；提炼层（finish prompt 结论先行 + extractConclusion 兜底）。652 tests 绿 + thinkLine 整数/extractConclusion node 断言 + mov-render inline 清零。**待验收**（同任务前后截图：答案首行=结论/提问真实/命令折叠/无未知原因）。

- 2026-08-02 P1 派单№7 交付 `08f07912`：无感工作态（Kimi PC 参照）——思考面板一行态（idle 隐藏/running「思考中…」无 tok·波形·大标题/done「已思考 N 秒 ›」收起可展开）；技能调用卡（Java AgentLoop emit tool_call + BridgeAi 补 name/arg，mov-render ⚡技能名·调用中→完成·结果摘要，数据真实）；消灭清单 grep 证据（THINKING/tok/波形 JS 无残留）；轻打回（存量种子 replay 白卡）。636 tests 绿 + thinkLine/toolStatusText node 断言。**待验收**（真机截图逐项：一行灰字/技能卡/已思考收起/存量白卡）。

- 2026-08-02 P1 派单№6 交付 `653d7e53`：房间会话视觉对齐 mockup 屏②——思考面板空闲单行 bar/运行≤35vh、种子消息 AI 白卡（chat.js 映射 note/brain）、plan 卡(失败/提问/暂停) paper 化 + fail 红边/paused 蓝边、deliver-line paper 化、taskbar done 类、thinkTps inline 清零。610 tests 绿 + thinkPanelMode node 断言。**待验收**（同房间改造前后截图对照）。

- 2026-08-02 P1 派单№5 交付 `ffc3bba2`：老脸设置迁移（TOKEN/模型管理/外观/终端迁新脸抽屉，view-run 清场）+ 两小任务（任务卡回显去重「📌目标」/思考条移植 attach）。610 tests 绿 + node 断言全过 + grep 清零。**待验收**（抽屉逐项截图/思考条 token 流/任务卡不重复回显）。

- 2026-08-01 18:10 巡检 #27（P5 四件，L3）：件二闸 ✅（无锁屏诚实降级+PIN 弹闸实证）、件四 ✅（bridge+隐私区块）、件三 diff 过——**件一 ❌ 打回**：KeystoreCrypto 缺 `setRandomizedEncryptionRequired(false)`，AndroidKeyStore 拒调用方 IV，生产加密必败（JCEKS 白盒测不出，4b 判例重演）。修法一行级，复验 vaultLock 全流。

- 2026-08-01 17:55 巡检 #26（P6 R-SWA 预研 a609048）：✅ 过——源码引用抽查 3/3 对得上（kv-cache:231/hparams:386/kv-cache:1150），改动点 8 项落文件:函数可施工。**移交 P4**：R-SWA patch 按 §二清单施工（直接解 decode 0.7t/s 阻塞）。

- 2026-08-01 17:40 巡检 #25（P1 第二幕 98e4f9a）：✅ 过（运行页真实统计/文件页版本徽章/预览 overlay/保险柜路由到 P5 真实功能）。挂起观察：运行中任务卡「可中断可续+停止」需一次真任务截图。**第三幕放行**（撤 bnav+老视图清场）。

- 2026-08-01 17:20 巡检 #24（P4 embd 进展 8b81e71）：prefill 15.6-19.7 t/s ✅（注入路径成立）。阻塞转移：decode 0.7 t/s@400KV + ə 退化。定夺排序：**①退化先修（ngram 全启用+golden1 对照，正确性>速度）②快赢矩阵（-fa/线程/KV 量化 1h 零代码）③R-SWA 升关键路径与 P6 合流（P6 出改动点 P4 施工）④Vulkan 垫底**。详见 OCR_DECODER_MNN §17。

- 2026-08-01 17:00 巡检 #23b（P1 轻打回 bb8fe38）：✅ 关闭——CDP 实证 utter 即时渲染+去重（shown:true count:1）。**第二幕放行**（运行/文件页，mockup 屏③④）。

- 2026-08-01 16:50 巡检 #23（P4 embd 阻塞 eb65067）：定性 **273 embd 被当 273 次独立 decode**（2.3s/embd × 273 ≈ 650s 严丝合缝）。执行令：①审 vision_infer.cpp batch 构造（最优先，九成在这）→ ②换 llama.cpp 版本 → ③graph 解剖；Vulkan 暂不碰。EMB 一批 ≤60s 才算过。

- 2026-08-01 16:35 巡检 #22（P1 专家新脸化第一幕 88e1507）：✅ 过（切换/预填/列表/会话/发送全流 CDP 实证）+ **轻打回**：发送后自己的 utter 不即时渲染（重进才现，修法乐观渲染+按 event id 去重）。执行 ✗ 为 LLM 环境侧非视图层。第二幕开工前先修轻打回。

- 2026-08-01 16:20 巡检 #21（P1 修复 8c1bc57）：**第三幕 ✅ 正式过**——screen 触发器探针正反两例实证（screen_off→FAIL / screen_on→PASS）。巡检#20 误判纠错留档：MIUI 充电事件自动亮屏干扰了 power 探针场景，8c1bc57 修复本就成立。随行小修正（一行）：is_charging 加 EXTRA_PLUGGED!=0 合取（本机拔电 status 残留 CHARGING）。**workflows 扩展包四幕全部收官**，P1 进专家模式新脸化。

- 2026-08-01 16:10 巡检 #20（P1 修复 a725976）：❌ **三次打回**——拉取式架构✓（现查/解耦/充电网络字段实测正确），但 `PowerManager.isInteractive()` 在 MIUI 屏灭仍 true（DSREAD 埋点实证：Asleep + Display OFF 时 so=true）。修法一行级：screenOn 改 DisplayManager `getState() != STATE_OFF`（真机实证 OFF/ON 一致）。复验：灭屏插电必须 FAIL。临时埋点已还原未入库。

- 2026-08-01 15:45 巡检 #19（P1 第三幕修复 2ada580）：❌ **二次打回**——回填写在家族 receiver 里，而 receiver 按触发器家族按需注册；条件要的数据与触发器家族无关（探针 power 触发器 → SCREEN/BATTERY 族从未注册 → 亮屏 screen_is_on 仍 FAIL）。修法写死：拉取式 DeviceStateReader（粘性广播/PowerManager/ConnectivityManager 现查，与注册解耦），测试必须覆盖拉取路径。复验要「数据与家族无关」实证。

- 2026-08-01 15:40 巡检 #18（P4 GGUF 验证点 bafa676）：**步骤 1-2 ✅ 过**——GGUF 三档字节级核对、二进制真跑、Hello→World! 连贯、实测 Prompt 6.2 t/s / Generation 5.2 t/s（自报 7.0 有出入以实测为准）。**新风险**：prefill 45s/页成新瓶颈，步骤 3 验收加第四条「单页总时长 ≤60s」（详见 OCR_DECODER_MNN §12）。

- 2026-08-01 14:50 巡检 #17（P1 第三幕+S1 接线）：fuzzyScore 清欠✅、S1 方案二接线✅、变异测试杀 mutant✅、720 tests 绿——**第三幕 ❌ 打回（主）**：9 条件真机全死（Snapshot 扩展字段零接线，WorkflowEventSource.snapshot() 旧构造；亮屏 screen_is_on 仍 FAIL 实证）。修法已写任务文档（setDeviceSnapshot 回填 + lastRunAt 取 lastFireAt），复验要真机正反两例。S1 修复 ✅、fuzzyScore 清欠 ✅ 不受打回影响。

- 2026-08-01 14:15 巡检 #16（P1 大批：第二幕+OCR 五件，L2/L3）：**第二幕 ✅**（cron/manual 真机实证）+ **OCR 五件 ✅**（设置页条目/诚实卡/PII mutant 杀除）——S1 附**轻打回**：wrapOcrText 无调用点，P4 对接前必修（修法见 OCR_PREP 验收结论）。707 tests 实测绿。第三幕（条件扩展+清欠）继续。

- 2026-08-01 12:40 巡检 #15（P1 #2 第〇+一幕，L2/L3）：**修复1 ✅ 全链过**（scroll 5ms/submit SUCCESS 落账/cooldown 生效/已搜：牛奶）+ **触发器族 ✅**（按需注册实证、screen/power/battery 真触发、零启用零常驻）；变异测试杀 planner mutant；670 tests 实测绿。第二/三幕继续。详见 TASKS_P1_WF_EXPAND 验收结论。

- 2026-08-01 12:00 用户定位修订（已录 DESIGN_OCR_MOBILE.md）：**OCR = 隐私通道不是体验主线**（API 直连=体验主线 / API 精修=体验增强 / 本地 OCR=无 API 可取且不能出端的数据）。OCR 移植继续但卸下主体验压力；云端加速 OCR 方案（云 prefill/投机采样）作废，云端定位=通用 API 精修。

- 2026-08-01 11:20 巡检 #14（OCR 方法1结果 8befb00）：双路被堵证据核实通过（mnnquant 平台级损坏 + weightQuantBits 反涨）。**批准转方法 3 llama.cpp，跳方法 2 理由已录**（MNN 无稀疏 MoE，数日投入也不解 87min/图）。连续读文档可行性判据写死 tok/s≥5。执行令见 OCR_DECODER_MNN.md §11。

- 2026-08-01 10:50 巡检 #13（OCR 探针 1c004e2）：失败证据链核实通过（llmexport 无 deepseek-v2 + moe_infer 不可导出，两路径撞同墙）。**用户拍板走 a) P4 真 int8 内核**，执行要求写 OCR_DECODER_MNN.md §9（先 1 片验证点：RSS+diff 双达标才全量，i8sdot 要实证；验证点 ≤半天，挂→方法栈下一项（ggml/NNAPI）；**用户终裁：方案 b 永久下架，模型不换云不议**）。

- 2026-08-01 10:20 巡检 #12（P2/OCR 状态报告 ce14ce6，L1）：状态属实（655 tests 绿、OCR 边界内、内存墙论证链完整）。**定夺：投 MNN-LLM int4（方案 1），先 ≤2h llmexport 架构兼容探针再全量**；方案 2 只配当 golden 对照不批主路径（87min/图不可用）；探针挂→fallback P4 真 int8→产品级重新选型（拉用户）。P3(R-SWA) 维持挂起。详见 OCR_DECODER_MNN.md §7。

- 2026-08-01 09:30 巡检 #11（P1 #0 两幕，L3）：修复2 落账 ✅（变异测试杀 mutant + 真机 no_effect 实证）；**修复1 ❌ 打回**——根因实锤两条（scroll 等非写类型 executeBrowserAction 无分支静默丢弃 / submit 导航丢回调恒 TIMEOUT），精确修法已写任务文档；第二幕端侧 ✅、schema 修正 ✅；655 tests 实测全绿与自报一致。relay server.py v2 就绪（本地 10 场景全过），部署被 SSH 微信扫码阻塞（见环境阻塞）。

- 2026-08-01 08:40 巡检 #10：**DV-10 真机终验 ✅ 过**（全链 evidence + text_match 探针正路径，见 DEVICE_ACCEPTANCE.md DV-10 记录）；打回轻项两条转 P1（cbId 回调不投递/动作白等 10s；FIRED 落账先于副作用）。**职业注册表 schema 505e390 审过**，两条修正（craft 枚举不一致 8 vs 11、迁移执行方未定）已写 DESIGN_GIG_REGISTRY.md，P1 先修文档再开工实现。期间定位：v2/v3 跑中对话框消失系平板前有人手动点掉（MotionEvent 实证），非 bug。

- 2026-07-31 09:20 巡检：b43d0bc/a2369d7（W1 第一幕）部分验收过，打回轻项（单测缺失）已写 TASKS_P1_DISH_FIRST 末尾；814 tests 全绿；真机部分被环境阻塞
- 2026-07-31 09:45 巡检 #2：无新代码 commit（HEAD=a2369d7 已验）。卫生提醒：docs/ 下验收人设计文档（DESIGN_A2A/DESIGN_BROWSER_PROTOCOL/DESIGN_VIDEO_LIBRARY/PHASE3B笔记/ACCEPTANCE_PLAYBOOK 等）积压未提交，P1 或 P2 顺手批量 commit：`docs: 设计文档批量入档—A2A/浏览器协议/视频库/支付闸笔记/验收手册`
- 2026-07-31 10:15 巡检 #3：无新代码 commit（HEAD=a2369d7 已验）。P1 第二幕（随机抽评）进行中；P2/P3 队列待认领；平板网络已恢复（用户重启解决），商家已迁服务器常驻（mov-merchant-a/b）
- 2026-07-31 10:55 巡检 #4：无新代码 commit。期间验收人完成基建：relay TLS 上线（https://mow.kim，Caddy+Let's Encrypt 自动续期，relay 移 8080）；遗留：www.mow.kim A 记录（用户补）、P2 队列加 BASE_URL 迁移 https 一项
- 2026-07-31 11:15 巡检 #5：无新代码 commit（HEAD=a2369d7 已验）。期间验收人完成：官网 mow.kim 上线（site/index.html，Live 状态+两店徽章，/healthz 分流正常）。战略节奏已定：审核窗口期三线推进（服务商方案/W2/验收扩容）
- 2026-07-31 11:45 巡检 #6：无新代码 commit。期间验收人完成：蚂蚁影视本机接入（个人源不上架，注册表+反跳规则）+ 任务 G 派单（蚂蚁搜索适配器，搜索 URL/解析规格已实测备好，在 TASKS_P1_DRAMA_UX 末尾）；定位平板代理为 mow.kim/蚂蚁打不开根因（已临时清，WiFi 重连会回写，待用户白名单）
- 2026-07-31 12:15 巡检 #7：无新代码 commit（HEAD=a2369d7 已验）。P1 有任务积压：fuzzyScore 单测、任务 G（蚂蚁适配器）、第二幕（随机抽评）；P2/P3 队列待认领
- 2026-07-31 13:20 巡检 #8：无新 commit。注意：任务 G（蚂蚁适配器+ConnectWeb 路由）验收人已全链修通并真机验证（v37-final2 截图），但**代码仍在工作区未提交**（bridge.js/newface.js/DramaSource.java/BridgeDevice/BridgeFactory 五处）——等 P1 commit：`feat(DramaSource): 蚂蚁影视搜索适配+ConnectWeb内嵌详情页—任务G`，附带 polish：来源显示「蚂蚁影视」非 mayi91、海报加载
- 2026-07-31 13:45 巡检 #9：无新 commit，任务 G 五处改动仍待 P1 提交（第二次提醒）

## P1 交付记录（2026-07-31 下午 ~ 2026-08-01）

> 按 TASKBOARD 规则 2：完成写 hash + 一句话交付说明。真机自验清单挂起（平板装新构建后执行）。

| 交付 | commit | 说明 |
|---|---|---|
| 任务 G 遗留 + docs 批量入档 | `f7e14b4` | 蚂蚁影视搜索适配（DramaSource/MayiParser）+ 设计文档入档 |
| 官网 mow.kim | `a6ae4f5` | Live 状态 + 两店徽章 + /healthz 分流 |
| 三件打回修复 | `18f513c` | 音乐错误区分 / LLM 意图路由（intent 字段）/ 平行注册表合并（FastSceneProvider 8 场景卡）——440 tests 全绿 |
| F3 记忆收编 | `1574da0` | MemoryToolProvider（watch_history/drama_memory/face_history/face_mine）446 tests |
| F4 意图层 | `1715a0f` | intentPromptText 喂 LLM 意图层，448 tests |
| 正确性四修 | `2427c7e` | volatile/fastRegistry 刷新/机票防误路由（newface-router 纯函数+node 回归）/intent 白名单 |
| 缓存两修 | `d560206` | tool_manifest 响应缓存 + VideoSourceRegistry 实例缓存 |
| 设置页重组 ① | `5832f38` | 折叠树骨架 + 连接区并入 + 场景卡区块（大脑/连接/场景卡/技术） |
| 设置页重组 ② | `0e7ba74` | 能力区块（tool_manifest 驱动 + checkFn）+ 隐私强化（查看/清空） |
| F6 晋升统计 | `6547048` | ToolStats journal 工具频次，453 tests |
| F5 结果回脸 | `e6aaa2d` | newface 监听 deliver → 交付卡回流，453 tests |
| workflows 5+5 v1 | `be9c4b2` | 纯 JVM 引擎（5 触发器+5 条件），29 单测 |
| workflows ConnectWeb 接入 | `cf7135d` | 页面事件源（PAGE_LOAD/URL_CHANGE/TICK）+ 浏览器动作执行 |
| element/text 检测 | `7160d27` | 2s 轮询检测 JS → MovWfReport → 引擎 |
| 条件快照 v2 | `e5ff611` | element/text 条件用页面真实快照 |
| 演示 workflow 入仓 | `cd20134` | browser.open 工具 + 种子（初版京东） |
| 两步链演示 | `5f67739` | 京东首页→open 搜索页→input（反爬后发现） |
| 埋点+种子升级 | `e2e69cb` | 全链路 log（tag Workflow）+ seedVersion 合并更新 |
| DV-10 改道+静默catch | `8d0fc29` | 自家演示店 demo_shop_search + 静默 catch 全修 |
| DV-10 线程修复 | `33d3431` | report JavaBridge 线程 WebView API → lastPageUrl 缓存（最后一环） |
| 职业注册表 schema 草案 | `505e390` | relay devices 表扩展（role/professions）+ 迁移路径，待审 |
| DV-10 线程死锁修复 | `d01d87d` | 事件 fire 切后台线程，动作不再白等 10s |
| FIRED 落账时机 | `2eb7125` | ActionExecutor 返回回执，只在真实执行时落账（mutant 防护） |
| schema 两条修正 | `4b70c87` | craft 11 项统一 + 迁移执行方选 a 端侧上报 |
| 职业注册表端侧 | `89cf2cf` | role/professions 注册 + query_pro 发现（A2aClientPayloadTest 7） |

**FUSION 主线（F1-F6）收官**。设置页重组两 commit 完成。**workflows 5+5 全闭环**，DV-10 真机终验 ✅（2026-08-01）。

**当前队列**：① P1 修 DV-10 打回轻项两条（cbId 回调投递 + FIRED 落账时机，见 DEVICE_ACCEPTANCE.md DV-10 记录）② 职业注册表实现（schema `505e390` 已审过；**先把 DESIGN_GIG_REGISTRY 两条修正改进文档**：craft 枚举统一为分类表 11 项、迁移执行方写死二选一，然后开工：relay devices 扩展 + 端侧 A2aClient 注册扩展 + query_pro 发现）③ workflows 扩展包（14 触发器+9 条件）

## 欠账登记（用户已批，后续幕补）

> 第三幕清场（撤老底导航+删老视图 DOM）按用户口径「核心补齐+次要接受」接受的功能缺口，**不许悄悄丢**。原代码在 git 历史有底。

| 欠账 | 说明 | 原位置（git 历史） |
|---|---|---|
| 多选删房 | 房间列表多选批量删除 | app-room.js `enterSelMode`/`toggleRoomSel`/`selConfirmOk` |
| 新建文件 sheet | 手动创建文件（fileNewSheet） | app-files.js `openFileNewSheet`/`btnFileNewCreate` |
| inbox+archive 文件区 | 文件页「产出/资料/归档」三区浏览 | files.js `renderStorageView`/`renderInboxFiles`/`renderArchiveFiles` |
| **因果记忆·模型融合（近档）** | 文本→四元组自动抽取：DeepSeek 把原文/OCR 文本结构化 → `causal.record` 前置抽取器（当前 v1 靠显式写入绕过模型，验收打回缺口③）。量级：1 小任务（半日）。**优先级用户已定：暂缓，先做其他** | 分支 `feat/causal-memory`（引擎 `75b9d37` 已交付未 merge；抽取桥接入点为 CausalToolProvider/causal.record 前置） |
| **因果记忆·模型融合（远档）** | 图文合一 3B 模型：Unlimited-OCR + LocateAnything 三阶段融合（视觉塔统一蒸馏→解码器统一 LoRA 路由→20 万坐标标注数据对齐）。重模型训练工程，依赖云租 GPU（ms-swift LoRA，OCR-finetune 链）+ 数据标注投入，按周~月计。**优先级用户已定：暂缓，先做其他** | 蓝图 §4（对话归档）；`OCR-finetune` 微调链（记忆 `project_ocr_finetune`）；v1 自述 docs/causal-memory/README.md「v2 方向」 |

## 工单10-13 登记（2026-08-06，新阶段 MOV实现计划.md）

| 工单 | 内容 | 状态 |
|---|---|---|
| 10 | root 工具层（RootShell + UI 三件套 + 红线黑名单 + DANGEROUS 闸） | ✅ `a52c048`（红线黑名单验收员亲杀恒放行→双红→还原绿；微信真机拒启在案，设备控制升格「能操作」） |
| 11 | kimi-code MCP 握手（欠账解法） | ✅ `b8f6bdb`（`.mcp.json` 加 `type:"http"` → 会话 tools/list 见 MOV 工具；memory.cover 真调 kimi-code 走脚本化，记欠账待手写 MCP client 补实证） |
| 12 | 健身竖闭环 v0.1（四幕：OCR 入账→周叙事→新脸视图→真机+PII） | 🔨 幕一/幕二 MOV 侧 ✅ `4830742`（fitnessIngest 落 fitness 域 + weeklyNarrativePrompt/serve 周叙事端点，验收员变异亲杀过）；**幕三/幕四移交新会话**（新脸健身卡视图 + OCR 真实识别依赖 llama-server 就绪 + 全链真机） |
| 13 | 上线无聊工程小包（新人 10 分钟路径/崩溃恢复/分发/升级不丢数据） | ✅ `37f9ae7`（新人路径：4 缺陷修复——报错透传/编辑保 key/保默认大脑/空 key 拦截）+ `c150acb`（崩溃恢复：状态如实「已中断」）+ `4ac1e01`（升级回归单+抽验）+ `RELEASE_PROCESS.md`（分发规范，未执行上传） |

## 工单14+ 登记（2026-08-07 起，查验员派单制：查验员出计划/验收，程序员施工）

| 工单 | 内容 | 状态 |
|---|---|---|
| 14 | 设置页用户视角重做（IA 重排+术语清零+二级页，DeepSeek 式；设计已定稿） | ✅ `dbab066` 复核通过 + 轻打回已修 `97ee9fa` 关闭（1805 残留文案改「设置 → 高级 → 设备协作」，grep 零残留亲验） |
| 15 | 孤儿房间目录对账清理（e8f6409 前专家模式删房不删磁盘的历史残留） | ✅ `054a204` 复核通过（orphanRooms 对账 + rooms.orphan/cleanup 桥；查验员真机实测探针检出→清理→磁盘消失，2210 tests 绿；遗留：清理入口 UI 并入工单14 幕二「系统」页） |
| 16 | onboarding 文档两处订正（adb 真路径 + 「改 assets 重进即生效」错误说法） | ✅ `77be6fc` 复核通过（路径与本机实证一致 + assets 订正准确 + CDP 复验手法入 playbook §2） |
| — | 左侧栏对话历史删除（报障三连修） | ✅ `106f5e1`+`7ec0ca7`+`e8f6409`（overlay 懒建/抽屉遮挡/room_destroy 不落盘三层根因；真机 CDP 端到端实证列表 8→7+目录消失，2208 tests 绿） |
| 17 | 首页对话连续性（视觉断/进程断/任务断三断点；决策已定：同会话连续派活同房） | ✅ `3fb86d7` 主体过 + 打回②已修 `74445ee` 关闭（currentWatchingContext 注入 watch_history 当前在看条目，diff 精读在案） |
| 18 | 去「专家模式」割裂感文案（11 处用户可见文案替换表；叙事切换：一个产品我们分配任务） | ✅ `a0246e2` 复核通过（用户可见串 grep 零命中亲验；真机顶栏「任 务」/「返 回 首 页」在案） |
| 19 | 交付卡「去查看」去模式跳转（首页顶部入口；新脸内展开交付物，不切专家面板） | ✅ `a0246e2`+打回③修复 `eba0535` 复核通过（showExpertPane 公共序列；查验员真机亲点历史条目进房三要素齐+房内真发消息闭环截图在案）——**批次1 全关** |
| 20 | Linux+Hermes 合并工具化（hermes.task：开放子任务进 Linux 自主完成，产物回房） | ✅ `3e98af9`+打回④修复 `b792bb6` 复核通过（ESSENTIAL 一行+单测变异+真机 goal 非空落房；token 脱敏+轮换查验员亲手复验旧拒新通；2238 绿）——**工单14-20 全关** |
| 22 | 记忆层收官=**果因引擎 1.0**（因果正向+果因逆向+融合链） | ✅ `17539117`+`123f79d1`+`38c09c85` 复核通过（四幕真机证据链 + Journal 收敛并发用例 + 评测机制查验员亲跑亲杀；2280 绿）——**记忆层达成** |
| 23 | CodeGraph 轻量版（改前影响分析） | ✅ `0a0f2199` 复核通过（查验员亲跑三查询判分全中+0.6s 建索引+自测变异在案；顺手抓出 streamAppend 死代码） |
| 24 | 资产转化层（对话→技能提炼环：提炼器防角色捕获三件套 + 候选确认入库 + 高值升级工厂产线；Wiki 后置笔记支柱） | 🔨 已交付 `0f97001f`（幕一提炼环+升级通道，真机七环节实证，交付说明 docs/DELIVERY_TICKET24_ASSET_FORGE_2026-08-08.md），**待验收** |
| 21 | MCP 工厂（带质检的工具生产线） | ✅ `200862cd`+`2cfd6cf7` 复核通过（首品种 pb.* 五件出厂：8389 真实调用/坏拒收好出厂/组合合成+调用，查验员六条逐项亲验，2298 绿）——**产线闭环成立** |
| 25 | MCP 市场 幕一（能逛不能买：多 server 地基 McpServerStore/McpProvider + 市场页 v2 + 本地页 + 货架 6 件） | ✅ 复核通过（查验员 2026-08-09：全量 1216×2 亲跑绿 + 20 commit diff 审查——派单内/红线守住/测试无假覆盖/E 系列修复正确；打回 P1 mcp.test 契约断裂合并轮顺手修） |
| 26 | MCP 市场 幕二+幕三（付费全链：微信支付 Native 下单/查单 + Intent 直跳微信支付 + A2A 加密发货 + 买家解密安装；出口=0.01 元真单全链证据链） | ✅ 代码侧复核通过（同上审查结论「可合并但待真单」）。**挂账**：① 0.01 元真单八段证据链（待用户配合）② 货架其余 6 件接真 Shelf 或标「即将上架」（现点购买必 PRODUCT_NOT_FOUND）③ OrderStore journal 滚动 snapshot 重建 |
| — | 职业体系架构选型定稿（MCP or 内置平台） | ✅ 设计定稿 `docs/DESIGN_GIG_PLATFORM.md`（2026-08-09 用户拍板）：**内置底座（续建 GIG v3 G1-G4）+ MCP 出口薄层（G5: gig.* 四件）+ 官方插件面孔**三层；纯 MCP 方案否决；入口定稿=账户管理二级页加「我的职业」（多工种叠加/接单中状态上行显/收款码端侧持），buyer 侧无新入口走对话卡片；G5 建议 G1 后并行 |
| 27 | 微信支付服务商特约商户进件 M1（资料收集+后端进件：账户管理→身份认证→六步表单；partner-server 持私钥部署 mow.kim/partner/*） | ✅ `e057a6df`+打回修复 `ae795afb` 复核通过（查验员逐项亲验：decodePath 零残留/图片必填 addImg 全纳入/mask 全 esc/sales_info 前缀/1171×2 绿；后端真密钥签名链路 curl 实证）。**后续**：真机端到端填单 → applyment_id（需公钥ID已填+平板操作） |
| 28 | **语义召回层**（端侧 embedding 增强 Journal.search，方案 B：子串命中≥K 保底 + <K 补最近窗口语义；M1-M4） | docs/PLAN_SEMANTIC_RECALL_2026-08-09.md | ✅ **M4 端到端通过**（M1-M3 `a7b23287` + M4 `05d3bef6`）：8388 E2E 正例「睡眠不足」命中「凌晨三点才睡」/反例「中午吃了什么」滤掉/8081 embedding 证据链；阈值实测调参 0.5→0.4；报告 docs/device-acceptance/2026-08-10/m4-semantic-recall.md。**待合并 main** |
| 29 | **memory.search 工具 arg 空**（agent 调记忆检索不传查询词 → 工具对模型形同虚设；定性：工具 desc/schema 未教 agent 传 query / 参数名不匹配，优先级高于 M4 收尾） | 真机发现 docs/device-acceptance/2026-08-10/m4-semantic-recall.md §五 | 🔴 新立（待派） |

> **17-20 合并派单包（2026-08-07 查验员整理）**：`docs/PACKAGE_TICKETS_17-20_2026-08-07.md`——批次1 叙事统一包（19→18→17打回②→顺手①room_destroy 竞态/②失败文案笼统）+ 批次2 Hermes 工具化（20），两批无文件冲突可并行。

> **移交标注（2026-08-06）**：今日工作线收尾——批1 记忆层 G1-G10 全清 → 宿主化（Kimi 入驻 + MCP 握手）→ root 工具层。工单12/13 新会话续。待办：① 用户查平板联网控制（疑 MIUI 按 uid 封网）② 健身竖闭环开工（新会话）。

## 变更日志

- 2026-07-31 验收人建板 v1：人肉信使模式终结，仓库即消息总线
- 2026-07-31 验收人改 v2：AI 刻度队列制（用户指示：AI 程序员不按人类工作量计算）
- 2026-08-01 P1 程序员回写 v3：**派单体系统一**——唯一权威队列 = 本板 P1/P2/P3；ONBOARD 分工表仅声明文件边界（P1 主线/P4 OCR），不派单；EVAL 仅评估不派单。设计文档需带「状态位」，做完回写（见 STATUS.md 同步更新）
- 2026-08-09 查验员 hash 订正：分支 rebase 致 7 项板载 hash 失效（非内容缺失），已全局订正为 main 实际 hash——№9 b115e4d9 / №8 8a32e412 / №7 08f07912 / №6 653d7e53 / №5 ffc3bba2 / W3 f56e4ad2 / DISTILLATION f5f56153（is-ancestor 逐项亲验）。8 项代码均在 main，真机行为截图验收仍挂查验员队列。
- 2026-08-09 查验员：feat/mcp-market 验收合并——20 commit diff 审查「可合并但待真单」+ 全量 1232×2 亲跑绿 → merge `544797ba`（解 newface.js/TASKBOARD 冲突 + 账户页语义冲突：MovApplyment 版为主+补商户收款行；顺手修打回 P1 mcp.test 按 id 查 store / P3 PollGuard 防双轮询链 / P4 凭证缺失转 MANUAL，新增 PollGuardTest 4 用例）。分支已删（本地+远端）。挂账：0.01 真单八段证据链 / 货架 6 件接真 Shelf / OrderStore snapshot 重建。
- 2026-08-10 查验员：工单26 E-14 定案——「去支付」Native 直跳不可行（weixin://bizpayurl adb 直发实测微信无响应）；产品池实测 Native✅/JSAPI✅/App支付❌(403 NO_AUTH)。E-14 修订 = **「去支付」改 JSAPI 链路**（微信内 H5 chooseWXPay），Native 留扫码兜底。材料全齐：商户四证✅ JSAPI权限✅ appsecret（access_token+jsapi_ticket 已实证）✅ MP_verify 校验文件✅（待部署 mow.kim 根路径）。待建设：mow.kim /pay 承载页（授权跳转→openid→JSAPI下单→chooseWXPay）+ MOV mktGoPay 改拉起微信打开支付页。待用户：公众号后台配「网页授权域名=mow.kim」。
- 2026-08-10 查验员：用户拍板「JSAPI 体验不满足」——E-14 JSAPI 链路建成即退役为降级通道，转向 **E-15 App 支付唤起（OpenSDK 一键直达）**，派单 docs/TASKS_P1_MCP_MARKET_E15_APP_PAY_2026-08-10.md。并行：用户开放平台创建移动应用（1-3 工作日审核）+ 商户平台开通 App支付；程序员预建（下单/二次签名/唤起/通道可配），开通后真机验收出口=微信输密码页直出。另：E-14 首跑抓到惰性建单 ORDER_NOT_EXIST 误杀订单 bug 已修（isWaitingBuyer + 单测）。
- 2026-08-10 用户拍板·阶段3 六项烂尾裁决（正式化）：①健身竖闭环幕三/幕四=**砍**（OCR 入账/周叙事已通部分保留）②场景扩展真链路=**搁置**③追剧卡内嵌播放=**搁置**④OCR R-SWA=**实现**（结束阻塞态，待派单：读 docs/OCR_RSWA_ANALYSIS.md + OCR_DECODER_MNN.md §9-19，含 40 页长文档验证）⑤因果记忆·模型融合近/远档=**搁置**（重启条件：近档=DeepSeek 抽取器立项；远档=GPU/数据投入立项）⑥平板联网控制=用户本人查证后销账
- 2026-08-10 查验员：feat/semantic-recall 验收合并 `c22e3c96`（M4 端到端通过 `05d3bef6` + 阈值实测调参 0.5→0.4 有实测依据 + 全量 1268×2 亲跑绿），分支已删。**新欠账入板**：serve/MCP token 分发通道——getServeToken 桥缺失时连自家验收都拿不到 token（M4 实证痛点），需补 token 获取桥/文档。平板手动 8081 进程已清理（pkill 实证）。
