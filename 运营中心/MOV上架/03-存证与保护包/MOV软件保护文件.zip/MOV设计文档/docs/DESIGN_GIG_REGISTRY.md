# DESIGN：职业注册表 schema（GIG v3 底座）— 2026-08-01（✅ 审过，两条修正先行）

> 定位：职业注册表 = **relay devices 表扩展**（唯一底座），不建新模块。商家/运力/手艺都是职业人。
> 统一公式：**职业人 = 身份 + 工种 + 服务形态 + 收款码 + 行为档案**。商家 = 工种为「卖货」的职业人。
> 施工衔接：DV-10 引擎修复 → 本 schema 落地 → Marketplace M1 / Gig G1 都从注册表取数（不许各建商家表/运力表）。

## 一、现有 A2A 模型（注册表前身）

现有 relay devices 结构（`A2aClient` 客户端模型）：
- `deviceId`（relay 唯一标识）+ `name` + `token`（认证）
- `a2aRegister(deviceId, name)`：注册（买家/商家都走这个）
- `a2aPeers` → `List<Peer>{deviceId, name}`（附近设备发现）
- 菜单/商品：`a2aGetMenu(deviceId)` → 独立菜单数据（按 deviceId 关联）

**现状缺口**：peer 只有 deviceId+name，无 role/工种/服务形态——无法区分商家/运力/手艺，无发现索引（按工种+半径查）。

## 二、devices 表扩展 schema

在现有 devices 表上加字段（**只增不改**，兼容现有设备）：

```jsonc
{
  "deviceId": "device_abc",          // 现有，不变
  "name": "老王盖浇饭",              // 现有，不变
  "token": "jwt...",                 // 现有，relay 认证
  "role": "pro",                     // 新增：buyer(默认,兼容现有买家) | pro(职业人)
  "professions": [                   // 新增：多工种（白天理发师晚上跑外卖 = 两个条目）
    {
      "craft": "shop",               // 工种（11 项统一，对齐 §二分类表）：shop|food|delivery|express|taxi|barber|nail|massage|tutor|repair|cleaning
      "form": "instant",             // 服务形态：instant(即时单) | appointment(预约单)
      "radiusKm": 2,                 // 服务半径（附近搜索）
      "payCodeRef": "local:alipay:...",  // 收款码引用（端侧本地加密存，relay 只存引用）
      "online": true,                // 接单中（发现索引可查）
      "behaviorRef": "behavior:<deviceId>:<craft>",  // 行为档案指针（G4 对账/排名数据）
      "menuRef": "menu:<deviceId>"   // 卖货型：菜单/商品卡（现 a2aGetMenu 关联）
    }
  ]
}
```

**工种分类学 → craft 枚举**（对齐 DESIGN_GIG §一）：
| 子类 | craft | form |
|---|---|---|
| 卖货型 | shop / food | instant |
| 运力型 | delivery / express / taxi | instant |
| 手艺·到店 | barber / nail / massage | appointment |
| 手艺·上门 | tutor / repair / cleaning | appointment |

## 三、迁移路径（现有商家配对 → 新 schema，无损）

**执行方（选 a 端侧上报，写死）**：端侧下次 `a2aRegister` 时上报 `role`/`professions`；旧调用点缺省 = `buyer`/无 professions（兼容，迁移无感）。relay 不主动回填。

现有 `a2aRegister(deviceId, name)` 注册的商家（merchant，有菜单）迁移：

1. **端侧判定**：`a2aGetMenu(deviceId)` 有菜单 → 上报 `role="pro"`, `professions=[{craft:"shop", form:"instant", online:true, menuRef:"menu:<deviceId>"}]`
2. **缺省兼容**：不传 role/professions = `buyer`（现有买家/商家配对流程零改动）
3. **无损保证**：`deviceId`/`name`/`token` **不动**；菜单数据不动（menuRef 指向原数据）；已有配对关系（pair）不变
4. **兼容**：迁移期 role 缺省按旧逻辑（无 professions = 旧商家，菜单照旧）；relay 按 professions 索引，无 professions 的旧设备不参与工种发现

> 不另起炉灶：`a2aRegister` 迁移对齐（加 role/professions 参数，缺省兼容），不推翻现有注册/配对/消息链路。

## 四、端侧 / relay 数据分工

| 侧 | 存什么 | 用途 |
|---|---|---|
| **端侧本地** | profile 缓存投影（自己职业档案 + 附近 pro 缓存） | 离线可用、快速渲染 |
| **relay** | 发现索引（professions 工种 + radiusKm + online） | 附近搜索：按工种+半径查 |

- relay 只存发现索引（deviceId + professions 可索引字段），**收款码/行为档案详情端侧持，relay 不碰**（红线：不碰钱，收款码直达）
- 附近搜索：`query {craft, radiusKm, online}` → relay 返回匹配 deviceId 列表 → 端侧投影详情

## 五、取数约束（M1/G1）

- **Marketplace M1 / Gig G1 都从 devices 表查 professions 取数**，不许各建商家表/运力表
- 商流（Marketplace）= 职业注册表之上交易视图：商品卡 = professions[craft=shop].menuRef；服务卡 = professions[craft!=shop].appointment
- 即时任务（G1） = 运力/卖货 professions 的即时单；预约（G3）= 手艺 appointment

## 六、落地步骤

1. **relay 侧**（服务端，mow.kim）：devices 表加 professions 字段 + 工种索引 + 发现查询接口（`query_pro` by craft/radius）
2. **端侧**：`A2aClient` 注册 payload 加 role/professions；`a2aRegister` 签名扩展（缺省兼容）；`query_pro` 桥（附近职业人发现）
3. **迁移**：现有商家自动映射（menuRef），无感
4. **M1/G1**：从注册表取数（对接第 1/2 步）

## 七、红线（对齐 DESIGN_GIG §九）

- 不碰钱：收款码端侧持 + 直达，relay 只存引用
- 职业体系不得读取本单之外信息（买家地址仅本单可见）
- v1 信任模型 = 附近熟人经济，不接保险/赔付

## 八、验收结论（验收人 2026-08-01，commit 505e390，L1 设计审）

**结论：审过**——只增不改兼容策略、不另起炉灶（a2aRegister 对齐）、不碰钱（收款码端侧持 relay 只存引用）、M1/G1 统一注册表取数，均符合红线与 GIG v3 方向。实现可开工，但先把两条修正写回本文档：

1. **craft 枚举不一致**：§二 JSONC 注释列 8 项（shop|food|delivery|express|taxi|barber|tutor|repair），§二分类表 11 项（多 nail/massage/cleaning）。以分类表 11 项为准统一，否则 relay 索引与端侧各写各的。
2. **迁移执行方写死（二选一）**：§三「读现有商家数据判定卖货型」没说谁触发迁移、菜单数据存哪侧。建议 a) 端侧下次 a2aRegister 时上报 role/professions（缺省兼容，迁移无感）；或 b) relay 一次性迁移脚本回填（menuRef 存在 → pro/shop）。选定后补进 §三。

核对过现状模型描述（a2aRegister/a2aPeers/a2aGetMenu 与 BridgeA2a 桥接一致，见 TASKS_P1_A2A_BUYER 验收记录），§一属实。
