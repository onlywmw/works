# 大模型测验手册（LLM TEST PLAYBOOK）— 2026-08-01 验收人立

> 用途：模型升级/修改后的**快速高质量验收**。方法论 + 判例库 + 指标体系 + 一键脚本。
> 本手册从 2026-08-01 Unlimited-OCR 移植全天实战中提炼，每一条都有当天的判例出处。

## 一、指标体系（验收四指标，已成型）

| 指标 | 线 | 怎么测 | 判例 |
|---|---|---|---|
| ① 精度 | golden ≥98%，**逐字比对非相似度**（OCR 错一个字就是错） | 黄金样本三图（已锁，换图对照即打回），归一化：去 det/ref 标签 + 去空白后 exact match | 巡检#28：380/380 exact_match=True |
| ② 内存 | RSS ≤4GB（读 /proc/self/status VmRSS，非估算） | 识别全程结束后自读 | 2.14GB（巡检#28） |
| ③ 速度 | decode ≥5 tok/s，**报 prefill/decode 分解**，不许只报 decode | 固定剧本（同图同 prompt 同 n） | 5.1 t/s（巡检#28） |
| ④ 单页总时长 | ≤60s（翻页不断判据） | prefill+decode 实测 | 83.9s ⚠️（R-SWA 解） |

**第五隐性指标：正确性先于速度**——输出退化（重复/乱码）时先修正确性，速度优化不许在错误输出上做。

## 二、判例库（测大模型的反模式，全都咬过人）

| # | 判例 | 教训 |
|---|---|---|
| T1 | **测试路径≠设备路径**：JCEKS 白盒没有 AndroidKeyStore 的 randomized-encryption 限制，生产加密必败单测全绿 | 平台特性（Keystore/电源/显示）必须在真机过一遍 |
| T2 | **注入构造≠生产构造**：Snapshot 单测注入设备字段全绿，生产 snapshot() 旧构造零数据源，9 条件真机全死 | 交付带真机正反两例，单测绿不证明生产接线 |
| T3 | **API 语义以真机为准**：PowerManager.isInteractive() AOSP 语义 awake，MIUI 屏灭仍 true | 平台 API 不许只看文档，验收环境的行为就是标准 |
| T4 | **短负载测不出长负载的病**：llama-cli "Hello" 5.2 t/s，长 KV 掉到 0.7 t/s（8× 退化） | 测速必须在真实负载（真实 KV 长度/真实图片）下做 |
| T5 | **自报测速不可信**：P4 报 7.0，验收人实测 5.2——测法不同数就飘 | 统一固定剧本，报分解数字，附原始日志 |
| T6 | **多症状≠多 bug**：退化+慢+崩三线症状，根因是一个 logits_idx | 先找总根因再分头修；症状清单不是 bug 清单 |
| T7 | **数字特征定性法**：>650s/273embd ≈ 2.3s/embd 严丝合缝 → 「拆批」假设（后被证伪，但证伪也靠一行日志） | 先算数量级对号入座，再用最小埋点证伪 |
| T8 | **stderr/stdout 混排陷阱**：printf 的结果在日志尾部，perf 行在中间——切片切错得出「没输出」 | 拉全量日志本地分析，别在设备上 grep 中文（GBK/UTF-8 坑） |
| T9 | **假覆盖四形态 + 第五形态**：「工具类写了测了但生产零调用点」（wrapOcrText） | 交付必须附调用点 grep |
| T10 | **交互模式污染**：llama-cli 无 tty 空转刷几百 MB `"> "`；`pkill -f` 自匹配杀自己 | 非交互参数 `-no-cnv --no-display-prompt`；`pkill -x` |

## 三、快速验收流（模型升级后，按序跑）

```
新权重
 → ① gguf_convert.sh（转换+量化 q4_K_M/q8_0，字节数对账）
 → ② 冒烟：OCR_PLAYBOOK §三命令（Hello→World，2 分钟）
 → ③ 一键验收：ocr/scripts/ocr_accept.sh（三图 golden 回归+速度+内存，详见下）
 → ④ 报告四指标分解数字 + 原始日志入库 docs/device-acceptance/<date>/
```

变更注意：
- **黄金样本锁死**：换图/换参考即打回；模型升级只允许「同图对同参考」
- 权重 SHA256 对照官方入档（S3 纪律）
- llama.cpp 版本变更 = 重新钉版 + 记录新旧版本号 + 同剧本对比

## 四、一键验收脚本（ocr/scripts/ocr_accept.sh）

今天手跑全链的固化：三图特征生成（MNN proot python）→ vision_infer → 归一化 diff → 四指标报告。
用法见脚本头注释。**判读：输出 PASS/FAIL + 四指标表 + 失败样本的 diff 明细。**

## 五、测试资产清单（都在仓库/平板）

| 资产 | 位置 |
|---|---|
| 黄金三图+参考输出 | `ocr/testdata/golden/` + `docs/OCR_GOLDEN_SAMPLES.md` §3（锁死） |
| 特征生成 | `/data/local/tmp/gen_prefetch_raw.py`（MNN proot，OCR_PLAYBOOK §三跑法） |
| 识别二进制 | `/data/local/tmp/vision_infer`（源码 `ocr/scripts/vision_infer.cpp`） |
| 一键验收 | `ocr/scripts/ocr_accept.sh`（本次新建） |
| 验收证据归档 | `docs/device-acceptance/<date>/`（每次验收必归档） |
| 运维/跑法 | `docs/OCR_PLAYBOOK.md` §三 |
| 判例同步 | 本手册 §二（谁踩新坑谁补，验收人核对） |

> 本手册随测试实践演进（同 OCR_PLAYBOOK 双书制：PLAYBOOK 管「怎么跑」，本手册管「怎么判」）。
