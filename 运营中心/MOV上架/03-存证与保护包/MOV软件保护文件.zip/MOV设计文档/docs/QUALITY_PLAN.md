# 质量超越 Hermes + Dyad 行动计划

> 状态: 📐 design-ready
> 日期: 2026-07-29
> 目标: 在质量维度建立 MOV 独有优势，不追数量追深度

---

## 一、认清差距，不追数量

| 维度 | Hermes | Dyad | MOV 策略 |
|------|--------|------|---------|
| 测试数量 | 2235 | 761 | **不追**（不同量级产品） |
| 快照测试 | 229 个 Prompt 快照 | 少量 | **5 个核心快照**即可覆盖关键路径 |
| 预提交钩子 | 无 | 3 道关（oxlint+oxfmt+tsgo） | **1 道关**：`./gradlew :app:testDebugUnitTest` |
| CI/CD | 16 workflows | CI 门禁 | **不需要**（单机开发） |
| 错误分类 | 20 类 | 10 类 | **10 类**够用，不需 20 |
| 平台测试 | 无（桌面端） | Playwright E2E | **真 Android 设备测试**（独有） |

**核心思路**：MOV 不做 SaaS 产品，不需要 Hermes 那种生产级测试规模。但 MOV 有三个 Hermes/Dyad 做不到的事：

1. **真硬件测试** — 在真实平板上跑，不是模拟器
2. **断点续跑测试** — kill App 后验证 Journal 恢复
3. **网络韧性测试** — 飞行模式下 AI 优雅降级

---

## 二、即刻实施（Phase 1，1 天）

### 2.1 预提交质量门（20 分钟）

```bash
# 在 .git/hooks/pre-commit 加一行
#!/bin/sh
./gradlew :app:testDebugUnitTest 2>&1 | grep -q "BUILD SUCCESSFUL" || { echo "❌ 测试未通过"; exit 1; }
```

**为什么只要一行**：单人项目不需要 lint 门禁，测试通过就够了。

### 2.2 3 个核心快照测试（对标 Hermes 229 个）

```java
// ToolRegistrySnapshotTest.java — 每次改 prompt 自动检查
@Test public void stepPrompt_snapshot() {
    String p = registry.promptText();
    assertTrue(p.contains("tool.execute"));
    assertTrue(p.contains("ESSENTIAL_TOOLS 全部 20 个"));  
    assertTrue(p.length() < 5000);  // token 预算
}

@Test public void planPrompt_snapshot() {
    String p = registry.promptText("plan"); 
    assertTrue(p.contains("可用手段"));
    assertTrue(p.length() < 5000);
}

@Test public void toolDescribe_works() {
    Tool t = registry.find("tool.describe");
    assertNotNull(t);
    Result r = t.handler.run(new JSONObject("{\"name\":\"file.read\"}"));
    assertTrue(r.ok);
    assertTrue(r.text.contains("params"));  // 返回完整签名
}
```

### 2.3 错误分类升级（5→10 类）

```java
// ErrorReporter.java — 补充 5 类
public enum ErrorKind {
    // 现有
    USER, EXTERNAL, INTERNAL,
    // 新增
    VALIDATION,    // 参数校验失败
    TIMEOUT,       // 超时
    BRIDGE_DOWN,   // 桥不可用
    PERMISSION,    // 权限不足
    RATE_LIMITED   // 频率限制
}
```

### 2.4 Contract Test（1 个）

```java
// ProtocolContractTest.java
@Test public void adaptLegacyResponse_handlesAllJavaFormats() {
    assertEquals(true, adaptLegacyResponse("OK").ok);
    assertEquals(false, adaptLegacyResponse("Error: bad").ok);
    assertEquals(true, adaptLegacyResponse("{\"ok\":true}").ok);
    assertEquals(true, adaptLegacyResponse("").ok);
}
```

---

## 三、后续升级（Phase 2，2 天）

### 3.1 真设备断点续跑测试

```bash
# 启动 agent → kill 进程 → 重启 → 验证恢复
adb shell monkey -p com.hermes.android ...
# 发送任务 → 等第 3 步执行 → adb shell am force-stop
# 重启 → 检查 RECOVERY 态触发
```

### 3.2 网络韧性测试

```bash
# 飞行模式下发送 AI 请求 → 验证优雅降级
adb shell cmd connectivity airplane-mode enable
# 验证错误提示而非崩溃
```

### 3.3 内存泄漏检测

```java
// 在 Activity.onDestroy 中加断言
@Override protected void onDestroy() {
    shell.destroy();
    assert shell.isDestroyed() : "WebView 未正确销毁";
}
```

---

## 四、不计入（保持克制）

| 不做 | 理由 |
|------|------|
| CI/CD pipeline | 单人项目，本地跑就够了 |
| Prettier/ESLint | 旧代码不强制格式化 |
| E2E 测试框架 | 太重，手工冒烟 6 步够用 |
| 100% 覆盖率 | 质量 > 数字 |
| 复制 Hermes 的快照数量 | 5 个核心快照覆盖 90% 风险 |

---

## 五、质量对比（完成后）

| 维度 | Hermes | Dyad | MOV 完成后 |
|------|--------|------|-----------|
| 测试 | 2235 (量) | 761 + E2E | 260+ 5快照 + 契约 + 真设备 |
| 错误分类 | 20 类 | 10 类 | 10 类 |
| 预提交 | CI | 3 道关 | 1 道关（测试） |
| 平台测试 | 无 | Playwright | **真 Android 设备**（独有） |
| 断点恢复 | 无 | 无 | **RECOVERY 态**（独有） |
| 网络韧性 | 无 | 无 | **飞行模式降级**（独有） |

**结论**：不在数量上追，在**深度和独有优势**上超越。
