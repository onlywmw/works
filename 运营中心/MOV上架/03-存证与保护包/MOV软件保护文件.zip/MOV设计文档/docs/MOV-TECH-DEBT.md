# MOV-APP 技术债与诊断记录

> 2026-07-26 · commit: a1c6e53 · 下次上线看这个

---

## 历史阻塞（已闭环）：连续两次计划解析失败

### 状态：✅ 已闭环（诊断结论：工作正常，见 §67 行附近「诊断结论」段；2026-08-01 清洗时归档）

Phase 1 的 prompt 冲突已修复（`CLARIFY_PROMPT` 替代 `planPrompt`），但仍然失败。

### 如何获取诊断数据

```bash
adb logcat -s MOV-DIAG
```

日志包含：
- `P1 raw(Nchars): ...` — Phase 1 LLM 原始输出前 300 字
- `P1 extractJson=null` — Phase 1 未能提取 JSON
- `P2-att1 raw(Nchars): ...` — Phase 2 第 1 次尝试的原始输出
- `P2-att1 extractJson=null` — Phase 2 提取 JSON 失败
- `P2-att1 gotJSON but no plan array` — Phase 2 提取到 JSON 但无 plan 数组
- `P1 fail` / `P2-att1 fail` / `P2-att2 fail` — 失败记录

### 诊断流程

1. 跑一个任务观察失败
2. `adb logcat -c && adb logcat -s MOV-DIAG` 清旧日志重新收集
3. 看 Phase 1 输出：如果 P1 能正确输出 `{understanding, clarify}` → Phase 1 OK
4. 看 Phase 2 输出：如果 P2 两次都是 `extractJson=null` → LLM 完全不输出 JSON
5. 如果 P2 `gotJSON but no plan array` → LLM 输出对象而非数组

### 已知已排除的假设

| 假设 | 验证结果 |
|------|---------|
| ActionParser 栈式解析器有问题 | ❌ 排除，256 单测全绿 |
| Phase 2 缺工具描述 | ❌ 已补 registry.promptText() |
| PLAN_RULES 硬条件过长 | ❌ 已回退 |
| Phase 1 prompt 冲突（plan vs clarify） | ✅ 确认并已修复 |

---

## P8 改动清单（本轮会话所做）

| 改动 | Commit | 状态 |
|------|--------|------|
| 栈式 JSON 解析器 | cc5399b | ✅ |
| 精准 retry 诊断反馈 | 8135493 | ✅ |
| Worker 执行路由（plan→worker） | 18e6c23 | ✅ |
| BridgeAi 构建 Worker 注册表 | bfecb1a | ✅ |
| Plan 拆分 clarifyThenPlan | ac1cdb0 | ✅ |
| Phase 2 独立 prompt | d28ed1d | ✅ |
| Phase 2 补工具描述 | f2abc0b | ✅ |
| Hermes 触发硬条件 | c67ce63 | ⏳ 已回退，待重新设计 |
| Phase 1 clarify 独立 prompt | 2f98ae7 | ✅ |
| 无选项提问卡修复 | 3f61318 | ✅ |
| ComplianceScanner 集成 | 5d6787e | ✅ |
| 栈式 Parser FIRST 优先 | cc5399b | ✅ |

---

## 未解决的技术债

### 1. Plan 拆分稳定性（2026-07-30 诊断——建议降级为非阻塞）

**诊断结论**：Plan 拆分当前**工作正常**。"当前阻塞"标签疑似过时——此前修复（CLARIFY_PROMPT 替代 planPrompt、ActionParser 栈式提取、P2 自动包装/修复）可能已联合消除原故障。建议降级为普通债，移出"阻塞"。

**诊断证据**：
1. 真机 MOV-DIAG（2026-07-30 14:02）：
   - MiMo 简单任务：`P1 raw(1573chars)` → 正常 → `P2-att1 raw(379chars)` → `自动包装(有action)` → Plan 生成成功
   - MiMo 复杂任务（Python数据分析）：同上，P1→ask→P2→plan 全正常
   - DeepSeek 复杂任务：同上，无失败
2. `AgentLoop.java:877-932` 审查：P2 有 3 层兜底——自动包装(有action)、自动修复(补action+name)、精准反馈(告诉 LLM 输出格式)。前两层已覆盖大部分 LLM 输出变体。
3. 未复现"连续两次解析失败"——MAX_PARSE_FAILS=2 的防御路径在真实模型测试中从未触发。

**如果未来复现，按以下路径诊断**：
1. `adb logcat -s MOV-DIAG` 收集：
   - `P1 extractJson=null` → Phase 1 提取失败（LLM 输出无 JSON）
   - `P2-att1 extractJson=null raw=...` → P2-att1 无 JSON
   - `P2-att2 invalid. got=...` → P2-att2 有 JSON 但非 array/action/path
2. 看 raw 里 LLM 到底输出了什么——废话？markdown 包裹？对象非数组？
3. 用 mock-llm（`tools/e2e/mock-llm.py`）注入同样输出复现，确认解析管线反应

**两种修法（如复发时选择）**：
- **A. Prompt 侧**（低风险）：P2 prompt 加更强制约束 + few-shot 例。优势：不动解析器，兼容性好。风险：token 成本增加
- **B. 解析器侧**（中风险）：ActionParser 加 markdown 代码块提取正则 + JSON 修复（缺逗号/引号）。优势：扛 LLM 输出变异。风险：可能误提取非 JSON 文本

### 2. Hermes 触发率低

**现象**：LLM 很少主动标 `worker:heavy:hermes`
**上次尝试**：硬条件 prompt（已回退——导致解析失败增多）
**建议方向**：
- 方案 A：硬编码触发规则（按工具名或文件类型）
- 方案 B：Prompt 微调（比硬条件更温和的措辞）
- 方案 C：用户手动触发（计划卡加"委派 Hermes"按钮）

### 3. 理解闸无独立状态机

**现象**：clarify 逻辑嵌入在 clarifyThenPlan 内部，无独立的 `UNDERSTAND_GATE` 状态
**影响**：用户看不到"理解确认"阶段，体验和 plan gate 混在一起
**设计文档**：DESIGN_DELIVERY_GATE.md 定义了完整的状态机，未实施

### 4. 委派守门员（ActionInterceptor）未实施

**现象**：文件类型分流逻辑不存在，委派完全依赖 LLM 的 worker 标注
**设计文档**：DESIGN_DELIVERY_GATE.md §委派守门员

### 5. 交付基线 ComplianceScanner 已建但未深度集成

**现象**：Scanner 代码在，但只在 deliver 阶段运行一个 scan
**缺失**：
- 扫描结果修复循环（缺陷→LLM 自我修复→复扫）
- 带瑕疵交付的 UI 展示
- report_gap 卡

### 6. 单步串行无法改

**现象**：AgentLoop 不支持多步骤并行执行
**影响**：多模型协作只能"评审投票"，不能"分工并行"
**依赖**：需要先稳定 Plan 拆分 + Worker 路由

### 7. 模型列表头像简陋

**现象**：头像显示厂商首字母 + 颜色
**上次尝试**：favicon URL（部分可用）+ 头像选择器 UI（被否决）
**当前**：回退到字母头像 + 品牌色

### 8. 高级设置默认折叠已修复

**现象**：之前编辑模型时高级设置自动展开
**状态**：✅ 已修复（f7507e4）

---

## 下次上线可以做的事

1. **先看 MOV-TECH-DEBT.md 这个文件**，了解上次进度
2. `adb logcat -s MOV-DIAG` 收集诊断日志
3. 根据日志判断 Plan 拆分失败的具体位置
4. 决定下一步：修 Plan 拆分 vs 回退到旧 makePlan

---

## 关键文件速查

| 文件 | 作用 |
|------|------|
| AgentLoop.java | clarifyThenPlan() — Plan 拆分逻辑（Phase 1+2） |
| ActionParser.java | extractJson() — 栈式 JSON 提取 |
| ComplianceScanner.java | 交付基线扫描器 |
| BridgeKernel.java | gate_respond understand/ask 分支 |
| BridgeAi.java | buildReviewer + Worker 注册 |
| HeavyWorker.java | Hermes 委派执行 |
| PLAN_RULES | AgentLoop 的 Plan prompt |
| CLARIFY_PROMPT | Phase 1 clarify prompt |
| PLAN_ARRAY_RULES | Phase 2 plan prompt |

---

## 后续候选功能（登记于 2026-07-30）

### 交付物微调编辑器（htmltool2 思路）

- **来源**：`C:\Users\Administrator\Desktop\GitHub项目\htmltool2-main.zip`（MIT，单文件 1123 行，纯本地，默认禁脚本）
- **痛点**：AI 交付的 HTML（点单应用/报告/PPT）生成后，用户改一个字都要走一轮 agent（慢+烧 token+易改坏）。
- **方案**：`index.html` 收进 `assets/editor/`（保持单文件便于追踪上游）；files.js 文件预览 overlay 加「编辑」按钮唤起；**保存必须先走 StorageManager 快照再落盘**（铁律，编辑器不得绕过版本机制）；用户手改记录进 journal（audit:true）。
- **排期**：Phase 3 之后（当前兵力在新脸 Phase 1 收尾 + Phase 2 意图管道）。
- **注意**：不用于新脸选项渲染（新脸已有"模板+数据填充"，见 NEWFACE_PLAN）。

---

## BUGFIX_PLAN_2026-07-29 结转长期债（2026-07-30 核实）

### BUG-5: AgentLoop 状态双写吞 IllegalStateException

- **结论**：属实。`AgentLoop.java:224-240` `changeState()` catch `IllegalStateException` 仅 Log.e，
  旧 state 无条件覆盖绕过校验，STATE_DESYNC 不上报。
- **最坏后果**：终态下收到新指令 → 旧变量被改但 ctx 拒绝 → 主循环状态分裂 → 任务重复执行或悬挂。
- **为什么暂缓**：修 changeState 涉及 15 个调用点 + 2 个直接赋值，需逐条审查容错语义。
- **文件**：`app/src/main/java/com/hermes/android/agent/AgentLoop.java:224-240`；
  `AgentContext.java:20-25`

#### 状态机加固方案（2026-07-30 设计，待审批）

**0. 现状问题分析**

双变量架构：`AgentLoop.state`(旧 volatile) + `AgentContext.state`(新容器)。
- `changeState()`: 旧变量无条件赋 target (L229)，ctx 抛异常后吞掉 (L231-233)
- 直接赋值 `this.state = State.PLANNING` (L268) 和 `= State.RECOVERY` (L278) 绕过全部校验
- STATE_DESYNC 只记日志，不上报 ErrorReporter
- `isActive()` (L350) 读的是旧 state，`ctx.getState()` 没人读

**1. 15 个调用点分类**

| # | 行号 | 源 → 目标 | 调用场景 | 失败容错 | 分类 |
|---|------|----------|---------|---------|------|
| 1 | L455 | → PLANNING | 计划周期起点，无条件执行 | **不可失败** | must |
| 2 | L510 | PLANNING→PLAN_GATE | 计划生成后，出闸前 | 非法时 crash early | must |
| 3 | L520 | PLAN_GATE→EXECUTING | 计划批准后，开始执行 | **不可失败** | must |
| 4 | L644 | EXECUTING→PLAN_GATE | revise_plan: 新计划生成 | 非法时 crash early | must |
| 5 | L652 | PLAN_GATE→EXECUTING | 修订计划批准后 | **不可失败** | must |
| 6 | L657 | PLAN_GATE→EXECUTING | 修订计划驳回→继续 | **不可失败** | must |
| 7 | L984 | EXECUTING→PAUSED | 可恢复错误暂停 | 非法时 crash | must |
| 8 | L1002 | PAUSED→EXECUTING | 用户续跑 | **不可失败** | must |
| 9 | L1215 | → DONE | 交付完成 | 必须落终态 | best-effort |
| 10 | L1219 | → FAILED | fail(String) | 必须落终态 | best-effort |
| 11 | L1231 | → FAILED | failMov(MovError) | 必须落终态 | best-effort |
| 12 | L1252 | → STOPPED | stopRequested | 必须落终态 | best-effort |
| 13 | L455 | → PLANNING | 同#1, 重复 | — | must |
| 14 | L268 | = PLANNING | Recovery 构造直接赋值 | 绕过校验 | 待消除 |
| 15 | L278 | = RECOVERY | Recovery 构造直接赋值 | 绕过校验 | 待消除 |

**2. 新语义设计（推荐方案：双变量合一 + 严格校验）**

核心思路：
- **删除旧 `state` 变量**，全代码改用 `ctx.getState()`
- `changeState()` → 重命名为 `transition()` 并去掉 try-catch：非法转换**直接抛**（RuntimeException 不吞）
- `isActive()` / `isTerminal()` 改为 `ctx.getState().isActive()` 等
- L268/L278 直接赋值改为走 transition()

三种方案对比：

| | A. 双变量合一+抛异常 | B. changeState 返 boolean | C. 最小修补 |
|---|---|---|---|
| 改动量 | 中（15处+变量删除） | 大（30+处加返回值判断） | 小（5处） |
| 非法转换行为 | 抛异常，调用方必须处理 | 返 false，调用方可能忽略 | 同现状（吞） |
| 反脆性 | 高（fail-fast） | 中（可能静默） | 低（同现状） |
| 回归风险 | 中（调用链可能未预料 throw） | 低（调用方可选处理） | 低 |

**推荐方案 A**，理由：
- 状态机非法转换是编程错误，应 fail-fast 而非静默
- 当前 15 个调用点中 12 个已经是 `must`（不可失败），抛异常是正确行为
- 3 个 `best-effort` (DONE/FAILED/STOPPED) 需特殊处理：catch 后强制覆写终态 + 上报 ErrorReporter
- 删除直接赋值消除旁路

**3. 反例审查：「这样改哪个调用方会死」**

| 调用方 | 风险 | 缓解 |
|--------|------|------|
| L455 PLANNING 周期起点 | `!isTerminal() → PLANNING` 在终态时抛异常 | 外层 while(true) 已有 stopRequested 和 MAX_PLAN_CYCLES 守卫，在 transition 前加 isTerminal 检查 |
| L1215 DONE | 如果已在终态(DONE→DONE 合法) | canTransitionTo 已有 `this==target → true` |
| L1219/1231 FAILED | 同 DONE | 同上，FAILED→FAILED 合法 |
| L1252 STOPPED | 并发竞态：stopRequested + fail 竞速 | STOPPED→FAILED 不在转换表！需加到 STOPPED 的允许目标 |
| L1002 PAUSED→EXECUTING | parkForResume 超时后 resumeApproved=true | 超时 break 出 while 后 resumeApproved 仍为 null，不会走到 transition |
| L268 直接赋值 | Recovery 构造 | 改为 `ctx.transition(PLANNING)` 后 startNew 覆盖为 PLANNING |

**关键发现**：`STOPPED→FAILED` 不在 canTransitionTo 表中（终态默认返回 false）！如果 `stopped()` 和 `fail()` 竞速，后者会抛 IllegalStateException。

**Q1（评审人）· 终态竞速语义**：药方「加 STOPPED→STOPPED 同态」治不了 STOPPED→FAILED。终态后续转换语义三选一，倾向 **b) 先到者胜+no-op**——用户喊停是最高意志，不该被随后的 fail 覆盖。

**答**：采纳 b。终态转换规则：`isTerminal() → true` 后，任何后续 transition 均为 no-op（不抛异常，静默返回）。调用方影响分析：

| 竞速场景 | b 行为 | 影响 |
|---------|--------|------|
| stop → fail 竞速：stopped()先到 | fail() 看到 STOPPED → no-op | 日志里不会有 FAILED 事件（journal 中只有 STOPPED）——正确，用户喊停是最高意志 |
| fail → stop 竞速：fail()先到 | stopped() 看到 FAILED → no-op | 同上的对称情况——失败记录保留 |
| deliver→stop 竞速 | stopped() no-op | deliver 的 DONE 事件已落 journal，stop 不覆盖——可接受，交付完成应保留 |
| deliver→fail 竞速 | fail() no-op | DONE 不被覆盖——可接受 |
| 同态转换（DONE→DONE） | canTransitionTo 已返回 true | 不变 |

实现：best-effort 调用方 (L1215/L1219/L1231/L1252) 在 transition 前检查 `ctx.getState().isTerminal() → return`。Phase 1 先加守卫（不改 throw 语义），Phase 2 统一为 no-op 模式。

**Q2（评审人）· 谁兜底**：12 个 must 点改 throw 后，意料外的 throw 杀循环线程、任务悬挂、用户无感知。catch-all 在哪？

**答**：现存 `run()` L530-532 已有 catch-all：
```java
} catch (Exception e) {
    failMov(MovError.internal("LOOP_EXCEPTION", "出了点问题，已记录", e));
}
```
覆盖范围验证：
- L448 try 块包裹 L449-L529 全部主循环逻辑 → ✅ 所有 12 个 must transition 都在 try 内
- L268/L278 构造赋值 → 不在 try 内，但改为走 transition() 后在 startNew 调用链中，由调用方 catch
- respondResume/agentAnswer 回调中的 transition → **不在 try 内！** 需加守卫

Phase 2 补充：
- `respondResume()` (L977-980) 改为只设置标志 + notify，不直接调 transition；transition 由主循环在 try 内执行
- `agentAnswer()` — 同上，已是纯标志设置
- run() catch-all 加上 `android.util.Log.wtf` 确保异常不被完全淹没
- ErrorReporter.report() 在 failMov 中已有（L1234-1242），覆盖 INTERNAL 类异常

**4. 迁移顺序**

Phase 1（安全，无行为变更）:
1. 删除 L268/L278 直接赋值 → 用 transition()
2. 终态竞速守卫：DONE/FAILED/STOPPED 调用方加 `isTerminal()→return`（先到者胜）
3. canTransitionTo 加终态同态返回 true（DONE→DONE / FAILED→FAILED / STOPPED→STOPPED）
4. 提交，构建+单测绿

Phase 2（主重构）:
5. changeState() 去 try-catch → 非法转换直接 throw
6. 删除旧 `state` 变量 → `isActive()`/`isTerminal()` 读 ctx
7. DONE/FAILED/STOPPED 改为 no-op 模式（已在终态→静默返回）
8. run() catch-all 加 Log.wtf + 确认 ErrorReporter 覆盖
9. respondResume 回调守卫：只设标志，transition 由主循环在 try 内执行
10. 提交，构建+单测绿

Phase 3（收尾）:
8. 删除 `@Deprecated transition()` 别名 → 统一用 changeState()
9. STATE_DESYNC 日志 → 改为 ErrorReporter.report()
10. 提交

**5. 回归测试计划**

- AgentLoopTest 现有全部用例保持绿
- 新增：非法转换抛异常（PLANNING→DONE 直接跳终态→assertThrows）
- 新增：终态竞速（STOPPED+FAILED 并发→不抛）
- 新增：isActive 全态覆盖（PLANNING/PLAN_GATE/EXECUTING/PAUSED/RECOVERY→true，DONE/FAILED/STOPPED→false）
- 新增：Recovery 构造路径合法转换

### BUG-7: Keystore 不可用时降级明文，违反 TC-SEC02

- **结论**：代码违规。合同（`ARCHITECTURE.md:445`）要求 Keystore 不可用 → 不降级明文 +
  JS toast + apiKey 不持久化；代码（`ModelRegistry.java:46-66`、`AiProviderConfig.java:38-62`、
  `DeployConfig.java:43-51`）全部静默降级明文 SharedPreferences。
- **最低成本修法**：Keystore 不可用时抛异常（禁止降级），ModelRegistry.isEncrypted 已存在可复用。
- **完整修法**：+JS toast 桥 + UI 层 apiKey 仅内存缓存（均需额外改动）。
- **建议**：先做最低成本修法（禁止降级明文），单独 commit 通知验收人。
- **① 已修**：`7bf7183` — Keystore 不可用时用临时空桶 `__xxx_enc_unavailable__`
  替代明文 fallback；isEncrypted=false。② (JS toast) ③ (apiKey 不持久化 UI) 留安全轮次。
- **文件**：`app/src/main/java/com/hermes/android/model/ModelRegistry.java:46-66`；
  `app/src/main/java/com/hermes/android/ai/AiProviderConfig.java:38-62`；
  `app/src/main/java/com/hermes/android/linux/DeployConfig.java:43-51`

---

## TASKS_P2_2026-07-30 关闭记录

| 编号 | 内容 | Commit | 状态 |
|------|------|--------|------|
| BUG-8 | chat.js streamPane 死代码 | `6f388e8` | ✅ 已删 |
| BUG-14 | McpServerTest 假覆盖 → 行为测试 | `73e995c` | ✅ 已重写 |
| BUG-5 | AgentLoop 吞 IllegalStateException | `2598a39` | ✅ 已核实（暂缓修，待状态机加固专项） |
| BUG-7 | Keystore 降级 vs TC-SEC02 | `b0fb26e` | ✅ ①已修（禁止降级明文）②③留安全轮次 |
| BUG-4a | aiChatWithModel 裁剪行笔误 | `4d852b5`（提前修） | ✅ 已修复 |
| BUG-4b | 房间历史重启持久化 | `720beb8`（打回重修） | ✅ 已实现（journal.jsonl + actor 过滤） |

全部 6 项已验收通过。R2 三项（`7a253ec` `f48a0a0` `b0fb26e`）已合并关闭。

---

## TASKS_P2_ROUND2_2026-07-30 关闭记录

| 编号 | 内容 | Commit | 状态 |
|------|------|--------|------|
| R2-2 | 4b 重建 actor 过滤 | `7a253ec` | ✅ |
| R2-1 | aiChatAsync/aiInfo 旧配置链误报 | `f48a0a0` | ✅ |
| R2-3 | BUG-7① 禁止降级明文 | `b0fb26e` | ✅ 验收通过（接线测试站岗+真机回归无损） |

全批关闭 ✅（2026-07-30 验收人）。

---

## 附带发现（2026-07-30 验收人 + P2 核实）

### B.aiInfo() configured:false 误报

- **现象**：本机 `B.aiInfo()` 始终报 `configured:false`，`B.aiAsync` 旧路径永远误报"AI 尚未配置"
- **原因**：旧 `AiProviderConfig`（SharedPreferences `hermes_ai_prefs`）无 API Key；
  实际模型配置走 `ModelRegistry`（SharedPreferences `mov_models`）
- **影响范围**：`bridge.js:18` `B.aiAsync()`；`chat.js:140-146` 无默认模型时的 fallback 提示
- **非紧急**：新路径（`B.aiChatWithModel` → `ModelRegistry`）正常工作；
  旧路径仅在无默认模型时作为兜底错误提示，文案虽不精确但不影响核心功能
- **建议**：下一轮统一 `getAiInfo()` 查询 ModelRegistry 获取真实配置状态

#### 方案评审意见（2026-07-30 验收人）——两条答清才许 Phase 1

**Q1（自相矛盾，必须修）：终态竞速的修法文不对题。**
反例审查发现「STOPPED→FAILED 不在转换表，stopped() 与 fail() 竞速会抛」——发现是对的，但开出的药方是「终态表加 STOPPED→STOPPED 同态」——**这治不了 STOPPED→FAILED**。
要求答清：终态到达后的后续转换语义到底是什么？建议三选一并写明理由：
a) 终态→任意终态合法（幂等覆写，最后到达者胜）；
b) 终态→终态一律 no-op + ErrorReporter（先到者胜，STOPPED 不被 FAILED 覆盖）；
c) 白名单细化（DONE→FAILED 允许、STOPPED→FAILED 允许、其余拒）。
倾向 b（用户喊停是最高意志，不该被随后的 fail 覆盖语义），但你要给出调用方影响分析。

**Q2：抛异常后谁兜底？**
12 个 must 点改 throw 后，AgentLoop 跑在 executor 线程——一个意料外的 throw 会杀死循环线程，任务悬挂且用户无感知。要求指明：主循环（或 execute 入口）最外层是否有 catch-all 兜底转 FAILED + ErrorReporter？没有就加进 Phase 2 清单。

其余批准：15 调用点分类、双变量合一、Phase 1 无行为变更先行、回归测试 4 项。Q1/Q2 答进方案后即可启动 Phase 1。

---

## 后续候选 · 卡片 UI 解耦（2026-07-31 用户提问登记）

- 现状：卡片流程逻辑与 HTML 拼接未解耦（newface.js 字符串渲染）；CSS 类可换肤但 inline 样式有残留
- v1（低成本）：inline 样式清零 + 卡片 DOM 契约文档（类名=换肤接口）
- v2（第三个卡片流出现时）：flow engine/renderer 可插拔分离——SDUI 着陆点（DESIGN_TECH_KERNEL）
- 触发条件：当前批（A2A 真剧本跑通）之后再做 v1；rule of three，第三流出现再做 v2
