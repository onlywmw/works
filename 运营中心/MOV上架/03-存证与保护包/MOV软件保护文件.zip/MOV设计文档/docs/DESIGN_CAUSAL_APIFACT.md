# DESIGN：因果记忆·API 归因层（本地叙事 + 云端因果分析）— 2026-08-04 v1

> 来源：端云协同因果记忆蓝图（由果推因）的**API 落地版**——不建自建云端，云端=无状态大模型 API（复用 MOV 现有 DeepSeek/AiClient 通道），本地把脱敏因果图编译成叙事 prompt，收 JSON 逻辑补丁编译回本地规则。
> 关系：本地引擎已交付（feat/causal-memory `75b9d37`，四元组+哈希链+钩子+衰减，真机实证）；本设计为其**云归因扩展层**。
> 明确不做（本设计）：不建服务器、不存储任何用户数据、不改本地引擎（§2 保持不变）。

## 一、核心架构

```
本地 CausalEngine（已交付）
  → 因果问题生成器（新增）          触发：负面结果 / 周度 / 用户 causal.reflect
      ├─ 叙事生成器：索引/边/事件 → 脱敏叙事文本（无真名/金额/原文）
      └─ API 归因封装：调 AiClient(DeepSeek) → JSON 补丁 {hidden_variables, probability_change, patch_rule}
  → 补丁编译（新增）：patch_rule → CausalRule 钩子 → 写账本新区块 → 可触发提醒
```

**隐私红线**：发给 API 的内容只含角色标签（"实体A"）与抽象类型（"商务伙伴"），绝对不含真实姓名/数字金额/原文；API 无状态，明确指示不记忆。

## 二、新增组件 1：叙事生成器（NarrativeBuilder）

**职责**：从 CausalEngine 数据合成一段紧凑脱敏叙事，供 API 分析。

### 数据源
`CausalEngine.query(room)` 的 `links`（高关联对 label 标签）+ `CausalIndex` 事件统计（原子频次）。

### 实体脱敏规则
- 真实标签 → `实体X`（按出现频率编序号）；类型从 `CausalEvent.meta.type` 取（如 "商务伙伴"/"亲属"），缺省 "人"
- 数字金额 → `一笔款项`（绝不写具体数字）；日期 → 相对表述（`逾期时长平均 N 天`→ 只写 `存在逾期`，或 ≤2 位整数天数）
- 谓词/关系保留语义（转账/承诺/逾期）——这是分析价值所在，与身份无关

### 叙事模板（示例输出）
```
在过去 90 天内，我与类型为「商务伙伴」的实体A发生了三次资金往来，
每次都伴随实体A的口头还款承诺，但两次出现逾期。
在我的因果图中，这些事件从未出现「书面协议」或「自动提醒」节点。
对比：与该类型实体的成功往来中均存在「书面协议」节点。
实体A与我的交互历史较短，当前关联置信度为 0.6。
```

### 生成逻辑（伪码）
```
narrate(engine, room):
  links = engine.query(room).links            # 高关联对
  entities = 按 links 频次编号 → 实体A/B/C
  stats = 每对(relation, 逾期/成功次数)       # 从 _causal_event 谓词 + meta.outcome 统计
  missingNodes = 活跃规则里 from meta.type 推断的缺失环节（如无「书面协议」边）
  return 模板拼接（≤10 行，≤800 token）
```

## 三、新增组件 2：API 归因封装（CausalOracle）

**通道**：复用 `AiClient`（MOV 已有 DeepSeek，`Brain.chat(systemPrompt, userText)`），**不新增外部 API 依赖**。

### Prompt 模板（system = 分析师角色 + 指令；user = 叙事文本）

```
[system] 你是个人因果分析专家。我会给你一段完全脱敏的个人生活事件模式描述，
所有实体用抽象标签（实体A/实体B/事件类型X），不含真实个人信息。
请：1) 从最终不良结果逆向找缺失/薄弱因果环节（隐变量）；
2) 估计加入这些环节后结果改变的概率变化；
3) 生成一条可执行的逻辑补丁规则。
严格按 JSON 返回，键：hidden_variables, probability_change, patch_rule。

[user] <NarrativeBuilder 产出的脱敏叙事>
```

### 响应契约（DeepSeek 返回 JSON）
```json
{
  "hidden_variables": ["书面协议节点缺失", "缺少自动还款提醒"],
  "probability_change": "加入书面协议后，逾期概率可降低约35%",
  "patch_rule": {
    "condition": "当与类型'商务伙伴'实体产生'资金借出'边，且无现有'书面协议'边时",
    "action": "INSERT_NODE",
    "new_node": { "type": "书面协议", "suggested_trigger": "转账后1小时内生成并确认协议" },
    "confidence_boost": 0.3
  }
}
```

### 错误处理
- 返回非 JSON / 解析失败 → 丢弃本次补丁，记日志（不打断）；下次触发重试
- 网络失败 → 静默（照 AiClient 现有 transient 语义），周度/事件驱动下次补
- 成本：prompt ≤800 token + 返回 ≤200 token，DeepSeek 单次 <<0.01 美元，周度/事件驱动月成本可忽略

## 四、新增组件 3：补丁编译（PatchCompiler）

**职责**：API 返回的 `patch_rule` → 本地 `CausalRule` 钩子 → 追加账本新区块（不改历史，铁律③）。

### patch_rule → CausalRule 映射
| patch_rule | CausalRule schema |
|---|---|
| `condition`（语义条件） | `when.type=cooccur` + `atoms`（从 condition 提取的关键原子，如 [资金借出, 实体A, 书面协议缺]） |
| `action=INSERT_NODE` + `new_node.suggested_trigger` | `then.alert`（触发时提醒，如"建议：转账后 1h 生成书面协议"） |
| `confidence_boost` | `then.linkDelta`（命中给关联强度增量） |
| `hidden_variables`（诊断展示） | 存 `rule.meta.diagnosis`（rule 补 meta 字段，可展示给用户"因果助手建议"） |

### 落库
```
upsertRule(ruleId="patch_<uuid8>", label="因果补丁:<type>", when, then)
→ CausalEngine.upsertRule → _causal_rule 事件 + _causal_rule_block（evidence 含 patch_id/reason）
→ causal.query 可见活性规则 → 命中时 causal.record 触发 alert
```

### 用户可见
钩子命中 alert 文本即"因果助手建议"通知载体（v1 结构化的 alerts；UI 弹窗后置）。

## 五、触发时机

| 触发 | 条件 | 入口 |
|---|---|---|
| 事件驱动 | 新 `_causal_event` 带 `meta.outcome=negative`（逾期/冲突/遗忘） | record 后检查 + 触发 |
| 周度 | 复用 workflows `time_cron`（灭屏+充电窗口） | 新 `causal.reflect` 调度动作 |
| 用户主动 | `causal.reflect` 工具（"反思最近交往模式"） | ToolRegistry 新工具 |

## 六、实现要点（后续编码清单）

| 新文件 | 职责 | 关键方法 |
|---|---|---|
| `causal/NarrativeBuilder.java` | 脱敏叙事合成（纯 Java） | `static String narrate(CausalEngine, String room)` |
| `causal/CausalOracle.java` | API 归因封装（依赖 AiClient 接口注入，可测） | `JSONObject analyze(String narrative)` / `boolean shouldTrigger(JSONObject record)` |
| `causal/PatchCompiler.java` | 补丁→CausalRule 编译 + 落库 | `JSONObject compile(CausalEngine, String room, JSONObject patch)` |
| `toolprovider/` 加 `causal.reflect` | 用户主动触发归因 | handler → NarrativeBuilder → Oracle → PatchCompiler |

**测试（JVM 纯 Java）**：NarrativeBuilder 脱敏断言（无真名/数字）；PatchCompiler 映射断言（condition→when）；CausalOracle 用 fake AiClient 返回固定 JSON（注入 Brain 接口）。

## 七、验收（后续编码后）

1. 叙事生成器：因果图 → 脱敏文本，断言不含原文字符/金额数字
2. API 归因：fake Brain 返回补丁 JSON → PatchCompiler 生成 CausalRule + 账本区块
3. 端到端（JVM）：record 负面事件 → 归因 → 补丁钩子注册 → 命中触发 alert
4. 真机（可选）：`causal.reflect` 调 DeepSeek 出真实补丁

## 八、明确不做（本版）

- 不建自建云端/数据库；API 无状态
- 不改本地引擎核心（§2 四元组/哈希链/钩子/衰减）
- 不做贝叶斯置信度/反常度异常检测（蓝图 §3 的机制差异项，另案评估）
- 不做实体 type 字段（叙事用 meta.type 粗分，够用）
