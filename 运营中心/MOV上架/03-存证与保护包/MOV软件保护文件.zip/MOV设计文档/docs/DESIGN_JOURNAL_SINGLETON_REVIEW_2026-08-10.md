# Journal 单例收敛 —— 现状核查与剩余工作评估（2026-08-10）

> **性质**：队列三⑥ 欠账核查。结论先行：**计划所述核心问题（seq 重号）已被工单22 完整解决**，本稿核查实现 + 评估剩余可做空间。

## 一、计划 ⑥ 原描述 vs 实际现状

| 计划 ⑥ 描述 | 实际现状（2026-08-10 核查） |
|---|---|
| 全仓 5 处 `new Journal(...)` | ✅ 属实：BridgeKernel / AgentLoop×2 / CausalEngine / McpProvider / MovMcpServer / MarketEngine（6 处） |
| `synchronized` 实例锁跨实例失效 → seq 重号（实证 seq 6,6） | ✅ 工单22 已修：`SEQ_LOCKS` 静态 Map + roomsDir 路径级锁，全进程同路径共享 |
| 修法方向：单例注册表 `Journal.forRoom(dir)` 或 seq 分配改文件级锁 | ✅ 已走「文件级锁」路线（工单22），**单例收敛非必需** |

## 二、已落地实现（工单22 代码证据）

`Journal.java`:
- L72-73：`private static final Map<String,Object> SEQ_LOCKS` —— 静态，进程级共享
- L94-96：`append()` 内 `SEQ_LOCKS.computeIfAbsent(roomsDir路径)` → `synchronized(lock)` 包 `appendLocked` —— 跨实例串行化 seq 分配+写入
- L499+ `nextSeq()`：index 最后 seq+1 与 journal 尾部实际 max（`tailSeq` O(1) 尾读）**取 max** 兜底，杜绝 seq 复用

`JournalTest.java`:
- `concurrentAppend_twoInstances_noSeqDup()`：双实例并发 append 同一房间 2N 次，断言 seq 集合无重复（工单13 实证 seq 6,6 的回归防线）
- `concurrentAppend_seqIsContiguous()`：双实例并发后 seq 从 1 连续无空洞（文件级锁串行化验证）

## 三、验收对照（计划 ⑥ 要求）

| 要求 | 状态 |
|---|---|
| 并发 append 压测用例（多实例同房间并发写 → seq 唯一递增） | ✅ 已存在（上述两测试） |
| 变异（锁去掉 → 重号 → 用例必红） | ✅ 工单22 施工时变异亲杀过（还原绿，记录在 ACCEPTANCE_LOG 工单22） |
| 全量不回归 | ✅ 工单22 全量绿 |

## 四、剩余可选工作（非必须）

**方向 A：Journal 单例收敛**（架构整洁，可选）
- 现状 6 处 `new Journal(roomsDir)` 各持实例，靠路径级锁互斥。收敛为注册表 `Journal.forRoom(dir)` 可：
  - 消除 6 处重复实例的簿记开销
  - 让「每房间一实例」成为显式契约
- 代价：改动 6 处调用点 + 单例生命周期管理（App 重启失效需重建）——**影响面大、收益边际**，建议**不急于做**，留作未来重构。

**方向 B：seq 窗口防御**（可选加固）
- 当前锁是「内存 Map 的进程级锁」，同一 roomsDir 在**多进程**（若未来出现）下仍失效。但 MOV 单进程，无此场景。若未来加多进程，需文件锁（FileLock）。

## 五、结论

- **计划 ⑥ 的核心欠账已闭环**，无需施工。
- 建议：TASKBOARD 该条标记「已解决（工单22）+ 可选加固方向 A/B 记录在案」，不派新单。
- 本核查稿即 ⑥ 的交付物（验证计划状态过时 + 剩余空间评估）。

---
*程序员核查产出，供查验员复核。*
