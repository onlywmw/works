# MOV 验收员档案（Acceptance Log）

status: active

> 验收员独立于执行方（P1/P2/P3/P6）。本档案是验收员的**唯一产出落点**：验收结论、打回记录、判例、自纠记录都写这里，不再散落进任务文档。
> 铁律一句话：**不信自报，信实物**（见 docs/ACCEPTANCE_PLAYBOOK.md）。

---

## 角色与分工

| 角色 | 职责 | 落点 |
|---|---|---|
| 验收员 | 审每个 commit，按 L 级验收，不合格打回（附精确修法） | 本档案「验收记录」区 |
| 初验员 | P1/P3 的 L1/L2 commit 初验，验收员复核 | TASKS_P2_FIRST_VERIFY |
| 执行方 | 交付自验 ≠ 验收结论 | 任务文档「交付自验」区 |

**界限**：任务文档只放执行方的「交付自验」；验收员的「验收结论」只放本档案，任务文档/TASKBOARD 留指针。

## 验收流程（按需）

1. **触发**：执行方 commit 后**手动请验**（自动巡检已于 2026-08-03 取消，规则见 TASKBOARD）
2. **定级**：L1/L2/L3——拿不准往高定（定错级 = 验收事故第一来源）
3. **五招**：不信自报信实物 / 变异测试杀 mutant / 假覆盖四形态对照 / 真机证据链 / 打回可施工
4. **结论**：写入本档案「验收记录」+ TASKBOARD 状态更新；任务文档只留指针

## 验收记录

### 2026-08-08 工单21 MCP 工厂（`200862cd`+`2cfd6cf7`）— ✅ 通过（查验员六条逐项亲验）

> 执行：程序员会话｜复核：查验员。**工厂首件出厂，产线闭环成立。**

| 标准 | 查验员实证（非转述） |
|---|---|
| ① 需求→8389 真实调用 | ✅ 亲跑 MCP 全链：initialize 握手 mov/3.3.0 + 无 token 401 + tools/call pb.query 读回真实数据（中文无损）；Streamable HTTP SSE 流正常 |
| ② 坏拒收/好出厂 | ✅ 亲造坏工具（catch 吞错+无 Manifest+撞 sms 红线域）→ check-report **reject 三因齐全**；好工具 pass；verify RPT 10 项证据在案 |
| ③ 组合实证 | ✅ compose-spec 合成正确（input/output/deps/errors 合并、`_composition.synthesized:true` 在案）；设备上「买牛奶·组合实证」记录佐证组合调用真实发生 |
| ④ 单测+变异入仓 | ✅ PbToolProviderTest 9/9 亲跑（昨日已验） |
| ⑤ 协议合规 | ✅ check-report 协议项（SSE/弃用原语）零命中 |
| ⑥ 全量绿 | ✅ 独立重跑 2298 tests（1149×2）0 failures；JS 11/11；工厂自测全过 |

**流程注记**：pb 首品种走 feat/pb-tools 分支 → 查验后 cherry-pick 合 main（200862cd），工厂工件（schema/redlines/DRIVER/reports/specs/registry.jsonl）已同步 main——产线工件与产出同库可查。

**结论：MCP 工厂产线闭环成立（需求→施工→质检→报告→登记→8389 可调）。工单21 关闭。**

### 2026-08-07 工单23 CodeGraph 轻量版（`0a0f2199`）— ✅ 通过（查验员亲跑判分）

> 执行：程序员会话｜复核：查验员（全部亲手复跑，非转述）。

| 标准 | 查验员实证 |
|---|---|
| impact expertConfirm | ✅ 亲跑：hop1 = newface.js + history-delete/settings 两测试（与今日施工实况精确一致）；hop2 泛化为保守超集（契约内：误报可忍） |
| dead 判分 | ✅ 亲跑 mergeOnUpdate：dead=false，8 引用点全列（ModelRegistry:111/123 + 两测试文件行号全对）；streamAppend 死代码清理 grep 零命中亲验 |
| 漏报抽查 | ✅ refs/defs 行号与代码实况一致（T13-1 审查过的代码我认得） |
| 索引速度 | ✅ 亲跑 534 文件/7015 符号/362k 引用 = **0.6s**（门槛 2 分钟） |
| 变异/自测 | ✅ codegraph-self-test 全过（含引用边漏建→影响面崩拦截）；JS 11/11 亲跑 |

**兑现注记**：dead 查询首日上岗即抓出 streamAppend 死代码——「删函数前先查调用方」从人肉纪律变机器判定，正是本单立项初衷。

### 2026-08-07 TencentDB Agent Memory 调研（`20d97998`）— ✅ 通过（查验员外部抽查）

> 调研类交付，从宽从快：结构与官方 README 逐项对照一致——四类资产（Chat Memory L0-L3/Skill 审核配装/Wiki 链接图/CodeGraph 影响分析）、ACL 三档、冷启动、跨框架清单（OpenClaw/Hermes/Claude Code/CodeBuddy）全部对得上官方原文；对照 MOV 的定性（同构分层 + 缺 Wiki/CodeGraph/团队 ACL）准确。MOV 可借鉴点已记录：CodeGraph 轻量版进项目记忆（改前影响分析）。

### 2026-08-07 工单22 记忆层收官·果因引擎 1.0（幕一二三+收敛 `17539117` / 幕四+评测 `123f79d1`+`38c09c85`）— ✅ 通过（查验员终审）

> 执行：程序员会话｜复核：查验员（本会话，逐项亲验）。

| 项 | 结果 | 查验员实证 |
|---|---|---|
| 幕一 注入理解度 | ✅ | CausalPromptBuilder 事实注入 diff+测试在案；真机 answer.txt「张三还欠我钱」+ 思维链 amount:500 |
| 幕二 调用准确率 | ✅ | 6 例样本记录在案（serve invoke×3 + AgentLoop 内自主调用×2 + 思维链参数设计×1） |
| 幕三 自动抽取器 | ✅ | act3 证据亲读：user_input「我周三借了张三 500 块」→ `_causal_event{source:extractor, amount:500}` + 哈希索引 atoms 我/借给/张三——真抽取非显式写入 |
| 幕四 果因融合链 | ✅ | act4 证据亲读：reflect 全链 patch_7c5976c7 落库 + 账本区块 925f3098 + 二次命中活性 + 脱敏抽检（张三→实体A，金额未出现） |
| Journal 单例收敛 | ✅ | 修法=跨实例文件级锁（SEQ_LOCKS），5 处 new Journal 零改动；并发用例 40×2 无重号在案 |
| 评测机制（裁判） | ✅ | GOLDEN 12 题六类 + LEDGER 台账规则；**EngineGoldenEval 查验员亲跑 10/10 绿；变异亲杀亲手复杀**（CausalRule.matches 恒假 → T01/T02 红 → 还原绿）——评测真在测引擎 |
| 全量 | ✅ | 独立重跑 2280 tests（1140×2）；过程中 1 假红（MovInboundServerTest 绑 8388）查实系查验员自己 adb forward 占端口，撤 forward 复跑 23/23 绿——环境教训在案 |

**观察（轻项，不阻塞）**：① GOLDEN.md 执行命令写 `node run-eval.js` 但该文件不存在（真执行端是 JUnit EngineGoldenEval）——文档一行修正 ② 幕一「改天追问」跨日端到端未跑（当天注入→答对已证，跨日由 journal 持久化兜底）③ 计划 JSON 偶发解析失败为既有模型侧 flake（工单4 已知障碍），非本单引入。

**结论：果因引擎 1.0 闭环成立，工单22 关闭。**

### 2026-08-07 工单20 hermes.task 工具化（`3e98af9`）— ❌ 打回④（双项，附修法）

> 执行：程序员会话｜复核：查验员（本会话，独立重跑 + 真机亲跑探针）。

**✅ 通过项**：幕一 infer 通路证据链在案（8388 直连 48 / proot→8388 全链 63 + MOV 推理 logcat）；幕二注册件 diff 精读合格（plan 闸 + Manifest high/exec + 快慢搭档描述 + Linux 可用性 checkFn）；幕三证据链四段在案（sales.csv=1195.0 验算 ✓）；独立重跑 2236 tests（1118×2）0 failures + JS 11/11。

**❌ 打回④-1（hermes.task 未进 ESSENTIAL_TOOLS——缝里的 bug，查验员真机亲跑抓获）**：
- 实证：探针任务「执行 hermes.task：创建 probe_hermes.txt」→ 计划批准 → 执行 → `tool_call hermes.task arg:""` → `tool_result ok:false "goal 为空"`（journal r_t20_probe3 seq8/9 在案）
- 根因铁证（logcat MOV-DIAG 模型思维链原文）：「我需要理解 hermes.task 的参数格式。**工具列表里只有 "hermes: hermes.task**」——compact 模式（promptText 默认路径）下非 ESSENTIAL 工具只剩菜单行，模型看不到 `goal` 参数 schema → 只能空猜
- 这正是 causal 工具 `99d300d` 的同款病，派单纪律里「单测全绿 ≠ 真机能用」的又一实例：他们的 sales.csv 全链过是模型猜对了参数格式，我的探针是模型没猜对——**靠猜的链路就是断的链路**
- **修法**：`ToolRegistry.ESSENTIAL_TOOLS`（ToolRegistry.java:468）加入 `"hermes.task"`（一行）；补单测断言 promptText 含 hermes.task 完整参数文档（goal 必填）；变异亲杀；**真机复验**：新任务 → tool_call hermes.task arg 非空 → 产物落房

**❌ 打回④-2（证据脱敏红线）**：`act1-infer-evidence.txt` 明文写完整 X-Mov-Token（32 位全量）入公开仓库——T13-3 证据的脱敏规范是「head=aVWn」只露前 4 位。**修法**：证据文件 token 脱敏重打 + **serve token 轮换**（已进 git 历史视为泄漏）+ 抽查本批其他证据文件无同类问题。

**✅ 打回④修复复核通过（`b792bb6`，2026-08-07）**：
- ④-1：ESSENTIAL_TOOLS 加 hermes.task 一行 diff 在案；prompt 含 goal 参数文档的单测+变异亲杀在案；查验员独立重跑 **2238 tests（1119×2）0 failures**；真机复验（goal 非空 + DONE + 产物落房）截图在案
- ④-2：旧 token 全仓 grep 零残留亲验；**轮换由查验员亲手复验**——旧 token 调 8388 亲得 `UNAUTHORIZED token 无效`（fail-closed），新 token 亲得 `3 × 3 = 9`

**观察（非打回）**：① gate_respond 重复批准已批闸会重复落 journal 事件（幂等性可加固，查验员自动化脚本踩出）② 计划闸超时自动停止机制工作正常（「计划超时未批准, 自动停止」在案）③ 探针房间已清理。

---
### 2026-08-07 批次1 叙事统一包（`a0246e2`）— 部分通过：**工单19 ❌ 打回**（视图层不进房），工单18/17打回②/顺手①② ✅

> 执行：程序员会话｜复核：查验员（本会话）。

**✅ 通过项**：
- **工单18 文案**：`专家模式|新脸|专家` 用户可见串零命中亲验（残留全为注释/标识符）；真机顶栏「任 务」+「返 回 首 页」在案
- **17打回②**：`74445ee` 已在 main——`currentWatchingContext()` 读 watch_history 取最新条目注入「[当前情境：在看《仙逆》· 第 22 话]」，失败静默，diff 精读在案
- **顺手① 竞态**：BridgeKernel 等 loop 终态（100ms×30）+ Journal deletedRooms 拒重建，双保险在案（观察：Journal 层防御是实例级的，loop 临终 append 走 AgentLoop 自己的 Journal 实例——真正生效的是等终态那一重；实例级 gap 与 seq 竞态同属 Journal 单例收敛欠账）
- **顺手② 失败文案**：「出了点问题」清零，AgentLoop.java:548「任务失败：<原因>」在案
- **全量**：独立重跑 2224 tests（1112×2）0 failures；JS 11/11 含新 newface-entry-unify

**❌ 打回③（工单19 核心项，附精确修法）**：两个新入口**只进数据层不进视图层**——
- 实证：真机 CDP 点左侧栏历史条目 → `curRoomId` 已置（数据层进房）但 `expertPane.style.display=none`，屏幕停在首页；交付卡 `gotoDelivery` 带 roomId 路径同样直调 `expertOpenRoom`，同病
- 根因：`expertOpenRoom`（:expertOpenRoom）只切 pane 内部子视图，**不含面板显示序列**（`switchToExpert` 里的激活 view-face/隐藏 faceCover/`pane.style.display='flex'`）；两个新入口都绕过 `switchToExpert` 直调它
- 程序员自证截图 01 其实拍到了 bug：房间内容投到首页封面（顶部无房间顶栏、底部是首页输入胶囊）——误读为「进房成功」，教训：证据截图要看承载容器
- **修法**：抽公共 `showExpertPane()`（激活 view-face + 隐藏 cover + pane display flex + 默认子视图），`openRoomFromHistory` 与 `gotoDelivery` 带 roomId 分支都先调它再 `expertOpenRoom`
- **复验**：两入口各点一次——截图必须见房间视图顶栏+会话流+房间输入框；房间内真发一条消息闭环

**✅ 打回③修复复核通过（`eba0535`，2026-08-07）**：showExpertPane() 公共显示序列抽取照修法（switchToExpert/expertOpenRoom 统一调，diff 精读在案）；查验员真机复验——历史条目点按 → pane=flex + 房间视图三要素齐（顶栏「create a fil…」‹返回 / alpha-beta 会话流 / 房间输入框「追问一句…」），截图亲见程序员房内真发「room check ok 73921」agent 承接 file.write 完成。断言五连+变异亲杀在案，JS 测试查验员亲跑过。**工单19 关闭。**

---
### 2026-08-07 工单17 首页对话连续性（`3fb86d7`）— ✅ 主体通过 + 打回一项（§六 未施工）

> 执行：程序员会话｜复核：查验员（本会话，五条标准逐项 + 补充条款核对）。

| 标准 | 结果 | 查验员实证（非自报转述） |
|---|---|---|
| ① 三轮同屏 | ✅ | 真机 CDP 亲聊三轮（记代码 blue-whale-42 → 法国首都 → 追问代码）：轮3 答对且引用更早内容；封面 **6 个 utter 节点（3 问 3 答）同屏累积** |
| ② 73921 全链 | ✅ | 亲跑全流程：r_home journal 落盘 19 行亲见 → `am force-stop` → 重进 → 追问答出 blue-whale-42 **外加更早的 73921**（懒重建连上批测试都捞回来了，方案 b 扎实） |
| ③ 同房派活 | ✅ | 截图 05 亲见 alpha/beta 两任务同房间流内；`_homeHandoff`/`_homeRoomId` 复用逻辑 diff 在案（ROOMS.some 守卫防野指针） |
| ④ 全量绿+变异 | ✅ | 独立重跑 2218 tests（1109×2）0 failures；JS 10/10 含新 newface-chat-continuity；变异 3 连自报在案 |
| ⑤ 回归 | ✅ | face_history 跳 r_home diff 在案（MemoryToolProvider +2）；左侧栏/房间列表/已中断语义不劣化 |
| 顺手修复 | ✅ | openConnect 导出补漏（工单14 遗留）grep 在案 :3734 |

**打回②（§六 升级情境注入未施工，附修法）**：派单文档 §六（e7f87db 补充）要求「短→长升级必带情境」——追剧中途升级开房时注入 watch_history 当前条目（在看什么/第几集）。交付 diff 中 autoHandoff 仅置 `_homeHandoff=true`，**无情境注入**，汇报亦未提。**修法**：autoHandoff/handoffToExpert 拼 ctx 时读 `B.query({q:'watch_history'})` 当前在看条目（或在追情境卡数据），以 `[当前情境：在看《仙逆》第 22 话]` 形式注入新房间首条上下文；验收照 §六 追加条款实证（追剧中途说「写观后感」→ 新房上下文含剧集集数）。

**观察（不修）**：r_home 现含验收测试对话（blue-whale-42/73921 等），用户可在 设置→清除对话记录 清掉；05 截图里驳回后「任务失败：出了点问题，已记录」文案偏笼统，轻观察留档。

---
### 2026-08-07 工单14 设置页用户视角重做（`dbab066`）— ✅ 通过 + 轻打回一项（查验员终审）

> 执行：程序员新会话｜复核：查验员（本会话，按派单文档六条验收标准逐项）。

| 标准 | 结果 | 查验员实证（非自报转述） |
|---|---|---|
| ① 截图对照 demo | ✅ | 03 一级页/04 模型页/08 清除 sheet 逐张亲对 demo：8 行结构/模型卡+用量条收二级/清除三项并列，一致 |
| ② 术语 grep 清零 | ✅（1 漏网） | `大脑\|意图路由\|场景卡\|TOKEN` 非注释**零命中**亲验；`A2A` 设置区仅注释。**漏网**：`newface.js:1805` 买家侧卡片流残留用户可见文案「配对入口已移至 设置 → 🤝 A2A」——指向已不存在的旧位置 + 违禁词 + emoji（轻打回①，见下） |
| ③ 迁移映射在案 | ✅ | rooms.orphan/cleanup 系统页带确认（工单15 遗留入口已并）/ tokenStats→「本月用量约 N%」/ MOV_APP_VERSION=3.3.0 与 build.gradle versionName 一致亲核 / mov_theme 三态 / clearRecordsSheet / vaultList 逐项 grep 在案 |
| ④ 新人路径回归 | ✅ | 真机装机后 CDP 亲点：AI 模型页 → 添加模型 → **表单渲染 API Key 输入框在**；桥零新增 AgentLoop 未动 |
| ⑤ 全量绿+变异 | ✅ | 独立重跑 2210 tests（1105×2）0 failures；JS 9/9 含新 newface-settings.test.js 8 组；变异亲杀 3 连自报在案 |
| ⑥ 真机三闸抽查 | ✅ | 深色切换亲验 bg rgb(253,253,251)→rgb(20,24,15)→恢复浅色；保险柜页锁定态+解锁查看+加密说明在；清除 sheet 截图在档。修复过程发现并解决的 openSettings 无限递归（STARTUP_ERROR）属实——真机 openSettings 可用即证 |

**轻打回①（一行修，不阻塞本单关闭，下批顺手）**：`newface.js:1805` 「配对入口已移至 设置 → 🤝 A2A」→ 改「配对入口在 设置 → 高级 → 设备协作」（去 emoji 去术语指对路）。**✅ 已修 `97ee9fa` 复核关闭**（diff 恰好一行 + 全文件 🤝/A2A 残留 grep 零 + newface-settings 测试过）。

**结论：工单14 通过。** 设置页从代码模块图投影变为用户任务导向，DeepSeek 式清单达成。

---
### 2026-08-07 工单15 孤儿房间对账（`054a204`）+ 工单16 onboarding 订正（`77be6fc`）— ✅ 双过（查验员复核）

> 执行：程序员会话｜复核：查验员（本会话，独立重跑+真机实测）。

**工单15**（孤儿房间目录对账清理）：

| 项 | 结果 | 查验员实证 |
|---|---|---|
| diff 精读 | ✅ | `orphanRooms` = 磁盘目录 − `roomIds()`（有 journal.jsonl 才算有效房间，依赖核实 Journal.java:214）；`rooms.orphan`/`rooms.cleanup` 桥两命令；测试断言真实行为（含负例「有效房间不算孤儿」），变异亲杀自报在案 |
| 独立重跑 | ✅ | cleanTest 后双变体 **1105×2 = 2210 tests 0 failures**（含新增 orphan 例） |
| 真机实测 | ✅ | 手工塞无 journal 孤儿目录 → CDP `rooms.orphan` 检出 → `rooms.cleanup` 首跑 **cleaned:0（如实返回）**——查出系探针目录 root 属主 app 无权删（探针制作瑕疵，非代码 bug）；修正属主后复跑 **cleaned:1 → 复查 orphans:[] → 磁盘目录消失** |

**定义差异在案（不打回）**：orphan 定义 = 磁盘有目录但无有效 journal；「e8f6409 前专家模式删房（localStorage 删、journal 完好）」的残留**不算孤儿、不在清理范围**——此类房间在左侧栏可见可删（长按删除链已通），保守防误删合理。**遗留**：清理入口 UI 未做（commit 只到桥层），建议并入工单14 幕二「高级→系统」页加一行「清理残留房间」，届时真机复验 UI 链。

**工单16**（onboarding 订正，docs-only）：adb 真路径与本机实证一致（`platform-tools/platform-tools`，AppData 路径不存在已亲证）；「改 assets 重进即生效」错误说法订正准确（HermesActivity.java:236 `file:///android_asset/` 加载）；CDP 复验手法入 ACCEPTANCE_PLAYBOOK §2——本会话三个根因均靠此手法实锤，内容属实。✅

**附带观察**：真机 rooms 目录较上午少两个（r1786062930492/r1786068910274）——用户已自行用左侧栏长按删除两条真实房间，删除功能真实使用中。

---
### 2026-08-07 工单13 无聊工程小包四项（`37f9ae7`/`c150acb`/`4ac1e01`/`e8317cc`）— ✅ 通过（验收员终审）

> 执行：p4 会话｜复核：验收员（本会话，独立复跑+亲验）。**上线前「无聊工程」四件套收官：新人路径/崩溃恢复/升级回归/分发规范。**

| 项 | 结果 | 验收员实证（非自报转述） |
|---|---|---|
| T13-1 新人路径 | ✅ | diff 精读：`brainErrorMsg` 按 errorClass 透传（AUTH→点名 API Key+指引，其余保持通用文案不误导）、`mergeOnUpdate` 纯函数保留非表单字段、`_msave` 空 key 拦截（ollama 豁免合理）；测试为真实行为断言非字面量比较；截图 02 亲见失败卡含「API Key 无效或已过期…模型管理」——截图里看得到断言的那件事 |
| T13-2 崩溃恢复 | ✅ | `roomBadge` 叠加 `agent_state`（BridgeKernel:334 case 在案，`getStateJson` 含 active/roomId 字段核实匹配）；崩溃 journal 原件亲验 **12 行 0 坏行**；截图 01 亲见崩溃房「已中断」灰徽章+完成态房间无 badge |
| T13-3 升级回归 | ✅ | install -r 前后四组对照文件**验收员亲手 diff 全一致**（房间/journal 行数/交付物 sha256/模型配置+token）；检查单 10 项可施工；vault_lock 需锁屏 PIN 如实记人工项（安全设计非缺陷） |
| T13-4 分发规范 | ✅ | RELEASE_PROCESS 仅文档未执行（如实）；versionCode 规则（30301 起跳只增不减）/keystore 不入库/changelog 面向用户/发布前 6 项 gate 引用升级回归单，闭环成立 |
| 全量复跑 | ✅ | 验收员独立 `assembleDebug test`：**2202 tests（1101×2 变体）0 failures 0 skipped**；JS 回归 `newface-save-guard`+`newface-expert` 亲手跑过 |

**验收员顺手修（在案）**：`UPGRADE_DATA_CHECKLIST.md` 基线命令端口笔误 `8398`→`8388`（MovInboundServer.PORT=8388；照单抓药必落空）。

**发现登记（非本单引入，不打回，欠账区候选）**：崩溃 journal 原件 seq 出现 **6,6 重复**（phase/gate 各一条）。根因：`Journal.append` 是 `synchronized` 实例锁，但仓库有 5 处 `new Journal(...)`（BridgeKernel/AgentLoop×2/CausalEngine/McpProvider/MovMcpServer 各持实例），跨实例并发 append 时 `nextSeq` 读-改-写竞态 → 重号。闸批准（UI 线程走 BridgeKernel 实例）与 phase 事件（AgentLoop 实例）并发即踩中。影响面目前轻微（readAfter/search/roll 均容忍；无丢事件无坏行），但「seq 唯一递增」假设不实，建议后续派单：Journal 收敛单例（或 seq 分配改文件级锁/全局原子）。证据：`t13-2-crash-recovery/02-crash-journal.jsonl` 行 7/8。

**遗留观察（如实）**：证据 md 称「无 seq 断号」——断号确实无，但重号未提及；证据采集时用「断号」措辞侥幸避过，提醒后续证据校验把「重号」也纳入检查项。

---

### 2026-08-07 工单12 幕四 A 线全链（`9457458`+`ee51b74`）— ✅ 通过（验收员变异亲杀 + 证据核验）

> 执行：p3 + 验收员（mmproj 自转部署）｜复核：验收员。**端侧视觉 OCR 全链打通——隐私通道与记忆层合流。**

| 件 | 结果 | 实证 |
|---|---|---|
| mmproj 支持 | ✅ | `buildServerCommand` 纯函数含 --mmproj；**验收员亲杀**：删 mmproj append → `buildServerCommand_includesMmproj` 唯一红（14 tests 1 failed）→ 还原绿 |
| 视觉识别真文本 | ✅ | 500「image not supported」消失；golden1 文档 → 标题/修订日期/三条条款带坐标真文本，与 golden 一致（证据 p12-ocr-e2e-evidence.md） |
| 全链 | ✅ | OCR 文本 → fitnessIngest（fitness 域 seq=136）→ weekly_narrative 三段式（趋势/异常/建议） |
| 质量修复 | ✅ | OkHttp readTimeout 10s→300s（视觉推理超时，如实记录） |

**路径注记**：mmproj 由验收员在 Windows 侧从设备 HF 权重自转（baidu/Unlimited-OCR 视觉塔，476 tensors/826MB）并部署——A 线（llama-server 视觉）自此成为正线，B 线 MNN 管道（峰值 10.2GB OOM）退役观察。

**工单12 健身竖闭环数据层全通：真实 OCR（本地）→ 域记忆 → 叙事。剩幕三新脸健身卡（面子工程）。**

### 2026-08-06 工单12 健身竖闭环 MOV 侧（`4830742`）— ✅ 通过（验收员变异亲杀）

> 执行：p3 ｜复核：验收员。幕一/幕二 MOV 侧闭环；幕三/幕四移交新会话。

| 件 | 结果 | 实证 |
|---|---|---|
| 幕一 fitnessIngest | ✅ | 文本 → fitness 域 `_tool_receipt`（tool=ocr.local）落 journal + serve `/memory fitness_ingest`；**验收员亲杀**：删空文本拒写 → `fitnessIngest_emptyText_rejected` 唯一红 → 还原绿 |
| 幕二 周叙事 | ✅ | `weeklyNarrativePrompt` 纯函数（趋势/异常/建议，含记录/空头双例）+ serve `/memory weekly_narrative`（fitness 域近 7 天 → 默认模型提炼） |
| 欠账（如实） | 登记 | 幕三新脸视图（assets JS 大改）；幕四真机+PII（OCR 真实识别依赖 llama-server 就绪，守「不假识别」红线） |

**意义：健身竖闭环的数据层打通——文本进域记忆、域历史变叙事的通道已就绪，差 OCR 真实识别与前端视图两个面子。**

### 2026-08-06 工单10 root 工具层（`a52c048`）+ 工单11 kimi MCP 握手（`b8f6bdb`）— ✅ 通过（验收员变异亲杀）

> 执行：p3 ｜复核：验收员。

| 件 | 结果 | 实证 |
|---|---|---|
| root 通路 | ✅ | KernelSU uid=0 真机在案（p10-root-ui-evidence.md） |
| UI 三件套 | ✅ | ui.dump 经 8388 真机拉取控件树（package/bounds 实证）；DANGEROUS 闸（approval=plan, risk=high）；ui.tap 截图断言留补（机制与 ui.dump 同通路已验，观察项） |
| **红线黑名单** | ✅ | 真机实测微信包名 → `PERMANENT_DENIED`；**验收员亲杀**：isDenied 改恒放行 → `deniedPackages_rejected`+`deniedActions_rejected` 双红（5 tests 2 failed）→ 还原绿 |
| 工单11 MCP 握手 | ✅ | 解法 `.mcp.json` 加 `type:"http"`（Claude Code 兼容格式）；kimi-code 会话 tools/list 真见 MOV 工具（p11 实录）；memory.cover 直接调用未在会话完成（脚本化 httpx 实证替代）——记欠账 |

**里程碑：设备控制升格完成（能打开→能操作，带硬红线）；宿主化全链通（客居脑经 MCP 读到 MOV 工具）。**

### 2026-08-06 工单7 P1 四项（`2404776`）+ 幕二实测（`096625d`）— ✅ 通过（验收员双变异亲杀 + 证据核验）

> 执行：p3 ｜复核：验收员。

| 件 | 结果 | 实证 |
|---|---|---|
| G10 expire 幂等 | ✅ | **验收员亲杀**：删幂等判定 → `expireStaleDrafts_idempotent` 唯一红（39 tests 1 failed）→ 还原绿 |
| G8 span 指纹 | ✅ | **验收员亲杀**：指纹改常量 → `cover_spanFingerprint_noFalseCacheHitAcrossBatches` 唯一红 → 还原绿 |
| G7+G6 脱离 tail500 | ✅ | diff 亲读：promotedDraftSet/memoryDrafts/cachedSummary 全改 eventsOfType 全量重建（滚动后不丢） |
| G4 双脑读一致 | ✅ | DualBrainReadConsistencyTest 行为测试（§分隔投影）+ 防分叉扫描 |
| 幕二实测（096625d） | ✅ 部分 | **已证**：Kimi Code 0.33.0 proot 运行 + LLM 真实推理回包（api.kimi.com 经代理）+ 三件套 MOV 侧真机生效（AGENTS.md 投影 2 条真记忆 / skills.sync 导出 2 技能 / memory 工具入只读集）。**欠账**：kimi-code 未读 .mcp.json（MCP 客居脑握手未通）——如实记录转欠账，待 kimi-code MCP 配置方式确认 |
| 纪律 | ✅ | 两批分开 commit 分开 hash；key 零入库；验收员条目原样入档 |

**至此：批1 记忆层 P0+P1 缺口全清（G1-G10 落地），工单9 宿主化幕一闭环 + 幕二三件套 MOV 侧生效 + 客居脑 LLM 走通。**

### 2026-08-06 工单9 幕二三件套 MOV 侧使能（`6a934d3`）— ✅ 通过（验收员变异亲杀）

| 件 | 结果 | 实证 |
|---|---|---|
| a. MCP memory 只读工具 | ✅ | memory.cover/memory.search 补入 MemoryToolProvider（access=readonly → 8389 只读集） |
| b. skills.sync 桥 | ✅ | 接缝 exportSkills（Supplier+Function 注入）；**验收员亲杀**：跳过复制 → `exportSkills_copiesFiles` 唯一红 → 还原绿 |
| c. generateGuestContext 桥 | ✅ | memoryCover → exchange/AGENTS.md 记忆段；guestContextText 核心可测；写回仍走 8389 审批闸 |
| 纪律 | ✅ | 6 文件边界干净；key 零入库；我的幕一打回修复条目原样入档 |

**Kimi Code 0.33.0 proot 运行成功在案**（p9-cli-install-blocked.md；Claude Code native/proot Bus error 定案不兼容）。客居入驻实测（三件套 e2e）进行中。

### 2026-08-06 工单9 幕一单表化打回修复（`65b8fc5`）— ✅ 通过（验收员行为级变异亲杀）

| 验收项 | 结果 | 实证 |
|---|---|---|
| 可测接缝 | ✅ | `activateBuiltinSkills(registry, nameProvider, reader)`（Supplier+Function 注入，生产传 assets 读取器逻辑原样搬，RegistryProvider.java:104） |
| 行为测试 | ✅ | 假读取器→注册表含 skill.echo→8388 invoke 200 回显——生产接线全程串联，不再绕过 |
| 变异亲杀 | ✅ | **验收员亲手**：接缝跳过激活循环 → `activateBuiltinSkills_behavioral_e2e` 唯一红 → 还原 BUILD SUCCESSFUL。文本级存活点根治 |
| 设备侧收尾 | ✅ | 验收员旁证：8137 监听/进程已清（netstat 零）；默认模型已还原直连 |
| 日志入档 | ✅ | 验收员条目原样一字未改 |

**工单9 幕一闭环**：单表化（行为级守护）+ 出网网关 + PII 闸 + Bearer + 目录根治。

**🔴 环境阻塞（新，优先于幕二）**：平板 app 进程 DNS 无法解析外网域名（`Unable to resolve host api.deepseek.com`；ping 通=内核 ICMP 正常，app 网络栈 DNS 失败）——疑为已知「WiFi 重连回写代理」复发。影响：MOV 快脑/网关出网全断。**待用户查平板 WiFi 代理/DNS 设置后恢复**（证据 docs/device-acceptance/2026-08-06/p9-device-cleanup.md）。

### 2026-08-06 工单9 幕一（`a1da6f0`+`93cc772`）+ 根治单（`581beba`）— 网关/Bearer/根治 ✅ ｜ 单表化 🔴 轻打回

> 执行：p3 ｜复核：验收员亲手变异三轮。

| 件 | 结果 | 实证 |
|---|---|---|
| 根治单（目录残留统一） | ✅ | 验收员变异：AgentLoop 296 行改回 filesDir/rooms → JournalDirConsistencyTest 红 → 还原绿。源码扫描用于「模式禁令」成立（该守卫管的就是源码字面规约） |
| 出网网关 `/v1/chat/completions` | ✅ | OpenAI 兼容 + **PII 闸验收员亲杀**：删 PiiScrubber → `gatewayScrubsPiiBeforeEgress` 唯一红 → 还原绿。拍板 E（PII 闸）就此落地 |
| Bearer 并列鉴权（93cc772） | ✅ | 3 行，fail-closed 语义不变（同 token 比对）；真机证据 p9-serve-gateway.txt：修复前 401 → 修复后 serve 任务 done 输出计划 JSON——**serve-chain 欠账（proot 直连不通）销账** |
| **单表化（RegistryProvider 激活内置技能）** | 🔴 轻打回 | **验收员变异存活**：`skills=null` 跳过激活 → 测试全绿。原因：RegistrySkillsConsistencyTest 是源码文本扫描（`contains("SkillActivator.activate")`），MovInboundServerTest 的 skill.echo 用例手动 activate 绕过生产接线——生产接线（assets 读取→激活）无行为测试守护，撞假覆盖形态③字面量比较 |

**单表化打回修法**：把资产激活抽成可测接缝——package-private 方法接收「名称→字节流」读取器（生产传 assets 实现），测试喂假读取器 → 断言注册表含 skill.echo 且 8388 invoke 通；变异（跳过激活）必须红。文本扫描测试可保留作辅助，但行为测试必须存在。

**观察项（不阻塞）**：① 设备侧 MOV 默认模型 base_url 仍指 127.0.0.1:8137 取证代理（G14 取证遗留），需还原直连 + 杀代理进程；② 网关对全部消息过 PiiScrubber，system prompt 中正常数字串可能误伤，v1 接受。

### 2026-08-06 G14 打回修复（`c8e0f9b`）— ✅ 通过（验收员真机旁证）

| 验收项 | 结果 | 实证 |
|---|---|---|
| 根因修复 | ✅ | `memoryCoverSuffix` 改 `StorageManager.getRoomsDir()`（AgentLoop.java:984），与 serve/McpProvider/真机 journal 同目录 |
| 真机复验 | ✅ | 证据 `g14-reverify-pass.txt`：执行步请求含【记忆】段原文（两条草案 § 连接）；**验收员旁证**：testroom journal 确在外部存储、修复后任务真实跑通（seq 134/135 deliver+telemetry，promptTokens 11664 与含记忆段大 prompt 吻合） |
| 日志入档 | ✅ | 验收员三条目原样提交一字未改 |

**新发现（p3 自报，派根治单）**：`compressTranscript` L2 抢救草案仍写内部 filesDir/rooms（AgentLoop.java:1096）——同类目录不一致，抢救草案进了 memoryDrafts 从不读的目录 = 抢救失效。要求全仓排查 filesDir/rooms 同类残留一并根治。

### 2026-08-06 真机证据链轮（`f31dd51`）— 工单8/exportModels ✅ ｜ PII ⚠️ 转欠账 ｜ **G14 🔴 打回**

> 执行：p3（真机 21770d7d）｜复核：验收员。证据：docs/device-acceptance/2026-08-06/g15-evidence-chain.md 等 4 件。

| 项 | 结果 | 实证 |
|---|---|---|
| 工单8 mem.domain 查询链 | ✅ | _tool_receipt 四字段 + domainCover 按域历史真机通；调工具环节受 McpProvider.discover 环境阻塞（如实记录） |
| exportModels 自清 | ✅ | 内部 filesDir 落账 / 外部无明文（工单5 遗留销账） |
| PII 闸（拍板 E） | ⚠️ | distill 出网未过 PiiScrubber——**转欠账，工单9 幕一网关落地时必须带上** |
| **G14 真机缺陷** | 🔴 打回 | `memoryCoverSuffix` 用 `filesDir/rooms`，生产房间在 StorageManager 外部目录——**目录不一致 → cover 恒空 →【记忆】段从未注入**。单测绿（注入临时目录）真机红，正是「单测全绿≠真机能用」判例。修法：目录解析对齐 StorageManager；复验：真机 prompt 含【记忆】段 |

### 2026-08-06 工单8 域记忆移植 v1（`fb920e8`）— ✅ 通过（验收员变异亲杀）

> 执行：p2 ｜复核：验收员。**用户「MCP 工具数据主权」方向首个落地件。**

| 验收项 | 结果 | 实证 |
|---|---|---|
| 信封截取 | ✅ | `_tool_receipt` 四字段（tool/domain/ts/payload 原文）；截取点 McpProvider callTool 出口（工具零配合）；失败/空不落账 |
| domain 兜底链 | ✅ | `effectiveDomain()`：domain→manifest→toolset→other；构造重载兼容旧调用 |
| 弃用连续性 | ✅ | 测试实证 fitbit 弃用→oura 同域续写→历史无断裂 + domainCover 预算塌缩 |
| 变异亲杀 | ✅ | **验收员亲手**：toolReceiptEvent 改恒 null → 3 红（envelopeThreeFormats/domainFilterIsolated/toolDeprecationContinuity）→ 还原 5 绿 |
| 计数 | ✅ | XML 亲数 **debug 1059 / 0 failures** |
| 撞车处理 | ✅ | p3 在途测试锁 tmp 曾阻塞全量，协调后解决；双线 commit 边界干净 |

**文档-代码出入（已在 DESIGN §八 注明，追认）**：① MCP 动态发现无法逐工具声明域 → v1 同域 `biz`（合理降级，后续 server 元数据协商再细分）；② 域投影走新增 `domainCover`，不动 memoryCover 核心。

### 2026-08-06 工单7 幕二 G15：serve /memory distill 懒生成入口（`044527c`）— ✅ 通过（验收员变异亲杀）

| 验收项 | 结果 | 实证 |
|---|---|---|
| scope 锁定 | ✅ | 仅 serve 端点 + Brain 适配 + 3 单测（workflows 触发器/桥未做，符合派单 scope） |
| Brain 适配 | ✅ | ModelRegistry 默认模型 → AiClient → Journal.Brain（复用 /infer 模式）；无默认模型 → NOT_CONFIGURED |
| 变异亲杀 | ✅ | **验收员亲手**：runDistill 改恒 skipped → `runDistill_withFakeBrain_injectsFrozenSummary` 唯一红（19 tests 1 failed）→ 还原绿 |
| 施工纪律 | ✅ | 只 add 2 文件，未碰 p2 在途；no-context/负路径覆盖 |

**至此批1 记忆层读侧双断线（G14/G15）全部接通。** 遗留：真机证据链（G14 注入实测 + G15 真模型提炼 + 工单8 MCP 落账）合一轮装机做；PII 闸（拍板 E）随真机轮一并验。

### 2026-08-06 工单7 幕二 G14：memoryCover 注入 AI 上下文（`23645d4`）— ✅ 通过（验收员变异亲杀）

> 执行：p3 ｜复核：验收员亲手变异。**意义：记忆层读侧断线接通——「灵魂上身」第一刀落地。**

| 验收项 | 结果 | 实证 |
|---|---|---|
| 注入点正确 | ✅ | `buildStepInput` 记忆草案指令后接 `memoryCoverSuffix()`（与 causalMemorySuffix 同模式并列）；房间无草案/空覆盖 → 返回空串不占 token；纯读 journal 无副作用；失败静默降级 |
| 覆盖语义 | ✅ | 走生产函数 `Journal.memoryCover(roomId, COVER_BUDGET_DEFAULT=20)`（常量亲见 Journal.java:905），§ 连接成【记忆】段——预算内逐字/超预算塌缩的已验收算法，无新逻辑 |
| 可测性 | ✅ | `setMemoryJournal` 测试注入临时目录（仿 causal 模式），纯 JVM 可测 |
| 变异亲杀 | ✅ | 验收员删 `+ memoryCoverSuffix()` → `memoryCoverInjected_roomWithDrafts_promptContainsMemory` 唯一红（36 tests 1 failed）→ 还原 BUILD SUCCESSFUL；空房间负例 `emptyRoom_noMemoryInjection` 在案 |
| 施工纪律 | ✅ | 3 文件 +91/-1，边界干净；P0 验收条目原样入档 |

**后续观察项**：注入发生在每步工具调用的 step input——多步任务会重复携带【记忆】段（≤20 条+塌缩，量级可控）；DESIGN 若改「仅计划步注入」另行派单。G15（distill 调度入口）为下一刀。

### 2026-08-06 工单7 幕二 P0：G1+G2 记忆层存取缺陷（`7964591`）— ✅ 通过（验收员双变异亲杀）

> 执行：p3 ｜复核：验收员亲手变异两轮。

| 验收项 | 结果 | 实证 |
|---|---|---|
| G1 tombstone 重 add 压制 | ✅ | 修法=按 seq 生效（`removedAfter != null && draftSeq < tombstoneSeq` 才排除，Journal.java:853）；**验收员亲杀**：改回无条件压制 → `tombstoneDoesNotSuppressReAdd` 唯一红（35 tests 1 failed）→ 还原绿 |
| G2 index 落后 journal 的 seq 复用 | ✅ | 修法=`max(fromIndex, tailSeq+1)`，tailSeq 反向尾读 8KB 窗口取实际最大 seq；**验收员亲杀**：tailSeq 改恒 0 → `append_doesNotReuseSeq_whenIndexBehindJournal` 唯一红（26 tests 1 failed）→ 还原绿 |
| 施工纪律 | ✅ | 先红后修；3 文件边界干净（未碰 assets/、未碰 G3-G16）；基于并行提交 6fa2161 无撞车 |

**观察项（不阻塞）**：① 首轮全量 `AgentLoopTest.stopDuringExecution` 偶发红（release 变体同用例绿，重跑绿）——flaky 时序测试，与 Journal 改动无关，登记待后续加固；② p3 在幕一期间曾提前施工 G2（越权一次，已告诫，验收时点追认）。

### 2026-08-06 工单6 W1 inline 清零 + 追剧跳外修复（`6c1a4d4`）— ✅ 通过（验收员，含方案修正批准）

> 执行：p2 ｜复核：验收员独立抽验 + 变异亲杀 + 真机证据核验。

| 验收项 | 结果 | 实证 |
|---|---|---|
| 任务A inline 清零 | ✅ | 验收员亲数 `style=` 116→**17**，逐条核剩 17 处全为契约允许动态值（animation-delay/background/color/width）；newface.css 新增 101 行类；diff 仅 style/class 行 |
| 防回归测试 | ✅ | **验收员两轮变异**：① `.style.fontSize=` 注入存活（定位：测试只扫 HTML 模板 `style="` 词法，非 JS 属性赋值——变异体写法出界）② 修正变异体 `style="font-size:12px"` 模板注入 → **红**（AssertionError L3361 精确命中）→ 还原 PASS |
| 任务B 方案修正 | ✅ 批准 | p2 以真机证据推翻 iframe 方案：91mayitv 全站 XFO SAMEORIGIN（跨域 iframe 必被拦，与验收员先前分析一致）+ ConnectWeb 直开播放页实测硬解渲染 75s+（logcat c2.qti.avc.decoder 持续 Render，pid 5888）+ 截图实证播放中；**真实跳外源头 = newface.js:1578「一键观看」误用 _a2aOpenPayLink**（2026-07-31「一键观看必须内嵌」打回漏网），已改 _openConnectUrl。证据：桌面 MOV调试/工单6/mayi_play_evidence.log + mayi_play_t0.png |
| 计数 | ✅ | JUnit XML 亲数 **1045/0**（debug）；node newface-inline 亲跑 PASS |
| 施工纪律 | ✅ | 仅 3 文件 +245/-106；未碰 p1/p3 区域 |

**方案修正定性**：原派单「方案 C iframe」被证据否决，实际修复路径 = 修真实跳外 bug + ConnectWeb 内嵌兜底。**批准**，TASKBOARD P1 #7 方案 C 条目按此销账（不再要求 iframe 硬实现）。

**新发现欠账（派 p2 小修）**：`newface-expert.test.js` 在 main 上 pre-existing FAIL（`linuxStateText is not a function`，上个 commit 亲验同样缺、本 diff 未碰）——派单№9 遗留断言，非本次引入。

**观察项**：inline 防回归测试仅扫 `style="` 单行词法，`style ="`（带空格）或 `style='...'`（单引号）可绕过——契约层约定可接受，入档备查。

### 2026-08-06 工单5 技术债五小项（`e45b3f7`）— ✅ 通过（验收员）

> 执行：p1 ｜复核：验收员独立抽验 + 变异亲杀。

| 验收项 | 结果 | 实证 |
|---|---|---|
| requestId 重号 | ✅ | diff 精读（UUID 8hex 前缀 + seq 保留可读性）；**验收员变异亲杀**：删 UUID 前缀 → `requestId_uniqueAcrossInstances` 红（唯一红，断言"重启后新实例 requestId 不得重号"）→ 还原 BUILD SUCCESSFUL |
| @Ignore 复活 | ✅ | 验收员亲扫全仓 `@Ignore` = **0**；3 条适配说明合理（rescue 降级 / uname 进白名单系生产行为演进，适配保留测试意图非改逻辑凑绿） |
| PiiScrubber 重叠 | ✅ | 新建 PiiPatterns 共享识别单一来源，PiiMasker/PiiScrubber 收敛组合，行为不变 |
| exportModels 明文 | ✅ | 移内部 filesDir + 启动清旧外部明文文件。遗留：平板旧外部文件待新 APK 装机自清（或手动删） |
| 端口+1 | ✅ | `+200` 端口爬行循环删除亲见，固定端口绑定、被占明确失败降级 |
| 计数口径 | ✅ | test-results XML 验收员亲数 **1045 tests / 0 failures**（debug，当日 09:17 跑） |
| 施工纪律 | ✅ | diff 边界干净 10 文件，未碰 p2 在途前端文件（newface.*）——双线无撞车 |

**观察项（不阻塞）**：McpApprovalGateTest 新测试注释写「时间戳组件」与实现 UUID 不符（注释准确性）；AgentLoopTest 复活的 18 条此前标注 "mock brain infra" 实为行为演进，标注失真已久。

### 2026-08-06 工单4 dual-brain 三批真机端到端（`9edb4c7`）— ✅ 通过 + 🔴 安全事故（密钥泄漏）

> 执行：桌面程序员（Claude Code）｜复核：验收员独立抽验。任务性质为真机验证单（证据产出），非代码改动单。

| 抽验项 | 结果 | 验收员亲验 |
|---|---|---|
| 全量测试 | ✅ | test-results XML 亲数 **1044 tests / 0 failures / 0 errors**（102 类，当日跑） |
| 8388/8387 healthz | ✅ | 验收员亲 curl：8388 `0.1.0` / 8387 `hermes_agent_version 0.19.0` |
| 鉴权 fail-closed | ✅ | 验收员无 token 亲打 /infer + /tools/skill.echo/invoke，双 401 UNAUTHORIZED |
| 批1 Anthropic 协议 | ✅ | 证据链齐（请求体铁证 POST /v1/messages + DeepSeek 真实生成 ping→pong + openai 对照不回归）；代理仅取证转发，非 mock 喂答案 |
| 批2 缺口如实 | ✅ | 注册实证（144 工具含 7 技能）+ 双阻塞形态具体（8388 静态 registry 不含动态技能 + AgentLoop 卡 PLANNING=已知 deepseek 澄清障碍），未绕过未假绿 |
| 批3 缺口如实 | ✅ | 验收员独立 grep 确认 `CdpClient.connect()` 全仓零调用点；平板无浏览器（pm 核实）——实现+环境双缺口属实 |
| Hermes 工具/记忆链路 | ✅ | 8388 infer/memory 写读检索/tools 全通；serve 完整任务链 Connection error 定性为 proot 内直连 LLM 网络不通（具体形态首记，转欠账） |

**🔴 安全事故**：证据文件 `ticket4-batch1-anthropic-request.txt` 明文记录 DeepSeek Bearer key 并推送公网。处置（用户拍板 2026-08-06）：① DeepSeek 控制台轮换密钥（用户执行）；② 仓库脱敏 commit（派程序员执行）。**教训入验收红线：证据落盘前必须脱敏——Bearer key / token / Authorization 头一律打码，验收员复核加「证据文件密钥扫描」一项。**

**瑕疵（不阻塞）**：① 执行方 commit message 自称「验收员独立实证」，角色归属错误，以本条为准；② 未走 worktree 隔离直推 main。

**欠账转化**：批2 执行链（8388 动态技能并表 + AgentLoop PLANNING 卡壳）、批3 端到端（connect 调用点接入 + 平板装浏览器）、serve 完整任务链（proot 出网）——均已登记 TASKBOARD 后续队列。

### 2026-08-05 旧 McpServer 存量安全面整治（`bf24b63`）— ✅ 通过（验收员，R8 预审）

| 验收项 | 结果 | 实证 |
|---|---|---|
| allowlist 默认拒绝 | ✅ | @McpExpose 未标注直接 continue；execCommand/installApk 等不再上网；28 个标注逐一核对全只读 |
| 鉴权 fail-closed | ✅ | 未配置 token 全 401；无/错 token UNAUTHORIZED；401 短路在 dispatch 前；变异（恒放行→1红） |
| CORS/脱敏 | ✅ | 响应头无 Access-Control-Allow-Origin；mov.models.export 走 maskKey（前后 4 位），MCP 面无明文 Key 出口 |
| 回归 | ✅ | JS 桥走 BridgeFactory 直连不受影响；合并后终验 **2086/0/0/36** |
| 变异双杀（预审亲手） | ✅ | 鉴权恒放行→1红；allowlist 反转→2红；还原绿 |

**观察项（派为下一单小修）**：@McpExpose 注解位置误导（写在前一方法尾行后）；鉴权 wiring 缺 socket 级 401 集成测试；dispatch 死 case 尸体；HermesActivity 过时注释。存量记档：HermesApplication.exportModels 私有目录明文 mcp_models.json。

### 2026-08-05 MCP 真机证据链 + 安全打回修复（`474497a`+`4476416`+`161b5c7`）— ✅ 通过（验收员，R7 预审+复验）

| 验收项 | 结果 | 实证 |
|---|---|---|
| 真机证据链 | ✅ | initialize protocolVersion=2025-03-26；只读态 70 工具无写；显式开启后 115 工具含 file.write、DANGEROUS 两态恒无；审批闭环 [APPROVAL_PENDING]→mcp.approvalRespond 批准→file.write 真写入 mcp-evidence.txt→journal seq9/10 落账（docs/device-acceptance/2026-08-05/05-mcp-p2-approval.md + 原文 5 份，预审逐字咬合） |
| **R7 打回（安全）** | ✅ 修复 | getServeToken() 被旧 McpServer 反射面二次暴露（无鉴权匿名取 token）→ `161b5c7` denylist 排除 + 回归测试；变异亲杀（删 denylist→1红） |
| 去重 normalize 修复 | ✅ | 缺省 path 归一化比较一致；变异（旧行为→1红） |
| 全量 | ✅ | 合并后 main 终验 **2078/0/0/36** |

**新立项欠账（R7 强烈建议）**：旧 McpServer 存量无鉴权面（CORS * / execCommand / installApk / mov.models.export 明文 Key）+ 反射默认上网模式改 @McpExpose allowlist——已派为下一工单。requestId 重启重号、setMcpWriteEnabled 接设置页须加确认，记档。

### 2026-08-05 L3 记忆模型提炼（`7faedef`）— ✅ 通过（验收员，R5 预审）

> 单程序员编队首单（Claude 会话施工 w7 + 巡检发现交付 + R5 预审 + 终审合并 `3086d8f`，已推送）。

| 验收项 | 结果 | 实证 |
|---|---|---|
| 全量 | ✅ | 预审员亲跑（清陈旧产物后）：自报 996/0/0/18 单变体吻合；合并后 main 终验 **2026/0/0/36** |
| append-only 红线 | ✅ | 提炼产物走 append() `_memory_summary` 事件（actor:l3，payload 无原文）；原文 3 条草案 distill 后完整可读 |
| 懒生成不阻塞 | ✅ | memoryCover 读取路径零模型调用（grep 实证 distillMemory 生产零调用方，调用方择时） |
| 缓存失效 | ✅ | span=塌缩统计指纹，原文变→span变→失配重算；distill_spanChange_recompress + 变异双重实证 |
| 变异复核（预审员亲手） | ✅ | 删冻结注入→2红；span 恒不命中→1红；还原绿 |
| 观察项 | 登记 | cachedSummary 只扫 REPLAY_TAIL_N 窗口（fail-safe 重算）；distillMemory synchronized 需后台线程接入；span 统计指纹理论碰撞极率低 |

### 2026-08-05 欠账清理四工单（P1-P4 + R 预审制）— ✅ 全部通过（验收员）

> 流程：验收员派单 → 4 程序员隔离 worktree 施工 → R 预审员（独立子代理，亲手跑数/变异复核/红线扫描）→ 验收员终审抽查+合并。P5 为并后抽审员。

| 工单 | 内容 | 结论 | 实证 |
|---|---|---|---|
| P1 McpClient 遗留 | SSE 分帧取 response 帧 / 会话重连写回 sessionId / close() 发 HTTP DELETE；Transport 抽象+FakeTransport 11 用例 | ✅ 并入 `18bd5e2`（R3 通过） | 全量 1954/0；变异双杀（恒取首帧→1红、删 sessionId 回写→1红）还原绿 |
| P2 测试盲区 | args.path 回归测试解除 @Ignore（根因：android.jar Log 抛错桩→测试影子类）+ web.search/fetch 零网络单测 + DDG 零结果归因 PARSE_DRIFT/SOURCE_DOWN | ✅ 并入 `1e87479`（R2 通过） | 全量 1938/0（自报）/预审 969/0/0/18 亲跑；变异杀链接正则→2红还原绿 |
| P3 隐私脱敏 | PiiScrubber 确定性脱敏（手机号/身份证/邮箱/卡号/金额/URL）+ CausalOracle 出网必经关口 + PatchCompiler 写回 PII 闸门 + 审计档案 `docs/AUDIT_PRIVACY_CAUSAL_LINK.md` | ✅ 并入 `eb6f46e`+`dd37111`（R1 通过；P5 抽审打回点=审计文档漏交，终审已收编消解） | 全量 1954/0；变异双杀（scrub 直通→12红、闸门恒放行→1红）还原绿 |
| P4 真机线 | **proot EPERM 定案**：KSU/SELinux 运行时策略窗口，重启自愈非代码缺陷（销「环境阻塞」欠账）；新增 ProotDiag 诊断工具+diagnostics.proot 桥命令；**抓出两真凶**：RootfsManager diskUsage 10 线程并发遍历 1.5GB rootfs 拖死进程（改进程级单飞+try/finally 复位）、三个内置 HTTP server Content-Length 字节/字符混淆（中文 body 必挂死）；真机证据链 docs/device-acceptance/2026-08-05/ | ✅ 并入 `1118be5`（R4 打回→返工 9b00187→复验通过） | 全量 980/0/0/19（单变体）；变异杀 try/finally→1红还原绿；真机：MCP 8389 401 fail-closed+protocolVersion、causal 闭环 seq=6、serve healthz 懒启动 2.4s |

**融合终验**：main HEAD `1118be5`，`assembleDebug test` 全量 **2012 tests / 0 failures / 0 errors / 36 skipped**。

**流程教训（沉淀为验收纪律）**：
1. worktree 验收必须先删 `app/build/intermediates/javac` + `app/build/tmp/kotlin-classes` 再跑——UP-TO-DATE 假绿实证骗过一次（R1）
2. 预审变异必须预审员亲手注入，施工方自报记录只作参考（P5 实证：自报 11 红 vs 实测 12 红）
3. 多会话/多 worktree 并发：禁 gradle --stop（杀全局 daemon），文件锁只杀本 worktree 残留 Test Executor PID
4. 数字口径统一全仓四数（P2 单自报 1938 仅 app 模块，全仓实际 2228）

**新欠账（本轮新登记）**：MCP 完整三连真机调用（token 加密存储不可直读，取证法已录 02-mcp-initialize.md）；serve 完整任务链真机证据；PiiScrubber 与 security/PiiMasker 规则重叠治理；McpClient sessionId 非 volatile 注释约束。



**定级**：L3（多分支融合：网络/鉴权/状态机缝合）。

| 分支 | 结论 | 实证 |
|---|---|---|
| `acceptance-data` | ✅ 并入 `707fa15` | 纯文档（docs/+tools/e2e 零代码）；冲突 3 处：ACCEPTANCE_LOG 取验收区档案结构+并入 main MCP P1 记录；TASKBOARD P3 区留 main 超集；GUIDE_DEVICE 留验收区版本 |
| `feat/surpass` | ✅ 并入 `ec0d2bb` | 纯文档（PLAN_SURPASS+PRODUCT_COMPARISON）；README 与 main 同文自动合并 |
| `核心竞争力` | ✅ 并入 `f73da53` | 与 surpass 重复文件自动去重，净增量仅 CORE_COMPETENCY.md |
| `feat/mcp-external` | ⚠️→✅ 修复后并入 `5ef2d54` | **打回项**：McpProvider 静默默认 mcp.golcer.com（未配置即在桥线程同步出网第三方，违安全红线）→ 已删兜底+删字面量假覆盖测试（`8b7cb3a`）。实证：全量 1716/0；变异杀 sseData 恒 null → 3 failed → 还原绿 |
| `feat/fullscreen-html` | ⚠️→✅ 修复后并入 `ef17f40` | **打回项**：D: 盘 NDK 路径硬编码入共享 build.gradle→已删；新代码零测试→unescapeJsString 抽 `browser/JsStringCodec`（原类 Color.parseColor 静态字段致纯 JVM 不可测）+6 单测（`5ba4ee0`）。实证：全量 1612/0；变异杀 \n 分支 → 1 failed → 还原绿 |
| `feat/dual-brain-upgrade`（含 causal-memory 全部） | ⚠️→✅ 修复后并入 `964e5be` | **打回项 4 条**（`1d57765`）：①CausalSpikeCheck/CausalReflectProbe 挂 onCreate 每次冷启动跑（主线程 IO+真 DeepSeek 出网）→已移除并删类；②wb.* 动态工具借兼容构造器混入 readonly/none→会被 MCP 只读服务对外暴露浏览器操控→accessFor 分级（navigate=write/evaluate=dangerous）+回归测试；③hermes-agent.zip 只看 pyproject 存在否，更新后老设备静默陈旧→加 .zip-version 版本戳；④CdpClient.nextId 竞态→AtomicInteger；httpGet 不查状态码→4xx/5xx 抛错。实证：全量 1774/0；变异杀 accessFor → 1 failed → 还原绿 |
| WIP stash（未提交在制） | ✅ 回收并入 `2333154` | RoomStaticServer:8787 多文件 HTML 项目（回环绑定+403+canonical 防越界，11 单测）；AgentLoop args.path 白名单修复+PLAN_ARRAY_RULES 加固；AiClient max_tokens=4096（AiClientTest 断言随行为变更更新）。冲突 2 处（HermesApplication/HtmlViewerActivity）双侧保留 |
| `new-mov/main`（远端） | ⏸️ 不处理 | 已是 origin/main 祖先（落后 804），纯历史快照 |

**融合终验**：main HEAD（`2333154`）`assembleDebug test` 全量 **1926 tests / 0 failures / 0 errors / 38 skipped**（debug+release 双变体）；变异亲杀 RoomStaticServer.isWithin 恒真 → 2 failed → 还原绿。

**观察项（不阻塞，登记欠账）**：
1. AgentLoopTest 新增 multiFilePlan_argsPath 用例仍 @Ignore（pre-existing mock brain 基建债，ARCH_DEBT_PLAN.md #0）——args.path 修复无在跑测试防护
2. McpClient StreamableSession：sseData 跨帧拼接 data 行（通知帧在前会拼坏 JSON）；session 过期重试不更新 this.sessionId；close() 几乎不走 HTTP DELETE——P2 扩展时修
3. web.search/web.fetch（DuckDuckGo 抓取）零单测；DDG 零结果返回 ok:true 建议改 SOURCE_DOWN 归因
4. 因果记忆云端归因把谓词语义发 DeepSeek，脱敏完全依赖 NarrativeBuilder 纪律——隐私观察项
5. 真机欠账：dual-brain 三批（Anthropic 端点/skill 激活/CDP 真浏览器）与 causal AgentLoop 端到端未真机验；proot 失效（execve EPERM）环境待修
6. 本地 main 领先 origin/main 72 commits 未推送（含本次融合全部提交）；stash@{0}（WIP 原件）语义已入 `2333154`，留档未删



**定级**：L3（网络协议/鉴权/持久化——MCP Streamable HTTP + token fail-closed）。

| 验收项 | 结果 | 实物 |
|---|---|---|
| 构建+测试 | ✅ | `assembleDebug test` 全量 **800 tests, 0 failures, 0 errors**（18 skipped, PASS 782）；APK 27MB |
| Diff 精读 | ✅ | mcp/server 五类：MovMcpServer（8389/mcp 幂等启动+token 同源 HermesServeConfig+只读工具注册） / McpToolAdapter（ParamDef→JSON Schema、handler→CallToolResult+maxResultChars 截断） / RegistryProvider（consolidate buildRegistry，ToolManifest/MovInboundServer 删重复副本） / AndroidHttpServer+AndroidStreamableHttpTransport（纯 Java HTTP 帧层，官方 SDK 接入） |
| 变异测试 | ✅ | 杀 `McpToolAdapter.isReadonly`（只读过滤）→ `18 tests, 1 failed`（isReadonly_filtersByAccess 红）→ 还原绿 |
| 真机 initialize | ✅ | `POST /mcp`（Bearer token）→ `{"result":{"protocolVersion":"2025-03-26","capabilities":{"tools":{"listChanged":true}},"serverInfo":{"name":"mov","version":"3.3.0"}}}` |
| 真机鉴权 | ✅ | 无 token → **HTTP 401**（fail-closed） |
| 真机 tools/list | ✅ | 带 Mcp-Session-Id → **59 只读工具**（含 file.read/file.list/tool.describe/model.list；**不含 file.write/device.cmd**——只读过滤正确） |
| 真机 tools/call | ✅ | `file.list` 调用返回（执行路径通）；`file.write` → `Tool not found`（写工具未暴露，安全边界正确） |

**结论**：MOV MCP 化 P1 交付成立，只读工具集边界 + 鉴权 fail-closed + 协议全路径均实测。观察项（不阻塞）：真机端口为 8390（8389 被占时自动 +1）；file.list 需 roomId 参数（空参返回「非法房间ID」是 StorageManager 既有语义）。P2 扩展（全量工具+审批闸+mov.* 查询）待派。

### 2026-08-03 记忆层 v2 读取时按需覆盖 — ✅ 通过

> 任务：docs/TASKS_P6_MEMORY_COVER_2026-08-03.md ｜ 交付：P1（`bdb3593`） ｜ 定级：L1（纯 JVM 纯函数 + Kernel 只读查询）

| 项 | 结果 | 实证 |
|---|---|---|
| 代码审查 | ✅ | memoryCover 纯算法（无模型调用）；预算内全逐字；超预算旧稿塌缩 1 行摘要（数量/最早日期/kind 统计）+ 最新 budget 条逐字（总行数=budget+1）；原文不删只影响"读到什么"；Kernel memory.cover（roomId 必填 / budget 默认 20） |
| 测试质量 | ✅ | 5 覆盖用例直调生产函数（非 mock LLM），覆盖验收标准；JournalMemoryDraftTest **22/22** |
| 变异亲杀 | ✅ | 无变异 22/22 绿 → 注入 `collapsedN=0` → 2 failed（coverKeepsOriginalInJournal + coverOverBudgetCollapsesOld）→ 还原 22/22 绿 |
| 全量 | ✅ | `:app:testDebugUnitTest` BUILD SUCCESSFUL：**758 tests / 18 skipped / 0 failures / 0 errors**（四数，实测） |
| 计数口径 | ✅ | 四数统一 tests/skipped/failures/errors；P1 早期报 754 = 首次全量轮（P6 阶段3 入库前）测试集，P6 入库后 758（+4），tests 字段含 skipped |

**观察项（不阻塞）**：coverVerbatim(null) 对 null 元素 NPE（当前数据源自构造，风险低）；budget=0 钳制为 1，「全摘要」不可表达（设计未要求，可接受）。

**后续派单候选**：needsCompress=true 的 L3 模型提炼（摘要懒生成、空闲补齐，DESIGN v2 §六，单独派单）。

### 2026-08-03 阶段3 B：LLM 收编（/infer 走 MOV BridgeAi）— ❌ 打回

> 任务：docs/TASKS_P2_HERMES_SLIM_B_2026-08-03.md ｜ 交付：P3（自验） ｜ 定级：L3（网络协议/新增端点）

| 项 | 结果 | 实证 |
|---|---|---|
| 证据 hash | ❌ | 「真机 21770d7d」在仓库不存在（`git log 21770d7d` → unknown revision）；/infer 代码仍留在工作区未 commit。B1「7\*6=42」等实证无 commit 可核 |
| 验收结论归属 | ❌ | 结论区由执行方自写，验收人未出结论 |
| B1 推理路径单测 | ❌ | 唯一测试 `infer_implemented_noContext_errorsGracefully` 传 null context → 只走到 NOT_CONFIGURED/INFER_ERROR 提前返回；**messages 解析→AiClient→{content} 映射零执行**，变异必存活 |
| 禁网两条腿 | ⚠️ | B1 MOV 出网正常无实物（依赖真机 hash 补）；任务工具禁网（LD_PRELOAD）未验（环境：app 用户 proot 失效） |
| 全量 | ⚠️ | 未自跑 assembleDebug test（工作区改动未验证） |

**打回修法（逐条到能直接修）**：

1. **证据入档**：将 MovInboundServer（/infer + context 字段）+ MovInboundServerTest + serve_fg_b.sh + 任务文档改动一起 commit，回填真实 hash；真机 B1 附 logcat「MOV 推理 model=…」原文 + 回包截图（证据链：触发 → logcat → 截图）。复验：验收人 `git show <hash>` 可开 + logcat/截图与断言对应。
2. **验收结论分离**：执行方「交付自验」与验收人「验收结论」分区，本档案为准。复验：两区边界清晰。
3. **B1 核心路径单测**（禁 mock LLM 当生产，二选一）：
   - A（推荐）：把 `messages→(prompt, history)` 解析抽成 package-private 纯函数，单测喂 JSON 断言拆分正确（含末条非 user、空 content 跳过、history 顺序）；
   - B：AiClient 构造注入 chat 函数接口，单测传假实现测 infer() 编排（测编排不测 LLM，不算喂答案）。
   复验：变异测试杀 infer() 解析/映射行必须红；`assembleDebug test` 全量报实数。
4. **弱断言加固**：`infer_implemented_noContext_errorsGracefully` 断言 error.code（NOT_CONFIGURED 或 INFER_ERROR 之一），别只 `assertFalse(ok)`。

**观察（不阻塞）**：/infer 在 serve 线程内同步等 LLM（AiClient HttpURLConnection），daemon 侧超时须 > 模型 readTimeout，否则必超时——B1 实测时带计时记录。

**架构确认（B2 硬约束成立）**：AiClient 只有 chat/chatStream（body 无 tools），agent 推理换路会丢 tool_calls——属实。是否扩展 AiClient 支持 function calling 需**用户拍板独立派单**，不在本任务范围内。**B3 纠正属实**：model_tools.py 是工具分发核心非 provider 配置，真裁点（DeepSeek 配置收编）依赖 B2 可行。

### 历史巡检记录

- 巡检 #61 → #2（2026-07-31 至 2026-08-02）：**docs/TASKBOARD.md「待验收人处理」区**（本档案建档前的历史结论保留原处）

## 判例索引

| 判例 | 位置 |
|---|---|
| 验收手册五招 + 假覆盖四形态 + 变异测试 | docs/ACCEPTANCE_PLAYBOOK.md |
| 历史打回判例（4b SOE / KeystoreFallback 三形态 / ContextProvider battery / ConnectWeb 四层） | docs/ACCEPTANCE_PLAYBOOK.md §4 |
| 真机验收 DV 清单 | docs/DEVICE_ACCEPTANCE.md |
| 环境药方（文件锁/CDP/截图全黑/logcat 自匹配） | docs/ACCEPTANCE_PLAYBOOK.md §2 |
