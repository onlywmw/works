# DESIGN：MOV 快脑 × Hermes 慢脑 融合架构 — 2026-07-31（用户拍板）

> 用户拍板：把工具全部提取出来做统一注册表，MOV 和 Hermes 共用。
> 定位：终结「两套平行世界」（ToolRegistry vs BridgeKernel 29 case），一表两脑，安全闸统一。

## 一、两脑分工矩阵

| | MOV 快脑（场景卡） | Hermes 慢脑（AgentLoop） |
|---|---|---|
| 干什么 | 订票/听歌/追剧/点菜——链路固定 | 开放/复合/长程任务：汇总报告、网页探索、文件整理、工具组合 |
| 响应 | <2s，无 LLM 成本 | 允许思考，PLANNING→EXECUTING→DONE（BUG-5 状态机） |
| 确定性 | 回归向量守着 | 允许试错自我纠正 |
| 底层 | TrainSource/MusicSource/DramaSource/A2A | AgentLoop + ToolRegistry + proot Linux + rootfs |

**丘脑 = LLM 意图分类器**（走 BridgeAi 现成管道，禁新写 LLM 客户端）：每句话先分类 → fast 卡 / slow 任务 / chat / 诚实卡。正则退为快速通道（高置信直通，省 token）。

## 二、统一注册表规格（核心）

### 工具元数据 schema

```java
ToolManifest {
  name:        "train_search"        // 全局唯一，点分隔
  level:       FAST | SLOW           // 场景卡 | 慢脑工具
  tier:        READONLY | ACTION | DANGEROUS   // DevicePolicy 风险分级
  toolset:     "travel" | "media" | "device" | "productivity" ...
  sync:        true/false            // 网络 IO 禁同步桥（铁律）
  timeoutMs:   5000
  params:      [ParamDef...]         // 已有结构
  examples:    [...]                 // 喂 LLM 用，已有结构
  checkFn:     硬件/权限探测          // 无闪光灯 → 一开始不放行，已有
}
```

### 两脑消费方式

- **快脑**：`B.query({q:'train_search'})` → BridgeKernel 退化为薄壳：查注册表 → 执行 → 返回。不再有自己的 case 逻辑
- **慢脑**：AgentLoop 按动作名查表执行（现状不变）
- **LLM 意图层**：吃 `ToolRegistry.promptText()`（按 toolset 分组，已有）——看到什么工具才能正确分流；新工具注册一行，LLM 立刻认识，路由零改动
- **安全闸**：DevicePolicy / PermissionPolicy / PaymentGate 对两脑一视同仁（现状已是统一闸，保持不变）

### BridgeKernel 29 case 迁移清单（按现状逐条归类）

| 归类 | case | 去向 |
|---|---|---|
| **控制面（留桥层，非工具）** | user_input / stop_task / resume_task / gate_respond / understand / plan / shell / ask / agent_state / intent_classify | 桥控制通道，不进注册表——它们是 agent 生命周期管理，不是工具 |
| **存储面（留桥层）** | room_destroy / subscribe_history / append_event / journal_tail / journal_index / journal_replay | StorageManager 契约层 |
| **fast 场景卡（进注册表 level=FAST）** | train_search / music_search / face_search_drama / video_sources / web_sites / web_adapt / mayi_latest / check_drama_updates | 各包一个 ToolProvider |
| **记忆读写（进注册表 level=FAST, tier=READONLY/WRITE）** | watch_history / drama_memory / face_history / face_mine | MemoryToolProvider 一个类收编 |

> 已有库存（SLOW 侧，注册表已在管）：SystemToolProvider 10 工具 / UtilityToolProvider（speech.recognize/qr.generate/email.send/audio.record…）/ ExtraToolProvider（camera.capture/location.get/bluetooth.list/wifi.scan…）/ packager（ApkAssembler+PackageBuilder）/ mcp 全套。**迁移后快脑也能直接调它们**（如「帮我打个包」→ fast 通道直达 PackageBuilder）。

## 三、四条互联通道

1. **下行分流**：LLM 分类 → fast 卡（快脑）/ slow 任务（慢脑）/ chat / 诚实卡（听不懂绝不演）
2. **卡即工具**：fast 卡注册即入表，慢脑干活时直接调（Hermes 规划行程时 train_search 是它的 tool）
3. **结果回脸**：AgentLoop 产物 → 桥 → newface 任务进度卡 + 交付物卡。用户永远只面对一张脸
4. **双向升级**：fast 卡发现超纲 → 交接卡升慢脑；慢脑探索成功（WebAdapter C 级）→ 固化 SiteCard/fast 卡。**经验固化 = 两个脑之间最值钱的通道**

## 四、工具晋升/降级机制

| 方向 | 判据 | 动作 |
|---|---|---|
| SLOW → FAST（固化） | 高频（journal 统计调用次数）+ 链路固定 + 无需组合 | 包成场景卡，写回归向量，level 改 FAST |
| FAST → SLOW（降级） | 链路失效（回归向量红/站点改版） | level 改 SLOW，Hermes 现场探索，修好后升回 |
| 永久 SLOW | 需组合/低频/开放（打包 APK、硬件控制组合技） | 留在慢脑，不固化 |

## 五、施工序列（P1 主线，依赖：LLM 意图分类先行）

1. **F1 元数据扩展**：ToolManifest 加 level/sync/timeoutMs（tier/toolset/checkFn 已有）
2. **F2 场景卡收编**：train/music/drama/a2a 包成 ToolProvider 注册；BridgeKernel 对应 case 改为查表转发（先双跑一周，再删 case）
3. **F3 记忆收编**：watch_history/drama_memory 等归 MemoryToolProvider
4. **F4 意图层吃 promptText**：LLM 分类器 prompt 自动包含注册表工具文档
5. **F5 结果回脸**：AgentLoop 产物 → newface 任务卡/交付物卡（交接卡 showHandoff 改造）
6. **F6 晋升统计**：journal 按工具统计调用频次，月报候选固化清单

每步独立可验：F2 完成后「我要听小苹果」走注册表路径与走 case 路径结果一致（双跑对比即回归向量）。

## 六、红线

- 网络 IO 禁同步桥（注册表 sync 元数据强制声明，违规注册拒绝）
- 支付域工具 tier=DANGEROUS，无锁屏设备直接拒绝（支付铁律不变）
- 迁移期禁删旧路径：先双跑验证一致，再删 case（删快了就是下一个「演机票」）
- 注册表对 LLM 暴露的文档只读，LLM 无权注册/修改工具
