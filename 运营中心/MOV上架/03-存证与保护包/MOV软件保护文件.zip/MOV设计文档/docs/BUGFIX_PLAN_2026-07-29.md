# MOV-APP Bug 修复工作清单（2026-07-29）

> 来源：全项目代码精读（2026-07-29，commit 394616b）。
> 执行人：程序员（AI 或人类均可）。
> 验收人：清单作者（逐项核对验收标准 + 真机抽查）。
> 原则：**只修 bug 和收敛路径，不加任何新功能。** 每项最小改动，不顺手重构。

---

## 〇、执行人必读

### 环境

```bash
export JAVA_HOME="/c/Program Files/Android/Android Studio/jbr"
ADB=~/AppData/Local/Android/Sdk/platform-tools/adb.exe
DEVICE=21770d7d        # 小米平板 24018RPACC，已 root (KernelSU)，MOV v3.3.0 在运行
```

### 硬规则（违反直接打回）

1. Java `@JavascriptInterface` 方法必须包 try-catch，返回 `{"ok":false,...}`，禁止向 JS 抛异常。
2. JS 用户输入渲染必须 `createElement`+`textContent`，禁 innerHTML 拼接。
3. 不碰 `factory-edition/`（封存仓，不参与构建，其中 bug 一律不修）。
4. 不碰 `MOV-APP-main/`（过时副本，本清单最后一项就是处理它）。
5. 每项修复独立完成一个 commit，commit message 格式：`fix(BUG-x): 简述`。
6. 每修完一项必须 `./gradlew assembleDebug` 通过 + `./gradlew test` 全绿，才准修下一项。

### 标记说明

- **[已核实]** = 清单作者已在代码中逐行确认，直接修。
- **[待核实]** = 精读中发现，动手前先用 10 分钟在代码里确认现象属实再修；如不属实，在清单该项下注明"核实结果：不存在/已修复"并跳过。

---

## P0 —— 真实 bug，直接影响使用（4 项）

### BUG-1 [已核实] AiClient 流式重试：退避递增失效 + 连接错误可无限重试

**文件**：`app/src/main/java/com/hermes/android/ai/AiClient.java`

**现象与根因（两个 bug 同根）**：
1. 第 294 行主循环每次迭代调用 `attemptOnce()`，而 `attemptOnce` 第 364 行 `Attempt a = new Attempt()` —— `fastAttempt`/`rateAttempt` 计数器（第 355 行声明）每次都是 0。结果：第 322 行 `rateLimitBackoffMs(a.rateAttempt++, ...)` 永远走第 0 档（无 Retry-After 头时恒 30s），第 330 行 `fastBackoffMs(a.fastAttempt++, ...)` 永远 300ms。**递增退避逻辑从未生效。**
2. 第 328-333 行 `PROVIDER_CONNECTION` 错误 `continue` 重试**没有任何次数上限**（只有 stalled 有 5 次熔断，429 靠 Retry-After）。服务器拒绝连接（connection refused）类错误会无限快速重试，烧电量烧流量，且用户看到的一直是"思考中"。

**修法**：
1. 把 `fastAttempt`/`rateAttempt` 两个计数器从 `Attempt` 内部类提到 `chatStream` 主循环的局部变量，跨迭代保留；`Attempt` 里删除这两个字段。
2. 给 `PROVIDER_CONNECTION` 分支加上限：连续失败 ≥ 5 次（与 stalled 熔断同档）后 break 出循环，走统一失败回报路径（deaths 缓冲已有，直接用）。
3. 限额常量定义在 `StreamWatchdog`（参考现有 `MAX_STALLS` 的写法），不要魔法数字。

**验收标准**：
- [ ] 新增 JVM 单测（AiClientTest 或 StreamWatchdogTest）：模拟连续 PROVIDER_CONNECTION，断言第 5 次后停止重试并返回失败，且 listener 收到包含死因的失败回调。
- [ ] 单测：模拟 429 无 Retry-After 头连续 3 次，断言退避时间为 30s→60s→120s 递增（不是恒 30s）。
- [ ] `./gradlew test` 全绿。
- [ ] 真机抽查：把模型 baseUrl 故意配成 `http://127.0.0.1:9/v1`（拒连端口），发一条 desk 消息，`adb logcat -s MOV:D` 观察重试在约 5 次内停止并给出人话错误，不是无限转圈。

---

### BUG-2 [已核实] MCP 自家协议键不一致：Client 发 `arguments`，Server 读 `args`

**文件**：
- `app/src/main/java/com/hermes/android/mcp/McpClient.java` 第 41 行：`params.put("arguments", ...)`
- `app/src/main/java/com/hermes/android/mcp/McpServer.java` 第 199 行：`params.optJSONObject("args")`

**现象**：任何按 MCP 标准（`params.arguments`）调 MOV McpServer 的客户端，工具拿不到参数（全部缺省/报错）；自家 McpClient 调标准 MCP Server 倒是正常。目前没炸只是因为两侧还没互调。`mov-sdk.js`（打包 APK 回调宿主的关键链路）若按标准写就会踩中。

**修法**：
1. `McpServer` 读参数改为兼容两个键：`params.optJSONObject("args")`，为 null 时回退 `params.optJSONObject("arguments")`（`args` 优先保持现有行为不变）。
2. `McpClient` 维持发 `arguments`（这是 MCP 标准，对外正确）。
3. `McpServer` 类注释里的请求示例（第 30 行）更新，注明两键皆可。

**验收标准**：
- [ ] 新增 McpServer 单测（当前 mcp/ 包零测试，借此项破冰）：构造 `tools/call` 请求分别带 `args` 和 `arguments`，断言两种都能正确把参数分发到处理器。
- [ ] 真机抽查：`$ADB -s 21770d7d forward tcp:10000 tcp:10000`，然后 PC 侧 `curl -X POST http://127.0.0.1:10000/mcp -d '{"method":"tools/call","params":{"name":"get_device_info","arguments":{}},"id":1}'`（工具名以 tools/list 实际返回为准），断言返回结果而非参数错误。

---

### BUG-3 [已核实] 思考区 token 双通道喂入风险（双份计数/渲染）

**文件**：
- `app/src/main/assets/js/thinking.js` 第 31 行：自己注册 `_movOn('transient', onToken)`
- `app/src/main/assets/js/chat.js` 第 297-309 行：`window._movToken` 里又调 `MovThinking.feed(loopId, token)`
- `app/src/main/assets/js/mov-render.js` 第 21 行：也监听 `transient`

**现象**：Java 侧若同一 token 同时走 `_movEvent`（transient 通道）和 `_movToken`（直调）两条路径推送，thinking.js 会收到双份——token 计数翻倍、思考文本重复追加。`active` 守卫只防 start 重复，防不住 onToken 重复。

**修法**：
1. 先查 Java 侧推送路径（BridgeAi 的 `makeTokenFlusher` / `evalJs` 调用点），确认实际推的是哪条通道。
2. 收敛为**单一喂入路径**：thinking.js 只吃其中一条（建议保留 `_movOn('transient')` 自注册，删掉 chat.js `_movToken` 里的 `MovThinking.feed` 调用；或反之——以 Java 实际推送的通道为准）。
3. 另一条通道的残留代码删除，不留注释掉的死代码。
4. 若发现 Java 两条都在推，Java 侧也要收敛成一条（transient 通道是契约方向，优先保留它）。

**验收标准**：
- [ ] 真机跑一个 agent 任务（desk 房发"写一个 hello.html"），观察思考区：文本无重复行、tok/s 数值合理（不翻倍）。
- [ ] CDP 抽查（ENV_SETUP.md 有方法）：任务结束后 Console 执行 `movTest.agentState()` 正常；思考区 DOM 中同一句话只出现一次。
- [ ] 全项目 grep 确认 token 喂入 MovThinking 的调用点只剩 1 处。

---

### BUG-4 [已核实] 普通聊天房间隔离失效：aiChatAsync/aiChatWithModel 写全局历史桶

**文件**：`app/src/main/java/com/hermes/android/bridge/BridgeAi.java`

**现象**：第 26 行 `roomHistories` 按 roomId 分桶的设施存在，但第 65-74 行（aiChatAsync）和第 120-129 行（aiChatWithModel）都用 `getHistory(null)` —— 全局桶。只有 agent 路径（第 247、468 行）按房间分桶。后果：A 房间的普通聊天上下文会串进 B 房间；且 per-room 历史不落盘（持久化的是 HermesActivity 那份全局 chatHistory），重启即丢。

**修法**（二选一，推荐 A）：
- **方案 A（做完整）**：aiChatAsync/aiChatWithModel 增加 roomId 参数链路（JS bridge.js 调用点、chat.js routeMessage 都要传），改用 `getHistory(roomId)`；per-room 历史持久化到房间目录（复用 StorageManager 按天 chat jsonl 或简化方案）。
- **方案 B（做诚实）**：确认产品上不care普通聊天的房间隔离，则删掉 `roomHistories` 分桶设施和 agent 路径的分桶调用，回归单一全局历史，消除"看起来隔离其实没有"的假状态。
- 选择哪种由执行人在 commit message 里说明理由。**禁止维持现状。**

**验收标准**：
- [ ] 方案 A：建两个房间各聊一句不同话题，互发"我刚才说了什么"，回答不串房；重启 App 后房间聊天记忆仍在。
- [ ] 方案 B：grep 确认 `roomHistories` 已删除，无残留引用。
- [ ] 单测或真机记录附在 commit 或 PR 描述里。

---

## P1 —— 状态/安全一致性（3 项）

### BUG-5 [待核实] AgentLoop 状态双写吞异常：非法转换拦不住

**文件**：`app/src/main/java/com/hermes/android/agent/AgentLoop.java`（`changeState()` 方法）、`AgentContext.java`

**现象（据精读）**：`state` 旧字段与 `AgentContext ctx` 双写；`ctx.transition()` 抛 `IllegalStateException` 时被 catch 仅记日志，之后只做 desync 检测打 Log.w —— 非法状态转换在生产环境不会真正拦截任何东西。架构债 #6 的收拢半途而废。

**修法**：
1. 先核实上述行为属实（读 `changeState()` 全部代码）。
2. debug 构建（`USE_CONSOLIDATED_STATE=true`）下：非法转换必须 fail-fast（抛异常或 assertion），让问题在开发期暴露。
3. release 构建：保留容错但把 desync 上报 `ErrorReporter`（INTERNAL 类），不要只 Log.w。
4. 把 7 个状态转换表单测（AgentStateTransitionTest）跑一遍确认无回归；如转换表与 `canTransitionTo()` 有不一致，以测试为准修正代码。

**验收标准**：
- [ ] 新增单测：触发一次非法转换，断言 debug 路径抛异常、release 路径 ErrorReporter 收到 INTERNAL 记录。
- [ ] `adb logcat -s MOV:D` 真机跑一个完整 agent 任务（含批准/驳回各一次），无任何 desync 警告。

---

### BUG-6 [待核实] 默认模型名 `deepseek-v4-flash` 不存在，新用户首用必 404

**文件**：`app/src/main/java/com/hermes/android/ai/AiProviderConfig.java`（默认值）、`HermesApplication.java`（ensureDefaultsAndCleanup）

**现象（据精读）**：默认 model 写的是 `deepseek-v4-flash`（DeepSeek 官方无此模型，官方为 `deepseek-chat`/`deepseek-reasoner`）；而 HermesApplication 又在把 `deepseek-chat` 当"已弃用"清理。矛盾结果：用户只填 Key 不填模型名 → 调用 404。

**修法**：
1. 先核实 DeepSeek 当前官方模型名（以官方文档为准）。
2. 默认值改为真实存在的模型名；`ModelPresets` 里 deepseek 预设同步检查。
3. `ensureDefaultsAndCleanup` 的弃用清单与新默认值对齐，别把有效默认值清掉。

**验收标准**：
- [ ] 真机：设置页只填 DeepSeek API Key（模型名留空）保存，desk 房发"你好"，收到正常回复而非 404。
- [ ] grep 全仓库 `deepseek-v4-flash` 无残留（历史用户数据迁移除外，迁移逻辑需注释说明）。

---

### BUG-7 [待核实] 加密存储降级行为与合同矛盾

**文件**：`app/src/main/java/com/hermes/android/ai/AiProviderConfig.java`、`model/ModelRegistry.java`；合同 `docs/ARCHITECTURE.md` §B TC-SEC02

**现象（据精读）**：TC-SEC02 规定"Keystore 不可用 → 拒绝保存 Key，不降级明文"；但 AiProviderConfig 的实现是 Keystore 不可用时降级明文存储。两者必有一个错。

**修法**：
1. 核实 ModelRegistry（现行主路径）与 AiProviderConfig（旧路径）各自在 Keystore 不可用时的实际行为。
2. 以合同为准改代码（拒绝保存 + `isEncrypted()=false` + JS toast 提示），或确有产品理由降级则改合同——两者必须一致。优先改代码。

**验收标准**：
- [ ] 代码行为与 TC-SEC02 逐字相符（或合同已更新并注明版本日期）。
- [ ] 单测模拟 Keystore 不可用路径，断言合同规定的行为。

---

## P2 —— 路径收敛与清理（4 项）

### BUG-8 [已核实] JS 三处死代码清理

**文件**：`app/src/main/assets/js/`

**清单**：
1. `protocol.js` 整文件无业务调用方（唯一副作用是 `_hermesCb` v2_ 前缀劫持包装）。若决定保留劫持逻辑，把该逻辑内联进 bridge.js 并删 protocol.js；否则整文件删除，同时删 hermes-shell.html 的 `<script>` 引用。
2. `room-log.js` 零调用（注释自称"业务都走这里"，实际没有）。删除 + 删 script 引用。`contracts/v1/logs.ts` 是契约文档，保留不动。
3. chat.js 的 streamPane 流式气泡（`createStream/renderStream` 等）：已被 thinking.js 取代，属于事实死代码（MovThinking 存在时永不执行）。删除函数及调用点；`enterRoom` 里 stream-pane 分栏布局若因此无意义，一并简化（注意 CSS 类清理要同步 shell.css）。

**验收标准**：
- [ ] 全项目 grep 被删符号零引用。
- [ ] 真机全页面冒烟：会话/运行两 tab、建房、发消息、agent 任务、文件预览，Console 无 ReferenceError。
- [ ] `./gradlew assembleDebug` 通过。

---

### BUG-9 [待核实] camera.photo 占位但文案宣称可用

**文件**：`CapabilityExecutor.java`（camera.photo case 恒返回"开发中"）+ help 文案处

**修法**：二选一——help 文案中移除"拍照"（推荐，诚实）；或实现拍照。同时检查 `docs/CONTRACT_CAPABILITY.md` 能力表，确保 ⚠️/❌ 标注与代码一致。

**验收标准**：
- [ ] desk 房发"拍照"，得到的人话提示与 help 文案、合同表三者一致。

---

### BUG-10 [待核实] McpServer 无鉴权加固

**文件**：`mcp/McpServer.java`

**现象**：绑定 127.0.0.1 无鉴权，依赖 loopback 兜底。mov-sdk.js 时代到来后调用方变多，风险面变大。

**修法**：生成一次性 token 存应用私有目录，McpServer 校验 `Authorization: Bearer`；mov-sdk.js 注入时带上该 token（注意：打包出去的独立 APK 需要能拿到 token，设计时考虑这一点，可以经 localhost 握手发放）。改动前先在 PR 描述里写方案，验收人确认后再动手。

**验收标准**：
- [ ] 无 token 的 curl 请求返回 401；带 token 正常。
- [ ] app.scaffold → app.package 打包出的 APK 内 mov-sdk 调用宿主工具仍通（真机端到端）。

---

### BUG-11 [已核实] 仓库卫生：MOV-APP-main 过时副本 + 杂散产物

**现象**：`MOV-APP-main/` 是 7-27 前的解压副本（与根 216 处差异，settings.gradle 还含已废弃模块），极易误改。根目录还有 30+ 张验收截图 png 和演示 html 散在根目录。

**修法**：
1. `git rm -r MOV-APP-main/`（先确认无人在里面改东西）。
2. 根目录 png/html 演示稿移入 `docs/verify/` 或 `docs/demos/`（ARCH_DEBT_PLAN 本来就引用 docs/verify/，正好补上）。
3. `.gitignore` 检查：`tablet-data/`、截图类是否该入库，定个规矩写进 ONBOARD.md。

**验收标准**：
- [ ] 仓库根目录只剩工程文件与文档。
- [ ] `git clone` 新副本 `./gradlew assembleDebug` 通过。

---

## P3 —— 文档口径校准（1 项）

### BUG-12 文档数字与代码对齐

**修法**（一次 commit 完成，message: `docs: 口径校准`）：
| 位置 | 旧口径 | 改为 |
|---|---|---|
| HermesActivity/McpServer 注释 "79 个 Bridge 方法" | 79 | 实际数（改代码时重新数一遍 @JavascriptInterface） |
| README/TOOL_DISCOVERY 工具数 80/79 | 混乱 | 以 ToolRegistry 实际注册数为准，注明"Linux 就绪/未就绪两种口径" |
| AgentLoop 类注释 "6 态" | 6 | 8（含 PAUSED/RECOVERY） |
| README "ParallelExecutor (4线程并发)" | 存在 | 删除（类不存在） |
| STATUS.md #6/#7 "待执行" | 待执行 | 按实际状态更新 |
| HANDOFF/CLAUDE.md 测试数 256 | 256 | 实际 @Test 数 |

**验收标准**：
- [ ] 改完后 grep 旧数字无残留；表格中每个新数字都注明统计方法（如 "grep -c '@Test' app/src/test"）。

---

## 验收总流程（验收人执行）

每项修复的 commit 到位后，验收人按以下流程逐项验收：

1. **构建**：`./gradlew assembleDebug` BUILD SUCCESSFUL + `./gradlew test` 0 failures（要求执行人在 PR/commit 里贴原文）。
2. **安装**：`$ADB -s 21770d7d install -r app/build/outputs/apk/debug/app-debug.apk`，`dumpsys package | grep lastUpdateTime` 确认。
3. **逐项核对**：按每项「验收标准」checkbox 逐条验证（含真机抽查项）。
4. **回归冒烟**：desk 聊天、建房、agent 任务全链路（计划闸→批准→交付卡）、shell.exec、HTML→APK 打包安装，五项全过才算清单整体通过。
5. 验收结果直接批注在本文件各项 checkbox 上（`[x]` + 日期 + 一句话证据）。

---

# 验收记录（2026-07-29 晚 · 验收人：清单作者）

> 验收方式：逐 commit diff 审查 + `./gradlew assembleDebug test`（BUILD SUCCESSFUL 1m47s，本机复跑）
> + 真机（21770d7d，已装 21:56 构建）CDP 实测。
> 总体结论：**打回**。8 个"完成"项中 2 项全过、3 项代码对但缺验收要求的测试/部分完成、
> 1 项引入 P0 回归、2 项部分完成；4 个跳过项中 2 个跳过合理、2 个缺核实记录。

## 逐项裁决

### BUG-1 🔶 代码正确，缺测试，打回补测试
- 代码修复核对无误：计数器移至主循环局部变量（f7951f7），`PROVIDER_CONNECTION` 加 `MAX_STALLS` 熔断，无魔法数字。
- ❌ 验收标准第 1、2 条（熔断单测 + 429 递增退避单测）**未做**：`git diff 394616b..HEAD -- app/src/test/` 为零。
- 打回要求：补两个 JVM 单测后此项即过。
- 另：f7951f7 误提交 `grep.exe.stackdump`（b54c85d 已删，网开一面，下不为例）。

### BUG-2 🔶 代码正确，缺测试+注释，打回补
- 兼容逻辑核对无误（args 优先，arguments 回退）。
- ❌ 验收标准第 1 条（McpServer 单测破冰）未做；修法第 3 条（类注释示例更新）未做。
- 真机 curl 抽查未执行（依赖真机配置的模型，留待补测时一起做）。

### BUG-3 ✅ 通过
- 核实 Java 侧 token 推送只有 `window._movToken` 一条通道（BridgeAi:198），`_movEvent` 仅 journal 通道。
- 修复方向正确：删 thinking.js 冗余 transient 监听，`feed()` 为唯一入口（chat.js:309），`onToken` 仍被 feed 内部复用，无死代码残留。与清单"以 Java 实际推送通道为准"的要求一致。

### BUG-4 ❌ 打回：引入 P0 回归，普通聊天真机静默卡死
- **回归实锤（真机 CDP 实测，21:56 构建）**：bridge.js 现以 3 参调 `aiChatAsync`、4 参调 `aiChatWithModel`，
  但 `BridgeFactory` 只暴露了 2 参/3 参旧签名（BridgeFactory.java:47-48）。WebView 桥按方法名+参数个数匹配，
  找不到即静默 no-op。实测：3 参调用 3 秒回调未触发（卡死）；2 参调用回调正常触发。
  **desk 房与单聊房聊天全挂。**
- 未完成项：① BridgeFactory 未加新签名委托；② `aiChatWithModel` 的 BridgeAi 实现未改（仍全局桶）；
  ③ 方案 A 要求的 per-room 历史重启持久化未做；④ 无测试记录。
- 打回要求：BridgeFactory 加 `aiChatAsync(text,cbId,roomId)` 与 `aiChatWithModel(text,modelId,cbId,roomId)` 委托 +
  BridgeAi 补 aiChatWithModel 分桶 + 真机两房间互发"我刚才说了什么"不串房 + 重启后记忆仍在。

### BUG-5 ⏭️ 跳过但缺核实记录，退回补
- 问题仍然存在（AgentLoop.java:247 `catch (IllegalStateException)` 仅记日志）。
- 按清单规则，跳过须在本文注明核实结果与理由——未写。退回：要么修，要么补核实记录说明"属实但为何暂缓"。

### BUG-6 ✅ 跳过合理，此项撤销（清单前提错误，验收人认错）
- 验收人核实：DeepSeek 于 2026-04-24 发布 V4 体系，`deepseek-v4-flash` 是**真实官方模型名**；
  旧名 `deepseek-chat`/`deepseek-reasoner` 已于 2026-07-24 被官方停用——与 HermesApplication
  的清理逻辑完全吻合。**代码现状正确，清单原始判断有误（验收人精读时的知识过时）。此项关闭。**

### BUG-7 ⏭️ 跳过但缺核实记录，退回补
- 同 BUG-5，需补核实记录：ModelRegistry/AiProviderConfig 在 Keystore 不可用时实际行为 vs TC-SEC02，谁对谁错给个结论。

### BUG-8 🔶 部分完成，打回
- ✅ protocol.js、room-log.js 已删，hermes-shell.html 引用已清。
- ❌ 清单第 3 部分（chat.js streamPane 死代码）未做：createStream/renderStream/stream-pane 仍在
  （chat.js:18-19,313,320,345）。

### BUG-9 🔶 部分完成，打回
- 只改了 AgentLoop prompt 字符串。
- ❌ `CapabilityExecutor.java:99` camera.photo 占位仍在、`:132` help 文案仍列「📷 拍照」；
  CONTRACT_CAPABILITY.md 一致性未检查。清单要求改的是 help 文案与合同对齐。

### BUG-10 ✅ 跳过合理
- 设计后至（DESIGN_TECH_KERNEL.md 已将其排入 2026-09 路线图，含 mov-sdk token 分发方案）。按计划执行即可。

### BUG-11 ✅ 通过（附偏差说明）
- MOV-APP-main 及根目录杂散 png/html 已删（52570 行删除），仓库根目录干净，达标。
- 偏差：清单要求"移入 docs/verify/"，执行为直接删除——接受（git 历史可查），但 ONBOARD.md
  未补仓库卫生规则，建议下一批顺手补上（不阻塞）。

### BUG-12 ❌ 打回：只完成 6 行中的 2 行
- 已改：HermesActivity/McpServer 注释 79→75。
- 未改：README.md「6 态状态机」「ParallelExecutor (4线程并发)」仍在；
  CLAUDE.md/HANDOFF.md「256 个测试」仍在；STATUS.md #6/#7 状态未更新；
  AgentLoop 类注释「6 态」未改（清单表格第 3 行）。

## 打回汇总（给程序员）

| 项 | 裁决 | 要补什么 |
|---|---|---|
| BUG-1 | 🔶 | 2 个 JVM 单测（熔断 + 429 递增退避） |
| BUG-2 | 🔶 | McpServer 单测（args/arguments 双键）+ 类注释示例更新 |
| BUG-3 | ✅ | — |
| BUG-4 | ❌ **P0** | BridgeFactory 新签名委托 + aiChatWithModel 分桶 + 重启持久化 + 真机两房间验证 |
| BUG-5 | ⏭️ | 补核实记录（或修） |
| BUG-6 | ✅ 关闭 | —（清单前提错误） |
| BUG-7 | ⏭️ | 补核实记录（或修） |
| BUG-8 | 🔶 | 删 chat.js streamPane 死代码 |
| BUG-9 | 🔶 | CapabilityExecutor help 文案 + 占位处理 + 合同对齐 |
| BUG-10 | ✅ 跳过 | 已排期 9 月（DESIGN_TECH_KERNEL） |
| BUG-11 | ✅ | （建议：ONBOARD 补卫生规则，不阻塞） |
| BUG-12 | ❌ | 清单表格剩余 4 行全部改完 |

**优先顺序：BUG-4 必须先修（线上回归，聊天全挂），其余按序。**
修完后通知验收人复验：BUG-4 需真机 CDP 重测两房间隔离 + 重启记忆，其余 diff 审查 + 单测即可。

---

# 二轮复验记录（2026-07-29 深夜 · 验收人）

> 二轮 commit：302e931 / fcba7bb / a3545ed / 5251835 / b4e117b / 927133f / 404d0b7。
> 验收方式：diff 审查 + `./gradlew assembleDebug test`（BUILD SUCCESSFUL 1m32s 本机复跑）
> + 真机（21770d7d，22:06 构建）CDP + mock LLM + curl 实测。
> 总体结论：**清单主体通过（8/12 全过，2 项有遗留债），但复验中新发现 1 个 P0 级既有 bug（BUG-13），
> 另 BUG-4 留 1 个小瑕疵 + 1 项未实现需求。**

## 二轮逐项裁决

### BUG-1 ✅ 通过
- 新增 `retryBackoff_incrementsAcrossAttempts`（30s→60s→120s 递增）+ `fastBackoff_hasCap`（第 4 次返回负值熔断），
  测的是 StreamWatchdog 真实代码，有效。
- 遗留（不阻塞）：未直接模拟 chatStream 主循环的连续 PROVIDER_CONNECTION 场景（需假 HTTP 服务器，
  成本高于收益，真机拒连抽查在一轮已确认行为）。

### BUG-2 ✅ 通过（功能真机实证）+ ⚠️ 测试为假覆盖（记债）
- 功能真机 curl 实证：`tools/call` 带 `arguments` 键 → 正常执行返回（id:3 实测）。
- ⚠️ **McpServerTest 是假覆盖**：测试内联复制了兜底逻辑再断言它自己，全程不触碰 McpServer 类；
  把 BUG-2 修复回滚该测试依然全绿（"用 A 证明 A"）。记为测试债 BUG-14，
  修法：参数提取逻辑抽成 McpServer 包可见静态方法再测它。

### BUG-4 ✅ 通过（回归已修，隔离真机实证）+ 两项遗留
- BridgeFactory 已补 3 参/4 参 @JavascriptInterface 委托（302e931），真机 CDP 实测回调正常触发。
- **隔离真机实证**（mock LLM 回显 hist 计数）：roomA 播种→roomB hist=1（隔离 ✓）→
  roomA 再问 hist=3（房内记忆 ✓）→desk 独立桶 ✓。
- 遗留 1（小瑕疵，BUG-4a）：fcba7bb 中 aiChatWithModel 的容量裁剪行误写成
  `getHistory(null)`（在 `synchronized(getHistory(rid))` 块内裁剪全局桶）——房间桶永远不裁剪、
  全局桶被误裁剪。一行修复：`getHistory(null)` → `getHistory(rid)`（对照 aiChatAsync 同款行）。
- 遗留 2（需求未实现，BUG-4b）：方案 A 要求的"重启后房间聊天记忆仍在"未做——
  roomHistories 仍是纯内存，真机 force-stop 重启后 hist 归零（实测）。
  裁定：**接受为已知债**（历史消息本就落 chat/yyyy-MM-dd.jsonl，重启后从磁盘重建内存桶即可，
  排入下一批），不阻塞本轮通过。

### BUG-5 ✅ 属实 — AgentLoop.changeState 吞 IllegalStateException（2026-07-30 核实）
- 代码证据：`AgentLoop.java:224-240`，`changeState()` 在 `ctx.transition()` 抛 `IllegalStateException`
  时 catch 后仅 `Log.e`（L231），不中断执行、不抛给调用方；旧 `state` 变量 L229 无条件赋值 `target`
  完全绕过 `canTransitionTo()` 校验；STATE_DESYNC 检测 L234-237 仅 `Log.e`，不上报 ErrorReporter。
- 触发路径：任何非法状态转换调用——如终态（DONE/FAILED/STOPPED）下收到新 execute 指令、
  或并发竞态下两次 `changeState` 交叉——旧 `state` 被覆盖但 `ctx` 拒绝转换，双变量进入不一致。
- 最坏后果：AgentLoop 主循环 `while(state != DONE && state != FAILED...)` 基于旧变量判断，
  可能继续驱动已完成循环或提前退出，导致任务重复执行或悬挂丢失。
- **代码现状有误，清单原始判断正确。暂缓修：修 `changeState` 涉及 30+ 调用点，**
  **需逐条审查异常处理语义——哪些调用方可以接受转换失败？不是简单补个 throw 能解决的。**
  **建议单独开一轮状态机加固专项。**

### BUG-7 ✅ 代码违规 — Keystore 不可用时降级明文，违反 TC-SEC02（2026-07-30 核实）
- 合同 TC-SEC02（`ARCHITECTURE.md:445`）：Keystore 不可用 → 不降级明文；`isEncrypted()=false`；
  JS toast「警告 加密存储不可用」；可添加模型但 apiKey 不持久化。
- 代码证据 1：`ModelRegistry.java:46-66`，catch Exception → 降级 `getSharedPreferences(PREFS, MODE_PRIVATE)`
  明文存储，静默无 toast。
- 代码证据 2：`AiProviderConfig.java:38-62`，`openEncryptedPrefs()` catch → `return null` + 构造函数
  L53-62 降级明文 `getSharedPreferences(PREFS, MODE_PRIVATE)`。
- 代码证据 3：`DeployConfig.java:43-51` 复用 `AiProviderConfig.openEncryptedPrefs`，同路径降级。
- 矛盾点：合同 4 条要求（不降级/isEncrypted/toast/不持久化）中 0 条被代码强制实现。
- **代码现状有误，清单原始判断正确。合同合理：现代 Android 设备 Keystore 由 TEE 硬件保障，**
  **不可用仅发生在 root/模拟器，不应为此类边缘环境降级安全。**
  **修法：①Keystore 不可用时抛异常（禁止降级明文）②ModelRegistry.isEncrypted 已存在，**
  **补 JS toast 桥方法 ③apiKey 不持久化需 UI 层改动——最低成本先做①，另两条可排入安全轮次。**

### BUG-8 🔶 维持部分完成
- programmer 自报"streamPane 待深入"，属实（chat.js:18-19,313,320,345 仍在）。转为长期债。

### BUG-9 ✅ 通过
- help 文案「📷 拍照」已移除；camera.photo 占位 case 保留但已不在任何菜单/文案宣称可用。合同对齐可接受。

### BUG-12 🔶 基本通过，仍有遗漏
- README 已对齐（84 工具/8 态/删 ParallelExecutor ✓）。
- ❌ 遗漏：CLAUDE.md:66、HANDOFF.md:28,103 仍写「256 个测试」；且 README 写的 271 已被本轮
  新增测试超过（实测 275 个 @Test）。建议数字统一改为"≈275（以 grep -rc '@Test' 实测为准）"。

## 🚨 复验新发现（本轮最重要的产出）

### BUG-13（P0，既有 bug，非本轮引入）：MCP 带参调用可致全 App 崩溃
- **真机实锤**：curl `tools/call` toast 带 `{"text":"..."}` → 主线程
  `IllegalStateException: You must either set a text or a view`（BridgeFactory.java:124）→ **App 整个崩溃**。
- 根因：McpServer 反射按**参数名**映射 JSON 字段，但构建未开 `-parameters` 编译 flag，
  参数名退化为 arg0/arg1 → 命名参数全部映射为 null → toast(null) 崩主线程。
  一轮精读已记录该隐患（"退化为 arg0/arg1"），本轮真机证实其致命性。
- 这意味着**所有带参数的 MCP 工具调用都在裸奔**，mov-sdk.js（独立 APK 回调宿主）是重灾区。
- 修法要求：① app/build.gradle 开 `javaCompileOptions.compilerArgs += '-parameters'`；
  ② 桥方法入参做 null 防御（toast 等 UI 操作对 null text 拒绝而非崩溃）；
  ③ McpServer 按位兜底（单参方法 JSON 只有 1 个字段时按位置映射）；
  ④ 配套真机 curl 回归（带参调用 10 个工具抽样）。

### BUG-14（测试债）：McpServerTest 假覆盖改写（见 BUG-2）

## 长期债登记（本清单关闭后转入 MOV-TECH-DEBT.md）
| 编号 | 内容 | 来源 |
|---|---|---|
| BUG-4a | ✅ 已修复 `4d852b5` aiChatWithModel 裁剪行笔误 | 二轮复验 |
| BUG-4b | ✅ 已修复 `720beb8` per-room 历史从 journal.jsonl 重建 | 一轮清单方案A |
| BUG-5 | ✅ 已核实 `2598a39` 暂缓修（状态机加固专项） | 一轮清单 |
| BUG-7 | ✅ 已核实 `2598a39` 代码违规（安全轮次修复） | 一轮清单 |
| BUG-8 | ✅ 已修复 `6f388e8` chat.js streamPane 死代码 | 一轮清单 |
| BUG-12 | CLAUDE/HANDOFF 测试数 256→实测；README 271→275 | 二轮复验 |
| BUG-13 | **MCP 带参调用崩溃（P0，优先修）** | 二轮复验新发现 |
| BUG-14 | ✅ 已重写 `73e995c` McpServerTest 行为测试 | 二轮复验 |

## 最终裁决

**清单通过关闭。** 12 项：8 全过（1/2/3/4/6/9/10/11）、2 基本通过带债（8/12）、2 转长期债（5/7）。
**下一批第一优先 = BUG-13（MCP 带参崩溃）**——它是 mov-sdk 战略链路上的地雷。

设备善后提示：平板上留有验收注入的 mock 模型 `mock-accept`（默认模型，指向 127.0.0.1:8787），
请在运行页删除或改回原默认模型。

---

# 三轮复验记录（2026-07-29 23:00 · 验收人）

> 三轮 commit：4d852b5。验收方式：diff 审查 + 本机构建（BUILD SUCCESSFUL 1m3s）
> + 真机（22:57 构建）curl/CDP 实测 + class 文件 javap 验证。

### BUG-13 ✅ 主修复通过（真机实证）+ ⚠️ 残留 BUG-13b（P1）
- javap 验证：`-parameters` 生效，.class 含 MethodParameters 属性。
- 真机实证：tools/list 的 toast inputSchema 显示**真实参数名 `message`**（修复前为 arg0）；
  用正确键 `{"message":"..."}` 调用 → 执行成功、App 存活、0 FATAL。
- **验收人自我修正**：我二轮的崩溃复现用的是错误键 `text`（真实参数名是 `message`）——
  修复前 arg0 任何键都崩，诊断结论不受影响；但特此记录验收用例本身的瑕疵。
- ⚠️ **BUG-13b（P1，未修）**：修法第 ② 条 null 防御未做——键名错误或缺参时参数仍为 null，
  `toast(null)` 主线程崩溃杀全 App（三轮实测：错误键 `text` 调用 → 同款 FATAL，复现两次）。
  任何外部 MCP 客户端参数不全都是远程杀 App 的向量。
  要求：BridgeFactory.toast 等 UI 方法 null/empty 拒绝 + McpServer 缺参返回 -32602 而非传 null。
- 备注：debug 构建已验证；若未来开启 minify，需在 proguard 加 `-keepparameternames`（写进 ONBOARD）。

### BUG-4a ✅ 通过
- `getHistory(null)` → `getHistory(rid)` 一行修复，diff 核对无误。

### BUG-12 ✅ 通过
- CLAUDE.md/HANDOFF.md 256→271 已改。备注：实测 @Test 已 275 个（三轮新增所致），
  数字下次顺手校准即可，不阻塞。

## 清单最终状态（三轮关闭）

**原 12 项全部关闭**（10 全过 + 5/7 转长期债）。复验新增项：BUG-13 主修复 ✅；
残留开放项 = **BUG-13b（null 防御，P1）**、BUG-4b（重启持久化）、BUG-14（McpServerTest 假覆盖）、
BUG-8 streamPane、BUG-5/7 核实记录——全部已登记长期债表，转入 MOV-TECH-DEBT.md 跟踪。

**给程序员的下一批第一优先：BUG-13b。** 它是同一个崩溃向量的另一半，且只需几行防御代码。

---

# 最终确认（2026-07-29 23:10 · 验收人）

> commit：08071f3（McpServer 缺参 → -32602 拒绝）。真机（23:0x 构建）curl 三连实测：

| 用例 | 结果 |
|---|---|
| ① 错误键 `{"text":"x"}` | ✅ `-32602 缺少必填参数: message`，App 存活 |
| ② 空参 `{}` | ✅ 同上拒绝，App 存活 |
| ③ 正确键 `{"message":"13b-OK"}` | ✅ 正常执行 |
| 全程 | **0 FATAL**（此前同款调用复现过两次主线程崩溃杀 App） |

**BUG-13b 通过。至此：原 12 项 + 复验新增 13/13b 全部关闭，验收结束。**
残留长期债（BUG-4b 重启持久化 / BUG-14 假覆盖测试 / BUG-8 streamPane / BUG-5/7 核实记录）
按登记转入 MOV-TECH-DEBT.md 跟踪，不属于本清单。

---

## 明确不做

- factory-edition/ 内所有已知 bug（MovDBBridge Integer/Long 强转等）——封存仓不修。
- MOV SDK 文档补写、Hermes 触发率、ActionInterceptor、并行执行——这些是功能/设计项，不在本 bug 清单内。
- 任何顺手重构、格式化全文件、升级依赖。
