# 黄金样本定稿（OCR Golden Samples）— P0b

> 状态：✅ P0b 完成（CPU 基线跑通 + 3 张黄金图 + bf16/fp16/int8 精度对照）
> 日期：2026-08-01
> 依据：docs/DESIGN_OCR_MOBILE.md P0；docs/OCR_RSWA_ANALYSIS.md
> **黄金样本一经定稿锁死，换图对照即打回。**

## 1. 执行环境（复现必需）

| 项 | 值 |
|---|---|
| 设备 | 小米平板 24018RPACC（arm64，root，kernelSU） |
| 运行环境 | MOV-APP proot Linux（Ubuntu 24.04.3 aarch64）+ Python 3.12 venv |
| 依赖 | torch 2.13.0+cu130（CPU）、transformers==4.57.1、torchvision、Pillow、einops、addict、easydict、pymupdf、psutil、matplotlib、requests |
| 模型 | `PaddlePaddle/Unlimited-OCR`（ModelScope 镜像，与 HF 同源），bf16 权重 6.2GB |
| 推理方式 | base 模式（image_size=1024, crop_mode=False），`no_repeat_ngram=35, window=128`，temperature=0 |
| 复现脚本 | `ocr/scripts/run_cpu_baseline.py`（CPU patch + 多精度）；`ocr/scripts/download_model.sh`（权重下载+SHA256） |

> ⚠️ 关键环境事实：transformers 需钉 **4.57.1**（5.x 移除了 `is_torch_fx_available`，模型代码无法导入）；torch 内置 qint8 动态量化在 aarch64 不可用（`unknown architecure`），int8 用权重舍入模拟，见 §4。

## 2. 黄金测试图（`ocr/testdata/golden/`，已锁）

| 文件 | 内容 | 验证点 |
|---|---|---|
| golden1_doc_chinese.png | 中文打印体文档页（标题/副标题/四条款/列表/落款） | 基础转录、条款结构、列表 |
| golden2_paper.png | 论文页（标题/作者/摘要/LaTeX 公式/HTML 表格/图注） | 公式与表格结构化输出 |
| golden3_receipt.png | 票据/收据（表头/明细表/合计/支付信息） | 表格抽取、金额数字、票据要素 |

3 图均 1024×1448，白底，正文 34px（base 模式 0.707 缩放后 ~24px 有效，保证小字可读）。
生成脚本：`ocr/scripts/make_golden_images.py`（Windows 侧，字体走 `C:/Windows/Fonts/`）。

## 3. 黄金参考输出（bf16，已锁）

### 3.1 golden1_doc_chinese（395 字符，wall=643.3s，rss=7.0GB）

```
《智能终端软件研发中心管理条例》
(2026年7月第3次修订)
第一条 为规范智能终端软件研发中心的项目协作、代码质量与数据安全，依据《软件研发规范指南》制定本条例。本条例适用于本中心全体工程协作人员。
第二条 项目房间实行文件仓库制。所有产出文件须存放于对应项目房间目录内，跨房间调用需在运行台登记引用关系，禁止擅自复制第三方项目资产。
第三条 协作遵循指令优先路由原则：明确的功能指令直接执行；语义模糊的请求由大脑模型生成计划，经项目主持人确认后实施。
第四条 数据安全红线：支付、短信、通讯录、通话记录等敏感能力一律不允许第三方模型接触；识别类任务必须在端侧完成，识别内容不得写入运行日志。
第六条 版本与交付要求:
（一）每阶段改动须通过编译与全量测试；
（二）重大改动须先备份并标注日期与状态；
（三）黄金样本一经定稿，换图对照即打回；
（四）模型权重与口令类资产禁止进入版本库。
```
> 注：模型在「（四）」后发 EOS 提前收尾（第七条/落款未输出）——这是参考实现的真实解码行为，MNN 移植需复现此行为。RAW 输出含 `<|det|>type [bbox]<|/det|>` 版面标记。

### 3.2 golden2_paper（615 字符，wall=191.2s，rss=7.0GB）

```
一种基于参考滑动窗口的文档解析方法
张某某 1，李某某 2
(1 智能终端软件研发中心 2 计算视觉实验室)
摘要：针对长文档连续解析中键值缓存随输出线性增长的问题，本文提出参考滑动窗口注意力，保持参考前缀常驻，仅对最近输出令牌维护定长窗口，使缓存占用为常数。
2 方法
给定查询、键、值矩阵，参考滑动窗口注意力的计算定义如下，其中 W 表示窗口大小：
\[
\text { Attention } (Q, K, V) = \operatorname{softmax} \left(Q K ^ {T} / \sqrt {d _ {K}}\right) \cdot V
\]
其中 d 为键向量的维度，窗口内仅保留最近 W 个令牌。
表 1 不同解码策略的缓存占用对比
<table><tr><td>解码策略</td><td>缓存增长</td><td>上下文长度</td></tr><tr><td>全注意力</td><td>随输出线性增长</td><td>32K</td></tr><tr><td>参考滑动窗口</td><td>恒定</td><td>32K</td></tr><tr><td>流式外推</td><td>窗口内恒定</td><td>8K</td></tr></table>
图 1 参考滑动窗口的缓存占用曲线（略）。
实验表明，在 40 页连续解析任务上，所提方法将峰值内存占用降低约 60%，且满足移动端实时性要求。
```
> 模型把公式转成 LaTeX、表格转成 HTML——**结构化输出能力已验证**，直接喂 6.7 云端协同的分段/结构化需求。

### 3.3 golden3_receipt（516 字符，wall=424.3s，rss=7.0GB）

```
鑫诚数码科技 销售小票
票据编号：XC-20260801-0093
日期：2026-08-01 14:32
收银台：03 收银员：王某某
电话：010-88997766
<table><tr><td>商品名称</td><td>单价</td><td>数量</td><td>金额</td></tr><tr><td>无线键盘 K520</td><td>89.00</td><td>1</td><td>89.00</td></tr><tr><td>鼠标 双模静音</td><td>45.50</td><td>1</td><td>45.50</td></tr><tr><td>USB 扩展坞 4口</td><td>129.00</td><td>1</td><td>129.00</td></tr><tr><td>Type-C 数据线</td><td>19.90</td><td>2</td><td>39.80</td></tr></table>
合计金额：□ 303.30
实收：¥ 305.00 找零：¥ 1.70
支付方式：支付宝 交易号：2026080100319256
本小票仅作为消费凭证，不作为报销依据。
感谢惠顾，欢迎再次光临！
```
> 全表金额/交易号正确。注意「合计金额」行的 `¥` 误读为 `□`（同图「实收/找零」行的 `¥` 又读对了）——货币符号字形识别不稳定，属参考真实行为，锁定。

## 4. 精度对照表（P4 精度选型判据）

方法：同输入、同参数，三档精度各跑一遍，以 bf16 为黄金参照，字符级 LCS 相似度。
- fp16：模型 fp16 加载（官方 infer 硬编码 bf16 图片，脚本已 patch forward 统一 dtype）
- int8：**权重 int8 舍入模拟**（per-channel scale=amax/127，解码器 2196 个 Linear 舍入，计算仍 bf16）——因 torch 内置 qint8 动态量化在 aarch64 不可用，改用此模拟精确度量「int8 权重精度对输出的影响」

| 图片 | 精度 | 相似度 | 字符编辑(删/增) | 耗时 s | RSS GB |
|---|---|---|---|---|---|
| golden1 | bf16 | — | — | 643.3 | 7.0 |
| golden1 | fp16 | **100.0%** | 0/0 | 424.9 | 5.1 |
| golden1 | int8(模拟) | **100.0%** | 0/0 | 659.2 | 7.7 |
| golden2 | bf16 | — | — | 191.2 | 7.0 |
| golden2 | fp16 | **100.0%** | 0/0 | 316.5 | 4.9 |
| golden2 | int8(模拟) | **99.8%** | 1/1 | 676.8 | 7.1 |
| golden3 | bf16 | — | — | 424.3 | 7.0 |
| golden3 | fp16 | **100.0%** | 0/0 | 564.5 | 5.2 |
| golden3 | int8(模拟) | **100.0%** | 0/0 | 443.8 | 7.1 |

**int8 唯一差异**（golden2 论文页公式）：`\sqrt {d _ {K}}` → `\sqrt {d} _ {K}`——LaTeX 下标标记的书写位置差，**语义等价**（均为 d_K），int8 舍入推动了 TeX 标记的 logit 决定。内容零错。

**结论（P4 输入）**：
- **fp16：零损失，可全精度使用**
- **int8 per-channel：≥99.8%，满足「相似度 ≥98%」判据，int8 可用**；实测差异仅为 TeX 标记格式，语义不变
- P4 建议：优先 int8（内存 3.3GB），若 int4 掉字严重（OCR 对数值敏感）退回 int8 混合方案；纯端侧隐私场景无精度损失顾虑（识别内容不出设备）

## 5. 复现步骤

```bash
# 1. 下载模型（~6.2GB）+ SHA256 校验
ocr/scripts/download_model.sh /path/to/model   # 权重不入 git，脚本+清单入库
# 2. 平板 proot 内跑基线（见 run_cpu_baseline.py 头注释，CPU patch 说明）
python3 ocr/scripts/run_cpu_baseline.py \
  --model /path/to/model \
  --images ocr/testdata/golden/golden1_doc_chinese.png \
           ocr/testdata/golden/golden2_paper.png \
           ocr/testdata/golden/golden3_receipt.png \
  --dtype bf16            # 黄金；fp16 / bf16 --quant-int8 对照
# 3. 精度对照表
python3 ocr/scripts/compare_precision.py --dir <results目录>
```

## 6. 对接 6.7 云端协同（输出 schema 约束）

黄金输出已验证模型原生能力：
- **页锚点**：多页模式原生 `<PAGE>` 分隔（infer_multi）
- **版面结构化**：`<|det|>type [bbox]<|/det|>` 标记可剥离出段落级边界（标题/正文/表格/公式/equation），天然支持分段检索
- **结构化内容**：表格→HTML、公式→LaTeX，云端 LLM 分块摘要可直接消费

P5 集成时：段锚点 + 结构化 Markdown 直接复用这些原生标记，无需重训；「同一文档只 OCR 一次、按段发云端」物理基础成立（见 DESIGN_OCR_MOBILE.md 6.7 验收）。

---

## 附：环境踩坑记录（P0b）

1. HF 全端口不可达 → 权重/源码走 ModelScope 镜像 `PaddlePaddle/Unlimited-OCR`
2. transformers 5.x 不兼容（`is_torch_fx_available` 被移除）→ 钉 4.57.1
3. 官方 infer/forward 硬编码 `.cuda()` + `autocast("cuda")` → 脚本 CPU patch（no-op + nullcontext）
4. torch qint8 动态量化 aarch64 不可用 → int8 权重舍入模拟
5. proot 长任务后 execve 退化（date/tee 无法执行）→ 分批独立 proot 会话
6. app 重装导致 native lib 路径漂移 → proot.sh 动态解析包路径
7. fp16 图片 dtype 硬编码 bf16 导致 masked_scatter 不匹配 → forward patch 统一 dtype
