# MOV MCP 工具登记表（资产 → 出口）

> 数据源：真机 21770d7d tool_manifest 实拉（2026-08-07，查验员登记）。
> 口径：**MCP = 可调用的出口**（有名字/有入参/能 invoke）。环境（proot Ubuntu）、引擎（journal/策展）、资源（相机硬件）是底层资产，不在此表——它们记在总览护城河页。
> 全量 **151 个出口工具**，按「资产 → 出口」登记：

## 〇、MCP 是什么（对齐官方定义）

**MCP（Model Context Protocol）**是 AI 应用连接外部工具/数据源的**开放标准协议**（2024 年 11 月由 Anthropic 首发；**2025 年 12 月已捐赠给 Linux 基金会旗下 Agentic AI Foundation（AAIF）**，Anthropic/OpenAI/Block 共创，治理中立）。核心约定：

- **角色**：server 暴露能力（tools 工具 / resources 资源 / prompts 模板），client 连接调用
- **通信**：JSON-RPC 2.0；传输走 stdio 或 **Streamable HTTP**（现行正线；旧 HTTP+SSE 已于 2026-07 版正式弃用，一年过渡）
- **最新规范**：**2026-07-28 版**——无状态协议核心、多轮请求、Tasks 扩展（持久任务轮询）、授权强化（CIMD 取代 DCR）、Roots/Sampling/Logging 弃用
- **生态**：SDK 月下载破 1.1 亿；ChatGPT/Claude/Cursor/Gemini/Copilot 全线一等支持；2026-01 首个官方扩展 MCP Apps（server 渲染 UI）

**MOV 对官方的支持（代码实证）**：8389 MCP server 跑在**官方 Java SDK** 上（`io.modelcontextprotocol.sdk:mcp-core:1.0.2`，app/build.gradle:81；`MovMcpServer` 用 `McpServer.sync` + Streamable HTTP 传输）——任何标准 MCP client 都能按官方协议接入；MOV 也作为官方协议 client 接社区 server。**8389 用的 Streamable HTTP 正是 2026-07 规范的正线传输**（旧 SSE 已弃用），未站错队。

**MOV 的「自创内嵌 MCP」是什么**：协议层完全兼容官方，自创的是**内容层**——把一台 Android 设备的能力（记忆/工具/Linux/浏览器/跨设备互调）封装成 MCP 服务面。官方给了「怎么连」，MOV 造了「连上能用到什么」。


## 一、护城河资产的 MCP 出口（独有核心）

| 底层资产 | 出口（数量） | 工具清单 |
|---|---|---|
| ① 记忆（journal/策展/因果） | 17 + 1（OCR 采集） | `memory.save` `memory.load` `memory.delete` `memory.list` `memory` `memory.cover` `memory.search` `face_history` `drama_memory` `watch_history` `face_mine` `causal.record` `causal.query` `causal.link` `causal.forget` `causal.rule` `causal.reflect` `ocr` |
| ② 内嵌 Linux（MCP 体系） | 2 | `shell.exec` `hermes.task`（hermes.task 工单20 在途） |
| ② ConnectWeb 浏览器 | 17 | `browser.open` `browser.wait_for` `browser.scroll` `browser.click` `browser.type` `browser.submit` `browser.click_and_read` `browser.snapshot` `browser.read` `browser.execute` `browser.done` `wb.navigate` `wb.snapshot` `wb.click` `wb.fill` `wb.evaluate` `wb.screenshot` |
| ③ 隐私通道（保险柜） | 3 | `vault_lock` `vault_unlock` `vault_list` |
| ④ 设备控制 | 14 | `device.cmd` `location.get` `wifi.scan` `bluetooth.list` `wifi.status` `wifi.toggle` `camera.info` `sensor.list` `ui.dump` `ui.tap` `ui.swipe` `ui.input` `camera.capture` `screen.capture` |

## 二、公共服务封装出口（自研封装，数据源公共）

| 服务 | 数量 | 工具清单 |
|---|---|---|
| 12306 火车票 | 9 | `train_search` `get-tickets` `get-current-date` `get-stations-code-in-city` `get-station-code-of-citys` `get-station-code-by-names` `get-station-by-telecode` `get-interline-tickets` `get-train-route-stations` |
| 百度地图 | 10 | `map_geocode` `map_reverse_geocode` `map_search_places` `map_place_details` `map_directions_matrix` `map_directions` `map_weather` `map_ip_location` `map_road_traffic` `map_poi_extract` |
| 网页/购物 | 5 | `web.search` `web.fetch` `shop_search` `web_sites` `web_adapt` |
| 音乐/追剧源 | 5 | `music_search` `face_search_drama` `video_sources` `mayi_latest` `check_drama_updates` |

## 三、常规件出口（自研 baseline，谁都有但得有）

| 数量 | 工具清单 |
|---|---|
| 68 | `file.list` `file.read` `file.write` `app.scaffold` `app.package` `clipboard.write` `notification.post` `notification.cancel` `timer.set` `timer.cancel` `timer.list` `battery.status` `network.info` `storage.info` `volume.set` `brightness.set` `session.search` `skill.list` `todo.add` `todo.list` `todo.done` `tts.speak` `kanban.add` `kanban.view` `cron.add` `cron.list` `cron.remove` `message.send` `process.list` `file.info` `calc.math` `qr.scan` `calendar.add` `calendar.today` `contacts.search` `app.list` `share.text` `clipboard.read` `email.send` `speech.recognize` `audio.record` `download.file` `hash.text` `uuid.generate` `base64.encode` `base64.decode` `qr.generate` `toast` `sms.recent` `media.play` `app.launch` `app.stop` `app.info` `settings.get` `file.rename` `file.delete` `file.copy` `search.replace` `search.chats` `read.chat` `read.logs` `code.search` `generate.image` `model.list` `model.add` `model.set_default` `tool.describe` `skill.echo` | undefined |

## 四、体系件状态（非工具，是通道）

| 件 | 状态 | 说明 |
|---|---|---|
| 8389 MCP server | ✅ 已验收 | 只读集 + 审批写；Kimi Code 实测接入 |
| 8388 入站网关 | ✅ 已验收 | infer/memory/tools + PII 打码闸，fail-closed |
| A2A relay（mow.kim） | ✅ 基建完成 | 跨设备互调，TLS |
| MCP 工厂 | 🔜 在途（工单21，PC 端） | 产合格工具：本体+查验报告+能力说明书 |

## 登记纪律

- 重拉更新：CDP `B.query({q:'tool_manifest'})`（手法见 ACCEPTANCE_PLAYBOOK §2）
- 新工具合 main / 出厂后回本表登记
- 红线域（message.*）登记在案，调用受红线约束
