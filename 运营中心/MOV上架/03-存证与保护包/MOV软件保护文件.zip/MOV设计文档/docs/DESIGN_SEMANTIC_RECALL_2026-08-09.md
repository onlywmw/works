# DESIGN：语义召回层（端侧 embedding 增强 Journal.search）— 2026-08-09

> 来源：用户拍板「补上语义召回，不然体验感不好」；缺口定位见 `docs/EVAL_JCODE_MOV_2026-08-09.md`（对照 jcode 语义记忆后的结论：MOV 记忆体系强在因果引擎，弱在召回）。
> 关系：**不动因果引擎本体**，只增强 `Journal.search` 的召回层；长在 journal 通路（铁律③），不另起平行库。
> 结论先行：**端侧 embedding（llama.cpp 第二实例）是唯一符合隐私红线的路线**；检索 = **方案 B**（子串命中 ≥K 走保底，<K 对最近时间窗补语义重排——吸收查验 A1 漏斗漏洞），embedding 失败静默回退子串排序，契约不变。修订细节见 `docs/PLAN_SEMANTIC_RECALL_2026-08-09.md`。

---

## 〇、缺口定位

| | 现状（MOV） | 目标 |
|---|---|---|
| 检索方式 | `Journal.search` 纯子串匹配（`text.toLowerCase().contains(q)`），扫 journal + archive 两文件 | 子串召回 + **语义重排**：能召回「表述不同但意思相关」 |
| 示例 | 存「凌晨三点才睡」搜「睡眠不足」→ 搜不到 | 同上搜索 → 命中 |
| 隐私 | 因果记忆：手机不存原文只存哈希，云端只收脱敏叙事 | 保持不破 |

## 一、方案（3 部件）

### 部件 1：EmbeddingClient（llama.cpp `/v1/embeddings` 封装）
- 新建 `llama/EmbeddingClient.java`，对 127.0.0.1:8081 发 `/v1/embeddings`（OpenAI 兼容），返回 float[]。
- **可注入接口**（照 `LlamaServerManager.HealthProbe` 模式）：单测注入假 embedder，确定性 cosine，零网络。
- Bearer token 鉴权（照现有 llama serve 纪律）。

### 部件 2：EmbeddingServerManager（第二 llama-server 实例）
- 端口 **8081**（现有 OCR 是 8080，隔离不互相影响）。
- 模型：**bge-small-zh-v1.5**（GGUF，int8 ~24MB，中文语义检索成熟小模型），放 `models/embedding/`。
- 生命周期照抄 `LlamaServerManager`：懒启动 → healthz-on-call → 空闲 30min 退出；`decide` 纯函数 + HealthProbe 注入（复用现有可测设计，可拆公共父类或拷贝结构）。

### 部件 3：`Journal.search` 增强（契约不变）
- 现签名 `search(roomId, query, limit)` 返回 `{ok, data:{events:[{seq,ts,type,snippet}], count}}`——**对外契约、字段、前端零改动**。
- **检索策略（修订，吸收查验 A1）**：子串粗筛 → 命中 ≥K(3) 走保底（ts 倒序，与现状一致）；命中 <K → 对最近 30 天/≤50 条记忆补做批量 embedding + cosine 重排（query 加 BGE 指令前缀、阈值 ≥0.5），子串命中前置、语义命中后置，截 topN。详见 `docs/PLAN_SEMANTIC_RECALL_2026-08-09.md` §二。
- **失败静默回退**：embedding 服务未起 / 超时 / 模型未装 → 回退现有子串 ts 排序，不打断、不抛错（照 MOV 容错哲学，search 不因增强层挂掉而白屏）；未就绪时本次直接回退 + 异步预热。

## 二、为什么必须端侧（隐私红线）

- 云端 embedding = 把记忆原文/搜索文本发第三方 embedding API → **违背因果记忆设计**（「手机里不存你的原文，只存哈希；云端只给脱敏叙事」）。
- DeepSeek **无 embedding API**（AiClient 现只走 `/chat/completions`）；OpenAI embedding 需新增 key + 把记忆内容外发。两者都不可接受。
- 端侧 llama.cpp 已有运行底座（8080），加第二实例成本可控，算力/隐私都在本地。

## 三、检索策略（性能/容错/电热）

- **子串召回保底（修订）**：子串命中 ≥K 直接返回，零语义开销；语义补充只在命中 <K 时对「最近 30 天/≤50 条」触发（避免粗筛漏斗先空）。
- **批量**：候选 ≤50 单批 batch（input 数组），几十 ms 级，不做全量索引（v1 明确不做）。
- **电热纪律**：语义推理只在「检索被调用且子串命中不足」时触发，不后台常驻；L3/空闲窗口不受影响。

## 四、分期

| 期 | 内容 | 验收 |
|---|---|---|
| M1 | `EmbeddingClient`（批量 payload/解析/cosine/mapError，纯 JVM） | 单测：payload 结构、批量多向量按 index、非法 null、cosine 全分支、mapError |
| M2 | `EmbeddingServerManager`（8081 实例 + 生命周期） | 单测：decide 状态机、healthz 假探针零网络 |
| M3 | `Journal.search` 方案 B + `SemanticReranker` + 测试 | 接缝（JournalTest fake 注入）+ 实现（SemanticRerankerTest，变异恒零/恒等余弦必红）；子串保底不回归 |
| M4 | 真机验证 | journal 存「凌晨三点才睡」搜「睡眠不足」能召回；子串召回全过；logcat 见语义重排日志 |

## 五、验收标准（对齐 MOV 交付铁律）

1. 编译 + 全量单测绿（新代码必配新测试）。
2. **变异反证（靶点对齐）**：SemanticRerankerTest 对 cosine 排序/阈值逻辑做变异（恒零向量、恒等余弦）→ 排序断言必红（带真实计数）；JournalTest 接缝用 fake 注入，不经过真实现。
3. 真机 M4：语义召回正反例各一（正例「表述不同意思相关」命中、反例子串无命中不误召回）；证据链：触发截图 → logcat（embedding 调用/回退日志）→ 结果截图。
4. 前端零改动：`hermes-shell.html` / JS 不动，契约字段不变。

## 六、明确不做（v1）

- 不做全量语义索引缓存（`embedding.index.json` 可丢弃缓存留 v2，先候选集实时算）。
- 不碰因果引擎（CausalEngine）、不碰记忆三层 L1/L2/L3、不碰 serve。
- 不做云端 embedding（隐私红线）。
- 不引入新的外部依赖（仅用 llama.cpp 现成能力 + 已有文件系统）。

---

## 附：决策落账（原「待确认」，已由 PLAN §八 决策，2026-08-09 查验复核后勾销）

1. 模型文件来源 → **桌面下载 GGUF → `adb push`** 到 `filesDir/models/embedding/`（A7）。
2. 端口 8081 → 与 serve 纪律一致（127.0.0.1 + Bearer token），无占用（已确认）。
3. 派单去向 → **登记 TASKBOARD 新工单**（查验员派单制，A8）。
