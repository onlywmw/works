# AUDIT：记忆层可靠性盘点（批1 地基四要素）— 2026-08-06

> **派单**：工单7 PLAN_SURPASS 批1 幕一（p3 验收员盘点，只交盘点报告，不写生产代码）
> **依据**：docs/PLAN_SURPASS.md §五（批1 地基四要素）、§六（下一步 1 = 演化记忆的存取/演化正确性）；
> docs/DESIGN_MEMORY_LAYERS.md（记忆三层 + v2 读取时按需覆盖）
> **范围**：Journal（append-only 真理源）、memoryCover（bdb3593）、L3 提炼（7faedef）、因果记忆引擎、以及全部记忆读写的接线（桥/工具/serve）
> **纪律**：只新增本文档；引用代码给 `文件:行号`；不碰 p2 在途文件（assets/）

---

## 〇、派单线索与现状的出入（以代码为准）

| 派单线索 | 代码现状 | 依据 |
|---|---|---|
| 因果记忆引擎在 `feat/causal-memory` 分支，未并 main | **已并入 main**：`app/src/main/java/com/hermes/android/causal/` 12 文件 + `app/src/test/.../causal/` 11 个测试类 + `CausalToolProvider` 已注册（ToolRegistry.java:1084）；本机无 causal-memory 分支 | ToolRegistry.java:1084；causal 提交历史（e45b3f7 仍在修它） |
| L3 提炼（7faedef）"摘要懒生成+冻结注入" | `distillMemory` 已实现（Journal.java:942），但**无任何生产入口**：BridgeKernel 只有 `memory.curate`/`memory.cover`（BridgeKernel.java:776/790），serve 无 distill 端点，JS 无调用 | 见 §四 缺口 G15 |

**核心结论先行**：记忆层「写侧」通路完整且有测试；**「读侧」与「演化侧」的接线几乎未落地**——
`memoryCover` 无生产调用方、`distillMemory` 无调度入口、记忆不注入 AI 上下文（AgentLoop.java:964 只给模型"写草案"的指令，无读注入）。
批1 四要素里，**覆盖即时性在生产上是断线的**，存取/演化正确性各有一处真实缺陷（G1 tombstone 重 add 压制、G2 seq 复用）。

---

## 一、记忆层现状地图

```
写侧（已接线）
  AgentLoop prompt 指令（写 _memory_draft，单行硬顶）        AgentLoop.java:964
  L2 先抢救后压缩：压缩前抽 todo 草案                        AgentLoop.java:1057
  ToolRegistry.memory 工具 add/replace/remove/read          MemoryToolProvider.java:260-313
  serve /memory curated/replace/remove                     MovInboundServer.java:343-398
  Journal：appendDraft / memoryRemove(tombstone) / memoryReplace / promoteDraft / expireStaleDrafts / memoryCurate

读侧（代码存在，接线缺失）
  memoryDrafts（过滤 tombstone/晋升/TTL）                  Journal.java:790
  memoryCurated（§ 分隔投影）                              Journal.java:855
  memoryCover（预算覆盖，纯算法）                          Journal.java:876
  search（C2 按内容检索，journal+archive）                  Journal.java:351
  L3 提炼 distillMemory（冻结注入 _memory_summary）          Journal.java:942
  桥：memory.cover / memory.curate                          BridgeKernel.java:790 / 776
  serve：curated / replace / remove                        MovInboundServer.java:369-390

因果记忆（已并入 main）
  causal.* 6 工具（record/query/link/forget/rule/reflect）   CausalToolProvider.java:65-198
  桥：causal.query/match/chain/index/sweep                  BridgeKernel.java:799-829
  测试：CausalChain/Engine/Hash/Index/Oracle/PromptBuilder/RuleEngine/ToolProvider/NarrativeBuilder/PatchCompiler/PiiScrubber 共 11 类
```

---

## 二、批1 四要素逐项盘点

### 要素 1 · 存取正确性（记忆的读/写对不对）

**现状**：
- 写：`appendDraft` 单行硬顶/空拒写/非法房间拒写（Journal.java:756-771）；`memoryRemove` 写 tombstone（:833）；`memoryReplace` = remove + add（:848）；错误码：-1（拒写/失败）、-2（空）。
- 读：`memoryDrafts` 过滤 tombstone/已晋升/超 TTL（:790-828）；`memoryCurated` § 分隔投影（:855）；`memoryCover` 预算覆盖（:876）；`search` C2 按内容检索覆盖 journal+archive（:351-402）。
- 双脑共用：工具侧 `MemoryToolProvider.memory` read（:292-297）+ serve 侧 `MovInboundServer.curated`（:369-374），均 `new Journal` 实例读同一 roomsDir。

**已有测试覆盖**：
- JournalMemoryDraftTest：单行/回车/空/多行拒写（:40-56）、memoryDrafts 有效/空房（:60-69）、tombstone 排除（:243-249）、replace 更新（:251-257）、curated § 分隔（:259-265）、cover 预算内全逐字/超预算塌缩/原文保留/空房/预算钳制（:191-239）。
- JournalTest：append seq 分配/header/非法房间/index/80 字摘要（:36-134）、tail/replay/historyPage（:137-242）、roll 大 journal（:258）、search 正反例/大小写/空 query/archive（:369-431）、5000 事件性能（:298）、多房间隔离/seq 单调（:333-367）。

**缺口**：

| # | 缺口 | 证据 | 修法建议 | 量级 | 验证 |
|---|---|---|---|---|---|
| **G1** | **tombstone 按文本压制，删除后重新 add 同文本被永久屏蔽** | Journal.java:800-816：先收集全部 tombstone 文本集，再 `if (tombstoned.contains(draftText)) continue`——`remove("A")` 后 `appendDraft("A")` 的"A"仍被排除，用户"删掉又想起，重新记住"失效 | add 事件携带新 seq；tombstone 匹配按"被删事件 seq > 最近一次 add 同文本的 seq"判定，add 后同文本 tombstone 失效 | 小（约半天） | **纯单测可验**：先红（构造 remove→add→read=0）→ 修 → 绿 |
| **G2** | **index 与 journal 非原子 → 崩溃后 seq 复用** | append 先写 journal 再 updateIndex（Journal.java:111-117）；`nextSeq` 只读 index（:438-452），index 损坏才走 `scanMaxSeq` 兜底（:455）。崩溃落在"journal 已写、index 未写"之间 → 下条 append 复用 seq → 同 seq 两条事件，回放/检索重复 | ① append 先读 journal 实际最大 seq（O(1) 读尾行）再分配；② 或 nextSeq 失败降级 scanMaxSeq 前先比对 journal 尾部 | 中（1 天） | **纯单测可验**：构造"index 落后于 journal"的临时目录 → append → 断言新 seq 无冲突 |
| **G3** | **memoryReplace 两步非原子，并发交错** | `memoryRemove` + `appendDraft`（Journal.java:848-852）非同一临界区；两脑并发 replace 可交错（A remove 后 A 的 add 被 B 覆盖） | 合并为单次 append（replace 事件含 old/new），或整个 replace 持同锁串行化 | 小-中 | **纯单测可验**：多线程并发 replace 后断言终态一致 |
| **G4** | **双脑读路径无一致性测试** | 工具侧 read（MemoryToolProvider.java:292-297）与 serve 侧 curated（MovInboundServer.java:369-374）各自 new Journal；MovInboundServerTest 只有 no-context 负例（:202），工具侧**无任何测试类** | 加一条跨入口一致性测试：同一 roomsDir，先写后两端读断言 § 分隔结果一致 | 小 | **纯单测可验** |
| **G5** | **appendDraft 错误码不可区分** | 多行/写失败/非法房间均返回 -1（Journal.java:758-770），调用方无法区分"拒写"与"IO 失败" | 定码：-1 拒写、-3 写失败（复用 error envelope 语义） | 小 | **纯单测可验** |
| **G6** | **存取视图依赖 replay 尾部 500 条** | `memoryDrafts`/`promotedDraftSet`/tombstone 收集均走 `replay(REPLAY_TAIL_N=500)`（Journal.java:776/793/1004）；草案+晋升+tombstone 总量 >500 且滚动后，tail 外旧草案状态丢失（已晋升草案复活、旧 tombstone 失效） | 草案区状态改用 `eventsOfType` 全量重建（:726 已有），或草案专用轻量索引 | 中（1 天） | 纯单测可验（构造 >500 草案 + 滚动场景） |

### 要素 2 · 演化正确性（记忆随使用演化对不对）

**现状**：
- 晋升：`promoteDraft` 显式写（:1058）；`memoryCurate` 重复写入 ≥2 自动晋升（:1081-1114）。
- 衰减：`expireStaleDrafts` 写 `_memory_draft_expired`（:1028-1055）；`memoryDrafts` 读时 TTL 过滤（:819）。
- 摘要演化：span 锚定，原文变 → 占位 span 变 → 缓存失效重算（`distill_spanChange_recompress` 已测，JournalMemoryDraftTest.java:347）。
- 因果引擎：四元组/哈希索引/逻辑钩子/账本/遗忘墓碑，11 个测试类。

**已有测试覆盖**：
- 晋升：promote 后排除/写 verified 事件/草案与晋升都是 journal 事件（JournalMemoryDraftTest.java:88-122）；curate 重复晋升/单次不晋升/不同不晋升/限流/变异（:126-187）。
- 衰减：超 TTL 清理/未超不清理（:73-84）；curate 清 stale（:142）。
- 摘要：冻结注入/缓存命中/空 Brain/异常/空摘要/预算内跳过/span 失效（:269-358）。

**缺口**：

| # | 缺口 | 证据 | 修法建议 | 量级 | 验证 |
|---|---|---|---|---|---|
| **G7** | **演化状态（晋升/tombstone/摘要）视图基于 tail 500，滚动后状态复活/丢失** | `promotedDraftSet`（Journal.java:774-787）、tombstone 收集（:800-808）、`cachedSummary`（:1003-1017）全走 replay tail；滚动后这些事件进 archive，tail 内不可见 → 已晋升草案重新当有效、冻结摘要失效重算 | 同 G6：状态重建走 `eventsOfType` 全量；摘要缓存可并读 archive | 中（随 G6 一起） | 纯单测可验（构造滚动场景） |
| **G8** | **摘要占位 span 碰撞 → 误命中缓存** | 占位串 =「历史草案 N 条 · 最早 MM-dd · kind×N」（Journal.java:895-903），无原文指纹；两个不同 span 若 N/最早日期/kind 相同 → 占位串相同 → `cachedSummary` 返回错 span 的旧摘要（:1014） | 占位串追加原文集合指纹（如稳定性 hash）；`cachedSummary` 命中时再校验 collapsed 数 | 小 | **纯单测可验**：构造两批不同原文同统计形状 → 断言不误命中 |
| **G9** | **晋升无"引用验证"记录** | `promoteDraft` 直接写，无"谁引用/是否验证"字段（Journal.java:1058-1070）；curate 用重复≥2 当弱证据（:1108）。设计"晋升靠使用不靠自审"（DESIGN 修正①），但使用痕迹未建模 | 需设计：引用事件（谁在何时引用了哪条草案）→ 晋升带证据链。超出本期打底，建议单独出设计再施工 | 大（设计先行） | 纯单测（注入引用事件）+ 语义需真机 |
| **G10** | **expireStaleDrafts 重复跑对同草案写多条 expired 事件** | 遍历 replay 草案、超 TTL 即 append expired（Journal.java:1036-1053），无"已过期"幂等检查；连续跑两次 → 重复标记事件（memoryDrafts 读时只看 TTL 不看 expired，故无功能影响，但事件流冗余） | expired 事件带草案 seq；扫描时跳过已有 expired 标记的草案 | 小 | **纯单测可验** |

### 要素 3 · 并发/崩溃稳定性

**现状**：append 全程 synchronized（Journal.java:84）；roll 在 append 临界区内同步执行（:120-121）；tail/replay/historyPage/search 非同步读；坏行解析 try-catch 忽略不中断（:166/261/281）。性能有 5000 事件单测（JournalTest.java:298）。

**已有测试覆盖**：roll 触发（:258）、5000 事件回放性能（:298）、多房间隔离（:333）、seq 单调（:355）。**无任何多线程/并发/崩溃中断测试**。

**缺口**：

| # | 缺口 | 证据 | 修法建议 | 量级 | 验证 |
|---|---|---|---|---|---|
| **G11** | **roll 非原子，崩溃可致事件丢失/回放断裂** | roll 顺序：读全 → 追加 archive → 写 snapshot → 重写 journal（Journal.java:592-663）。崩溃在"journal 重写后、snapshot 写前" → 回放用旧 snapshot + 新 journal tail，已截断的头部事件既不在 tail 也不在 archive 索引内 | ① 先写 snapshot 再截断 journal（archive 已先行）；② 崩溃恢复校验：journal 头 seq 与 snapshot.seq 衔接，断裂则从 archive 补 | 中 | 需真机（模拟 kill）或精心构造中间态文件单测 |
| **G12** | **读路径与 roll 并发无保护** | replay/tail（Journal.java:141/206）非同步；roll 在 append 内执行，读侧并发可能读到半滚状态（archive 追加中/journal 重写中） | 读写共用一把重入锁，或 roll 写临时文件 + 原子 rename | 中 | 多线程单测可构造并发场景 |
| **G13** | **大 journal 滚动阻塞写** | roll 全量读 + 全量重写，在 append 临界区内（Journal.java:120-121）；1MB 滚动一次可阻塞秒级 | 滚动迁出临界区（复制待滚文件后异步滚） | 中 | 需真机（量级验证） |

### 要素 4 · 覆盖即时性（读取时按需覆盖，预算内出全貌）

**现状**：`memoryCover` 纯算法已实现（预算内逐字/超预算塌缩 + needsCompress 标记，Journal.java:876-916）；`distillMemory` 摘要懒生成 + 冻结注入（:942-1000）；桥 `memory.cover`（BridgeKernel.java:790）。

**已有测试覆盖**：cover 预算内全逐字/超预算塌缩/原文保留/空房/预算钳制（JournalMemoryDraftTest.java:191-239）；distill 注入/缓存命中/span 失效/归因 7 例（:269-358）。

**缺口**：

| # | 缺口 | 证据 | 修法建议 | 量级 | 验证 |
|---|---|---|---|---|---|
| **G14** | **memoryCover 无生产调用方——覆盖即时性在生产断线** | 桥 `memory.cover` 存在（BridgeKernel.java:790-796）但 JS 侧 0 调用；AI 上下文（HermesClient/AgentLoop/HeavyWorker/BridgeAi）无 memoryCover/memoryCurated 注入（grep 全空）。DESIGN §六"读取时对记忆段做预算覆盖"未落地主链路 | 明确读侧接线：AI 上下文注入口（如 AgentLoop 计划构造/冻结注入时调 memoryCover）+ JS 展示口；配套接线后行为测试 | 大（接线 + 语义 + 测试） | 算法纯单测可验；主链路注入需真机 |
| **G15** | **distillMemory 无调度/无入口 → needsCompress=true 永不补齐** | BridgeKernel 只有 curate/cover 两 case（:776/790），无 distill；serve `/memory` 无 distill action（MovInboundServer.java:350-392）；无 workflows 触发器（灭屏+充电/time_cron）挂载。摘要永远显示占位串 | ① 桥/serve 加 distill 端点（懒触发）；② 空闲补齐挂 workflows 触发器（DESIGN 修正④） | 中 | 提炼编排纯单测可验；空闲触发需真机（logcat） |
| **G16** | **预算口径：实现是"预算 verbatim + 1 摘要"** | 超预算 cover 输出 = 1 摘要 + 预算逐字 = 预算+1 条（Journal.java:905-914；测试断言 4=3+1，JournalMemoryDraftTest.java:205） | 定口径：DESIGN §七验收 5"预算内不超"与实现不符，需明确"预算指逐字条数，摘要不计"并写进 DESIGN | 小 | 纯单测可验（断言已有） |

---

## 三、优先级建议（幕二施工清单的输入，待验收员批准）

**P0（存取正确性真缺陷，先修，均纯单测可验）**
1. G1 tombstone 重 add 压制 → 修 + 变异（把修复逻辑改恒空 → 测试必红）
2. G2 seq 复用（index 落后于 journal）→ 修 + 变异

**P1（演化正确性 / 一致性）**
3. G8 span 碰撞误命中 → 加指纹
4. G7+G6 演化状态视图脱离 tail 500（eventsOfType 全量重建）
5. G4 双脑读路径一致性测试（工具侧补测试类）
6. G10 expire 幂等

**P2（稳定性，量级偏大，排期考虑）**
7. G11 roll 原子性 / G12 读写并发 / G13 滚动阻塞
8. G3 replace 原子性

**P3（接线，依赖产品语义，需设计确认）**
9. G14 cover 接入 AI 上下文（批1"覆盖即时性"要成立，这条躲不掉）
10. G15 distill 调度入口（懒触发 + 空闲补齐）
11. G9 晋升引用验证（设计先行）
12. G16 预算口径定案（改 DESIGN 一行）

---

## 四、附：测试现状缺口摘要

| 缺口面 | 现无测试 | 修后应有 |
|---|---|---|
| 存取 | tombstone 重 add、index/journal 不一致、双脑读一致性、并发 replace | 对应单测 + 变异（G1/G2 必须变异亲杀） |
| 演化 | span 碰撞、expire 幂等、滚动后状态复活 | 单测即可 |
| 并发/崩溃 | 无任何多线程、无 roll 中断恢复 | 多线程单测 + 真机 kill 证据链（G11） |
| 覆盖 | cover 主链路行为（接线后） | 算法单测 + 真机注入证据链（G14/G15） |

> 真机项（G11/G13/G14/G15 的接线侧）需按 ACCEPTANCE_PLAYBOOK 产证据链；其余全部纯单测可验，不依赖设备。

**报告完。幕二施工清单以此文件为准，等待验收员审批。**
