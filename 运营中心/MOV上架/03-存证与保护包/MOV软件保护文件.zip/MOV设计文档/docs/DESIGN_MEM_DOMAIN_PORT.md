# DESIGN：域记忆移植（MCP 工具数据 → MOV 记忆层 · 数据主权归 MOV）v1

> **来源**：用户直接拍板方向（第一性原理见 §〇，不许写歪）。派单 2026-08-06（p2 起草）。
> **关系**：DESIGN_MEMORY_LAYERS（记忆三层）的**输入侧**姊妹篇——三层管「留下什么/怎么演化」，本文管「**外部工具产生的数据怎么进记忆层、且不随工具弃用消失**」。
> **底座**：journal（append-only 唯一事件源，Journal.java:84 append）、ToolRegistry/manifest（工具注册表）、McpProvider（MCP 工具来源，ToolRegistry.java:1058 注册）、causal 引擎（读取期提炼复用）。

---

## 〇、第一性原理（用户原话，设计不许写歪）

1. **记忆层要接很多 MCP 工具，每个工具有记忆接入口**；例：健身可能挂十几个 MCP 工具，但最终是为了「健身」这个目的——**数据不能随 MCP 弃用消失**。
2. **这些工具产生的数据没有标准，也不该强求标准**。**不定内容的标准，只定信封的标准。**

> 推论（承接上述）：MOV 是数据主权的持有者，工具只是「搬数据的通道」。通道会换、会死；**数据长在 MOV 的账本里，不寄生于任何工具**。

---

## 一、总体架构（三层：原始 / 语义 / 目的）

```
目的层（域）        健身 · 笔记 · 学习 · 工作 · other
                    │ 域 = 唯一稳定锚点（工具会死，域不塌）
                    ▼
语义层（读时解释）  L3 distill 提炼  │  causal 四元组抽取  │  memoryCover 预算覆盖
                    ▲ schema-on-read：写入时零解释，读取时才结构化
                    │
原始层（零标准）    journal `_tool_receipt` 事件 —— 信封四字段，原文全收
                    │
                    ▼
工具层（可替换）    MCP 工具 mcp.*  /  原生工具（toolset 分类）
```

| 层 | 时机 | 干什么 | 成本 |
|---|---|---|---|
| 原始层 | 工具调用回执时（单点截取） | 信封四字段原样进 journal，**零解释零标准** | 每次调用 1 条 append |
| 语义层 | 读取时（schema-on-read） | 对 `_tool_receipt` 做域过滤 → 预算覆盖 → distill/causal 提炼 | 读时才有，懒 |
| 目的层 | 注册时（manifest 声明 + 默认域） | 工具→域映射，账本按域聚合成目的的历史 | 注册时 1 字段 |

---

## 二、原始层：零标准全收（信封四字段）

### 2.1 截取点（MOV 侧单点，不要求工具配合）

MCP 工具的调用统一走 `McpProvider.discover()` 注册的 handler（McpProvider.java:61-73）：

```java
Tool tool = new Tool("mcp." + name, desc, null, args -> {
    JSONObject result = client.callTool(url, token, name, args);   // :62 统一出口
    boolean ok = result != null && !result.has("error");
    return new Result(ok, ...);
}, ...);
```

**落地建议**：在 `McpProvider.java:62` 拿到 `result` 之后、构造 `Result` 之前，插入一行统一截取：
```java
// MOV 侧单点：不要求 MCP 工具配合，工具不知道 MOV 在记录
ingestReceipt(room, name, domain, result);   // domain 来源见 §四
```
MCP 工具侧零改动——它照常返回自己的格式，信封截取是 MOV 自己加壳。这也符合「不定内容的标准，只定信封的标准」：**工具不参与任何约定**。

### 2.2 信封四字段（journal 事件 `_tool_receipt`）

```json
{
  "type": "_tool_receipt",
  "ts": 1754470000000,
  "payload": {
    "tool": "mcp.fitbit.sync",          // 哪个工具（完整注册名）
    "domain": "fitness",                // 哪个域（见 §四）
    "ts": 1754470000000,                // 什么时间（工具调用时刻）
    "payload": "<工具原文，零解释>"      // 原样进 journal，不裁剪不转化
  }
}
```
经 `Journal.append`（Journal.java:84）写入，append-only，原文永不编辑。事件类型命名 `_tool_receipt` 沿用 `_causal_event`（Journal.java:610）的 `_` 前缀先例。

### 2.3 为什么信封优于「canonical 语义表 + 适配器注册」

| 维度 | canonical 语义表 + 适配器 | 零标准信封（本文） |
|---|---|---|
| **适配器写不完** | 每个工具一个适配器把「工具 schema → canonical 字段」；MCP 生态工具线性膨胀 = 永远追不完的人力债 | 零适配器，工具不参与 |
| **表会腐烂** | canonical 字段是写时预设计；工具 schema 演化 → 字段漂移 → 表与数据脱节即废 | 不预设字段，无表可烂 |
| **工具死了接口殉葬** | 适配器绑定工具 schema；工具弃用 → 适配器失效 → 历史数据读不了 | 信封只记 tool 名，解释器（§三）与工具解耦，工具死了解释器照读 |
| **写入成本** | 每次写都要走映射 + 校验，且坏字段进不了表 | 1 条 append，零解释零校验 |

**一句话**：canonical 表把「结构化」押在**写入时**（赌工具 schema 稳定），信封把「结构化」挪到**读取时**（赌解释器可替换）。工具生态是前者赌不赢的——后者天然赢。

---

## 三、语义层：schema-on-read（读取时才结构化）

### 3.1 读取管线

```
AI 想了解「健身」→ 域过滤（domain=fitness 的 _tool_receipt 序列）
  → memoryCover 预算覆盖（Journal.java:913，新记忆逐字/旧记忆塌缩）
  → 结构化提炼：
      ├─ L3 distill（Journal.java:979 distillMemory）→ 域摘要（"近 7 天步数均值…"）
      └─ causal 四元组抽取（causal.record → _causal_event，docs/causal-memory/README.md:32-36）
  → 冻结注入 AI 上下文 / 因果账本
```

结构化**不做在写入时**，做在读取时；手段全部复用现有件（distill / causal / memoryCover），**不新建结构化管线**。

### 3.2 为什么 schema-on-read 优于 canonical 语义表（承接 §2.3 的读侧论证）

1. **结构化成本后置**：只在「要用」时付提炼成本，且可增量（先用到的域先提炼），冷门工具的数据零成本沉睡在原文里。
2. **无版本迁移**：工具 schema 演化、甚至工具换代，历史 `_tool_receipt` 的 payload 不变，用**新解释器**读旧数据天然向前兼容——不存在 canonical 表的迁移灾难。
3. **解释器可换**：提炼质量取决于 distill/因果抽取策略，而策略是 MOV 自己的（不是工具的）；未来换模型/换抽取算法，只动读取端，历史原文零改动。
4. **与既有律对齐**：DESIGN_MEMORY_LAYERS「铁律③长在 journal 上，不平行造系统」——信封就是 journal 事件，提炼就是 journal 上的投影，无平行库。

### 3.3 明确不做（v1）

- 不新建「域内 canonical 字段」定义（如统一把 step 存成 `{steps:N}`）——那是把 canonical 表换皮。
- 不做写时 JSON Schema 校验（零标准就是零校验）。
- 不做自动四元组抽取（依赖 LoRA 微调，见 causal README v2 方向，docs/causal-memory/README.md:109-112）；v1 用 distill 摘要 + 显式规则兜底。

---

## 四、目的层：域标签挂接（工具→域映射）

### 4.1 映射来源：manifest 声明 + 默认域

- **声明**：`ToolRegistry.Tool.manifest`（ToolRegistry.java:142-157，现有 category/level/risk）**新增 `domain` 字段**；`McpProvider` 注册（McpProvider.java:61）构造 Tool 时填 domain。
- **默认域**：未声明时从 `toolset`（ToolRegistry.java:196，"biz"/"file"/"shell"…）推导；推导不出 → `"other"`。
- 域是**配置/声明**，独立于工具生命周期——工具注销（ToolRegistry 不再 register）不影响已落账的 domain 字段。

### 4.2 账本 = 同域事件的连续历史

同一个 `domain` 下所有 `_tool_receipt` 事件在 journal 里按 ts 排列，即「该目的」的完整时间线。**域是聚合键，不是工具是聚合键。**

### 4.3 工具弃用/替换场景下连续性成立的论证

| 时序 | 事件 | 域连续性 |
|---|---|---|
| t1 | 工具 A（`mcp.fitbit.sync`, domain=fitness）调用 → `_tool_receipt` 落账 | fitness 历史开始累积 |
| t2 | **A 的 MCP server 关闭 / 工具弃用** → ToolRegistry 不再注册 A | A 的历史 `_tool_receipt` **仍在 journal**，domain=fitness 不变 |
| t3 | 新工具 B（`mcp.oura.sync`, domain=fitness）注册 → 新 `_tool_receipt` 落同域 | fitness 历史**无缝续写**（t2→t3 无断裂） |
| t4 | AI 读取 domain=fitness | 看到 A+B 的**连续数据**，提炼「健身」目的，不感知工具换代 |

**关键**：连续性不依赖「A 和 B 有相同 schema」，只依赖「A 和 B 声明了同一个 domain」+「原文进了同一账本」。schema 差异由 §三 schema-on-read 消化，A 的 JSON 和 B 的文本都能提炼成同一目的的摘要。

---

## 五、健身域样例：落账 → 弃用 → 新工具续写 → AI 读取提炼

虚构三个格式迥异的健身工具（无共同 schema，正是「不该强求标准」的场景）：

| 工具 | 格式 | 回执示例 |
|---|---|---|
| `mcp.fitbit.sync` | JSON | `{"steps":8432,"hr":{"avg":72,"max":148}}` |
| `mcp.smartscale.weight` | 纯文本 | `76.5kg` |
| `mcp.strava.run` | XML | `<run dist="5.2" dur="28:40"/>` |

**① 落账**：三次调用各自截取为信封进 journal（domain=fitness）：
```
{type:_tool_receipt, payload:{tool:"mcp.fitbit.sync",  domain:"fitness", ts:…, payload:"{\"steps\":8432,…}"}}
{type:_tool_receipt, payload:{tool:"mcp.smartscale.weight", domain:"fitness", ts:…, payload:"76.5kg"}}
{type:_tool_receipt, payload:{tool:"mcp.strava.run",  domain:"fitness", ts:…, payload:"<run dist=\"5.2\"…/>"}}
```
三份数据格式互不认识，但信封层统一、原文无损。

**② 弃用**：fitbit 的 MCP server 关闭。ToolRegistry 不再注册 `mcp.fitbit.sync`（McpProvider.discover 对不可达 server 返回空，McpProvider.java:43-48 已有「未配置/不可达→不接入」先例）。**已落账的 8432 步仍在 journal。**

**③ 新工具续写**：用户换 `mcp.oura.sync`（domain=fitness，返回 JSON `{"steps":9100,"sleep":390}`）。新 `_tool_receipt` 落同域。fitness 历史连续。

**④ AI 读取提炼**：读 domain=fitness → 域过滤 → memoryCover 预算覆盖 → distill 提炼：
> 「近 7 天步数 8432→9100 上升，体重 76.5kg，跑步 5.2km/28 分——健身趋势向好。」

用户只看到「健身」这一个目的，**看不到工具换代的痕迹**——这就是「数据不能随 MCP 弃用消失」的落地形态。

---

## 六、与现有件咬合（改动面评估）

| 现有件 | 现状（文件:行号） | 本文改动 | 量级 |
|---|---|---|---|
| journal 事件类型 | `_causal_event` 先例（Journal.java:610），append 唯一入口（Journal.java:84） | 新增事件类型 `_tool_receipt`；`buildSummary` switch（Journal.java:563-615）加 case（未加则 default 兜底为 type，Journal.java:615） | 小 |
| memoryCover | 纯算法预算覆盖（Journal.java:913），无生产调用方（AUDIT G14） | **不改算法**；读取管线里对域内 `_tool_receipt` 投影调用 | 零（纯调用侧） |
| distill | 摘要懒生成（Journal.java:979），无调度入口（AUDIT G15） | **复用**：语义层读取时调用；入口缺失问题归 AUDIT G15，不在本文新造 | 零（依赖既有） |
| causal 引擎 | `causal.record` 显式写四元组（CausalToolProvider），事件 `_causal_event`（Journal.java:610） | **复用**：语义层把 `_tool_receipt` payload → causal.record（v1 显式/规则，v2 LoRA 自动，docs/causal-memory/README.md:109-112） | 零 |
| ToolRegistry.Tool / Manifest | toolset（ToolRegistry.java:196）、category/level（:142-143）、McpProvider 注册（McpProvider.java:61） | Tool/Manifest 加 `domain` 字段（构造器扩展，兼容旧构造 ToolRegistry.java:190-230）；McpProvider 填 domain | 小 |
| 桥（BridgeKernel） | memory.cover/curate 已有（BridgeKernel.java:790/776） | 新增读取查询（如 `mem.domain`：域过滤 + cover 投影）供 JS/AI 读取 | 小-中 |
| PII | causal 有 PiiScrubber 出网闸门（causal README §隐私审计） | 对齐：信封原样落账**不出网**安全；**读取提炼出网前**过 PiiScrubber（distill 调 LLM 时） | 中（需在读取管线补闸） |

**明确不碰**：journal 存储结构（就是 append 事件）、memoryCover/distill/causal 核心算法、AgentLoop 主循环。

---

## 七、验收标准（怎么样算这个设计落地了）

1. **信封截取单测**：三个格式迥异回执（JSON/文本/XML）→ `_tool_receipt` 四字段正确、payload 原文逐字节完整；MCP 调用失败/空回执不落账。
2. **域过滤单测**：跨多个 domain 的混合事件 → 按 domain 聚合正确；同域事件按 ts 有序。
3. **工具弃用模拟**：注销某工具（不再注册）→ 其历史 `_tool_receipt` 仍可查询、可提炼；新工具注册同域后读到的历史**连续无断裂**（断言含弃用前 + 续写后的事件）。
4. **变异亲杀**：把截取点改成恒空（不落账）→ 测试必红；还原绿。
5. **真机证据链**（L2+）：配置 MCP server → 触发工具调用 → logcat 见 `_tool_receipt` 写入（含 domain）→ 域查询返回连续历史 → AI 读取提炼输出（截图逐断言对照）。
6. **不回归**：全量 `assembleDebug test` + node 测试全绿；零新增平行库（只加事件类型，不加新存储文件）。

---

## 八、拍板结论（2026-08-06 用户拍板，全部定案）

> **状态：已拍板**。施工（工单8）以此为准。

| 项 | 拍板结论 | 施工落点 |
|---|---|---|
| **A** 信封事件类型 | `_tool_receipt` | Journal 新增 `TYPE_TOOL_RECEIPT`，buildSummary 加 case（Journal.java:563-615 区） |
| **B** 域映射来源 | Manifest `domain` 字段声明 | Tool/Manifest 加 `domain` 字段 + `Tool.effectiveDomain()`（Tool.domain → manifest.domain → toolset → `"other"`） |
| **C** 默认域策略 | 从 toolset 推导，推不出归 `"other"` | effectiveDomain() 兜底链（ToolRegistry.java:196 toolset） |
| **D** 截取范围 | 仅 MCP 工具（`mcp.*`） | 截取点在 McpProvider.discover handler（McpProvider.java:61-73） |
| **E** PII 闸 | **加**，但闸随 G15 读取管线落地 | **本单只保证信封本地落账不出网**（append-only journal，落账零出网）；读取提炼出网闸（PiiScrubber）归 G15 施工时在读取管线加，本文 §六 已注明闸点 |
| **F** 样例工具名 | 不限 | 健身样例虚构工具仅为示意 |

**施工确认的文档-代码出入（改文档，不改设计原则）**：
1. **MCP 工具 v1 同域 `biz`**：MCP 工具由 `McpProvider.discover()` 动态发现（McpProvider.java:52-73），工具列表来自远端 server，**无法逐工具在 Manifest 预声明 domain**——v1 MCP 工具 domain 走默认域（toolset=`"biz"` 推导）。设计原则不变（域字段/兜底链就位），域区分度（fitness/笔记/…）待 per-server 域配置（后续可加 server_info 协商，McpClient.java:221）。
2. **memoryCover 投影的落点**：`memoryCover` 读 `memoryDrafts`（Journal.java:913），不读 `_tool_receipt`。施工在 Journal 新增 `domainReceipts`（按域过滤，eventsOfType 复用，Journal.java:761）+ `domainCover`（预算覆盖投影，纯算法，**不动 memoryCover 核心**），桥 `mem.domain` 走此路。
