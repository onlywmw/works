# 批次1 交付说明 — 叙事统一包（工单19/18/17打回②/顺手①②）

> 派单：`docs/PACKAGE_TICKETS_17-20_2026-08-07.md`（e983ed4）
> 施工：P1 前端线｜状态：待验收｜commit：见 git log（本说明随 commit 提交）

## 一、交付内容（按派单顺序 19 → 18 → 17打回② → 顺手项）

### 工单19 入口归一（TASKS_P1_DELIVERY_CARD_SEAMLESS）
1. **历史条目点按 → 进房**：`openRoomFromHistory(roomId, text)` —— 关抽屉 → ROOMS 查房（不存在兜底补建）→ `expertOpenRoom` 进真实会话视图（可继续对话/派活/看文件）。长按删除手势不变（点按=进房，长按=删除）。`replayConversation` 退役为 `openRoomFromHistory` 代理
2. **交付卡「去查看」→ 落所属房间**：`onDelivery` 把 `roomId` 写入 `mv:lastDel`；`gotoDelivery` 读 roomId → `expertOpenRoom(roomId)` + `expertGoFiles()` 落到文件/交付区（叙事「回到任务现场」）。无 roomId（旧数据）兜底进房间列表
3. **显式入口清零**：grep `switchToExpert` 调用点仅剩 1 处（gotoDelivery 无 roomId 兜底 = 自动承接语义）；「我的」页 `→ 专家模式` 入口行整行删除

### 工单18 文案去「专家模式」（TASKS_P1_DECOUPLING_COPY）
11 处用户可见文案全部替换（#7 整行删除）：`专 家 模 式`→`任 务`、`返 回 新 脸`→`返 回 首 页`、`房间 · 每个房间一位专家`→`任务 · 每个任务都有专人负责`、`这个适合专家模式…`→`这个交给我们，正在为你安排…`、`去专家模式做…`→`这个任务需要完整执行环境…`、`→ 专家模式`→`→ 开始执行`、`留在新脸`→`留在首页`、`专家模式产出`→`任务产出`、`专家完成任务后…`→`任务完成后…`、`让专家继续`→`继续这个任务`、`在专家模式完成任务后…`→`任务完成后…`。注释/标识符（expert*/newface*）一律不动；用户可见字符串 grep 清零

### 工单17 打回②（情境注入）
**核对通过，无需重复施工**：`74445ee` 已在 main（currentWatchingContext + handoffToExpert 注入），上一轮真机实证过「[当前情境：在看《仙逆》 · 第 22 话]」，测试断言 ⑥ 固化

### 顺手① room_destroy 竞态（活 loop 删房目录复活）
双保险修法：
- **BridgeKernel room_destroy**：requestStop 后限时轮询 `loop.isActive()`（100ms×30，最多 3s）等终态，再 append stopped + deleteRoom
- **Journal 层防御**：`deletedRooms` 登记集——`deleteRoom` 登记，`append` 对已删房间拒绝（返回 -1，不再 `mkdirs` 重建目录）
- 测试：JournalTest +2（`appendAfterDelete_doesNotRebuildDir` / `appendAfterDelete_otherRoomsUnaffected`），**变异亲杀**（append 拒绝判断恒假 → BUILD FAILED → 还原绿）

### 顺手② 失败文案笼统
`AgentLoop.java:545` 兜底失败 `「出了点问题，已记录」` → `「任务失败：<具体原因>」`（e.getMessage()，缺省用异常类型名；MovError 80 字符截断防超长）
- 测试：AgentLoopFailCopyTest（静态断言：笼统文案消失 + 必须拼接具体原因 + 必须走 failMov）

## 二、验收对照（批次1）

| 项 | 验收标准 | 自验结果 |
|---|---|---|
| 工单19 #1 | 真机历史条目进房可发消息 | ⏳ 待真机（JS 断言：openRoomFromHistory→expertOpenRoom 在案） |
| 工单19 #2 | 真机交付卡去查看落房间 | ⏳ 待真机（JS 断言：gotoDelivery 读 roomId→expertOpenRoom+expertGoFiles 在案） |
| 工单19 #3 | grep switchToExpert 仅剩进房+自动承接 | ✅ 仅 1 处（gotoDelivery 兜底）；「→ 专家模式」/expert-enter 清零 |
| 工单18 #1 | grep 专家模式\|新脸\|专家 用户可见零命中 | ✅ 注释/标识符除外零命中（node 脚本实证 + 测试断言） |
| 工单18 #2 | 真机四处截图 | ⏳ 待真机 |
| 顺手① | 活 loop 删房目录不复活 | ✅ 单测（删后 append 拒绝重建）+ 变异亲杀 |
| 顺手② | 驳回后失败卡含具体原因 | ✅ 单测静态断言 |
| 全量 | assembleDebug test 绿 + JS 测试过 | ✅ 见下 |

## 三、验证记录

- JS 测试：newface-entry-unify（10 断言）+ newface-chat-continuity + 既有 9 个，**11/11 PASS**
- 变异亲杀：工单19 变异 2 连（gotoDelivery 条件恒假 / 历史条目改回回放）均红→还原绿；顺手① 变异（append 拒绝恒假）红→还原绿
- Java 单测：JournalTest 32/32（含 2 新竞态）、AgentLoopFailCopyTest 通过
- 全量 `assembleDebug test`：**2218+ tests, 0 failures**（等最终确认计数）

## 四、风险与遗留

- 历史条目进房的 ROOMS 兜底房间 phase 为「进行中」（非「已交付」）——进入后 journal 回放是真理源，房间元数据仅作壳
- `replayConversation` 保留为导出（房间内回放能力），不再绑定历史条目；replay-wrap CSS 保留
- 顺手② 只修了 AgentLoop 兜底一处；验收备注「驳回后『出了点问题，已记录』」即此路径

---

## 七、工单19 打回③修复（验收 64f8317）

**根因**：expertOpenRoom 只切 pane 内部子视图，不含面板显示序列（view-face act / cover 隐藏 / pane flex）——
历史条目进房与交付卡落房间两新入口绕过 switchToExpert 直调它，curRoomId 已置但界面停在首页封面。

**修法**（照验收附精确修法）：
- 抽 `showExpertPane()` 公共显示序列（closeDrawer + buildExpertPane + view-face act + cover 隐藏 + pane flex）
- `switchToExpert` 与 `expertOpenRoom` 都改调 showExpertPane——所有进房入口（历史条目/交付卡/房卡点按）先显示面板再进房
- 测试断言 ⓪ 五连（showExpertPane 在案/expertOpenRoom 先显示/switchToExpert 复用/面板三要素/关抽屉）+ 变异亲杀（去掉 showExpertPane 调用 → 红）

**真机复验**（验收要求：两入口各点一次，截图见房间顶栏+会话流+房间输入框，房内真发消息）：
- 历史条目（beta 房）→ 房间视图完整（顶栏「create a fil…」+ alpha/beta/gamma 会话流 + expertRoomInput + ‹ 返回）
- 房内发消息「room check ok 73921」→ 出现在房间会话流 + agent 承接（「记录房间检查结果」）
- 截图 06/09/10/11 入 device-acceptance/batch1/

**验证**：JS 11/11；全量 2224 tests 0 failures；变异亲杀拦截
