# MOV Protocol Layer — 设计方案

> 状态: ✅ finalized
> 日期: 2026-07-29 (v2.5 定稿)
> 目标: JS ↔ Java/Kotlin 通信层建立类型安全契约，消灭静默失败
> 未来: 扩展为 Plugin Contract / Agent Contract / Storage Contract 的统一协议层

---

## 一、现状

```
JS (ES5)                          Java
──────────────────────────────────────────
B.postCmd({cmd:'append_event',     @JavascriptInterface
  roomId:x,                        public String postCmd(String json)
  type:'note'})                       ↓
    ↓                             JSON.parse(json)
  裸字符串                           字段名拼错？→ 静默吞掉
  无校验                            字段类型错？→ ClassCastException
  无类型                            缺必填字段？→ NullPointerException
```

**问题**：70 个方法、0 个契约。改一个字段名需要人肉检查所有调用点。

## 二、目标架构

```
TS (strict)                    契约层                    Kotlin/Java
────────────────────────────────────────────────────────
import { postCmd }              Contract                  class BridgeCmd {
  from '@/contract'           ┌──────────┐                  @Serializable
                              │  Schema  │                  data class AppendEvent(
postCmd({              →      │  (JSON)  │     →              val roomId: String,
  cmd: 'append_event',        └──────────┘                    val type: String,
  roomId: x,                  编译时检查                        val payload: JsonObject
  type: 'note'                运行时校验                       )
})                            错误分类
```

**三层防护**：

| 层 | 位置 | 做什么 |
|----|------|--------|
| 1. 编译时 | TypeScript `tsc` + Kotlin 编译器 | 字段名拼错 → 编译失败 |
| 2. 运行时 | JSON Schema 校验 | 畸形输入 → 明确拒绝 + 错误码 |
| 3. 生成层 | 代码生成器 | 改契约 → 自动同步两端代码 |

## 三、契约定义

### 3.1 真理源：TypeScript Interface（非 JSON Schema）

**为什么不用 JSON Schema**：TS 项目写 JSON 无 IDE 补全、重构不支持、与手写 TS 代码不同步。**TS Interface 就是 Schema。**

```typescript
// contracts/v1/commands.ts — 单一真理源，从这里生成 Kotlin

// ── 命令字面量（编译时防拼错） ──
export type CommandName = 'append_event' | 'room_destroy' | 'agent_start' | 'query';

// ── 通用信封（底层传输，不出现在业务代码里） ──
export interface ProtocolEnvelope {
  _v?: string;              // 契约版本号
  cmd: CommandName;         // 字面量类型，拼错编译报错
  roomId: string;
  type?: string;
  actor?: string;
  payload?: Record<string, unknown>;
  silent?: boolean;
}

// ── 具体命令（业务代码只调这些） ──
export interface AppendEventParams {
  roomId: string;
  type: string;
  actor?: string;
  payload?: { noteId?: string; text?: string };
  silent?: boolean;
}

export interface AgentStartParams {
  goal: string;
  roomId: string;
  modelIds: string[];
}

// ── 返回信封 ──
export interface ProtocolResult {
  ok: boolean;
  data?: Record<string, unknown>;
  error?: { code: string; msg: string };
}

// ── Push 事件（Java→JS，每个事件自带 schema 版本） ──
export interface MovEventEnvelope {
  schema: string;           // 事件名，如 "agent.step"
  version: number;          // 事件版本，如 2
  roomId: string;
  channel: 'journal' | 'transient';
  event: Record<string, unknown>;
}

// ── 事件版本兼容规则 ──
// 1. 新增字段 → 必须 optional
// 2. 删除字段 → 先标记 @deprecated，保留解析 2 个大版本
// 3. 修改字段类型 → 新增 v2 字段，老字段保留 deprecated
// 4. 每个事件自带 version，不依赖全局 version
```

### 3.2 命令封装（禁止裸传 cmd 字符串）

```typescript
// contracts/v1/commands.ts （续）

// 包装函数：cmd 由函数名决定，调用方不可写字符串
export function appendEvent(p: AppendEventParams): ProtocolResult {
  return postCmd({ _v: '1.0', cmd: 'append_event', ...p });
}

export function roomDestroy(roomId: string): ProtocolResult {
  return postCmd({ _v: '1.0', cmd: 'room_destroy', roomId });
}

// ── 返回值适配层：老 Java 返回非标准格式，JS 侧先洗一遍 ──

function adaptLegacyResponse(raw: string): ProtocolResult {
  if (raw === 'OK' || raw === 'Success' || raw === '') {
    return { ok: true };
  }
  if (raw.startsWith('Error:') || raw.startsWith('ERR:')) {
    return { ok: false, error: { code: 'GENERIC', msg: raw } };
  }
  try {
    const parsed = JSON.parse(raw);
    if (typeof parsed.ok === 'boolean') return parsed as ProtocolResult;
    return { ok: true, data: parsed }; // 老接口返回裸对象 → 视为成功
  } catch {
    return { ok: false, error: { code: 'PARSE_ERROR', msg: raw.slice(0, 100) } };
  }
}

// ── 异步 Promise + 回调 Router ──

type CallbackFn = (data: ProtocolResult) => void;
const callbackRouter: Map<string, CallbackFn> = new Map();

// Phase 1: 挂在旧 _hermesCb 上（Java 未改，不能期望 _hermesCbV2）
// 通过 cbId 前缀 "v2_" 区分新旧流量，实现逻辑隔离
window._hermesCb = (function(original) {
  return function(cbId: string, raw: string) {
    // 新协议回调：cbId 以 "v2_" 开头 → Router 处理
    if (typeof cbId === 'string' && cbId.startsWith('v2_')) {
      const fn = callbackRouter.get(cbId);
      if (fn) {
        callbackRouter.delete(cbId);
        try { fn(adaptLegacyResponse(raw)); } catch (e) {
          console.error('[Protocol] callback error', e);
        }
      } else {
        console.warn('[Protocol] Unknown v2 cbId:', cbId);
      }
      return;
    }
    // 旧协议回调：原样转发给原始处理器
    if (original) original(cbId, raw);
  };
})(window._hermesCb);

export function agentStart(p: AgentStartParams): Promise<ProtocolResult> {
  return new Promise((resolve, reject) => {
    const cbId = 'v2_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
    const timer = setTimeout(() => {
      callbackRouter.delete(cbId);
      console.warn('[Protocol] agentStart 超时, cbId:', cbId);
      reject(new BridgeError('TIMEOUT', 'agentStart 超时'));
    }, 30_000);
    callbackRouter.set(cbId, (data) => {
      clearTimeout(timer);
      if (data.ok) resolve(data);
      else reject(new BridgeError('AGENT_ERROR', data.error?.msg || '未知错误'));
    });
    window.HermesBridge!.agentStart(p.goal, p.roomId, JSON.stringify(p.modelIds), cbId);
  });
}

// ── Payload 强绑定：根据 cmd 推导 payload 类型 ──
// Phase 2 用条件类型实现，Phase 1 保持 Record<string,unknown> + 运行时校验

// ── Push 事件解析器 ──

export function parseMovEventV2(raw: string): MovEventEnvelope {
  const parsed = JSON.parse(raw);
  if (!parsed.schema || !parsed.version || !parsed.roomId) {
    throw new BridgeError('VALIDATION', '_movEventV2 缺必填字段');
  }
  return parsed as MovEventEnvelope;
}
```

### 3.3 同步调用适配层（`postCmd` 内部合并兜底逻辑）

```typescript
// contracts/v1/commands.ts （续）

// 底层 postCmd：所有调用路径共享同一个适配器
export function postCmd(params: ProtocolEnvelope): ProtocolResult {
  const raw = window.HermesBridge!.postCmd(JSON.stringify(params));
  // 统一适配层：处理老 Java 的非标返回
  if (raw === 'OK' || raw === 'Success' || raw === '') return { ok: true };
  if (raw.startsWith('Error:') || raw.startsWith('ERR:'))
    return { ok: false, error: { code: 'GENERIC', msg: raw } };
  try {
    const parsed = JSON.parse(raw);
    if (typeof parsed.ok === 'boolean') return parsed as ProtocolResult;
    return { ok: true, data: parsed };
  } catch {
    return { ok: false, error: { code: 'PARSE_ERROR', msg: raw.slice(0, 100) } };
  }
}
```

### 3.4 从契约生成的 Kotlin 代码

**原则**：不生成万能 `postCmd(params)` 入口。每个命令有独立的 data class，字段写在类型里，不塞进 `JsonObject`。

**⚠️ 铁律**：Phase 2 生成器必须从 TS `CommandName` 联合类型生成 Kotlin `sealed class Command` 及每个命令的 `object` 子类。**Kotlin 侧绝对不出现硬编码字符串 `"append_event"`**，否则 TS 侧删命令编译报错但 Kotlin 侧无声保留——契约在 Java 侧失效。

```kotlin
// Phase 2 生成器输出的 Kotlin 路由（禁止手写 when 字符串匹配）
sealed class Command {
    object AppendEvent : Command()
    object RoomDestroy : Command()
}

fun dispatch(cmd: Command, params: String) = when (cmd) {
    Command.AppendEvent -> handleAppendEvent(decode<AppendEventParams>(params))
    Command.RoomDestroy -> handleRoomDestroy(decode<RoomDestroyParams>(params))
    // 新增命令 → 编译器强制补分支，否则编译失败
}
```

```kotlin
// Phase 1 手写过渡版本，Phase 2 生成器自动替换为上方 sealed class 实现
// contracts/generated/AppendEvent.kt

@Serializable
data class AppendEventParams(
    val cmd: String = "append_event",  // Phase 2 生成器替换为 sealed class，此处仅过渡
    val roomId: String,
    val type: String,
    val actor: String? = null,
    val payload: AppendEventPayload? = null,
    val silent: Boolean? = null
)

@Serializable
data class AppendEventPayload(
    val noteId: String,
    val text: String? = null
)

// 生成的调用函数
fun appendEvent(params: AppendEventParams): PostCmdResult {
    return postCmdV2(Json.encodeToString(params))
}

// ── 通用返回信封 ──

@Serializable
data class PostCmdResult(
    val ok: Boolean,
    val data: JsonObject? = null,
    val error: BridgeError? = null
)

@Serializable
data class BridgeError(
    val code: String,
    val msg: String
)
```

## 四、错误分类

```typescript
// contracts/errors.ts

enum BridgeErrorCode {
  // 调用方的问题（不上报遥测）
  VALIDATION     = 'VALIDATION',      // 参数校验失败
  NOT_FOUND      = 'NOT_FOUND',       // 房间/文件不存在
  UNAUTHORIZED   = 'UNAUTHORIZED',    // 权限不足
  RATE_LIMITED   = 'RATE_LIMITED',    // 频率限制

  // 系统问题（上报遥测）
  INTERNAL       = 'INTERNAL',        // 内部异常
  TIMEOUT        = 'TIMEOUT',         // 超时
  BRIDGE_DOWN    = 'BRIDGE_DOWN',     // 桥不可用
}

class BridgeError extends Error {
  constructor(
    public code: BridgeErrorCode,
    public msg: string,
    public details?: Record<string, unknown>
  ) {
    super(`[${code}] ${msg}`);
  }
}
```

## 五、实施路线

```
Phase 1 (本次, 1天)               Phase 2 (后续, 2天)         Phase 3 (远期, 3天)
─────────────────────────────────────────────────────────────────────────────
1. 新建 contracts/ 目录           1. 生成器扫描 JSON Schema     1. Kotlin 侧接入
2. 手写 5 个核心契约              2. 自动生成 TS 类型文件       2. 存量方法迁移
3. bridge.ts 包一层校验            3. 自动生成 Kotlin 数据类     3. CI 强制校验
4. 5 个方法接入                   4. 所有 70 个方法接入         4. 旧代码完全下线
```

### Phase 1 工作量

| 文件 | 内容 | 时间 |
|------|------|------|
| `contracts/events.json` | 5 个核心契约定义 | 1h |
| `app/src/main/ts/contracts/postCmd.ts` | 类型 + 校验函数 | 30min |
| `app/src/main/ts/contracts/agent.ts` | Agent 相关契约 | 30min |
| `app/src/main/ts/contracts/errors.ts` | 错误分类 | 30min |
| `core/bridge.ts` | 接入 5 个带校验的调用 | 2h |
| 测试 | 编译验证 + 手动点击 | 1h |

## 六、契约清单（Phase 1 优先）

| # | 方法 | 方向 | 产出 |
|---|------|------|------|
| 1 | `postCmd` | JS→Java | 通用命令 + 3 个包装函数 (appendEvent/roomDestroy/agentCommand) |
| 2 | `agentStart` | JS→Java | 异步 Promise 封装，不暴露回调 |
| 3 | `_movEvent` | Java→JS | Push schema + parseMovEvent() 解析器 |
| 4 | `_hermesCb` | Java→JS | Promise.resolve/reject 封装 |
| 5 | `query` | JS→Java | 只读查询，返回强类型 |

## 七、不做的事

- 不迁移所有 70 个方法（Phase 1 只做 5 个核心）
- 不改 Java 侧（Phase 1 只做 JS 侧类型校验）
- 不引入 Zod（自己实现轻量校验，够用）
- 不强制旧代码接入（新代码用契约，旧代码照跑）
- 不引入代码生成器（Phase 1 手写，Phase 2 再加工具链）
- **不裸传 `cmd` 字符串**（业务代码调 `appendEvent()` 而非 `postCmd({cmd:'append_event'})`）

## 八、契约测试（Contract Test）

确保 Java 实现符合 TS 契约，不只靠编译检查：

```typescript
// contracts/v1/__tests__/commands.test.ts

import { appendEvent, roomDestroy, agentStart } from '../commands';

// 用合法数据跑一遍 Java 实现，验证返回格式
test('appendEvent 返回格式正确', () => {
  const res = appendEvent({ roomId: 'test', type: 'note', payload: { text: 'hi' } });
  expect(res.ok).toBe(true);
  expect(typeof res.ok).toBe('boolean');
});

test('agentStart 异步回调', async () => {
  const res = await agentStart({ goal: 'test', roomId: 'test', modelIds: ['m1'] });
  expect(res.ok).toBe(true);
});

test('appendEvent 缺 roomId 时 TS 编译报错', () => {
  // @ts-expect-error — roomId 是必填, 缺了编译不过
  appendEvent({ type: 'note' });
});
```

## 十、TS→Kotlin 代码生成

Phase 1 手写 Kotlin data class（仅 5 个命令），Phase 2 引入 AST 生成器。

**为什么 Phase 1 不写正则生成器**：正则无法可靠解析 TS 的 union type、泛型、嵌套对象、注释。生成的 Kotlin 代码必然会出错。Phase 2 用 `ts-morph`（TypeScript Compiler API 封装）做 AST 解析，100% 准确。

```typescript
// TODO: Phase 2 — 用 ts-morph AST 实现，不手写正则
// import { Project } from "ts-morph";
// const project = new Project();
// project.addSourceFileAtPath("contracts/v1/commands.ts");
// project.getSourceFile("commands.ts")!.getInterfaces().forEach(iface => {
//   // AST 结构化的属性提取，处理 union/generic/nested/optional/enum
// });
```

## 九、新老代码隔离准则

新契约和旧代码在**执行路径**上天然隔离（方法名不同），但在**数据存储**和**回调通道**上必须物理隔离。

### 隔离规则（仅通信层，不动存储）

**原则**：Protocol 层解决的是 JS↔Java 通信问题，不碰底层存储。隔离范围仅限于方法名和回调函数名。

| 资源 | 旧代码 | 新代码 | 隔离方式 |
|------|--------|--------|---------|
| JS→Java 方法 | `postCmd` | `postCmd` (同名，Phase 1 不新建方法) | JS 层包装函数做校验 |
| Java→JS 回调 | `_hermesCb` | `_hermesCb` (劫持，v2_前缀路由) | 逻辑隔离 |
| Java→JS 推送 | `_movEvent` | `_movEventV2` | 不同函数名 |
| SQLite/Prefs/API | 不变 | 不变 | **Phase 2 新建 _v2 表，Phase 1 暂不动**

### 安全交集（不担心）

- JS 全局对象不同名 → 各调各的
- Java 方法重载不同名 → JNI 映射不混淆
- 老 JS 不加载新模块、新 TS 不引用老模块 → 执行路径完全独立

### 致命交集（必须隔离）

| 场景 | 后果 | 措施 |
|------|------|------|
| 新旧代码共用 `_hermesCb` 回调 | 数据格式不兼容，静默失败 | 必须用 `_hermesCbV2` |
| 新旧代码写同一张 SQLite 表 | 字段映射冲突，数据错乱 | 必须用 `events_v2`（Phase 2 实施，Phase 1 不动存储） |
| 新旧代码共享 static 单例 | 状态互相覆盖 | 各自 `@Singleton` 独立实例 |
| 新旧代码控同一硬件/连接 | 资源抢夺 | 新代码独立 WebSocket + 版本路径 |
