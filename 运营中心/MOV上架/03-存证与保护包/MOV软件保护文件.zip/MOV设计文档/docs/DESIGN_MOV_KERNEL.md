# DESIGN: MOV Kernel — 统一内核架构（异构 → 插件）

版本: v2.0（P0~P7 全部实施完毕，与代码仓库 main 分支一致）
日期: 2026-07-26
status: implemented
交付对象: 全体程序员
前置: 全部已落地；DESIGN_AGENT_LOOP、DESIGN_DELIVERY_GATE、CONTRACT_STREAMING
依据: 大神三轮架构评审 + 终审（2026-07-25）+ 实施 2 天（2026-07-25~26）
      实测：256 单测全绿，真机验收 P0-P4 全部通过，内存 idle 213MB，无泄漏

---

## 核心诊断（大神原话 + 代码实证）

MOV 现状是五个异构系统挤在一个 APK：Android Native（壳）+ WebView（面）+
Java AgentLoop（脊髓）+ 内嵌 Linux Proot（内胆）+ Python Hermes（外挂大脑）。

问题不是组件多，是**接口不统一、数据流向混乱**，三处割裂均有代码实锤：

| 割裂 | 实证 |
|---|---|
| 工具割裂 | `device.cmd`（调 Java）与 `shell.exec`（调 Linux）两套动作协议，大脑认知负担重 |
| 状态割裂 | AgentLoop 在 Java、localStorage 在 WebView、Room 文件在 Linux 目录；KI-002 切房丢交付、KI-004 双数组错位 |
| 大脑割裂 | 云端 Flash 与 Hermes 之间无标准协议，ActionInterceptor 是给不标准协议强装的门禁 |
| 通道脆弱 | KI-003：Bridge 吞错返回 `{ok:true}`；70 个 @JavascriptInterface 字符串拼接喷事件 |

**本方案的总纲（大神）：将 AgentLoop 升级为唯一的状态真理来源；UI 只是 Loop 状态的投影。**

## 设计总则（五条，全部可验收）

1. **一个内核**：Java 层 = MOV Kernel。所有状态机、所有路由、所有鉴权只在 Java。
2. **文件系统即世界**：房间目录（已 bind 为 guest `/room`，M-ARCH）是唯一持久化真相；
   localStorage 降级为纯缓存，可随时重建。
3. **事件溯源（轻量版）**：每房间一份 append-only `journal.jsonl`；AgentLoop 回放恢复现场，
   WebView 读取尾部渲染。**不搞二进制 log.bin，不做分布式框架**——JSONL，与 wire.jsonl 同构。
4. **工具皆插件**：LLM 只输出 `{"action":"tool.execute","name":"...","args":{...}}`；
   ToolRouter 路由到 Native/Linux/Hermes 执行器。统一鉴权、统一审计。
5. **桥只做邮差**：JS↔Java 之间只有两种东西——命令信号（JS→Java）和事件（Java→JS）。
   JS 不得直接修改 Java 内部状态，只发信号，Java 自己决定怎么做。

## 目标架构

```
┌────────────────────────── WebView（显示器，零状态真理） ──┐
│  渲染器: journal 尾部 → DOM 投影    遥控器: 用户操作 → 命令信号 │
└────────────▲───────────────────────────────┬─────────────┘
             │ 事件 envelope                  │ 命令信号 cmd
┌────────────┴───────────────────────────────▼─────────────┐
│                  MOV Kernel (Java, 唯一真理)               │
│  AgentLoop(编排/状态机) ── 读/写 ──▶ journal.jsonl (房间)   │
│       │                                                  │
│  ToolRouter ─┬─ NativeExecutor (30 能力/文件/打包)         │
│              ├─ LinuxExecutor  (proot shell)              │
│              └─ HermesExecutor (hermes -z 委派)            │
│  WorkerRouter ─┬─ FastWorker (云端 flash)                  │
│                └─ HeavyWorker (Hermes/大模型)              │
└──────────────────────────────────────────────────────────┘
```

## 支柱一：Journal（事件溯源轻量版）— 修 KI-002 / KI-004

**格式**：`rooms/<id>/journal.jsonl`，一行一个 envelope：

```json
{"seq":42,"ts":1784923898,"taskId":"loop1784...","actor":"user|brain|kernel|worker","type":"user_input|plan|tool_call|tool_result|deliver|sys","payload":{...}}
```

**写点**（全部在 Java）：用户输入（经桥信号）、大脑动作、工具结果、闸事件、终态。

**回放（性能优先，大神终审 #1——P0 就必须做，禁全量回放）**：
- **轻量索引同步落地**：`index.json` 只存 `seq → {type, ts, summary(≤80字)}`，
  随 journal 每次写入增量更新；
- **默认只回放最近 N=500 条**（常量可调），更早历史经索引摘要按需加载详情；
- AgentLoop 恢复 = snapshot + 尾部回放；进房间渲染 = 索引摘要先上屏，滚动翻页再拉详情。

**投影**：WebView 进房间 → 桥拉 journal 尾部（增量 seq）→ 渲染。**UI 不渲染也必须落
journal**——切房丢交付（KI-002）在写点层面被消灭：deliver 先落 journal，用户随时回看。
**双数组废除**：msgData/msgs 索引错位（KI-004）随单一数据源自然消亡；typing/stream 等
瞬态 UI 不进 journal（它们本来就不是"事实"）。

**体积治理双机制**：
- **滚动 snapshot**：journal 超 1MB → Java 侧 `snapshot.json` + journal 只留尾部；
- **压缩点（大神终审建议）**：任务到 DONE/FAILED/STOPPED 终态时触发**里程碑压缩**——
  该任务的过程事件（tool_call/tool_result 流水）聚合为一条 `summary` 事件写入，
  原始事件归档到 `journal.archive.jsonl`。历史可追溯，日常回放数据量大减。

## 支柱二：桥协议（邮差化）— 修 KI-003 / 根治 KI-000

**两个统一入口**（新增）：

```java
@JavascriptInterface String postCmd(String json)   // JS→Java 命令信号: {"cmd":"stop_task","taskId":"..."}
@JavascriptInterface String query(String json)     // JS→Java 查询: {"q":"journal_tail","roomId":"..","afterSeq":41}
// Java→JS: 单一通道 window._movEvent(envelopeJson)
```

- **信号化**：`B.agentStop()` 这类直接操纵 Java 状态的调用废除，改为
  `postCmd({"cmd":"stop_task","taskId":...})`——Java 决定停不停、怎么停。
  UI 删除房间 = 发 `cmd_room_destroy`，Kernel 收到后停 loop 再走终态（吸收 DeliveryGate 的
  onRoomDestroy 钩子，KI-001 的死锁在协议层封死）。
- **错误信封**：所有桥返回统一 `{ok, data?, error?:{code,msg}}`；
  **catch 禁止返回 ok:true/空值**（KI-003 的两例毒瘤列为迁移首批清除对象）。
- **流式查询/subscribe（大神终审建议）**：大房间历史分页不靠前端正轮询——
  JS 发 `postCmd({"cmd":"subscribe_history","roomId":"..","beforeSeq":500,"count":50})`，
  Java 经 `_movEvent` 分批推送历史事件流，前端边收边渲染。
- **老桥冻结策略（大神终审 #4：替换，不迁移）**：从 P0 起**冻结** 70 个老接口——
  禁止为任何老接口加新功能，所有新需求强制走 postCmd/query/_movEvent；
  老接口随功能替换自然衰退，bridge.js 逐个标 `/* @deprecated → postCmd */`。

## 支柱三：Tool 统一路由 — 消灭工具割裂

**动作协议归一**（大脑只需要会一种）：

```json
{"action":"tool.execute","name":"file.write","args":{"path":"a.html","content":"..."}}
{"action":"tool.execute","name":"flashlight","args":{"on":true}}
{"action":"tool.execute","name":"shell.exec","args":{"cmd":"...","timeoutSec":300}}
```

- ToolRegistry（已存在，"工具唯一入口"）升级为 **ToolRouter**：name → 执行器
  （Native/Linux/Hermes），注册表生成 prompt 工具说明的机制不变。
- **白名单/路径校验收口到 Router 一处**：device.cmd 的 capability 白名单、file.* 的
  BridgeValidator、shell.exec 的 allowedShell 闸——全部变为 Router 的鉴权中间件，
  每个 tool 声明自己的 policy（只读/需批准/需计划内路径）。
- **幂等性契约（大神终审建议，断点续跑的前瞻设计）**：每个 tool 注册时必须声明
  `idempotent: true|false`（file.write 同路径覆盖 = 幂等；shell.exec 多数 = 非幂等）。
  Router 把幂等性写进 journal 的 tool_call 事件；未来断点续跑回放时，
  幂等操作可安全重放，非幂等操作跳过或警告。
- 老动作名（file.write/device.cmd）保留别名一个版本期，prompt 同步切换。

## 支柱四：Worker 插件化 — 消灭大脑割裂

```java
interface Worker {
    String id();                          // "fast:deepseek-flash" / "heavy:hermes"
    WorkerResult run(WorkerTask task);    // 统一入参/出参
    boolean available();                  // Hermes 未装 → false，编排期就可见
}
```

- **路由显性化（大神三轮 #3）**：PLANNING 阶段计划每步标注 worker：
  `{"step":4,"action":"tool.execute","name":"file.write","worker":"heavy:hermes",...}`。
  委派从"拦截器猜"变成"计划决定"。
- **worker 标注 UX（大神终审 #3：默认隐藏，按需展开）**：计划卡只显示**总预估时间**；
  用户点开某步骤才显示「由 Hermes 执行 · 预估 3 分钟」。透明但不焦虑，界面清爽优先。
- **ActionInterceptor 演化**（DESIGN_DELIVERY_GATE v1.1 的守门员不白费）：
  从"执行期拦截改道"退化为**计划合规校验器**——计划没标 worker 但产物超阈值 →
  打回重出计划（PLAN_GATE 驳回带原因）；执行期只做一致性检查（实际 worker == 计划标注）。
  文件类型分流表/禁网/sanitize/回写校验全部保留，移到 HermesExecutor 内部。
- **报告通道**：Worker 进度/流式 token 统一走 journal 事件（`actor:"worker"`），
  CONTRACT_STREAMING 的打字机/TPS 渲染逻辑不变，数据源换成 journal 尾部。

## 分期路线（全部实施完毕 ✅）

| 期 | 内容 | 修哪个 KI | 状态 | 关键 commit |
|---|---|---|---|---|
| **P0** | journal.jsonl + index.json + _movEvent + 错误信封 + Envelope 契约 | KI-003 | ✅ | `cc95283` |
| **P1** | cmd 信号化 + room_destroy + parkForResume 超时 + 老桥冻结 | KI-001 | ✅ | `52b4dda` |
| **P1.5** | MovRender 模拟事件流渲染器 (15 种事件类型) | — | ✅ | `2783d2f` |
| **P2** | desk 房 journal 回放 + tombstone + data-seq + msgData 废除 | KI-002/004 | ✅ | `c831953` |
| **P3** | tool.execute 统一协议 + ToolRouter 鉴权 + 契约全字段 | 工具割裂 | ✅ | `a88bbeb` |
| **P4** | Worker 接口 (Fast/Heavy) + 编排期可用性检查 | 大脑割裂 | ✅ | `e1b188f` |
| **P5** | 全房间 journal 化 + _agentLog 纯状态 + msgData 删除 + Journal 性能优化 | — | ✅ | `3ef5f8a` |
| **P6** | 遥测埋点 (_telemetry) + 删别名 + SseParser null 修复 | — | ✅ | `8467488` |
| **P7** | 模型列表精简 + 厂商下拉 + 模型名点选 + 滚动修复 | — | ✅ | `b04d2e0` |

**实测状态**：256 单测全绿 / 真机 P0-P4 verify 通过 / 内存 idle 213MB / 10 次冷启 Delta 0MB 无泄漏

## 契约先行清单（已冻结 ✅ 2026-07-25，P0 动工的唯一依据）

1. **Envelope 契约** → `docs/contracts/ENVELOPE.md`：journal 15 种事件 payload schema /
   index.json / snapshot.json / 回放规则 / postCmd/query/_movEvent 桥消息 / 错误码。
2. **Tool 契约** → `docs/contracts/TOOL.md`：注册条目全字段格式 / v1.0 三执行器工具清单 /
   六步路由鉴权流程 / 幂等声明 / 新增工具四步流程。
3. **Worker 契约** → `docs/contracts/WORKER.md`：WorkerTask/WorkerResult 字段表 /
   available() 语义 / 进度走 transient 通道 / 编排五规则。
代码以契约为准；契约变更只增不删不改义，走文档先行。

## 验收用例（每期的"能上线"标准）

- **TC-K-01（P0）**：执行任务中强杀 App → 重开 → AgentLoop 经 snapshot+尾部回放恢复断点，
  交付卡完整可见（含计量；评审结论字段 2026-07-30 随评审机制移除）。
- **TC-K-02（P0）**：任何桥方法异常 → JS 收到 `{ok:false,error:{code,msg}}`；
  全代码库 grep 不存在 `catch` 返回 `ok:true`。
- **TC-K-03（P0，性能闸）**：构造 5000 条 journal 的大房间 → 冷启动进房间 ≤1.5s 上屏
  （索引摘要先行），内存无全量对象驻留；翻页经 subscribe_history 分批加载正常。
- **TC-K-04（P1）**：任务在 PAUSED 状态删除房间 → `cmd_room_destroy` 到达 →
  loop 走 stopped 终态 → 新任务立即可发起（KI-001 场景复测）。
- **TC-K-05（P1.5）**：模拟事件流（含 typing/stream/瞬态交错）灌入新渲染器 →
  投影顺序/去重/瞬态消亡全正确，零真数据依赖。
- **TC-K-06（P2）**：切房后任务交付 → 回到原房间，交付卡/计量完整在历史里（评审字段 2026-07-30 随评审机制移除）；
  删除任意消息 → 重启 App → 历史与删除前一致（KI-004 场景复测）。
- **TC-K-07（P3）**：大脑输出 `tool.execute flashlight` → NativeExecutor 执行；
  输出老动作名 `device.cmd` → 别名路由正常 + journal 记 deprecation 警告；
  tool 注册表全部条目带 `idempotent` 声明。
- **TC-K-08（P4）**：计划标注 `worker:"heavy:hermes"` 的步骤 → 由 Hermes 执行（禁网/sanitize/
  回写校验生效）；计划未标但超限 → PLAN_GATE 驳回带「请标注 worker」原因；
  计划卡默认只显示总预估，点开步骤才显示 worker 详情。
- **TC-K-09（压缩点）**：任务 DONE 后 journal 出现该任务的 `summary` 聚合事件，
  过程流水归档 archive；回放默认路径不再加载归档细节。

## 红线

1. **Java 是唯一状态真理来源**：任何"UI 删了但 Loop 还在跑"式的状态打架 = 架构违规。
2. **journal 只追加不修改**：改历史 = 破坏事件溯源，禁止。
3. **JS 不得直接修改 Java 状态**：一切用户意图走 postCmd 信号。
4. **桥 catch 禁止吞错**：错误信封是协议义务，不是礼貌。
5. **分期不得跳跃**：P0 未验收不开 P2（投影依赖 journal）；老桥冻结令从 P0 生效。
6. **轻量版纪律**：不引入 EventBus 框架/二进制日志/分布式概念——JSONL + seq + index，够用即止。
7. **契约先行**：Envelope/Tool/Worker 三契约文档未冻结，P0 代码一行不写。
8. **性能优先**：journal 任何写入路径必须同步维护 index.json；默认回放禁止全量。

## 明确不做（YAGNI）

- 多 loop 并行（全局单 loop 不变；journal 为未来并行留 taskId 但不实现）
- journal 的跨设备同步/云端备份
- WebView 全量替换（如改原生 UI）——投影化后 WebView 仍是合格显示器
- Hermes 委派进度细颗粒度流式（同 DeliveryGate YAGNI）
- 老 localStorage 历史数据迁移工具（P2 上线时旧数据一次性转 journal 或接受从头开始，届时裁决）
- P2 趁机重组 12 个 JS 模块（大神终审 #2：投影化本身已经够大，不节外生枝）

## 开放问题（终审后剩余 2 项）

已裁决并入本文：①journal 回放性能→索引+近 500 条+压缩点 ②老桥退役→冻结策略
③worker 标注可见性→默认隐藏按需展开 ④P2 风险→P1.5 mock 渲染器先行
⑤历史分页→subscribe 流式查询 ⑥断点续跑前瞻→幂等性契约。

1. **snapshot/压缩阈值数值**：1MB 滚动 + N=500 回放是经验初值，真机数据回来后校准。
2. **幂等契约覆盖范围**：shell.exec 非幂等但大量实际命令无害（ls/cat），
   是否细分"只读 shell"子类？P3 实施时按真实工具清单定。
