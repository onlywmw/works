# 真机验收流程（DEVICE ACCEPTANCE）— 2026-08-01（用户拍板）

> 定位：真机验收从「想起来才跑」变「固定清单+批量跑+截图存档」的流水线环节。
> 设备：小米平板 24018RPACC（`adb -s 21770d7d`，root，debug 包 WebView 可 CDP）。

## 一、清单格式（每项必含）

| 字段 | 说明 |
|---|---|
| ID | DV-序号 |
| 来源 | 产生待验项的 commit / 打回 |
| 步骤 | 可机械执行的 adb 操作序列 |
| 通过判据 | 截图可见的客观标准（不许「看起来没问题」） |
| 状态 | ⏸️ 待跑 / ✅ 过 / ❌ 打回（附打回单号） |

## 二、执行规程

1. **装包先行**：验收前必须 `install -r` 最新 `app-debug.apk` 并核对 `lastUpdateTime`（历史教训：旧 APK 白忙一轮）
2. **批量跑**：待验项 ≥3 或每周五集中跑一轮；单项紧急可插单
3. **截图存档**：`docs/device-acceptance/YYYY-MM-DD/DV-<id>-<step>.png`，截图即证据，随验收结论引用
4. **结论三态**：✅ 过 / ❌ 打回（精确修法）/ ⚠️ 环境阻塞（写明缺什么）
5. **唤醒先行**：截图前 `KEYCODE_WAKEUP`，黑屏截图不算数

## 三、当前清单（2026-08-01 立）

| ID | 来源 | 步骤 | 通过判据 | 状态 |
|---|---|---|---|---|
| DV-1 | c22fbb9 | ConnectWeb 打开京东 → AgentLoop 执行 browser_snapshot/click | 工具返回真实页面数据非报错 | ⏸️ |
| DV-2 | I' 打回（0fd6d03 + be72030 白名单兜底） | vodplay 播放页 | 页面只剩播放器（body 非 player 直接子节点全藏，含评论区/panel；白名单兜底已修），CDP 验证隐藏 JS 无报错（回调返回隐藏计数可观测，WebView 已开 DEBUG） | ⏸️ P1 已修，待跑 |
| DV-3 | I' 新 bug（0fd6d03 修） | vodplay 连播 3 轮×90s | 无自动关闭；若关闭，埋点日志抓到 finish/onDestroy/onBackPressed 调用栈 | ⏸️ P1 已修（埋点），待跑 |
| DV-4 | W3 | ConnectWeb 打开 m.jd.com 搜索「牛奶」 | 搜索结果真实渲染，无 App 跳转拦截失败 | ⏸️ |
| DV-5 | W3 | ConnectWeb 打开 m.12306.cn | 页面可达（非拒绝页）；不可达则出诚实报告 | ⏸️ |
| DV-6 | 任务 R | 含微信收款二维码页面 | QR 检测触发 → 截屏存 DCIM/mov → 拉起微信扫一扫 | ⏸️ |
| DV-7 | 音乐打回 | 断网说「我要听小苹果」 | 显示「音乐服务连不上」而非「没有找到」 | ⏸️ |
| DV-8 | LLM 意图 | 说「来点轻音乐」「随便聊聊」 | 前者歌曲卡（正则未命中走 LLM），后者 chat/诚实卡不演场景 | ⏸️ |
| DV-9 | A2A 区块 | 设置页生成配对码 | 6 位码出现，5 分钟有效提示 | ⏸️（✅ 已半验：区块渲染过，生成未点） |
| DV-10 | cf7135d + element/text 接入 | ConnectWeb 打开页面，配置 pageload + element_appear + text_match workflow | 页面加载/元素出现/文本匹配后 workflow 动作执行（日志可见 fired）；interval 心跳按节拍触发 | ✅ 2026-08-01 终验过（HEAD b388c28，证据见下行） |
| DV-11 | 89cf2cf + relay v2 | 带 professions 注册（role=pro/craft=shop）→ relay devices 表可见 → query_pro 返回真实列表 | relay DB 里 professions 正确落库；query_pro craft/online/radius 过滤返回该设备；旧买家注册不受影响 | ✅ 2026-08-01（验收人，证据见下行） |

> **DV-11 终验记录（验收人，2026-08-01 09:47-10:00，设备 21770d7d + relay 62.234.55.76）**
> relay v2 已部署（server.py：devices 表 role/professions 只增不改 + /register 扩展 + /query_pro；Caddy 分流补 /query_pro）。本地 TestClient 10 场景全过。
> - 服务端烟测：register pro → token 签发；query_pro(shop,online) 命中；**38 个旧设备全部 buyer/无 professions 完好**（迁移无损）
> - TLS 外链：https://mow.kim/query_pro 200（Caddy 已加分流）
> - 真机端侧（tools/e2e/dv11-registry-verify.js，CDP 驱动）：`B.a2aRegister(dv11_pro_tablet, pro, professions)` ok → `B.a2aQueryPro("shop",0,true)` 命中该设备（真实列表非虚构）→ tutor 过滤空 ✓ → radius_km=5 > radiusKm=2 空 ✓ **ALL PASS**
> - 现场恢复：探针设备 dv11_pro_tablet 已删；平板原身份 buyer_peerfix 经服务端 token 转移 + 端侧重注册恢复，6 条配对完好（peers 列表实证含双商家两店）
> - 注意：curl 直 POST 中文 body 在 Git Bash 会出「error parsing the body」（本地编码问题，非服务端 bug；端侧 OkHttp 不受影响）

> **DV-10 终验记录（验收人，2026-08-01 08:17-08:35，设备 21770d7d）**
> 构建+测试：BUILD SUCCESSFUL，646 tests（app 501 + terminal-emulator 145）0 failed。固定四步执行。
> - element_appear 正链：`PAGE_LOAD → inject detect → report sel=#key → dispatch → hit=true → condition=PASS count=2 → FIRED actions=2 → 导航 q=牛奶 → 「已搜：牛奶」`（截图 DV-10-v3-dialog1/DV-10-v5-35s.png）
> - text_match 正链：注入探针 workflow（pattern「MOV 演示店」+ scroll 免审批动作）→ `report type=text_match → hit=true → PASS → FIRED actions=1`（logcat 08:35:11-21）
> - 防循环：q= 页 `condition=FAIL count=2`（invert ✓）、`skip cooldown` ✓；TICK 10s 节拍 ✓；jd 种子条件正确不命中 ✓
> - 审批闸：写动作弹「浏览器动作确认」拦住，批准前不执行（截图 DV-10-v4-t6/t10）
> - **打回轻项（转 P1 队列，不阻塞 DV-10）**：① `executeBrowserActionSync` latch 回调永不投递——免审批的 scroll 也吃满 10s 超时（08:35:11.320 PASS → :21.322 FIRED），「cbId 回调投递」红线在 workflow 同步路径失效；② FIRED/lastFireAt 落账先于动作副作用（审批慢于 10s 时），修法：审批等待不计 latch 或 latch 延长 + 落账移到动作回执后。根因排查起点：evalJsCb→javaCbMap 对 wf_ cbId 的投递路径

## 四、辅助脚本

`tools/device_accept.sh`：装包 → 唤醒 → 启动 app → 按序号执行预录 tap/截图序列 → 截图落档。
新待验项 = 清单加行 + 脚本加段，不许口头验收。
