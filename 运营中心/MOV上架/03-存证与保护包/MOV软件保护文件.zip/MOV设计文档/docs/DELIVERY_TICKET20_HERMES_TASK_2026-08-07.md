# 工单20 交付说明 — Linux+Hermes 合并工具化（hermes.task）

> 派单：`docs/TASKS_P2_HERMES_TASK_TOOL_2026-08-07.md`
> 施工：P2/agent 侧｜状态：待验收｜commit：见 git log（本说明随 commit 提交）

## 一、三幕交付

### 幕一：infer 通路实证（生死前提）✅
- **8388 直连**：`curl 127.0.0.1:8388/infer` → `{"ok":true,"data":{"content":"12 × 4 = 48。"}}`
- **serve 启动**：`startServe()` → healthz `{"ok":true,"version":"0.2.0","hermes_agent_version":"0.19.0"}`
- **proot→8388 全链**：`curl 127.0.0.1:8387/infer` → serve 转发 8388 → `{"ok":true,"data":{"content":"9 × 7 = 63"}}` + logcat `MOV 推理 model=deepseek-v4-flash`
- 证据：`docs/device-acceptance/2026-08-07/hermes-task/act1-infer-evidence.txt`

### 幕二：工具化 ✅
- **ToolRegistry 注册 `hermes.task`**（linuxAvailable 时）：
  - 描述：「开放式子任务——目标明确但步骤写不出的活。进内嵌 Linux 由 Hermes 自主完成，产物回房间 /room」
  - 分级：`approval=plan`（沿用审批闸）+ `Manifest risk=high`（DANGEROUS 分级）
  - handler → `Tools.hermesTask` → HeavyWorker serve 通路（submitTask + M3 SSE 进度落房间 journal + 产物闸 + PII 打码既有通路）
- **Tools 接口 +hermesTask**，三处实现：BridgeAi（完整）、BridgeKernel（快脑环境返回不可用）、RegistryProvider（MCP 侧完整）
- **PLAN_RULES**：删「worker:heavy:hermes」引导，改写「开放重活规划为 tool.execute + hermes.task 一步」
- **快脑 /tools 清单可见性**：fastRegistry() 按 Linux 可用性构建（原硬编码 false，hermes.task 不可见）
- **UI**：无「双脑/慢脑」用户可见字样（注释除外）
- 测试：HermesTaskToolTest 6/6（注册/分级/信封成功/失败具体原因/空 goal/变异互斥）+ 变异亲杀（handler 恒成功 → 失败断言红 → 还原绿）

### 幕三：全链实证 ✅（真机）
派「读取 sales.csv 计算销售总额写回 sum_result.txt」（shell.exec 干不了的开放任务）：
1. AgentLoop 计划：`tool.execute + hermes.task`（goal 写结果不写步骤）→ 批准
2. **EXECUTING steps=6**：Hermes 自主 3 轮 `tool_call→tool_result`
3. **产物回 /room**：`sum_result.txt` = `sales_total=1195.0`（120+230+95+310+180+260=1195 验证正确）
4. **file.read 可读**：`{"ok":true,"content":"sales_total=1195.0"}`
5. journal 证据链：`tool_call × 3 → tool_result × 3 → phase → deliver`（摘要实证）
- 截图：act3_01（ask 闸）/ act3_02（hermes -z 执行中）/ act3_03（交付）

## 二、施工中发现并修复的关键问题

**hermes LLM 未走 8388**（工单4 根因的正面解决）：
- 现象：hermes.task 卡在 PLANNING/EXECUTING，hermes -z 进程空转——proot 直连外网被 MIUI 封 uid
- 根因：`mov_serve.py` 执行器 `subprocess.Popen(hermes -z)` 未注入 LLM base_url，hermes 用默认配置直连外网
- 修法：executor 注入 `OPENAI_BASE_URL=http://127.0.0.1:8387/v1` + `OPENAI_API_KEY=X_MOV_TOKEN`（serve 的 OpenAI 兼容端点 → 转发 8388 /infer）
- 真机实证：注入后 hermes.task 正常执行至 DONE（产物正确）
- 注：真机已热部署（exchange editable 源码）；`assets/hermes-agent.zip` 需同步重打（zip 工具不可用，验收后可补）

## 三、验收对照

| # | 验收标准 | 自验结果 |
|---|---|---|
| 1 | 幕一 infer 通路证据 | ✅ 三实证（8388 直连 48 / serve healthz / proot→8388 全链 63 + MOV 推理 logcat） |
| 2 | hermes.task 在 /tools 可见 + DANGEROUS + 未授权计划被拒 | ✅ CDP 实证 `{name:"hermes.task",level:"SLOW",check:null}`；approval=plan + Manifest risk=high；空 goal 拒绝测试 |
| 3 | 幕三全链证据链（调用→进度→产物→可读） | ✅ 四段完整（journal tool_call→tool_result→deliver / sum_result.txt / file.read） |
| 4 | 全量绿 + 变异亲杀 | ⏳ 全量跑完待确认；HermesTaskToolTest 6/6 + 变异亲杀 2 连已绿 |

## 四、风险与遗留

- `assets/hermes-agent.zip` 未重打（真机 exchange 已热部署生效；验收后需重打 zip 保安装一致性）
- serve 代理 /tools/invoke 的 REQUEST_TIMEOUT=60s 对长 hermes.task 不够——真实场景走 AgentLoop 内 handler（无此限制）；serve 代理仅适合短工具（如需支持长工具后续调 REQUEST_TIMEOUT）
- hermes.task 产物经 `WorkerResult.files` 回传——HeavyWorker 产物闸（PII 打码）复用既有通路

---

## 五、打回④修复（验收 08d22be 双项）

### ④-1 hermes.task 未进 ESSENTIAL_TOOLS
**根因**（验收真机探针铁证）：compact 模式（默认）非 ESSENTIAL 工具只剩菜单行，模型看不到
hermes.task 的 goal 参数 schema → tool_call arg:"" 空猜（causal 工具 99d300d 同款病）。
**修法**：`ToolRegistry.ESSENTIAL_TOOLS` 加 `"hermes.task"`（一行）+ 单测
`hermesTaskInEssentialTools_promptCarriesGoalParam`（断言 prompt 含 hermes.task 完整文档 +
goal 必填参数描述）+ 变异亲杀（从 ESSENTIAL 移除 → 红 → 还原绿）。
**真机复验**（验收要求：新任务 → tool_call arg 非空 → 产物落房）：
- 计划步骤实证：`{name:"hermes.task", args:{goal:"在房间创建文件 probe_hermes.txt 内容写 probe-ok", timeoutSec:600}}`——goal 非空（修复前 arg:""）
- AgentLoop DONE steps=3；产物 `probe_hermes.txt`="probe-ok" 落房；MOV 工具执行日志（shell.exec/file.read）实证 Hermes 自主执行
- 截图 act3_04_recheck_probe.png

### ④-2 证据文件明文 token
**修法**：act1-infer-evidence.txt 脱敏重打（`X-Mov-Token: aVWn…` 只露前 4 位）；抽查本批其他证据文件
无同类问题；**serve token 轮换**（旧 `aVWn…` 进过 git 历史视为泄漏）：
- 删 shared_prefs/hermes_serve_prefs.xml → 重启后自动生成新 token `j5HLKB7V…`
- 实证：新 token 调 8388 → `3 × 3 = 9` ✅；旧 token → `UNAUTHORIZED`（fail-closed）✅
