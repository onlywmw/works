# DESIGN：支付闸统一 — 2026-08-01（审查裁决落地）

> 审查裁决：支付闸归谁管四种说法打架（FUSION「现状已是统一闸」/ TECH_KERNEL「新增第四道闸」/
> ARCHITECTURE「只认三道闸」/ TASKBOARD「支付闸待认领」）。单独立档承接：tier→闸映射，
> 快脑慢脑 browser_* 全走一条链。本文档为支付域的**唯一权威描述**，其他文档冲突处以此为准。

## 一、现有闸现状审计（事实，不是设计）

| 闸 | 位置 | 职责 | 输出 |
|---|---|---|---|
| DevicePolicy | `agent/ToolRegistry` | 硬件能力探测（相机/定位/闪光灯等），工具可用性 `checkAvailability` | null=可用 / 字符串=不可用原因 |
| PermissionPolicy | `agent/PermissionPolicy` | 慢脑 `tool.execute` 中间件：按工具 `access`/`approval` + allowedPaths 白名单 | ALLOW / DENY / CONFIRM |
| PaymentGate | `PaymentGate` | 支付域识别 + 审批 + 审计 | — |

**PaymentGate 现状**（已实现，非新设计）：
- 支付域识别：`isPaymentDomain(url)`，规则 `domain_policies.json`（RULES_FILE）
- 审批：`promptPaymentApproval(activity, actionDesc, onSuccess, onRejected)` —
  Keyguard 检查：无安全锁屏 → 直接拒绝（`no_lockscreen_denied`）；有锁屏 → `createConfirmDeviceCredentialIntent`（指纹/面部/PIN/图案）
- 结果：`handleActivityResult(requestCode, resultCode)`（REQUEST_CODE_PAYMENT_CONFIRM=9001）
- 审计：`auditEvent(action, url, biometricResult)` → `filesDir/payment_audit.jsonl`（append-only）
- 拒绝原因：`cancelled / no_lockscreen_denied / keyguard_unavailable / keyguard_intent_null`

**支付执行链路（当前唯一承接点）**：`ConnectWebActivity` 支付域页面 → `isPaymentDomain` →
`promptPaymentApproval`（生物识别+锁屏）→ 通过后放行 + `auditEvent`。

## 二、tier → 闸映射（裁决）

工具分三级风险，映射到闸：

| tier | 语义 | 闸 |
|---|---|---|
| **READONLY** | 只读查询，无副作用 | 直放（DevicePolicy 可用性探测通过即可） |
| **ACTION** | 有副作用的写操作 | 会话免审（PermissionPolicy CONFIRM：一次确认，会话内不再问） |
| **DANGEROUS** | 支付 / 高危（生物识别可撤销的动作） | **PaymentGate：生物识别 + 锁屏**。无安全锁屏设备直接拒绝（铁律不变：支付域 tier=DANGEROUS，无锁屏设备直接拒绝） |

> 与 ToolRegistry 工具字段的对应：`access=readonly/write` 映射 READONLY/ACTION 语义；
> `Manifest.category=io/exec/device` 是权限路由用；DANGEROUS 由支付域判定（`isPaymentDomain`）
> 或显式 tier 标注（browser_* 支付域工具）决定。

## 三、browser_* 全链（裁决）

browser_*（ConnectWeb）工具分级收编进统一注册表：

| 分级 | 例 | tier |
|---|---|---|
| 读 | browser 页面快照 / 取元素 / 查状态 | **READONLY**（FAST，直放） |
| 写 | browser 点击 / 输入 / 导航提交 | **ACTION**（FAST，过审批闸） |
| 支付域 | 支付提交 / 下单确认 | **DANGEROUS**（生物识别+锁屏） |

快脑（场景卡 query 转发）与慢脑（AgentLoop `tool.execute`）对 browser_* 的调用**全走这一条链**：
`PermissionPolicy 中间件 → tier 判定 → ACTION 会话免审 / DANGEROUS 生物识别`。

## 四、执行与承接

- **L1.5 落点**（TASKBOARD P3「支付闸 L1.5：新脸支付 sheet 接闸」）：新脸支付 sheet 的提交动作
  接 `PaymentGate.promptPaymentApproval`（生物识别），与 ConnectWeb 走同一闸。
- **browser_* 注册**：见 DESIGN_FUSION 迁移清单补充（browser_* 分级收编任务）。
- **OCR 文档修正**：`DESIGN_OCR_MOBILE` 引用的「支付闸金额核对环节」**当前不存在**——
  金额上下文提取有 `extractPaymentContext`（解析 ¥ 金额），但无独立"金额核对闸"。
  付款金额以页面实际提交为准，审计记录已含金额脱敏。

## 五、红线（不变）

- 支付/短信/通讯录/通话记录永久不碰（不碰钱、不碰信）
- 支付域工具 tier=DANGEROUS；无锁屏设备直接拒绝（生物识别不可用即拒绝，不降级放行）
- 审计 append-only（`payment_audit.jsonl`），禁改禁删
