# Kimi 桌面版逆向分析 — 工作方式与云端 API 数据处理

> 分析对象：`C:\Users\Administrator\AppData\Local\Programs\kimi-desktop`（v2.x，Electron）
> 日期：2026-08-04 ｜ 目的：深挖其工作方式，为接入 MOV 专家模式做技术准备
> 证据源：解包于 `C:\Users\Administrator\AppData\Local\Temp\kimi-analysis\`

---

## 一、架构总览（四层）

```
┌─ ① Electron 壳（app.asar 89MB）
│    主进程 out/main/index.js + preload 桥 + 渲染进程（kimi-agent.html / ConversationView）
│
├─ ② daimon 内核（daimon-bundle 258MB，另一团队交付）
│    本地 agent 运行时（@moonshot-ai/agent-core），强混淆（javascript-obfuscator-strong）
│    控制服务器：ws://127.0.0.1:<port>/control + Bearer token（loopback-dev-token）
│    运行时：Node v24 + CPython 3.12 + uv（nodePty 支持）
│
├─ ③ gateway 网关（gateway.asar 232MB）
│    含 anthropic-ai-sdk / clawhub 等 —— 模型 API 客户端
│
└─ ④ skill 系统（builtin-skills/）
      kimi-webbridge：控制真实浏览器（本地 daemon 127.0.0.1:10086，CDP）
      释放机制：daimon prepare 时释放到 KIMI_SKILLS_ROOT；kimi-webbridge 托管覆盖
```

## 二、云端 API 数据处理逻辑（核心）

### 协议栈（三层，**不是 SSE**）

| 层 | 技术 | 证据 |
|---|---|---|
| 应用协议 | **Anthropic Messages API** | `BASELINE_PROVIDER_API = "anthropic-messages"` |
| RPC 传输 | **bufbuild Connect** | `createConnectTransport` + `EnvelopeDecoderImpl` |
| 编码 | **protobuf binary**（默认）/ JSON（调试） | `useBinaryFormat` + `fromBinary(desc, value)` |

### 数据链路

```
发送: 请求 → buildAuthInterceptors(鉴权加 token)
      → Connect envelope 帧编码 → fetchViaChromiumNet(Chromium 网络栈)
      → POST https://agent-gw.kimi.com/coding

接收: 响应流 → ReadableStream + getReader 逐块读
      → EnvelopeDecoderImpl 按帧解析（5 字节头 + payload）
      → fromBinary(desc, value) 反序列化（@bufbuild/protobuf）
      → ConnectError 分类（ResourceExhausted 等）
      → 消息事件 → 渲染进程增量渲染（ConversationView）
```

### 帧格式（EnvelopeDecoderImpl）

```
每个消息 = 5 字节头 + payload
  byte 0     : flags（压缩/类型标记）
  byte 1-4   : length（大端 32 位）
  payload    : protobuf 序列化（Anthropic 消息：role/content/tool_use）
```

缓冲累积 → 逐帧 `pop()` → `assertReadMaxBytes` 校验（超限抛 ResourceExhausted）→ 完整帧才返回（**跨 chunk 不撕裂**）。

### 关键配置（index.js 基线）

```
BASE_URL     = https://agent-gw.kimi.com/coding
API 协议      = anthropic-messages
上下文        = 201072 tokens / max_tokens 32768
网关模式      = local（daimon 本地编排）
浏览器画像    = openclaw
调试后门      = KIMI_CAPTURE=1 切 JSON 编码（Charles 抓包可读）
```

## 三、各模块深挖

### daimon 内核（本地 agent 运行时）

- 入口 `bin/daimon.cmd`：先 `control serve`（等 Kimi Code API key），再 `runtime`（start --control）
- 控制服务器：`ws://127.0.0.1:<port>/control`，`Authorization: Bearer <token>`；fd-rpc 兜底
- 依赖：better-sqlite3 / @moonshot-ai/agent-core / yazl
- esbuild 打包 75 入口 / 15 chunk，强混淆（**逆向成本高**）

### skill 系统

- `KIMI_SKILLS_ROOT`：daimon skills 目录
- 注入通道：desktop app 独立注入（编译期注入 builtin-skills/，运行期释放）
- 释放策略：默认 **skip-if-exists**（缺失才拷）；`MANAGED_OVERRIDE_SKILLS`（kimi-webbridge）**强制覆盖**
- 单一信源：kimi-webbridge 真源是 CDN 压缩包，构建期下载注入（零漂移）

### kimi-webbridge（控制真实浏览器）

- 本地 daemon `http://127.0.0.1:10086`（kimi-webbridge.exe，PE 原生）
- 用用户真实浏览器 + 真实登录态（chrome.debugger/CDP）
- 工具：navigate / find_tab / snapshot(可访问性树) / click / fill(支持 contenteditable) / evaluate(async) / cdp(底层透传) / screenshot / network(抓包) / upload / save_as_pdf / 标签页管理
- 会话隔离：find_tab 默认只查本会话 tabs；`active:true` 借用用户当前标签页（borrowed）
- 用例：`curl -X POST http://127.0.0.1:10086/command -d '{"action":"navigate","args":{...},"session":"..."}'`

## 四、可借鉴点（为 MOV 专家模式）

| Kimi 机制 | MOV 现状 | 借鉴价值 |
|---|---|---|
| **skill 系统**（KIMI_SKILLS_ROOT + 托管覆盖） | ToolProvider（无 skill 市场） | 高——MOV 可加 skill 机制扩展能力 |
| **webbridge（CDP 控制真实浏览器）** | ConnectWeb（自研 WebView） | 高——真实浏览器 + 用户登录态是 ConnectWeb 没有的 |
| **Anthropic Messages 协议** | AiClient（OpenAI 兼容） | 中——扩展协议支持，接 Anthropic 生态 |
| **Connect 二进制分帧流** | SSE 流式 | 低中——MOV 已有 SSE，协议替代非急需 |
| **本地 agent 运行时 + WS control** | HeavyWorker / hermes serve | 中——架构参考（daimon 模式） |
| **调试后门**（KIMI_CAPTURE 切 JSON） | — | 低——MOV 已有 logcat |

## 五、接入 MOV 专家模式规划（草案）

### 高价值优先（可派单）

1. **skill 机制**（借鉴 KIMI_SKILLS_ROOT）
   - MOV 加 `skills/` 目录 + SkillStore 加载 + 释放策略（skip-if-exists / managed-override）
   - 首个 skill：`mov-webbridge`（复用下述浏览器控制）

2. **真实浏览器控制**（借鉴 webbridge CDP）
   - MOV 加本地 daemon（控制 Chrome/Edge 真实浏览器，用户登录态）
   - 复用 MOV 已有 BrowserToolProvider 的动作集 + CDP 层
   - 对接 ConnectWeb（自研 WebView 保留，真实浏览器为新增通道）

3. **Anthropic Messages 协议支持**（AiClient 扩展）
   - AiClient 加 anthropic-messages provider（tool_use 格式）
   - 让 MOV 能接 Anthropic 兼容端点（本地/云端）

### 中价值（后续）

4. **本地 agent 运行时 + WS control**（架构参考）
   - MOV HeavyWorker 强化：WS 控制服务器模式（vs 当前 healthz 轮询）

## 六、可继续深挖的点

- [ ] protobuf schema（Anthropic 消息字段、tool_use 格式）——解 gateway.asar 后搜 proto 定义
- [ ] 鉴权 token 生成/刷新（buildAuthInterceptors 内部）
- [ ] webbridge daemon 内部实现（kimi-webbridge.exe 反汇编/行为观察）
- [ ] daimon 混淆 JS 的 control WS 消息协议

---

> 备注：解包证据在 `C:\Users\Administrator\AppData\Local\Temp\kimi-analysis\`（app.asar 已解包，gateway.asar 未完整解包）。
