# PLAN：Hermes 阶段3 后半 — 一套工具表 / 一套记忆 / 一套 LLM 管道

status: 计划（待拆派单）
日期: 2026-08-03
依据: [DESIGN_HERMES_SERVE §九演进路线](DESIGN_HERMES_SERVE.md) + [HERMES_ANATOMY](HERMES_ANATOMY.md) + [TASKS_P6_HERMES_SLIM](TASKS_P6_HERMES_SLIM_2026-08-02.md)

---

## 一、目标

**Hermes 只留「规划器 + 执行循环」，不再自带给它那套平行世界的工具/记忆/LLM 管道。**

前置已完成：M1-M5 serve 全通 + 瘦身两刀（零成本砍 4 文件 + serve 白名单 32→16，巡检#50）。
本计划是**架构级瘦身**——收掉 Hermes 的重复实现，让它所有外部分别走 MOV 的底座。

```
┌─ Hermes（规划器+执行循环，serve 常驻）─────────────┐
│  推理 → POST /infer        → MOV BridgeAi 管道      │  LLM 收编
│  工具 → POST /tools/…/invoke → MOV ToolRegistry 统一闸 │  工具统一
│  记忆 → /memory 读写        → MOV journal（唯一事件源）│  记忆统一
└──────────────┬───────────────────────────────────────┘
               │ daemon → MOV 回调（A0 建的入站监听，127.0.0.1:8388）
```

**地基（A0）缺一不可**：目前 MOV 只有出站 HTTP（HermesClient 调 daemon），**没有入站监听**——daemon 要回调 MOV 执行工具/推理/记忆，必须先有 A0 通道。这是本计划第一个件。

## 二、现状（已核实的落点）

| 项 | 现状 | 落点 |
|---|---|---|
| /tools 预留位 | `GET /tools` 返回 `{"tools":[]}` 空表 | `hermes-agent/hermes-agent-main/mov_serve.py:378` |
| /tools/{name}/invoke | **未实现**（仅设计预留） | 同上，待补 |
| MOV 统一注册表 | ToolRegistry 全量工具（tier/level/checkFn） | `app/src/main/java/com/hermes/android/agent/ToolRegistry.java` |
| MOV LLM 管道 | BridgeAi/AiClient（桥内现成） | `app/src/main/java/com/hermes/android/bridge/BridgeAi.java` + `ai/AiClient.java` |
| MOV 记忆 | journal.jsonl（append-only 事件流 + 回放投影；**无按内容检索**） | `app/src/main/java/com/hermes/android/StorageManager.java` + Journal |
| MOV 入站监听 | **无**（只有出站 OkHttp；A0 要新建） | 新组件（见件 A0） |
| Hermes 自带实现 | model_tools.py(1259 行) / tools/registry.py(39 工具) / hermes_state.py(FTS 检索 :5443 / 会话恢复) 等 | `hermes-agent/hermes-agent-main/` |

## 三、三大件 + 裁剪（每件独立可验）

### 件 A0：MOV 入站监听（地基，第一个件）

**目标**：建 daemon→MOV 回调通道——MOV 侧起 127.0.0.1 HTTP 监听，让 serve 能回调 MOV 执行工具（B/C 的推理/记忆回调复用同一通道）。

| 子项 | 内容 | 落点 |
|---|---|---|
| A0-1 | 新组件 MOV 入站 HTTP 监听（127.0.0.1:8388，OkHttp/自研轻量 server），暴露 `/tools/{name}/invoke`（执行）+ `/infer`（LLM）+ `/memory`（记忆）预留路由 | 新建 `app/src/main/java/com/hermes/android/...`（如 `serve/MovInboundServer.java`） |
| A0-2 | 鉴权：回调带 X-Mov-Token（与 daemon 同 token），MOV 侧 fail-closed 校验 | 同上 + HermesServeConfig |
| A0-3 | 路由分发给 ToolRegistry 执行（走统一闸 DevicePolicy/PermissionPolicy） | AgentLoop / ToolRegistry |

**独立验收（A0 单独可验，不依赖 hermes agent 改动）**：
- 真机：proot 内 curl `127.0.0.1:8388/healthz` → MOV 响应；curl `/tools/{name}/invoke` 传 `shell.exec "echo hi"` → 返回 ToolRegistry 结果（logcat 见 MOV 执行）
- 错误 token / 无 token → 401 fail-closed；非 127.0.0.1 来源拒绝
- 全量 assembleDebug test 绿（A0 单测：路由分发/鉴权/信封）

**风险**：MOV 进程死 → 回调断 → hermes 工具全不可用（需 healthz-on-call 对称；与 daemon 同纪律）。

### 件 A：工具统一（依赖 A0，先做）

**目标**：Hermes 调工具 = 回调 MOV，不自带工具实现。

| 子项 | 内容 | 落点 |
|---|---|---|
| A1 | `POST /tools/{name}/invoke` 端点实现：收 `{params}` → 经 A0 转发 MOV 执行 → 回结果 | mov_serve.py |
| A2 | HermesClient 加 `invokeTool()`（调 MOV 入站监听）；**单独一验** | HermesClient.java |
| A3 | `GET /tools` 填真：MOV ToolRegistry 清单（name/level/tier/params/examples）推到 daemon | mov_serve.py + ToolRegistry |
| A4 | Hermes agent 工具层改造：执行循环改走 `/tools/…/invoke` 回调（`tools/registry.py` 裁掉，白名单变 MOV 清单）——**最高危点，单独一验** | hermes-agent agent/tools 层 |

**A4 拆验顺序（防断 M1 剧本）**：① 先 serve 内 curl 通 A0/A1（不碰 agent）→ ② 再动 hermes agent 侧工具层，跑 M1 剧本全链 → ③ 最后才裁 `tools/registry.py`。三步各自独立验证，任何一步红回退上一步。

**验收**：
- serve 内 hermes 任务用 `shell.exec`/`file.write` → logcat 可见经 MOV ToolRegistry 执行（非 hermes 本地实现）
- `/tools` 返回真实清单（非空表）；`/tools/{name}/invoke` 端到端 curl 可调
- 危险工具 tier=DANGEROUS 在 MOV 侧照旧弹确认（两侧都验）
- 全量 assembleDebug test 绿 + pytest 端到端

**风险**：Hermes→daemon→MOV 回调链路 RTT（相对本地工具慢，2-hop reverse；v1 串行可接受）；A4 工具调用协议改动面大（改错会断 M1 剧本）。

### 件 B：LLM 管道收编

**目标**：Hermes 推理走 MOV BridgeAi 管道，`model_tools.py` 裁掉。

| 子项 | 内容 | 落点 |
|---|---|---|
| B1 | daemon 加 `POST /infer`：收 prompt → 转发 MOV BridgeAi → 回补全 | mov_serve.py + BridgeAi |
| B2 | Hermes agent 推理客户端换路：LLM 调用改走 /infer 回调（provider 配置收编，不再自管 DeepSeek 等） | hermes-agent agent/llm 层 |
| B3 | `model_tools.py`(1259 行) 裁掉；venv 依赖里 model/provider 相关移除 | hermes-agent |

**验收**：
- serve 任务推理真实走 MOV BridgeAi（logcat：MOV 模型请求 + 回包）
- `model_tools.py` grep 零引用；删后 serve 全链不回归
- 禁网语义复核：infer 走 MOV 侧网络，不受任务 network=false 影响（否则禁网任务无法推理）

**风险**：agent 推理循环强耦合 LLM 客户端内部，换路是阶段3 最高危件；Streaming/上下文管理要逐段对齐。

### 件 C：记忆统一（工作量比「代理」重——需补检索实现）

**目标**：journal 唯一事件源，Hermes 读写走 serve；但 **journal 是 append-only 事件流 + 回放投影，语义 ≠ hermes_state.py 的检索库**（FTS 按内容搜历史 :5443 / 会话恢复是 hermes 的核心能力）。直接删平行库会让 `session_search` 类能力**退化**，必须先在 journal 侧补检索。

| 子项 | 内容 | 落点 |
|---|---|---|
| C1 | serve 加 /memory 读写端点 → 代理到 MOV journal（读=回放投影，写=append） | mov_serve.py + Journal |
| C2 | **journal 侧补按内容检索**：历史事件全文检索（事件内容→索引/扫描→按相关度返回），对齐 hermes FTS 能力（:5443 的等价物） | 新组件（Journal + 检索层），落点 `Journal.java` / StorageManager |
| C3 | Hermes 记忆层换路：hermes_state.py 等读写改走 /memory，`session_search` 用 C2 的检索 | hermes-agent 记忆层 |
| C4 | Hermes 侧平行记忆库删除/收编（**在 C2 落地后**才允许删） | hermes-agent |

**验收**：
- 同一事件 MOV 侧与 Hermes 侧读到同一份（journal）；Hermes 平行记忆库 grep 清零
- **C2 检索不退化**：历史事件按内容关键词搜得到（对齐 hermes FTS 的检索语义，正例+反例）
- 会话恢复/`session_search` 类能力真机实证（旧能力清单逐项对照，禁降级）

**风险**：C2 是真工作量——journal 若事件未全量落盘检索字段，需设计索引/事件 schema；hermes FTS 的查询语义（fuzzy/rank）要对齐否则能力降级。**这是件 C 的真实成本，此前计划低估。**

### 件 D：裁剪（收尾）

- cli 交互界面 / 批处理 / termux 专用部分按解剖清单裁（延续第一刀）。
- 验收：serve 闭包最小集实测（当前 16 模块 → 目标 <10）；`hermes --version` 正常。

## 四、禁网语义（两条腿分开写，验收人勿猜）

- **network=false 只拦任务「工具」的网络操作**：serve 的 LD_PRELOAD 禁网库（mov_nonet.so）挂在任务子进程上，拦的是任务内 shell/工具出网（M5 已实证）。
- **infer 是 MOV 侧 LLM 能力，天然出网**：Hermes 推理走 MOV BridgeAi 管道后，推理连接走 MOV 自身网络，**不受任务 network=false 影响**（否则禁网任务无法推理）。
- 结论：**任务工具网 / 推理网是两条腿**。M5 禁网实证（network=false 出网失败）针对工具腿；infer 不在此列。验收时分开测，不许拿一条腿的结论套另一条。

## 五、依赖与排期

```
A0 入站监听（地基）──> A 工具统一 ──┬──> B LLM 收编（复用 A0 通道）
                                   └──> C 记忆统一（复用 A0 通道，可与 B 并行）
D 裁剪 最后（三件收完再裁，避免裁了又要用）
```

- **A0 先**：唯一地基，B/C 的 daemon→MOV 回调都吃它。
- **A0 独立成件**：单独验收（真机 curl 实证），不依赖 hermes agent 改动。
- **A 次之**：A1-A3 可先（serve 端点 + MOV 回调），A4（hermes 工具层重写）最高危、单独一验、拆三步。
- **B、C 可并行**（互不依赖，都吃 A0 通道）。
- **D 收尾**。

## 六、明确不做（延续 DESIGN §十）

- 不做多实例/并发池（v1 串行）
- 不做跨设备访问（绑死 127.0.0.1）
- 不做热升级、不引入新持久化
- 阶段3 只收 Hermes 的平行实现，**不动 MOV ToolRegistry/Journal/BridgeAi 本体**（两脑共用底座，MOV 侧是真理源）

## 七、验收结论

（执行人填写；每件独立验收，A0 是地基，A 是 B/C 前置）

## 八、验收标准（严格版，验收人按此逐环核）

**定级**：A0/A/B/C = L3（桥签名/持久化/权限闸，全套：diff 精读+变异+真机多场景）；D = L2。

**证据链铁律**（L2+ 真机项必产，链断一环 = 打回）：
```
[触发] 输入/发起截图（能看到任务/命令内容）
  → [动作] 执行 logcat 原文（工具名/时间戳/参数）
  → [中间态] 过程截图（动作有 UI 副作用时必给，如 browser.click 前后各一屏对比）
  → [结果] 结果截图 + 断言对照（截图里看得到断言的那件事）
```
- 截图与断言一一对应（断言 X 必须指到链上实物）；时间戳与 logcat 对齐；每环能指回 diff 对应代码。
- **点击验证**：真实点击（adb tap / CDP），点前点后各一屏对比，「点了有反应」必须看到变化。

**假覆盖四形态**（每件对照）：① mock 喂答案（推理用 mock LLM 当生产）② 虚构数据路径（**回调链路用 fake MOV 端点当生产**——A0 最大坑）③ 字面量比较 ④ 测试重写被测逻辑。

**变异测试**：每件一个核心 mutant 必红（带真实计数 `N tests completed, M failed`）：
- A0：入站端点返回恒空 → A0 测试红
- A：回调链路跳过 PaymentGate/DevicePolicy → 危险工具无确认执行 → 红
- B：/infer 恒回固定 → 推理测试红
- C：/memory 写假 journal → 双端同读红

**各件真机证据链**：
| 件 | 证据链 |
|---|---|
| A0 | curl 请求截图 → 返回 JSON 截图（真实工具结果）→ 401 无 token 截图 |
| A（A4 换路） | 任务触发截图 → 发任务 logcat → **MOV ToolRegistry 执行行 logcat** → 结果回传截图 |
| B | 任务触发 → MOV 模型请求 logcat → UI 回复截图（流式中态+完成态两张） |
| C | MOV 写事件截图 → journal 落盘 → Hermes 侧读回截图（同一段内容两处可见）→ 检索正例+反例 |
| D | 起服 healthz 截图（版本号）→ 任务全链 → `hermes --version` 终端截图 |

**打回格式**：现象(实证) → 根因(文件:行号) → 修法(具体/二选一) → 复验方式。不写「体验不好」。
