# 视频资源库（VideoLibrary）设计 — 2026-07-30

> 用户原话：「我要做一个视频资源库，就是给 agent 用的」。
> 定位：**agent 的可查询视频资源池**——不是文件夹浏览器，是 agent 帮用户找片/放片时调用的结构化索引。
> 隐私：100% 端侧，索引/文件名/观看记录不出设备。

## 三层架构

```
┌─ 工具层（agent 的手）──────────────────────────┐
│  video.search(query) → 结构化结果（标题/时长/源） │
│  video.get(id) → 详情                            │
│  video.play(id) → LocalPlayerActivity 内嵌播放    │
│  （注册进 agent 工具表，play 过审批闸）            │
├─ 索引层（VideoLibrary）─────────────────────────┤
│  统一条目 {id, title, sub(集数), duration,        │
│           resolution, source, path,              │
│           playCount, lastWatchedAt}              │
│  内存索引 + filesDir/video_library.json 持久化    │
│  mtime 增量重扫，不全量                           │
├─ 采集层（三个源，v1）───────────────────────────┤
│  ① local：MediaStore 本机视频文件                │
│  ② history：观看历史（journal/观看记录重建）       │
│  ③ fav：用户收藏（"收藏这个"指令/卡片星标）        │
└─────────────────────────────────────────────────┘
```

## 消费者（谁用它）

1. **追剧流**：`DramaSource.search()` prepend 本地命中（原任务 D 做法）
2. **新脸对话**：「我有什么悬疑片」「放个电影」→ IntentEngine 分类 → video.search → 片库卡片流 → 点击内嵌播
3. **agent 专家模式**：工具表里的 video.* 工具，LLM 直接调
4. **（Phase 3A 联动，v2）**：情境图谱——晚上插着电视频推荐，主动卡片「看一部？」

## 关键设计决策

| 决策点 | 选择 | 理由 |
|---|---|---|
| 元数据补全 | v1 只做文件名+MediaStore（时长/分辨率） | 豆瓣已下线，在线补全无可靠中文源；文件名规则已验证（任务 D 的提取器复用） |
| 索引进 LLM 上下文 | **不直接进**——video.search 结果进 | 索引可能几百条，塞上下文烧 token；工具调用按需取（协议 §0 的省钱原则） |
| 播放 | LocalPlayerActivity 内嵌（已定） | 用户铁律：影视内嵌 |
| 观看记录回写 | play 后写 journal + playCount/lastWatchedAt | 「接着上次看」从追剧延伸到片库 |
| 收藏 | v1 指令式（"收藏这部"）+ 卡片星标 | 轻，不做合集/片单 |

## 与现有资产的关系

- 任务 D 的 LocalVideoLibrary → 降级为采集层 ① 的扫描器
- video_sources.json 的 `local` 条目 → 升级为整个 VideoLibrary 的注册卡
- LocalPlayerActivity → video.play 的落点（复用）

## v1 施工顺序（P1）

1. 索引层：VideoLibrary + 条目结构 + 持久化 + mtime 增量
2. 采集层 ①：local 扫描器（任务 D 的提取器并入）
3. 工具层：video.search/get/play（桥方法 + 审批闸）+ 新脸片库卡片
4. 采集层 ②③：history 重建 + fav 标记
5. 追剧流 prepend 改造（DramaSource 改调 VideoLibrary）

## 验收（到时候我实测）

- 塞 3 个本地片（庆余年 S01E01/漫长的季节 E08/一部无关片）→ 说「我要追庆余年」→ 本地第一；说「我有什么剧」→ 片库卡片流（3 条带时长）；点击内嵌播放；journal 有播放记录
- 飞行模式全流程可用
- 断网单测：索引增量/标题提取/工具 envelope
