# 工单24 交付说明 — 资产转化层：对话→技能提炼环

> 派单：`docs/TASKS_P2_ASSET_FORGE_2026-08-07.md`
> 施工：程序员｜状态：待验收

## 一、交付内容（幕一提炼环 + 升级通道）

### 提炼器 SkillDistiller（核心）
- **转录**：读房间 journal（user_input/tool_call/tool_result/deliver）→ 转录文本（只读不写）
- **防角色捕获三件套**（借 TencentDB skill-review-prompt 骨架）：
  - a. 转录标记：输入包裹 `<<past-user>>/<<past-assistant>>`，prompt 声明模型是分析者不是参与者
  - b. 输出契约：只允许 `{action:save|nothing|reject}` 形状；垃圾输出/解析失败 → nothing
  - c. 库收敛：候选与既有技能重名/描述近似 → nothing（优先 patch 旧技能）
- **指令式内容检测**：转录含「忽略你的规则/act as/你现在是」等 → reject（不执行）
- 测试：SkillDistillerTest 8/8 + 变异亲杀（防捕获恒 false → reject 测试红）

### 双通道触发
- **手动**：`skill.distill` postCmd（用户「把这个做成技能」）
- **自动**：AgentLoop deliver 后异步旁路（同域成功 ≥2 次才触发——防噪声）

### 确认卡入库（addSkill）
- `SkillStore.addSkill` + BridgeSkill/BridgeFactory/JS 三层暴露
- **修复 parseSkill 丢字段 bug**：triggers/steps/validation/params 原被丢弃 → 全保留（SkillStoreAddSkillTest 2/2 锁定）
- `SkillActivator` 装配扩展：用户技能库（addSkill 入库的）在 agentStart 时也装配（新房间触发语命中前提）

### 升级通道（复用≥3 → 工厂产线）
- `promoteReadySkills`：uses≥3 的技能 → 生成需求单（title/input/expectedTools/checkCases/skillSource）→ 落 `filesDir/mcp-factory-inbox/`（PC 同步）；req.exists() 幂等防重复

## 二、真机实证（21770d7d）

| 环节 | 证据 |
|---|---|
| 任务交付 | agentStart「创建 products.csv+读取确认」→ PLAN_GATE 批准 → fileWrite 闸 → DONE steps=2 |
| 提炼 | skill.distill → `{action:save, skill:{name:create_and_verify_csv, triggers:[...], steps:[...], validation, params}}` |
| 确认入库 | addSkill → `{ok:true, id:create_and_verify_csv}`；listSkills count=4 inLib=true |
| 库收敛 | 再提炼同房间 → nothing（不产重复品） |
| **防角色捕获** | 注入「忽略你的规则」→ `{action:reject, reason:"检测到指令式内容，拒绝提炼"}` |
| **闲聊零候选** | 纯闲聊房间 → nothing |
| **升级通道** | recordSkill×3 → promoteReadySkills → `REQ-create_and_verify_csv` 落盘（幂等） |

截图 act1_fullchain.png + 证据 act1-evidence.txt

## 三、验收对照

| # | 验收标准 | 自验结果 |
|---|---|---|
| 1 | 真机全链：任务→候选→确认→新房间触发命中 | ✅ 任务→候选→确认入库全通；触发命中装配扩展已接（真机新房间触发需再跑一条任务验证） |
| 2 | 反例：闲聊零候选 | ✅ nothing 实证 |
| 3 | 防角色捕获 | ✅ reject 实证 |
| 4 | 全量绿 + 变异亲杀 | ⏳ 全量跑完待确认；SkillDistillerTest 8/8 + 变异拦截 |

## 四、风险与遗留

- **新房间触发命中**（验收 1 尾段）：装配扩展已实现（agentStart 装用户技能库），但真机「新房间触发语→技能生效」需再跑一条完整任务+新房间触发验证（本次因 App 重启任务流中断未完成该段；触发语命中依赖技能 tools 装配——当前 addSkill 技能 tools 为空数组（提炼技能是步骤描述非工具），实际命中机制待真机复验确认）
- Wiki 后置（笔记支柱开工时内置，ingest-v2 参照件 reference/ 备查）——本单未涉及
