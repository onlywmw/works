# MOV 分支查验报告（2026-08-05）

> 按 BRANCH_RULES 查验标准（diff 精读 + 全量四数 + 验收记录核查），深入各分支（git log + 关键设计/自述文档），登记于 acceptance-data。
> 查验人：P1 ｜ 方法：git log 各分支 ^main + git show 关键文档 + 全量测试 + 验收记录 grep。

## 一、分支地图总览

| 分支 | 未合并 | 内容类型 | 验收状态 | 建议 |
|---|---|---|---|---|
| **main** | 稳定线 | 已验收交付 + 总自述 + 欠账 | — | — |
| **feat/dual-brain-upgrade** | 38（13 独有+25 共享） | 一表双脑（Anthropic/技能/浏览器/工具重定向）+ rootfs 开箱 | 批1 ✅ 入档；批2/3 ⚠️ 待验收 | 批1 先 merge，批2/3 补验收 |
| **feat/causal-memory** | 25 | 因果记忆编译器 + API 归因层 | 引擎打回后已修复+真机实证；模型融合两档暂缓 | 引擎可先 merge 或待融合 |
| **feat/mcp-external** | 1 | MCP 官方 SDK server（P1 已入 main） | ✅ P1 已验收 | 剩文档并入 main |
| **feat/surpass** | 6 docs | 超越计划/产品对比/四支柱定位 | 定位定稿，无验收 | 文档可并入 main |
| **核心竞争力** | 7 docs | 核心资产库（OCR 壁垒等） | 资产盘点，无验收 | 文档可并入 main |
| **feat/fullscreen-html** | 外部新增 | HtmlViewer 全屏相关 | 未查验 | 待用户说明 |

## 二、各分支查验详情

### 1. main（稳定线）
- **定位**：AI 原生个人成长伴侣——可演化记忆层 + 健身/笔记/学习/工作四支柱，快脑+慢脑一表双脑、90+ 工具、MCP、端侧 OCR、因果记忆、Agent 循环。
- **质量锚点**：800+ JUnit（含 causal 848）；OCR golden 380/380；DV-10 真机终验通过（2026-08-01）。
- **欠账登记**（TASKBOARD 尾部）：多选删房 / 新建文件 sheet / inbox+archive 文件区（第三幕清场缺口，不许悄悄丢）；因果记忆模型融合近档（DeepSeek 四元组抽取）+远档（3B 图文合一）——**用户已定暂缓**。
- **观察**：README 引用的 `docs/PLAN_SURPASS.md`/`CORE_COMPETENCY.md`/`UPGRADE_DUAL_BRAIN.md`/`causal-memory/` 在 main 不存在（各分支文档待 merge 补齐）。

### 2. feat/dual-brain-upgrade（38 未合并）
- **一表双脑升级三批**（方案 `docs/UPGRADE_DUAL_BRAIN.md`）：
  - 批1 Anthropic Messages 协议（`8054ec9`）：AiProviderConfig.protocol 双分支 + SseParser anthropic 事件 + tool_use 统一走 ToolRegistry 闸
  - 批2 动态技能系统（`cf9d5d9`）：SkillStore ensureSeeded + registerDynamicTool + mov-demo 内置技能（反假菜单）
  - 批3 CDP 真实浏览器控制（`11352e0`）：CdpClient + MovWebBridge + mov-webbridge skill
  - 另含：rootfs 种子开箱即用（`92996fc`/`0ef8a4a`）、解压提速 68s→16s（`a3f32ca`）、开放对话 DeepSeek 真回复（`b16eb1c`）
- **验收**：批1 入档（`8f79f57`：变异 3 杀+补强，全量 883/18/0/0）；批2/3（含工具重定向/记忆桥接/技能共享）**无验收记录**——但我 2026-08-04 已按查验表登记 A25-A27（三批 886/18/0/0 全量绿 + diff 精读真实现）。
- **独特资产**：Anthropic 双协议分支、动态技能系统、CDP 真实浏览器通道（与 ConnectWeb 并存）、rootfs 预置。
- **结论**：代码质量高（分批清晰、均有测试），批1 已验收，批2/3 我查验过（A25-A27）。**待真机端到端**（Hermes serve proot 内 adb 不可达）后整体 merge main。

### 3. feat/causal-memory（25 未合并）
- **本地因果记忆编译器 v1**（分支自述 `docs/causal-memory/README.md`）：四元组事件 + SHA-256 哈希索引（不存原文）+ IF..THEN 逻辑钩子 + 哈希链认知账本 + 时间衰减遗忘（7 天墓碑）。纯 Java 零 android，全量 848 + 变异反证 2 处。
- **API 归因层**（`docs/DESIGN_CAUSAL_APIFACT.md` + `e3b43f5` 实现）：NarrativeBuilder 脱敏叙事 + CausalOracle（DeepSeek 归因，无状态不存数据）+ PatchCompiler 补丁钩子。
- **验收历程**：v1（`75b9d37`）打回（缺口③模型融合）→ 修断点①工具进 ESSENTIAL_TOOLS（`99d300d`）→ CausalSpikeCheck 真机引擎链路实证（`67f0acd`）→ 由果推因闭环 + patch_rule 修复（`5e9b415`/`89eda4d` 分支查验表）。
- **模型融合两档欠账**（用户暂缓）：近档 DeepSeek 文本→四元组抽取、远档 3B 图文合一。
- **独特资产**：因果引擎、哈希链账本、脱敏归因层。
- **结论**：引擎 + 归因层代码已成熟（多轮修复 + 真机实证），唯一欠账是模型融合（用户暂缓）。**建议**：引擎部分可单独 merge main（欠账表已登记），或保持分支待模型融合条件成熟。

### 4. feat/mcp-external（1 未合并）
- **MCP 化 P1 已验收入 main**（`230c1e0`，ACCEPTANCE_LOG 2026-08-03：initialize mov/3.3.0 + 无 token 401 + tools/list 59 只读 + file.write 拒绝 + 变异亲杀 isReadonly，全量 800）。
- 官方 SDK server（MovMcpServer + AndroidHttpServer 纯 Java HTTP 帧层 + StreamableTransport 官方接入），fail-closed 只读边界。
- 剩 1 未合并 commit（总自述更新 `3534c88`）。
- **结论**：P1 已完成，剩余文档 commit 可并入 main；P2 扩展（全量工具+审批闸+mov.* 查询）待派。

### 5. feat/surpass（6 docs）
- **超越计划**（`docs/PLAN_SURPASS.md`）：先立身（AI 原生个人成长伴侣）再盖楼（四支柱：健身/笔记/学习/工作），工作支柱对标 WorkBuddy（成长轨迹 vs 工作痕迹）。
- 产品对比 HTML（MOV vs Dyad/Hermes/Cindy 9 域逐点）+ 12 条行动清单。
- 无验收记录，定位定稿。
- **结论**：纯文档，README 已引用，**建议并入 main**。

### 6. 核心竞争力（7 docs）
- **核心资产库**（`docs/CORE_COMPETENCY.md`）：端侧 OCR 全链路改造（最硬核壁垒：Unlimited-OCR R-SWA patch/GGUF 转换/MNN 视觉余弦 0.9999/golden 380/380/一键验收）+ MOV 产品设计 + 架构独有机制（Journal 事件溯源、内嵌 Linux proot）+ 方法论。
- 无验收，资产盘点。
- **结论**：纯文档，README 已引用，**建议并入 main**。

### 7. feat/fullscreen-html（外部新增，未查验）
- 本地有未提交 M 文件（HtmlViewerActivity/HermesActivity），全屏查看器相关。
- 不在 2026-08-04 分支地图（外部新增），**待用户/验收人说明用途**。

## 三、整体判断与建议

**项目状态**：main 稳定线清晰（AI 原生成长伴侣定位 + 900-级测试 + 多轮验收）；多个功能分支并行，两个代码分支（dual-brain/causal）内容成熟但各有验收缺口，三个文档分支（surpass/核心竞争力/mcp 剩余）随时可并入。

**建议 merge 优先级**：
1. **feat/surpass + 核心竞争力 + mcp-external 剩余文档** → main（README 已引用，补齐链接断裂，零风险）
2. **feat/dual-brain-upgrade 批1**（Anthropic 协议，已验收 883 绿）→ main
3. **feat/dual-brain-upgrade 批2/3**（我已查验 A25-A27 886 绿）→ 真机端到端后整体 merge
4. **feat/causal-memory 引擎** → 可先 merge（模型融合欠账已登记、用户暂缓），或保持分支待融合

**待办**：真机端到端验证（dual-brain Hermes 工具/记忆链路、causal reflect 真实 DeepSeek）、W1 第三幕 117 处 inline 清理、mcp P2 全量工具+审批闸。

**环境**：平板 `21770d7d`；MOV 入站 127.0.0.1:8388；serve daemon 8387（proot 内）。
