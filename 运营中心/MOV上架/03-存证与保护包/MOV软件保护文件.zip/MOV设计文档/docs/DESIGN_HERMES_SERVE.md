# DESIGN：Hermes 服务化（常驻唤醒）— 2026-08-01 v1（草案，待审）

> 状态：**M1/M2 已实现**（2026-08-02，P2 派单 TASKS_P2_HERMES_SERVE_2026-08-01）。M1 = 9bef440（serve 骨架进部署 zip），M2 = f24d5ea（HermesClient + HeavyWorker 切路径）。联调（真机 logcat 计时 / exec 回退 / 取消）挂起，待 rootfs 恢复。

> 问题：现状 Hermes = 「每次任务 proot 冷启动一次性进程」（HeavyWorker → `hermes -z`），无常驻、无反向通道、重活启动慢、Hermes 无法推 MOV。
> 目标：Hermes 常驻服务化——MOV 懒启动它、随叫随到（无冷启动）、能双向通信（Hermes 可推进度/完成）、安全三件套平移、AgentLoop 接口不变。
> 前提：rootfs 恢复（app UI 重装）+ hermes-agent（Python 侧）可加 serve 入口。

## 一、总体架构

```
┌─ MOV（Android 进程）─────────────────────────────┐
│ AgentLoop → HeavyWorker（接口不变）→ HermesClient │
│     ↑                                    │ HTTP   │
│  UI/进度 ← BridgeAi ← EventListener ←────┘ 127.0.0.1:8387
└──────────────────────────────────────────┼───────┘
┌─ proot Ubuntu rootfs ────────────────────┼───────┐
│ hermes serve（常驻，FastAPI，127.0.0.1:8387）     │
│   ├─ POST /task      收任务（排队串行执行）        │
│   ├─ GET  /task/{id} 查状态/取结果               │
│   ├─ POST /task/{id}/cancel 取消                 │
│   └─ GET  /events    SSE 事件流（进度/完成推送）   │
│ pidfile + token 在 /exchange（bind mount 共享）   │
└──────────────────────────────────────────────────┘
```

选型说明：走 HTTP on 127.0.0.1 而非 unix socket——proot 共享网络命名空间（实证：llama-cli/relay 均通），OkHttp 客户端是现成轮子（LlamaClient 同款）；unix socket 在 OkHttp 里反而别扭。

## 二、协议（v1 最小集）

| 端点 | 请求 | 响应 |
|---|---|---|
| GET /healthz | — | {ok, version, hermes_agent_version} |
| POST /task | {instruction, constraints:{network:bool, maxTokens:int, timeoutSec:int}} | {task_id} 或 409（已有任务在跑——v1 串行） |
| GET /task/{id} | — | {status: queued/running/done/failed/cancelled, output?, error?} |
| POST /task/{id}/cancel | — | {ok} |
| GET /events | SSE | {task_id, kind: progress/done/failed, data} |
| GET /tools（阶段 3 预留） | — | MOV 注册表清单 |
| POST /tools/{name}/invoke（阶段 3 预留） | {params} | 转发 MOV 统一闸执行 |

鉴权：Header `X-Mov-Token`——token 由 MOV 生成（Secrets.tokenUrlSafe），存 EncryptedSharedPreferences，经 env 传给 daemon；daemon 每次启动从 env 读，不落地 rootfs 以外的盘。

## 三、生命周期（这是「踏实」的关键，逐条定死）

1. **懒启动**：HeavyWorker 首次调用 → healthz 不通 → `ProotRunner.startDaemon()`（nohup hermes serve &）→ 轮询 healthz（10s 上限）→ 通了才发任务。后续调用零启动成本。
2. **崩溃恢复**：每次调用前 healthz（200ms 超时，便宜）——不通按懒启动重来（pidfile 只作参考不作信任，**healthz 是唯一真相**）。
3. **空闲退出**：daemon 30min 无任务自动退出（与 llama-server 同纪律）；MOV 下次调用自然再懒启动，用户无感。
4. **升级路径**：rootfs/hermes-agent 重装（HermesInstaller 版本机制已有）→ 先 kill daemon（pidfile）→ 装 → 下次调用懒启动新版。**不许热升级**（运行中换代码是薛定谔的服务）。
5. **app 死亡**：MOV 进程死 → daemon 变孤儿——可接受（下次 app 启动 healthz 通则复用，不通则拉起新实例；端口占用冲突时按 pidfile kill 旧的再起）。
6. **看门狗免责**：不做 MOV 侧常驻 watchdog 线程——healthz-on-call 模式已够（每调用前检查），少一个常组件少一个崩点。

## 四、安全模型平移（三件套 → 服务化）

| 现状（exec 模式） | 服务化后 | 落点 |
|---|---|---|
| 指令 sanitize（危险模式拒绝） | 不变，MOV 侧发任务前做 | HeavyWorker（复用现有 sanitize） |
| 默认禁网（unset proxy） | constraints.network=false → daemon 为该任务子进程 unset proxy（每任务独立 env） | hermes serve 任务执行器 |
| 产物 canonical 回写校验 | 不变，MOV 侧收结果后做 | HeavyWorker |
| 网络面=权限面 | 绑死 127.0.0.1 + X-Mov-Token 必填 | hermes serve |
| 支付/短信等红线 | 工具白名单不变（ToolRegistry 层，与本设计正交） | 不动 |

## 五、兼容层（AgentLoop 不动）

HeavyWorker 的 WorkerResult 接口、取消语义、超时语义全部保持——内部从「exec 一次性」换成「POST /task + 轮询/SSE 等结果」。取消：取消请求发到 daemon（杀任务子进程）→ 返回 CANCELLED，与现状语义一致。超时：MOV 侧计时不变，daemon 侧 timeoutSec 双保险。

## 六、分幕实施

| 幕 | 内容 | 验收 |
|---|---|---|
| M1 | hermes serve 骨架（healthz + /task 串行执行 + token 鉴权），proot 内手动起 | curl 实证：起服/发任务/拿结果/token 错误 401 |
| M2 | HermesClient（Java，OkHttp，cbId 异步）+ HeavyWorker 切服务路径（exec 路径保留回退开关）+ 懒启动/healthz | 真机：首次调用含拉起、后续调用**无拉起延迟**（日志计时实证）；exec 回退可用 |
| M3 | /events SSE + BridgeAi 进度事件进 UI（替换轮询） | 真机：长任务进度事件实时到 UI（logcat+截图），daemon 推送→UI <1s |
| M4 | 韧性：杀 daemon 自动恢复 / 空闲 30min 退出再懒启动 / 升级重装流程 | 三项真机逐项实证 |
| M5 | 安全验收：禁网实证（daemon 内 curl 外网不通）、sanitize 拒绝实证、产物校验实证 | 逐项 logcat/脚本证据 |

> 状态标注（2026-08-02）：**M1 ✅ 已实现**（子命令 `mov-serve`，避开已占用 `serve`；Windows 侧 pytest 11 项端点契约全过 + uvicorn 冒烟 healthz/401/200；联调 curl 实证挂起，待 rootfs 恢复）。**M2 ✅ 已实现**（HermesClient 纯 JVM 核心 10 项单测 + OkHttp 实例；HeavyWorker serve 优先 + exec 回退；全量 1240 tests green；真机计时/回退/取消实证挂起）。**M3 ✅ 已实现**（/events SSE 端点，stdout 节流 progress + 终态事件，pytest +4=15 全过；HermesEventListener OkHttp SSE 订阅/重连 3 次降级轮询 + 8 项单测；HeavyWorker serve 改 SSE 主路径轮询兜底；BridgeAi 进度进房间 note；全量 1256 tests green；真机 daemon→UI <1s 计时实证挂起）。**M4 ✅ 已实现**（Python idle-exit IdleGuard + --idle-timeout + pidfile 写清 + VERSION 0.2.0；Java ensureServeUp 恢复决策可注入测 + SERVE_CMD pidfile 预杀 + logcat 恢复计时；pytest +4=19、HeavyWorkerLifecycleTest 4 项、全量 1280 tests green；真机 kill -9 恢复计时 / 空闲 60s 退出再拉起 / 重装无残留实证挂起）。

## 七、验收硬指标（写完才算踏实）

1. 后续任务启动延迟：exec 模式基线 vs serve 模式，**省掉 proot+venv 拉起段**（实测数字，预期秒级→百毫秒级）
2. 反向通道：daemon → UI 事件延迟 <1s（实测）
3. 恢复：kill -9 daemon 后下一次调用自动拉起并完成任务
4. 安全：token 错误 401；network=false 时 daemon 内出网失败实证
5. 兼容：现有 HeavyWorker 全部调用点（AgentLoop 剧本）不回归——mov-verify 剧本过

## 八、风险表

| 风险 | 缓解 |
|---|---|
| hermes-agent 无 serve 入口（Python 要新写） | M1 最小骨架先行；FastAPI/uvicorn 已在 termux constraints 生态内 |
| 串行瓶颈（v1 单任务） | 接受（现状 exec 也是串行）；并发是 v2 话题 |
| proot 进程模型意外（daemon 被杀不通知） | healthz-on-call，不信 pidfile |
| SSE 在 proot HTTP 下不稳 | M3 不达则退化为短轮询（500ms），事件语义不变 |
| rootfs 再被清 | 环境恢复流程入 OCR_PLAYBOOK 同款手册；serve 设置页有状态行 |

## 九、演进路线（用户拍板 2026-08-01：瘦身立项）

```
阶段 1（现状）   Hermes 全量独立（cli.py 745KB 等整套 vendor）
阶段 2（本设计）  hermes serve 常驻——M1-M5
阶段 3（瘦身）   一套工具表/一套记忆/一套 LLM 管道，Hermes 只留「规划器+执行循环」：
  · 工具统一：MOV ToolRegistry 经 serve /tools 端点暴露，Hermes 调用工具=回调 MOV（不自带重复实现）
  · LLM 管道收编：Hermes 推理走 MOV BridgeAi 管道（model_tools 裁掉）
  · 记忆统一：journal 唯一事件源，Hermes 读写走 serve
  · 裁剪：cli 交互界面/批处理等 termux 用不上的部分
协议预留（M2 实施时埋好，阶段 3 不返工）：
  · GET  /tools            → MOV 注册表清单（name/level/tier/params/examples）
  · POST /tools/{name}/invoke → 转发 MOV 执行（走统一闸）
```

## 十、明确不做

- 不做多实例/并发池（v1 串行）
- 不做跨设备访问（绑死 127.0.0.1，永远不暴露 LAN）
- 不做热升级、不做常驻 watchdog 线程、不引入新持久化（任务结果由 journal 已有体系记）
