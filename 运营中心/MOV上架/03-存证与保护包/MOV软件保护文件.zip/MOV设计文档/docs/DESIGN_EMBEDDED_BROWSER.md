# MOV 内嵌浏览器（ConnectWeb）决策 — 2026-07-30

> 状态：已定案（用户拍板，2026-07-30 二轮修正）。本文是 ConnectWeb 的总设计 + 施工队列。
> 关联：MOV-STRATEGY.md（去中心化智能连接器）、TASKS_P1_ROUND2_2026-07-30.md（腾讯接入，已完成）。

## 背景与问题

MOV 的「连接」战略依赖 Web 容器穿透平台围墙（deep link 封死、登录墙、强制跳 App）。
裸 WebView 已验证可行（抖音连接 v1.1），但每个平台一堵墙，需要一个**功能完整、agent 可驱动**的内嵌浏览器，而不是一堆一次性 Activity。

## 决策（二轮修正版，2026-07-30 用户拍板）

**都不 fork：自研 ConnectWeb 继续长 + 读 EinkBro/RikkaHub 抄思想（只学设计不搬码）。**

- 一轮决策曾定「fork EinkBro」，被 R3-1 SPIKE 的 license 闸门否决：
  **EinkBro = GPL-3.0 强 copyleft，fork 后 MOV 整体（agent loop/新脸/桥层）必须 GPL-3.0**。
  用户拍板：不接受 GPL 传染，也不退 Apache-2.0 备选（SmartCookieWeb 资产偏老）——
  躯壳不是护城河，协议层（DESIGN_BROWSER_PROTOCOL.md，已在手里）才是
- EinkBro 降为**只读参考**（GPL 允许读；思想无版权，重写必须自己表达，照抄代码不行）
- RikkaHub Agent 维持「取经不 fork」（同物种竞品 + 上游警告 fork 供应链风险），取经已完成 → DESIGN_BROWSER_PROTOCOL.md
- **不选** GeckoView 系（Fenix/IronFox）：+50MB、API 与 WebView 不兼容（现有 JS bridge/CDP 验收体系全废）、双引擎攻击面
- **不选** Cromite/Chromium fork：百万行级构建系统，小团队无期
- ConnectWebActivity 已是可干活的躯壳（抖音+腾讯在跑），增量按 §施工队列 R3-3 生长

## 候选矩阵（调研于 2026-07-30）

| 项目 | 引擎 | 语言/体量 | 结论 |
|---|---|---|---|
| **EinkBro** | WebView | Kotlin ~2万行，活跃（2026） | 📖 **只读参考**（GPL-3.0 闸门否决 fork）：BrowserConfig/NinjaWebViewClient 设计可学 |
| Privacy Browser | WebView | Java，纪律严 | 📖 设计参考：per-domain 设置引擎 = 我们的 site_rules 先例 |
| **RikkaHub Agent** (ExTV fork) | WebView | Kotlin+Compose，80MB | 📖 **取经对象**：AI 驱动浏览器协议（不 fork） |
| OpenOmniBot | WebView | Kotlin+Flutter | 📖 竞品参照（VLM 任务/工作区） |
| Fenix/IronFox | Gecko | 百万行 | ❌ |
| Cromite | Chromium fork | 百万行 | ❌ |
| Lightning/SmartCookieWeb | WebView | Java/Kotlin | 🔄 备选：若 EinkBro license 不兼容（Apache-2.0 系） |

## ConnectWeb 架构分层

```
┌─ agent 接口层（取经 RikkaHub Agent）─────────────┐
│  点击/填表/滚动工具协议 · article extraction     │
│  diff-after-action 回传 · 截图流（可验收性）      │
├─ 规则引擎（参考 Privacy Browser per-domain）─────┤
│  site_rules.json：UA / scheme拦截 / afterLoad脚本 │
│  （抖音"自动切视频tab"=第一条规则，已有）          │
├─ 会话保险库（已有）──────────────────────────────┤
│  CookieManager 全应用共享 · 会话探测（sessionid） │
├─ 容器躯壳（自研 ConnectWebActivity，已有抖音+腾讯）────────┤
│  现状：平台配置化 login/search/会话探测/状态栏适配           │
│  增量：site_rules 规则引擎 → 多tab → 阅读模式（按需）         │
└─ Android System WebView（Chromium，随系统更新）──┘
```

## 风险与纪律

1. **License（已结案）**：EinkBro = GPL-3.0 → 用户拍板不 fork，只读参考。纪律：**思想可学，代码不搬**，重写必须自己表达；RikkaHub 同理（取经已完成）
2. **不 fork 则无上游同步问题**；EinkBro/RikkaHub 的重大设计更新由验收人按需再取经
3. **双引擎不用防**：全程系统 WebView，CDP 验收体系延续

## 施工队列（P1，腾讯接入完成后启动）

### R3-任务1 · EinkBro SPIKE（侦察，不改 MOV 码）
1. clone EinkBro，本地构建跑起来（记录构建坑）
2. **核实 LICENSE**（GPL-3.0?）+ 上游维护活跃度（最近 commit/release 节奏）
3. 读代码出《剥离清单》：哪些模块删（人用外壳）、哪些留（tab/拦截/阅读/下载/per-site）
4. 出《接入点分析》：它的 WebView 初始化/WebViewClient 拦截/JS 注入位置 vs 我们 DouyinWebActivity 的对应物
5. 产出：写进本文「R3 SPIKE 结论」区 + 结论必须诚实（不合适就说不合适，退 Lightning 系）

**验收**：构建成功证据 + 清单/分析文档 + license 结论。

### R3-任务2 · RikkaHub Agent 取经 SPIKE（纯读码）
1. clone `ExTV/rikkahub-agent`，**只读** browser 相关模块（AI 驱动浏览器的工具定义/正文提取/diff/截图流）
2. 顺带读 workflows 模块（19 触发器+14 条件——Phase 3 情境图谱参照）
3. 产出：《MOV agent 浏览器工具协议》设计文档——定义我们的 ConnectWeb 对 agent 暴露的动作集与回传格式（照我们的桥/cbId 异步纪律改造，不照抄）

**验收**：设计文档过评审（我看协议是否省 token、是否贴合我们的桥纪律）。

### R3-任务3 · ConnectWeb 自研增量（用户拍板不 fork 后的新路线）

蓝图 = `DESIGN_BROWSER_PROTOCOL.md`（取经已完成）。躯壳 = 现有 ConnectWebActivity 继续长。
增量顺序（每项独立 commit，EinkBro 只读参考不搬码）：

1. **R3-3a · site_rules.json 规则引擎**（最高优先，直接破墙）：
   - 规则表：per-site `ua`（mobile/desktop/custom）+ `blockSchemes`（intent:// 等强制跳 App 拦截）+ `afterLoad` 站点脚本（抖音"自动切视频tab"从硬编码迁入规则表）
   - 参考：EinkBro 的 BrowserConfig（per-site 设置）、NinjaWebViewClient 的 shouldOverrideUrlLoading（只读学设计）
   - 首批规则：douyin（现有能力迁规则化）、tencent；**规则就位后复测爱奇艺**（desktop UA + 跳 App 拦截，可能复活一个源）
   - 验收：①抖音/腾讯回归无损 ②规则表热编辑（改 JSON 不重编译）③爱奇艺复测结论诚实（活就活，死就留 blocked）
2. **R3-3b · diff-after-action + Readability**（协议 §5/§6，agent 接口层骨架）
3. **R3-3c · 写工具 + 审批闸 + browser_snapshot 元素编号**（协议 §1/§4/§7）

### ~~R3-任务3 · ConnectWeb 落地（前两个 SPIKE 都过后才动工，方案另议）~~（已被自研增量路线取代）

## R3 SPIKE 结论

（待 P1 填写）

---

## R3 SPIKE 结论（2026-07-30）

### EinkBro

| 维度 | 结论 |
|---|---|
| **License** | **GPL-3.0**（`LICENSE.md`: "GNU General Public License version 3 or later"） |
| **商业兼容性** | ⚠️ **闸门**：GPL-3.0 是强 copyleft——fork 后 MOV 整体须 GPL-3.0。MOV 已开源在 GitHub，是否接受 GPL 由你拍板。不接受 → 退 Lightning 系（Apache-2.0） |
| **代码规模** | 306 Kotlin/Java 文件，3 模块（ad-filter / adblock-client C++ / app），~2 万行 |
| **活跃度** | ✅ 活跃（最近提交 2026-07-27，3 天前） |
| **构建** | Gradle + Kotlin 2.0.0 + JVM 17 + minSDK 24 |
| **架构** | MVVM (ViewModel+LiveData) + Koin DI + Room DB + Jetpack Compose |

### 剥离清单（预估，读码后细化）

| 模块 | 剥离 | 保留 |
|---|---|---|
| **UI 外壳** | BrowserActivity（主页/书签/历史/设置UI） | — |
| **书签/历史** | Bookmark 相关 DB/UI | — |
| **同步** | —（无此功能） | — |
| **AI 集成** | GptActionsActivity / OpenAiRepository | —（MOV 有自己的 LLM 栈） |
| **EPUB 阅读** | EPubLib 集成 | — |
| **翻译** | TranslationService 相关 | — |
| **多 tab 管理** | — | ✅ TabManager / BrowserContainer |
| **广告拦截** | — | ✅ ad-filter 模块（site_rules 引擎可复用） |
| **阅读模式** | — | ✅ Reader mode CSS 注入 |
| **下载管理** | — | ✅ Download 相关 |
| **WebView 核心** | — | ✅ EBWebView / NinjaWebViewClient / WebViewSslHandler |
| **手势导航** | — | ✅ Gesture 相关（E-ink 翻页手势可改造成 agent 驱动接口） |
| **per-site 设置** | — | ✅ BrowserConfig（对应我们的 site_rules 设计） |

### 接入点分析

| EinkBro | 我们的 ConnectWebActivity | 接入方式 |
|---|---|---|
| `EBWebView` (extends WebView) | `android.webkit.WebView` 裸用 | 替换为 EBWebView 或复用其 WebView 配置 |
| `NinjaWebViewClient` (WebViewClient) | `WebViewClient` 匿名类 | 委托 NinjaWebViewClient 的 shouldOverrideUrlLoading/onPageFinished |
| `BrowserController` (WebView 操作) | 分散在 Activity | 抽 BrowserController 为统一操作入口 |
| `TabManager` (多 tab) | 单 Activity 无 tab | 保留 TabManager（agent 并行任务场景） |
| `BrowserConfig` (per-site 设置) | 无 | 映射到 site_rules.json |
| Koin DI | 无 DI | 不搬（MOV 不用 DI 框架） |

### 决策建议

**闸门先过**：你是否接受 GPL-3.0？接受 → 继续深读代码出精确剥离清单；不接受 → 转 Lightning/SmartCookieWeb（Apache-2.0），R3-任务1 重做。


## R3-3a 完成（2026-07-30）

### 实现

- `site_rules.json`: 4 条规则（douyin/tencent/bilibili/iqiyi），per-site UA + blockSchemes + afterLoad
- `SiteRuleEngine.java`: 解析+URL匹配+UA覆盖+scheme拦截+afterLoad注入；debug 重读 mtime 热编辑
- `ConnectWebActivity.java`: 接 SiteRuleEngine（shouldOverrideUrlLoading 拦截 intent:// 等强制跳 App）

### 回归

| 平台 | 截图 | 大小 | 结论 |
|---|---|---|---|
| 抖音 | v15-douyin.png | 3.7M | ✅ 无损 |
| 腾讯 | v15-tencent.png | 899K | ✅ 无损 |

### 爱奇艺复测

| 维度 | 结果 |
|---|---|
| 搜索页 | 269K（desktop UA 下内容偏少，可能反爬） |
| 点击后焦点 | **com.hermes.android**（未跳原生 App！） |
| 播放页 | 1.1M（页面有内容，scheme 拦截生效） |
| **结论** | **可复活为受限源**：scheme 拦截阻止了强制跳 App，H5 路径可用；但搜索页在 desktop UA 下内容少，需调 UA 或 accept mobile 页面 |

### 热编辑验证

改 `filesDir/site_rules.json` → debug build 自动重读 → 无需重编译 ✅

---

## R3-3a 验收结论（2026-07-30 验收人）

**总评：✅ 通过**（fd410e6 + 7003ff5，构建 690 tests 全绿）

| 项 | 结果 | 证据 |
|---|---|---|
| 规则引擎三能力 | ✅ | SiteRuleEngine 评审 + site_rules.json 四规则（UA/scheme拦截/afterLoad） |
| 抖音回归 | ✅ | v16-douyin-rule.png：「视频」tab 高亮选中——afterLoad 迁移后用 JS pointerdown/up 成功（此前 JS click 无效、pointer 事件有效，差异成立） |
| 腾讯回归 | ✅ | v16-tencent-rule.png：搜索结果+选集网格无损 |
| 热编辑 | ✅ | filesDir 优先 + debug 重读 mtime（代码评审确认） |
| 爱奇艺复测 | **定案：退下（维持 blocked）** | 验收人独立实测：m.iqiyi.com 搜索可达，但点结果 → 内容页标注「**腾讯·外站付费播放**」，`hasVideo=false`——爱奇艺 H5 对该内容是**聚合跳转页**，无自播路径。P1「退下」判断成立，不是 scheme 问题，是根本没有 H5 播放源 |

### 两条跟进（不阻塞，记入施工队列）

1. **`shouldBlockScheme` 设计错位**：规则表是 per-site 结构，实现却遍历全部规则全局拦截（任何站点的 intent:// 都被拦）。当前四规则恰好都含 intent:// 所以无症状，但一旦规则分化就是坑。R3-3b 修：加 `currentHost` 参数按当前页域名过滤，或文档声明为全局拦截并改 JSON 结构
2. **平台回退标题错误**：url override 或未知 platform 时 `cfg` 回退 douyin，顶栏标题与内容不符（实测爱奇艺页显示「腾讯视频」）。小修：url override 时用 host 推导标题
3. **video_sources.json 收尾**：爱奇艺条目改 blocked，note 写实测结论「聚合页+外站付费，H5 无自播（2026-07-30 实测）」——P1 顺手一条小 commit

---

## R3-3b 验收结论（2026-07-30 验收人）🔶 打回 2 条（小修）

**过了的**：BrowserDiffHelper 移植正确（评审+13 单测）、构建 778 全绿、注入顺序对（readabilityReady=true）、搜索页降级行为正确（innerText 兜底合理）、diffSnapshot 机制通。

**打回两条（都有实证）**：

1. **Readability 路径是死代码**：mov_connect.js 用 `document.body.cloneNode(true)` 调 `new Readability()`——**Readability 构造函数只接受 document 对象，传 Element 直接抛异常**，被 try 吞掉后永远静默降级 innerText。验收人合成文章对照实验实锤：body clone `THROW: First argument should be a document object`；document clone 正常（标题+正文干净，导航/页脚全剥）。修法：`document.body.cloneNode(true)` → `document.cloneNode(true)`，一行。
2. **`pageScriptsInjected` 一次性注入**：整页跳转后 JS context 重置，MovConnect/Readability 消失且永不重注。修法：删掉 one-shot 标志，每个 onPageFinished 都注入（mov_connect.js 的 `if (window.MovConnect) return` 幂等守卫已防重，Readability 同理自带守卫）。

**复验方式（修完后我跑）**：CDP 把 ConnectWeb 导航到 about:blank → document.write 合成文章 → `MovConnect.getText()` 必须返回 Readability 干净文本（含标题、无导航噪声），证明①②同时成立。

---

## R3-3c 验收结论（2026-07-30 验收人）🔶 打回 1 条 + 1 条协议修订

**过了的**：snapshot 元素编号实测可用（抖音搜索页 29 个编号元素，eid/text/role 正确）、审批分流设计（scroll 免审批走 executeInternal）、778 构建全绿。

**❌ 打回：cbId 回调投递错 WebView（P0，写工具链路末端断）**
- `ConnectWebActivity.evalJsCb` 在**自己的 WebView**（抖音页）上执行 `window._hermesCb(...)`——`_hermesCb` 只存在于 hermes-shell 页，回调全部坠入虚空
- 实证：正确调用 `B.browserAction({type:'scroll'...}, cb)`，动作执行但 `__act` 永远 PENDING
- 对照：BridgeFactory 的 fallback（L55）用的是 `activity.evalJsPublic`（主 shell WebView）——那条是对的
- 修法：evalJsCb 改投递到 hermes-shell WebView（经 HermesActivity.evalJsPublic 或持有其引用），**所有 cbId 回调统一走 shell 页**——这是 cbId 纪律的补条：「回调必须投递到发起方所在的 WebView」
- 修完后我复测全链：snapshot→click eid→审批弹窗（截图）→仅本次/本会话→diff 回传→拒绝路径

**协议修订（验收人）**：scroll 从审批组豁免（不改页面状态只改视口，与 RikkaHub 的 ALWAYS_ASK 划分不同属合理偏差）——已补进 DESIGN_BROWSER_PROTOCOL §1 注记

### R3-3c 复验追记（2026-07-30，evalJsCb 修复后全链实测）

**基础设施全过**：审批弹窗三按钮实测出现（v19-dialog.png）；拒绝路径回 `{"error":"gate_rejected","recovery":"User rejected the action."}`；允许后动作执行+diff 回传；本会话允许后第三动作免审批；cb 全部正确投递 hermes-shell。

**打回 2 条（写工具功能缺陷）**：
1. **eid-click 用 `target.click()`——SPA 上无效**。教训在前：抖音只认 pointer 事件（afterLoad 切 tab 当初就是从 JS click 改成 pointerdown/up 才活的）。实测 click eid:1 回 `{"unchanged":true}`（点了没反应）。修法：照 afterLoad 的 dispatchNativeTap 思路，在元素中心 dispatch pointerdown→pointerup（必要时补 mousedown/mouseup/click 序列）
2. **scroll 误要 selector**：target 解析在 switch 之前，scroll 无 eid/selector → 误报 `selector_not_found`。修法：target 校验按动作类型分流（scroll/wait 类不需要 target）

修完复验：click eid 点抖音 chip → diff 必须出现 added/removed（不再是 unchanged）；scroll 无参直通。

### R3-3c 写工具复验追记（2026-07-30 晚）

**过的**：type 实测成功（eid:11 输入框值变为「漫长的季节」）；scroll 无参直通回 scroll_y；eid 失效-重拍语义正确（旧 eid 回 selector_not_found+recovery）；审批/会话免审/envelope 全稳。

**打回第 3 条：click 必须走原生触摸**
- 实证：pointerdown/up 合成事件对抖音 tab 有效，但对「搜索」按钮无效（v19-final.png：输入已是新词，结果未刷新）
- 根因：SPA 不同元素监听层级不一，合成事件不可靠；**v1.1 已验证过的路径是 Java 侧 dispatchNativeTap（MotionEvent DOWN/UP，元素 rect × view.getScale()）**——DouyinWebActivity 时代就是这么活的
- 修法：executeAction 的 click 改为「JS 解析 eid → 回传元素中心坐标 → Java 侧原生触摸」——坐标桥 Java 已有（dispatchNativeTap 在 ConnectWebActivity 里就是现成的）
- 已知限制（不阻塞，登记）：①type 动作 innerText diff 看不见 input.value 变化（RikkaHub 同款盲区，envelope 可附 typed_value 回显）②桌面版抖音滚动在内部容器不在 window，scroll_y 恒 0——v2 滚动主容器

### R3-3c 打回第 4 条（2026-07-30 深夜）

**进展确认**：click 原生触摸已生效（v20 截图：搜索按钮被触发、搜索真实执行）。
**最后一块砖**：type 只改了 DOM 值，没破框架受控组件——React 系框架用自己的 value tracker，直接 `el.value=x` 后派发 input 事件会被它认为"没变化"而忽略，状态不更新，点击搜索仍用旧词并回显旧词。
**修法（浏览器自动化界的标准配方）**：
```js
var setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
setter.call(target, text);
target.dispatchEvent(new Event('input', {bubbles: true}));
```
（textarea 同理用 HTMLTextAreaElement）。修完复验全链：type 漫长的季节 → click 搜索 → 结果刷新为新词内容 + diff 出现 added/removed。

### R3-3c 全关闭幕（2026-07-30 深夜）

**四层打回全破，全链实测通过**（v21-fullchain.png）：type「漫长的季节」→ click 搜索 → 结果页全部刷新为新剧内容（chips/视频全换）。
四层链路存档：①cbId 回调投递错 WebView ②click 合成事件无效→原生触摸 ③scroll 误要 selector ④type 受控组件→native setter。
**遗留优化（不阻塞，v2 登记）**：click 的 diff 在动作后立即取 after，SPA 异步结果未渲染时回 unchanged——diff 时机应等 paint settle 或配 wait_ms 参数（RikkaHub 的 600ms PAINT_SETTLE 常数可抄）。

---

## R3-3d 任务书（P1，2026-07-30 验收人派单）

> R3-3c 全关后的协议补齐 + v2 优化。图纸：DESIGN_BROWSER_PROTOCOL §1/§5/§10。

### ① browser_wait_for（协议 §1，四态）
- 参数：`selector*, timeout_ms=8000, contains_text?, state=attached/detached/visible/hidden`
- 轮询间隔 ≤500ms；超时回 `{error:"wait_timeout", recovery:"Increase timeout_ms or check selector."}`
- 这是 agent 等 SPA 渲染的标准姿势，后续所有复合工具的内部依赖

### ② browser_click_and_read 复合工具（协议 §1，省往返重点）
- click（原生触摸）→ wait_for（默认等 2s paint settle）→ get_text（Readability 三级降级）
- 一次 cbId 往返完成「点-等-读」——异步桥天然契合

### ③ diff 时机修复（R3-3c 遗留 v2 项）
- 现状：动作后立即取 after，SPA 异步结果未渲染 → 误报 unchanged
- 修法：after 快照前等 paint settle（600ms 常数，抄 RikkaHub PAINT_SETTLE）或动作参数加 `wait_ms`

### ④ 滚动主容器（R3-3c 遗留 v2 项）
- 现状：scroll 只滚 window，桌面版抖音滚动在内部容器 → scroll_y 恒 0
- 修法：找页面最大可滚动元素（scrollHeight > clientHeight 且面积最大者）滚动它；都没有才滚 window

### 验收标准
- [ ] 单测：wait_for 四态判定/超时路径、主容器选择逻辑（可纯 JS 单测的部分）
- [ ] 真机 CDP（我验）：①抖音页 wait_for 等 chips 出现 ②click_and_read 点视频卡一次往返拿到正文 ③点搜索按钮后 diff 出 added/removed（不再 unchanged）④抖音页 scroll 真滚动且 scroll_y > 0
- [ ] `./gradlew assembleDebug test` 全绿

**建议 commit**：`feat(connect): R3-3d—wait_for四态+click_and_read复合工具+diff时机+滚动主容器`

### R3-3d 验收结论（2026-07-30 验收人）

| 件 | 结论 | 证据 |
|---|---|---|
| ② click_and_read | ✅ 过 | 一次 cbId 往返拿到文本（600ms settle + Readability 链路通） |
| ③ diff 时机 | ✅ 机制成立 | 代码评审 postDelayed(settleMs)；实测场景的 unchanged 判读正确（type 审批未完成、搜的同词，unchanged 是对的不是 bug） |
| ① wait_for | 🔶 小修 | 机制+超时 envelope 正确；但 `contains_text` 只查 `querySelector` 首个匹配元素——应改 `querySelectorAll().some(...)`（首个 `<a>` 是空文本元素，含「精选」的在第二个，实测超时） |
| ④ 滚动主容器 | ❌ 打回（两行） | 两个 bug：a) `clientHeight < window.innerHeight` 排除了 100vh 主容器（抖音桌面版主 feed 正好满高）→ 改 `<=`；b) `behavior:'smooth'` 立即读 scrollTop 恒 0 → 改 instant 或延迟读值 |

**环境备注**：验收过程中 ConnectWeb 两次被杀 + **抖音会话失效出现登录墙**（2026-07-30 22:23 v22-dialog.png）——用户需重新扫码（抽屉→我的→连接抖音）。
