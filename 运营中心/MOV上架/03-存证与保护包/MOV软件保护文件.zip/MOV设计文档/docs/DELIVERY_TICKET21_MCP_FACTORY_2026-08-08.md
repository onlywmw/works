# 工单21 交付说明 — MCP 工厂（带质检的工具生产线）

> 派单：`docs/TASKS_P2_MCP_FACTORY_2026-08-07.md`
> 施工：P2 线（main + feat/mcp-factory 分支工件）｜状态：待验收

## 一、交付内容（三幕）

### 幕一：单品种试点（证明产线通）— pb.* 五件合入 main
- **cherry-pick a97f8471**：PbToolProvider（388 行）+ PbToolProviderTest（9/9+变异亲杀）+ 注册点（ToolRegistry + HermesApplication init）
- **8389 MCP 真实调用实证**（真机）：
  - initialize 握手：`{"protocolVersion":"2025-06-18","serverInfo":{"name":"mov","version":"3.3.0"}}`
  - tools/list → pb.query（只读闸：动作工具被过滤，符合只读 MCP）
  - pb.start（8388）→ superuser 就绪 port 8090
  - **tools/call pb.query → totalItems=2 真实数据读回**（中文 UTF-8 无损）
  - 错误信封：PB 未启动 → `{"ok":false,"error":{"code":"PB_IO",...}}`（不崩不吞）
- 证据：act1-8389-evidence.txt

### 幕二：查验自动化（坏拒收/好出厂）
- **`check-report.js`**：机器可跑红线检查（错误信封/每个 catch 必须 return/分级闸/协议合规/红线域 payment·sms·contacts·call_log/明文密钥脱敏）
- **验证**：好工具（PbToolProvider）8 项全过 **pass**；吞错变异 → **reject**（catch 吞错检出）；risk 变异 → **reject**
- **verify 模式**：复核 RPT-20260807-010 → 10 项证据全在案 ok=true
- 工厂工件同步 main：schema×4（Requirement/CheckReport/CapabilitySpec/RegistryEntry）+ redlines.json + DRIVER.md + 首品种报告

### 幕三：组合实证（说明书自动合成 + 组合调用）
- **`compose-spec.js`**：组合能力说明书自动合成（provides 语义保留、input/output/deps/errors 合并、auth 取严、`_composition:{synthesized:true}`）
- **组合调用真实闭环**：pb.create 写入「买牛奶·组合实证」→ pb.query 8389 读回（totalItems 2→3）
- 组合说明书落盘：`registry/specs/pb.query+pb.create.combo.json`

## 二、验收对照

| # | 验收标准 | 自验结果 |
|---|---|---|
| 1 | 幕一：需求→8389 真实调用全链 | ✅ pb.* 合 main → 装机 → initialize/tools/list/tools/call 全链证据 |
| 2 | 幕二：坏工具拒收/修好出厂 + 报告抽验 | ✅ 吞错/risk 变异 reject；好工具 pass；verify RPT ok |
| 3 | 组合：说明书自动合成 + 组合调用真实成功 | ✅ compose-spec 合成 + create→query 闭环 |
| 4 | 出厂工具单测+变异亲杀入仓 | ✅ PbToolProviderTest 9/9 + 变异亲杀（分支报告在案） |
| 5 | 协议合规：无 SSE/Roots/Sampling/Logging | ✅ grep 零命中 |
| 6 | 全量绿 | ⏳ 全量跑完待确认 |

## 三、风险与遗留

- 8389 只读模式（动作工具被闸过滤）——pb.create/update/auth 只走 8388 写通道；如需 8389 写需 enableWrite 开关
- MCP server capabilities 声明含 logging（server 自身通知机制，非工具原语——验收 5 针对出厂件工具，grep 零命中已过；如需严格可后续关）
- 组合说明书 errors 去重按字符串（PB_IO 两种文案各留一条）——后续可归一
- 工厂编排器（inbox 监听/模板生成器）为 DRIVER 自动化路线远期项，未在本单（幕二已提供可跑检查器）
