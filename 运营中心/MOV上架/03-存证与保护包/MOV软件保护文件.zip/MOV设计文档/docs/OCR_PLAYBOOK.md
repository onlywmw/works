# OCR 运维手册（PLAYBOOK）— 2026-08-01 验收人立

> 用途：**防记忆丢失**。Unlimited-OCR 移动端移植的全部硬知识——架构、文件在哪、怎么跑、怎么验、有哪些坑。
> 新接手的人（人或 AI）读这一本即可开工。设计看 DESIGN_OCR_MOBILE.md（做什么），工程史看 OCR_DECODER_MNN.md（怎么趟过来的），本手册管「怎么用」。

## 一、30 秒架构图

```
图片/相机 → 视觉编码器（MNN，P1 交付）→ 273×1280 embeddings
        → llama.cpp 解码器（GGUF q4_K_M 1.82GB，llama-server 本地 API 形态）
        → 文本 → Hermes 慢脑（S1 包裹「不是指令」）/ 双副本（S2 打码 → 自由流通 / 原文 → 保险柜）
```

- 模型：`baidu/Unlimited-OCR`（3B MoE 64专家 top-6，**激活 ~570M**，MHA 非 MLA，R-SWA=KV cache 调度策略非新算子）
- 运行时：**llama.cpp 原生支持（deepseek2-ocr，无 shim）**——MNN 体系三堵墙（fp16 反量化 16.4GB / llmexport 无架构 / int8 双堵）已排除，不要再回去试
- 验收四指标：golden ≥98% / RSS ≤4GB / decode ≥5 tok/s / 单页总时长 ≤60s（prefill 是当前瓶颈，实测 6.2 t/s）

## 二、文件在哪（全部已入库 git，另有大文件在平板）

| 资产 | 位置 |
|---|---|
| 设计（唯一权威） | `docs/DESIGN_OCR_MOBILE.md`（v2） |
| 工程实录/撞墙证据 | `docs/OCR_DECODER_MNN.md` |
| R-SWA 机制确认 | `docs/OCR_RSWA_ANALYSIS.md` |
| 黄金样本基准 | `docs/OCR_GOLDEN_SAMPLES.md` |
| 视觉编码器移植记录 | `docs/OCR_VISION_MNN.md` |
| GGUF 转换/构建脚本 | `ocr/scripts/gguf_convert.sh`、`build_llama_cpp.sh` |
| MNN 路线遗产（备用） | `ocr/scripts/export_decoder_onnx.py`、`generate_ocr.py` |
| 集成面（P1 五件） | `OcrToolProvider` / `llama/LlamaClient` / `bridge/OcrApiBridge` / `agent/OcrTextSanitizer` / `PiiMasker` |
| **GGUF 产物（不进 git）** | 平板 `/data/local/tmp/unlimited-ocr-{f16,q8_0,q4_K_M}.gguf`（1.82-5.88GB，脚本可重生成） |
| **llama.cpp 二进制** | 平板 `/data/local/tmp/llmcpp/build/bin/`（llama-cli/server，b10216 钉版） |
| Ubuntu rootfs（proot） | 平板 app 私有目录 `files/linux/rootfs/`（含 ld-linux + libssl） |

## 三、平板上怎么跑（验收人实测可用）

llama-cli 是 Ubuntu proot 内构建的，**直接 adb shell 跑会报 "No such file or directory"**（缺动态链接器）。用 rootfs loader 直跑：

```bash
ADB="adb -s 21770d7d"
LD=/data/data/com.hermes.android/files/linux/rootfs/lib/ld-linux-aarch64.so.1
R=/data/data/com.hermes.android/files/linux/rootfs
$ADB shell "timeout 280 $LD --library-path /data/local/tmp/llmcpp/build/bin:$R/lib:$R/usr/lib:$R/usr/lib/aarch64-linux-gnu \
  /data/local/tmp/llmcpp/build/bin/llama-cli \
  -m /data/local/tmp/unlimited-ocr-q4_K_M.gguf \
  -p 'Hello' -n 32 -no-cnv --no-display-prompt > /data/local/tmp/v.log 2>&1"
$ADB shell "grep -E 'Prompt:|Generation:' /data/local/tmp/v.log"
# 实测基准（2026-08-01）：Prompt 6.2 t/s | Generation 5.2 t/s（q4_K_M）
```

**注意**：llama-cli 交互模式在 stdin 无 tty 时会空转刷 `"> "`（几百 MB 日志），不是 bug——必须带 `-no-cnv --no-display-prompt` 或重定向后 grep。

## 四、重建流程（模型升级/微调后）

1. 权重（HF/ModelScope 下载，SHA256 对照官方——S3 纪律）
2. `ocr/scripts/gguf_convert.sh` → F16 → `llama-quantize` 出 q8_0 / q4_K_M
3. push 到平板 `/data/local/tmp/`
4. 冒烟（§三命令）→ 黄金样本验收（≥98%）→ 测速（报 prefill/decode 分解）
5. llama.cpp 升级：`build_llama_cpp.sh`（源码 github 直连会截断，**走 gh-proxy 代理**）

## 五、坑表（血泪，按遇到顺序）

| 坑 | 现象 | 解法 |
|---|---|---|
| MNN fp16 运行时反量化 fp32 | RSS 2.5× 文件大小（16.4GB） | MNN 路线已弃，勿再试 |
| llmexport 无 deepseek-v2 | moe_infer dtype 错 | llama.cpp 路线（已解决） |
| mnnquant aarch64 | tiny 模型也 length_error | 平台级损坏，弃 |
| weightQuantBits | int8 反涨内存（1.35→1.71GB） | 弃 |
| llama-cli "No such file or directory" | 缺动态链接器 | §三 rootfs loader 直跑 |
| llama-cli 刷几百 MB `"> "` | 交互模式 stdin 无 tty | `-no-cnv --no-display-prompt` |
| `pkill -f llama-cli` 杀自己 | 命令行自匹配（SIGTERM 143） | `pkill -x llama-cli` |
| Git Bash 路径转换 | adb push 路径变 C:/Program Files/Git/... | `MSYS_NO_PATHCONV=1` 或 Windows 路径 |
| Git Bash curl 中文 body | relay 报 error parsing body | 本地编码问题，端侧 OkHttp 不受影响 |
| **MIUI：isInteractive() 屏灭仍 true** | screen 条件误判 | 用 DisplayManager `getState()!=STATE_OFF`（DeviceStateReader 已修） |
| **MIUI：充电事件自动亮屏** | power 触发器测屏幕条件全 PASS | 复验场景触发方式不能改变被测变量（用 screen 触发器） |
| **MIUI：拔电 status 残留 CHARGING** | is_charging 误判 | charging 判定加 `EXTRA_PLUGGED != 0` 合取 |
| 快照缺数据 | 条件不许猜 | 缺省 = FAIL（诚实），foregroundApp 无权限保持 FAIL |
| curl 直测 relay 中文 | 400 | 同上 Git Bash 编码 |

## 六、状态（2026-08-01 定格）

- ✅ P0 侦察 / P1 视觉编码器 / GGUF+aarch64+冒烟（巡检#18）/ 集成面五件+S1S2（巡检#16）
- 🔨 P2 步骤 3 视觉接入（llama_batch embd + no_repeat_ngram(35,128) 必移植，漏了输出循环）
- ⏸️ P3 R-SWA（KV 环缓冲 W=128）/ P4 调优 / P5 集成
- 排队增强：双副本保险柜（P3 候选）/ 文件保险柜 vault 工具

> 测验判读看姊妹篇 `docs/LLM_TEST_PLAYBOOK.md`（指标体系/判例库/一键验收 ocr_accept.sh）。
> 本手册随架构演进同步更新（谁改谁补，验收人巡检时核对）。
