# TASKS_CODEGRAPH_LITE — CodeGraph 轻量版进 MOV（改前影响分析）策划（2026-08-07）

> 派单方：查验员｜来源：TencentDB Agent Memory 调研借鉴点（官方 CodeGraph 模块致谢的外部项目同思路）
> 用户指令：「CodeGraph 轻量版怎么进 MOV，出个策划」

## 一、解决什么痛（实证在案）

MOV 自己的施工已经反复踩「不知道改动影响面」的坑：
- 设置页重做时 `expertPreviewOverlay` 懒建位置没人知道 → 左侧栏删除假死（三层根因修了三次）
- 「删函数前先 grep 确认调用方为零」是手写纪律——人肉 grep，漏了就出事故
- 工厂量产后，工具进表/改表的影响面只会更难人肉

**一句话：改代码前，先知道「动了它会震到谁」。**

## 二、形态定案：引用图，不是 AST

| 方案 | 判定 |
|---|---|
| 真 CodeGraph（Tree-sitter AST/调用图） | ❌ 重——端侧跑不动，PC 端也不必 |
| **轻量引用图（本策划）** | ✅ 词法级：符号表（类/函数定义点）+ 引用边（文件 X 提到了符号 Y）+ 反向 BFS = 影响路径 |

放弃精确调用分析，拿「谁在引用」的保守超集——影响分析场景里，误报可忍、漏报不可忍。

## 三、数据模型（最小集）

```
symbols:  (name, kind[class|func|const], file, line)
refs:     (fromFile, symbolName, line)     -- 词法扫描「出现即引用」
impactOf(symbol) = 反向 BFS(refs) 逐跳列文件:行号
```

三个查询面（MVP 就这三个）：
1. `refs <symbol>` —— 谁在用
2. `impact <file|symbol>` —— 改动影响面（反向可达文件清单，按跳数分层）
3. `dead <symbol>` —— 调用方为零检查（grep 纪律的机器化）

## 四、两步走

### 幕一：PC 端先行（服务工厂与施工）
- 形态：`mcp-factory/` 下一个 Node/Python 脚本（`codegraph.js scan <dir>` → SQLite/JSON 索引；`impact <symbol>` 查询）
- 覆盖语言：Java + JS（MOV 全部代码面）
- **接入点**：工厂质检环节 + 程序员施工自查——改 MOV 代码前先跑 `impact`
- **实证验收（在 MOV-APP 真仓库上）**：
  - `impact expertConfirm` → 必须列出 newface.js 内全部调用点 + 历史删除链路（已知答案，可判分）
  - `dead <某死函数>` → 与人工 grep 结果一致
  - 漏报率抽查：随机 5 个符号，机器结果 ⊇ 人工 grep 结果

### 幕二：端侧工具（可选，后议）
- `code.impact` 工具进 ToolRegistry（纯 JVM 词法扫描房间项目/自身源码包）
- 面向：AI 在房间里改用户项目（HTML→APK 工程）前自查影响面
- 启动条件：幕一在 PC 证明有用再说，不提前建

## 五、施工约束

- 零重型依赖（不引 Tree-sitter/编译器）；单测零网络
- 索引可重建（删了重扫即可），不进 journal（不是用户记忆，是工程索引——铁律③不适用于它，但也不要污染房间）
- 厂律沿用：证据链 + 变异亲杀（引用边漏建 → 影响面测试必须红）

## 六、验收标准（查验员执行）

1. MOV-APP 真仓库实证三查询（refs/impact/dead），已知答案判分
2. 漏报抽查 5 符号全过
3. 索引 2 分钟内建成（MOV-APP 全仓）+ 增量重建正确
4. 全量绿 + 变异亲杀记录
