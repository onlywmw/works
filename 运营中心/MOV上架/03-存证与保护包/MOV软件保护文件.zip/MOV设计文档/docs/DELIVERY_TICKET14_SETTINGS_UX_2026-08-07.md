# 工单14 交付说明 — 设置页用户视角重做

> 派单：`docs/TASKS_P1_SETTINGS_UX_REDO_2026-08-07.md`（231b98e）
> 设计定稿：`docs/mockups/settings-redesign-2026-08-07.html`（用户拍板 demo v3）
> 施工：P1 线｜状态：待验收｜commit：见 git log（本说明随 commit 提交）

## 一、交付内容

**只动了 `app/src/main/assets/js/newface.js` + `app/src/main/assets/css/newface.css`，桥接口零新增**（验收标准 3 前提满足）。

### 一级页（全屏，不再是抽屉）
```
本地用户（头像行 M）
外观              浅色 ›
AI 模型        DeepSeek ›
保险柜               ›
清除对话记录（红字）
检查更新        v3.3.0 ›
意见反馈               ›
高级 ▸（默认收起：理解方式/设备协作/快捷场景/权限与功能/服务连接/系统）
```
- 宿主：`#settingsPane` 全屏容器 JS 懒建挂 `#view-face`（仿 `ensureExpertOverlay` 模式），z-index 9（低于确认 sheet overlay 12，确认弹层不被盖）
- 抽屉（`#faceDrawer`）只留历史/我的；`openDrawer('settings')` 分支退役
- 导航：`settingsGo/settingsBack` 栈式二级页，一级页 ‹ 关闭

### 二级页（10 个，每页只干一件事）
| 入口 | 内容 | 数据源（复用现有桥） |
|---|---|---|
| 外观 | 浅色/深色/跟随系统 打勾单选 | `mov_theme` = light/dark/auto（新增三态，applyTheme 用 matchMedia） |
| AI 模型 | 模型卡（测连接/编辑/设为默认/删除）+ 添加模型 + 本月用量条 + OCR 本地模型底部 | listModels/tokenStats/providerPresets/addModel/updateModel/deleteModel/testModel/setDefaultModel/listLocalModels |
| 保险柜 | 状态 + 解锁查看 + 条目列表 + 数据说明 | vaultList/vaultUnlock/vaultDelete（P5 原样迁入） |
| 意见反馈 | 输入框 + 附带诊断日志开关 + 提交 | 提交附日志时走 `diagnostics.export`（技术区块诊断导出迁此） |
| 理解方式 | 更准/更快 单选，各带代价说明 | `mv:routing`（原意图路由，文案重做） |
| 设备协作 | 状态 + 连接另一台设备（配对码）+ 已配对列表 + Relay 服务器 | a2aPairRequest/a2aPeers/a2aGetRelay/a2aSetRelay（原 A2A 区块） |
| 快捷场景 | FAST 卡清单 + 视频源开关收编底部 | tool_manifest（level=FAST）+ video_sources |
| 权限与功能 | 待开启组（每行带用途）+ 已开启组 + 功能健康行 + 工具组 | permState/openAppSettings/health/tool_manifest |
| 服务连接 | 点名服务行（未登录/已连接）+ 清除登态 | web_sites/connectStatus/removeCookies |
| 系统 | 终端 + Linux 环境 + Hermes 服务 + MCP + SSH + 导出诊断 + 清理残留房间 + 重置系统 | openTerminal/linuxStatus/hermesStatus/mcp.set/mcp.test/getDeployConfig/saveDeployConfig/testDeployConnection/diagnostics.export/diagnostics.clear/rooms.orphan/rooms.cleanup/resetSystem |

## 二、施工决策（派单「施工定并注明」项）

1. **本地模型（OCR）→ AI 模型二级页底部**（派单二选一）。理由：用户找「模型」会去 AI 模型页；OCR 模型属模型资产。
2. **清空（观看历史/追剧记忆）→ 一级「清除对话记录」确认 sheet 内并列选项**（派单二选一）。点「清除对话记录」弹 sheet：清空观看历史 / 清空追剧记忆 / 清空全部对话记录（遍历 face_history 房间逐个 `room_destroy`）。
3. **视频源开关 → 快捷场景页底部收编**（原场景卡区块内容，不丢功能）。
4. **Relay 服务器 → 设备协作页**（原 A2A 区块内容，迁移映射「A2A→设备协作」）。
5. **版本号展示 → JS 常量 `MOV_APP_VERSION='3.3.0'`**（与 `app/build.gradle` versionName 同步）。桥接口零新增约束下无版本查询桥，检查更新行仅展示 + toast「已是最新版本」，无网络更新逻辑。
6. **外观三态**：`mov_theme` 由两态扩为 light/dark/auto，`toggleTheme` 保留兼容（dark↔light 切换）。

## 三、验收对照

| # | 验收标准 | 自验结果 |
|---|---|---|
| 1 | 真机截图对照 demo | ⏳ 待真机（无平板接入本次施工环境） |
| 2 | 术语 grep 清零（注释除外） | ✅ 设置区非注释代码 `大脑|意图路由|场景卡|A2A|TOKEN` 零命中；测试断言 ③ 固化 |
| 3 | 迁移映射逐项 grep 在案 | ✅ newface-settings.test.js 断言 ④（15+ 项调用点） |
| 4 | 新人路径回归（装→配模型→派活） | ⏳ 待真机；配模型全链路在 AI 模型二级页内（listModels→addModel→setDefaultModel） |
| 5 | 全量绿 + 变异亲杀 | ✅ `assembleDebug test` BUILD SUCCESSFUL，**2210 tests, 0 failures, 0 errors**（debug+release 各 1105）；9 个 JS 测试全 PASS；变异亲杀 3 连（一级页行名/删除模型确认闸/术语混入）均红→还原绿 |
| 6 | 外观切换/清除确认/保险柜闸 真机各一次 | ⏳ 待真机 |

## 四、变异亲杀记录（验收标准 5）

| 变异 | 注入 | 结果 | 还原 |
|---|---|---|---|
| V1 | 一级页「AI 模型」→「大脑」 | 测试红（① 结构断言） | 绿 |
| V2 | `_mdelete` 删除 expertConfirm 调用（恒空） | 测试红（⑤ 确认闸断言） | 绿 |
| V3 | 高级入口「理解方式」→「意图路由」 | 测试红（③ 术语断言拦截） | 绿 |

## 五、风险与遗留

- 检查更新无真实更新检查（demo 语义：展示版本号），如需联网检查需放行桥接口（本工单零新增约束）
- 意见反馈提交为本地行为（导出诊断日志 + toast），无后端上报通道
- 真机项（验收 1/4/6）需平板 21770d7d 接入后执行，证据链按 DEVICE_ACCEPTANCE 补
