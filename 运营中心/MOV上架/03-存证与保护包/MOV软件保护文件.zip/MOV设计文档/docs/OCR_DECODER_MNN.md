# MoE 解码器 MNN 移植（P2）状态 — 内存墙阻塞

> 状态：⚠️ P2 进行中，被**内存墙**阻塞（fp16 MNN 运行时 ~16.4GB，超出平板 9GB 与 Windows 可用内存）
> 日期：2026-08-01
> 依据：docs/DESIGN_OCR_MOBILE.md P2

## 1. 已完成（可复用）

### 1.1 解码器 ONNX 导出（fp16, 6 片 × 2 层）
- **架构**：DeepSeek-V2-MoE（12 层，第 0 层 dense + 1-11 MoE，MHA 非 MLA，topk=6 贪婪路由），hidden 1280，vocab 129280
- **单图 KV-cache 导出**（`ocr/scripts/export_decoder_onnx.py`）：
  - 输入：`inputs_embeds(1,q,1280) position_ids(1,q) past_key(6,10,M,128) past_value mask(1,1,q,M) cache_len()`
  - 输出：`logits_last new_key new_value new_cache_len`
  - 单图同时处理 prefill(q=S) 与 decode(q=1)，q 为动态轴
- **MoE 可导出形式**：全专家 einsum（Wg/Wu/Wd 堆叠为 (64,*,*) 常量）+ TopK gather——静态图无法动态选专家，64× 冗余但**数值正确**
- **fp16 而非 fp32**：fp32 导出 MoE 权重 9.7GB 超平板内存；bf16 在 MNN 有 bug（溢出）；**fp16 与 MNN 兼容且 MNN 实测 diff 0.001**
- **切 6 片**：完整解码器 ONNX→MNN 转换在 optimize 阶段内存崩；2 层/片可转换（segfault 在转换成功后退出清理，产物有效）

### 1.2 MNN 转换（`--fp16`）
| 片 | 层 | 文件 | fp16 大小 |
|---|---|---|---|
| piece_0 | 0-1 (dense+MoE) | piece_0.mnn | 533MB |
| piece_2/4/6/8 | 2-9 (MoE) | piece_*.mnn | 935MB each |
| piece_10 | 10-11+lm_head | piece_10.mnn | 1267MB |

### 1.3 生成循环（`ocr/scripts/generate_ocr.py`）
- 链路：vision(273×1280) → 拼 inputs_embeds(文本 embed.mnn) → 6 片解码器（MNN Module API）→ no_repeat_ngram → 贪心
- **Module API**（非 Interpreter）：动态形状 + cache_len 标量输入需 Module API（Interpreter 报 "shape compute need input content"）
- **prefill 已验证**：golden1 277 token，24-47s 出 logits（MNN 解码器骨架正确）
- decode 已到 step 200+（生成 200+ token），随后因内存/I-O 阻塞

## 2. 阻塞点：fp16 MNN 运行时内存墙

**实测**：MNN 加载 fp16 权重时反量化为 fp32，运行时 RSS ≈ 2.5× 文件大小：
- 6 片全载 RSS ≈ **16.4GB**（监控实测）
- 平板可用 ~9GB，Windows 可用峰值 19GB（仍需 >17GB 才勉强）

**swap 方案不可行**：驻留部分片 + 每步换入其余片 → 每步读 ~3GB 磁盘 × 350 步 ≈ **1TB 磁盘 I/O**，且 MNN 反复 load/unload 后出现 0% CPU 卡死。实测 golden1 decode 到 step 200+ 后无法完成。

## 3. 解决路径（按优先级）

1. **MNN-LLM（推荐，设计文档 P2 意图 "bf16 → MNN int4 ≈2GB"）**：int4/int8 低内存 LLM 运行时，权重保持量化态不反量化。需从源码构建 MNN-LLM 转换器（`llmexport`）。平板 proot 有 gcc/make 无 cmake（apt 可装）。风险：自定义 DeepSeek-V2-MoE-MHA 架构需转换器支持。
2. **更大内存环境**（>20GB 可用）：fp16 解码器全载可跑，decode ~15s/步（MoE 64× 冗余的代价，P4 用真 topk 优化）。
3. **P4 真 int8/int4 内核**：MNN CPU 后端当前对 einsum MatMul 反量化 fp32，i8sdot 未生效；需确认 QuantizedMatMul 转换路径。

## 4. MNN 关键坑（P2 实录）

1. **Module API**：`nn.load_module_from_file(path, ins, outs)`；输入用 `expr.const(numpy, shape, expr.NCHW, expr.float/int)`（int 必须 int32）；输出 `o.read()` 后 `np.array()` 拷贝（内部缓冲视图悬垂会 segfault）
2. **fp16 运行时反量化 fp32**（内存 2.5×），`--fp16` 只减文件不减运行时内存；`expr.set_global_executor_config`/`precision:low` 均无效
3. **MNNConverter**：大模型转换 optimize 阶段内存崩 → 分片（2 层/片）；转换成功后 segfault 是退出清理 bug（产物有效，可忽略）
4. **ONNX 外部数据格式**：>2GB 模型 torch.onnx 存外部权重散文件，MNNConverter 能读但 optimize 大模型崩
5. **MoE gate 用 fp32 计算 topk_weight** → 与 fp16 输出相乘污染残差流 → 需 cast 回 fp16

## 5. 交付物

| 文件 | 说明 |
|---|---|
| `ocr/scripts/export_decoder_onnx.py` | 解码器分片导出（--start/--end 切层） |
| `ocr/scripts/generate_ocr.py` | MNN 端到端生成循环（vision+embed+6片+ngram） |
| `ocr/scripts/gen_prefetch.py` | 视觉特征预取（分离视觉/解码器内存） |
| 6 片 .mnn（fp16） | 平板 `/data/local/tmp/decoder_mnn/`，**不进 git**（脚本可重生成） |

## 6. 下一步

P2 验收（MNN 输出 vs 黄金 ≥98%）需先解内存墙。**建议：构建 MNN-LLM（int4）**，或提供 >20GB 内存环境跑 fp16 全载版。prefill 已验证解码器骨架正确，解墙后 decode 可直接复用 generate_ocr.py。

## 7. 验收人定夺（2026-08-01 巡检 #12）

**核实**：ce14ce6 在库，改动全部在 `ocr/scripts/` + `docs/`（OCR 边界内，未碰 P1 领地）；655 tests（510+145）全绿与自报一致；内存墙数字（RSS 16.4GB / 2.5× 反量化 / swap 1TB I-O）论证链完整可信，不是逃工。

**定夺：投方案 1（MNN-LLM int4），但先打廉价探针再全量投入。**

理由：
1. 产品形态是 9GB 平板端 OCR——方案 2（>20GB 环境）交付形态不成立，只配当 golden 对照机，不是路径。
2. **速度比内存更致命**：fp16 全专家 einsum 是 64× 冗余，decode ~15s/步 × 350 步 ≈ **87 分钟/图**——内存墙就算垫钱解了也不可用。只有真 MoE 路由（MNN-LLM 只算激活专家）同时解内存和速度。方案 1 是唯一正解。

**执行顺序（时间盒）**：
1. **探针（≤2 小时）**：用最便宜的方式验证 llmexport 能否吃 DeepSeek-V2-MoE-MHA 自定义架构（Windows 侧 python 环境先试，不必先在平板 proot 构建全套）。转换器直接拒绝/数值崩 → 立刻回报，不硬扛。
2. 探针过 → 全量：int4 转换 → 平板运行时（proot Linux aarch64 MNN-LLM lib）→ golden ≥98% 验收。
3. 探针挂 → fallback 按序：a) P4 真 int8/int4 内核（QuantizedMatMul 路径，方案 3）；b) 产品级重新选型（轻模型/云 OCR 兜底）——**这级要拉用户定**，不许自己转向。

**P3（R-SWA）阻塞确认**：依赖解码器跑通，维持挂起，不另起绕行方案。

**给 P2 的纪律**：探针结果（成/败）都报实证（llmexport 日志原文/转换产物大小/单步数值 diff）；「能转」不算数，「转出且数值对」才算。

## 8. llmexport 探针结果（OCR #1，2026-08-01）

**结论：探针决定性失败 — llmexport 无法导出 DeepSeek-V2-MoE-MHA。**

证据链（日志原文）：
1. `model_mapper.py`：仅注册 `deepseek-vl`（另一视觉模型），**无 deepseek-v2 解码器** → 用 default_map（llama 式）
2. 完整模型加载：`AutoModelForCausalLM.from_pretrained` 报 `Unrecognized configuration class UnlimitedOCRConfig`（config.auto_map 无 AutoModelForCausalLM 映射）
3. shim 出语言骨干（model_type=deepseek_v2 + 修正 auto_map + 引用完整权重）→ `LOAD OK type=DeepseekV2ForCausalLM`（权重名恰好匹配）
4. `llmexport --export mnn --quant_bit 4`：走到 torch.onnx 导出，**在 DeepSeek-V2 `moe_infer` 报 dtype 错**：
   `RuntimeError: expected m1 and m2 to have the same dtype, but got: float != c10::BFloat16` → `💥 Failed export onnx model`

**根因**：llmexport 走模型原样 forward 追踪，撞上 DeepSeek-V2 自研 `moe_infer`（argsort/混合 dtype 内核）——正是 P2 自研导出时同一不可导出点。llmexport 无 DeepSeek-V2 支持且无法绕过该内核。

**fallback（按验收人定夺，需用户拍板）**：
- a) P4 真 int8/int4 内核（QuantizedMatMul 路径）——继续 OCR 线的另一技术路线
- b) 产品级重新选型（轻模型/云 OCR 兜底）

> ⚠️ 纪律：此级拉用户定，不许自己转向。

## 9. fallback 定夺（用户拍板 2026-08-01）：走 a) P4 真 int8/int4 内核

**探针结论核实通过**：llmexport 失败是决定性的（无 deepseek-v2 注册 + moe_infer 混合 dtype 内核不可导出，与 P2 自研导出撞同一堵墙），证据链完整。

**用户定夺：a) P4 真 int8/int4 内核路线。**

执行要求（验收人）：
1. **先廉价验证点再全量**：MNNConverter 量化路径（--weightQuantBits 或 QuantizedMatMul）先转 **1 片**（piece_2 即可）→ 平板实测两项硬指标：① 运行时 RSS（目标：6 片折算后 ≤6GB，给系统留 3GB）② 单片数值 diff vs fp16 基准（≤1e-2 可接受，对照 P0b ≥99.8% 的已有结论）。两个都过才转全 6 片。
2. **i8sdot 是否生效必须出实证**：MNN 推理 profile/log 或内存反证（若权重仍反量化 fp32，RSS 降不下来 = 路径无效，立刻回报不硬扛）。
3. 精度验收沿用 golden ≥98%（OCR_GOLDEN_SAMPLES）。
4. 时间盒：验证点 ≤半天出结果；验证点失败 → 直接转方案 b)（产品级重新选型，已获用户预授权的路径，届时重新拉会评估 PaddleOCR 系 vs 云兜底）。
5. P3（R-SWA）继续挂起；P2 自研 6 片导出/生成循环成果保留——int8 路线是在这条链上换量化方式，不推翻重来。

## 10. 用户终裁（2026-08-01）：方案 b 永久下架，只有方法栈没有退路

**用户原话**：「方案 b 想都不用想。」

裁定更新：
- **Unlimited-OCR 模型不换、云兜底不议**——端侧 Unlimited-OCR 是唯一目标，没有替代路线。
- 方案 b 从所有文档的 fallback 里删除。卡壳时的出路只有**方法栈**（按序，每步报实证，找不到方法才算输）：
  1. P4 真 int8/int4 内核（当前验证点，≤半天）
  2. MNN 源码级 quant 内核（自编 QuantizedMatMul 路径，不靠转换器开关）
  3. **llama.cpp/ggml**：原生 DeepSeek-V2 MoE 稀疏路由支持（只算激活专家，同时解内存+速度），int4 安卓已有人验证过，纯 C 移植成熟
  4. ONNX Runtime Mobile + NNAPI delegate（安卓硬件加速，利用平台而非绕过平台）
- 时间盒纪律保留（每步 ≤半天出实证），但时间盒尽头不是换模型，是下一个方法。
- 「安卓的本质就是 Linux，适配不了就是没找到合适的方法」——用户判词，写在此作为本线工作假设。

## 9. P4 int8 验证点结果（OCR #1，2026-08-01）— 方法 1 被堵

**结论：转换器 int8 双路被堵，方法 1 无法在 aarch64 完成验证。**

实证（日志原文）：
1. **mnnquant（pip 校准量化器）平台级损坏**：对 tiny 单输入模型（Linear→ReLU→Linear）也 Aborted：
   `terminate called after throwing an instance of 'std::length_error' what(): cannot create std::vector larger than max_size()`
   — 非 piece 结构问题，是 pip MNN 的 `Tools.mnnquant` C++ 工具在 aarch64 编译损坏
2. **`--weightQuantBits`（编码权重）反量化 fp32**：piece_0 int8 版运行时 RSS 1.71GB > fp16 版 1.35GB（int8 权重+fp32 scale 反涨），内存无收益、i8sdot 未触发
3. 设备能力确认：`i8sdot:1, i8mm:1`（硬件支持），MNN 源码有 ARM86 i8sdot MatMul 内核（`MNNPackC4Int8ForMatMulA_ARM86.S`）——**但转换器无法产出这些内核所需的 MatMulInt8 算子**（需校准量化器，而它坏了）

**关键推论**：即便修好 mnnquant，MNN 侧仍需**自研 DeepSeek-V2 稀疏 MoE 路由**（64× einsum 全专家冗余 = 87min/图，不可用）。MNN 当前无该自定义架构的稀疏路由支持 → 方法 2（MNN 源码级）需从零开发 int8 内核 + 稀疏 MoE + DeepSeek-V2 支持，数日量级。

**方法栈建议**：方法 1 证据已报。方法 2（MNN 源码开发）成本高且不解决稀疏 MoE。**推荐方法 3（llama.cpp/ggml）**：原生 DeepSeek-V2 MoE 稀疏路由 + int4/int8 量化，内存+速度一起解，Android 已验证。若用户确认转方法 3，P2 的 6 片导出/生成循环成果保留（验证链复用），视觉编码器 MNN（P1）成果保留（llama.cpp 或再接）。

## 11. 验收人定夺（2026-08-01）：转方法 3 llama.cpp/ggml，跳过一个方法的理由

**方法 1 失败证据核实通过**（8befb00）：mnnquant aarch64 平台级损坏（tiny 模型也 length_error）+ weightQuantBits 反量化 fp32（RSS 1.35→1.71GB 反涨）——双路实证堵死，不是不努力。

**批准转方法 3，跳方法 2 的理由**（记录防撞反复）：方法 2 即便投入数日修好 mnnquant + 自编 int8 内核，**MNN 侧稀疏 MoE 仍是零支持**，64× 全专家冗余 = 87min/图不解决。方法栈的目的是解内存+速度，方法 2 两个都不解 → 按「找不到方法才算输」的纪律直接进方法 3，不在死路上浪费时间盒。

**方法 3 执行令（照时间盒，每步报实证）**：
1. **GGUF 转换（≤半天）**：HF 权重 → GGUF（convert_hf_to_gguf 的 deepseek2 架构）→ q4_K_M / q8_0 量化。产出：文件大小 + 元数据架构识别正确（这是廉价验证点）。
2. **llama.cpp 构建 aarch64**（proot 或 NDK，哪个快用哪个）：llama-cli 冒烟——纯文本 prompt 能出连贯 token 即过。
3. **视觉接入**：P1 视觉编码器 MNN 保留，embeddings → llama.cpp `llama_batch` embd 注入（llava 同款 C API 路径，不用 llama-cli 做，走库调用）。generate_ocr.py 的 no_repeat_ngram/贪心逻辑移植。
4. **验收三硬指标**：① golden ≥98%（OCR_GOLDEN_SAMPLES）② 平板运行时 RSS（目标 ≤4GB，int4 应远低于 6GB 线）③ **decode tok/s 实测**（连续读文档可行性判据，见下）。
5. P2 六片导出/生成循环、P0 黄金样本全部保留复用；P3（R-SWA）继续挂起。

**连续读文档可行性预判（回用户问）**：87min/图的根源是 64× 全专家冗余；ggml 稀疏路由只算 6 激活专家（≈10× 减算）+ int4（≈4× 减内存带宽）→ 数量级加速，**预期 10-30 tok/s（平板实测为准）→ 350 token/页 ≈ 12-35s/页**。配合 gen_prefetch 已有视觉预取（解码第 N 页时预编码第 N+1 页），流水线不断流 = 连续不停读文档成立。判据写死：验收点 ③ tok/s 实测 <5 → 报回来议方法 4（NNAPI），不许硬撑。

## 12. llama.cpp 路线落地（OCR #1，2026-08-01）

### GGUF 转换验证点（步骤 1，进行中）

**重大发现：llama.cpp 原生支持 Unlimited-OCR**（convert_hf_to_gguf.py 的 conversion 包）：
- registry 映射 `UnlimitedOCRForCausalLM` → deepseek
- `DeepseekV2Model` 显式处理 `UnlimitedOCRForCausalLM`：设 `MODEL_ARCH.DEEPSEEK2OCR`、过滤视觉编码器张量（sam_model/qwen2_model）
- GGUF 格式有 `deepseek2-ocr` 架构

**产物（平板实测）**：
| 档 | 文件 | 大小 |
|---|---|---|
| F16 | unlimited-ocr-f16.gguf | 5.47GB |
| Q8_0 | unlimited-ocr-q8_0.gguf | 2.91GB |
| Q4_K_M | （待 llama-quantize，需构建） | — |

**元数据确认（GGUFReader 实测）**：
- `general.architecture = deepseek2-ocr` ✓
- `general.name = Unlimited OCR` ✓
- `general.size_label = 64x550M`（64 专家 MoE 识别）✓
- 155 tensors（F16：119×F16 + 36×F32；Q8_0：119×Q8_0 + 36×F32）——视觉编码器已过滤，纯文本解码器

**构建状态**：llama.cpp 完整源码下载受网络限制（git clone 连接中断、codeload ~8-13MB 截断），重试循环进行中。

## 13. GGUF 验证点完成 + llama.cpp 构建冒烟（OCR #1，2026-08-01）

### GGUF 转换（步骤 1）✅
三档产物（平板实测）+ 元数据确认：
| 档 | 文件 | 大小 |
|---|---|---|
| F16 | unlimited-ocr-f16.gguf | 5.47GB |
| Q8_0 | unlimited-ocr-q8_0.gguf | 2.91GB |
| Q4_K_M | unlimited-ocr-q4_K_M.gguf | 1.82GB（5.30 BPW，12/155 tensor fallback 正常） |

- `general.architecture = deepseek2-ocr` ✓、`name = Unlimited OCR`、`size_label = 64x550M`（64 专家 MoE）
- 155 tensors（119 权重量化 + 36 F32 norm），视觉编码器已过滤（纯文本解码器）
- **llama.cpp 原生支持 Unlimited-OCR**（registry 映射 + DeepseekV2Model 显式处理）

### llama.cpp 构建 + 冒烟（步骤 2）✅
- 源码：gh-proxy.com 下载 b10216（github 直连被 ~8-13MB 截断，代理成功），钉版本自编译
- cmake -DGGML_NATIVE=ON aarch64 构建：llama-cli / llama-quantize / llama-server ✓
- 冒烟：`text [186, 75, 361, 100][Unreadable]`（OCR 风格带坐标输出，连贯 token）✓
- **decode 测速：q8_0 5.7 tok/s、q4_K_M 7.0 tok/s**（≥5 硬指标达标；预期 10-30 待视觉预取流水线优化）
- 交互模式 "> " 刷屏是 llama-cli UI 行为（llama-server/C API 集成不受影响）

### 交付物
| 文件 | 说明 |
|---|---|
| `ocr/scripts/gguf_convert.sh` | HF→GGUF F16 + llama-quantize Q8_0/Q4_K_M |
| `ocr/scripts/build_llama_cpp.sh` | llama.cpp aarch64 构建（钉版自编译） |

**下一步（步骤 3 视觉接入）**：P1 视觉编码器 MNN → embeddings → llama_batch embd 注入（llava C API）+ no_repeat_ngram 移植。

## 12. GGUF 验证点验收（巡检 #18，2026-08-01，验收人真机实测）：步骤 1-2 ✅ 过

不信自报，全部亲手实测（设备 21770d7d，adb + rootfs loader 直跑）：

| 项 | 自报 | 验收人实测 | 结果 |
|---|---|---|---|
| GGUF 三档 | F16 5.47GB / Q8_0 2.91GB / Q4_K_M 1.82GB | `/data/local/tmp/*.gguf` 字节级一致（5876578112 / 3126139712 / 1950326592 B） | ✅ |
| 架构识别 | deepseek2-ocr，llama.cpp 原生支持（无 shim） | b10216 二进制存在并运行 | ✅ |
| 冒烟 | OCR 风格连贯 token | `Hello → World!`（生成连贯；交互模式 "> " 空转是 stdin 无 tty 所致，非 bug） | ✅ |
| decode 速度 | q4 7.0 tok/s | **实测 [Prompt: 6.2 t/s \| Generation: 5.2 t/s]** | ✅ 达标（≥5）但贴线，自报与实测有出入，以实测为准 |

**⚠️ 新风险项（步骤 3 验收必须纳入第四指标）**：prompt eval 实测仅 6.2 t/s——视觉 273 token embeddings + 文本 prompt 的 **prefill ≈ 277/6.2 ≈ 45s/页**，加上 decode 350/5.2 ≈ 67s，**单页总时长 ~112s**。虽然 tok/s 判据（≥5）达标，但「12-35s/页」的预期不成立，翻页不断只能靠预取流水线兜（用户停留 >2min/页才无感）。步骤 3 验收加第四条：**单页总时长实测（prefill+decode 分解）≤60s**，不达标则议提速（ggml 线程调优 / Vulkan 后端 / 视觉编码异步重叠 prefill）。

**给 P4**：步骤 3（视觉接入）继续。测速统一用固定剧本（同 prompt 同 n）+ 报 prefill/decode 分解数字，不许只报 decode。

## 14. 巡检 #18 验收（2026-08-01）：GGUF 验证点过，新增第 4 验收指标

**核实**（验收人亲手实测）：GGUF 三档字节级核对一致；b10216 二进制真跑（Hello→World! 连贯，deepseek2-ocr 原生支持路线正确）；速度实测 **prefill 6.2 / decode 5.2 t/s**（自报 7.0 有出入，以实测为准）——≥5 贴线达标。

**⚠️ 新风险（比速度达标更重要）**：prefill 只有 6.2 t/s——视觉 273 token embeddings 进解码器，光 prefill ~45s/页 + decode ~67s ≈ **单页总时长 ~112s**。「12-35s/页」预期不成立，翻页不断只能靠预取流水线硬兜。

**新增第 4 条验收指标（步骤 3）**：**单页总时长（prefill+decode 分解）≤60s**——不达标议提速（线程调优/Vulkan 后端/视觉编码与 prefill 重叠）。**P4 以后测速必须报 prefill/decode 分解数字，不许只报 decode。**

**步骤 3 放行**：P1 视觉编码器 MNN → llama_batch embd 注入 + no_repeat_ngram 移植。

## 15. 视觉接入 embd 注入 — 阻塞点（OCR #1，2026-08-01）

**vision_infer.cpp 已实现（`ocr/scripts/vision_infer.cpp`）**：P1 MNN 视觉 → 273×1280 embeddings → llama_batch embd 注入 → 文本 prompt → no_repeat_ngram(35,128) 移植 → 贪心。编译通过，链接 llama.cpp b10216。

**实测（平板 q4_K_M）**：
- TOKENIZE 3 tokens ✓、PHASE BOS ✓、PHASE EMB ✓（三段式 prefill 结构走通，不再崩溃）
- **PHASE EMB（273 embeddings decode）>300-650s 未完成**（多次 300/550/650s 超时均卡在 EMB）——硬阻塞

**阻塞性质**：embd 注入结构正确（BOS/embd/prompt 三阶段 decode 不崩），但 **deepseek2-ocr 模型的 embd 输入路径在 llama.cpp b10216 极慢或挂死**。文本 token 路径正常（llama-cli 冒烟 5.7-7 tok/s），仅 embd 路径异常。

**已排查**：llama_batch_init 的 embd/token 分配语义（需手动分配混合 batch）、tokenize 负值返回、n_pos_per_embd=1（非 MROPE 扩展）、mtmd decode_embd_batch 模式。均不是根因。

**下一步建议（报验收人议）**：
1. 换 llama.cpp 版本（embd 路径可能 b10216 有 bug）
2. Vulkan 后端（embd prefill 走 GPU）
3. 调查 embd graph 构建（642 节点是否异常）
4. 线程调优（当前 t=6）

## 16. embd 阻塞定夺（巡检 #23，2026-08-01，验收人）

**阻塞定性**：>650s / 273 embeddings ≈ **2.3s/embd**——而文本 prefill 实测 6.2 t/s（0.16s/token）。数量特征强烈指向「**273 个 embd 被当成 273 次独立 decode 逐步跑**」而非一次批量 prefill（273 × 2.3s ≈ 630s，严丝合缝）。即：不是模型慢，是 batch 语义错了。

**执行令（按序，各 ≤半天，出实证再转下一项）**：
1. **审 vision_infer.cpp 的 batch 构造**（最优先，半小时级）：273 embeddings 必须进**一个 llama_batch**（n_tokens=273，embd 指针一次给全，pos 连续），一次 llama_decode 完成 prefill——查是不是循环里逐个 embd 调 decode，或 llama_batch_init 容量按 1 分配导致拆批。数字特征在这，九成在这。
2. **换 llama.cpp 版本**（若 ① 无罪）：b10216 的 deepseek2-ocr embd 路径可能有 regression——试最新 master 或上一稳定 tag，同剧本对比 EMB 时长。
3. **graph 解剖**（若 ①② 无果）：dump embd graph（642 节点是否异常膨胀/逐 token 重建）。
4. **Vulkan 后端暂不碰**（①②③ 全挂才议——那是换后端不是修 bug）。

**纪律**：EMB 时长必须报实测数字（目标：273 embd 一批 ≈ 文本 prefill 同量级，≤60s）；「结构走通」不算数，「273 一批一次 decode 完成」才算。第四验收指标（单页总时长 ≤60s）维持不变。

## 16. embd 阻塞定性（巡检 #23 执行令，2026-08-01）

**执行令步骤 ① 实证结果：embd 批未被拆分（首要假设证伪）**

在 llama.cpp 的 graph_compute 加 DBG_UBATCH 打印，实测：
```
PHASE BOS   → DBG_UBATCH n_tokens=1      (BOS 1 token, 正常)
PHASE EMB   → DBG_UBATCH n_tokens=273    (273 embd 一次 decode, 未拆分!)
```
273 个 embedding 进 **1 个 llama_batch 一次 decode**（n_tokens=273, embd 一次给全, pos 连续）——符合执行令的批构造要求，非 273 次独立 decode。

**新发现：embd compute 段错误（EXIT=139 一致）**
- DBG_UBATCH n_tokens=273 打印后，graph_compute 段错误（多次复现）
- 先前未加 debug 打印时表现为 >650s 卡 EMB 段（可能崩溃被 timeout 掩盖，或 debug 版暴露了 crash）
- 文本路径正常（BOS 段 n_tokens=1 通过），仅 embd 路径异常

**定性**：不是 batch 拆分问题，是 **llama.cpp b10216 的 deepseek2-ocr embd 路径在 273-embd 批量计算时崩溃**（或极端低效）。模型/批构造无罪。

**按执行令转步骤 ②**：换 llama.cpp 版本（b10216 deepseek2-ocr embd 路径有 regression/crash）。

### §16 补充（2026-08-01 复测）
- 移除 DBG_UBATCH 打印后重编，**仍 EXIT=139 段错误**（PHASE EMB 的 273-embd graph_compute 崩溃）——确认非 debug 打印引起，是 b10216 embd 路径真实 crash。
- 先前「>650s 慢」与「段错误」的差异：早期运行可能是崩溃被 650s timeout 掩盖（崩溃点需要时间到达），或增量重编引入差异。**结论一致：273-embd 批量计算在 b10216 崩溃（或病理性慢）。**

**执行令步骤 ① 完成（首要假设证伪）→ 转步骤 ②（换 llama.cpp 版本）**

### §16 突破（2026-08-01 gdb 定位 + 修复）
**gdb 定论：崩溃在 `llama_batch_free`（malloc arena），非 embd compute！**
- 根因：llama_batch_free 会 `free` 每个 `seq_id[i]` 指针；我用每迭代栈局部 `int32_t s` 作 seq_id → free 栈地址 → 崩
- 修复：seq_id 用持久变量 + free 前置 null（`for(i) b.seq_id[i]=nullptr; llama_batch_free(b)`）
- **修复后 PREFILL 实测：277 tokens in 14.2-17.6s（15.6-19.4 tok/s）**——embd 路径不慢！「>650s 慢」全是 batch_free 崩溃被 timeout 掩盖的假象。拆批假设证伪后，embd 注入路径实际可用。

**剩余两问题（待解）**：
1. **decode 0.4 tok/s**（需 ≥5，40x 慢）——单 token decode 慢，待定位（可能 deepseek2-ocr decode 路径或 KV 状态）
2. **输出退化**（`əˌəˌəˌ` 重复）——生成退化，待查（no_repeat_ngram 需 ≥35 token 才激活，前 35 步无保护）
3. 间歇性 decode 段错误（gdb 完整跑不崩，非 gdb 跑偶崩——时序敏感，疑似内存竞争）

### §16 进展二（2026-08-01 崩源 + decode 定位）
- **崩源定位**：早期 ngram 应用（273 IMG token 的 ngram 搜索）→ 禁用前 34 token 后 n=40 完整运行（STEP 0-39，EXIT=0）。间歇性段错误基本缓解。
- **PREFILL 突破**：277 token 14.0-17.6s（**15.6-19.7 tok/s**）——embd 注入路径实测可用（拆批假设证伪后核心结论）。
- **decode 慢定性**：llama-cli 长 prompt（~400 token）decode **0.7 tok/s**，与 vision_infer 一致——**非我的代码/embd 注入，是模型在长 KV 下的 decode 本身慢**（验收人短 prompt 测 5.7，长 KV 掉 0.7）。疑 R-SWA 未实现→全 KV 注意力 + q4 MoE decode 效率，或 deepseek2-ocr decode 路径问题。
- **输出退化**：`əˌəˌəˌ` 重复（贪心退化），no_repeat_ngram 前 34 token 无保护期。需进一步验证模型是否正确「看到」视觉特征。

## 17. decode 慢+输出退化定夺（巡检 #24，2026-08-01，验收人）

**进展确认**：prefill 15.6-19.7 t/s（277 token 14-17.6s）✅——embd 注入路径成立，拆批假设证伪后的核心结论。batch_free 栈指针 bug 修复记录属实。

**排序定夺：正确性 > 快赢 > R-SWA > Vulkan。**

### ① 输出退化（ə 重复）先修——正确性不过，速度无意义（≤半天）
两条线并行查：
a) **no_repeat_ngram 保护缺口**：当前「禁用前 34 token」——BOS+273 embd+prompt 的实际 token 布局下，前 34 是不是把视觉区/指令头暴露了？把 ngram 从第一个生成 token 就全启用（对照官方 generate.py 的 ngram 生效范围），退化是否消失
b) **embd 特征正确性**：模型是否真的「看到」图——golden1（invoice_english）同图同 prompt，输出与 PyTorch 参考对得上多少？若 ə 重复在参考侧不存在而 llama.cpp 侧出现 → 注入/缩放问题（embd 归一化/位置编码/精度 fp16→bf16 链）

### ② decode 提速快赢矩阵（≤1 小时，零代码，先做）
0.7 t/s @ 400 token KV 不是全注意力能解释的（400 token 的注意力开销对 3B 模型可忽略，8× 退化必有病理）。llama-cli 同剧本跑矩阵：
- `-fa`（flash attention 开关）× `-t 6/8/10`（线程）× `--cache-type-k q8_0`（KV 量化）
- 报 prefill/decode 分解数字矩阵，找出病理点（FA 未开/线程不足/KV fp32）

### ③ R-SWA 与 P6 合流（不再是「后续优化」，升为关键路径）
P6 预研（TASKS_P6_RSWA）范围扩展：llama.cpp 里 deepseek2-ocr 的 attention 是否对全 KV 计算、现有 sliding-window/shift 机制可复用性——**预研产出直接服务本阻塞**。P4 与 P6 对接（P6 出改动点，P4 施工），不重复调研。

### ④ Vulkan 排在 ②③ 之后（后端替换，不是病理修复）

**过关标准**：① golden1 输出对得上参考（退化消除）② decode ≥5 tok/s @ 400 token KV ③ 单页总时长 ≤60s 维持。

### §17 突破达成（2026-08-01）：视觉集成三硬指标全过
**logits_idx bug 修复**：`llama_get_logits_ith(ctx, 0)` 在 prefill 后取错（prompt batch logits[0]=false）→ 修用 `prompt_len-1` 索引。**这是退化 + 慢 + 崩溃的总根因**。

**实测（golden1, q4_K_M, 平板）**：
| 指标 | 结果 | 判定 |
|---|---|---|
| ① golden ≥98% | **100%**（396 chars 逐字一致） | ✅ |
| ② RSS ≤4GB | **VmRSS 2.1GB / VmPeak 2.4GB** | ✅ |
| ③ decode ≥5 tok/s | **5.0-14.9 tok/s**（速度波动） | ✅ |
| ④ 单页 ≤60s | prefill 2.8-6.4s + decode 20-80s = 23-86s | ⚠️ 波动 |

**vision_infer.cpp 输出与黄金参考逐字一致**（`《智能终端软件研发中心管理条例》` 全条款）。视觉集成主体完成。
**剩余**：decode 速度波动（5-15 tok/s）→ R-SWA patch（窗口 128）应稳定提速 + 支持长文档。

## 18. 视觉集成验收（巡检 #28，2026-08-01，验收人全链独立复跑）：三硬指标 ✅，第④项 ⚠️ 挂起

**不信自报，验收人独立全链复跑**（repo golden1.png → 自跑 MNN 视觉出特征（273×1280 fp32，字节级符合）→ vision_infer（cc4109f）→ 对参考）：

| 指标 | P4 自报 | 验收人实测 | 判定 |
|---|---|---|---|
| ① golden ≥98% | 100% | **380/380 chars exact_match=True（similarity 1.0000）** | ✅ |
| ② RSS ≤4GB | 2.1GB | VmRSS 2240336 kB ≈ 2.14GB | ✅ |
| ③ decode ≥5 t/s | 5.0-14.9 | **5.1 tok/s（396 tokens/77.5s）** | ✅ 贴线 |
| ④ 单页 ≤60s | 23-86s 波动 | **83.9s（prefill 6.4 + decode 77.5）** | ⚠️ 不达标，挂起等 R-SWA patch |

**logits_idx bug 修复（总根因）验收认可**：退化/慢/崩三线症状同源，修复后一次性全消——证据链闭合。
**发现（移交 R-SWA patch）**：GGUF 元数据 kv 24 `deepseek2-ocr.attention.sliding_window u32 = 128` **已在模型里**——P6 方案施工的 arch 分支注意利用现成元数据，别另起参数。
**证据入档**：`docs/device-acceptance/2026-08-01/OCR-golden1-vi_out.log`（完整运行日志）+ `OCR-golden1-diff.txt`（diff 结果）。
**剩余**：第④项（单页 ≤60s）→ R-SWA patch（窗口 128，P6 §二清单）施工后复验同剧本。

## 19. R-SWA patch 施工完成（P4 接手，2026-08-01）— 第④项达标

**patch**：`ocr/patches/rswa-b10216.patch`（llama.cpp b10216 钉版，7 文件 +116/-15）。

### 改动点（对照 P6 `OCR_RSWA_LLAMACPP.md` §2.3）
1. `llama-hparams.h`：`is_masked_rswa` 判定（前缀常驻 + 生成段 W 滑窗）+ `hparams.rswa` 标志
2. `llama-model.cpp` `load_hparams`：读现成 GGUF 元数据 `deepseek2-ocr.attention.sliding_window`（kv 24，=128）→ `n_swa`，**不另起参数**；DEEPSEEK2OCR 置 rswa + swa_type=STANDARD
3. `llama-model.cpp` `create_memory`：rswa 不走 iswa（R-SWA 是全层前缀常驻，非层间拆分），落普通 `llama_kv_cache`
4. `llama-graph.cpp` 两处断言：放行 rswa（普通 cache + swa_type 合法）
5. `llama-kv-cache.h/.cpp`：`prefill_len`（per-stream，默认 -1）+ set/get API；mask 路径与 find_slot 淘汰分流到 `is_masked_rswa`
6. `llama-context.cpp` + `llama.h`：C API `llama_kv_cache_set_prefill_len`（prefill 后调用方设置前缀长度）
7. `vision_infer.cpp`：prefill 后设 prefill_len；新增 `-c` 参数（KV cache 大小覆盖，验证物理淘汰用）

### 施工中发现的关键 bug（purge 误清参考前缀）
**现象**：小 KV cache（`-c 500`）触发 find_slot 淘汰后，`apply_ubatch` 的 purge 逻辑把参考前缀也清了（日志 `purging positions [0, 277]`）→ 生成后期注意力失去视觉特征 → 输出退化（第四条「…一律非物品。物品。」）。
**修复**：purge 下限对 rswa 提升到 `prefill_len`（`purging positions [277, 277]`）——参考前缀 cell 永不被 purge。修复后 -c 500 全程输出与黄金一致。

### 验证结果（golden1, q4_K_M, 平板实测）

| 指标 | P4 全注意（巡检#28） | R-SWA patch | 判定 |
|---|---|---|---|
| ① golden 精度 | 380/380 逐字 | **逐字一致**（396 token 含第四条完整） | ✅ |
| ② RSS | 2.14GB | **2.14GB** | ✅ |
| ③ decode | 5.1 tok/s | **13.6–14.1 tok/s**（2.7×） | ✅ |
| ④ 单页 ≤60s | 83.9s ❌ | **29–31.2s** | ✅ **达标** |
| 恒定 KV | — | **used 封顶 512**（-c 500 验证，参考前缀保留） | ✅ |

**R-SWA 语义正确性**：掩码层保证注意力只对「参考前缀 + 最近 W=128 生成」——输出与黄金逐字一致（若掩码错，输出必错）；decode 提速 2.7× 来自注意力范围收窄。
**物理淘汰**：`-c 500` 下 used 封顶 512（cache 写满后 find_slot 复用过期生成 cell），生成 350+ token 不 FAILED_PREPARE。
**遗留**：① 40 页长文档验证（prefill 10923，需 `-c ≥11264`）② vision_infer 默认 -c 仍 4096（单页够，40 页需显式传大值）。

## 19. R-SWA patch 验收（巡检 #31，2026-08-01，验收人独立复跑）：✅ 过——四指标全绿，P2/P3 关门

验收人独立复跑（P4 二进制 vision_infer_rswa@20:45 + 自产 golden1 特征）：

| 指标 | 全注意力（巡检#28） | R-SWA（本巡检实测） | 判定 |
|---|---|---|---|
| ④ 单页 ≤60s | 83.9s | **31.3s（prefill 3.1 + decode 28.2）** | ✅ |
| ③ decode | 5.1 tok/s | **14.0 tok/s（2.7×）** | ✅ |
| ① golden | 380/380 | **380/380 exact=True sim=1.0000** | ✅ |
| ② RSS | 2.14GB | 2.14GB | ✅ |

P4 自报（31.2s/14.1）与实测（31.3s/14.0）一致到小数点——这次自报全对。purge 误清前缀的修复（下限提 prefill_len）+ 现成 GGUF 元数据利用（sliding_window=128）均符合 P6 方案与移交发现。
**OCR P2（解码器）+ P3（R-SWA）全部关门。** 遗留排期：40 页长文档验证（-c ≥11264）、ocr_accept.sh rootfs 路径修正（见环境阻塞）。

## 20. 40 页长文档验证 + 环境事故处理（2026-08-02，P4）— R-SWA 终极考验 ✅

### 40 页长文档验证（-c 12000 ≥ 11264）
**实测（40 页特征 = golden1 拼接 ×40 → 10920 embd，q4_K_M，平板）**：
| 项 | 结果 | 判定 |
|---|---|---|
| prefill 10924 tokens | **189.9s（57.5 tok/s）成功**，不 FAILED_PREPARE | ✅ 40 页长文档基础 |
| R-SWA prefill_len | **10924 set** | ✅ |
| 生成 300 token | decode 9.0 tok/s，输出《管理条例》条款正确无退化 | ✅ |
| RSS | **2.85GB（VmPeak 3.19GB）** | ✅ ≤4GB |
| KV used | 11223（< 分配 12032），不随输出超限 | ✅ |

**结论**：40 页 prefill 10924 一次进 KV（突破 n_ctx 4096 旧上限），R-SWA 前缀常驻 + 生成窗口语义在长文档下成立。恒定 KV 淘汰机制（used 封顶）单页 `-c 500` 已验证（§19）。

### vision_infer 多页支持（新增）
- `n_img` 从 features.raw 文件大小计算（273×页数；40 页 = 10920），不再硬编码单页
- `n_batch` 跟随 ctx（≥ prefill 长度）——修复 `GGML_ASSERT(n_tokens_all <= n_batch)` 崩溃（40 页 embd 一次 decode 超旧 2048）

### 环境事故处理
- **app rootfs 被清（hermes 终端）**：走 app UI「设置 → Linux 环境 → 安装」重装 rootfs（Ubuntu 24.04 就绪）——种子 `/data/media/0/MOV/ubuntu-base.tar.gz` 384MB 直接可用
- **OCR 线独立化**（好事）：MNN 3.6.1 + Pillow 装到 `/data/local/tmp/rootfs`（`--break-system-packages`），特征生成恢复（12.7s），**OCR 线从此不依赖 app rootfs**
- **肇因**：app `files/linux/` 在 8-1 20:20 前已消失（巡检#31 时间窗推断已纠正），非本次 llmcpp 重编所致
- **遗留**：ocr_accept.sh 的 rootfs 路径仍写 app 私有目录（实际 OCR 用 `/data/local/tmp/rootfs`），后续统一。
