# 程序员快速接入（ONBOARD）— 2026-08-03

> 给新接入的 AI 程序员的一段话，直接复制可用。随架构演进同步更新。

---

**仓库**：`C:\Users\Administrator\MOV-APP`（git@github.com:onlywmw/MOV-APP.git，main 直推）。构建：`export JAVA_HOME="/c/Program Files/Android/Android Studio/jbr" && ./gradlew assembleDebug test`。**交付铁律：编译+测试不过不许报 hash；BUILD FAILED ≠ 测试红，要看 N tests completed。**

**项目是什么**：Android 对话式服务入口（包名 com.hermes.android）——「说一句话，服务就到了」。现在是一个**多脑底座**：

- **WebView 新脸**（assets/js/newface.js 专家模式 + 设置折叠树 + 意图路由）
- **桥内核**（bridge/BridgeKernel，query case 分发 + 统一工具注册表；新功能只走 postCmd/query 信封）
- **Hermes 常驻服务**（serve/mov-serve：127.0.0.1:8387 daemon + HermesClient + HeavyWorker serve 路径，M1-M5 全通）
- **双副本保险柜**（vault/：SecureVault AES-GCM + KeyguardGate 锁屏闸 + DualWriter 打码分流）
- **工具健康体系**（ToolRegistry 统一注册表 + H1 reason code + H2 HealthMonitor 周期探测 + ToolRuntimeLimits 双超时）
- **workflows 触发器引擎**（com.hermes.android.workflow，纯 JVM）

## 二、5 分钟跑起来（2026-08-07 实证订正）

环境（Windows 已配好；每次开新 shell 都要 export）：

```bash
export JAVA_HOME="/c/Program Files/Android/Android Studio/jbr"
ADB="/c/Users/Administrator/platform-tools/platform-tools/adb.exe"   # 真路径（非 AppData/Local/Android/Sdk，本机不存在）
```

```bash
./gradlew assembleDebug test                       # 构建 + 全量单测（看 N tests completed）
"$ADB" -s 21770d7d install -r app/build/outputs/apk/debug/app-debug.apk
"$ADB" -s 21770d7d shell am start -n com.hermes.android/.HermesActivity
```

> **订正（2026-08-07）**：改 `assets/` 下 HTML/JS **不是"重进即生效"**——assets 编译进 APK 只读，
> 必须重新 `./gradlew assembleDebug` + `install -r` 才生效。真机前端迭代按此流程，勿信旧说法。

协作模式：用户当中转，验收人（另一个 AI）审你的每个 commit，不合格打回（带精确修法）。

## 包结构（2026-08-02 拆包后，新类按职责归位，不许回根包）

| 包 | 内容 |
|---|---|
| 根包（16 类） | Activities（manifest FQN 零改动）+ 基础设施（StorageManager/RulesManager/SessionVault/TokenMeter/ToolStats 等） |
| `capability/` | 指令→能力链（IntentParser/CapabilityExecutor/ParsedCommand/CommandResult） |
| `scene/` | 场景卡/源（TrainSource/MusicSource/MayiSite/SiteCard/DramaSource/FastSceneProvider 等） |
| `browser/` | ConnectWeb 浏览器壳（BrowserAction*/SiteRuleEngine/BrowserToolProvider）+ ToolRuntimeLimits |
| `toolprovider/` | 工具提供者（System/Hermes/Extra/Utility/Memory/Ocr 等 + ModelToolProvider.kt） |
| `security/` | 支付闸（PaymentGate）/ 中继（PayQRRelay）/ PII 打码（PiiMasker） |
| `workflow/` | 触发器引擎 + 集成壳（Workflows/WorkflowEventSource/DeviceStateReader 等） |
| `vault/` | 双副本保险柜（SecureVault/KeyguardGate/DualWriter/AesGcm） |
| `agent/` | AgentLoop/ToolRegistry/HermesClient/HeavyWorker/HealthMonitor/VideoSourceRegistry |

**上手文档（按序读）**：
1. `docs/ARCHITECTURE.md` — 当前架构总览（一表两脑）
2. `docs/DESIGN_HERMES_SERVE.md` — Hermes 常驻服务化（M1-M5，serve 纪律）
3. `docs/DESIGN_TOOL_HEALTH.md` — 工具健康（H1 reason code + H2 周期探测）
4. `docs/PLAN_HERMES_SLIM_PHASE3.md` — 阶段3 瘦身计划（A0/A/B/C/D，**已全收官**，验收记录见 TASKBOARD P2 #5-9）
5. `docs/ACCEPTANCE_PLAYBOOK.md` — 验收规矩：假覆盖四形态、变异测试、证据链
6. `docs/DEVICE_ACCEPTANCE.md` — 真机验收（DV 清单，截图即证据，L2+ 需证据链）
7. `docs/ARCH_REVIEW.md` — 架构评审（拆包依据）
8. `docs/TASKBOARD.md` — 任务队列（唯一权威）

## 核心红线

- 网络 IO 禁同步桥（cbId 异步）；回调必须投递到发起方所在 WebView
- 支付/短信/通讯录/通话记录永久不碰（不碰钱、不碰信）；收款码直达，无资金池
- 单测零网络：注入式写法（构造函数注入数据，解析方法 package-private）
- 禁假覆盖：mock 喂答案 / 永真断言 / 字面量比较 / 注释冒充实现
- 听不懂的话 → 诚实卡「我还不太明白」，任何场景流不得作为默认兜底
- **保险柜纪律**：原文只进 `filesDir/vault/`，index 只存元信息不落内容片段，名称脱敏（长数字→[数字]）
- **serve 纪律**：绑死 127.0.0.1 + X-Mov-Token fail-closed（未配置全 401）；不许热升级；healthz-on-call 是唯一真相（不信 pidfile）
- **掉线/断连处理**：serve daemon 被杀 → 下次调用 healthz 不通自动懒启动恢复；空闲 30min 自动退出再懒启动；SSE 断线重连 3 次降级 500ms 轮询；pidfile 预杀防端口冲突
- **工具失败可归因**：所有工具失败带 H1 reason code（NOT_CONFIGURED/SOURCE_DOWN/PARSE_DRIFT/PERMISSION_MISSING/ENV_BROKEN/NOT_REGISTERED/UNKNOWN），不许「调用不了」一锅端
- 修复要修对地方：改完全局 grep 确认同类问题清零再报
- DOM/页面问题先 curl 源码或 CDP 看真实结构再开药
- JS 注入串无换行 → 禁 `//` 单行注释（会吞后续代码），用 `/* */` 或删
- WebView API 只在主线程；JavaBridge 回调线程用缓存值

## 验收流程

做完报 commit hash → 验收人跑编译+全量测试+diff 审查+（需要时）真机 DV → 过/打回。打回附精确修法，**逐字读完再动手，别修上一轮的 bug**。真机 L2+ 项需**证据链**：触发截图 → 执行 logcat → 中间态截图 → 结果截图+断言对照（截图里看得到断言的那件事）。

## 多程序员分工（2026-08-07 起：查验员派单制）

> 现行模式：**查验员出计划/验收，程序员施工**——工单登记在 TASKBOARD「工单14+ 登记」区，认领/回写都在板上。早期 P1/P2 队列制保留如下（文件边界仍有约束力）：

| 编号 | 战线 | 文件边界 |
|---|---|---|
| P1 主线 | 新脸/设置页/workflows/融合架构/呈现层 + 记忆层 | newface*.js / bridge/ / workflow/ / 设置页 + hermes-agent + Journal |
| P2 服务化+工具 | Hermes serve / 工具健康 / vault / 阶段3 / MCP 产线 | serve/ + vault/ + agent/ 工具侧 + hermes-agent + mcp/ |

> 原 P3（备位）/P4（OCR）/P5（保险柜）/P6（记忆/瘦身）已下线，工作并入 P1/P2（认领以 TASKBOARD 为准）；历史交付记录保留在 TASKBOARD 各区。

## 当前任务队列

见 `docs/TASKBOARD.md`（唯一权威）。截至 2026-08-08：阶段3 A0/A/B/C/D 全部复核通过；工单14-23 全关；**最新交付 = 工单24 资产转化层 `0f97001f`（待验收）**；后续队列（serve 完整任务链真机证据 / Journal 单例收敛 / PLAN_SURPASS 批2）见板上「后续队列」区。**设计文档带状态位，做完回写。**
