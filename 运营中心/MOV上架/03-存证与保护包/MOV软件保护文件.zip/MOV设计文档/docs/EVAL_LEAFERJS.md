# LeaferJS 引擎评估报告

> 2026-07-30，评估源码 `leafer-ui-main.zip`（v2.2.7，MIT 协议）。
> 审查目的：判断是否引入 MOV 技术栈，以及引入时机。

---

## 1. 引擎概况

| 维度 | 值 |
|---|---|
| 名称 | LeaferJS (`leafer-ui`) |
| 版本 | 2.2.7 |
| 协议 | MIT |
| 包大小 | 70 KB min+gzip（零依赖） |
| 语言 | TypeScript，无编译运行时依赖 |
| 仓库 | github.com/leaferjs/leafer-ui |
| 作者 | Chao (Leafer) Wan，五年持续维护 |
| 商业模式 | 核心开源 MIT + PxGrow 商业插件 |

**核心定位**：Canvas 2D 渲染引擎，类 DOM API + 场景树 + Flex 布局。宣称是"AI 时代的无限画布引擎"——百万级交互图形 60fps，内置 Editor 插件支持旋转/缩放/移动/多选。

### 技术架构

```
leafer-ui (主集成仓库，1 行 re-export)
  └─ @leafer-ui/web (Web 渲染器)
       ├─ @leafer-ui/core (UI 层：图形、布局、编辑器)
       │    └─ @leafer/core (引擎核心：场景树、事件、渲染管线)
       ├─ @leafer-ui/draw (Canvas 2D 绘图后端)
       ├─ @leafer-ui/interaction-web (Web 交互：拖拽、多点触控)
       └─ @leafer-ui/partner (第三方集成适配)
```

分包 ~150 个 TS 源文件在本仓库，核心逻辑在 `@leafer/core` 和 `@leafer-ui/core` 独立仓库。

---

## 2. 关键性能数据

| 测试项（100 万个可交互矩形） | 传统 Canvas 库 | LeaferJS | 提升 |
|---|---|---|---|
| 首屏创建 | ~9-15s | 1.28s | ~8× |
| 内存占用 | ~2-4GB（常崩溃） | 320MB | ~8× |
| 单元素拖拽帧率 | 0-4 FPS | 60 FPS | ~15× |

测试环境：2K 屏笔记本 / Chrome V143。命中检测（Hit Testing）在引擎层实现，不靠 DOM 事件代理。

> **数据置信度**：以上性能数据来自 [LeaferJS 官方 benchmark](https://benchmark.leaferjs.com/leafer/)，未经 MOV 团队独立复测。结论采纳官方数据作为方向性参考，实际落地前应在小米平板 24018RPACC 上复测百万矩形场景以确认移动端表现。

---

## 3. 对 MOV 的价值分析

### 3.1 问题定义

MOV 当前 agent 生成视觉内容的标准路径：

```
agent → 生成 HTML+CSS 字符串 → 写入 .html 文件 → WebView 预览
```

此路径有三个结构性弱点：

1. **LLM 出错率高**：CSS 定位、层叠上下文、响应式断点极容易生成错误，修复消耗额外轮次。
2. **无交互能力**：生成的 HTML 是静态的，用户要调整布局/颜色/大小只能回 chat 让 agent 改源码。
3. **重渲染开销**：每次修改都是"改源码→重新加载整页"，没有增量更新。

### 3.2 替代路径

```
agent → 生成场景图 JSON → journal 记录 → LeaferJS Canvas 渲染 → 用户直接拖拽编辑
```

| 维度 | agent 生成 HTML+CSS | agent 生成 LeaferJS 场景图 JSON |
|---|---|---|
| LLM 出错率 | 高——CSS 定位/层叠易错 | 低——结构化 JSON，坐标和属性显式声明 |
| 渲染性能 | DOM 重排重绘，复杂页掉帧 | Canvas 60fps，百万元素可交互 |
| 用户交互 | 无，需额外手写 JS | 内置：拖拽、缩放、旋转、多选、对齐 |
| 数据体积 | 完整 HTML 页面可达数百 KB | 场景图 JSON 一般 2-20 KB |
| 增量编辑 | 改源码→重载全页 | 操作场景树节点→增量重绘 |
| agent 可读性 | 需解析 HTML 字符串 | 结构化 JSON，直接读 |

### 3.3 与 MOV 架构的咬合

```
AgentLoop 生成场景图 JSON
  │
  ├─ journal 记录 (audit:true, type:canvas.render)
  │
  ├─ MovRender 投影 → 房间 chatBody 出现画布卡片
  │
  ├─ WebView 内 LeaferJS 渲染 Canvas
  │    └─ Editor 插件: 用户拖拽/缩放/旋转元素
  │
  └─ 用户编辑 → _movEvent(edit) → 变更 JSON → journal
       └─ agent 可基于变更后 JSON 继续修改（闭环）
```

这直接延伸了 MOV 核心定义——"人和 AI 在项目房间里共同工作，产出文件"。现有房间产出的是文本文件，加了 LeaferJS 后可以产出**可编辑的视觉文件**。

### 3.4 接入成本

**极低。** 接入方式是 WebView 内加载，不涉及原生 Java 代码：

```html
<!-- hermes-shell.html 加一行 -->
<script type="module" src="leafer-ui/dist/web.esm.min.js"></script>
```

- 70KB gzip，首屏增量可忽略
- 零 Java/Kotlin 适配——LeaferJS 是纯 JS 引擎
- 不碰任何 MOV 既有模块（桥、AgentLoop、Journal）
- MIT 协议无合规风险

### 3.5 与 htmltool2 路线的分工

MOV-TECH-DEBT 已登记「交付物微调编辑器（htmltool2 思路）」——两者解决同一需求源（用户改交付物不走 agent 轮次），但定位不同，不撞车：

| 维度 | htmltool2 | LeaferJS |
|---|---|---|
| 改什么 | HTML 源码文本 | 画布上的视觉元素 |
| 怎么改 | 光标点进去改字/换图 | 鼠标/手指拖拽、缩放、旋转 |
| 适用交付物 | 文字为主的页面（报告、文档、表单） | 视觉为主的画布（海报、图表、数据看板） |
| 编辑粒度 | 字符级 | 元素级（位置/大小/颜色/图层） |
| 用户心智 | "我要改这一行字" | "我要把这个方块往左挪一点" |
| 技术层 | DOM 内 contentEditable | Canvas 2D 场景图 |
| 接入位置 | `assets/editor/` 单文件嵌入 | `hermes-shell.html` 动态 import |
| 与 agent 关系 | 用户手改 → agent 继续改源码 | 用户拖改 → 变更 JSON → agent 继续改场景图 |

**分工结论：两条路都留着，按交付物类型自动/手动选择。** agent 生成海报/图表/看板 → 走 LeaferJS 画布；agent 生成文档/表单/报告 → 走 htmltool2 源码编辑。不互斥，不撞车。

接入决策表：

| 触发条件 | 选哪个 |
|---|---|
| 交付物是 .html 文件、用户说"改个字" | htmltool2 |
| 交付物是视觉布局、用户说"挪一下/大一点/换个色" | LeaferJS |
| agent 自己判断交付物类型 | 两个工具都暴露，LLM 根据场景选 |

### 3.6 与 DESIGN_TECH_KERNEL 层 3（SDUI）的关系

**互补，不互替。** SDUI（Kotlin Compose）做原生 UI 控件叠加——进度条、选项卡、表单。LeaferJS 做 Canvas 内容渲染——图表、画布、海报。两个层在 WebView 内不同 `<canvas>` / `<div>` 区域各自工作。

---

## 4. 风险

| 风险 | 等级 | 缓解 |
|---|---|---|
| **需求错配**：引入后半年无真实场景使用 | 中 | 先定明确接入场景再引入——"agent 生成海报/图表，用户在画布里调"是一个可演示的 e2e |
| **Canvas 无障碍**：Canvas 内容对屏幕阅读器不可见 | 低 | MOV 是视觉交互工具，非无障碍优先场景；可在场景图 JSON 层加 aria 标注备查 |
| **LeaferJS 社区 bus 因子** | 低 | MIT 协议 + 五年维护 + 商业赞助生态（PxGrow 12 金牌赞助商），不依赖单一维护者 |
| **与 WebView 主界面冲突** | 低 | Canvas 嵌入在房间消息卡片区域，不替换主界面 DOM |
| **包大小**：70KB gzip 虽小但仍增加 | 极低 | 可延迟加载（首次用到 `canvas.render` 时动态 import） |

---

## 5. 不适用场景（明确不做）

| 场景 | 原因 |
|---|---|
| 替代 HTML 页面渲染 | LeaferJS 是 Canvas 绘图引擎，不是 HTML 渲染器 |
| 替代 SDUI 原生 UI 控件 | Canvas 无原生控件语义，表单/输入框仍走 Compose |
| 替代 PDF 预览 | 已有原生 PDF 预览，不需要 Canvas 重新实现 |
| 作为全应用 UI 框架 | 主界面不走 Canvas，与 MOV WebView 架构冲突 |

---

## 6. 建议

### 结论：推荐引入，但不现在

**推荐理由**：技术上完全适合 MOV——零 Java 依赖、MIT 协议、70KB、直接把"agent 生成 HTML"升级为"agent 生成可编辑画布"。与 MOV 五条不可变规则无冲突，与 DESIGN_TECH_KERNEL 三层无重叠。

**延迟理由**：当前棋盘没有需要 Canvas 2D 渲染引擎的已排期任务。P1 做浏览器协议、P2 做 AgentLoop 稳定性、P3 做情境图谱——三路都跟 Canvas 渲染无关。盲目引入 = 70KB 死代码。

### 推荐接入路径

```
触发条件: 有一个明确的 product requirement——
         "agent 生成的可视内容（海报/图表/画布）用户可以直接拖拽编辑"

接入步骤:
  1. hermes-shell.html 动态 import leafer-ui（首次用到才下载）
  2. 新工具 canvas.render：收场景图 JSON → WebView 渲染 Canvas + Editor
  3. MovRender 新增 canvas-card 投影类型
  4. Editor 变更 → _movEvent → journal 闭环
  5. e2e: agent 生成一张海报 → 用户拖拽改布局 → agent 基于变更后 JSON 继续改
```

### 短期可做的准备

1. agent 工具 schema 里预留 `canvas.render` 和场景图 JSON 契约（不实现，只占位）
2. 在 `docs/ARCHITECTURE.md` 的依赖清单里标注"LeaferJS 预选（Canvas 2D）"
3. 如果一个 sprint 内 agent 三次以上生成 HTML 视觉内容且用户要求"能不能拖一下"，立即启动接入

---

*评估人：P3 储备程序员。审查后如批准，接入时间点由创始人决定。*
