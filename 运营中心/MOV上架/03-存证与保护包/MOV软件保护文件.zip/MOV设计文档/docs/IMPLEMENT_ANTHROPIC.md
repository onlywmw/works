# 批 1 实施计划：Anthropic Messages 协议（精确到步骤 + 验证标准）

> 日期：2026-08-04 ｜ 分支：feat/dual-brain-upgrade ｜ 基于 main 实际代码
> 目标：AiClient 支持 `anthropic-messages` 协议（非流式 + 流式），双脑可接 Anthropic 兼容端点
> 关键前提（已确认）：**AgentLoop 用非流式 `chat()` + 计划解析**（工具走 `tool.execute`），不是 OpenAI tool_calls 循环——批 1 重点是 AiClient 协议层，不动 AgentLoop 工具执行。

## 涉及实际文件（main）

| 文件 | 关键位置 |
|---|---|
| `app/.../ai/AiProviderConfig.java` | provider 常量 `:29-33`、KEY_* `:22-27`、getBaseUrl `:126-137`、getModel `:151-162` |
| `app/.../ai/AiClient.java` | `chat()` `:148-245`、`attemptOnce()` `:371-491`、`buildBody()` `:493-509`、`extractContent()` `:511-521` |
| `app/.../ai/SseParser.java` | `Event` `:19-31`、`feed` `:41-52`、`handleLine` `:65-108`、`toolCallJson` `:111-114` |
| `app/.../agent/AgentLoop.java` | `brain.chat()`（AiClient 非流式）——不改 |

---

## Step 1：AiProviderConfig 加 anthropic provider + protocol

**文件**：`AiProviderConfig.java`

改动：
1. 加常量 `:33` 后：`public static final String PROVIDER_ANTHROPIC = "anthropic";`
2. `getBaseUrl()` `:129` switch 加分支：`case PROVIDER_ANTHROPIC: return "https://api.anthropic.com/v1";`
3. `getModel()` `:154` switch 加分支：`case PROVIDER_ANTHROPIC: return "claude-sonnet-4-6";`
4. `getProviderDisplayName()` `:196` 加分支：`case PROVIDER_ANTHROPIC: return "Anthropic";`

**验证标准**：
- 单测（`AiProviderConfigTest`）：`applyPreset("anthropic")` 后 `getBaseUrl()` = `https://api.anthropic.com/v1`、`getModel()` = `claude-sonnet-4-6`、`getProviderDisplayName()` = `Anthropic`
- 既有 provider（deepseek 等）默认值不回归

## Step 2：AiClient 协议分支（URL + body 构造）

**文件**：`AiClient.java`

改动：
1. 加判断方法（`getBaseUrl()` 附近）：`private boolean isAnthropic()` —— `"anthropic".equals(getProvider())`
2. `chat()` `:151-152`：URL 按协议
   - openai：`baseUrl + "/chat/completions"`
   - anthropic：`baseUrl + "/v1/messages"`
3. `buildBody()` `:493` 加 anthropic 分支：`buildAnthropicBody(userText, history, stream)`
   - body：`{model, max_tokens: 4096, system: <systemPrompt>, messages:[{role, content}...], stream}`
   - messages 首条是 system（不重复放 system 字段外）；user/assistant 历史照搬

**验证标准**：
- 单测（`AiClientTest`）：anthropic provider 时 URL 尾部 = `/v1/messages`；body 含 `system` 字段 + `messages` 数组 + `max_tokens`；openai 时保持 `/chat/completions` + 原 body（不回归）

## Step 3：AiClient anthropic 非流式响应解析

**文件**：`AiClient.java`

改动：
1. `chat()` `:205-220`：协议分支解析
   - openai：现有 `choices[0].message.content`
   - anthropic：`json.content[]` 数组，拼接 `type=="text"` 的 `text` 字段
2. 加方法 `extractAnthropicContent(JSONObject json)`：遍历 `content` 数组 → 收集 text；`stop_reason` 可留作 `tool_use` 判断
3. `usage` 解析 `:224-228`：anthropic 用 `input_tokens`/`output_tokens`（兼容处理）

**验证标准**：
- 单测：anthropic 响应 `{"content":[{"type":"text","text":"你好"}],"stop_reason":"end_turn"}` → content="你好"；usage 用 input_tokens/output_tokens 正确计 tokens
- openai 响应解析不回归

## Step 4：SseParser 扩展 anthropic SSE 事件（流式 UI）

**文件**：`SseParser.java`

改动：
1. `Event` 加字段或新类：支持 anthropic 事件类型（`type`）
2. `handleLine()` `:65` 加 anthropic 分支（按 data JSON 的 `type` 字段识别）：
   - `content_block_delta` + `delta.type=="text_delta"` → 产出 token（`delta.text`）
   - `content_block_start` + `content_block.type=="tool_use"` → 记录 `tool_use` 块（id/name）
   - `content_block_delta` + `delta.type=="input_json_delta"` → 累积 tool_use input
   - `message_stop` → done
3. 保留 openai 分支（现有逻辑）——按 `data` 里有无 `choices` 区分协议

**验证标准**：
- 单测（`SseParserTest`）：anthropic 事件流（text_delta 增量 / tool_use 块 start+delta / message_stop）正确解析；openai 流不回归

## Step 5：全量回归

**验证标准**：
- `./gradlew assembleDebug test` 全量绿（800+ tests，causal/journal/tool 不回归）
- 四数报告 tests/skipped/failures/errors

## Step 6：真机验证（平板）

**验证标准**：
- 平板配置 anthropic 端点（真实或本地 Anthropic 兼容 server）
- 房间发任务 → AgentLoop 走 anthropic 协议 → 回复正常 + UI 流式显示
- logcat 见 `/v1/messages` 请求 + anthropic 响应解析
- 切回 deepseek（openai）→ 不回归

---

## 风险与注意

| 风险 | 缓解 |
|---|---|
| anthropic 与 openai 请求/响应格式差异 | 协议分支在 AiClient 内部隔离，`isAnthropic()` 单一判断 |
| `max_tokens` 硬编码 4096 | 可后续从 ModelConfig 读，v1 固定值够用 |
| 流式 UI 双协议 | SseParser 按 data 有无 `choices` 自动识别，openai 零影响 |
| tool_use 完整支持（多轮） | v1 只做解析 + 记录，多轮 tool_use 循环留批 2/后续（MOV 计划模式不强依赖） |

---

## 验收结论

- **2026-08-04 验收（按查验表标准：变异测试 + 全量四数）**
  - 变异 3 杀（ACCEPTANCE_PLAYBOOK 招 2）：
    - 批1：`isAnthropic()` 恒 false → **AiClientTest 14 tests, 1 failed**（暴露测试缺口：buildAnthropicBody 直调绕过分支 → 补强 `buildBody_anthropicProvider` 测试后抓到）
    - 批3：`cdpCommand` navigate 恒 null → **MovWebBridgeTest 7 tests, 1 failed**
    - 批2：`handlerFor` skill.echo 恒 null → **SkillActivatorTest 5 tests, 2 failed**
  - 全量四数：**883/18/0/0**（88 类，含批1/2/3 +24 测试）
  - 相关测试计数：AiClientTest 14 / SseParserTest 14 / SkillStoreTest 4 / SkillActivatorTest 5 / MovWebBridgeTest 7 / ToolRegistryTest 19 全绿
  - **真机待验**：Anthropic 协议跑通 / skill 释放+激活 / CDP 连真实浏览器（wb.* 工具）
