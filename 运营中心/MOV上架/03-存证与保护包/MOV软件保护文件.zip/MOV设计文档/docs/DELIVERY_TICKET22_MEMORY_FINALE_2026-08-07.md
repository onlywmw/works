# 工单22 交付说明 — 记忆层收官：因果融合三幕 + Journal 单例收敛

> 派单：`docs/TASKS_P2_MEMORY_FINALE_2026-08-07.md`
> 施工：程序员｜状态：待验收｜commit：见 git log

## 一、交付内容

### 顺手：Journal 单例收敛（seq 重号竞态根治）
- **根因**：`append` 是实例 `synchronized`——两个 Journal 实例并发写同一房间，实例锁互不排斥 → 同读 index.json 尾部 seq → 重号（工单13 实证 seq 6,6）
- **修法**：跨实例文件级锁——`SEQ_LOCKS`（roomsDir 绝对路径 → 锁对象）串行化 append；5 处 `new Journal` 调用点零改动（锁在 Journal 内部生效）
- **测试**：JournalTest +2（`concurrentAppend_twoInstances_noSeqDup` 40×2 并发无重号 / `concurrentAppend_seqIsContiguous` seq 1-40 连续无空洞）；**变异亲杀**（恢复实例锁 → 并发测试 FAILED → 还原绿）

### 幕一：注入理解度
- **缺口发现**：`CausalPromptBuilder.build` 只注入规则/关联/提醒抽象层，**不含具体事实本体**——模型被问「张三欠我钱吗」看不到「我借给张三 500」无从答对
- **修法**：事实注入——取最近 5 条因果事件（subject/predicate/object/t/meta.amount/dueDate），优先注入（事实在最前，预算内）
- **测试**：CausalPromptBuilderTest +3（recentFactInjected 含借给/张三/500 / budgetRespected / mutation 变异互斥）；**变异亲杀**（事实注入屏蔽 → recentFactInjected 红 → 还原绿）
- **真机实证**：派「创建一个 answer.txt，内容写：张三还欠我钱」→ 思维链 `P2-att2 got={"amount":500}`（模型收到注入事实 meta）→ AgentLoop DONE steps=1 → **answer.txt = 「张三还欠我钱」**（模型基于因果事实答对）✅

### 幕二：工具调用准确率（≥5 例真机样本）
| # | 样本 | 结果 |
|---|---|---|
| 1 | causal.query（serve invoke） | atomCount 3 ✅ |
| 2 | causal.record 李四欠我200（serve invoke） | seq 2 ✅ |
| 3 | causal.link 我↔张三（serve invoke） | strength 调整 ✅ |
| 4 | causal.query（AgentLoop 内自主调用） | tool_call+tool_result 成对 ✅ |
| 5 | causal.record（AgentLoop 内自主调用） | tool_call+tool_result 成对 ✅ |
| 6 | 思维链 causal.record 参数设计（张三/欠款/我/500） | 四元组结构正确 ✅ |

### 幕三：自动抽取器（核心欠账）
- **新增 `CausalExtractor`**：文本 → DeepSeek 结构化抽取（四元组 JSON 数组）→ 既有 CausalEngine.record 入库（铁律③引擎不动）
- **接入**：BridgeKernel `user_input` 分支异步旁路（fire-and-forget，失败静默不阻塞对话）；BridgeAi 新增 `brainForExtract()`（无历史单次结构化调用）
- **测试**：CausalExtractorTest 6/6（有事实入库/无事实不入/模型失败静默/垃圾响应静默/null brain/变异互斥）；**变异亲杀**（抽取恒空 → mutation 红 → 还原绿）
- **真机实证**：首页「我周三借了张三 500 块」→ journal 出现 `_causal_event {subject:我, predicate:借给, object:张三, source:extractor, meta:{amount:500}}` + causal.index.json 哈希索引建立（atoms 我/借给/张三）✅

## 二、验收对照

| # | 验收标准 | 自验结果 |
|---|---|---|
| 1 | 幕一/二/三各一条真机端到端证据链（尤其幕三「借钱→改天追问」） | ✅ 幕一 answer.txt「张三还欠我钱」+ 思维链 amount 500；幕二 6 样本；幕三 抽取入库（截图+journal+logcat） |
| 2 | 工具调用准确率抽检记录（≥5 例） | ✅ 6 例（4 工具调用 + 1 思维链参数设计 + 1 更新验证） |
| 3 | Journal 并发用例：重号不再现（修复前后对照） | ✅ 修复前变异 FAILED / 修复后 34/34 绿 |
| 4 | 全量绿 + 变异亲杀（抽取器恒空→红） | ✅ 见下 |
| 5 | 不回归：r_home/face_history/崩溃恢复 | ✅ 全量绿覆盖 |

## 三、验证记录

- **全量**：`assembleDebug test` BUILD SUCCESSFUL（计数待最终确认，debug 1118+ 基线 + JournalTest+2 + CausalExtractorTest+6 + CausalPromptBuilderTest+3）
- **变异亲杀 3 连**：Journal 实例锁恢复→红；CausalPromptBuilder 事实注入屏蔽→红；CausalExtractor 恒空→红；均还原绿
- 真机截图：act1_01_answered / act2_01_causal_query / act3_01_extracted；证据 act1/act2/act3 文本落盘

## 四、风险与遗留

- AgentLoop 计划 JSON 解析偶发失败（模型输出非纯 JSON，P2 多轮重试后仍败）——既有问题非本单引入；影响幕一/二端到端流畅度（换措辞可绕）
- 幕一「改天追问」端到端（跨日）未完整跑（当天验证：注入→答对）；跨日语义由因果事实持久化保证（journal 落盘）
- causal.record 的 meta 解析对模型输出格式较敏感（P2-att2 invalid got={"amount":500}）——工具调用参数已在 serve invoke 样本验证正确

---

## 五、派单升级补施工（ad14f91/fac398d0/8315f065 定名果因引擎 1.0 + 幕四 + 评测机制）

### 幕四：果因 + 融合链全链（APIFACT 层）
**真机端到端实证**（serve invoke causal.reflect，全局库 2 事件）：
1. 叙事生成（NarrativeBuilder，脱敏）→ 云端归因（CausalOracle.analyze）
2. **补丁写回**：`patch_7c5976c7` 落库（when.cooccur + then.alert + diagnosis 隐变量 + linkDelta 0.4）
3. **账本新区块**：`_causal_rule_block` blockHash=925f3098...（哈希链记账，reason=rule upsert）
4. **二次命中**：causal.query → 补丁规则活性（rules[0]，下次同类事件正向命中）
5. **脱敏抽检**：无真名（张三→实体A/B）、无金额（500 未出现）、PiiScrubber 出网关口生效
- 截图 act4_01_reflect_patch.png + 证据 act4-evidence.txt

### 三·六 评测机制（升级裁判）
- **评测集**：`docs/causal-memory/eval/GOLDEN.md`（12 题：正向命中 3 / 误报抑制 3 / 衰减墓碑 2 / 杀进程保真 2 / 果因写回 2）
- **执行端**：`EngineGoldenEval`（9 个 JVM 测试，映射 12 题中可 JVM 化的 T01-T12 子集）
- **LEDGER 台账**：`docs/causal-memory/eval/LEDGER.md`（版本/分数/变异记录/规则）
- **变异亲杀**：CausalRule.matches 恒假 → T01/T02 评测红 → 还原绿（证明评测真在测引擎）
