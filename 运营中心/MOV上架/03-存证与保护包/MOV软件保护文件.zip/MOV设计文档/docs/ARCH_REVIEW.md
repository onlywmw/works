# MOV 架构评审（2026-08-02，v2 大神复核后）

> 状态：✅ 评审 + 大神复核完成（7 条 → **6 收、1 划、3 条修正**）
> 依据：2026-08-02 全量代码扫描（143 Java + 1 Kotlin / 15 JS 模块 / 142 桥方法 / ~107 工具 / 610+ 测试）
> 性质：架构建议，未动代码。本文 = 大神复核后的定稿，供排期用。

---

## 一、整体评价

**地基是对的**：
- Journal 事件溯源（append-only，唯一消息真理源）
- 一表两脑（ToolRegistry + FastWorker 快脑 / HeavyWorker 慢脑）
- 指令优先路由（IntentParser → CapabilityExecutor，未命中 → AI）
- proot 内嵌 Ubuntu 抽象层、OCR 线独立脚本隔离、workflows/context 纯 JVM 可测

**组织层有债务**：根包职责黑洞、巨型前端文件、文档-代码漂移（本评审 v1 自己也漂了一处——#5 serve 已完成，见下）。

---

## 二、问题与建议（大神判定后定稿）

### 1. 根包 52 类 = 职责黑洞 — ✅ 收，挑窗口做

**现状（实测）**：根包 `com.hermes.android` 52 类——Activity 壳、IntentParser→CapabilityExecutor（30 能力）、StorageManager、场景卡、ConnectWeb 浏览器、10 个 ToolProvider、PaymentGate/PayQRRelay、Workflows 集成壳、DeviceTriggerManager 全挤在一起。

**建议**：按职责拆子包（`capability/`、`scene/`、`browser/`、`toolprovider/`、`security/`）。
**大神修正**：方向对、半天量、610+ 测试兜底。但 **P1/P2/P5/P6 多线并行，52 类移动 = 大面积 merge 冲突**——必须挑**串行窗口**做（各线当前幕收尾后，冻一天做）。
**排期**：等一个无并行线的窗口。

### 2. 场景卡 / 集成壳位置归位 — ✅ 收，随 #1 同窗口

**现状**：DramaSource 在 `agent/`，TrainSource/MusicSource 在根包；workflows 集成壳 `Workflows` 在根包（引擎在 `workflow/`）。
**建议**：归位统一。**随 #1 同窗口做**（都是机械移动，一起动 merge 面最小）。

### 3. newface.js 3202 行拆分 — ⚠️ 收，但排 №7 之后

**现状**：`newface.js` 165KB/3202 行，新脸 + 专家模式两套 UI 挤在一个文件；已抽 4 个纯逻辑 node 可测模块，DOM 层未拆。
**大神修正**：**现在别拆**——P1 正在做「无感工作态」（№7）改的就是这个文件，现在拆 = 双重触碰 merge 地狱。**排在 №7 落地后**。
**排期**：P1 №7 之后。

### 4. 架构自检脚本 — ✅ 收，与 H1 合为一族

**现状**：CLAUDE.md 写「7 子桥/70 接口/12 模块/271 测试」，实测 9/142/15/610——已漂移。
**大神修正**：**别搞两个脚本**——H1 刚做的一致性单测（id ⊆ 注册表）和这个是同族。做成**「一致性测试家族」**：id 一致性（H1）+ 数字一致性（桥方法/类数/JS 模块数/测试数 diff 架构文档）。
**建议**：`tools/arch-check.sh` 并入一致性测试家族，每轮交付跑。

### 5. HeavyWorker serve 化升硬里程碑 — ❌ 划掉（已完成）

**现状**：v1 建议 serve 化列为硬里程碑。
**大神判定**：**已完成**——M1-M3 已验收（巡检#37/38，serve 常驻 + SSE 已跑通）。这条不是「建议升里程碑」是「已在实施」。
**顺带说明**：v1 评审信息滞后（文档漂移的活例证）。HeavyWorker 已走 serve 路径（`HermesClient`/`HermesServeConfig`）。

### 6. 桥 142 方法收敛 Kernel — ⚠️ 收，改增量门禁（不全量重写）

**现状**：BridgeFactory 115 @JavascriptInterface + 9 子桥 = 142 桥方法，每加一能力加一方法。
**大神修正**：全量收敛 = 1-2 天中等风险。改法：**新能力一律走 Kernel（postCmd/query），老方法只读冻结不迁**——同样抑制膨胀，成本降一个量级，零回归风险。
**建议**：增量门禁（新能力走 Kernel 是硬规则），老方法冻结。

### 7. Robolectric — ⚠️ 最后做，别当答案

**现状**：610+ 测试全 JUnit，前端 JS 单测仅 newface-*.js 纯逻辑，app 无 Robolectric；vault 暴露「JVM ≠ 设备」判例。
**大神修正**：vault 判例的教训是**「设备路径必测」不是「上 Robolectric」**——AndroidKeyStore 在 Robolectric 里同样不完整模拟。**真机是底线，Robolectric 只是补充**。最后做，别当答案。

---

## 三、行动清单（大神复核后）

| 动作 | 判定 | 排期 |
|---|---|---|
| #1 根包拆包 + #2 归位 | 收 | 挑串行窗口（各线收尾后冻一天） |
| #4 一致性测试家族（H1 id + 数字 diff） | 收 | 近期（与 H1 合一） |
| #6 桥增量门禁（新能力走 Kernel） | 收（改） | 近期（从下一个新能力开始） |
| #3 newface 拆分 | 收（改） | P1 №7 之后 |
| #7 Robolectric 补充 | 收（改） | 最后做 |
| #5 serve 化 | 划掉 | 已完成（M1-M3 验收） |
| Kotlin 迁移策略 | 排除 | 用户明确不做 |

---

## 四、已排除项

- **Kotlin 迁移策略**：用户明确不做（ModelToolProvider.kt 单文件，不扩不迁不定策略）。
- **#5 serve 化**：已完成（巡检#37/38，serve 常驻 + SSE 已跑通），非待办。

---

## 五、待排期确认 → **已拍板（验收人 2026-08-02）**

1. **串行窗口**：等 **P2 M4（serve 韧性）+ P5 v1.1（钥匙轮换/GATE_BUSY）** 收尾即动 #1+#2——拆包是纯 Java 动作，**P1（newface.js 无感工作态）不受影响照常并行**。窗口=M4 验收后。
2. **一致性测试家族归属**：**P2**（管线，H1 已是其交付；数字一致性并入同族）。
3. **桥门禁起点**：下一个真实新能力起——**OCR llama-server 对联接口**（P6 llama-server 部署的新桥）——新接口必走 Kernel 信封，老 142 方法只读冻结。
