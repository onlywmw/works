# MOV 决策日志 + 规则热更新 设计文档 v2

> 评审修正: 移动端本地文件不可信, 安全红线必须硬编码; 砍 FileObserver 防并发; 复用 Journal 不加新文件
> 日期: 2026-07-28

---

## 1. 规则分级管理 (RulesManager)

### 设计原则

**本地文件不可信**。与 OPA 的根本差异: OPA 跑在服务端, 配置文件有权限管控; MOV 跑在用户手机,
本地文件任何人都能改。因此不能照搬 OPA 的"所有规则都可热更"模式。

### 三级规则

```
┌─────────────────────────────────────────────┐
│ 红线 — 硬编码, 不可被 JSON 覆盖             │
│ rm -rf /  mkfs  dd  shutdown  reboot ...    │
│ 写在 Java static final Set 里, 永不从文件读  │
├─────────────────────────────────────────────┤
│ 黄线 — JSON 可配置, 有默认值兜底            │
│ curl wget pip install 等需确认命令           │
│ 受保护的文件路径 (*.key *.pem 等)             │
│ 禁用的设备能力                               │
├─────────────────────────────────────────────┤
│ 绿线 — JSON 可配置, 有默认值兜底            │
│ max_steps  max_exec_ms  timeout             │
│ auto_approve_tools                           │
└─────────────────────────────────────────────┘
```

### 文件格式 `files/rules/rules.json`

```json
{
  "version": 1,
  "shell": {
    "require_confirm_patterns": ["curl", "wget", "pip install"],
    "max_timeout_sec": 600
  },
  "file": {
    "protected_paths": [".git", "secret", ".env", "*.key", "*.pem"],
    "max_write_size_bytes": 1048576
  },
  "device": {
    "disabled_capabilities": ["sms.send", "contact.write"],
    "require_confirm": ["app.install", "camera.capture"]
  },
  "agent": {
    "max_steps": 12,
    "max_exec_ms": 600000,
    "auto_approve_tools": ["file.read", "file.list"]
  }
}
```

注意: **没有** `deny_patterns` 字段。破坏性命令红线硬编码, 不暴露给 JSON。

### RulesManager 架构

```java
class RulesManager {
    // 红线 — Java 常量, 永不从文件读
    static final Set<String> REDLINE_SHELL = Set.of(
        "rm -rf", "mkfs.", "dd if=", "> /dev/sda", "chmod 777 /",
        "shutdown", "reboot", "poweroff", "halt", "init 0", "init 6"
    );

    File rulesFile;
    volatile RulesConfig current;   // volatile 保证线程间可见
    long lastModified;

    void init(Context ctx);         // Application.onCreate 调用一次
    RulesConfig load();             // 读文件解析, 失败返回默认值
    RulesConfig loadIfChanged();    // agent_start 时调用: 文件变了才重读
}
```

### 加载策略: 任务级, 不实时

- **启动时**: `init()` 加载一次。
- **每个 agent 任务开始时**: `loadIfChanged()` 检查 `lastModified`, 文件有变化才重新解析, 解析结果赋给 `volatile current`。
- **不加 FileObserver**: 不需要"正在执行时热更"。
- **并发安全**: `volatile` + 每次任务开始才换实例, 任务执行期间规则不变。不存在 AgentLoop 跑到一半读到脏数据的问题。

### 解析失败兜底

- 文件不存在 → 自动写默认值
- JSON 格式错误 → Log.w + 保持旧值
- 字段缺失 → 用默认值填充
- 类型错误 → 用默认值

### 验收标准

| # | 场景 | 预期 |
|---|------|------|
| 2.1 | 首次启动 | `files/rules/rules.json` 自动创建, 写入默认黄/绿线规则 |
| 2.2 | 改 rules.json 的 max_steps 为 5 | 下一个 agent 任务最多 5 步 |
| 2.3 | 改 rules.json 的 require_confirm_patterns | 匹配的命令执行前弹确认 |
| 2.4 | 试图在 JSON 里加 `rm` 为白名单 | 无效 — `rm` 在 Java 红线里硬编码, JSON 管不了 |
| 2.5 | 改非法 JSON | Log.w + 规则保持旧值, agent 正常运行 |
| 2.6 | 不需重编译 APK | 改 JSON → 下次 agent 任务生效 |
| 2.7 | Agent 执行中改文件 | 不影响当前任务, 下次任务才生效 |

---

## 2. 决策日志: 复用 Journal

### 设计原则

不加新文件。现有:
- `journal.jsonl` — UI 回放渲染 (已有, 每房间)
- `errors.jsonl` — 错误追踪 (已有, 全局)

再加 `decisions/YYYY-MM-DD.jsonl` 会三份 I/O, 拖慢 agent 速度, 字段大量重复。

### 方案: Journal 加 `audit` 标记

在 journal.jsonl 里, 需要审计的关键事件加 `"audit": true`:

```json
{"seq":1,"ts":1753783200,"type":"agent_start","audit":true,"payload":{"goal":"用户目标"}}
{"seq":2,"ts":1753783201,"type":"phase","payload":{"phase":"讨论中"}}
{"seq":3,"ts":1753783202,"type":"step","payload":{"name":"file.read"}}
{"seq":4,"ts":1753783210,"type":"agent_deliver","audit":true,"payload":{"summary":"交付摘要"}}
```

**加 audit 的事件类型**: `agent_start`, `agent_deliver`, `agent_fail`, `agent_stopped`,
`shell.exec`(payload 含 cmd 摘要), `app.package`。

不加 audit 的: `phase`, `step`, `token`, `note`, `_telemetry` 等高频/内部事件。

### 导出时过滤

设置页 [导出诊断日志] 时, 不改现有导出逻辑, 只是多一步:
从 journal.jsonl 里 grep `"audit":true` 的行, 打包进诊断报告。

计算压力从"运行时每条都多写一个文件"转移到"导出时过滤"。Agent 执行时 I/O 开销不变。

### 验收标准

| # | 场景 | 预期 |
|---|------|------|
| 1.1 | agent_start | journal 里该事件含 `"audit":true` |
| 1.2 | agent_deliver | journal 里该事件含 `"audit":true` |
| 1.3 | agent_fail | journal 里该事件含 `"audit":true` + reason |
| 1.4 | shell.exec 步骤 | journal 的 step 事件含 `"audit":true` + cmd 摘要 |
| 1.5 | 导出诊断日志 | 自动含所有 audit=true 的事件 |
| 1.6 | 普通步骤 (file.read/phase/note) | 不带 audit 标记, 不增加导出噪音 |
| 1.7 | 写入失败不崩 | Journal.append 已有 try-catch 兜底, 不加 audit 也不会崩 |

---

## 实施顺序

```
20 分钟: RulesManager (红线硬编码 + 黄绿线 JSON + 任务级加载)
10 分钟: AgentLoop/BridgeAi 里 agent_start/log 加 audit 标记
10 分钟: ErrorReporter.export 加 journal audit 过滤
 5 分钟: 编译安装验收
```
