# 提交清单 2026-07-30 — 新脸追剧链路收尾

> **开工前必读**：环境信息（仓库路径、构建命令、adb、平板序列号）全在
> `C:\Users\Administrator\MOV-APP\ENV_SETUP.md`，先读它。最小集合：
> ```bash
> cd /c/Users/Administrator/MOV-APP
> export JAVA_HOME="/c/Program Files/Android/Android Studio/jbr"
> ./gradlew assembleDebug && ./gradlew test
> ```
> adb：`~/AppData/Local/Android/Sdk/platform-tools/adb.exe -s 21770d7d`，包名 com.hermes.android。
>
> 任务：工作区有一批已**真机验收通过**的改动未提交。按下面拆成 3 条 commit，提交后我来验收。
> 分支 main，基线 `1e08aff`。
> 纪律：逐条提交、每条后构建不红再提下一条；不要 `git add -A` 一把梭。

## 现状（git status 已核对）

修改：AndroidManifest.xml、assets/js/bridge.js、assets/js/newface.js、agent/DramaSource.java、bridge/BridgeAi.java、bridge/BridgeDevice.java、bridge/BridgeFactory.java、bridge/BridgeKernel.java
新增：DouyinWebActivity.java、agent/VideoSourceRegistry.java、assets/video_sources.json、scripts/subset-fonts.py

## Commit 1 — `feat(NEWFACE): 抖音连接 v1.1—扫码会话+直进视频搜索+状态栏适配+原生触摸切tab`

文件：
- `app/src/main/java/com/hermes/android/DouyinWebActivity.java`（新）
- `app/src/main/AndroidManifest.xml`（注册 DouyinWebActivity）
- `app/src/main/java/com/hermes/android/bridge/BridgeDevice.java`（douyinStatus/openDouyinLogin/openDouyinSearch + openDeepLink 显式 setPackage）
- `app/src/main/java/com/hermes/android/bridge/BridgeFactory.java`（新方法接线）
- `app/src/main/assets/js/bridge.js`（B.douyinStatus/openDouyinLogin/openDouyinSearch）
- `app/src/main/assets/js/newface.js` **只挑抖音相关 hunk**：openDouyin()、renderConnectCard()、renderDramaOptions 末尾的抖音通道卡
  - 用 `git add -p app/src/main/assets/js/newface.js`，只 stage 上述 hunk

提交后：`./gradlew assembleDebug` 必须绿。

## Commit 2 — `feat(NEWFACE): 视频源注册表+豆瓣/B站/西瓜/咪咕/乐视下架`

文件：
- `app/src/main/java/com/hermes/android/agent/VideoSourceRegistry.java`（新）
- `app/src/main/assets/video_sources.json`（新，11 源留档）
- `app/src/main/java/com/hermes/android/agent/DramaSource.java`（setRegistry + 按注册表过滤 + tryBilibili HTML 路径）
- `app/src/main/java/com/hermes/android/bridge/BridgeKernel.java`（video_sources query + face_search_drama 注入注册表）
- `app/src/main/java/com/hermes/android/bridge/BridgeAi.java`（faceSearchDramaAsync 注入注册表——**两处注入点缺一不可**）
- `app/src/main/assets/js/newface.js` **剩余 hunk 中的注册表相关**：renderSourcesSection()、toggleSource()

提交后：`./gradlew assembleDebug test` 必须绿。

## Commit 3 — `refactor(NEWFACE): 视频源管理迁入设置页`

文件：
- `app/src/main/assets/js/newface.js` **最后剩余 hunk**：openDrawer settings 分支、openSettings() 改开设置页、toggleSource 刷新目标改 settings

## scripts/subset-fonts.py

- 字体子集化工具，属 Phase 1 遗留。单独第 4 条：`chore(tools): 字体子集化脚本 subset-fonts.py`。也可并入你认为合适的提交，但 commit message 里要提到。

## 验收标准（我逐条核）

1. `git log --oneline -4` 看到上述 3(+1) 条，顺序正确
2. `git status` 干净（除 e2e 截图等本就不入库的内容）
3. 每条 commit 的 `git show --stat` 文件清单与上面一致——**尤其 newface.js 不许整文件塞进一条**
4. HEAD 构建 + 单测全绿：`./gradlew assembleDebug test`
5. 装机回归（我做，不用你跑）：抽屉「我的」无视频源区、齿轮 → 设置页有源管理、说「我要追xx」进抖音搜索结果

## 注意

- newface.js 一个文件横跨三条 commit，必须 `git add -p` 分 hunk；实在分不清的 hunk 往**后**一条 commit 放，不许往前塞
- 不要动 docs/ 下的验收截图（v11/v12 系列是我验收留档，如已被 .gitignore 忽略则不管）

## 追加任务（2026-07-30 验收后）：收尾提交 + 推送

前面 5 条验收**已全过**（commit 顺序/文件清单/301 单测/装机回归三项，截图留档 v13-accept-douyin2.png）。剩两件：

1. **补一条 docs commit**：工作区现有 3 个未提交的文档改动（验收人加的，直接收编，不用改内容）：
   - `ENV_SETUP.md`（仓库路径修正 + 补单测命令）
   - `docs/COMMIT_PLAN_2026-07-30.md`（开工前必读块 + 本追加任务）
   - `docs/TASKS_P2_2026-07-30.md`（开工前必读块）
   - commit message：`docs: ENV_SETUP路径修正+清单环境指引+验收结论`
2. **推送 origin main**：本地已领先 30 条。推送前 `./gradlew assembleDebug test` 再绿一次，然后 `git push origin main`。

**验收标准**：
- [ ] `git status` 全干净（除验收截图等本就不入库的）
- [ ] `git log origin/main..HEAD` 为空（30+1 条全部上远端）
- [ ] 推送后我 `git fetch` 核对远端 HEAD 与本地一致
