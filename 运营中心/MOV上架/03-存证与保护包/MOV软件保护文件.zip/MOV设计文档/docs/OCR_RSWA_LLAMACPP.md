# OCR R-SWA 在 llama.cpp 的实现预研（b10216 钉版）

> 状态：✅ P6 预研完成（源码精读 + 方案 + 验证，纯桌面零真机，未改任何 ocr/ 代码）
> 日期：2026-08-01
> 依据：docs/TASKS_P6_RSWA_2026-08-01.md（P6 派单）、docs/OCR_RSWA_ANALYSIS.md（P0a 机制确认）、docs/DESIGN_OCR_MOBILE.md（OCR 全局设计 v2）
> 领地主权：本文只产设计文档。ocr/ 生产代码属 P4 领地，本文未触碰。
> 源码基准：**llama.cpp tag b10216**（`ggml-org/llama.cpp`）。本地镜像 `.ocr_p0/llmcpp/`，与官方 b10216 tarball 核对：`src/llama-kv-cache.cpp` / `src/llama-context.cpp` / `src/llama-graph.cpp` 三个关键文件 **sha256 逐字节一致**（4ee0076f / 2cf2ba8f / c83460b6）。**所有 文件:行号 引用均针对 b10216，勿拿 master 对号。**

---

## 〇、结论速览（给 P4 的 30 秒版）

1. **b10216 的 KV cache 是「连续大 tensor + cell 索引」模型**：每层 K/V 一个 `[embd, kv_size(cells), n_stream]` 张量（`llama-kv-cache.cpp:231-232`），kv_size = n_ctx。写入靠 `ggml_set_rows` + 每 token 的 cell 索引，读出靠 `ggml_view_4d` 切片。
2. **b10216 原生已有滑动窗口注意力（SWA）全套机制**：`llama_swa_type` 四种类型（`llama-hparams.h:20-25`）、掩码判定 `is_masked_swa`（`llama-hparams.h:386`）、SWA 物理淘汰（`find_slot` 复用过期 cell，`llama-kv-cache.cpp:1150`）、独立 SWA 缓存 `llama_kv_cache_iswa`（`llama-kv-cache-iswa.cpp:34`）。
3. **但原生 SWA ≠ R-SWA**：原生 SWA 的窗口从 **pos 0 开始**（`is_masked_swa` STANDARD 判定 `p1-p0 >= n_swa`，`llama-hparams.h:395`），早期 prompt/视觉前缀也会被掩和淘汰。**R-SWA 的关键差异 = 参考前缀常驻 + 只窗口化生成段**。
4. **deepseek2-ocr 当前在 b10216 上 = 全注意力**（无窗口、KV 随输出增长）：GGUF 转换未设 SWA 参数（`convert_hf_to_gguf.py` 无 swa 写入），走 `llama_model::create_memory` default 分支的普通 `llama_kv_cache`（`llama-model.cpp:2323-2343`），n_swa=0、swa_type=NONE。
5. **实现路线：掩码 + 物理淘汰双管齐下**（与 llama.cpp 原生 SWA 同一做法），核心是给 SWA 判定引入「参考前缀边界」——一处判定函数改动，掩码路径（`set_input_kq_mask_impl`）与淘汰路径（`find_slot`）同时生效。注意力算子、RoPE、graph 结构**全部不动**。
6. **恒定 KV 账本**：12 层 MHA（10 KV head × 128 dim）F16 → **60 KiB/token**。40 页 prefill 10923 token ≈ 640 MiB 前缀 + 7.5 MiB 窗口 = **恒定 ≈ 648 MiB**，不随输出长度增长。模型 q4_K_M 1.82GB + KV 648MiB + 激活，RSS ≤4GB 余量充足。

---

## 一、llama.cpp b10216 KV cache 源码精读

### 1.1 数据结构：`llama_kv_cells`（cell 元数据）+ `llama_kv_cache`（存储与管理）

**KV cache 的「单位」是 cell**（一个 token 在一层的一槽位），元数据与物理数据分离：

`llama_kv_cells`（`llama-kv-cells.h:32`，即 `llama_kv_cells_vec = vector<llama_kv_cells>`，`llama-kv-cells.h:535`）：

| 成员 | 类型 | 语义 | 位置 |
|---|---|---|---|
| `pos[i]` | `llama_pos` | 第 i 个 cell 的**绝对逻辑位置**；`-1` = 空 cell | `llama-kv-cells.h:464` |
| `ext[i]` | `llama_kv_cell_ext` | M-RoPE 的 2D 空间位置 (x,y)，普通模型恒 0 | `llama-kv-cells.h:466` + `llama-kv-cells.h:13-28` |
| `shift[i]` | `llama_pos` | 累积的位置平移量（KV 转移/压缩用） | `llama-kv-cells.h:484` |
| `seq[i]` | `bitset<LLAMA_MAX_SEQ>` | 该 cell 被哪些序列占用 | `llama-kv-cells.h:489` |
| `used` | `set<uint32_t>` | 非空 cell 索引集合（支持 min/max 快速查询） | `llama-kv-cells.h:462` |
| `seq_pos[s]` | `map<llama_pos,int>` | 序列 s 每个逻辑位置在缓存中的出现次数 → `seq_pos_min/max` O(log n) | `llama-kv-cells.h:499` |

cell 生命周期关键操作：
- `pos_set(i, p)`：把空 cell 写入位置 p，加入 `used`（`llama-kv-cells.h:395-403`）
- `rm(i)`：清空 cell（`llama-kv-cells.h:222-234`）
- `seq_rm(i, seq)`：移除序列占用，cell 变空则 `pos=-1`（`llama-kv-cells.h:238-258`）
- `pos_add/pos_div`：位置平移（shift 机制，用于 cache 压缩时重映射 pos，`llama-kv-cells.h:413-456`）

> **关键语义**：`pos` 是**逻辑绝对位置**（与 RoPE 位置一致），cell 的物理索引（`i`）与逻辑位置（`pos[i]`）**解耦**。环缓冲/淘汰 = 改 cell 归属，不动 pos 语义——这使「绝对位置 RoPE」天然成立（见 §1.3）。

`llama_kv_cache`（`llama-kv-cache.h:20`）持有一切：
- 每层一个 `kv_layer`（`llama-kv-cache.h:226`）：`k`、`v`（存储 tensor）+ `k_idx`（索引器/图像 token，本模型无）
- `v_cells`：cell 元数据（共享引用，`llama-kv-cache.h:284`）
- `v_heads`：每个 stream 的「环缓冲头」指针——**find_slot 从这里开始搜空 cell**（`llama-kv-cache.h:277`）
- `n_swa` / `swa_type`：SWA 窗口参数（`llama-kv-cache.h:249` / `:270`）

### 1.2 KV 存储布局与寻址（分配 / 写入 / 读出）

**分配**（`llama_kv_cache` 构造，`llama-kv-cache.cpp:64`）：

```
K: ggml_new_tensor_3d(ctx, type_k, n_embd_k_gqa, kv_size, n_stream)   // llama-kv-cache.cpp:231
V: ggml_new_tensor_3d(ctx, type_v, n_embd_v_gqa, kv_size, n_stream)   // llama-kv-cache.cpp:232
布局: [embd_gqa, kv_size(cells), n_stream(并行序列)]
```

- `kv_size` = 分配的 cell 数，**直接决定 KV 内存**（`llama-kv-cache.cpp:231` 的 ne[1]）
- kv_size 的来源：`llama_model::create_memory` 里普通 cache 传 `cparams.n_ctx_seq`（`llama-model.cpp:2334`），而 `n_ctx_seq = n_ctx`（单序列）或 `n_ctx / n_seq_max`（`llama-context.cpp:287-290`）
- 默认 KV dtype = **F16**（`llama-context.cpp:3504-3505`）
- 每层 cell 数相同，K/V 一次分配完毕，**不随输出增长**（预分配模型）

**写入**（每 decode 一步）：

```
ubatch → find_slot() 分配 cell 索引 sinfo.idxs[seq][i]      // llama-kv-cache.cpp:958
      → build_input_k_idxs/v_idxs 生成 k_idxs/v_idxs        // llama-kv-cache.cpp:1516/1548
      → cpy_k/cpy_v: ggml_set_rows(k, k_cur, k_idxs)        // llama-kv-cache.cpp:1457/1492/1513
      → apply_ubatch(): 更新 cell 元数据                    // llama-kv-cache.cpp:1190
```

- `cpy_k`（`llama-kv-cache.cpp:1425`）：`ggml_set_rows(ctx, k, k_cur, k_idxs)` —— 把本批 K 写到 k_idxs 指定的 cell 行。`cpy_v` 同（1460）。
- `apply_ubatch`（`llama-kv-cache.cpp:1190`）是**元数据写入点**：对每个 token 的 cell idx —— 若已被占则 `cells.rm(idx)` 并记录 `seq_pos_max_rm`（1222-1231）→ `cells.pos_set(idx, ubatch.pos[i])` 写新逻辑位置（1233）→ `seq_add` 挂序列（1243-1245）→ **purge 被覆写位置更小的残留**（1249-1268，保持该序列 [pos_min,pos_max] 连续不变量）。
- 头指针推进：`v_heads[strm] = sinfo.idxs.back()+1`（1271-1275）。

**读出**（构建注意力图时）：

- `get_n_kv`（`llama-kv-cache.cpp:1340`）：当前 batch 要看的 KV cell 数 = `used_max_p1()` 向上 pad 到 256（图复用稳定）。**n_kv 决定注意力扫多少个 cell**。
- `get_k/get_v`（`llama-kv-cache.cpp:1356/1376`）：`ggml_view_4d` 从存储 tensor 切出 `[head_dim, n_head_kv, n_kv, n_stream]` 视图，stride 按 `kv_size`（总 cell 数）——**只取前 n_kv 个 cell，物理布局不变**。

### 1.3 Attention mask 构建与 pos 传递

mask 在两类路径构建，判定逻辑一致（s0≠s1 / causal 未来 / SWA 窗口）：

**(a) 无 cache 路径（prefill 首段，KV 全量存时）** — `llm_graph_input_attn_no_cache::set_input`（`llama-graph.cpp:406`）：
- `fill_mask` lambda（`llama-graph.cpp:410`）：初始化全 `-INF`；逐 (query token i1, key token i0)：
  - `s0 != s1` → 掩（425-427）
  - causal 且 `p0 > p1` → 掩未来（430-432）
  - **SWA**：`is_masked_swa(n_swa, swa_type, p0, p1)` → 掩（435-437）
  - 否则 0（或 alibi 距离，439）
- 两个 mask tensor：`self_kq_mask`（causal，`fill_mask(...,0,NONE)`，450-454）+ `self_kq_mask_swa`（SWA 层专用，追加窗口，456-464）

**(b) 有 cache 路径（decode / prefill 续段）** — `llama_kv_cache::set_input_kq_mask`（`llama-kv-cache.cpp:1871`）→ 模板展开 `set_input_kq_mask_impl`（`llama-kv-cache.cpp:1684`）：
- 逐 (query token i, key cell j)：`cells.is_empty(j)` → 掩（1773-1775）；`!cells.seq_has(j, seq_id)` → 掩（1778-1780）；`causal && p0 > p1` → 掩（1793-1809）；**`is_masked_swa(n_swa, swa_type, p0, p1)` → 掩（1812-1815）**；否则 keep（1821）。
- 同序列 mask 行复用优化（1732-1757）：同一序列 token 的 mask 行先复制再局部更新（注意：SWA 会影响哪些 cell 可变，见 1784-1791 的 n_swa+32 记录范围）。
- mask tensor：`build_attn_inp_kq_mask`（`llama-graph.cpp:26-44`），形状 `[n_kv, n_tokens/n_stream, 1, n_stream]`，FA 用 F16 / 否则 F32。

**pos 传递与 RoPE**：
- `ubatch->pos[i]` 是**绝对逻辑位置**（`llama-batch.h:47`），直接进 cell（`llama-kv-cache.cpp:1233`）和 mask 判定（`p0/p1`）。
- deepseek2 属标准 RoPE（`llama-arch.cpp` `llm_arch_supports_sm_tensor` 组，含 DEEPSEEK2/DEEPSEEK2OCR）。
- **推论：RoPE 按绝对 pos 施加，与 cell 物理索引无关。环缓冲覆写不影响位置语义 —— R-SWA 要求的「绝对位置 RoPE、不因环截断复位」llama.cpp 天然满足。**

### 1.4 decode 每步 KV 写入点

`llama_context::decode`（`llama-context.cpp:1700`）主循环：
```
llama_batch → 拆成 ubatch 序列
  do {
      process_ubatch(ubatch, ...)     // llama-context.cpp:1320
          ├─ mctx->apply()            // llama-context.cpp:1321  ← KV 元数据写入（apply_ubatch）
          ├─ llama_model::build_graph // 含 cpy_k/cpy_v 节点（物理写 K/V）
          └─ graph compute
  } while (mctx->next());             // llama-context.cpp:2025（多 ubatch 续批）
```
- **每个 ubatch 一次 `apply()` + 一次 graph**。KV 写入发生在 graph compute 时（`cpy_k/cpy_v` 的 `ggml_set_rows` 节点），cell 元数据在 apply 时先更新。
- 视觉 embd 注入（273 embd）与 token 走同一 `llama_batch` 通道：`llama_batch.embd`（`include/llama.h:255-259`），`llama_batch_init(..., embd, ...)` 分配（`llama-batch.cpp:945`）。

### 1.5 容量上限行为（写满会怎样）

- `find_slot`（`llama-kv-cache.cpp:958`）搜不到可用 cell → 返回空 slot_info（1175/1181）。
- 空 slot → `LLAMA_MEMORY_STATUS_FAILED_PREPARE` → `LLAMA_LOG_WARN("failed to find a memory slot for batch of size %d")` → **decode 返回失败**（`llama-context.cpp:1811-1823`）。
- **结论：KV 写满 = 硬错误返回，不会静默出错 / 不会乱写。** 这是 R-SWA 失效兜底（§3.3）可利用的行为：prefill 超长会提前暴露为 decode 失败，不会输出乱码。

### 1.6 现有的 SWA / 淘汰机制（可复用与对照）

b10216 已有一套完整 SWA 机制，与 R-SWA 是「近亲」：

| 机制 | 位置 | 说明 |
|---|---|---|
| `llama_swa_type` 枚举 | `llama-hparams.h:20-25` | NONE/STANDARD/CHUNKED/SYMMETRIC 四种 |
| `is_masked_swa(n_swa, swa_type, p0, p1)` | `llama-hparams.h:386-420` | **掩码判定**。STANDARD：`p1-p0 >= n_swa` 掩（395）|
| SWA 掩码写入（有 cache） | `set_input_kq_mask_impl` `llama-kv-cache.cpp:1812` | 调 `is_masked_swa` |
| SWA 掩码写入（无 cache） | `fill_mask` `llama-graph.cpp:435` | 同上 |
| **SWA 物理淘汰（cell 复用）** | `find_slot` `llama-kv-cache.cpp:1135-1154` | cell 被单序列占用且 `is_masked_swa(..., pos_cell, seq_pos_max+1)` → **视为过期可覆盖复用** |
| SWA 独立缓存 | `llama_kv_cache_iswa` `llama-kv-cache-iswa.cpp:34-106` | `kv_base`（非 SWA 层）+ `kv_swa`（SWA 层）；`size_swa = GGML_PAD(min(size_base, n_swa*n_seq + n_ubatch), 256)`（73）|
| cache 类型选择 | `llama_model::create_memory` `llama-model.cpp:2051` | default 分支：`swa_type != NONE` → `llama_kv_cache_iswa`（2306）；否则普通 `llama_kv_cache`（2326）|

**关键对照：原生 SWA 的窗口从 pos 0 开始**（`is_masked_swa` STANDARD 判定 `p1-p0 >= n_swa`，即 `p0 < p1-n_swa` 就掩/淘汰）。对长 prefill（视觉前缀 273×N）来说，**前段 prompt 会被误伤** —— 这正是 R-SWA 要修正的语义（见 §2.1）。

### 1.7 关键结论：deepseek2-ocr 当前是无窗口全注意力

- `convert_hf_to_gguf.py` 对 deepseek2-ocr 只设架构与张量过滤，**不写 SWA 元数据**（grep 无 swa 相关）→ GGUF 无 `n_swa`/`swa_type`。
- hparams 默认 `swa_type = NONE`（`llama-hparams.h:143`）、`n_swa = 0`（145）→ `create_memory` 走普通 `llama_kv_cache`（`llama-model.cpp:2323-2343`）。
- 结果：**全注意力，KV cell 数 = n_ctx，生成到 n_ctx 即 FAILED_PREPARE**。P4 解码器施工中的「长文档」能力（恒定 KV、超长输出）在 b10216 默认路径下**尚未实现** —— 这就是 P6 预研要补的设计。

---

## 二、R-SWA 实现方案

### 2.1 语义差异：R-SWA vs llama.cpp 原生 SWA

| 维度 | llama.cpp 原生 SWA（iswa/is_masked_swa） | **R-SWA（本方案）** |
|---|---|---|
| 窗口作用于 | 按层（`is_swa` pattern 判定哪些层 SWA，`llama-hparams.cpp:11-20`） | **全部 12 层**（R-SWA 是所有解码层的行为） |
| 窗口起点 | pos 0（STANDARD 判定 `p1-p0>=n_swa`，早期 token 也被掩） | **参考前缀（视觉 embd + BOS + 指令头）永不淘汰/永不被掩** |
| 窗口终点 | 最近 n_swa 个 token | 最近 W=128 个**生成** token |
| 前缀保留 | ❌ 长前缀被掩掉 | ✅ **参考前缀常驻**（这就是 R-SWA 的「R」） |

依据：`OCR_RSWA_ANALYSIS.md` §3.3 明确——transformers 原生 sliding_window 会连早期 prompt 一起淘汰，**R-SWA 保留参考前缀、只窗口化生成段**。llama.cpp 原生 SWA 与 transformers 原生 sliding_window 同病，直接开窗口会输出与黄金样本不符。

**R-SWA 精确掩码/淘汰判定**（本方案的数学定义）：
```
给定: 序列 s 的参考前缀长度 prefill_len[s]（= 首个生成 token 之前的 KV 长度）
对于 (query pos p1, key pos p0)：
    if  p0 < prefill_len[s]        → 不掩（参考前缀常驻，注意力全开）
    elif p1 - p0 >= W              → 掩（生成段滑窗，只看最近 W）
    else                           → 不掩
```

### 2.2 掩码 vs 物理淘汰：二选一论证（结论：双管齐下）

| 方案 | 做法 | 内存 | 正确性 | 结论 |
|---|---|---|---|---|
| **A 纯掩码** | 只改 `set_input_kq_mask`/`fill_mask`，物理 KV 全留 | ❌ KV 仍随输出增长（n_ctx 要预留输出长度），**不满足「恒定 KV」验收**（DESIGN_OCR_MOBILE.md §三 RSS≤4GB 前提是长文档不撑爆） | ✅ 注意力正确 | **否决**（作为独立方案） |
| **B 纯物理淘汰** | 只改 `find_slot` 淘汰过期生成 cell，decode 无 mask 全注意 | ✅ 内存真恒定（参考 + 最近 W） | ⚠️ 依赖 cell 淘汰与注意力**恰好一致**（transformers 参考实现 decode 确实无 mask，`OCR_RSWA_ANALYSIS` §3.1）——但 prefill 续段、序列切换、异常路径下无 mask 兜底，风险高 | 单独用风险高 |
| **C 掩码 + 物理淘汰（推荐）** | **两处共用同一 R-SWA 判定**：`find_slot` 淘汰过期生成 cell（内存恒定）+ `set_input_kq_mask` 同步掩码（注意力严格正确） | ✅ 恒定 | ✅ 掩码兜底，淘汰偏差只浪费 cell 不产生错误注意力 | **采用** |

**为什么 C 是对的**：
1. llama.cpp 原生 SWA 就是这么设计的（`find_slot` 复用 + `set_input_kq_mask` 掩码共用 `is_masked_swa`，见 §1.6）—— R-SWA 只是给这套判定加「前缀边界」，**架构零新增**。
2. 双写成本极低：两处都只是调用同一个判定函数（`is_masked_rswa`），改一处核心逻辑两处生效。
3. 掩码是**语义正确性兜底**：即使 cell 分配因边缘情况（多序列、续批、shift）与淘汰判定不一致，注意力仍不会越界。

### 2.3 改动点清单（P4 施工单，文件:函数:改什么）

> 全部改动在 llama.cpp 侧（独立 fork/补丁），**零改动**注意力算子、RoPE、graph 拓扑、转换脚本（GGUF 已含架构）。共 6 处代码改动 + 1 处 API 新增 + 1 处调用方接入。

**① 新增 R-SWA 判定函数** — `src/llama-hparams.h`
```
位置: is_masked_swa 旁（llama-hparams.h:386-420 之后）
新增: static bool is_masked_rswa(uint32_t n_swa, llama_pos prefill_len, llama_pos p0, llama_pos p1)
     if (p0 < prefill_len) return false;              // 参考前缀常驻
     return (p1 - p0 >= (int32_t) n_swa);             // 生成段 W=128 滑窗
说明: 与 is_masked_swa 同风格（inline static），供下面 ③④⑤ 三处调用。
```

**② 运行时前缀长度状态** — `src/llama-kv-cache.h` + `src/llama-kv-cache.cpp`
```
位置: llama_kv_cache 成员区（llama-kv-cache.h:270 附近，swa_type 后）
新增成员: std::vector<llama_pos> prefill_len;   // per stream，默认 -1（未设置）
新增方法: void set_prefill_len(uint32_t stream, llama_pos len);   // 供调用方 prefill 完成后设置
          llama_pos get_prefill_len(uint32_t stream) const;
位置: 构造（llama-kv-cache.cpp:135-143 初始化 v_heads 处）初始化 prefill_len 为 -1
说明: OCR 单序列 → stream 0。per-stream 设计兼容未来多序列。
```

**③ 掩码路径（有 cache）** — `src/llama-kv-cache.cpp`
```
位置: set_input_kq_mask_impl 的 SWA 判定（llama-kv-cache.cpp:1811-1815）
改:   if (llama_hparams::is_masked_swa(n_swa, swa_type, p0, p1)) goto skip;
      → 改为按 prefill_len 状态分流：
        if (prefill_len[stream] >= 0)                       // 生成段 → R-SWA 判定
            if (llama_hparams::is_masked_rswa(n_swa, prefill_len[stream], p0, p1)) goto skip;
        /* else: prefill 段（prefill_len 未固化）→ 不掩 SWA，前缀内部全注意 */
说明: ⚠️ 关键 —— 不能用「prefill_len<0 时走原生 is_masked_swa」：那会让 prefill 续批（多页视觉 embd 分批 prefill）被 `p1-p0>=128` 窗口化，把早期前缀掩掉。
      prefill 阶段语义 = causal only。swa_type 只用来触发本分支，deepseek2-ocr 场景永不落到原生 is_masked_swa。
      新引入 args 字段 prefill_len（args_set_input_kq_mask 结构，llama-kv-cache.cpp:1668-1681 加成员）。
```

**④ 掩码路径（无 cache，prefill 首段）** — `src/llama-graph.cpp`
```
位置: llm_graph_input_attn_no_cache::set_input 的 fill_mask（llama-graph.cpp:435-437）
改:   SWA 判定同 ③ 分流（此处是纯 prefill 段，prefill_len 语义 = 本批全长，R-SWA 退化为无窗口 = 全部不掩）。
说明: 实际 prefill 首段 q_len>1 无窗口需求，此改动为语义完备性（prefill 段 R-SWA 判定天然不掩，可不动）。
```

**⑤ 淘汰路径（物理恒定）** — `src/llama-kv-cache.cpp` `find_slot`
```
位置: cell 复用判定（llama-kv-cache.cpp:1135-1154）
改:   if (llama_hparams::is_masked_swa(n_swa, swa_type, pos_cell, cells.seq_pos_max(seq_id_cell)+1)) can_use=true;
      → 改为按 prefill_len 状态分流：
        if (prefill_len[strm] >= 0)
            can_use = llama_hparams::is_masked_rswa(n_swa, prefill_len[strm], pos_cell, cells.seq_pos_max(seq_id_cell)+1);
        /* else: prefill 段 → 不淘汰（can_use 保持 is_empty 结果），前缀 cell 只追加不覆盖 */
说明: 关键 —— 该判定决定「参考前缀 cell 永不复用」（pos_cell < prefill_len → 不淘汰），生成段 cell 环状覆写。
      与 ③ 同款防坑：prefill_len<0（prefill 中）时禁止任何 cell 复用，否则分批 prefill 会覆盖已写前缀。
      ⚠️ strm 取自 seq_to_stream[seq_id]（本文件 1056/1059 已有），prefill_len 按 stream 索引。
```

**⑥ KV 分配大小 = 前缀 + 窗口** — `llama-kv-cache.cpp` 构造 + `llama-model.cpp`
```
位置: llama_kv_cache 构造的 kv_size（llama-kv-cache.cpp:98 断言 kv_size%n_pad==0 之前，或 create_memory 传参）
改:   deepseek2-ocr 启用 R-SWA 时，kv_size = max_prefill_len + W + n_ubatch 余量
      （而非 cparams.n_ctx_seq = n_ctx）。
位置: create_memory default 分支（llama-model.cpp:2323-2343）为 LLM_ARCH_DEEPSEEK2OCR 加分支：
      swa_type=STANDARD、n_swa=128、构造普通 llama_kv_cache（同 2326 形态）但 kv_size 用上限值。
说明: 这是「内存恒定」的根：物理 cell 总数封顶在 prefill_max+W，输出再长也不超。
      需把 prefill 上限（视觉 273×N + 指令）从调用方传入（见 ⑧）。
```

**⑦ hparams / GGUF 接线** — `src/llama-model.cpp` 或运行时 cparams
```
位置: model 加载后设置 hparams.n_swa / hparams.swa_type（deepseek2-ocr 默认 NONE，需显式置 STANDARD/128）
选法A（推荐，无转换改动）: create_memory 里按 arch==LLM_ARCH_DEEPSEEK2OCR 直接硬编码 n_swa=128、swa_type=STANDARD；
选法B: convert_hf_to_gguf.py deepseek2-ocr 分支写元数据 + llama-model-loader 解析。
说明: 选法A 改动最小（P4 可先跑通语义再固化到 GGUF）。
```

**⑧ 调用方接入（P4 vision_infer.cpp）**
```
位置: 现有 embd 注入 prefill 完成后（vision_infer.cpp 的三段式 prefill 尾部）
新增: 调 llama_kv_cache_set_prefill_len(ctx, 0, n_prefill)（② 的 C 封装 API，或直接进 context）
说明: n_prefill = 参考前缀实际 token 数（视觉 273×N + BOS + 指令），prefill 后固化。
      若调用方未设置：decode 首个单 token batch 时可用「该序列 seq_pos_max」自动快照兜底（② 里实现一个 fallback）。
```

**改动量评估**：核心逻辑新增 1 个纯函数（①）+ 3 处 3~5 行判定分流（③④⑤）+ 1 处 KV 分配参数（⑥）+ 1 处成员/API（②）+ 1 处 arch 分支（⑦）+ 1 处调用方（⑧）。**半天量级**，与 b10216 现有 SWA 机制同构，无架构性新增。

### 2.4 与 deepseek2-ocr 的兼容点（语义对齐检查）

| 兼容项 | 结论 | 依据 |
|---|---|---|
| 注意力算子 | ✅ 不变 —— R-SWA 是缓存/掩码策略，MHA scaled-dot-product 原样 | `OCR_RSWA_ANALYSIS.md` §1/§2.2 |
| RoPE 绝对位置 | ✅ 天然满足 —— cell 物理索引与逻辑 pos 解耦（§1.3） | `llama-kv-cache.cpp:1233`（pos_set 写绝对 pos）|
| 全部 12 层生效 | ✅ 方案在**每层同一个 KV cache** 上改判定，非 iswa 的层间拆分（§2.1） | — |
| no_repeat_ngram(35,128) | ✅ 无关 —— logits 层后处理，P4 已移植，不受 KV 影响 | `OCR_RSWA_ANALYSIS.md` §4.4 |
| 训练-推理对齐 | ✅ 官方「老路」= transformers ring buffer 语义（参考前缀常驻 + W=128）；本方案用 mask+淘汰实现**同一语义**，非新数学 | `OCR_RSWA_ANALYSIS.md` §2.2/§2.3 |
| 视觉编码器 | ✅ 不走 R-SWA（单次全注意 prefill），llama.cpp 侧只是把视觉 embd 当参考前缀 | `OCR_RSWA_ANALYSIS.md` §4.3 |

**需要对齐的一个细节**：transformers 参考实现 decode 是「无 mask 全注意」（`OCR_RSWA_ANALYSIS` §3.1 steady state）。本方案保留掩码（§2.2 方案 C）——掩码结果是「参考 + 环内最近 W」全注意，**与 transformers 数值一致**（被淘汰的 token 在两种实现里都不可见）。唯一差异：llama.cpp 环内可能因 find_slot 分配略宽松而多留几个 token（n_pad/256 对齐），但 mask 会精确掩掉窗口外的 —— **数值仍一致**。

### 2.5 容量模型（恒定 KV 内存账本，对照 RSS ≤4GB）

**每 token KV 字节**（F16，2B/元素）：
```
每层 = n_head_kv × head_dim × 2B × 2(K+V) = 10 × 128 × 2 × 2 = 5120 B
12 层 = 5120 × 12 = 61440 B = 60 KiB/token
```

**场景账本**（R-SWA：参考前缀常驻 + W=128）：

| 场景 | 参考前缀 | 前缀 KV | 窗口 KV | 恒定总量 |
|---|---|---|---|---|
| 单页文档 | 277（273 视觉 + BOS + 指令） | 16.2 MiB | 7.5 MiB | **≈ 24 MiB** |
| 40 页文档 | 10923（273×40 + 指令） | 640 MiB | 7.5 MiB | **≈ 648 MiB** |

**对照：全注意力（b10216 现状）**：

| 场景 | 输出长度 | 全注意力 KV | 差距 |
|---|---|---|---|
| 40 页 + 短输出 500 tok | 11423 | 670 MiB | +22 MiB |
| 40 页 + 长输出 4000 tok | 14923 | 875 MiB | +227 MiB |
| 40 页 + 重排 10000 tok | 20923 | 1.23 GiB | +580 MiB |

**结论**：
1. R-SWA 的恒定收益在**长输出**时兑现（重排整本文档输出 1 万+ token 时省 ~600 MiB 且不撞 n_ctx 上限）；短输出时全注意力也能跑，但 R-SWA 语义（前缀常驻）是**黄金样本对齐的前提**，不是可选项。
2. **RSS 预算**：q4_K_M 权重 1.82GB（`OCR_DECODER_MNN.md` §13 实测）+ 40 页 KV 648 MiB + 激活/计算图（预估数百 MiB）≈ **2.7~3.0 GB < 4GB** ✅（DESIGN_OCR_MOBILE.md §四 RSS≤4GB 达标）。
3. 单页场景 KV 仅 ~24 MiB —— 恒定 KV 的实际意义是「**n_ctx 只分配 prefill_max+W**，无需按输出长度预留」，40 页时把 KV 分配从「按 n_ctx 上限（通常≥4096+输出）」压到 10923+128，且生成可无限持续不 FAILED_PREPARE。

---

## 三、验证方案（P4 可照做的验收设计）

### 3.1 数值对照：llama.cpp R-SWA vs PyTorch 参考（黄金样本长文档版）

**对照对象**：`OCR_GOLDEN_SAMPLES.md` 的 3 张黄金图（base 模式）+ 新增 1 条**长文档黄金样本**（多页拼接文本，触发滑窗淘汰）。
- 参考实现 = P0b 的 PyTorch transformers CPU 基线（`OCR_RSWA_ANALYSIS.md` §9，官方 `SlidingWindowLlamaAttention` ring buffer 路线）——**它是 R-SWA 语义的权威**。
- 被测 = llama.cpp R-SWA 版（q4_K_M 或 q8_0）。

**判据**：
1. 逐 token 贪心输出**逐字一致**（同 `OCR_DECODER_MNN.md` 的 golden ≥98% 线，但 R-SWA 语义对照应追求 100% 对齐——注意量化误差允许个别 token 差异，以「不含非参考 token」为最低线）。
2. **窗口正确性专项**：构造输出 >300 token 的长生成，**第 100~300 个 token 的注意力范围**用 `LLAMA_KV_CACHE_DEBUG=2`（`llama-kv-cache.cpp:960` 的 debug 打印）核对：cache 里前缀 cell 全部保留、生成 cell 数 ≈ W。
3. 阴性对照：**不开 R-SWA 的全注意力版** vs 参考 —— 允许通过（全注意是参考的超集，长输出数值也应一致）；**开原生 SWA（窗口从 pos0）版** vs 参考 —— 必须失败（早期前缀被掩 → 输出不同），证明 R-SWA 前缀常驻语义是关键差异。

### 3.2 恒定 KV 实证（埋点设计）

**埋点**（b10216 未暴露 KV 占用 C API——grep 确认 `include/llama.h` 无 `llama_get_kv_cache_used_cells`。用以下两级，第一级零改代码）：
1. **日志埋点（零改代码）**：`LLAMA_KV_CACHE_DEBUG=1` 环境变量触发 `find_slot` 的 debug 打印（`llama-kv-cache.cpp:960-991`），每 decode 步输出 `stream/used/head/size/n_swa`（967 行）+ `seq_pos_min/max`（1016-1022）。**恒定判据：生成 500+ token 期间 `used`（已用 cell 数）封顶在 `prefill_max + W + pad` 附近，不随输出长度增长。** 附 `LLAMA_KV_CACHE_DEBUG=3`（992-1014）打印每个 cell 的 pos 分布，直接看环状覆写形态。
2. **构造内存埋点**：构造时日志已有 `KV buffer size = ... MiB`（`llama-kv-cache.cpp:305`）与 `size = ... MiB (... cells, ... layers)`（327）——记录一次即得 KV 物理占用基线。
3. **集成期埋点（vision_infer.cpp 侧，加临时 printf）**：每 N 步调 `llama_n_ctx(ctx)`（不变）+ 读 `find_slot` 的 debug 行；或对 llama.cpp 加一行临时 debug：`get_n_kv`（1340）返回值打印。对照 `get_size()`（1295，分配 cell 数）。

**执行剧本**（照 `OCR_DECODER_MNN.md` §14 的「固定剧本」纪律）：
- 同 prompt 同 n，prefill 277（单页）→ 生成 600 token，每 50 token 打一次埋点；
- 40 页场景：prefill 10923 → 生成 600 token。
- **通过线**：生成段每 50 步 `n_kv` 增量 ≈ 50（滑窗内）且总量 ≤ prefill_max+W+256；KV buffer 大小恒定不变。

### 3.3 失效兜底（R-SWA 实现 bug 时的退化行为）

**设计原则：任何 R-SWA 相关失败 → 自动回退全注意力，不许输出乱码。**

| 失效场景 | 触发 | 兜底动作 |
|---|---|---|
| prefill 超长（> 分配的 max_prefill_len） | `find_slot` 返回空 → FAILED_PREPARE（§1.5） | 捕获 decode 失败 → **增大 kv_size 重开 context 走全注意力**（退化为 §1.7 现状路径），输出仍正确只是内存随输出增长；诚实日志上报 |
| 调用方未设 prefill_len | `prefill_len[stream] == -1` | ② 的 fallback：首个单 token decode 前自动快照 `seq_pos_max` 为 prefill_len；或直接降级全注意力 |
| mask/淘汰判定不一致 | 无（掩码兜底，§2.2 方案 C） | 掩码保证注意力不越界；淘汰偏差仅浪费 cell，最多提前 FAILED_PREPARE（同上兜底） |
| 数值漂移（实现 bug 未报错） | 黄金样本对照不过（§3.1） | 比对失败 → **强制切全注意力**再验；golden 对照是最后闸门 |

**核心保障**：llama.cpp 的「写满即硬错误」+ 本方案的「预分配封顶」共同保证——R-SWA 失效时是**可检测的错误/可比的数值差异**，绝不会静默输出垃圾。配合 `OCR_RSWA_ANALYSIS.md` §6 的黄金样本锁死机制，换图即打回。

---

## 四、遗留事项与风险

1. **prefill 上限的确定**：max_prefill_len 需调用方给出（视觉 273×N + 指令）。40 页 ≈ 10923；单页 277。P4 集成时按实际 prefill 传值，**预留 256 对齐余量**（`get_n_kv` pad 到 256，§1.2）。
2. **n_ctx_seq 与 kv_size 的关系**：⑥ 若直接把 kv_size 设小，需确认 `n_ctx_seq` 其它消费方（如 ROPE/YaRN 的 `n_ctx_orig`，`llama-kv-cache.cpp:2004`）不受影响——建议 **kv_size 独立于 n_ctx 传参**，不覆盖 n_ctx_seq。
3. **多序列场景**：本方案 per-stream prefill_len 已预留，但 OCR 单序列无需验证；llama-server 并发序列若启用 R-SWA 需按序列分别设置。
4. **iswa 双缓存路线**（§1.6）**不采用**：iswa 的 `kv_base/kv_swa` 是**层间拆分**（部分层 SWA），与 R-SWA「全层前缀常驻」语义不符，复用其机制会误伤前缀。方案 C 直接在普通 `llama_kv_cache` 上加判定，更贴近 transformers 参考实现。
5. **与 P4 解码器现状的关系**：本文设计基于 b10216 现状（deepseek2-ocr 全注意力，`OCR_DECODER_MNN.md` §16 decode 0.4tok/s 未解）。R-SWA 改动与「decode 慢/退化」问题正交，P4 可先解性能再落 R-SWA，或并行。
6. **vLLM 掩码路线对照**（`OCR_RSWA_ANALYSIS.md` §2.3）：vLLM 选掩码因其 PagedAttention 统一管理 KV；本方案选 mask+淘汰因 llama.cpp 是 cell 模型、物理封顶成本为零。语义一致，无冲突。

---

## 附录：本预研已核实的 b10216 源码引用清单（验收抽查用）

| 论断 | 文件:行号 | 本地镜像 |
|---|---|---|
| cell 元数据（pos/seq/used） | `llama-kv-cells.h:32` `:464` `:489` `:462` | `.ocr_p0/llmcpp/src/llama-kv-cells.h` |
| K/V 张量布局 | `llama-kv-cache.cpp:231-232` | `.ocr_p0/llmcpp/src/llama-kv-cache.cpp` |
| kv_size 来自 n_ctx_seq | `llama-model.cpp:2334` + `llama-context.cpp:287-290` | 同上 |
| KV 写入 ggml_set_rows | `llama-kv-cache.cpp:1457` | 同上 |
| cell 元数据写入点 | `llama-kv-cache.cpp:1190` `:1233` | 同上 |
| 有 cache 掩码判定 | `llama-kv-cache.cpp:1812-1815` | 同上 |
| 无 cache 掩码判定 | `llama-graph.cpp:435-437` | `.ocr_p0/llmcpp/src/llama-graph.cpp` |
| is_masked_swa 判定 | `llama-hparams.h:386-420` | `.ocr_p0/llmcpp/src/llama-hparams.h` |
| SWA 物理淘汰（find_slot 复用） | `llama-kv-cache.cpp:1135-1154` | `llama-kv-cache.cpp` |
| SWA 独立缓存 iswa | `llama-kv-cache-iswa.cpp:34-106` | `.ocr_p0/llmcpp/src/llama-kv-cache-iswa.cpp` |
| cache 类型选择 | `llama-model.cpp:2051` `:2326` | `llama-model.cpp` |
| KV 写满行为 | `llama-context.cpp:1811-1823` | `.ocr_p0/llmcpp/src/llama-context.cpp` |
| deepseek2 标准 RoPE 组 | `llama-arch.cpp` `llm_arch_supports_sm_tensor` | `.ocr_p0/llmcpp/src/llama-arch.cpp` |
| KV 默认 F16 | `llama-context.cpp:3504-3505` | `llama-context.cpp` |
| 版本核验 sha256 | 本仓 `.ocr_p0/llmcpp/` vs 官方 b10216 tarball：`llama-kv-cache.cpp` `4ee0076f...`、`llama-context.cpp` `2cf2ba8f...`、`llama-graph.cpp` `c83460b6...` | `.ocr_p0/llmcpp_verify/` |

> 本地镜像 `.ocr_p0/llmcpp/` 与官方 b10216（`llama.cpp-b10216.tar.gz`，gh-proxy 拉取）三文件 sha256 逐一一致，详见本仓 `.ocr_p0/llmcpp_verify/`。
