# CONTRACT_STREAMING — 流式活性与断线感知 (v1.0 · 2026-07-24)

> 目标：消灭"假死无感知"——等回复时有活性反馈、断线秒级可察觉、出错可恢复、动效轻量不耗电。
> 校准来源：Hermes agent（chat_completion_helpers.py 停滞看门狗实战值）+ Kimi Code（TPS 活性显示/快退避/任务暂停恢复）二进制实证。

## 一、原则

1. **字在走 = 活着**：SSE 流式是唯一的活性真相源；打字机 + TPS 速率是默认等待反馈。
2. **provider 的 SSE ping/保活帧不算活性**：只有真实内容 chunk 才重置停滞计时。
3. **看门狗先于 socket 超时开火**：readTimeout 必须 ≥ 停滞阈值，让带重试和诊断的停滞检测先触发（hermes 血泪教训，不得反转）。
4. **网络类错误不判死刑**：分类后进入「已暂停·可续跑」，恢复后续跑而非重头来。
5. **动效预算**：零额外线程/进程；JS 定时器 ≤2Hz；页面隐藏立即停帧；CSS 动画优先于 JS 动画。

## 二、机制定义

### 2.1 SSE 流式（AiClient）
- 请求 `stream:true`，逐 chunk 解析（处理粘包/半行；`data: [DONE]` 终止）。
- 显示流与解析流分离：UI 实时打字机；agent 循环动作解析仍等完整响应（行为不变）。
- tool calls 累积规则：name 赋值不拼接（防重复发送），arguments 拼接，流末 JSON 校验+修复（补括号/去尾逗号）。
- provider 不支持 SSE（返回完整响应）→ 本会话降级非流式，看门狗参数切换为 2.2 非流式档。

### 2.2 停滞看门狗（stall watchdog）
- `lastChunkTime` 每真实 chunk 重置；检查周期 1s（复用现有等待计时器，不新增线程）。
- 阈值：`STALL_STREAM_MS = 180_000`（默认）；reasoning/深度思考模型 `300_000`；本地端点 `600_000`；非流式档 `90_000`。
- 触发 → `call.cancel()` 杀流 → 计入停滞重试（见 2.3）→ 换连接重发。
- 连续停滞熔断：同任务连续 5 次停滞 → 放弃并报「provider 持续无响应」，防烧钱。

### 2.3 双速重试
| 错误类 | 策略 |
|---|---|
| 网络抖动（连接重置/超时/5xx 无 Retry-After） | 快退避：300ms → 600 → 1.2s → 2.4 → 5s 封顶，+50% jitter，最多 3 次 |
| 429/限流 | 尊重 `Retry-After`（上限 600s）；无头则 30→60→120s 长退避，最多 3 次 |
| 首字节（TTFB） | 不单独设短超时；由停滞阈值兜底（避免误杀深度思考） |
| socket readTimeout | ≥ 停滞阈值 + 30s 余量（永远让看门狗先开火） |
- 重试过程诊断缓冲：成功静默，全部失败才展示完整死因。

### 2.4 错误分类 → 任务暂停可恢复
- 分类：PROVIDER_API / PROVIDER_AUTH / PROVIDER_CONNECTION / RATE_LIMIT / MODEL_CONFIG / RUNTIME。
- 网络类（CONNECTION/RATE_LIMIT）重试耗尽 → agent 任务进入 `PAUSED`（新状态）：
  - 交付卡/失败卡替换为「已暂停 · 可续跑」卡：原因 + 已完成步数 + [立即续跑] 按钮；
  - 网络恢复（见 2.5）→ 提示可续跑；用户点续跑 → 从 transcript 断点继续（不重置 stepsDone/producedFiles）。
- AUTH/MODEL_CONFIG → 维持 fail（配置问题重试无意义，直达设置页引导）。

### 2.5 网络监听（HermesActivity）
- `ConnectivityManager.registerDefaultNetworkCallback`：断网瞬间中止在途请求 + 状态条「网络已断开」；恢复 → 「网络已恢复，可续跑」。

### 2.6 取消
- 先置 `cancelled` 标志再 `call.cancel()`；异常处理区分「用户取消」（不重试、标已取消）vs「网络错误」（进重试）。
- 已显示的部分文本保留；agent 步骤日志标「已取消」。

## 三、UI 与动效规范（轻量硬约束）

### 3.1 等待状态行（聊天气泡 + agent 步骤行共用）
- 内容：`⠋ 思考中 · 12.3 tok/s · 已等 45s`；阶段文案：连接中 → 思考中 → 生成中。
- 30s 无 chunk → 追加解释：`（模型可能在深度思考，180s 后自动重连）`。
- TPS 计算：滑动窗口（最近 10s 的 chunk 数/秒），**每 500ms 最多刷新一次 DOM**。

### 3.2 动效（品牌款 M 流光 + 光标，默认 A+B）
- **A. M 流光（默认等待动效）**：w→m→w→m 连笔波浪线 + 光脉冲沿线无限流转（莫比乌斯式连续线，MOV 的「M」展开）。
  - 内联 SVG（零图片零字体文件），path（已审定，w 起笔波峰下压，一笔不断）：
    `M2 3 L10 15 L18 3 L26 15 L34 3 L42 15 L50 3 L58 15 L66 3 L74 15 L82 3 L90 15 L98 3`（viewBox `0 0 100 18`）
  - 双层描边：base `stroke:var(--seal-soft)` + pulse `stroke:var(--seal)`，宽 2.5，round caps/joins
  - 动画：pulse `stroke-dasharray:34 166`，`stroke-dashoffset:200→0`，1.6s linear infinite（纯 CSS，合成器渲染）
- **B. 光标呼吸**：打字机末尾 `▍` 纯 CSS blink（1s steps）。
- **C. TPS/秒数**：单一 `setInterval(500ms)` 驱动，任务结束立即 clear。
- **红线**：禁 GIF/WebM/ lottie；禁 `requestAnimationFrame` 常驻；禁新线程/HandlerThread/进程；`document.hidden=true` 时停掉 C 类定时器；动画元素脱离文档即销毁，不得泄漏。M 流光为品牌资产，等待场景统一使用，不得另造等待图形。

### 3.3 暂停卡
- 「已暂停 · 可续跑」卡：原因一行 + 进度（N 步/产物列表）+ [立即续跑]（btn-acc）+ [放弃]（btn-ghost）。

## 四、实施范围

| 层 | 改动 |
|---|---|
| `ai/AiClient.java` | SSE 解析、分层超时、取消标志 |
| `ai/`（新 `StreamWatchdog`） | 停滞检测/熔断/退避策略（纯逻辑可单测） |
| `bridge/BridgeAi.java` | 流式回调通道（onToken/onState/onPaused）+ 错误分类 |
| `agent/AgentLoop.java` | PAUSED 状态 + 断点续跑入口 + 停滞熔断计数 |
| `chat.js/render.js/shell.css` | 打字机/TPS/等待动效/暂停卡 |
| `HermesActivity.java` | 网络监听 |
| `i18n.js` | 全部新文案 |

## 五、验收用例

- TC-SSE-01：正常流式 — 打字机逐字出现，TPS 数字每 500ms 刷新一次（DOM 写入计数断言）。
- TC-SSE-02：模拟 60s 无 chunk — 状态行出现「深度思考」解释，**不**误杀（阈值 180s 未到）。
- TC-SSE-03：模拟 181s 无 chunk — 看门狗杀流并自动重连，步骤日志记「停滞重连 (1/3)」。
- TC-SSE-04：连续 5 次停滞 — 熔断报「provider 持续无响应」，不再重试。
- TC-SSE-05：飞行模式中断 — 1s 内状态条「网络已断开」；恢复后出现「可续跑」。
- TC-SSE-06：暂停续跑 — 暂停卡[立即续跑]后从断点继续，stepsDone/产物不重置。
- TC-SSE-07：取消 — 点击取消，无重试发生，已显示文本保留，日志标「已取消」。
- TC-SSE-08：动效预算 — 等待期间线程数不增加；`document.hidden` 后定时器停止；任务结束后无残留 interval（JS 侧断言 + 内存快照对比）。
- TC-SSE-09：provider 不支持 SSE — 降级非流式，看门狗切 90s 档，功能正常。
- TC-SSE-10：限流 429 带 Retry-After:5 — 恰在 5s 后重试（日志断言），不提前。

## 六、红线

1. 禁反转开火顺序：readTimeout 永远 ≥ 停滞阈值 + 30s。
2. 禁把 SSE ping/注释帧当活性重置 lastChunkTime。
3. 禁为动效新增任何线程/进程/GIF/lottie；禁常驻 rAF。
4. 禁网络类错误直接 fail（必须给「已暂停·可续跑」出口）。
5. 禁取消后重试。
6. 重试诊断只在全部失败时展示，成功静默。
