# 工单17 交付说明 — 首页对话连续性修复

> 派单：`docs/TASKS_P1_HOME_CHAT_CONTINUITY_2026-08-07.md`（9fc9699）
> 施工：P1 线｜状态：待验收｜commit：见 git log（本说明随 commit 提交）

## 一、交付内容（两幕 + 三断点）

### 幕一：视觉连续（newface.js）
- 新增 `ensureStream()` + `_chatStreamOn` 对话流状态：faceCover 即对话流，首轮 say 清屏初始化，之后**追加式渲染**
- `say()` / `routeByIntent` 不再整体清屏；`routeByIntent` 只移除 thinking 行，不重复追加 utter
- 各路由分支（startMusicSearch / startTrainSearch / startA2A / startFlow / startFail / autoHandoff / showInlineChat / showHandoff）全部走对话流 + utter 防重
- 清屏仅限显式动作：`resetFace()`（恢复封面=新会话）、`showEmpty()`（新会话引导页）、`replayConversation()`（历史回放）

### 幕二A：进程连续（方案 b — 首页对话落 journal 房间，BridgeAi.java + MemoryToolProvider.java）
- 新增固定首页房间 `HOME_ROOM_ID = "r_home"`（通过 Journal.isValidId 格式校验）
- `getHistory(null)` 全局桶首次访问从 `r_home/journal.jsonl` 懒重建（原仅 roomId 房间参与重建）
- `aiChatAsync` / `aiChatWithModel` 成功路径在 `rid == null`（首页对话）时 `persistHomeChat()`：append `user_input`(actor=user, payload.text) + `deliver`(payload.summary) 事件到 r_home journal——事件格式对齐 `rebuildHistoryFromJournal` 提取规则，杀进程后重启可恢复
- `MemoryToolProvider` face_history 扫描跳过 r_home（左侧历史列表语义不变；孤儿清理不会误删——有 journal 即有效）

### 幕二B：同房派活（newface.js）
- `expertCreateRoom` 加 `_homeRoomId` / `_homeHandoff`：首页自动交接链路（autoHandoff 置标记）首句建房并记录房间，**同一会话后续派活复用同一房间**（不新建）
- 手动输入 / ＋新建 照旧开新房（`_homeHandoff` 仅 autoHandoff 链路置位）
- `resetFace()` 回封面清空 `_homeRoomId`（显式新会话才开新房）

## 二、施工决策（派单「施工定并注明」）

1. **持久化选方案 b**（派单建议优先评估项）：首页对话落 `r_home` journal 房间，全局桶走 journal 懒重建——符合「journal 唯一真理」红线，且复用现有 `rebuildHistoryFromJournal` 提取逻辑，零新增桥
2. **face_history 跳过 r_home**：首页对话历史由 r_home journal 承载（进程记忆），但不进左侧历史列表——验收 5「历史不劣化」零风险
3. **utter 防重策略**：say() 渲染 utter 后，各路由分支 `streamHasUtter()` 防重（startFlow 原防重逻辑保留）

## 三、验收对照

| # | 验收标准 | 自验结果 |
|---|---|---|
| 1 | 真机三轮连续对话同屏 | ✅ 真机：hello→法国首都→记住代码，三轮 utter+回复累积同屏（uiautomator 文本连续实证，截图 01/02） |
| 2 | 73921 测试法全链 | ✅ 真机：记 73921 → `am force-stop` → 重进 → 追问「what was the code」→ 模型答 **73921**（r_home journal 懒重建恢复，截图 03） |
| 3 | 同房派活 | ✅ 真机：派活前 5 房 → 第一句 +1（6）→ 第二句仍 6 房，同房间流内见 alpha+beta 两任务（截图 04/05） |
| 4 | 全量绿 + 变异亲杀 | ✅ `assembleDebug test` BUILD SUCCESSFUL，**2218 tests, 0 failures, 0 errors**（debug+release 各 1109）；JS 测试 10/10；变异亲杀见下 |
| 5 | 回归不劣化 | ✅ 左侧栏历史（face_history 语义不变）、专家房间列表（ROOMS 内存数组不含 r_home）、崩溃恢复「已中断」（r_home 无 agent 任务不受影响） |

## 四、变异亲杀记录

| 变异 | 注入 | 结果 | 还原 |
|---|---|---|---|
| V1 (JS) | say() 恢复 `cover.innerHTML=''` | newface-chat-continuity 断言 ② 红 | 绿 |
| V2 (JS) | expertCreateRoom 删 `_homeRoomId` 复用分支 | 断言 ⑤ 红 | 绿 |
| V3 (Java) | persistHomeChat 事件类型 deliver→note | BridgeAiHomePersistenceTest `mutation_assistantEventTypeChanged_breaks` 拦截（助手消息丢失） | 绿 |

## 五、风险与遗留

- **顺手修复工单14 遗留缺口**：`NewFace.openConnect` 未导出（服务连接二级页点按会崩），本次补 `openConnect: openConnect` 导出——验收工单14 时未真机点服务连接页，属既有缺口，交付说明一并注明
- r_home 房间会出现在 env.search 粗搜等房间遍历中（有 journal 即参与），无副作用；如需彻底隔离可加房间类型标记（后续工单）
- 首页对话视觉层不随 journal 回放（重进 App 对话流从空开始，上下文靠模型记忆）——符合用户报障语义「对话连续=追问答对」

---

## 六、打回修复（验收 0bdf18b 打回②：§六 升级情境注入未施工）

**修法**（照 ACCEPTANCE_LOG 附修法 + 派单 §六 补充条款）：
- `handoffToExpert` 拼 ctx 时调用新增 `currentWatchingContext()`：读 `B.query({q:'watch_history'})`，
  取 ts 最大（最近在看）条目，注入 `[当前情境：在看《X》 · 第 N 话]`；读失败静默（不阻塞交接）
- `newface-chat-continuity.test.js` 增断言 ⑥（情境注入 4 项 + 失败静默）

**真机实证**（验收 §六 追加条款）：首页说「write a review essay about xianni」→ 新房首条上下文为
`[type: review essay, topic: xianni] [当前情境：在看《仙逆》 · 第 22 话]`——剧集情境注入成功
（截图 06_upgrade_context_inject.png）

**验证**：JS 10/10 PASS；`assembleDebug test` 2218 tests 0 failures（无回归）
