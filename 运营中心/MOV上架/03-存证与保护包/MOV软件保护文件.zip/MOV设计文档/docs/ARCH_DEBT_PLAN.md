# MOV 架构债清理方案 v4

> 来源：docs/DYAD-VS-MOVAPP.md 对比分析
> 前提：**UI 迁移 Phase 5（删死 CSS）收尾后**再动 Java 层。UI 迁移期间 Java 冻结。
> 原则：一次改一处，改完测试，确认再下一步。

---

## 优先级排序

| # | 事项 | 工时 | 前置 | 动 Java |
|---|------|------|------|---------|
| 0 | 修 26 个失败单测 | 4h | 无 | ✅ |
| 1 | 错误分类（3 类 + retryable） | 3h | #0 | ✅ |
| 2 | 桥接层校验 | 4h | #1 | ✅ |
| 3 | JS 测试（mov-render + chat，jsdom） | 4h | 无 | ✗ |
| 4 | 流式 patch 校验 | 3h | #3 | ✗ |
| 5 | Prompt 模块化 | 4h | 无 | ✅ |
| 6 | 状态机收拢 | 12h | #0 #1 #2 | ✅ |
| 7 | JS 测试补齐（bridge + thinking） | 3h | #6 | ✗ |
| 8 | per-room chatHistory | 2h | 无 | ✅ |

总计 ~39h。不跳序。

---

## 验收与补救通用规则

**量化验收标准（每项必做）：**
- 单测不新增失败（`./gradlew testDebugUnitTest`）
- 真机截图（平板跑核心场景，截屏存档 `docs/verify/`，文件名 `<tag>-<场景>.png`）
- CDP 验证（每个 [ ] 项在 chrome://inspect 控制台打一遍）

**分级补救（出 bug 时按序执行，不要上来就全回滚）：**

| 级别 | 触发条件 | 操作 | 时间 |
|------|---------|------|------|
| L1 热修 | 编译过但不达预期 | 直接改代码 + 重编译安装，同一 commit 追加 | <30min |
| L2 部分回滚 | L1 搞不定 | `git checkout <tag> -- <单文件>` 只还原出错的文件 | <10min |
| L3 全回滚 | L2 不行或涉及 3+ 文件 | `git reset --hard <tag>` + `git push -f`，记 issue | <5min |

**tag 规则：** 每项开始前打 `<tag>-start`，通过后打 `<tag>-done`。L2/L3 回到 `<tag>-start`。

---

## 0. 修 26 个失败单测（前置任务）

**现状：** `./gradlew testDebugUnitTest` 26 failed。改前就坏，不修这个后面改 AgentLoop 更不可能绿。

**验证（量化）：**
- [ ] `./gradlew testDebugUnitTest` → `BUILD SUCCESSFUL`，失败数 = 0
- [ ] 若有 @Ignore：每个带 reason 注释 + issue 链接，总数 ≤ 3
- [ ] 截图：`docs/verify/arch-test-fix-done.png`（终端 BUILD SUCCESSFUL）

**分级补救：**

| 级别 | 场景 | 操作 |
|------|------|------|
| L1 | 个别测试修不动 | 加 `@Ignore("reason #issue")`，不新增 |
| L2 | 修出新的失败 | `git diff arch-test-fix-start` 定位，还原该文件 |
| L3 | — | 只能全回滚（#0 是地基） |

**tag：** `arch-test-fix-start` → `arch-test-fix-done`

---

## 1. 错误分类（3 类 + retryable）

**现状：** AgentLoop 里 catch(Exception e) 吞掉一切，用户看到"执行失败"四个字。

**改动文件：**
- 新增 `agent/MovError.java`（~70 行）
- 改 `AgentLoop.java`：catch(Exception) 的 `fail("执行失败")` → 分类错误
- 改 `ErrorReporter.java`：report() 按 kind 分桶 + EXTERNAL 按 code 去重

**验证（量化）：**
- [ ] 传错文件路径 → 交付卡报 USER 类中文提示，截图 `arch-err-done-user.png`
- [ ] 断网发任务 → 交付卡报 EXTERNAL + 重试按钮可见，截图 `arch-err-done-external.png`
- [ ] 一次任务触发 20 次 API_TIMEOUT → `adb logcat -s MOV-ERR` 只 1 条 + `count=20`
- [ ] msg 超 80 字符 → 日志里实际截断到 ≤80
- [ ] `./gradlew testDebugUnitTest` → BUILD SUCCESSFUL

**分级补救：**

| 级别 | 场景 | 操作 |
|------|------|------|
| L1 | 某个 catch 点分类错了 | 调 MovError 工厂方法参数，重编译 |
| L2 | ErrorReporter 采样逻辑有问题 | `git checkout arch-err-start -- ErrorReporter.java`，其余保留 |
| L3 | AgentLoop 大面积异常 | `git reset --hard arch-err-start` 全回滚 |

**tag：** `arch-err-start` → `arch-err-done`

---

## 2. 桥接层校验

**现状：** BridgeFactory 70 个 @JavascriptInterface 方法，参数不校验。

**改动文件：**
- 新增 `bridge/BridgeGuard.java`（~50 行）
- 改 `BridgeFactory.java`：每个桥方法第一行加校验

**铺设策略：先 3 个试跑，再全量。**
1. 改 postCmd（单参）、aiChatAsync（多参）、ping（白名单）
2. CDP + 真机验证
3. 确认后脚本批量铺剩余 67 个

**验证（量化）：**
- [ ] CDP `B.postCmd(null)` → `{ok:false,error:{code:"EMPTY_PARAM"}}`，截图
- [ ] CDP `B.postCmd("{bad")` → BAD_JSON，截图
- [ ] CDP `B.ping()` → 正常返回，截图
- [ ] 以上 3 张截图存入 `docs/verify/arch-guard-done-cdp-*.png`
- [ ] 正常发消息 → 功能不受影响，截图
- [ ] `./gradlew testDebugUnitTest` → BUILD SUCCESSFUL

**分级补救：**

| 级别 | 场景 | 操作 |
|------|------|------|
| L1 | 单个方法模板写错 | 直接改那一行，重编译 |
| L2 | 试跑 3 个有问题 | 还原 BridgeFactory.java，重新设计模板后重试 |
| L3 | 全量铺崩了/bug 原因不明 | `git reset --hard arch-guard-start` |

**tag：** `arch-guard-start` → `arch-guard-done`

---

## 3. JS 测试（mov-render + chat，jsdom）

**现状：** 15 个 JS 模块零测试。

**依赖：** jsdom（红线唯一豁免）

**改动文件：**
- 新增 `js/__tests__/mov-render.test.js`、`js/__tests__/chat.test.js`
- 新增 `package.json`
- 不改现有 JS

**验证（量化）：**
- [ ] `node js/__tests__/mov-render.test.js` → 所有 assert 通过，exit 0
- [ ] `node js/__tests__/chat.test.js` → 所有 assert 通过，exit 0
- [ ] 截图 `docs/verify/arch-test1-done.png`（终端输出 PASS）
- [ ] CI 挂上：push 时自动跑 node test

**分级补救：**

| 级别 | 场景 | 操作 |
|------|------|------|
| L1 | 某个测试写错了 | 直接改测试文件 |
| L2 | jsdom 引入有问题 | 换最小 DOM mock（手写 20 行 createElement 替代） |
| L3 | 整个测试框架不可用 | `rm -rf js/__tests__ package.json` |

**tag：** `arch-test1-start` → `arch-test1-done`

---

## 4. 流式 patch 校验

**现状：** token 直接拼接，丢 chunk 无检测。

**改动文件：**
- 改 `js/chat.js`：_movToken 加 null 检查 + 起止日志 + 乱序检测（~15 行）

**验证（量化）：**
- [ ] 正常任务 → `adb logcat` 看到 `[mov] loop=X stream START` 和 `stream END`
- [ ] CDP `_movToken("x", null)` → 控制台 warn `null token`，不崩
- [ ] 截图 `docs/verify/arch-stream-done.png`（logcat START/END 闭环）
- [ ] #3 的 chat.test.js 全过

**分级补救：**

| 级别 | 场景 | 操作 |
|------|------|------|
| L1 | 日志格式不对/太吵 | 直接改 chat.js |
| L2 | 校验影响性能 | 降采样：`seq.count % 100 === 0` |
| L3 | _movToken 大面积异常 | `git checkout arch-stream-start -- js/chat.js` |

**tag：** `arch-stream-start` → `arch-stream-done`

---

## 5. Prompt 模块化

**现状：** prompt 是 AgentLoop 里字符串拼接，改词翻 200 行。

**改动文件：**
- 新增 `assets/prompts/system.txt`、`review_rules.txt`
- 新增 `agent/PromptLoader.java`（~40 行，缓存 + 内置默认值兜底）
- 改 `AgentLoop.java`：buildPrompt() 从文件读

**验证（量化）：**
- [ ] debug build 改 system.txt 一个字 → 发任务，新词生效
- [ ] 删 assets/prompts/system.txt → 任务不崩，PromptLoader 内置默认值生效
- [ ] `adb logcat -s PromptLoader` 能看到 `loaded system.txt @version 1.0`
- [ ] `./gradlew testDebugUnitTest` → BUILD SUCCESSFUL

**分级补救：**

| 级别 | 场景 | 操作 |
|------|------|------|
| L1 | 文件路径不对 | 改 PromptLoader 路径常量 |
| L2 | 缓存逻辑有问题 | `git checkout arch-prompt-start -- agent/PromptLoader.java` 单文件回滚 |
| L3 | buildPrompt 异常 | `git reset --hard arch-prompt-start` |

**tag：** `arch-prompt-start` → `arch-prompt-done`

---

## 6. 状态机收拢（收拢到已有 State 枚举，feature flag 灰度）

**现状：** phase/awaiting/step 等变量散落，切房漏清就串房。

**关键约束：AgentLoop.java:172 已有完整 State 枚举（PLANNING/PLAN_GATE/EXECUTING/PAUSED/DONE/FAILED/STOPPED），带 canTransitionTo()/isTerminal()/isActive()。不新增枚举，不合并 STOPPED 和 FAILED（行为不同：stopped 不清产物不记 reason，failed 要记）。**

**改法：两步，feature flag 灰度。**
- 第一步：双写过渡（旧变量 + AgentContext）
- 第二步：删旧变量
- flag：`BuildConfig.USE_CONSOLIDATED_STATE`，debug 先开
- **reset() 只允许终态（DONE/FAILED/STOPPED）调用。活跃态（EXECUTING 等）必须先 cancelAndReset() 停掉正在跑的 shell 进程再重置，否则出"状态机说空闲但 shell 还在跑"的幽灵进程。**

**改动文件：**
- 新增 `agent/AgentContext.java`（~50 行）
- 改 `build.gradle`：加 feature flag
- 改 `AgentLoop.java`：双写 + flag 控制
- 改 `BridgeAi.java`：agentState() 按 flag 读

**验证（量化，最严格）：**
- [ ] #0 做完，单测不新增失败
- [ ] 双写期 5 场景全部录屏：`docs/verify/arch-state-<场景>.png` ×5
- [ ] flag OFF（release）→ 行为和改造前一致
- [ ] flag ON（debug）→ 切房 20 次无串房
- [ ] EXECUTING 切房 → `adb logcat -s AgentContext` 看到 `cancelAndReset`
- [ ] CDP `movTest.agentState()` 返回 state 与实际一致

**分级补救：**

| 级别 | 场景 | 操作 |
|------|------|------|
| L1 | 单个状态转换写错 | 直接改 AgentContext.transition 表 |
| L2 | 双写不一致 | 日志定位哪个点漏写，补写。不改 AgentContext 核心逻辑 |
| L3 | flag ON 大面积崩溃/串房 | `BuildConfig.USE_CONSOLIDATED_STATE = false` 切回旧路径 |

**tag：** `arch-state-start` → `arch-state-done`

---

## 7. JS 测试补齐（bridge + thinking）

**现状：** #3 已覆盖 mov-render/chat。本项补 bridge + thinking，放最后。

**改动文件：**
- 新增 `js/__tests__/thinking.test.js`、`js/__tests__/bridge.test.js`

**验证（量化）：**
- [ ] `node js/__tests__/thinking.test.js` → PASS
- [ ] `node js/__tests__/bridge.test.js` → PASS
- [ ] 截图 `docs/verify/arch-test2-done.png`

**分级补救：** 同 #3

**tag：** `arch-test2-start` → `arch-test2-done`

---

## 8. per-room chatHistory

**现状：** 全局 List，不同房间对话串上下文。

**改动文件：**
- 改 `BridgeAi.java`：`List` → `ConcurrentHashMap<String, List>`
- 改 `HermesActivity.java`：`getChatHistory()` → `getChatHistory(roomId)`

**验证（量化）：**
- [ ] A 房聊"我叫张三" → 切 B 房问"我叫什么" → 不知道
- [ ] 切回 A 房问 → 回答"张三"
- [ ] 截图 `docs/verify/arch-history-done.png`（A 房/B 房各一张）
- [ ] 单测不新增失败

**分级补救：**

| 级别 | 场景 | 操作 |
|------|------|------|
| L1 | 某处漏传 roomId | 补 roomId 参数 |
| L2 | Map 线程安全有问题 | 换 `Collections.synchronizedMap` |
| L3 | 大面积异常 | `git reset --hard arch-history-start` |

**tag：** `arch-history-start` → `arch-history-done`

---

## 红线

1. **UI 迁移 Phase 5 收尾前不动 Java 层**
2. **每项独立 tag：`<tag>-start` → `<tag>-done`**
3. **单测不新增失败**
4. **#6 必须真机 5 场景全过**
5. **不引入新依赖（jsdom 豁免）**
6. **回滚必复盘，记 issue**
7. **合并前 review（#6 至少一人）**
8. **每项验证截图存 `docs/verify/`**

---

## 时间线

```
UI Phase 5 收尾（删死 CSS）
  ↓
#0 修单测（4h）→ arch-test-fix
  ↓
#1 错误分类（3h）→ arch-err
  ↓
#2 桥接校验（4h）→ arch-guard
  ↓
#3 JS 测试 mov-render/chat + jsdom（4h）→ arch-test1
  ↓
#4 流式校验（3h）→ arch-stream
  ↓
#5 Prompt 模块化（4h）→ arch-prompt
  ↓
#8 per-room chatHistory（2h）→ arch-history
  ↓
#6 状态机收拢（12h）→ arch-state（最危险）
  ↓
#7 JS 测试补齐（3h）→ arch-test2
```

**穿插：** #3/#4 只碰 JS，UI 迁移间隙可做。#0/#1/#2/#5/#6/#8 等 Phase 5 收尾。
