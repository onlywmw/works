# 评估：jcode 结合 MOV 的可行性 — 2026-08-09

> 来源：`github.com/1jehuang/jcode`（Rust 编写的 AI 编码 harness，自称「最省内存」，含语义记忆图 / swarm 多 agent / 自研 mermaid 渲染与终端）
> 背景：用户询问能否与 MOV 结合或改造。本文件为**可行性评估**，不动代码。
> 结论先行：**代码不可移植（Rust 桌面 CLI vs Android Java/WebView）**；结合点集中在「语义记忆」与「桌面宿主桥接」两处。推荐先走方向 B（桌面宿主，成本最低、复用现有 MCP/serve 通道），语义记忆（方向 A）作为二期增量。渲染/低 RAM/终端类能力不适用。

---

## 〇、jcode 是什么（30 秒版）

- **形态**：桌面 CLI harness（对标 Claude Code / Codex CLI / OpenCode），Linux/macOS/Windows，安装即用，无浏览器依赖。
- **核心卖点**：
  1. **内存效率**：基准自测单会话 PSS ~28MB（本地 embedding 关）、多会话增量 ~10MB/会话；对比 Claude Code ~387MB / ~213MB 每会话。
  2. **语义记忆图**：每轮对话做向量嵌入 → 记忆图 cosine 相似度检索 → 命中经「memory sideagent」验证相关性后注入上下文；记忆经 sideagent 定期提取/整合，另有显式记忆工具与跨会话 RAG。
  3. **Swarm**：同仓库多 agent 协作，A 改文件 → 服务器通知已读该文件的 B，支持 DM/广播。
  4. **自研渲染**：mermaid-rs-renderer（声称快 1800×）、handterm 终端、侧面板。
- **技术栈**：Rust 为主（~26MB 代码），另有少量 Python/Shell/Swift/TS。

## 一、结合点对照

| jcode 能力 | MOV 现状 | 结合判定 |
|---|---|---|
| 语义记忆图（embedding + cosine + sideagent 验证） | 三层记忆 L1/L2/L3 + journal + 读取预算覆盖（已吸收 OptMem/TencentDB）；**Journal.search 是子串匹配（阶段3 C2），非语义**；LlamaClient 仅做 chat/vision（默认 unlimited-ocr），**无 embedding 端点** | **真实增量**：子串 → 语义。但端侧 embedding 需要新增模型/端点（见 §三 成本） |
| memory sideagent 验证后再注入 | HeavyWorker / Hermes agent 评审环节存在 | 设计可并入现有评审，不另起系统（守住修正③） |
| Swarm 文件冲突通知 | 房间 = 多模型协作，天然多会话 | 思想可借鉴进房间事件推送；与 Workflows 触发器叠加 |
| 低 RAM 多会话 | 端侧资源本来就紧；journal append-only | 方法论参考一次，非代码移植 |
| mermaid-rs / handterm / 高性能渲染 | WebView 渲染 + MovRender | **不适用**（Rust 渲染库搬不进 WebView） |
| harness 本体（PTY/TTY、桌面 UI） | Android 原生 + 内嵌 Ubuntu proot | **不可移植** |

**红线约束**：修正③「长在 journal 上，不平行造系统」——任何结合只允许「借设计进现有通路」，禁止引第三方系统当平行记忆/服务宿主。

## 二、三个方向可行性

### 方向 A：语义记忆设计借鉴（端侧 embedding）— 增量真实，成本中

- **做什么**：在现有 Journal 通路内，把 `Journal.search`（C2 子串匹配）增强为「子串召回 + 语义重排」，或对记忆段做 embedding 索引；检索结果按 cosine 排序。sideagent 验证思路并入 HeavyWorker 评审。
- **可行性**：llama.cpp 本身支持 embedding，MOV 已跑 llama server（127.0.0.1:8080）；但当前只配了 unlimited-ocr 推理模型，**需另配 embedding 模型/端点**。
- **风险**：端侧 embedding 模型体积/精度/电热约束（须符合 L3 空闲窗口纪律）；embedding 端单独自测（单测零网络纪律——注入构造，package-private 解析）。
- **分期建议**：先做**云端 embedding 重排**探路（验证语义检索相对子串的真实增益、token 成本），增益确认后再决策是否上端侧。不破坏读取预算覆盖（覆盖只影响读到什么，原文仍在 journal）。

### 方向 B：jcode 当桌面宿主（MCP 桥接）— 成本最低，复用现有通道

- **做什么**：让 jcode 在桌面充当「重型大脑」，通过 MOV 已有 MCP 通道（`mcp/` 目录完备：McpServer/McpClient/McpProvider）接入房间，作为外部 Worker。
- **可行性**：MOV 的 serve（8387）+ MovInboundServer（8388）+ McpServer 已是常驻 HTTP 面；跨设备用 ADB reverse 打通本地回环即可，不破「绑死 127.0.0.1 + X-Mov-Token」纪律。
- **待验证前提**：jcode 是否支持 MCP client/server（README 未明确，需查 jcode.sh/docs 实证）。
- **价值**：桌面算力/完整 TTY 跑重活，MOV 平板当控制面，契合「接任何服务」定位；多出一个房间可插拔 Worker。

### 方向 C：渲染 / 低 RAM / harness 移植 — 不适用

- mermaid-rs / handterm 是 Rust 渲染，进不了 WebView；内存 benchmark 只取方法论（端侧遥测已有 _telemetry，可参考其多会话增量口径）。

## 三、成本与风险汇总

| 项 | 方向 A | 方向 B |
|---|---|---|
| 新增模型/依赖 | 端侧 embedding 模型（体积/精度权衡） | 无（复用现有 mcp/ 通道） |
| 新增代码 | Journal 检索改造 + embedding 客户端 + 单测 | MCP 侧适配 + 鉴权接线 |
| 破坏红线风险 | 需守住「不平行造库」+ 单测零网络 | 需守住 serve 纪律（fail-closed 401） |
| 真机验证 | L2+ 需证据链 | 需 ADB reverse + 跨设备会话证据链 |

## 四、分期建议

1. **阶段 0**：本评估定案（现状）。
2. **阶段 1（先做）**：方向 B——验证 jcode 的 MCP 支持 → ADB reverse 打通 → 桌面上跑通 jcode↔MOV MCP 会话。
3. **阶段 2（二期）**：方向 A——云端 embedding 重排探路 → 增益确认 → 决策是否上端侧。
4. **明确不做**：jcode 渲染/终端移植、harness 移植 Android、引 jcode 做平行记忆库。

---

## 附：关键事实依据

- MOV：`Journal.search` 为大小写不敏感子串匹配（`agent/Journal.java` search/searchableText，阶段3 C2）；`LlamaClient` 仅 buildChatPayload/buildVisionPayload（127.0.0.1:8080，默认 unlimited-ocr）；`mcp/` 目录含 McpServer/McpClient/McpProvider + Jackson schema 校验；serve 8387 / MovInboundServer 8388 / McpServer 8389。
- 记忆设计基线：`docs/DESIGN_MEMORY_LAYERS.md`（三层五律 + 修正③④，读取预算覆盖）。
- 外部参考先例：`docs/RESEARCH_TENCENTDB_AGENT_MEMORY.md`（吸收思路不移植实现）、`docs/EVAL_OPENCLI.md`（同款评估格式）。
