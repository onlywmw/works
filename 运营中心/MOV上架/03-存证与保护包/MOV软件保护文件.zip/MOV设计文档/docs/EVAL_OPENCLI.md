# OpenCLI 技术萃取 — 2026-07-31

> 来源：`OpenCLI-main.zip`（jackwener/opencli，Node.js，100+ 站点 CLI 适配器 + Browser Use）
> 结论：**理念同源（网站→确定性接口给 AI 用），工程细节大量可偷**。MOV 的 WebAdapter 按下面五处吸收。

## 一、最有价值：API 发现方法论（直接移植）

`skills/opencli-adapter-author/references/api-discovery.md`——**反爬红线表**，我们撞过的坑全在册：

| 信号 | 厂商 | 含义 | 策略 |
|---|---|---|---|
| `acw_sc__v2` / `ssxmod_itna` | Aliyun WAF | 返回滑块非真数据 | 先在浏览器上下文验证，再定 fetch 路线 |
| `__cf_bm` / Cloudflare Ray ID | Cloudflare | TLS 指纹标记 | 同上 |
| `_abck` / `bm_sz` | Akamai | 带 cookie 也常被挡 | 同上 |
| `geetest` / `gt_captcha` | 极验 | 滑块，程序无解 | 放弃或 UI 策略 |

- **MOV 直接吸收**：WebAdapter 探索第一步加「反爬指纹检测」（B站 412 风控就属于这类，当时我们硬试出来的）
- 还有 CORS 跨子域判定法（跨 subdomain fetch 必死，除非 ACAO）——蚂蚁/未来站点多 subdomain API 时用得上

## 二、adapter-author 四段法（比我们的 WebAdapter 框架细）

```
site-recon（站点侦察分类）→ api-discovery（找数据 endpoint）→ field-decode（字段解码）→ verify（实跑验证）
```

- 配套模板：adapter-template.md（声明式 adapter 结构）/ coverage-matrix.md / field-decode-playbook.md / jsdom-fixture-pattern.md
- **MOV 吸收**：WebAdapter 的 A/B/C 分级保留，但探索流程改走这四段（尤其是「先侦察分类，再发现 endpoint」的顺序——我们上次是先试 URL 再想结构，顺序反了）

## 三、声明式 adapter 结构（SiteCard 升级参考）

```js
cli({ site, name, args: {...}, columns: [...], func: async (page, args) => rows })
```

- 每个 adapter = 一次声明（站点/命令/参数/列定义/实现函数）
- **auth 标准化**：`registerSiteAuthCommands({site, loginUrl, quickCheck(cookies), verify(identity)})`——和我们 douyinStatus 同款但更标准，MOV 的「连接」机制（抖音/腾讯）可以统一成这个形态
- **MOV 吸收**：SiteCard schema 加 `columns`（输出字段约定）和 `auth`（quickCheck+verify 两段）两个字段

## 四、100+ 站点知识库（现成弹药）

`clis/` 目录——每个站点一个适配器包，含端点/解析/测试：
- **12306**（用户早就想接的订票场景！）、bilibili、知乎、小红书、36kr、51job、youtube、tvmaze…
- **MOV 吸收**：按场景移植端点知识（不是搬代码——他们是 Node+浏览器扩展，我们是 Java+WebView，但 **URL 模式/字段结构/解析规则是可移植的**）
- 优先：12306（订票）、bilibili（已死过一次的源，看看他们怎么绕风控）

## 五、对照：Browser Bridge vs MOV ConnectWeb

| | OpenCLI | MOV ConnectWeb |
|---|---|---|
| 载体 | Chrome 扩展 + 本地 daemon | 自包含 WebView 容器 |
| 会话 | 用户自己的 Chrome 登录态 | CookieManager 应用内共享 |
| 诊断 | `opencli doctor` 全链路自检 | （无，值得抄） |

- **MOV 更自包含**（不依赖用户装 Chrome），但 `opencli doctor` 的**环境自检命令**值得偷：一条命令输出 桥/会话/网络/规则 全链路健康度——MOV 可以做个 `mov doctor`（验收排障都快）

## 行动清单（给 P1/P2）

1. WebAdapter 探索流程改四段法（site-recon → api-discovery → field-decode → verify）+ 反爬红线表进 api-discovery 步骤（**本项最高优先**）
2. SiteCard schema 加 `columns` + `auth{quickCheck,verify}` 两字段；「连接」机制（抖音/腾讯 auth）统一成 registerSiteAuth 形态
3. 12306 适配器端点知识移植（订票场景预研，W3 的 SPIKE 前置）
4. B站适配器研究（clis/bilibili/utils.js 的 wbi 签名+风控绕行——我们的 412 死局他们有解）
5. `mov doctor` 环境自检命令（桥/会话/网络/规则一屏输出）

## 不吸收的

- Browser Bridge 扩展+daemon 架构（MOV 自包含 WebView 更轻，不引入外部依赖）
- CLI 枢纽/gh/docker 包装（与 MOV 场景无关）
- 他们的 npm 生态（语言栈不同，只移植知识不移植代码）
