# Termux API / Widget 取经评估 — 2026-07-31（用户拍板：不整包加入，当目录用）

> 来源：`Desktop/GitHub项目/termux-api-master.zip`（52 个设备能力 API）+ `termux-widget-master.zip`（桌面小组件跑脚本）。
> 结论：**不整包合并**（GPLv3 传染面 + 半数已有或踩隐私红线），把 52 个能力当「能力目录」对账，缺口走 MOV 自己的 ToolProvider 体系自研补齐。

## 一、对账总表（termux-api 52 类 → MOV 处置）

| 分类 | termux-api 项 | MOV 现状 | 处置 |
|---|---|---|---|
| **已有，不重复** | Clipboard / Toast / Notification / Volume / Brightness / Battery / Download / MediaScanner / Keystore / Vibrate | SystemToolProvider 10 个 L1 工具已覆盖 | ✅ 不动 |
| **隐私红线，永久不接** | SmsInbox / SmsSend / CallLog / ContactList / Telephony | — | 🚫 端侧定位 ≠ 读短信通讯录；除非用户明确拍板且走支付闸级审批 |
| **值得补（本期）** | SpeechToText / TextToSpeech / Location / Torch | 缺 | 🎯 自研补齐，见下 |
| **v2 候选** | Sensor / NotificationList / CameraPhoto / Wifi / Audio | 缺 | 📋 排队，需权限闸设计 |
| **参考不搬** | MediaPlayer（有自己的播放器）/ SAF / Share / Dialog / Wallpaper / Usb / Nfc / Infrared / MicRecorder / JobScheduler / Fingerprint | 各有对应或暂无场景 | 👀 需要时抄接口设计 |
| **基础设施** | ResultReturner / SocketListener / TermuxApiReceiver 等 IPC 骨架 | MOV 桥体系已完备 | ❌ 不需要 |

## 二、本期补缺 6 项（优先级排序）

> ⚠️ 2026-07-31 修正：盘点发现 `UtilityToolProvider` 已有 **speech.recognize**（STT）、`ExtraToolProvider` 已有 **location.get**——缺的不是工具，是接线（新脸路由不认识它们）。#1/#3 从「自研新建」改为「接线+复验」。

| # | 能力 | 场景 | 实现路径（自研，零 GPL） | 工作量 |
|---|---|---|---|---|
| 1 | **SpeechToText** ⭐插队 | 「说一句话，服务就到了」的咽喉 | **已有 `speech.recognize`（UtilityToolProvider）→ 只需接线到 newface + 真机复验** | ~1 小时 |
| 2 | **TextToSpeech** | agent 回答念出来（老人/驾驶/平板远场） | `android.speech.tts.TextToSpeech` | ~1 小时 |
| 3 | **Location** | 「我家附近的盖浇饭」「去最近的机场」 | **已有 `location.get`（ExtraToolProvider）→ 补权限闸即可** | ~半天 |
| 4 | **Torch** | 「帮我开手电」高频小工具 | CameraManager.setTorchMode | ~10 行 |
| 5 | Sensor（v2） | 摇一摇/步数 → 情景图谱素材 | SensorManager | 排队 |
| 6 | NotificationList（v2） | 通知摘要（端侧） | NotificationListenerService + 用户明示授权 | 排队 |

> 接口命名/参数设计可参考 termux-api（思想不受版权保护），**代码一行不搬**——Android 原生 API 人人可调，没有移植必要。

## 三、termux-widget 的遗产（只借思想）

- ❌ 不搬代码、不加依赖
- ✅ 借思想：**桌面小组件 = 一句话入口**。MOV 的 `HermesWidgetProvider` 升级为「桌面麦克风按钮」：按下 → 直接进 newface 并唤起 STT 收音。比「跑脚本」贴合「说一句话，服务就到了」的理念
- 与补缺 #1（STT）合并施工，一次到位

## 四、红线

1. **零 GPL 代码搬入**：终端两模块（terminal-emulator/terminal-view）是仅有的例外，已封版；设备能力一律自研
2. **隐私红线不分级豁免**：短信/通讯录/通话记录永久不接（与「不碰钱」同级的「不碰信」）
3. **新能力必须过权限闸**：定位/麦克风/通知读取都是敏感权限，申请时机=用户首次说到相关指令时，不得启动即要
4. **STT/TTS 失败要诚实**：识别不出 → 「没听清，再说一次？」；不得静默转文字乱猜（参照「宁演不识」禁令）

## 五、派单建议

- **P1**：STT（#1）+ TTS（#2）+ 桌面麦克风 widget（三合一，「说」的闭环）→ Torch（#4 顺手）
- **P2**：Location + 权限闸（#3，要动审批体系，适合细致活）
- 回归向量：每项能力至少 1 条真行为断言（如 Torch 的 CameraManager 调用可用 mock 验参数，STT 意图路由「帮我打开手电」→ torch 工具）

## 六、termux-packages（追加评估，同日拍板）

- 是什么：2093 个 Linux 包的**构建脚本库**（build.sh + bionic 补丁），无预编译二进制
- 处置：**不合入仓库**（14MB 死重，依赖 Termux 整套构建链），留在本机当外部参考源
- 用途：rootfs（hermes-agent.zip）将来加工具时查 patch（ffmpeg/imagemagick/aria2 等）
- 省事优先路径：直接取 **Termux 官方 apt 仓库的预编译 .deb**，`ar`+`tar` 解进 rootfs，绕开 dpkg 数据库（不踩 app uid 的坑）
- 红线：下载器类包（yt-dlp 等）涉版权，**永久不接**——与假数据禁令/不碰钱/不碰信同级
