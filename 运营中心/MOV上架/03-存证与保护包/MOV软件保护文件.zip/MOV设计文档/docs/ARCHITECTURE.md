# MOV 是什么构造（大白话版）

> 一句话：**MOV 是开在你手机里的一个小作坊**。你跟它说人话，它交出真东西（文件、网页、能装的 App）。
> 看不懂类名没关系，记住 6 个角色就行。

---

## 6 个角色

### 1. 门面 —— 你看到的那个界面
聊天、房间、文件、运行状态，全在这层。
技术上就是一个网页（12 个 JS 文件拼的），但它只是**显示器 + 按钮**，自己不干活。

### 2. 传菜口 —— 界面和手机系统之间的唯一通道
界面上点任何按钮，都通过 70 个"窗口"喊手机系统干活（读文件、调模型、调安装器）。
**安全规矩：每个窗口都有保安，出错只说"失败了"，绝不许把错误扔到界面上**（扔到界面 = 白屏）。

### 3. 大脑 —— 真正想事儿的
你的目标交给它，它拆成计划、一步步干、干完汇报。
它本身不在手机里，是云端的 DeepSeek/通义这些大模型；手机里的是**指挥它的教练**（AgentLoop），负责：
- 目标有歧义就先反问你（理解闸）
- 把它的计划拦下来给你批（计划闸）
- 盯着它别偷懒别跑偏（步数上限、工具纪律）
- 搞砸了就给你一张失败卡，能一键重来

### 4. 双手 —— 大脑能用的工具
三类：
- **文件**：读、写、查房间里的文件
- **手机硬件**：手电、亮度、音量、朗读、通知、剪贴板……共 30 样
- **打包机**：把网页压成一个真能安装的 APK（烧烤摊 App 就是这么来的）

### 5. 仓库 —— 文件放哪
每个房间一个独立仓库，产出/资料/归档分开放。
**每次覆盖旧文件前自动留底（快照）**，改坏了能一键回到上一版。

### 6. 保安 —— 三道闸（你唯一需要操心的地方）
| 闸 | 什么时候拦你 | 你要做的 |
|---|---|---|
| 理解闸 | 你的话有多种理解时 | 点一个选项（不用打字） |
| 计划闸 | 每次任务一次 | 看一眼"它理解成什么+要动哪些文件"，批准或驳回 |
| 交付验收 | 交活的时候 | 每个文件能点开预览，满意再装/再用 |

除了这三下，其余全自动。

---

## 走一遍：你说"帮我做个烧烤摊收银应用"之后

1. 大脑琢磨：这话有两种意思（顾客点单？老板记账？）→ **理解闸弹出两个选项**，你点"老板记账"
2. 大脑出计划：一张卡片写着"给谁用/什么场景/要改哪个文件" → **你批准**
3. 大脑写 bbq.html（计划内的文件，直接写，不再烦你）
4. 大脑喊打包机：bbq.html → bbq.apk
5. **交付卡**：bbq.html（可预览）、bbq.apk（可安装）→ 你点安装 → 桌面出现"烧烤摊收银"
6. 要是中途断网了 → **失败卡**：原因说人话 + 已完成的保留 + 一键重开

第 6 步那种情况，已烧的 token 不白费：重开时大脑看到"文件已经在了"，会接着干而不是重写。

---

## 精确版（给要改代码的人，2026-08-02 按现有代码核对）

| 角色 | 真实代码 |
|---|---|
| 门面 | `assets/hermes-shell.html`（唯一 WebView 壳）+ `js/` 15 个模块（新脸 `newface.js` 3202 行 + 专家模式） |
| 传菜口 | `bridge/BridgeFactory`（**115 个 @JavascriptInterface，聚合 9 子桥**）+ `BridgeValidator`（校验）+ `BridgeGuard`（参数闸）+ `bridge/BridgeKernel`（postCmd/query 新桥） |
| 大脑 | `agent/AgentLoop`（循环）+ `agent/ToolRegistry`（**~107 工具**）+ `ai/AiClient`（调模型）+ `agent/FastWorker`（默认大脑）+ `agent/HeavyWorker`（内嵌 Hermes 委派） |
| 双手 | 根包 `IntentParser`→`CapabilityExecutor`（30 能力）+ `StorageManager`（文件）+ `packager/`（APK 打包）+ `linux/`（proot Ubuntu 全工具链）+ `ConnectWeb`（浏览器） |
| 仓库 | `StorageManager`（房间文件）+ `agent/Journal`（**append-only 事件溯源，唯一消息真理源**） |
| 记忆 | `agent/Journal`（journal.jsonl）+ `vault/`（双副本保险柜 v1）+ `context/`（情境感知） |
| 引擎 | `workflow/`（触发器引擎，纯 JVM：14 触发器+9 条件）+ 根包 `Workflows`（ConnectWeb 集成） |
| 壳 | `HermesActivity`（WebView）+ `ConnectWebActivity`（浏览器）+ `TerminalActivity`（M3 终端）+ `HermesSettingsActivity`（设置）+ `HtmlViewerActivity` 等 |

**规模（实测）**：Java **143** 文件 + **1 Kotlin**（ModelToolProvider.kt）· JS 15 模块 + 3 目录外 · 桥方法 **142**（BridgeFactory 115）· 工具 **~107** 静态 + MCP 动态 · 能力 30 · 测试 **610+** · Gradle 模块 3（`app` / `terminal-emulator` / `terminal-view`）· OCR 独立脚本线（`ocr/` 17 脚本，不入 Gradle）
约束细节：本文末尾「合同约束汇编」+ `CONTRACT_STORAGE/MODEL/ROOM/CAPABILITY/STREAMING.md`；产品方向：`MOV-STRATEGY.md`
（注：`cron/` 定时模块已整体移除，68541fd）

---

## M1 内嵌 Linux（linux/ 包，2026-07-24 真机落地）

第 7 个角色：**真电脑** —— 手机里再装一台完整的 Ubuntu 24.04，agent 用
`shell.exec` 跑真 shell（python3/git/联网），用 `file.push`/`file.pull` 在房间和
Linux 之间搬文件（guest 里挂 `/exchange`）。

### 架构要点（全是真机撞出来的）

- **proot 用户态 chroot，无 root**：二进制为 green-green-avk/build-proot-android
  的**静态构建**（动态链接系统 bionic、无第三方依赖），以 `libproot.so` 名义打进
  `jniLibs/arm64-v8a`（Android 只释放 `lib*.so` 命名的文件，且需 manifest
  `extractNativeLibs="true"`），安装时释放到 nativeLibraryDir —— app 域
  （untrusted_app）唯一能 exec 原生二进制的位置。
- **Termux 版 proot 不能用**：app uid 下 dpkg 必报
  "unable to securely remove .dpkg-tmp"（其 seccomp/loader 与 app uid 不兼容）。
- **app 域 SELinux 禁止 exec /system/bin/tar** → GNU tar/gzip 及其依赖
  （libacl/libiconv/libcharset/libandroid-glob/libandroid-selinux/libpcre2-8）
  全部随包（libtar.so/libgzip.so，仅 RootfsManager 解压用）。
- **app 域 SELinux 禁止创建硬链接**（dontaudit，无 avc 日志），且静态 proot 的
  `--link2symlink` 模拟只走 seccomp 拦截、在 app 域不生效（runas_app 域反而生效；
  设 PROOT_NO_SECCOMP 则更糟：linkat 直接 ENOSYS）。
  ⇒ **rootfs 必须预消除硬链接 + 预装包**：在 shell 域解包 Ubuntu Base 24.04、
  apt 装好 python3/python3-venv/git，修掉 l2s 残留的绝对 symlink，
  `tar --hard-dereference` 重打包。安装时只做 复制→解压→写
  resolv.conf/99mov-proot→`python3 --version` 验活（约 1 分钟），不做 in-app apt。
- **运行命令行**：`proot -0 --kill-on-exit --link2symlink -r rootfs -b /dev -b /proc
  -b /sys -b linux-exchange:/exchange [-b /sdcard:/sdcard] -w /root /usr/bin/env
  PATH=.. HOME=/root DEBIAN_FRONTEND=noninteractive /usr/bin/bash -lc 'cmd'`
  - `-0` fake root（dpkg 检查 geteuid()==0）
  - `--kill-on-exit`（超时 destroyForcibly 时 tracee 孤儿化会持 dpkg lock 卡死）
  - 必须显式注入 PATH/HOME（继承 Android PATH 则 guest 命令全部 not found）
  - env 注入 `PROOT_LOADER=libproot-loader.so`（execve EACCES 回退）、
    `TMPDIR`/`PROOT_TMP_DIR=files/linux/tmp`
- **陷阱：`run-as` 处于 runas_app 域，没有网络权限** —— 验证联网/apt 必须用真实 app。
- **已知边界**：guest 内 apt/dpkg 装新包在 app 域不可用（dpkg status 备份必做
  link()，硬链接被禁且模拟不生效）；需要新包时走预置 rootfs 重建路线。

### 代码与数据

| 件 | 位置 |
|---|---|
| 引擎定位/探测 | `linux/Proot.java`（设置页顶部探测行 = M1 生死验证） |
| 执行器 | `linux/ProotRunner.java`（buildArgs/truncate 纯函数可单测；超时 15–600s，stdout/stderr 各 6000 字符截断） |
| 安装/状态机 | `linux/RootfsManager.java`（NOT_INSTALLED→…→READY，state.json 持久化；本地包 `/sdcard/MOV/ubuntu-base.tar.gz` 优先免下载） |
| agent 接线 | `ToolRegistry.build(..., linuxAvailable)` 注册 shell.exec/file.push/file.pull；`AgentLoop` allowedShell 闸（计划内含=批准即授权；计划外→shellPreview 卡→`respondShell`） |
| 文件交换 | `StorageManager.pushToExchange/pullFromExchange`（canonical 双向防越界） |
| 设置页 | HermesSettingsActivity「Linux 环境」区（探测/状态/磁盘占用/安装/授权/卸载） |

---

## M2 内嵌 Hermes agent（2026-07-24 真机落地）

在 M1 的 Ubuntu 里再装一个完整的 Hermes agent（Nous Research, v0.19.0），
MOV agent 通过 shell.exec 把重任务（深度调研/大文件生成/多步骤自动化）委派给它。

### rootfs 预装清单（ubuntu-base.tar.gz, 226MB, M2 版）

Ubuntu Base 24.04.3 (aarch64) + python3 3.12.3 / python3-venv / python3-pip 24.0 /
python3-dev / git 2.43.0 / ca-certificates（`update-ca-certificates` 已跑）/
curl 8.5.0 / build-essential (gcc 13.3.0)。shell 域装好 → 修 l2s 绝对 symlink →
`tar --hard-dereference` 重打包（0 硬链接条目）。M1 版备份为 ubuntu-base-m1.tar.gz。

### Hermes 安装与配置

- **源码**：hermes-agent 0.19.0 精简（去 tests/website/apps/infographic/docs 等，
  158MB→48MB）打成 `assets/hermes-agent.zip`（16MB, 2088 文件）。
- **安装器** `linux/HermesInstaller.java`（rootfs READY 后可触发，hermes-state.json
  持久化 NOT_INSTALLED/INSTALLING/READY/ERROR）：
  解 zip → `linux-exchange/hermes-agent`（guest `/exchange`）→
  `python3 -m venv ~/.hermes-venv` →
  `pip install -e '/exchange/hermes-agent[termux]' -c constraints-termux.txt`
  （真实 app 域有网，约 40 个依赖全部 aarch64 wheel，~10 分钟）→
  `~/.hermes-venv/bin/hermes --version` 验活。
- **配置注入**（幂等，安装后与模型变更时可重跑）：MOV 默认模型（ModelRegistry
  缺 key 时兜底 AiProviderConfig 旧配置）→ `~/.hermes/.env`
  （OPENAI_API_KEY/OPENAI_BASE_URL）+ `config.yaml`
  （`model: {default, provider: custom, base_url}`，变量名经 hermes 源码确认）。
  key 只写文件不进日志。
- **委派格式**（headless，源码 hermes_cli/oneshot.py 确认）：
  `~/.hermes-venv/bin/hermes -z '<任务>'` — 单发执行，自动批准工具
  （HERMES_YOLO_MODE=1），只把最终回答打到 stdout；启动开销 ~50s，
  shell.exec timeoutSec 给 300–600。

### M2 新踩的坑（已修）

- **CA 证书包 postinst 在 proot 下静默失败** → pip 报
  "Could not find a suitable TLS CA certificate bundle"；解法：root 域补跑
  `update-ca-certificates` 后重打包。
- **TMPDIR 泄漏**：ProotRunner 曾给 proot 设 TMPDIR=宿主路径，该变量泄漏进
  guest，guest 程序 mktemp 必败（update-ca-certificates 实踩）；proot 自己的
  临时目录只能走 PROOT_TMP_DIR，TMPDIR 一律不设。
- pip 直连 pypi.org 可用（国内网络偏慢但通），未用镜像。
- e2e 手法：mock-llm-m2 按 system prompt 分流 MOV/Hermes 两个"大脑"，
  Hermes 主对话走 SSE 流式（stream:true 时 mock 回 SSE chunk）。

---

## 真实链路终验（2026-07-24, 小米 MiMo 真实 API）

大脑与 hermes 主模型均配 MiMo（OpenAI 兼容, mimo-v2.5-pro-ultraspeed）。
全程无 mock，真机实测通过。暴露了三个真实 bug（均已最小修复）：

### 1. hermes 自定义端点必须 named custom provider（401 修复）
M2 的 `buildConfigYaml` 生成 `provider: custom` + `model.base_url`，hermes
主循环把 `custom` 当内建别名解析、请求落到错误端点 → MiMo 返回
`HTTP 401: Invalid API Key`（key 本身 PC curl 验证有效）。**修复**：
config.yaml 改生成 `providers` 块注册端点 + `model.provider` 指向别名，
key 只经 `key_env: OPENAI_API_KEY` 引用 .env（不明文）：
```yaml
model: { default: "<model>", provider: "mov-custom" }
providers:
  mov-custom: { base_url: "<url>", key_env: "OPENAI_API_KEY" }
```
验证：root 域 hermes -z '1+1' → 真实回答 `2`；MOV 内委派任务
shell.exec→hermes→file.pull 全通（hermes plugin discovery 日志 + 产物短诗）。

### 2. desk 单聊停在旧版单模型配置（ModelRegistry 迁移遗留）
`routeMessage` 用 `B.aiInfo()`（旧 AiProviderConfig）判断是否已配置 →
配了 ModelRegistry 也回「AI 尚未配置」。**修复**：desk 单聊优先取注册表
默认模型（`B.listModels()` isDefault+apiKey 非空）走 `aiChatWithModel`，
兜底旧配置。验证：desk 单聊「用一句话介绍你自己」→ MiMo 真实回复。

### 3. B.listModels() 的 toJson 无 isConfigured 字段
前端判断"已配置"不能用 `m.isConfigured`（undefined）→ 用 `apiKey 非空`
（脱敏后仍非空）。

### 配置同步钩子
`BridgeModel.setDefaultModel` 成功后后台触发
`HermesInstaller.writeModelConfig`（幂等）——换默认模型即同步 hermes 配置，
不必重装 Hermes。

### 真实终验产物
- 贪吃蛇 APK：`snake.html`（146 行完整 HTML5 canvas 游戏，keyboard 控制）
  → `snake.apk`（17KB）计划→批准→file.write→app.package→交付全通
- hermes 委派：短诗任务 shell.exec→hermes（真实 plugin discovery + MiMo）
  → file.pull 取回 `poem.txt`（完整 4 行诗）

---

## M4 全栈交付（2026-07-24, agent 写后端→自测→ssh 部署）

目标：产物"能上线"——agent 写 FastAPI/Express 后端，内嵌 Linux 本地起服务
curl 自测，ssh/scp 部署到用户服务器，APK/前端走 HTTPS 对接。

### rootfs 工具链（ubuntu-base.tar.gz, M4 版 381MB）

M2 基础上补 `nodejs v18.19.1 / npm 9.2.0 / sshpass 1.09 / openssh-server`
（M2 版备份 ubuntu-base-m2.tar.gz）。重打包 `tar --hard-dereference`（0 硬链接条目）。

### 部署服务器配置（linux/DeployConfig.java）

- 存储：host/port/user/authType(密码|私钥)/secret，走模型 key 同款
  EncryptedSharedPreferences；设置页「部署服务器」区（保存/测试连接/状态），
  BridgeFactory 三接口（getDeployConfig[脱敏]/saveDeployConfig/testDeployConnection）。
- **注入 rootfs（内联参数，不写 ~/.ssh/config）**：保存时生成
  `/usr/local/bin/movssh` + `movscp`：
  - 密码 → `SSHPASS='..' sshpass -e ssh ...`，私钥 → 裸 `ssh -i key ...`
  - host/port/user 全内联（agent 只写 `movssh 'cmd'` / `movscp f /remote/dir/`）
  - `-o ConnectionAttempts=15`（扛 localhost 夹具重启间隙 + 网络抖动）
  - `scp -O`（Ubuntu24 scp 默认 SFTP 协议，远端 sftp-server 不稳，强制 legacy）
  - `UserKnownHostsFile=/dev/null`（否则更新 known_hosts.old 时 unlink 被 app 域 SELinux 拒）
  - 测试连接 = ProotRunner 真跑一次 `movssh 'echo MOV_SSH_OK'`

### M4 踩坑（全实测，已修）

- **不写 ~/.ssh/config**：app 域解压的文件属主是 app uid，guest fake root 下
  ssh 报 `Bad owner or permissions on /root/.ssh/config` → 目标参数全内联进 movssh/movscp。
- **sshd daemon 在嵌套 proot 下不可用**：OpenSSH daemon 模式的 rexec/fork 子进程
  及 privilege separation 的 chroot，在 proot 里执行 guest shell 报
  `/bin/bash: No such file`（dropbear 同病）。`sshd -ddd`（debug 模式禁 privsep）正常。
  ⇒ localhost 验收夹具 = **proot 内 bash 循环跑 `sshd -d`**（proot 主进程常驻稳定，
  每连接一个 sshd -d 子进程被正常 ptrace attach；见 movsvc 脚本）。
  注意：这只影响"平板当被控端"的夹具；MOV 作为 ssh **客户端**部署到用户真实
  服务器（标准 sshd）完全正常。
- **PEP 668**：Ubuntu24 系统 python 禁 `pip install` 直装（externally-managed）→
  prompt 教 venv 或 `--break-system-packages`（M2 装 hermes 用 venv 所以没踩）。
- 服务守护：shell.exec 里 nohup 起的服务会被 ProotRunner `--kill-on-exit` 清场
  （本地自测只能在同一命令内 curl 验证）；经 ssh 在远端起的服务不受此限
  （远端 sshd 侧无 kill-on-exit）——所以"本地自测 + 远端持久"的分工天然成立。

### prompt 全栈工作流（AgentLoop.PLAN_RULES/STEP_RULES）

- ❌做不了 删「真后端」；✅能做 加全栈交付段（写后端→本地 curl 自测→
  movssh/movscp 部署→HTTPS 对接，未配置→ask_user 引导去设置页）。
- 部署纪律：本地起服务 curl 自测通过才部署；systemd 或 nohup+日志守护；
  部署后必须 curl 健康检查再交付；长命令 timeoutSec 给足；防火墙/端口提示；
  有域名→nginx+certbot，无域名→诚实说明 WebView 拦明文 HTTP。
- pip 纪律：venv 或 --break-system-packages。

### localhost 验收夹具复现（无真实服务器时）

```sh
# root 域 (KernelSU): 起 sshd 于 127.0.0.1:8022, root/mov123
# 关键: 必须 proot 内 bash 循环 sshd -d (debug 禁 privsep), 不能用 daemon
LIBD=$(pm path com.hermes.android | sed 's/package://' | xargs dirname)/lib/arm64
export LD_LIBRARY_PATH=$LIBD PROOT_LOADER=$LIBD/libproot-loader.so
R=/data/data/com.hermes.android/files/linux/rootfs
nohup $LIBD/libproot.so -0 --link2symlink -r $R -b /dev -b /proc -b /sys -w /root \
  /usr/bin/env PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
  HOME=/root TMPDIR=/tmp \
  /usr/bin/bash -c 'while true; do /usr/sbin/sshd -d -p 8022 -E /tmp/sshd.log; sleep 0.2; done' &
# 设置页「部署服务器」配 127.0.0.1:8022 root/mov123 → 测试连接
```

### 验收产物（e2e agent-m4-deploy-verify.js, mock 驱动真实执行）

FastAPI 留言板：写后端+前端 → file.push → 本地 uvicorn 自测(curl 200) →
movscp 部署 → 远端 uvicorn 起服务 → 健康检查 `{"status":"ok"}` →
远端文件 /root/deploy/guestbook_api.py 存在 + 远端服务 8023 持续在跑 +
前端 fetch 指向 8023/api。全部断言通过。

---

## 房间即 Linux 工作区（M-ARCH 架构修正, 2026-07-24）

修正 M1-M4 的"两张皮"：房间不再是外挂 Linux 之外的孤岛靠 file.push/pull 手动搬运，
而是 **房间 = 内嵌 Ubuntu 里的一个项目目录**。

```
房间 (rooms/<id>/files/work)  ⇆  bind  ⇆  guest /room (-w /room)
  ├─ agent 的 file.write → 直接落在这个目录
  ├─ shell.exec        → 同一目录里直接跑 (零搬运)
  ├─ 工具              = 完整 Linux 工具链 (python3/git/node/jq/rg/curl/gcc/apt)
  └─ Java 层只剩: 模型调用 / APK 打包安装 / 设备能力
```

### bind 设计（ProotRunner）

- `ProotRunner.exec(ctx, cmd, timeoutSec, roomDir)`：roomDir 非空时命令行追加
  `-b <roomDir>:/room` 且 `-w /room`（为 null 时维持旧行为 `-w /root`，
  RootfsManager 安装/自检用）。
- `BridgeAi.shellExec` 把当前房间 `sm.roomWorkDir(roomId)` 传给 ProotRunner；
  `AgentLoop.Tools` 接口不变（roomId 在 BridgeAi 闭包里）。
- guest 内对 /room 的写入与 host 侧 file.write 是同一批文件
  （external-files 目录，app uid 拥有，fake root 下可写，M1 同机制）。
- **file.push / file.pull 退役**：从 ToolRegistry 注销（`/exchange` bind 保留给
  hermes editable 源码与调试）；prompt 世界观同步重写
  （"shell.exec 是主工具， file.* 是同目录快捷方式"）。
- hermes 委派同样受益：`hermes -z` 以 /room 为 cwd，产物直接留在房间。

### 验证（e2e agent-arch-room-verify.js）

正向：file.write hello.py → shell.exec 同目录直接运行（pwd=/room +
`hello-from-room 3.12.3` 输出）→ file.read 产物；反向：shell echo 建文件 →
房间文件列表立即可见。全程零 push/pull。

### 创建即初始化（M-ARCH-ENV, 2026-07-25）

创建房间不再是"秒开空壳"：点创建 → 按钮变「正在准备环境…」→
`B.prepareRoomEnv`（linux/RoomEnv.java，后台线程）真实执行：

1. rootfs READY 检查（未就绪 → needInstall，房间照建但环境卡标 ⚠️ + 引导去设置页）;
2. 确认房间 work 目录;
3. proot 预热（exec `true` 分摊冷启动）;
4. 一条 exec 实测工具链：`python3/node/git/jq/rg/hermes --version` 逐项解析
   （parseToolVersions 纯函数）;
5. 环境清单写 room.json env 段（StorageManager.writeRoomEnv/readRoomEnv）;
6. 房间 seed 环境卡（t:'env', render.js mkMsg 渲染，✓绿/⚠️橙）+ 真实耗时
   （"房间环境就绪 · 1.2s"）。

e2e（agent-env-card-verify.js）：正常路径数据与 root 域实测对拍一致；
边界（rootfs 改名模拟未就绪）→ 环境卡标「⚠ Linux 环境未就绪」+ 引导，恢复后正常。

⚠️ **rootfs 只能 app 域解压**：root 域 untar 的 rootfs 里 root 创建的 symlink
对 app 域 SELinux 不可读（dontaudit），proot 起 guest 必炸
（execve ENOSYS/interp 找不到）。修复/重建一律走 RootfsManager（app uid untar），
root 域只用于"装包进 seed 源 + 重打包"（/data/local/tmp 下操作，不进 app 目录）。

### rootfs 预装清单（M5 版 384MB）

M4 基础上补 `jq 1.7 / ripgrep 14.1 / unzip 6.0 / zip 3.0 / wget 1.21 / nano 7.2`
（M4 版备份 ubuntu-base-m4.tar.gz）。

---

## 交付质量闸门（2026-07-24, 针对"死按钮/交付不诚实"）

> **2026-07-30：多模型评审机制已整体移除**（计划评审 doPlanReview + 交付评审
> DELIV_REVIEW/deliveryVote + 返工循环 + 评审团 AgentReview/buildReviewer +
> 评审模型配置 isReviewer/setReviewer）。finish 后直接交付，质量闸门保留
> 下述「功能自检清单」与 ComplianceScanner 交付基线扫描（见交付卡 compliance 字段）。

### 功能自检清单（诚实交付，保留）
- PLAN_RULES：finish summary 必须含【功能自检清单】，逐项标 ✅真实现/⚠️演示及原因，
  禁止漏项；做不出真功能的 UI 元素必须在产物里带可见「演示」角标。
- AgentLoop.deliver 把 summary 的 ✅/⚠️ 行解析成 `checklist` JSON（ProductDigest.
  parseChecklist，纯函数），交付卡分色结构化渲染（✅绿/⚠️橙）。
- 附带修（保留）：deliver() 先落事件再置 DONE（此前 state=DONE 先于 log(d)，测试/观察者
  会在 deliver 事件前读到 DONE 竞态）。

---

## M3 交互式终端（terminal-emulator 原生方案，2026-07-24 真机落地）

给用户一台能敲的真终端：原生 TerminalView（非 xterm.js）跑 proot Ubuntu
交互 shell。源码移植自 termux-app（GPLv3，见两模块内 LICENSE.md）。

### 模块融合

- `terminal-emulator/`（VT 仿真 + JNI pty/fork/exec，C 编 libtermux.so，
  ndkBuild）与 `terminal-view/`（TerminalView 控件）**复制进 MOV 仓库**，
  仅改 build.gradle（去 maven-publish，定死 compileSdk 36 / minSdk 26 /
  ndkVersion 27.1.12297006 / abiFilters arm64-v8a 与 app 对齐）。
  **零 termux-shared 依赖**（两模块 import 自查确认，裁剪成本为零）。
  terminal-emulator 自带 148 个上游单测随仓保留（补 testImplementation junit）。
- `settings.gradle` 纳入两模块，app 仅 `implementation project(':terminal-view')`
  （它 api 依赖 terminal-emulator）。APK 增加 libtermux.so (47KB)。

### 会话与参数

- `linux/TerminalEnv.java`：交互式启动参数纯逻辑（可单测）。命令行与
  ProotRunner 同形态（`-0 --kill-on-exit --link2symlink -r rootfs -b /dev
  -b /proc -b /sys [-b exchange:/exchange] [-b /sdcard] -w /root /usr/bin/env
  PATH=.. HOME=.. TERM=xterm-256color ... /usr/bin/bash -l`），差异仅交互式
  `bash -l` + TERM 注入；proot 自身 env 走 PROOT_LOADER/PROOT_TMP_DIR。
  pty 由 terminal-emulator 的 JNI 提供（fork+execvp）。
- `TerminalActivity`（com.hermes.android，全屏）：TerminalView + 简化版
  虚拟按键行（ESC/CTRL/ALT/TAB/方向键；CTRL/ALT 为 toggle，经
  TerminalViewClient.readControlKey/readAltKey 供 KeyHandler 消费）。
  rootfs 未 READY 时显示引导文本而非崩会话。
- 入口：主界面运行页顶栏 `>_` 按钮（bridge.js `B.openTerminal` →
  BridgeFactory `@JavascriptInterface openTerminal()`）+ 设置页 Linux 卡
  「打开终端」。

### M3 踩坑（已修）

- **TerminalView 默认不可 focus**：termux 在 XML 里声明 focusable，代码
  动态 new 出来的是不可 focus 的 → requestFocus 永远 false，键盘/IME 输入
  全被按键行按钮截获（按键事件到 window 但分发给 Button）。必须
  `setFocusable(true)+setFocusableInTouchMode(true)`。
- **adjustResize 按键行被软键盘遮**：manifest+代码双设 SOFT_INPUT_ADJUST_RESIZE
  且根布局 `fitsSystemWindows=true` 才生效（否则键盘盖住按键行）。
- 无害噪音：proot `chdir("/root")` 警告（-w 在 host 侧先 chdir）与 bash
  `groups: cannot find name for group ID`（Android 组 ID 不在 guest
  /etc/group）——shell 功能不受影响，未处理。
- 卸载重装 rootfs 后 hermes venv 在 rootfs 内随删（重装 Hermes 即恢复）；
  M2 曾用 root 域热修的 CA 文件会让重装时 clearDirectory 删不动
  （SELinux 上下文异，dontaudit 无日志）——需要 root 清理，普通用户路径
  （应用内安装/卸载，不经 root 热修）不受影响。

---

## 当前架构快照（2026-08-02，按现有代码实测）

> 从 M1-M4 演进来的最新形态。演进史在上文各节；本节是现状全貌。

### 包结构（`app/src/main/java/com/hermes/android/`，143 Java + 1 Kotlin）

| 包 | 类数 | 职责 |
|---|---|---|
| 根包 `com.hermes.android` | 52 | Activity 壳（HermesActivity/ConnectWebActivity/TerminalActivity/HermesSettingsActivity）、IntentParser→CapabilityExecutor（30 能力）、StorageManager、场景卡（TrainSource/MusicSource/FastSceneProvider）、ConnectWeb 浏览器（BrowserActionExecutor/Router/DiffHelper）、PaymentGate/PayQRRelay、SessionVault/PiiMasker、Workflows 集成壳、DeviceTriggerManager、10 个 ToolProvider |
| `.agent` | 26 | AgentLoop（PLANNING→PLAN_GATE→EXECUTING→DONE）、ToolRegistry（~107 工具）、Worker 接口 + FastWorker/HeavyWorker、Journal（append-only 事件溯源）、IntentEngine、DramaSource、ComplianceScanner、PermissionPolicy、ProductDigest |
| `.bridge` | 13 | BridgeFactory（115 @JavascriptInterface，聚合 9 子桥：device/ai/file/skill/model/kernel/a2a/ocr/vault）、BridgeKernel（postCmd/query）、BridgeValidator/BridgeGuard |
| `.workflow` | 11 | 纯 JVM 触发器引擎：WorkflowEngine（触发→条件→动作）、TriggerEvaluator（14 触发器）、ConditionEvaluator（9 条件）、CronParser |
| `.context` | 8 | 情境感知中枢：ContextProvider（快照 + 4 族状态事件 + 端侧落盘），喂 workflows/支付闸/AgentLoop |
| `.vault` | 7 | 双副本保险柜 v1：SecureVault（Keystore AES-GCM）、KeyguardGate（锁屏闸）、DualWriter（双副本分流）、KeystoreCrypto/AesGcm |
| `.linux` | 7 | 内嵌 Ubuntu 24.04：Proot/ProotRunner/RootfsManager/HermesInstaller/DeployConfig/RoomEnv/TerminalEnv |
| `.ai` | 5 | OpenAI 兼容 LLM 客户端：AiClient、AiProviderConfig、ContextWindow、SseParser、StreamWatchdog |
| `.model` | 3 | 多模型注册中心 ModelRegistry + ModelConfig/ModelPresets |
| `.packager` | 3 | HTML→签名 APK：PackageBuilder/ApkAssembler/AxmlPatcher |
| `.mcp` | 3 | MCP 客户端/提供方/服务端（McpClient/McpProvider/McpServer，localhost JSON-RPC） |
| `.widget` | 2 | 桌面快捷指令小组件 |
| `.skill` | 1 | 技能存储 SkillStore |
| `.llama` | 1 | 本地 llama-server 客户端（纯 JVM，OCR 解码器接入点） |
| `.a2a` | 1 | A2A 传输层（OkHttp 异步） |

### 核心链路（三条）

1. **消息真理源**：`Journal`（Java，每房间 `journal.jsonl` append-only）→ `MovRender`（JS，`mov-render.js`）投影 → chatBody DOM。localStorage 只存房间元数据。
2. **指令优先路由**：`IntentParser` → `CapabilityExecutor`（30 能力直调 Android API）命中即执行；未命中 → AI（FastWorker/AgentLoop）。
3. **一表两脑**：`ToolRegistry`（工具注册表，15 个 ToolProvider + MCP 动态）＝一表；快脑 = `FastWorker`（云端模型，AiClient.chatStream，默认大脑）；慢脑 = `HeavyWorker`（内嵌 Hermes 委派 `hermes -z` / serve 路径）。

### 前端（`assets/`）

- **壳**：`hermes-shell.html`（113 行，唯一 WebView 页面，含新脸 view + 抽屉 + 专家面板占位）
- **15 个 JS 模块**（加载顺序即依赖顺序）：`i18n → store → bridge → mov-render → thinking → mov-mock → render → chat → runtime → newface-router → newface-delivery → newface-match → newface-expert → newface → app`
  - `bridge.js`：`B` 对象封装（postCmd/query）+ `_movEvent` Java→JS 事件通道 + `movTest` 测试 API
  - `mov-render.js`：MovRender，journal 事件→DOM 统一渲染
  - `newface.js`（3202 行）：新脸首页 + 专家模式（房间列表/会话/运行/文件四界面）
  - `newface-*.js` 四个：从 newface 抽出的纯逻辑模块（node 可单测）
- **3 CSS**：tokens.css / shell.css / newface.css；**5 HTML**（hermes-shell 为唯一壳，其余编辑器/模板/演示页）
- 旧壳 `factory-edition/`（app-chat/app-room 等）已冻结不参与运行

### 演进史之后新增（2026-07-25 ~ 08-02）

- **vault 保险柜 v1**（P5）：双副本（净化副本自由流通 + 原始副本 Keystore 加密进保险柜）；`vault_lock/unlock`=ACTION 审批闸、`vault_list`=READONLY
- **workflows 触发器引擎**（P1）：纯 JVM，ConnectWeb 事件源注入，扩展至 14 触发器+9 条件
- **新脸化**（P1）：`newface.js` + 专家模式（视图欠账视图还），旧底导航/旧视图清场
- **情境感知**（context/）：设备情境快照 + 状态事件（屏/电/电池/耳机/wifi/bt），喂 workflows/支付闸
- **MCP/llama/a2a**：McpServer 暴露桥方法、LlamaClient 接本地 llama-server、A2A 传输层
- **Kotlin 起步**：ModelToolProvider.kt（Java→Kotlin 渐进迁移第一站）

### OCR 线（独立脚本，`ocr/`，不入 Gradle）

- **技术栈定论**：视觉编码器 MNN（SAM-ViT-B + CLIP-L，273 token/页）+ 解码器 llama.cpp/ggml（DeepSeek-V2-MoE，q4_K_M 1.82GB）
- **R-SWA patch**：`ocr/patches/rswa-b10216.patch`（llama.cpp b10216，参考前缀常驻 + W=128 滑窗，恒定 KV）——golden 100%、单页 31.3s、RSS 2.14GB、40 页长文档 2.85GB 全过
- 17 个脚本：`export_vision_onnx/export_decoder_onnx/gguf_convert/build_llama_cpp/vision_infer/ocr_accept` 等；黄金样本 `ocr/testdata/golden/`
- app 侧无 OCR 运行时依赖（仅 `LlamaClient` 客户端 + `OcrTextSanitizer`）

### 非 App 资产

- `tools/`：桌面端 E2E 验证 harness（agent-*-verify.js + mock-llm + driver.js，Node 驱动 ADB 真机）
- `terminal-emulator/` + `terminal-view/`：M3 终端（Gradle 模块，GPLv3 移植自 termux-app，148 上游单测）
- `termux/`：未入构建的本地运行脚本；`hermes-agent.zip`（16MB vendor）；`site/`、`hermes-agent/`

---

## 合同约束汇编（2026-07-25 合并：原 CONTRACT_ARCH / SECURITY / RUNTIME / ZINDEX）

> 四份小合同并入本文，原文件已删。编号保持原样：§A=ARCH 技术边界、§B=SEC 安全、
> §C=RT 运行页、§D=Z 层级；外部引用按「ARCHITECTURE.md 汇编 §X-n」索引。
> **Cron 模块已整体移除（68541fd）——相关边界/用例/约束一律标注作废，不再执行。**
> 仍独立的合同：`CONTRACT_STORAGE.md` `CONTRACT_MODEL.md` `CONTRACT_ROOM.md`
> `CONTRACT_CAPABILITY.md` `CONTRACT_STREAMING.md`。

### §A 技术边界（原 CONTRACT_ARCH v1.0）

1. **平台：Android 手机，API 26+，targetSdk 36。** WebView + 纯 HTML/CSS/JS 前端。无前端框架。
2. **存储根路径：`context.getExternalFilesDir(null) + "/mov/"`。** 禁止 `/sdcard/mov/`。
3. **所有持久化 key 变更必须走 `MigrationManager`。** 无例外。
4. **所有桥方法参数必须过 `BridgeValidator`。** 无例外。
5. **所有 AI 文件写入必须经用户确认，无例外。确认粒度 = 计划闸（DESIGN_AGENT_LOOP）：批准计划即授权计划内列出的文件路径；执行段计划外路径由代码硬拒绝；每次写入记录工作日志。**
6. ~~Cron 只能执行白名单 action~~（作废：Cron 模块已移除，68541fd）。
7. **JS 文件加载顺序 = 依赖顺序。** `i18n → store → bridge → render → chat → files → runtime → app-chat → app-room → app-files → app-run → app`。
8. **两个 view（view-rooms, view-room）在会话 tab 中切换，view-run 独立。** 切换通过 CSS `.act` class，不销毁重建。

注：文件清单与启动流程以本文「精确版（给要改代码的人）」节为准——原 ARCH 清单含已删除的 cron/看板条目，不再维护。

### §B 安全（原 CONTRACT_SECURITY v1.0）

#### 验收用例

- **TC-SEC01 API Key 加密存储**：addModel 后 SharedPreferences 中值 ≠ 明文（已加密）；`listModels()` 脱敏 `sk-1****cdef`；`listModelsFull()` 仅 Java 内部返回完整 Key。
- **TC-SEC02 加密不可用时拒绝保存**：Keystore 不可用 → 不降级明文；`isEncrypted()=false`；JS toast「⚠ 加密存储不可用」；可添加模型但 apiKey 不持久化。
- **TC-SEC03 路径遍历被拦截**：`checkPath("../../etc/hosts")` → `{"ok":false,"error":"路径越界"}`，文件操作不执行。
- **TC-SEC04 超大内容被拦截**：`checkContent(6MB)` → `{"ok":false,"error":"内容过大 (>5MB)"}`。
- ~~TC-SEC05/06 Cron 白名单~~（作废：Cron 模块已移除）。
- **TC-SEC07 Widget receiver 权限保护**：第三方发 ACTION_EXECUTE → 缺 EXECUTE_WIDGET 权限 → 指令不执行。
- **TC-SEC08 消息渲染不执行脚本**：`<img src=x onerror=alert(1)>` 显示为纯文本，图片不加载脚本不执行。

#### 实现约束（不可违反）

1. **所有桥方法的路径参数必须通过 `BridgeValidator.checkPath()` 校验。** 禁止直接拼接路径。
2. **所有桥方法的内容参数必须通过 `BridgeValidator.checkContent()` 校验。** 5MB 硬上限。
3. ~~Cron 白名单硬编码 `CronPolicy.ALLOWED_ACTIONS`~~（作废：Cron 模块已移除）。
4. **Widget receiver 必须声明 `android:permission`。** 且 `executeCommand()` 必须过白名单检查。
5. **`render.js` 的 `mkMsg()` 必须用 `textContent` 设置用户输入文本。** 禁止 `innerHTML` 拼接用户输入；保留 `<code>` 用 `createElement('code')` + `textContent`。

### §C 运行页（原 CONTRACT_RUNTIME v1.0）

#### 验收用例

- **TC-RT01 进程卡片显示真实数据**：运行 >1 分钟后 pid/运行时长（"2h 13m"）/内存/AI 调用次数/最近指令均非 "--"。
- **TC-RT02 模型列表动态渲染**：NATIVE ENGINE + 已配模型逐行显示；默认标记 + 在线 🟢；点模型行设默认 toast；点「＋ 添加模型」弹快捷添加 sheet（见 CONTRACT_MODEL TC-M09），仅 ≡ 个人信息行与默认模型行跳原生设置页。
- **TC-RT03 模型全未配 → 引导**：NATIVE ENGINE + 空状态文案含「去设置页添加模型」引导，不崩溃。
- ~~TC-RT04/05/06 Cron 创建/删除~~（作废：Cron 模块已移除）。
- **TC-RT07 通道折叠行**：全部正常时只显示「全部正常」摘要，点开展开 4 通道详情。
- **TC-RT08 权限折叠行**：7 权限全部授权 → 折叠行完全隐藏。
- **TC-RT09 个人信息行**：显示用户名；点 ≡ 跳 AI 设置页。

#### 实现约束（不可违反）

1. **所有数据实时查询，不进缓存。** 每次切到运行 tab 重新调 `B.runtimeStats()` / `B.listModels()` 等。
2. **模型列表从 `B.listModels()` 动态生成，不硬编码。**
3. ~~Cron 最小间隔 15 分钟 notice~~（作废：Cron 模块已移除）。
4. **权限全部授权时 `rowPerms` 必须 `display:none`。** 不在 DOM 中占位。
5. **个人信息行的 ≡ 按钮调用 `B.openSettings()` 跳原生设置 Activity。** 不跳 WebView 内页面。

### §D 层级系统（原 CONTRACT_ZINDEX v2.0）

#### 分层体系（当前实现）

```
 30   .sheet .preview-overlay ← 底部 sheet + 文件预览 overlay
 29   .sheet-mask .preview-mask ← sheet 遮罩 + 预览遮罩
 20   .msg-actions            ← 长按操作条
 15   .bnav                   ← 底部导航栏
  5   .fab .file-fab .back-float .abar ← 浮动按钮 / 顶栏
```

| 层级 | z-index | 元素 | 备注 |
|------|---------|------|------|
| sheet | 29-30 | 所有底部 sheet + 遮罩, 文件预览 + 遮罩 | mask=29, panel/overlay=30 |
| action | 20 | 长按操作条 | 高于 nav(15), 低于 sheet(29) |
| nav | 15 | 底部导航栏 | — |
| float | 5 | FAB, 文件FAB, 返回按钮, 顶栏 | 内容区之上, nav 和 sheet 之下 |

#### 验收用例

- **TC-Z01 底部 sheet 不被导航栏遮挡**：sheet 滚到底，所有内容可见，max-height:92% 顶部不超出屏幕。
- **TC-Z02 长按操作条在 sheet 之下**：sheet 打开时操作条(20)被遮罩拦截不可点。
- **TC-Z03 FAB 在 sheet 之下**：sheet 打开时 FAB(5) 不可点击。

#### 实现约束（不可违反）

1. **所有 sheet 统一 `.sheet-mask{z-index:29}` 和 `.sheet{z-index:30}`。** 禁止单个 sheet 用 ID 选择器覆盖 z-index。
2. **新增 UI 组件时，先查本节确定层级，再赋值。** 禁止随意选数字。

注：死代码清理（`#sheetMask`/`#sheetNew`/`.dialog-mask`）已落地 shell.css，原约束 2/3 完成归档。
