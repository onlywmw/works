# Dyad vs MOV-APP 架构对比报告

> 基于 Dyad v1.9.0 源码（1525 TS 文件，462 测试文件）和 MOV-APP main 分支（b380521）实际代码。
> 生成日期：2026-07-26

---

## 一、整体架构

| 维度 | Dyad | MOV-APP |
|------|------|---------|
| 运行环境 | Electron (Chromium + Node.js) | Android WebView + Java Bridge |
| 渲染层 | React 18 + TanStack Router | 原生 JS (无框架) + 手写 DOM |
| 状态管理 | Jotai atoms + 显式状态机 | 散装全局变量 (`_agentLoop`, `_agentExecuting`, `_movStreams`, `_movEndedLoops`, `_agentLogBuf`) |
| 数据持久化 | Drizzle ORM + SQLite (WAL) | Journal JSONL 追加文件 + SharedPreferences |
| 代码规模 | ~1525 个 TS/TSX 文件 | ~50 Java + ~15 JS 文件 |
| 测试 | 462 个测试文件, hybrid 框架 | 256 个 Java 单测, JS 层零测试 |
| 语言 | TypeScript (strict mode) | Java + ES5 JavaScript (无类型检查) |

---

## 二、桥接层 (IPC / Bridge)

| 维度 | Dyad | MOV-APP |
|------|------|---------|
| 契约定义 | `defineContract()` + Zod schema，定义一次自动生成客户端/校验/白名单 | 无契约，裸字符串方法名，`@JavascriptInterface` 手动声明 |
| 类型安全 | 端到端推断：契约 → 客户端 → handler，编译期 + 运行时双重校验 | 无。Java 返回 JSON 字符串，JS 侧 `JSON.parse` 无校验 |
| 输入校验 | `createTypedHandler` 内 Zod `safeParse`，畸形输入直接拒绝 | 无。`postCmd` 的 JSON 不校验字段，`type`/`roomId` 可以是任意值 |
| 返回值协议 | 信封协议：`{__dyadIpcEnvelope:"v1", ok:true, value:T}` | 裸 JSON：`{ok, data, error}`，无类型标记，无法区分用户错误和系统 bug |
| 错误跨边界 | `serializeIpcError` 保留 `DyadErrorKind`，接收端重建 | `catch(Exception ignored){}`，错误类型信息全部丢失 |
| 通道白名单 | 从契约自动派生 `VALID_INVOKE_CHANNELS` | 无白名单，所有方法暴露给 JS 层 |
| 单向通道 | `SendContract` (fire-and-forget)，防 frame 销毁后回复崩溃 | 无。所有调用都是同步返回或 `evaluateJavascript` 单向推送 |
| 流式通道 | `StreamContract`: chunk/end/error 三事件，`InvocationRef` 关联 | `evaluateJavascript` 拼字符串：`"window._movToken(" + ... + ")"`，无关联 ID，无完整性校验 |
| 安全边界 | `contextBridge` + preload，只暴露白名单通道 | `addJavascriptInterface`，整个 `BridgeFactory` 对象暴露 |

---

## 三、流式渲染

| 维度 | Dyad | MOV-APP |
|------|------|---------|
| token 传输 | 主进程 → `webContents.send`，结构化 chunk 事件 | Java → `evaluateJavascript`，字符串拼接 `"window._movToken(...)"` |
| token 拼接 | tail-append patch + 偏移量 + djb2 哈希校验，patch 失败 → `triggerResync` | `s.text += (token\|\|'')` 裸拼接，丢一个 token 永久错位，无检测无恢复 |
| 批量/节流 | 主进程侧批量发送，渲染侧 rAF 对齐 | Java 侧 400ms 一批 (`BridgeAi:146`)，JS 侧无节流，每批直接写 DOM |
| 滚动跟随 | react-virtuoso `followOutput`: `isAtBottom ? "auto" : false`，`atBottomThreshold=80px` | `chatPane.scrollTop = scrollHeight`，无条件滚到底，用户上滚也被拉回，无"用户在阅读"检测 |
| 流状态 | 状态机 6 态：`idle→starting→streaming→cancelling→finalizing→idle` + `errored` | 标志位组合：`_movStreams[loopId]` 存在 = 流中，`_movEndedLoops[loopId]` = 已结束，无 starting/finalizing 概念 |
| 取消 | 多阶段：cancel → cancelling → registered 竞态 → 重发 abort → wasCancelled 终态兜底 | `B.postCmd({cmd:'stop_task'})`，发出去不管，无确认，无竞态处理 |
| 定时器管理 | 状态机 finalizing 态统一清理，不可能遗漏 | 切房守卫曾漏调 `endStream`（已修），依赖每个路径手动清理 |
| 错误保留 | `lastErrorByChatId` Map，新 controller 继承上次错误 | 无。流失败后错误信息丢失，切房再回来看不到之前的错误 |

---

## 四、Agent 生命周期

| 维度 | Dyad | MOV-APP |
|------|------|---------|
| 状态描述 | `StreamState` 联合类型，一个对象 = 全部状态，`never` 穷举检查 | 5 个独立变量：`_agentLoop` (对象\|null)、`_agentExecuting` (bool)、`_agentLogBuf` (数组)、`_movStreams` (字典)、`_movEndedLoops` (字典) |
| 计划审批 | `plan_handoff` 状态机：`idle→cancelling-stream→transitioning→persisting→preparing-chat→awaiting-stream-idle`，每步有失败类型 (`HandoffFailure`) | `_agentLoop.awaiting = 'plan'`，字符串标志，无转换约束，切房时自动驳回但无状态追踪 |
| 工具审批 | agent tool consent: ask/always/never 三级，持久化到 settings | `_agentLoop.awaiting = 'fileWrite'\|'shell'`，每次询问，无记忆，切房自动驳回 |
| 切房处理 | 状态机 + `InvocationRef`，旧流事件自动路由到旧 controller，新流不受影响 | 切房守卫 `if(curRoomId!==id)`：deliver/fail/stopped 手动清理（曾漏 endStream，已修） |
| 排队 | prompt queue：状态机管理入队/出队/编辑/删除，机器生成的不可编辑/删除 | `_agentLogBuf` (上限 50)：只处理启动竞态，非通用队列 |
| 暂停/续跑 | 状态机 cancelling 态 + resume 事件 | `_agentLoop.awaiting = 'paused'`，无状态机约束 |

---

## 五、错误处理

| 维度 | Dyad | MOV-APP |
|------|------|---------|
| 错误分类 | `DyadErrorKind` 10 类：Validation / NotFound / Auth / Precondition / Conflict / UserCancelled / RateLimited / External / Internal / Unknown | 无分类：全部是 `catch(e){}` 或 `catch(Exception ignored){}` |
| 遥测过滤 | 7 类预期错误不上报，3 类 (External/Internal/Unknown) 自动上报 PostHog | 无遥测 |
| handler 包装 | `createTypedHandler`：输入校验 → 执行 → 遥测 → 信封，异常不会泄漏到渲染层 | 无包装：每个方法自己 try/catch，异常处理不一致 |
| JS 侧错误 | `window.onerror` → 结构化错误面板 + 分类 | `window.onerror` → 红色 sysline 插入 chatBody，无分类 |
| 静默吞错 | 无。`safeSend` 也有 `log.debug` | `BridgeAi:358` `catch(Exception ignored)`；`AgentLoop:774` `catch(Exception ignored)`；`BridgeAi:657` 已修为 `Log.w`（本次） |

---

## 六、Prompt 工程

| 维度 | Dyad | MOV-APP |
|------|------|---------|
| 组织方式 | `src/prompts/` 独立模块：`system_prompt.ts` (783行)、`plan_mode_prompt.ts`、`local_agent_prompt.ts`、`security_review_prompt.ts` | `AgentLoop.java` 内硬编码字符串拼接 |
| 指南系统 | `guides/` 目录：`add-authentication.md`、`add-email-verification.md`，含 `<critical-rules>` `<anti-patterns>`，按框架过滤 | 无 |
| 用户规则 | `AI_RULES.md` 占位符替换 `[[AI_RULES]]` → 用户文件内容 | 无用户自定义规则入口 |
| 快照测试 | `system_prompt.test.ts` + `__snapshots__/` 目录，prompt 变更自动检测 | 无 |
| 思考提示 | `THINKING_PROMPT`：强制 `<think>` 结构化思考 | 无 |
| 模式分派 | `constructSystemPrompt` 按 `chatMode` 路由：build / ask / plan / local-agent | 单一 prompt，无模式区分 |

---

## 七、预览 / 产出

| 维度 | Dyad | MOV-APP |
|------|------|---------|
| 实时预览 | iframe sandbox：`sandbox="allow-scripts"`，独立进程渲染 | 无实时预览，产出文件需手动打开 (`HtmlViewerActivity`) |
| 控制台 | `preview_console`：捕获 iframe `console.log/error`，流式推送到 UI | 无 |
| 构建反馈 | `app_run` 状态机：`installing→building→running`，错误实时显示 | 无构建反馈，工具调用结果写 journal |
| 版本预览 | `version_preview`：任意历史版本即时预览，不影响当前工作 | 无 |

---

## 八、测试基础设施

| 维度 | Dyad | MOV-APP |
|------|------|---------|
| 单元测试 | Vitest，462 个测试文件 | JUnit，256 个测试 |
| 集成测试 | `hybrid.setup.ts`：mock Electron + 真实 IPC handler + happy-dom 渲染器 | 无 |
| 状态机测试 | `transition.test.ts`：全 state×event 矩阵 + co-simulation 对比测试 | 无 |
| E2E | Playwright：`e2e-tests/` 目录，fixtures + snapshots | 无 |
| Prompt 测试 | snapshot 测试：prompt 输出变更自动检测 | 无 |
| JS 层测试 | 渲染器组件全覆盖 | 零 |

---

## 九、工程规范

| 维度 | Dyad | MOV-APP |
|------|------|---------|
| 规则文档 | `rules/` 目录 28 个规则文件，每个领域独立 (IPC / 状态机 / 错误 / 测试 / git / 样式 / i18n) | `CLAUDE.md` 一个文件包含所有规范 |
| 产品文档 | `PRODUCT.md`：用户画像 / 品牌个性 / 反参考 / 设计原则 / 无障碍标准 | 无 |
| AGENTS.md | 规则索引表 + 前置检查清单，"写代码前必须读对应规则" | `CLAUDE.md` 含模块所有权 / 决策矩阵 / 代码规范 |
| 状态机文档 | `docs/why-state-machines.md`：真实 bug 故事 → 为什么用状态机，before/after 代码对比 | 无 |
| ADR | `docs/adr/` + `docs/adrs/`：架构决策记录 | 无 |
| 提交前检查 | `npm run fmt` + `lint` + `ts` + husky pre-commit | `black` + `ruff` + `pytest` + pre-commit hooks |

---

## 十、MOV-APP 有而 Dyad 没有的

| 维度 | MOV-APP | Dyad |
|------|---------|------|
| 移动优先 | Android 原生 + WebView，触摸手势 / 长按 / 滑动 | 桌面 Electron |
| 设备控制 | `BridgeDevice`: 真实设备指令，`execCommand` → shell | 无（纯代码生成） |
| 离线运行 | 完全本地，无网络依赖（除 AI 调用外） | 需要 API key 联网 |
| Journal 架构 | 追加式 JSONL + `RandomAccessFile` 尾部反向读，O(tailN) 回放 | SQLite 关系型，Drizzle ORM |
| APK 产出 | 工具调用可直接产出 APK，一键安装到设备 | 产出 Web 应用 |

---

## 总结：差距不在功能，在"状态纪律"

Dyad 的核心优势不是功能多，是**每个状态都有唯一所有者、每个转换都是显式的、每个错误都有分类**。

MOV-APP 的功能覆盖（设备控制、离线、APK 产出）是 Dyad 没有的差异化优势，但**状态散落**（5 个变量描述一个工作流）和**错误黑洞**（`catch ignored`）是当前最大的架构债。

### 建议优先级

| 优先级 | 事项 | 理由 |
|--------|------|------|
| 紧急 | 状态机收拢 | 解决切房泄漏类 bug 的根因 |
| 重要 | 桥接层校验 | 解决乱码 / 静默失败的排查盲区 |
| 重要 | 错误分类（3 类就够） | 用户错误 / 外部错误 / 内部错误 |
| 中期 | 流式 patch 校验 | 防 token 丢失错位 |
| 中期 | Prompt 模块化 | 可维护性 |
| 长期 | JS 层测试 | 回归防护 |
