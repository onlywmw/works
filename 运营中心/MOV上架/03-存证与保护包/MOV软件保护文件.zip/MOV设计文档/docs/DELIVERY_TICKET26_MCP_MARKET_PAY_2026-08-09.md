# 工单26 交付说明 · MCP 市场 幕二+幕三（付费全链）

> 日期：2026-08-09 · 分支：`feat/mcp-market` · 交付：见本文件所在 commit
> 派单：`docs/TASKS_P1_MCP_MARKET_M2_M3_2026-08-09.md` + 实施手册 `docs/TASKS_P1_MCP_MARKET_M2_M3_IMPL_2026-08-09.md`

## 一、交付内容（8 施工件全落地）

| 件 | 内容 | 落点 |
|---|---|---|
| M0-1 | 商户四证 + 卖家签名私钥入保险柜（prefs 只存 vault id） | `pay/MerchantCreds.java` + 桥 `mktSaveMerchant` + 设置页「商户收款」二级页（账户管理 → 商户收款） |
| M0-2 | A2aClient 多身份（deviceId 前缀 key，TokenStore 抽象可测） | `a2a/A2aClient.java`（旧单身份兼容） |
| M1-1 | 微信 API v3 签名（SHA256withRSA 五段签名串） | `pay/WxPaySigner.java` |
| M1-2 | Native 下单 + 查单（HttpTransport 接口化，OkHttp 生产/fake 测试） | `pay/WxPayClient.java` |
| M1-3 | 订单五态状态机（CREATED→PAYING→PAID→DELIVERED→INSTALLED + EXPIRED/MANUAL），journal 重放重建 | `pay/OrderStore.java` |
| M1-4 | 查单轮询 5s×≤360（30min）→ EXPIRED；连续 5 错 → MANUAL；绑 App 生命周期 | `pay/MarketEngine.java` |
| M3-1 | MOV-MCP 加密包（zip 5 件：manifest/spec/report/payload.bin AES-GCM/signature RSA） | `pay/MovmcpPackager.java` |
| M3-2 | 发货器：PAID 触发，K 每单随机、随单加密存 vault、只发付款 buyerId、用毕即焚 | `pay/MarketEngine.deliver()` |
| M3-3 | 安装器：验签（失败 journal 留痕拒装）→ 解密（K 即焚）→ 计划闸 AlertDialog → config/package 两型安装 → journal 回执 + A2A `mkt.installed` | `pay/MovmcpInstaller.java` |
| M2-1 | 市场桥 4 方法（cbId 异步，不进 BridgeKernel） | `bridge/BridgeMarket.java` + BridgeFactory 委托 |
| M2-2 | 市场页付费区：mktBuy 真流程 + 收款卡（金额/倒计时 30:00/去支付/状态轮询 5s）+ `_mktEvent` 状态推送 + 安装完成跳本地页 | `assets/js/mov-market.js`（createElement/textContent） |
| M4 | 货架 7 件（6 演示 + 0.01 验收包 pkg-accept-001）补 fen/sellerDeviceId/sellerPubKey；Java 侧 `pay/Shelf.java` 为真实交易数据源 | `pay/Shelf.java` + `mov-market.js GOODS` |

## 二、验证

- **全量**：`./gradlew assembleDebug test` → debug+release 各 **1209 tests, 0 failures**（APK 458MB）
- **新增测试 30 用例**：WxPaySignerTest 3 / WxPayClientTest 3 / OrderStoreTest 6 / MovmcpPackagerTest 6 / MovmcpInstallerTest 5 / A2aClientMultiIdentityTest 3 / MarketEngineLogicTest 4
- **变异亲杀三项**（改→红→还原绿，逐项记录）：
  1. 查单恒返 SUCCESS → `未付款不发货` 红（4 tests, 1 failed）→ 还原绿
  2. 解密恒空 → config/package/即焚 三用例红（5 tests, 3 failed）→ 还原绿
  3. 签名恒真 → 篡改 payload/manifest/异卖家/验签拒装 四用例红（11 tests, 4 failed）→ 还原绿

## 三、红线核对

- [x] 私钥零落仓（grep `BEGIN PRIVATE KEY` 主代码/测试零命中；卖家 RSA 私钥 pem 只生成在仓库外 Desktop，待用户真机粘贴入 vault）
- [x] 微信 API 签名只在 Java 侧（WxPaySigner），JS 永不见私钥
- [x] 网络 IO 全 cbId 异步（BridgeMarket 4 方法），BridgeKernel 未加同步 case
- [x] 统一错误信封 + 桥方法 try-catch 不抛 JS
- [x] 订单/安装/回执全进 journal（append-only，固定房间 `mkt`），JS 不直改 Java 状态
- [x] K 即焚（Installer finally 清零 + 卖家发完清零）、K 只发付款 buyerId、encPkg 可传 K 不可
- [x] 只调 Native 下单 + 查单两 API；无资金池/代收/分账
- [x] 安装前计划闸（DialogConfirm AlertDialog + CountDownLatch，60s 超时=取消）
- [x] JS createElement/textContent（收款卡/状态行无 innerHTML 拼用户输入）
- [x] 单测零网络（HttpTransport fake / TokenStore fake / Prefs fake / 临时目录 Journal）

## 四、遗留 / 待真机

1. **0.01 元真单八段证据链**（工单 §四）待用户配合：卖家私钥粘贴（Desktop/mov-seller-rsa-priv.pem → 商户收款页「卖家发货签名」）→ 双身份注册 → 购买 → 微信支付 → 发货 → 安装 → 已安装列表 → 工具实调 → journal 五态 + 商户后台截图
2. **package 型工具注册**：脚本落盘 + chmod + `ToolRegistryHook` 接口已留（`MarketEngine.setToolHook`），AgentLoop 装配处注入待接（验收走 config 型不受影响）
3. OrderStore 重放依赖 journal tail 500（≈70 单），mkt 房间滚动（1MB）后的 snapshot 重建未实现——验收场景不触发，留欠账
4. 支付闸锁屏确认要求设备已设锁屏（`isKeyguardSecure`），无锁屏设备购买会拒（诚实降级，符合 PaymentGate 既有语义）

## 五、关键设计决策（审查点）

1. **卖家侧 Shelf 为交易数据源**：JS 货架仅展示；下单/打包只认 Java `Shelf`（防买家伪造商品 payload）
2. **卖家 RSA 密钥对**：施工时生成，公钥常量三处一致（Shelf / JS GOODS / manifest.sellerPubKey）；私钥经「商户收款」表单入 vault（`sellerVaultId`），未配置 → 发货拒 + MANUAL 留痕
3. **单进程双角色**：同机 `mov-seller`/`mov-buyer-test` 两个 A2aClient 实例（TokenStore 前缀 key 隔离），共享同一 OrderStore/Journal（mkt 房间），买卖双方事件同源可回看
4. **`replay()` 信封实测**：`journal.replay()` 返回 `{ok, data:{events}}` 而非裸 events（8-09 实测修正，OrderStore.rebuild 已适配）
5. **K 清零顺序**：A2A 报文在 `post()` 同步构造后清零，避免编出全零 K（施工中自抓自修）

## 六、验收打回修复（2026-08-09 第二轮，E-1/E-2/E-3）

> 验收结论：打回一处必修（E-1）+ 建议同 commit（E-2/E-3）。修完免全面复审。

- **E-1（P0）退后台查单轮询永不恢复** → `MarketEngine.onResume()` 增加 `resumePolling()`：遍历 `orders.paying()` 逐单立即 `pollOnce` 补查并重挂 5s 循环（后台支付→回前台→自动发货闭环）。`OrderStore` 新增 `all()/paying()`。变异亲杀：paying 不过滤 → `paying筛选仅PAYING态` 红（7 tests 1 failed）→ 还原绿
- **E-2（P1）后台回调重挂轮询** → `foreground` volatile 标志位：`onPause` 置 false 后 OkHttp 回调不再 `postDelayed`（`reschedule()` 仅前台重挂），`onResume` 统一重挂
- **E-3（P1）K 即焚早退缺口** → `MovmcpInstaller.install` 的 `Arrays.fill(K,0)` 提到外层 try-finally，验签败/manifest 坏/用户取消/解密败/安装败/异常全路径覆盖（原内层 finally 删除，外层统一）
- 新增测试：`OrderStoreTest.paying筛选仅PAYING态_E1重挂用`、`MovmcpInstallerTest.E3早退路径K也清零`（验签败+用户取消两路径断言 K 全零）
- 全量：debug+release 各 **1211 tests, 0 failures**

1. **卖家侧 Shelf 为交易数据源**：JS 货架仅展示；下单/打包只认 Java `Shelf`（防买家伪造商品 payload）
2. **卖家 RSA 密钥对**：施工时生成，公钥常量三处一致（Shelf / JS GOODS / manifest.sellerPubKey）；私钥经「商户收款」表单入 vault（`sellerVaultId`），未配置 → 发货拒 + MANUAL 留痕
3. **单进程双角色**：同机 `mov-seller`/`mov-buyer-test` 两个 A2aClient 实例（TokenStore 前缀 key 隔离），共享同一 OrderStore/Journal（mkt 房间），买卖双方事件同源可回看
4. **`replay()` 信封实测**：`journal.replay()` 返回 `{ok, data:{events}}` 而非裸 events（8-09 实测修正，OrderStore.rebuild 已适配）
5. **K 清零顺序**：A2A 报文在 `post()` 同步构造后清零，避免编出全零 K（施工中自抓自修）
