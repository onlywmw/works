# 审查裁决登记 — 2026-08-01

> 审查员裁决三个未决问题，用户拍板「按照建议走」。本档为登记，后续施工状态在此回写。

## 裁决一：意图层正朔

**结论**：云端 LLM 丘脑为正朔（已上线：`IntentEngine` + `BridgeAi.intentClassifyAsync`）。
- 端侧小模型降级 **v2 可选项**（省 token / 离线场景）——已有意图路由开关提供「仅快速通道（正则，省 token）」路径，v2 端侧小模型同槽位，不替换正朔
- **drama 专用推理归并进统一意图**：`renderDramaOptions` 的续播推理复用 `intent=drama` 路由，不另起独立分类器

**施工**：✅ 已完成（F2/F4 意图层 + 路由开关，`18f513c`/`1715a0f`/`2427c7e`）

## 裁决二：连接区归属

**结论**：按 SETTINGS 施工（连接区从「我的」抽屉并入设置页折叠树）。**WEB_ADAPTER「泛化保留」撤销**，不按它回滚。
- `renderConnectSection` 唯一归属 = 设置页「连接」区块

**施工**：✅ 已完成（`5832f38`）

## 裁决三：browser_* 收编 + startFlow 残留

**结论**：browser_* 分级收编进统一注册表（读=FAST READONLY / 写=FAST ACTION 过审批闸 / 支付域=DANGEROUS 生物识别），见 `DESIGN_PAYMENT_GATE.md` §三。
**施工**：browser_* 收编任务 D4。

### startFlow 演示流残留清单

| 位置 | 演示流 | 现状 | 死刑条件 |
|---|---|---|---|
| `newface.js startFlow` | flight（机票）/ shop | 纯静态演示（FLOWS 数据） | 真链路（browser_* 收编）就绪后移除 |
| `newface.js startFlow` | drama | 已接真数据（renderDramaOptions） | 保留（真链路） |
| FLOWS 静态数据 | 演示选项 | 待移除 | 同 flight/shop |

**死刑日期**：**2026-08-15**（browser_* 真链路就绪即提前执行；到日未就绪则保留并在下一轮裁决复核）。
> 历史教训：未识别曾默认演机票——startFlow 是「诚实卡兜底」的残留，真链路到位前不得扩大使用。

## 回写状态

| 项 | 状态 |
|---|---|
| 意图层裁决 | ✅ 已声明（本文档） |
| 连接区裁决 | ✅ 已施工（`5832f38`） |
| browser_* 收编 | 🔨 D4 进行中 |
| startFlow 死刑 | ⏳ 2026-08-15 |
