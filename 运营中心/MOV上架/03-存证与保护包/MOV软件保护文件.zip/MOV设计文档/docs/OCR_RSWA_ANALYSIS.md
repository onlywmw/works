# 《R-SWA 机制确认书》— Unlimited-OCR 移动端移植 P0a

> 状态：✅ P0a 完成（源码侦察 + 机制确认 + CPU 基线计划）
> 日期：2026-08-01
> 依据文档：docs/DESIGN_OCR_MOBILE.md（P0 阶段 + 第六章 6.7 节）
> 源码来源：ModelScope 镜像 `PaddlePaddle/Unlimited-OCR`（HF 网络不可达，见 §8），与 HF `baidu/Unlimited-OCR` 同源

---

## 1. 结论（一句话）

**R-SWA = 「参考前缀常驻 + 生成 token 滑动窗口」的 KV Cache 淘汰/掩码策略，不是新的注意力数学算子。**

P0 阶段的关键假说**证实成立**，M3 里程碑不触发降级方案，P3「R-SWA 缓存策略实现」**保留**。移植时**注意力算子（MHA scaled-dot-product）无需修改**，改动落在 KV Cache 管理层（参考块常驻 + W=128 环缓冲）。

---

## 2. 判定依据（三层证据，互相独立）

### 2.1 官方命名与论文定义

- vLLM 官方 recipe（recipes.vllm.ai/baidu/Unlimited-OCR）明确命名：**Reference Sliding Window Attention (R-SWA)**
- 论文（arXiv 2606.23050）摘要原文：
  > "we replace all attention layers in the decoder with our proposed Reference Sliding Window Attention (R-SWA), which **reduces attention computation costs while maintaining a constant KV cache** throughout the entire decoding process."

论文把 R-SWA 称作「维持恒定 KV Cache 的注意力机制」，强调的是**注意力计算代价的降低**，落点是 KV Cache——语义上即缓存调度策略。

### 2.2 transformers 参考实现（HF/ModelScope `trust_remote_code` modeling 源码）

`modeling_deepseekv2.py` 定义了 `SlidingWindowLlamaAttention`（继承 `LlamaAttention`），docstring 自述：*"LlamaAttention with sliding window KV cache using a ring buffer during decode."*

其 forward 全程使用**标准 MHA**：
```
query_states = q_proj(hidden); key_states = k_proj(hidden); value_states = v_proj(hidden)
cos,sin = rotary_emb(...);  Q,K 应用 RoPE
attn_weights = matmul(Q, K.transpose) / sqrt(head_dim)   ← 标准 scaled-dot-product
attn_weights = softmax(attn_weights, float32)
attn_output = matmul(attn_weights, V); o_proj(...)
```
**没有任何新的矩阵乘法/融合 kernel/自定义算子**。滑动窗口全部体现在 KV Cache 槽位管理：
- 固定区域（prefill 参考 token）永不淘汰
- 生成 token 用 **ring buffer 原地覆写**（`kcache[:, :, prefill_len + ring_pos, :] = new_k`，`ring_pos = (ring_pos+1) % W`）
- decode 步对「固定参考 + 环内最近 W 个 token」做一次标准注意力，无需 causal mask（q_len=1）

### 2.3 vLLM 官方参考实现（`vllm/model_executor/models/unlimited_ocr.py`）

vLLM 源码 docstring 对 R-SWA 的复现描述（原文）：
> "the prompt/image tokens form a globally-visible prefix while the *generated* tokens additionally attend only a fixed sliding window (128) of recent tokens. We reproduce this with **backend-specific custom masks**: FA4 uses a `mask_mod`, FlexAttention uses a Triton block mask, and TritonAttention uses a unified-attention decode mask."

vLLM 在三个后端（FA4/FlexAttention/Triton）上全部用**注意力 mask**复现 R-SWA，无任何新算子。vLLM 选 mask 路线是因为其 PagedAttention 统一管理 KV；transformers 参考实现选 ring buffer 路线。**两条路线共用同一语义，都证明机制本质是「掩码/缓存调度」，不是新数学**。

> 注：vLLM 保留全部 KV + mask 会失去「恒定 KV」的内存优势；**MNN 移植应走 transformers 的 ring-buffer 路线**（内存最优，见 §7）。

---

## 3. R-SWA 精确机制（按 transformers 参考实现逐行核实）

### 3.1 阶段划分（SlidingWindowLlamaAttention.forward）

| 阶段 | 触发条件 | 行为 |
|---|---|---|
| **Prefill（全量）** | `q_len > 1` 且该层首次 | 全量因果注意力，KV 全存；记录 `_prefill_length[layer]` = prefill 后 cache 长度 |
| **Warmup（追加）** | `cur_len < prefill_len + W` | 标准 cat-append，带 causal mask；直至 `cur_len == prefill_len + W` |
| **Steady state（环覆写）** | `cur_len == prefill_len + W` | 新 token 的 KV 覆写环槽 `prefill_len + ring_pos`，`ring_pos=(ring_pos+1)%W`；对全 cache 做标准注意力（无 mask，q_len=1） |

### 3.2 关键语义

- **参考 token = prefill 全部 token**：多页输入时 = prompt + 所有页的 image token（如 40 页 ≈ 10920+）。它们**永不淘汰**。
- **生成 token**：只保留最近 `W = config.sliding_window = 128` 个，环缓冲循环覆写。
- **KV 总量恒定**：`prefill_len + W`，**不随输出长度增长**（满足 DESIGN_OCR_MOBILE.md P3 验收「KV Cache 占用不随输出长度增长」）。
- **RoPE 绝对位置**：`position_ids` 由 attention_mask `cumsum` 得出绝对索引，**不因环截断复位**。查询/键按各自真实绝对位置施加 RoPE 后做点积。
- **启用方式**：infer/infer_multi 在 generate 前把 `config.sliding_window`（=128）拷入 `config._ring_window` 供注意力读取，同时 `config.sliding_window = None` 关闭 DynamicCache 原生截断（原生截断会误删参考前缀）。generate 后恢复。
- **R-SWA 应用于全部 12 层**：`use_mla=False` → `attn_implementation="mha_eager"` → 所有层都走 `SlidingWindowLlamaAttention`（`first_k_dense_replace=1` 只影响 FFN 稠密性，不影响注意力）。

### 3.3 与原生 sliding-window 的关键区别（移植必须遵守）

transformers 原生 `config.sliding_window`（DynamicCache 截断）会**连早期 prompt 一起淘汰**；R-SWA 的独特之处是**保留参考前缀、只窗口化生成段**。因此：
- ❌ 错误做法：MNN 直接配 `sliding_window=128` 不保留前缀 → 输出与黄金样本不符
- ✅ 正确做法：KV Cache 分「参考区（只增不删）+ 环区（W 槽覆写）」

---

## 4. 真实计算图（config + 源码核对）

### 4.1 语言解码器（DeepSeek-V2 MoE，`language_config`）

| 项 | 值 |
|---|---|
| 层数 | 12（第 1 层 dense FFN，后 11 层 MoE） |
| hidden_size | 1280 |
| attention heads / KV heads | 10 / 10（**MLA 关闭，标准 MHA**，`use_mla=false`，head_dim=128） |
| 注意力类型 | R-SWA（全部 12 层），窗口 W=128 |
| MoE | 64 routed + 2 shared experts，top-k=6，`topk_method=greedy`，`moe_intermediate_size=896` |
| dense FFN intermediate | 6848 |
| vocab_size / max_pos | 129280 / 32768 |
| dtype | bf16 |

### 4.2 视觉编码器（DeepEncoder，`vision_config`）

| 项 | 值 |
|---|---|
| SAM-ViT-B | width 768，12 层，12 heads，global_attn_indexes=[2,5,8,11]，输入 1024×1024 |
| CLIP-L | width 1024，24 层，16 heads，patch 14，输入 224 |
| 投影 | linear projector 2048→1280（`projector_type="linear"`） |
| 可学习参数 | `image_newline`（行分隔）+ `view_seperator`（页分隔） |
| 视觉 token 数 | **base 模式每页 273**（16×16=256 网格 + 16 行分隔 + 1 页分隔）——设计文档里的「256」是网格数，漏了分隔符，移植以 273 为准 |

> ⚠️ 修正：DESIGN_OCR_MOBILE.md 第 27 行「视觉 token 数 256」应更正为 **273/page（base 模式）**。单图 gundam 模式为 global view 273 + 每 crop ≈111。

### 4.3 视觉编码集成（UnlimitedOCRModel.forward）

```
SAM(image) → f1；CLIP(image, f1) → f2
features = cat(f2[:,1:], f1.flatten(2).permute(0,2,1), dim=-1)   # 去 CLS，拼接 SAM 空间特征
features = projector(features)                                    # → 1280
global = view(h,w) + image_newline 展开                          # 行分隔
多图/多页时 + view_seperator 分隔
inputs_embeds[mask].masked_scatter_(image 位置, features)          # 填入 image token 位
```
视觉编码器**不使用 R-SWA**（单次全注意力 prefill，vLLM 源码亦确认「the vision encoder ... does not use R-SWA」）。

### 4.4 防重机制（P4 必须同步移植，官方点名）

`SlidingWindowNoRepeatNgramProcessor`（modeling_unlimitedocr.py:354）+ vLLM `NGramPerReqLogitsProcessor`：
- `no_repeat_ngram_size=35`，窗口 `window=128`（单页）/ `1024`（多页）
- 逐 token：扫描最近 window 内 n-gram，前缀匹配则 ban 该候选 token（score=-inf）
- **纯 logits 后处理，与注意力无关**，移植为 sampling 层的 logits processor 即可
- vLLM recipe 明确：*"without it long documents loop on <\|det\|> coordinate tokens"* ——漏掉会循环输出

---

## 5. 判定结论对里程碑的影响

| 里程碑 | 影响 |
|---|---|
| M1（P0 完） | ✅ 不触发。R-SWA = 缓存策略已证实 |
| M2（P2 全注意力版） | ✅ 不受影响。全注意力版 = prefill 全量 + decode 全量（W 设为无穷/关闭环），骨架与官方 base 模式等价 |
| M3（P3 R-SWA） | ✅ **保留**。无需降级为逐页拼接方案 |
| M4（P5 集成） | 不变 |

---

## 6. 黄金样本与输出 schema 约束（对接 DESIGN_OCR_MOBILE.md 6.7）

### 6.1 输出 schema 必须服务「本地看、云端想」成本协同

按 6.7 节验收（P5），OCR 输出 schema 需满足：
- **分段**：输出按语义块分段（标题/正文/表格/公式），每段可独立检索
- **页锚点**：保留 `<PAGE>` 分页标记，段与页号可互相定位
- **结构化 Markdown**：标题层级/表格/公式结构保留，供慢脑分块摘要
- 目标：慢脑按段检索 → **只把相关段落发云端**（token 降一个量级）；同一份文档只 OCR 一次

原生 `infer_multi` 已产出 `<PAGE>` 分隔文本 + `<|ref|>/<|det|>` 版面标记（`re_match` 可剥离），天然有页锚点。P5 需在其上补**段级锚点**与**结构化标记**，并在 P0 黄金样本阶段就把 schema 字段固定下来（黄金样本一旦定下不许更换）。

### 6.2 黄金样本候选（P0b 定稿后锁死）

3 张测试图（从公开基准/自摄中选取，定稿后换图即打回）：
1. 中文打印体文档页（含标题/正文/列表）—— 验证基础转录
2. 含表格 + 数学公式的论文页 —— 验证结构化输出
3. 票据/证件类（带版面坐标标记）—— 验证 det/ref 分支

---

## 7. 对 MNN 移植的实施方案（P3 输入）

**结论：注意力算子复用 MNN 标准 MHA，R-SWA 在 KV Cache 管理层实现。**

MNN 侧实现（对照 transformers ring-buffer 路线）：
1. **参考区**：prefill 的 KV 按层存固定块，只增不删（多页 = 全页 image token prefill 一次性完成）
2. **环区**：每层一个 W=128 的环形 KV 缓冲，decode 时新 KV 覆写最旧槽
3. **decode 注意力**：query 对「参考区 + 环区」拼接的 KV 做标准注意力，RoPE 用绝对位置
4. KV 总容量预分配 = `max_prefill_len + W`，运行时逐层 `_prefill_length` 记录实际 prefill 长

MNN 侧需确认的能力（P1/P3 立项时核对）：KV Cache 自定义槽位读写、每层独立 prefill 长度、绝对位置 RoPE。

---

## 8. 源码来源与校验（provenance）

### 8.1 网络环境实测（2026-08-01）

| 源 | 状态 |
|---|---|
| huggingface.co API / git / raw | ❌ 全部超时/连不上（api、git ls-remote、resolve 均不通） |
| github.com（api + raw） | ✅ 通（官方 README/infer.py 已拉取） |
| recipes.vllm.ai | ✅ 通（recipe 已拉取） |
| modelscope.cn | ✅ 通（镜像仓库 `PaddlePaddle/Unlimited-OCR` 与 HF 同源） |
| export.arxiv.org | ✅ 通（论文摘要已拉取） |

**下载脚本必须走 modelscope 镜像**，HF 权重直连在本机不可用。

### 8.2 源码快照 SHA256（已归档 `.ocr_p0/src/`，来源可信）

| 文件 | SHA256 |
|---|---|
| modeling_unlimitedocr.py | `268bdcbe12cf37bf5a2debb53faf542e56570958a5d9f3314aab3cab2cf6cb48` |
| modeling_deepseekv2.py | `74e36e6bd0ba7bc565ef76464a99baa8e6bccb710ae9c1007b54ac30b855fa4c` |
| deepencoder.py | `0ae2fb6d1e5ae8cf100fc32f854830acd08c821a0a1f23a94a76588c222ddcf2` |
| configuration_deepseek_v2.py | `b8470dd616ba8745fce6e27b093aef73a098863cc891b2477dcf9326a36000f7` |
| conversation.py | `ec7b6ce89bcda643de1f43269ffa66a7b2e65dc3ed30e427958f776546b4ba03` |
| config.json | `27246d03fd670904ec9601b1cb0861fbb79ec076830771daa8d943d6229946f9` |
| processor_config.json | `92588cffb1d7032ec83d0a06c3a5171b41df5cbf432d68765441139a57899328` |
| tokenizer_config.json | `a0cbe8464049da1f891b7a12676de06af4cb54c130995d42f71adc1c30c6e9f3` |
| vllm_unlimited_ocr.py（参考） | `003474a5c441d2fcb0f55a887860a8622fffe320a4f950798a477bb7c77665a5` |

---

## 9. CPU 基线计划（P0b，黄金样本执行）

### 9.1 目标
proot Linux（小米平板内嵌 Ubuntu 24.04）跑通**单页 + 多页** OCR，产出正确性基准（黄金输出），记录耗时/内存。

### 9.2 环境
- proot Ubuntu 24.04 + Python 3.12
- `torch`/`torchvision` CPU 版、`transformers`（需 ≥4.57.1 或兼容版本）、`Pillow`、`einops`、`addict`、`easydict`、`pymupdf`
- 模型权重：modelscope 镜像下载（~6GB），**不进 git**；入库的是下载脚本 + SHA256
- 精度：bf16→fp16→int8 三档对照（CPU 上 bf16 可能无加速，fp16/int8 走量化评估）

### 9.3 执行脚本（proot 侧，入库 `ocr/scripts/`）
1. `download_model.sh`：modelscope 拉权重 → SHA256 校验 → 落 `filesDir/models/unlimited-ocr/`（版本目录）
2. `run_cpu_baseline.py`：3 张黄金测试图 → base 模式（`image_size=1024, crop_mode=False`）→ 输出文本 + 耗时 + 峰值内存（`/usr/bin/time -v` / psutil）

### 9.4 记录项（每张图）
| 项 | 值 |
|---|---|
| 单页耗时 | prefill 秒 + decode 秒（TPS 从 TPSTextStreamer 取） |
| 峰值内存 | RSS / 每层 KV 字节 |
| 输出全文 | 落盘存档为黄金样本 v1 |

### 9.5 产出
- `docs/OCR_GOLDEN_SAMPLES.md`：3 张图的黄金输出 v1（锁定，换图打回）
- 降精度对照表：bf16 vs fp16 vs int8 的逐字差异（评估 int4/int8 掉字风险，喂 P4 精度决策）

---

## 10. 遗留事项（P1/P3 立项时核对）

1. MNN `mnn-llm` 的 KV Cache 层是否开放「分参考区 + 环区」槽位自定义（设计文档声称开放，需 P1 实测）
2. RoPE 绝对位置在环截断下的正确实现（transformers 用绝对位置，MNN 需同语义）
3. 视觉编码器 SAM/CLIP 精确拼接维度（projector input 2048 = CLIP 1024 + SAM 1024？SAM neck 实际输出 256，需 P1 逐层核对——见 §4.2 备注）
4. gundam 裁剪模式（`crop_mode=True, image_size=640, base_size=1024`）列为 P1 后补，本轮只做 base

---

## 附：本次 P0a 已核实的官方文件清单

| 文件 | 说明 | 归档 |
|---|---|---|
| GitHub README.md + infer.py | 官方用法、SGLang 并发推理 | `.ocr_p0/` |
| modeling_unlimitedocr.py | trust_remote_code 主建模（R-SWA 调用方） | 已存 SHA256 |
| modeling_deepseekv2.py | SlidingWindowLlamaAttention 实现 | 已存 SHA256 |
| deepencoder.py | SAM-ViT-B + CLIP-L DeepEncoder | 已存 SHA256 |
| vllm_unlimited_ocr.py | vLLM 官方复现（mask 路线） | 已存 SHA256 |
| arXiv 2606.23050 摘要 | R-SWA 官方定义 | 已录 |
| vLLM recipe | 推理要求（ngram processor 等） | 已录 |
