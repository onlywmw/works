# MOV 分支规则（BRANCH RULES）v3 — 2026-08-09

> 用途：仓库多分支后的规矩——谁、什么改动、走哪个分支、怎么并回 main。
> 现状：仓库从「单 main 直推」演进到「main + 功能分支 + 验收分支」，本档补上边界。

---

## 一、分支地图

| 分支 | 用途 | 谁用 | 推送方式 |
|---|---|---|---|
| **main** | 默认/稳定分支：已验收的交付代码 + 任务板 + 验收记录（ACCEPTANCE_LOG.md） | P1/P2/P3 交付、验收人结论 | 直推（交付铁律：编译+测试过才推） |
| **feat/\<name\>** | 功能/对外接口分支：新能力隔离开发，不碰 main | 功能负责人 | 从 main 切出，`git push -u origin feat/xxx` |
| **remotes/new-mov** | 其它远端（旧镜像） | — | 只读参考 |

> 2026-08-05 起仓库回归「单 main + 按需 feat/」：历史功能/文档/验收分支（surpass / causal-memory / dual-brain-upgrade / mcp-external / fullscreen-html / 核心竞争力 / acceptance-data）已全部验收入 main 并删除；验收查验表与证据常态化落 main 的 `docs/`（ACCEPTANCE_LOG / ACCEPTANCE_TRACKER / device-acceptance）。

## 二、规则

### 1. main 是唯一稳定线
- 交付代码**必须** `assembleDebug test` 绿 + 编译过才能推 main（交付铁律）。
- 验收结论写 `docs/ACCEPTANCE_LOG.md`（在 main）+ 任务板更新；查验表/证据直接落 main 的 `docs/`（2026-08-05 起 acceptance-data 分支已退休）。

### 2. 功能/对外接口走 feat/ 分支
- **什么走分支**：新功能、对外接口（如 `feat/mcp-external`）、跨幕的大改动——不直接推 main，先隔离开发。
- **命名**：`feat/<语义名>`（如 `feat/mcp-external`）。
- **切出点**：一律从 `origin/main` 切（不要从旧分支切，防带入脏历史）。
- **迭代**：在分支上开发 → 全量测试绿 → 请验 → 验收人复核 → **合并回 main**（见规则 3）。

### 3. 合并回 main 的规矩
- 合并前：分支**无未验收遗留** + `assembleDebug test` 全量绿。
- 合并方式：`git checkout main && git merge --ff-only feat/xxx`（保持线性）或先 rebase 再 fast-forward。
- 合并后：删远端分支（`git push origin --delete feat/xxx`）保持仓库干净；如需保留对外，保留并注明。

### 4. 验收记录落 main
- 2026-08-05 起 acceptance-data 分支已并入 main 并删除；验收查验表/证据/结论统一落 main 的 `docs/`（ACCEPTANCE_LOG.md 为准）。

### 5. 纪律
- **不跨分支提交**：功能改动只在它的 feat/ 分支；main 的改动不进 feat/（要同步先 `git merge main` 或 rebase）。
- **报 hash 前自查**：`git fetch origin main && git merge-base --is-ancestor <hash> origin/main` 确认在 main。
- 打回修复：若功能在 feat/ 分支，修在分支上；若已并 main，修在 main 再推。

### 6. 防复发三规矩（2026-08-09 收尾计划阶段4 定稿）
- **换会话必留交接物**：任何「移交新会话」必须先写 `TASKS_*` 工单文档（模板 = `docs/TASKS_WXPAY_APPLYMENT_M1_2026-08-09.md`），在 TASKBOARD 登记，否则不许停手。
- **分支不过夜**：验收通过后 **48h 内** `merge --ff-only` 合 main；超前 5 commit 未合的分支亮红灯。
- **验收不过周**：🔨 待验收项挂 **7 天** 无人验 → 自动升级给用户本人裁决（验 / 降级 / 砍）。

## 三、当前分支

- 仅 **main**（2026-08-05 全分支融合后）。MCP P2 扩展（全量工具+审批闸）等新工作从 origin/main 重新切 feat/ 分支。

## 变更日志

- 2026-08-03 v1：建档（配合 feat/mcp-external 分支落地）
- 2026-08-05 v2：全分支融合后更新——acceptance-data 退休，验收记录落 main；当前仅 main
- 2026-08-09 v3：加「防复发三规矩」（换会话必留交接物 / 分支不过夜 / 验收不过周），源于收尾计划阶段4
