# Phase 3B 支付闸 + workflows 引擎 理解笔记

> 2026-07-30，读完两份材料后撰写。不动手写实现代码，等 Phase 3 发令枪。

---

## 1. 支付闸怎么落进浏览器协议

### 1.1 现状：§7 安全闸已预留 `domain_policies`

DESIGN_BROWSER_PROTOCOL.md §7 列了五道闸，支付闸是第三道：

| 闸 | 规则 | 状态 |
|---|---|---|
| scheme 白名单 | 仅 http/https，WebViewClient 拦跳转，两处缺一不可 | v1 骨架 |
| 审批分层 | 写工具逐次确认 / 会话级 / 持久白名单 / eval_js NO_ALWAYS_ALLOW | v1 骨架 |
| **支付闸** | 金额/订单页面动作进 BiometricPrompt，`domain_policies` 预留 | **Phase 3B** |
| 敏感嗅探 | URL query 里 JWT/卡号形状 → envelope warning | v1 |
| cookie 边界 | 浏览器带用户会话，改状态必过闸 | v1 |

`domain_policies` 是 MOV 在浏览器协议里专门留的扩展点。当前是预留字段（还没落地），Phase 3B 把它填实。

### 1.2 支付闸的三个落地位置

支付闸不是一个独立模块，而是嵌在浏览器工具执行链的三个关卡里：

```
browser_click("结算按钮")
  │
  ├─ 关卡 1: domain_policies 匹配
  │   当前 URL host 命中支付域白名单？
  │   命中 → 标记此 write 操作为 "payment_sensitive"
  │
  ├─ 关卡 2: 审批闸升级
  │   普通 write: 会话级"本次允许"可覆盖
  │   payment_sensitive write: 强制 BiometricPrompt（指纹/面部）
  │   不可降级、不可"本次允许"、不可持久白名单
  │
  └─ 关卡 3: 敏感嗅探增强
      支付页面 URL 参数里的金额/订单号 → envelope 附加 payment_context
      金额/订单号做数据掩码（¥1***），靠数据最小化不靠模型自觉
```

### 1.3 `domain_policies` 字段设计推演

```json
// 浏览器协议 v1 已预留的扩展位
{
  "domain_policies": {
    "payment_domains": [
      "*.alipay.com",
      "*.paypal.com",
      "pay.weixin.qq.com",
      "tenpay.com"
    ],
    "payment_path_patterns": [
      "/cashier/*",
      "/checkout/*"
    ],
    "biometric_required": true,
    "amount_threshold_cents": 0   // 语义锁死: 0=任何金额都闸, 不可调大; 考虑直接删掉此字段减少攻击面
  }
}
```

这个字段存在但为空时 = 不启用支付闸。Phase 3B 的工作就是：
1. 设计 `domain_policies` 的完整 schema（上面是草稿方向）
2. 在 ConnectWebActivity 的 WebViewClient 链路里加入 domain 匹配逻辑
3. 匹配命中后，所有 write 工具（click/type/submit）的审批闸升级为 BiometricPrompt
4. `browser_eval_js` 的 HARDLINE 正则地板额外加入支付相关阻拦（`document.cookie` / `payment` / `checkout`）

### 1.4 与 rikkahub-agent 审批模型的对齐

rikkahub-agent 的三级审批豁免（会话/持久/YOLO）在 MOV 里被支付铁律约束收紧了一层：

| rikkahub 原版 | MOV 支付闸改写 |
|---|---|
| 写工具 ALWAYS_ASK，可降级到会话级"本次允许" | 支付域写工具永远不可降级 |
| eval_js NO_ALWAYS_ALLOW + HARDLINE 正则 | 同上，外加支付关键字阻拦 |
| 无支付域概念 | `domain_policies` 精确控制哪些 URL 触发升级 |

核心差异：rikkahub 的审批模型是"工具维度"的（按 tool name 分级），MOV 支付闸要求"工具 × 域"交叉维度——同一个 `browser_click` 在支付域和非支付域有不同的审批强度。

---

## 2. 触发器引擎：riksahub-agent workflow/ 精读

### 2.1 整体架构

```
TriggerRegistry（编排中枢）
  │
  ├─ observeAll() → Flow<List<WorkflowDefinition>>
  │   订阅 Room 数据库，每次变更重新 emit
  │   500ms debounce（防编辑器批量改触发 → 注册/注销风暴）
  │
  ├─ resync(enabled)
  │   按 trigger family 分桶 → 每个 family.sync(matching, callback)
  │   零启用 = 零 receiver（电池卫生）
  │
  └─ 12 个 WorkflowTriggerFamily
       ├─ TimeCronTriggerFamily       → WorkManager（Periodic + One-shot 链）
       ├─ WifiTriggerFamily           → BroadcastReceiver (NETWORK_STATE_CHANGED_ACTION)
       ├─ BluetoothTriggerFamily      → BroadcastReceiver (ACL_CONNECTED/DISCONNECTED)
       ├─ HeadphoneTriggerFamily      → BroadcastReceiver (ACTION_HEADSET_PLUG)
       ├─ PowerTriggerFamily          → BroadcastReceiver (ACTION_POWER_CONNECTED/DISCONNECTED)
       ├─ ScreenTriggerFamily         → BroadcastReceiver (ACTION_SCREEN_ON/OFF) [仅运行时注册]
       ├─ BatteryTriggerFamily        → BroadcastReceiver + 阈值过渡追踪
       ├─ GeofenceTriggerFamily       → Play Services GeofenceClient
       ├─ AppForegroundTriggerFamily  → AccessibilityService (TYPE_WINDOW_STATE_CHANGED)
       ├─ NotificationTriggerFamily   → NotificationListenerService
       ├─ BootTriggerFamily           → BroadcastReceiver (BOOT_COMPLETED)
       └─ ManualTriggerFamily         → 空壳（仅 workflow_run 工具 / "Run now" 按钮）
```

### 2.2 19 个触发器清单（与 DESIGN_BROWSER_PROTOCOL 附录一致）

| # | 触发器类型 | 参数 | 底层机制 |
|---|---|---|---|
| 1 | `time_cron` | cron / timeOfDay + daysOfWeek + timezone | WorkManager |
| 2 | `wifi_connected` | ssid? | BroadcastReceiver |
| 3 | `wifi_disconnected` | ssid? | BroadcastReceiver |
| 4 | `bluetooth_device_connected` | deviceAddress? | BroadcastReceiver |
| 5 | `bluetooth_device_disconnected` | deviceAddress? | BroadcastReceiver |
| 6 | `headphones_plugged` | — | BroadcastReceiver |
| 7 | `headphones_unplugged` | — | BroadcastReceiver |
| 8 | `power_connected` | — | BroadcastReceiver |
| 9 | `power_disconnected` | — | BroadcastReceiver |
| 10 | `battery_below` | thresholdPercent | BroadcastReceiver + 过渡追踪 |
| 11 | `battery_above` | thresholdPercent | BroadcastReceiver + 过渡追踪 |
| 12 | `geofence_enter` | lat, lng, radiusM, label? | Play Services Geofence |
| 13 | `geofence_exit` | lat, lng, radiusM, label? | Play Services Geofence |
| 14 | `app_launched` | packageName | AccessibilityService |
| 15 | `app_closed` | packageName | AccessibilityService |
| 16 | `notification_received` | packageName?, title/text contains/matches | NotificationListener |
| 17 | `boot_completed` | — | BroadcastReceiver |
| 18 | `screen_on` | — | BroadcastReceiver（运行时） |
| 19 | `screen_off` | — | BroadcastReceiver（运行时） |
| — | `manual` | — | workflow_run 工具 / Run now 按钮 |

### 2.3 注册/注销机制（按需注册 receiver）

核心原则：**零启用 workflow = 零 receiver**。这是电池卫生的铁律。

```kotlin
// TriggerRegistry.start() 的核心流程
workflowRepository.observeAll()                // Room Flow
  .map { loaded -> loaded.filter { it.entity.enabled }.map { it.definition } }
  .distinctUntilChanged()
  .debounce(RESYNC_DEBOUNCE_MS)               // 500ms 静默窗口
  .onEach { resync(it) }
  .collect { /* drained */ }

// resync: 按 family 分桶
suspend fun resync(enabled: List<WorkflowDefinition>) {
  for (family in families) {
    val matching = enabled.filter { family.handles(it.trigger) }
    family.sync(matching, fireCallback)
    // family 内部 diff 上次状态，决定 register/unregister
  }
}
```

每个 family 的 `sync()` 内部逻辑：
- 上次空、本次有 → register receiver
- 上次有、本次空 → unregister receiver
- 上次有、本次有但 trigger 变了 → unregister + register（re-reconcile）
- 上次有、本次有且没变 → no-op

**debounce 的必要性**：用户在 workflow 编辑器里快速 toggle 10 个开关，如果不 debounce，每次 toggle 都会触发一次完整的 12-family resync。500ms 静默窗口让这批编辑 coalesce 成单次 resync。代价是首次启用零→有 family 的 receiver 会延迟最多 500ms 才生效——对于 OS 级广播延迟来说感知不到。

### 2.4 Room 单表 canonical JSON

```sql
CREATE TABLE workflows (
  id TEXT PRIMARY KEY,
  name TEXT,
  description TEXT,
  enabled INTEGER DEFAULT 1,
  definitionJson TEXT,        -- ★ 真理源：完整的 WorkflowDefinition 序列化 JSON
  createdAtMs INTEGER,
  updatedAtMs INTEGER,
  lastRunAtMs INTEGER,        -- 投射列：UI 排序/筛选用，不要求解析 JSON
  lastRunStatus TEXT,         -- 投射列
  lastRunError TEXT,          -- 投射列
  runsTodayCount INTEGER,     -- 投射列：日配额计数
  runsTodayDate TEXT           -- 投射列：日配额日期 "yyyy-MM-dd"
);
```

两个关键设计决策：

1. **JSON 是真理源，投射列只是缓存**。`definitionJson` 包含 trigger + conditions + actions + cooldown + maxRunsPerDay 的全部字段。`name`/`enabled`/`lastRun*` 等投射列只在 UI 排序和快速筛选时用，不作为权威数据。这意味着新增字段不需要 Entity migration，只要 JSON 解析器能处理默认值即可。

2. **写入只改 JSON，不碰投射列**。`recordFire` 更新 `lastRunAtMs`/`runsTodayCount` 等投射列时不增加 `updatedAtMs`——这样 JSON parse cache（以 `(id, updatedAtMs)` 为 key）不会因为高频的 fire 记录而失效。这是一个精妙的热路径优化。

### 2.5 引擎执行链路

```
fire(workflowId)
  │
  ├─ 1. per-workflow Mutex（防止 WiFi 抖动导致并发 fire）
  │
  ├─ 2. 加载 workflow + 确认 enabled
  │
  ├─ 3. triggerRuntimeCheck
  │     geofence → 检查 FINE_LOCATION + BACKGROUND_LOCATION
  │     notification → 检查 NotificationListener 绑定
  │     app_launched/closed → 检查 AccessibilityService
  │     bluetooth → 检查 BLUETOOTH_CONNECT（Android 12+）
  │     失败 → 记录 FAILED（用户看到"为什么没触发"的原因）
  │
  ├─ 4. cooldown gate
  │     用 lastActualFireAtMs（历史表里最近 SUCCESS/FAILED），不用 lastRunAtMs 投射列
  │     （投射列在每次 SKIP 时也更新，用它做 cooldown 锚点会把 cooldown 窗口无限推远）
  │
  ├─ 5. daily-cap gate
  │     runsTodayCount vs maxRunsPerDay，按设备本地日期 "yyyy-MM-dd" rollover
  │
  ├─ 6. 条件评估
  │     ContextProvider.snapshot(lazy on location for sunset/sunrise)
  │     → ConditionEvaluator.evaluateAll (AND-combined, invert per-condition)
  │
  ├─ 7. 解析 assistant + tool surface
  │     优先 authoringAssistantId（确定性）
  │     找不到 → 第一个带 Workflows toggle 的 assistant（fallback + Log.w）
  │
  ├─ 8. 执行 action sequence
  │     WorkflowActionRunner: 逐 action → HARDLINE check → Tool.execute
  │     → per-action timeout
  │
  └─ 9. 持久化
        recordFire（run 历史行 + 更新投射列）
        → trim history (≤100 行/workflow)
        → AgentRun ledger (Phase 24 跨 pillar 账本)
```

### 2.6 14 个条件类型

| # | 条件 | 逻辑 |
|---|---|---|
| 1 | `time_between` | start/end "HH:mm"，支持跨午夜 |
| 2 | `time_after_sunset` | offsetMinutes，缺 location 时 fail-open=true |
| 3 | `time_before_sunrise` | 同上 |
| 4 | `day_of_week_in` | days [1..7] ISO |
| 5 | `wifi_ssid_is` | 精确匹配 |
| 6 | `wifi_ssid_in` | 任意匹配 |
| 7 | `battery_above` | > percent |
| 8 | `battery_below` | < percent |
| 9 | `is_charging` | 插电中 |
| 10 | `is_not_charging` | 未插电 |
| 11 | `foreground_app_is` | 精确匹配 |
| 12 | `foreground_app_in` | 任意匹配 |
| 13 | `screen_is_on` | 亮屏 |
| 14 | `screen_is_off` | 灭屏 |

所有条件支持 `invert: true` 取反。AND 组合，无 OR 组（v1 设计简化）。

---

## 3. 触发器引擎和情境图谱为什么是一体两面

这是读材料后最重要的洞见。trigger engine 和 context graph 不是两个独立模块，它们是**同一个系统的两个正交投影**。

### 3.1 形式化理解

```
情境图谱 = 设备状态随时间变化的快照序列
触发器   = 在这个序列上注册的断点（状态转移边检测器）
条件     = 断点命中后，对当前快照的属性校验（AND 组合）
动作     = 断点 + 校验通过后执行的副作用
```

换句话说：

| 维度 | 触发器引擎视角 | 情境图谱视角 |
|---|---|---|
| **时间** | Trigger（状态转移检测） | 时间轴上的事件节点 |
| **空间** | 条件（WiFi/位置/App） | 设备周围环境的属性图 |
| **状态** | WorkflowContext 快照 | 图谱的当前节点 |
| **动作** | WorkflowAction 执行序列 | 图谱边上的副作用标注 |

```
                        trigger 检测到边
                             │
               ┌─────────────▼─────────────┐
               │    WorkflowContext 快照     │
               │  ┌───────────────────────┐ │
               │  │ battery: 85%          │ │←── 情境图谱的当前节点
               │  │ wifi: "HomeWiFi"      │ │
               │  │ screen: on            │ │
               │  │ foreground: com.x.y   │ │
               │  │ location: (lat, lng)  │ │
               │  └───────────────────────┘ │
               │     ↓ AND-evaluate        │
               │  conditions pass? → fire  │──→ 动作执行（图谱边上的副作用）
               └───────────────────────────┘
```

### 3.2 rikkahub-agent 代码里的具体证据

**证据 1：ContextProvider 是 trigger 和 condition 的共享基础设施**

```kotlin
// 同一个 ContextProvider 同时服务于：
// 1. trigger family 的 matchEvent（如 WifiTriggerFamily 需要 currentSsid）
// 2. ConditionEvaluator 的 evaluate（如 wifi_ssid_is 条件）
// 3. trigger runtime check（如 geofence 需要 location permission）
```

ContextProvider 就是情境图谱的"传感器读取层"。trigger 和 condition 都是这个传感器层的消费者——trigger 消费"发生了什么变化"，condition 消费"现在是什么状态"。

**证据 2：AppForegroundDispatcher 的双重身份**

```kotlin
// AppForegroundDispatcher 被两个消费者共享：
// 1. AppForegroundTriggerFamily — "什么时候前台 App 变了"
// 2. ForegroundAppIs / ForegroundAppIn 条件 — "现在前台 App 是什么"
// 
// TriggerRegistry.resync 里统计 foregroundConsumerCount：
// 如果没有任何 workflow 用到 app_launched/app_closed 触发器
// 也没有任何条件引用 foreground_app_is/foreground_app_in
// → AccessibilityService 可以做 volatile 短路，不写 TYPE_WINDOW_STATE_CHANGED
```

这意味着：**情境图谱的某些传感器只在有消费者时才激活**。trigger 和 condition 共享同一个传感器（AccessibilityService），只是读取方式不同——trigger 读的是"变化事件"，condition 读的是"当前值"。

**证据 3：battery 触发器的过渡追踪本质上是情境图谱的边检测**

```kotlin
// BatteryTriggerFamily 不是简单订阅 ACTION_BATTERY_CHANGED
// 而是追踪 lastLevel → currentLevel 的过渡：
//   - battery_below: lastLevel >= threshold → currentLevel < threshold
//   - battery_above: lastLevel < threshold → currentLevel >= threshold
//
// 这本质上是在情境图谱的 battery 维度上做状态转移检测：
//   state: ABOVE → state: BELOW 触发 battery_below
//   state: BELOW → state: ABOVE 触发 battery_above
```

### 3.3 对 MOV 架构的推导

在 MOV 体系里，这个一体两面意味着：

```
Phase 3A (浏览器协议) + Phase 3B (支付闸 + workflows)
  │
  ├─ 浏览器工具 = agent 操作 Web 的手段
  │   支付闸 = 操作里最高危的一类，需要 domain_policies + BiometricPrompt
  │
  ├─ workflows 引擎 = 触发器注册 + 条件评估 + 动作执行
  │   └─ 本质是在设备状态图上注册断点
  │
  └─ 情境图谱 (未来 Phase) = 设备状态的统一查询层
      └─ ContextProvider 的泛化：不仅服务于 workflow conditions
         还可以服务于 AgentLoop 的上下文注入、浏览器工具的预填
```

**关键推论**：在 MOV 实现 workflows 引擎时，不应该把 ContextProvider 埋在 workflow 模块里。它应该是**跨模块共享的情境传感器层**：

```java
// MOV 应该的模块关系：
// ContextProvider（设备情境传感器层）
//   ├─→ WorkflowEngine（触发器条件评估）
//   ├─→ PaymentGate（检查设备是否解锁/用户是否在场 → BiometricPrompt）
//   ├─→ AgentLoop（注入情境到系统提示：当前 WiFi/电量/位置）
//   └─→ BrowserTools（domain_policies 匹配时的支付上下文）
```

rikkahub-agent 的 ContextProvider 之所以能独立于 workflow 存在，就是因为它天然是一个**通用基础设施**——任何模块想知道"设备现在在什么状态"都应该来问它。workflow conditions 只是第一个消费者，不是唯一消费者。

---

## 4. 关键移植清单（MOV 落地时的参考点）

### 4.1 可直接复用的设计模式

| 模式 | rikkahub 实现 | MOV 移植建议 |
|---|---|---|
| 按需注册 receiver | TriggerRegistry.resync 分桶 + family.sync diff | 同样按需注册，但用 Java 实现，每 family 一个类 |
| debounce resync | Flow.debounce(500ms) | 用 Handler.postDelayed / RxJava debounce 等效 |
| JSON 真理源 + 投射列 | Room + WorkflowJson.encode/decode | MOV 已无 Room（只用文件），但同样思路：JSON 文件为真理源，内存缓存投射字段 |
| per-workflow Mutex | `ConcurrentHashMap<String, Mutex>` | `ConcurrentHashMap<String, ReentrantLock>` |
| cooldown 用历史表不用投射列 | `lastActualFireAtMs` query | 同样区分：历史记录做 cooldown，投射字段仅 UI |
| 条件 AND-combined + invert | `ConditionEvaluator.evaluateAll` | 直接移植，14 个条件类型逐个实现 |
| trigger runtime check | 权限/服务绑定状态检查 | 同样在 fire 前检查，失败记录 FAILED（用户可见） |

### 4.2 MOV 特有的改造点

| 改造 | 原因 |
|---|---|
| 文件存储替 Room | MOV 没有 Room 依赖，用 journal.jsonl 风格的文件存储 |
| `domain_policies` 交叉维度审批 | 支付闸 = tool × domain，不是纯 tool 级别 |
| BiometricPrompt 集成 | MOV 支付铁律要求生物特征确认 |
| AgentLoop 上下文注入 | 情境图谱不只服务 workflows，也要服务 agent 的 system prompt |
| 桥架构适配 | 触发器触发 → 事件经 BridgeKernel → JS 侧 journal 化 |

---

## 5. 理解校验：自问自答

**Q1: 为什么 cooldown 不能用投射列 lastRunAtMs？**

因为投射列在每次 fire 尝试（包括 SKIPPED_COOLDOWN / SKIPPED_CONDITIONS）时都会更新。如果用它，一个被 cooldown 跳过的 fire 会把自己的跳过时间当作下次 cooldown 的锚点，导致 cooldown 窗口无限滑移。正确做法是查历史 run 表里最近一次 SUCCESS/FAILED 的时间。

**Q2: 为什么 trigger runtime check 要记录 FAILED 而不是 silently skip？**

因为用户看不到"为什么 workflow 没触发"是最常见的支持问题。geofence 没授权位置、notification 没开通知监听——这些 setup 错误如果不显式记录，用户只会觉得"workflow 功能坏了"。

**Q3: 为什么电池触发需要 transition tracking？**

`battery_below: 20` 的意思是"电量从 ≥20% 降到 <20% 的那一刻"，不是"电量低于 20% 的每一秒"。如果不追踪 lastLevel → currentLevel 的过渡，每次 `ACTION_BATTERY_CHANGED` 广播（每 1% 变化一次）都会重新触发，1 分钟内可能 fire 10+ 次。过渡追踪保证只在穿越阈值线的瞬间 fire 一次。

**Q4: 支付闸和审批闸的分层关系？**

支付闸 = 审批闸的一个特化子集。审批闸的通用模型是"工具 + 会话状态 → 审批强度"；支付闸在这个模型上增加了"域"维度——`browser_click` 在 `*.alipay.com` 上的审批强度高于在 `*.example.com` 上。这个交叉维度是 rikkahub-agent 审批模型没有的（它只有纯工具维度），是 MOV 独有的支付铁律产物。

**Q5: 为什么说 trigger engine 和 context graph 一体两面？**

因为它们共享同一个 ContextProvider 传感器层，只是对它做了两种不同的投影——trigger 读"变化事件"（时间导数），context 读"当前状态"（瞬时值）。把它们分成两个模块会导致传感器重复注册/状态不一致/电池浪费。rikkahub-agent 的 `AppForegroundDispatcher` 已经展示了正确模式：一个数据源，两个消费者（trigger family + condition evaluator），按需激活。

---

## 6. 等 Phase 3 发令枪时的准备工作

1. **`domain_policies` schema 需要冻结**：支付域列表、路径匹配模式、BiometricPrompt 触发条件、金额阈值
2. **ContextProvider 应作为独立模块设计**：不耦合到 workflows 或 browser 任何一个子模块
3. **14 个条件的 Java 实现**：纯函数 port，加上 Android 特有的 Context 依赖（WiFi SSID、电池、屏幕状态）
4. **12 个 trigger family 按优先级落地**：time_cron 和 manual 先做（零外部依赖），geofence 和 notification 后做（需要 Play Services / NotificationListener）
5. **文件存储替代 Room**：MOV 无 Room，workflow 定义存 JSON 文件，run 历史存 append-only 行（每行一个 JSON 对象，与 journal.jsonl 风格一致）
6. **桥接设计**：workflow fire → AgentRun ledger → journal 事件 → MovRender 投影到运行 Tab

---

*笔记完。两份材料已熟读，等发令枪。*

---

## 验收批注（2026-07-30 验收人）

**结论：通过，P3 录用为 Phase 3B 候补（支付闸 + workflows 引擎）。**

### 质量判据（为什么算"真读懂"）

1. **§1.4 tool × domain 交叉维度**——这是 rikkahub 没有、MOV 支付铁律必然推导出的设计增量，能自己推出来说明 §7 安全闸读透了，不是抄
2. **§3 一体两面的三条代码证据**（ContextProvider 共享、AppForegroundDispatcher 双消费者、battery 过渡追踪=边检测）——"trigger 读时间导数、condition 读瞬时值"的形式化准确，且 §2.4 的 parse cache `(id, updatedAtMs)` key 细节是探索代理报告里没有的，证明确实下了源码
3. **§5 Q1 cooldown 锚点滑移**——这是该代码库最微妙的坑之一，答对了

### 三处批注（发令枪后 schema 冻结时修正，不阻塞）

1. **§1.3 `*.weixin.qq.com` 不是支付域**——微信支付是 `pay.weixin.qq.com`/tenpay 系；支付域清单宁缺毋滥，冻结时逐域核实（错配 = 普通页面被强制生物识别，体验灾难）
2. **§1.2 关卡 3「模型可读但不可回显」不可强制**——模型能读就能输出，"不可回显"在 envelope 层没有强制力。改法：金额/订单号进 envelope 时就做掩码（`¥1***`），靠数据最小化不靠模型自觉（与敏感嗅探的 warning 思路对齐）
3. **§1.3 `amount_threshold_cents: 0` 语义要锁死**——MOV 铁律是"支付永远停在用户本人确认"，阈值字段若留，默认值必须是 0（=任何金额都闸）且不允许调大绕过；建议冻结时讨论是否干脆删掉该字段，少一个被攻击面

### 待命状态

- 不动手写码维持不变。Phase 3 发令枪 = ConnectWeb R3-3c（写工具+审批闸）落地之后，domain_policies 有挂载点时再启动
- 待命期间可加读：`MOV-APP/docs/DESIGN_TECH_KERNEL.md`（端侧模型渐进路线，与 ContextProvider 独立传感器层直接相关）
