# hermes-agent 瘦身盘点（解剖，不动刀）

> 状态：✅ P6 派单№2 完成（纯桌面只读，未改 hermes-agent 一个字符）
> 日期：2026-08-02
> 依据：docs/TASKS_P6_HERMES_ANATOMY_2026-08-01.md、DESIGN_HERMES_SERVE §九演进路线（阶段 3 瘦身）
> 对象：`app/src/main/assets/hermes-agent.zip`（16MB，解压后 48MB，890 个 .py）。分析在 `.ocr_p0/hermes_anatomy/`（解压副本），原 zip 未动。
> 判定基准：「serve 模式」= 把 agent 当本地服务跑（规划器 run_agent + 工具分发 model_tools/toolsets + 状态 hermes_state + 基础件），**不用的交互界面 / 消息平台 / 批处理 / 无关后端全砍**。
> 纪律：引用源码带 文件:行号，验收人抽查 3 处已自验（batch_runner 引用、tenacity/jinja2 死依赖、cli 引用点、create_session、registry glob 均实测属实）。

---

## ① 模块解剖表

**serve 判定**：serve 核心 = `run_agent`（规划器）→ `model_tools`（工具分发）→ `toolsets`/`tools/*`（工具集）→ `hermes_state`（状态）→ `utils`/`hermes_constants`/`hermes_logging`/`hermes_time`/`hermes_bootstrap`（基础件）。

### 顶层模块（pyproject.toml:317 py-modules 15 个）

| 模块 | 功能 | serve 要不要 | 砍不砍 | 砍的代价（引用证据） |
|---|---|---|---|---|
| **run_agent.py** (301KB) | AIAgent 规划器：对话/工具调用主循环、多 provider、消息历史 | **要**（serve 本体） | 不砍 | console 入口 pyproject.toml:313；acp_adapter/session.py:603；agent/conversation_loop.py:183、tool_executor.py:159；gateway/run.py:12506 等 ~30 处 |
| **model_tools.py** (65KB) | 工具注册表编排：get_tool_definitions:279、handle_function_call:1055、discover_builtin_tools:188 | **要**（工具分发核心） | 不砍 | run_agent.py:136；agent/tool_executor.py:182；tools/registry.py:628；tools/delegate_tool.py:1133 等 ~28 处 |
| **toolsets.py** (35KB) | 工具集分组/别名：get_toolset:588、resolve_toolset:689 | **要**（工具面核心） | 不砍 | model_tools.py:33；run_agent.py:6476；agent/memory_manager.py:93；tools/tool_search.py:157 等 ~26 处 |
| **hermes_state.py** (345KB) | SQLite 状态库 SessionDB:984（FTS5/WAL/parent_session 链） | **要**（serve 状态持久化） | 不砍（可瘦到 serve 方法子集，见②③刀） | run_agent.py:614/2028/3691；agent/conversation_compression.py:133；gateway/run.py:3380；cli.py:4053 等 ~35 处 |
| **utils.py** (20KB) | 共享工具（atomic_json_write、base_url_host_matches 等） | **要** | 不砍 | agent/agent_init.py:53；auxiliary_client.py:111；cron/jobs.py:42 等 ~40 处 |
| **hermes_constants.py** (48KB) | 共享常量/路径（get_hermes_home:65、OPENROUTER_*） | **要** | 不砍 | agent/* ~25 处；acp_adapter/session.py:11；gateway/run.py 等 ~40 处 |
| **hermes_logging.py** (31KB) | 集中日志（setup_logging:259、RedactingFormatter） | **要** | 不砍 | agent/agent_init.py:715；conversation_loop.py:74；gateway/run.py:22598 等 |
| **hermes_time.py** (4.5KB) | 时区时钟 now()/get_timezone() | **要** | 不砍（极小） | agent/context_compressor.py:2205；cron/jobs.py:41；gateway/run.py:946 |
| **hermes_bootstrap.py** (8KB) | Windows UTF-8 stdio 引导 | **要**（入口首行 import） | 不砍（极小） | run_agent.py:26；cli.py:18；gateway/run.py:19 |
| **cli.py** (745KB) | 交互式终端 UI（REPL、rich 排版、ChatConsole） | 不要（纯交互） | **砍**（最大单项，但代价高，见下） | hermes_cli/callbacks.py:24,203；cli_agent_setup_mixin.py:32；gateway/run.py:15632；tools/delegate_tool.py:3320；tui_gateway/server.py:3156 等 |
| **batch_runner.py** (57KB) | 批量数据集跑 agent（multiprocessing/checkpoint） | 不要（RL 数据管线） | **砍（零成本）** | 全库无 `import batch_runner`（仅 hermes_logging.py:242 logger 配置字符串、run_agent.py:6622 注释、delegate_tool.py:2988 本地函数名 `_batch_runner`，均非 import）；仅 pyproject.toml:317 列名 |
| **mcp_serve.py** (35KB) | stdio MCP 消息桥（conversations_list/messages_send 等 9 工具） | 不要（消息平台桥；**非**工具 MCP） | 可砍 | 仅 hermes_cli/mcp_config.py:1050（`hermes mcp serve` 懒加载）；注意与核心的 agent/transports/hermes_tools_mcp_server.py 区分 |
| **mini_swe_runner.py** (28KB) | SWE-bench runner（数据生成） | 不要 | **砍（零成本）** | 全库无 import；连 pyproject py-modules 都没进 |
| **trajectory_compressor.py** (69KB) | 轨迹压缩（RL 数据后处理） | 不要 | 砍 | scripts/sample_and_compress.py:270（dev 脚本懒加载） |
| **toolset_distributions.py** (12KB) | 工具集选择分布（batch 数据生成用） | 不要 | **砍（零成本）** | 仅 batch_runner.py:50,1223（同被砍）|

### 可砍清单（serve 确认）

| 模块 | 大小 | 代价 |
|---|---|---|
| batch_runner.py | 57KB | 零（仅 pyproject:317 列名） |
| mini_swe_runner.py | 28KB | 零（未打包） |
| toolset_distributions.py | 12KB | 零（随 batch_runner 死） |
| trajectory_compressor.py | 69KB | scripts/sample_and_compress.py:270 一处 |
| mcp_serve.py | 35KB | hermes_cli/mcp_config.py:1050 一处 |
| **cli.py** | **745KB** | **最高**：hermes_cli 内 ~40 处懒加载 `from cli import ...`（callbacks.py:24/203、cli_agent_setup_mixin.py:32/234 等）+ 外层 delegate_tool.py:3320、gateway/run.py:15632、tui_gateway/*、plugins/photon/adapter.py:1766 |

**cli.py 处置建议**：cli.py 引用面集中在 hermes_cli（交互命令包）与 tui_gateway/ui-tui。**若 serve 同时砍 hermes_cli + tui_gateway（交互界面层整体处置），cli.py 的引用随之消失，可整体删除**；若保留 hermes_cli 仅需 `hermes mcp serve`/`doctor`，则砍 cli.py 需改全部 ~40 处懒加载，投入产出比低。

---

## ② 依赖纠缠图（规划器最小闭包 + MOV 收编替换点）

### 2.1 核心分发链（serve 骨架）

```
run_agent.py::AIAgent
  ├─ :498 __init__ → agent/agent_init.py::init_agent(:1224 agent.tools = get_tool_definitions)
  ├─ :6350 run_conversation → agent/conversation_loop.py::run_conversation(:588 主循环)
  │     ├─ LLM 管道 → agent_runtime_helpers.create_openai_client(:4138)
  │     │            → chat_completion_helpers.interruptible_api_call(:4844)/streaming(:5256)
  │     │            → anthropic_adapter.create_anthropic_message(:4808) / codex_runtime / providers/
  │     └─ 工具执行 → agent/tool_executor.execute_tool_calls(:6222)
  │                  → model_tools.handle_function_call(:1055) → tools/registry.dispatch(:614)
  └─ 状态 → hermes_state.SessionDB（:614 create_session / :2028 append_message / :3691 end_session）
```

**最大纠缠点：工具注册是「import 副作用」模式**——`model_tools.py:188 discover_builtin_tools()` 无条件 glob 扫描 `tools/*.py`（registry.py:67-74）并 import 全部 39 个自注册工具模块，包括 discord/feishu/homeassistant/tts/video 等 serve 无关平台工具。**这是阶段 3 最高性价比刀口**（切法：(a) 删 tools/ 下平台工具文件，registry.py:72 glob 自然不再拉入；(b) discover_builtin_tools 加 allowlist/denylist）。

### 2.2 规划器最小闭包（serve 必需，模块级）

- **第 0 层（入口）**：run_agent.py（AIAgent:423/run_conversation:6350）、agent/conversation_loop.py:588、agent/agent_init.py:1224
- **第 1 层（工具）**：model_tools.py、tools/registry.py（ToolRegistry:217、registry 单例:765、discover_builtin_tools:67）、toolsets.py、agent/tool_dispatch_helpers.py、agent/agent_runtime_helpers.py + **serve 必需工具的 tools/* 子集**
- **第 2 层（LLM）**：agent/chat_completion_helpers.py、agent/anthropic_adapter.py、agent/system_prompt.py、agent/prompt_builder.py、providers/
- **第 3 层（状态/安全）**：hermes_state.py（仅 SessionDB 5 方法，见 2.4）、agent/memory_manager.py、agent/context_compressor.py、agent/redact.py、agent/error_classifier.py、agent/model_metadata.py
- **第 4 层（横切）**：hermes_constants.py、hermes_logging.py、utils.py、hermes_cli 惰性子集（env_loader:119/timeouts:120/config）

### 2.3 可切断清单

| 类别 | 模块/目录 | 理由 | 纠缠点 |
|---|---|---|---|
| 消息平台工具 | tools/discord_tool.py、feishu_*、homeassistant_tool.py、send_message_tool.py、microsoft_graph_client.py、x_search_tool.py、tts_tool.py、transcription_tools.py、video_generation_tool.py、xai_video_tools.py、yuanbao_tools.py、browser_camofox.py | serve 纯规划器不需要 IM/语音/视频/办公平台 | model_tools.py:188 discover_builtin_tools 无条件 import |
| 重媒体工具 | tools/browser_tool.py、browser_cdp_tool.py、browser_dialog_tool.py、computer_use/、image_generation_tool.py、vision_tools.py、code_execution_tool.py | 纯规划器可整刀切除 | run_agent.py:144 顶层 import browser_tool |
| CLI/批处理入口 | cli.py、batch_runner.py、mini_swe_runner.py、mcp_serve.py、hermes_cli/（若 serve 无 CLI 需求） | serve 入口是 gateway/api_server | 见① |
| gateway 平台适配器 | gateway/platforms/qqbot/ 等 telegram/discord/slack/webhook | 只留 api_server.py 作 serve 壳 | api_server.py:4682 调 run_conversation |
| TUI/Web/Dashboard | tui_gateway/、ui-tui/、web/、hermes_cli/subcommands/dashboard.py | 非 serve 必需 | — |
| Provider 适配器 | agent/anthropic_adapter.py、bedrock_adapter.py、vertex_adapter.py、codex_runtime.py、credential_pool.py 等 | LLM 收编 BridgeAi 后废弃 | run_agent.py:4338-4655 惰性 import |
| 重型 agent 功能 | agent/pet/、learning_graph*.py、background_review.py、moa_loop.py、insights.py、curator*.py | 与规划器循环解耦 | run_agent.py:1623/1636/1657 惰性 |

### 2.4 MOV 收编替换点（hermes ↔ MOV，阶段 3 一刀一个准）

| MOV 能力 | hermes 被替换的模块/函数（行号） | 收编方式 |
|---|---|---|
| **LLM → BridgeAi** | run_agent._create_openai_client:4136 / _interruptible_api_call:4842 / _interruptible_streaming_api_call:5252 / create_anthropic_message:4808 / scoped_runtime_main:6384 → 对应实现 agent_runtime_helpers.py:4138、chat_completion_helpers.py:4844/5256、anthropic_adapter.py | conversation_loop.run_conversation 保留为编排层，5 个 LLM 转发壳替换为 BridgeAi 调用；providers/ 与 7 个 provider 适配器整目录废弃 |
| **工具 → ToolRegistry** | model_tools.handle_function_call:1055 / get_tool_definitions:279、tools/registry.py ToolRegistry:217 register:365 dispatch:614 registry:765 discover_builtin_tools:67、toolsets.resolve_toolset:689 | MOV ToolRegistry 提供等价 register/dispatch → model_tools + tools/registry.py 整体替换；tools/* handler 按需迁移，serve 无关平台工具直接删 |
| **记忆/状态 → journal** | hermes_state.SessionDB:984，serve 实际只用 5 方法：create_session:2011（run_agent:614 调）/ append_message:4152（:2028）/ end_session:2359（:3691）/ get_messages:4505 / get_resume_conversations:5020；memory_tool:969、session_search_tool:903 | MOV journal 提供等价 create_session/append_message/end_session/get_messages → hermes_state 只留方法壳或整体替换；平台专属方法（Telegram topic:7007-7518、handoff:7719-7804、gateway routing:2016-2156）直接废弃 |

**阶段 3 三刀**：① 改 registry.py:72 discover_builtin_tools（或删 tools/ 平台工具）斩断 39 工具 import 副作用（serve 闭包缩 ~25 模块）→ ② run_agent 5 个 LLM 壳接 BridgeAi，providers 整目录废 → ③ run_agent 4 个 SessionDB 调用点接 journal，hermes_state 只留壳。

---

## ③ venv 依赖审计

### 3.1 核心依赖逐包（pyproject.toml [project.dependencies] L24-145）

**serve 必需（留）**：openai:45、certifi:46、python-dotenv:47、httpx[socks]:49、rich:50、pyyaml:52、ruamel.yaml:53、requests:54、pydantic:60、packaging:74、Markdown:84、urllib3:89（下限）、psutil:104、websockets:107、fastapi:110、uvicorn[standard]:111、python-multipart:116、ptyprocess:117（非 win32）、Pillow:130

**serve 可砍**：

| 包 | pyproject 行 | 用途 | 砍理由 |
|---|---|---|---|
| **tenacity==9.1.4** | L51 | 重试库 | **死依赖——全仓 0 处 import**（grep 实测仅 pyproject 命中） |
| **jinja2==3.1.6** | L55 | 模板 | **死依赖——全仓 0 处 import**（grep 实测） |
| fire==0.7.1 | L48 | CLI 框架 | 仅 run_agent.py:6649 / cli.py:16115 入口懒加载，serve 不走 |
| prompt_toolkit==3.0.52 | L62 | 交互 CLI | serve 无头不需要（agent 循环内全是注释/懒加载 display.py:1140） |
| croniter==6.0.0 | L64 | cron 调度 | 无定时任务则砍 |
| PyJWT[crypto]==2.13.0 | L86 | GitHub App JWT | 仅 bot 身份，非 serve 必需 |
| cryptography==46.0.7 | L92 | wecom/weixin 加解密 | 砍 PyJWT 后仅平台用 |
| pathspec==1.1.1 | L109 | .gitignore 匹配 | 仅 hermes_cli/main.py 桌面构建戳 |

**Termux 自动不装**：tzdata（win32 marker L98）、pywinpty:118、pywin32:122、concurrent-log-handler:144——无需处理。

### 3.2 termux/termux-all extras（L234-254）

`pip install -e '.[termux]'` 装：python-telegram-bot:236、cron(空):237、cli(simple-term-menu):238、pty(空):239、mcp(mcp+starlette):240、honcho:241、acp(agent-client-protocol):242。termux-all 追加 google/homeassistant/sms/web。
**结论**：serve 最小化不需要 telegram/honcho/acp/cli 这些 extras——它们都走懒安装（tools/lazy_deps.py），不进最小 requirements。

### 3.3 constraints-termux.txt（7 行，全为 IPython 传递树稳定钉）

ipython:9、jedi:10、parso:11、stack-data:12、pexpect:13、matplotlib-inline:14、asttokens:15——**全是 IPython 的传递依赖钉**，serve 无关。最小 requirements 不含 honcho/telegram 等拉 IPython 的包时，此文件可不引用。

### 3.4 阶段 3 最小 requirements 候选（serve，Termux/Linux，可直接 pip install）

```
openai==2.24.0
certifi==2026.5.20
python-dotenv==1.2.2
httpx[socks]==0.28.1
rich==14.3.3
pyyaml==6.0.3
ruamel.yaml==0.18.17
requests==2.33.0
pydantic==2.13.4
packaging==26.0
Markdown==3.10.2
psutil==7.2.2
websockets==15.0.1
Pillow==12.2.0
urllib3>=2.7.0,<3
ptyprocess>=0.7.0,<1; sys_platform != 'win32'
fastapi==0.133.1
uvicorn[standard]==0.41.0
python-multipart==0.0.27
starlette==1.0.1
```

20 包（核心 31 → 砍 11，含 2 死依赖）。`starlette==1.0.1` 是 CVE-2026-48710 必须显式 pin。若 MOV 不接 MCP 工具服务可去 mcp==1.26.0；确无 cron 可去 croniter；**若 serve 只跑 agent 循环不需要 HTTP 服务，fastapi/uvicorn[standard]/python-multipart/starlette 四项可整体去掉**（省 uvicorn[standard] 的 httptools/websockets/uvloop 传递树）。

---

## ④ 瘦身预估表

### 体积实测（du，解压后 /data/local/tmp/hermes_anatomy）

| 项 | 体积 |
|---|---|
| **zip 原始** | **16MB**（app/src/main/assets/hermes-agent.zip） |
| **解压后全树** | **48MB**（890 个 .py，du -sh .） |
| plugins/ | 8.3MB |
| skills/ | 8.2MB |
| hermes_cli/ | 7.2MB（web_server.py 756KB、main.py 620KB 最大） |
| tools/ | 4.7MB（mcp_tool.py 252KB、browser_tool.py 208KB） |
| agent/ | 4.7MB |
| gateway/ | 3.9MB（platforms/ 1.5MB） |
| ui-tui/ | 3.7MB |
| web/ | 2.6MB |
| scripts/ | 1.2MB |
| tui_gateway/ | 804KB |
| locales/ | 536KB |
| cron/ | 389KB |
| acp_adapter/ | 234KB |
| 顶层 .py | ~2.1MB（cli.py 728KB、hermes_state.py 340KB、run_agent.py 296KB 前三） |

### 瘦身预估（阶段 3，serve-only）

| 现体积 | 阶段 3 预估 | 砍法出处 |
|---|---|---|
| 解压 48MB | **~25-30MB**（serve 核心 + 最小依赖） | 见下明细 |
| zip 16MB | ~10-12MB（预估，随代码瘦身同比例） | ①③ |
| — ui-tui/ 3.7MB + tui_gateway/ 804KB | **-4.5MB** | ①（TUI 界面层）②（可切断） |
| — acp_adapter/ 234KB + plugins dashboard 类 ~3-4MB | **-3.2~4.2MB** | ①③（serve 非必需插件） |
| — cli.py 728KB + batch_runner/mini_swe/trajectory/toolset_distributions/mcp_serve 201KB | **-0.9MB** | ①（可砍清单） |
| — 重媒体/平台工具 tools/ 子集 | -1.5MB 级 | ②（discover_builtin_tools 刀口） |
| — venv 依赖 | 核心 31 包 → 最小 20 包（去 fire/prompt_toolkit/croniter/PyJWT/cryptography/pathspec/tenacity/jinja2） | ③（最小 requirements） |
| — skills/ 8.2MB | 按需裁（保留 serve 工具能力的技能子集） | ①③ |

**精确可砍数字（①可砍清单直接体积）**：cli.py 728KB + batch_runner 57KB + mini_swe_runner 28KB + trajectory_compressor 69KB + toolset_distributions 12KB + mcp_serve 35KB ≈ **929KB 纯 py**；加 ui-tui/tui_gateway/acp_adapter/plugins-dashboard ≈ **8-9MB**；再加 tools/ 平台工具子集 + venv 依赖瘦身 → **全树 48MB → ~25-30MB**，zip 16MB → ~10-12MB。

> 注：venv 实际体积未装测（阶段 3 pip install 最小 requirements 后实测），此处依赖瘦身以「包数量 31→20」量化。

---

## 验收自验（抽查 3 处以上）

| 论断 | 证据（已实测） |
|---|---|
| batch_runner 零 import | grep `batch_runner` 全仓仅 hermes_logging.py:242（logger 配置字符串）、run_agent.py:6622（注释）、delegate_tool.py:2988（本地函数名 `_batch_runner`），无 `import batch_runner` |
| tenacity/jinja2 死依赖 | grep `import tenacity/from tenacity`、`import jinja2/from jinja2` 全仓空 |
| cli.py 被引用 | hermes_cli/callbacks.py:24 `from cli import CLI_CONFIG`（另有 :203） |
| run_agent 调 hermes_state | run_agent.py:614 `self._session_db.create_session(...)` |
| 工具自注册副作用 | tools/registry.py:67-74 discover_builtin_tools 的 `tools_path.glob("*.py")` 扫描 |
| serve 收编替换点 | run_agent.py:4136/4808/4842/5252/6384（LLM 壳）、model_tools.py:1055（工具分发）、hermes_state.py:2011/4152/2359（状态 3 方法） |
