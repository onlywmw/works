# serve 任务链诊断报告 —— proot 内 LLM 连通性（2026-08-10）

> **性质**：队列三⑦ 诊断（限时只读三测，未改任何代码）。修法另派单。
> **方法**：手动重建 app 的 proot 启动命令（`libproot.so -0 --kill-on-exit --link2symlink -r <rootfs> -b /dev -b /proc -b /sys`），在 proot 内跑 curl/DNS/代理三测。

## 一、三测结果

| # | 测试 | 命令 | 结果 |
|---|---|---|---|
| 1 | 外网 curl | `curl https://api.deepseek.com` | ✅ **HTTP 401 in 0.467s**（通！401 = 无 token 正常响应） |
| 2 | DNS | `getent hosts api.deepseek.com` | ✅ **43.242.198.77**，RC=0；resolv.conf = 8.8.8.8/223.5.5.5 |
| 3a | 代理环境 | `env | grep -i proxy` | ✅ 无代理变量（纯直连） |
| 3b | 跨域名 | `curl api.deepseek.com` vs `api.openai.com`/`github.com`/`google.com` | ⚠️ **DeepSeek 通，境外全部超时**（openai/github/google 均 timeout 000） |

## 二、核心结论（推翻旧认知）

**「proot 内直连 LLM Connection error」的旧结论不准确。**

真相：**proot 网络本身完全通畅**（DNS 正常、TLS 握手正常、curl 真实出网），真正的问题是——

> **平板当前网络环境对境外域名受限**：国内端点（api.deepseek.com）可达，境外端点（api.openai.com / github.com / google.com）全部连接超时。

这是**平板网络层（运营商/路由器）的访问范围限制**，与 proot、与 serve 代码、与 LD_PRELOAD 禁网规则**均无关**。

## 三、对 serve 任务链的修法指向（供派单，本次未改码）

1. **确认 serve 用的 LLM 端点**：若 hermes agent 直连的是境外端点（OpenAI 协议如 `api.openai.com`），proot 内直连必失败——符合「走 MOV 侧 /infer 转发」的既有方向（`/infer` 走 MOV BridgeAi，MOV 用 DeepSeek 国内可达）。
2. **验证路径**：`/infer`（MOV 侧 8388）已通（工单4 实证）；serve 任务链应改为「proot 内 hermes → 本地 /infer 转发 → MOV BridgeAi → DeepSeek」，避开境外直连。
3. **诚实降级**：若无法改网络，serve 完整任务链以「走 /infer 转发」为修法派单，或诚实记录「网络受限，境外 LLM 直连不可行」。

## 四、证据（logcat / 实测输出）

- 诊断1：`HTTP 401 in 0.467184s`（DeepSeek）
- 诊断2：`43.242.198.77 api.deepseek.com.eo.dnse1.com` / `DNS_RC=0` / `nameserver 8.8.8.8, 223.5.5.5`
- 诊断3：`NO_PROXY_ENV` / `deepseek:401 github:000 google:000`

## 五、环境备注

- proot 二进制：`/data/app/.../lib/arm64/libproot.so`（213KB）
- rootfs：`/data/data/com.hermes.android/files/linux/rootfs`（app 域）+ `/data/local/tmp/rootfs`（tmp，OCR 用）
- 手动重建命令可复用（见附录），后续派单可直接套用

---
*诊断只读完成，未改任何代码。修法派单建议：serve 任务链改走 /infer 转发。*
