# MOV 核心竞争力资产库

> 目的：沉淀"我设计/改造出来比较特别的东西"——真正的核心竞争力，**不断强化**。
> 分支：`核心竞争力`（专属维护线，不在 main 上乱动）
> 建立：2026-08-03

---

## 一、端侧 OCR 全链路改造（最硬核壁垒）

**一句话**：不是用开源现成的，是把百度 Unlimited-OCR 从零改造成平板端可用的完整 OCR 系统（隐私通道：不能出端的数据本地解析）。

### 代码资产

| 文件 | 内容 |
|---|---|
| `ocr/scripts/vision_infer.cpp` | 视觉集成推理（embd 注入 + logits_idx 修复——退化/慢/崩总根因） |
| `ocr/scripts/gguf_convert.sh` | HF→GGUF F16 + llama-quantize Q8_0/Q4_K_M |
| `ocr/scripts/build_llama_cpp.sh` | llama.cpp aarch64 自编译（钉版 b10216，DeepSeek-OCR aware，上游不支持） |
| `ocr/scripts/ocr_accept.sh` | 一键验收脚本（三图 golden 回归 + 四指标判读） |
| `ocr/patches/rswa-b10216.patch` | **R-SWA patch**（参考滑动窗口注意力：恒定 KV，长文档不退化，decode 2.7×） |
| `ocr/scripts/export_vision_onnx.py` | 视觉编码器分图导出（SAM-ViT-B + CLIP-L，绕 OOM） |
| `ocr/scripts/verify_vision_mnn.py` | MNN 视觉管线 + 余弦验证（cosine 0.9999） |
| `ocr/testdata/golden/` | 三图 golden（golden1_doc_chinese/paper/receipt，380/380 判据） |

### 文档资产

| 文件 | 内容 |
|---|---|
| `docs/OCR_DECODER_MNN.md` | 解码器移植全史（MNN 墙→llama.cpp→R-SWA→验收） |
| `docs/OCR_VISION_MNN.md` | 视觉编码器 MNN 移植（分图方案、273 token/页） |
| `docs/OCR_RSWA_LLAMACPP.md` | R-SWA 设计与施工 |
| `docs/OCR_GOLDEN_SAMPLES.md` | 三图 golden 参考输出 |
| `docs/OCR_PLAYBOOK.md` | OCR 跑法手册 |
| `docs/LLM_TEST_PLAYBOOK.md` | 指标体系 + 判例库 |

### 强化方向
- [ ] 解码速度（R-SWA 后 13.7 tok/s → 目标更高）
- [ ] 视觉编码 GPU 加速（Adreno，CPU 23.5s → ≤2s）
- [ ] 微调升级（见 `OCR-finetune/README.md`，云 GPU LoRA）

---

## 二、MOV 产品设计（理念壁垒）

**一句话**：MOV = AI 原生个人成长伴侣，不是工具集合，是"会和你一起进化的 AI 伙伴"。

### 资产

| 文件 | 内容 |
|---|---|
| `docs/PLAN_SURPASS.md` | 超越计划（产品对位 + 可演化记忆层 + 四支柱 + 工作对标 WorkBuddy） |
| `docs/PRODUCT_COMPARISON.html` | 四支柱对位可视化（工作×WorkBuddy 对照） |
| `docs/DYAD-VS-MOVAPP.md` | 架构对比调研（Dyad v1.9.0 源码级） |

### 核心设计
- **可演化记忆层**（灵魂）：成长轨迹，AI 越来越懂"此刻的你"
- **四支柱**：健身 / 笔记（日记→视频工作流）/ 学习 / 工作（对标 WorkBuddy）
- **多模型协作**：快脑+慢脑、一表两脑

---

## 三、架构独有机制

**一句话**：用户定方向、定机制，在手机这个载体上做出别人没有的东西。

| 机制 | 位置 |
|---|---|
| Journal 事件溯源（append-only，唯一消息真理源） | `docs/ARCHITECTURE.md` + `app/.../agent/Journal.java` |
| 内嵌 Linux（proot Ubuntu 手机跑完整工具链） | `docs/ARCHITECTURE.md`（M1 节）+ `linux/` |
| 双副本保险柜（AES-GCM + KeyguardGate） | `vault/` |
| 记忆三层 + 工具健康（L1/L2/L3 + H1/H2） | `docs/ARCHITECTURE.md` + `agent/` |
| 对话式服务入口（说一句话→服务到位） | 产品整体 |

---

## 四、工程方法论（软壁垒）

| 资产 | 位置 |
|---|---|
| 验收体系（不信自报信实物/变异测试/假覆盖四形态/五招） | `docs/ACCEPTANCE_PLAYBOOK.md` |
| 三图 golden 回归 | `ocr/testdata/golden/` + `ocr_accept.sh` |
| 人机协同开发模式（多 AI agent + 任务板协议） | `docs/TASKBOARD.md` |

---

## 强化日志

> 每次强化核心竞争力，在这里记一条：日期 / 强化了什么 / 效果 / 验证。

| 日期 | 强化项 | 内容与效果 | 验证 |
|---|---|---|---|
| 2026-08-03 | 资产库建立 | 核心竞争力盘点入档，专属分支启动 | 分支 `核心竞争力` |
| | | | |
