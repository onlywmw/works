# MOV 验收手册（Acceptance Playbook）v1 — 2026-07-31

> 用途：验收质量守恒——谁拿这本册子验收，结果都一样仔细。
> 铁律一句话：**不信自报，信实物。**

---

## 0. 验收分级（先定级再动手）

| 级 | 范围 | 流程 |
|---|---|---|
| L1 低 | docs/注释/机械重命名/纯测试 | git show 扫读 + 构建绿 |
| L2 中 | 业务逻辑/JS 行为/规则表/文案 | +单测计数核对 + 针对性真机（一项） |
| L3 高 | 状态机/支付/桥签名/权限/持久化格式/网络协议 | 全套：diff 精读+变异测试+真机多场景+logcat |

定错级 = 验收事故的第一来源。拿不准就往高定。

## 1. 五招（逐条照做）

### 招 1 · 不信自报，信实物
- 程序员的「✅ 全过」表格只是**线索**，不是证据
- 每条验收标准必须对应一个**你亲手产出的实物**：截图/logcat 原文/测试计数/diff hunk
- **无图不验收**：真机项没有截图（或等效日志）= 没验

### 招 2 · 变异测试（杀一个 mutant 才算数）
流程：
1. 先无变异跑目标测试类，**确认它真绿**（输出含 `N tests completed`）
2. 在生产代码里种一个最小变异（删掉被测功能的核心一行）
3. 重跑——目标测试**必须红**，且输出含真实计数（`N tests completed, M failed`）
4. 还原变异（`git checkout`，**untracked 文件 git checkout 无效，先备份**）
5. **「BUILD FAILED」≠「测试红」**：可能是过滤器匹配 0 测试（`--tests` 打错模块）、编译错、文件锁。必须看到具体 `XxxTest > yyy FAILED` 行才算

### 招 3 · 假覆盖四形态图鉴（每个新测试类对照排查）
| 形态 | 特征 | 实例 |
|---|---|---|
| ① mock 答案喂解析器 | 断言的是 mock 输入不是生产行为 | mock LLM 答案测 ActionParser |
| ② 虚构生产不存在的数据路径 | 夹具造生产环境没有的文件/格式 | rooms/*/chat/*.jsonl（真实是 journal.jsonl） |
| ③ 字面量比较 | `assertNotEquals("a","b")` 不调生产代码 | KeystoreFallback 第一版 |
| ④ 测试里重写被测逻辑 | 把生产条件抄写一遍再断言 | battery 手写布尔自证 |

### 招 4 · 真机验证（L2 起必有）
- 固定四步：`install -r` → `am force-stop` → 启动 → 测（构建≠装机，P1 在这翻车两次）
- 网络 IO 走 cbId 异步桥，CDP 驱动（tools/e2e/）
- 断言与截图一一对应（截图里看得到断言的那件事）
- 警惕「设备路径≠测试路径」：单测 activity=null 走 A 路、真机走 B 路（4b SOE 就是这么炸的）

### 招 5 · 打回要写到能直接修
- 每条打回：现象（实证）→ 根因（文件:行号）→ 修法（具体方案或二选一）→ 复验方式
- 不写「体验不好」「感觉不对」这种没法施工的打回

### 招 6 · 证据落盘前脱敏（安全红线）
- 证据文件（日志/请求体/响应体/截图 OCR 文本）落盘前，**Bearer key / token / Authorization 头一律打码**（如 `sk-***REDACTED***`），保留字段结构即可
- 明文密钥进仓库 = 安全事故（2026-08-06 工单4 教训：DeepSeek key 进 device-acceptance 已推公网，被迫轮换）
- 验收复核加「证据文件密钥扫描」一项：`git grep -nE "sk-[a-f0-9]{32}"` 命中即打回，先脱敏再提交

## 2. 环境药方（ recurring 事故）

| 事故 | 药方 |
|---|---|
| Windows 文件锁（output.bin DeleteException） | `./gradlew --stop` → `rm -rf app/build/test-results`；顽固则 `taskkill //F //IM java.exe`（先确认 Android Studio 没在跑） |
| CDP socket hang up | 进程被杀了：重新 pidof + forward；targets 页面导航会杀旧 ws，重新发现 target |
| 截图全黑 | 设备息屏：`input keyevent KEYCODE_WAKEUP` |
| logcat grep 自匹配 | 命令本身进 logcat：`grep -v ShellService` |
| 「无变化」报告 | 旧包还活着：固定四步里的 force-stop 没做 |

**CDP 复验手法（2026-08-07 入档，工单16）**——真机查前端状态/驱动桥：

```bash
# 1) 找当前 app 的 WebView devtools remote 并 forward（app 每次重启 remote 变）
REMOTE=$(adb -s 21770d7d shell "cat /proc/net/unix | grep webview_devtools | awk '{print \$NF}' | head -1" | tr -d '\r' | sed 's/@//')
adb -s 21770d7d forward tcp:9222 localabstract:$REMOTE
# 2) 拿 page id
PAGE=$(curl -s http://127.0.0.1:9222/json | python -c "import sys,json;d=json.load(sys.stdin);print(d[0]['id'])")
# 3) WebSocket eval（python websockets）调 B 桥/查状态，如 B.query({q:'agent_state'}) / B.testModel(...)
```

## 3. 验收记录格式

- 结论表（项/结果/证据），打回项附实证与修法
- 写进 **docs/ACCEPTANCE_LOG.md「验收记录」区**（验收员唯一产出落点，2026-08-03 起），commit hash 标注；任务文档只留指针
- 自我纠错也记录（验收人错判留档，例如变异测试模块错误事件）

## 4. 历史判例索引（学习用）

- 4b SOE：递归+虚构数据路径双重打回 → TASKS_P2_2026-07-30
- KeystoreFallback 三形态：TASKS_P2_ROUND2_2026-07-30
- ContextProvider battery 第四形态：TASKS_P3_ROUND1_2026-07-30
- ConnectWeb 四层打回链（cb 投递/合成事件/受控组件）：DESIGN_EMBEDDED_BROWSER.md
