# WebAdapter：AI 网页解析接入技能 — 2026-07-31（用户拍板：连接一切）

> 用户原话：AI 对网页做出解析和适配这个很重要，和我们的理念契合——连接器，连接一切。这个要成为一个技能（MCP），快速解析、快速接入；不能解析和接入的，就让人手动去操作，给出改造方案。
> 定位：MOV 的第一技能。**接入一个站点，从「程序员写适配器」变成「AI 看一眼就会」**。

## 为什么这是理念级能力

```
v1 手写适配：DramaSource.tryDouban / tryBilibili / tryMayi   ← 程序员挨个写，写不动
v2 站点建模：MayiSite                                       ← 一处建模，但还是手写
v3 WebAdapter：给 AI 一个 URL，它自己学会怎么用             ← 连接一切
```

## 技能三段式

### ① 解析（agent 探索站点）

用户说「我想用这个站」→ agent 用 ConnectWeb 工具链探索：
- browser_snapshot → 认搜索框/导航/列表结构
- 试搜一个词 → click_and_read 认结果卡片结构（标题/链接/详情）
- 进详情 → 认选集/播放按钮/资源线
- 输出 **SiteCard（站点模型卡）**：

```json
{
  "site": "91mayitv.com",
  "searchUrl": "/vodsearch/{q}-------------.html",
  "resultCard": {"link": "a.v-thumb@href", "title": "@title", "poster": "@data-original"},
  "detail": {"episodes": ".stui-vodlist__media a", "nidPattern": "/vodplay/{id}-{sid}-{nid}.html"},
  "confidence": 0.92,
  "verified": "2026-07-31 实播验证通过"
}
```

### ② 分级接入（自信度路由）

| 级 | 判据 | 动作 |
|---|---|---|
| **A · 自动接入** | 结构清晰、实播验证过（confidence ≥ 0.8） | SiteCard 落库 → 立即可用（搜索/选集/播放） |
| **B · 半自动** | 部分可读（0.4-0.8） | AI 生成候选规则 → 用户确认一处 → 入库 |
| **C · 引导模式** | 解析失败（< 0.4） | **用户手动操作一遍**（ConnectWeb 记录操作序列成宏，可回放）+ AI 输出《改造方案》（为什么接不了、人工怎么用最顺、是否值得写专适） |

### ③ 运行时（模型驱动）

SiteCard 和手写 MayiSite **共享同一运行时接口**（Show/search/detail/latestEpisode/playUrl）——手写模型和 AI 生成模型对上层无差别。AI 生成的 SiteCard 定期复验（站点改版 → 降级回探索模式重新学）。

## MCP 工具（技能形态）

- `web_adapt(url, hint?)` → SiteCard（A/B/C 级判定 + 验证结果）
- `web_sites()` → 已接入站点列表（含等级和健康度）
- `web_use(site, action, params)` → 按 SiteCard 执行 search/latestEpisode/play 等
- `web_record(url)` → 开始录制人工操作宏（C 级用）

## 与既有资产的关系

- MayiSite 是 WebAdapter 的**第一个手工 SiteCard**（它的字段就是模型卡的雏形）
- ConnectWeb 工具链（snapshot/click_and_read/wait_for/审批闸）就是探索时的手脚——**R3 做的浏览器协议在这里兑现价值**
- C 级引导模式复用 观看历史/操作序列 journal

## 施工序列（P1 先行，P2/P3 合流）

1. 站点模型卡 schema + 运行时（MayiSite 改造成首张卡）
2. `web_adapt` 探索流程（agent 用 ConnectWeb 工具探索 + 生成卡 + 实播验证）
3. A/B/C 分级路由 + B 级确认 UI + C 级操作宏录制
4. 验收：给一个没接过的影视站 URL → A 级自动接入可播；给一个烂站 → C 级出《改造方案》

## 铁律沿用

- 支付闸：探索/播放不涉及支付域动作；接入的站点若带支付墙，只展示不代付
- 反假菜单：AI 生成的 SiteCard 必须实播验证才能标 verified，不许"看着像"就入库
- 端侧：SiteCard 落 filesDir，站点凭据（如蚂蚁的会话）不出设备

---

## SessionVault 通用登入态保险库（2026-07-31 用户加单）

> 用户原话：网站的登入态的记住要实现，这样用一些官方网站的时候就能不受影响了。
> 既有地基：CookieManager 应用级共享会话（抖音/腾讯「连接」已验证登录一次免登录）。
> 任务：从「抖音/腾讯特权」升级为「任意官方站通用」。

### 三层实现

**① 会话持久化加固（地基工程）**
- CookieManager.flush() 定时（30s）+ onPause/onDestroy 强制刷盘——防进程被杀丢内存 cookie
- 会话健康自检：启动时对每个已连接站点跑 quickCheck，失效自动标灰（不再让用户撞墙才发现）

**② 站点 auth 配置化（照 OpenCLI registerSiteAuth 形态）**
- SiteCard.auth = { loginUrl, quickCheck: {cookieKeys: [...]} , verify: {endpoint, field} }
- 首批官方站配置：
  - 爱奇艺：quickCheck=爱奇艺 auth cookie 键（实测确定）
  - 优酷/芒果/哔哩/12306：同法逐个配
- quickCheck 两级：cookie 键存在 → 「已连接」；再调 verify endpoint → 「身份有效/仅痕迹」

**③ 通用「连接」流程（任意站点复用）**
- 抽屉连接区：从「抖音/腾讯双卡」泛化为「已接入站点列表」（SiteCard 驱动）
- 新站连接：打开 loginUrl（ConnectWeb 登录模式）→ 用户登录 → quickCheck 通过 → 连接卡变绿「已连接」
- 连接后：该站所有页面共享会话（H5 播放/会员内容免登录——爱奇艺实测例：登录后 H5 播放页不再跳登录墙）

### 验收（真机）

- [ ] 任意官方站登录一次 → force-stop × 3 次 → 仍登录
- [ ] 爱奇艺登录后 → 说「我要看xxx」走爱奇艺源 → H5 播放无登录墙
- [ ] 连接卡显示真实状态（quickCheck 实测，不嘴硬）
- [ ] 单测：cookie flush 时机、quickCheck 两级判定
