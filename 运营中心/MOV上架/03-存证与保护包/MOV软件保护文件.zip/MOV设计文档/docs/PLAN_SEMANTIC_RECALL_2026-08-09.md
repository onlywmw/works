# PLAN：语义召回层（端侧 embedding 增强 Journal.search）— 2026-08-09 · 修订版

> **给谁看**：查验员 / 技术审查。
> **前置文档链**：`docs/EVAL_JCODE_MOV_2026-08-09.md`（可行性）→ `docs/DESIGN_SEMANTIC_RECALL_2026-08-09.md`（设计）。
> **本版修订**：吸收查验意见 **A1-A10**。头号修订 = **A1 粗筛漏斗漏洞**（原「子串粗筛→语义重排」在语义场景下粗筛先空，M4 正例必挂），改为**方案 B：子串命中 ≥K 走保底，<K 对最近时间窗补做语义**。
> **目标**：搜「睡眠不足」能命中「凌晨三点才睡」。现状纯子串匹配做不到。

---

## 〇、修订点汇总（对照查验意见）

| 编号 | 查验意见 | 处置 | 落点 |
|---|---|---|---|
| 🔴 A1 | 粗筛漏斗漏洞：语义场景粗筛先空，头号目标不成立 | **采纳方案 B**：子串命中 ≥K(3) 保底照旧；<K 对最近 30 天/≤50 条补语义 | §二 流程 |
| 🔴 A2 | 200 条逐条 embed = 秒级卡顿；须 batch，候选压 ≤50 | **采纳**：候选上限 ≤50，单批 batch（input 数组原生支持）；EmbeddingClient 已内建批量 | §二 流程 + §三 |
| 🟠 A3 | 重排粒度：整条长记忆截断稀释 | **采纳内核**（截断策略 A10 落地；方案 B 无命中位置可用，不用 ±N 上下文窗口） | §三 截断 |
| 🟠 A4 | 首启同步等 1-3s 必卡 | **采纳**：未就绪→本次直接回退 + 异步预热；等待上限写进测试 | §三 首启 |
| 🟠 A5 | 排序从 ts 序变相关度序，须列调用方 + 阈值 | **采纳**：调用方清单已 grep（§四）；加相似度阈值（cosine ≥0.5 才前置） | §四 + §三 |
| 🟡 A6 | bge query 需指令前缀 | **采纳**：SemanticReranker 对 query 加前缀，候选不加 | §三 |
| 🟡 A7 | 模型文件走桌面下载→adb push | **采纳**：桌面下载 GGUF → `adb push` 到 filesDir | §七 |
| 🟡 A8 | 派单走 TASKBOARD 查验员派单制 | **采纳**：登记新工单 | §七 |
| 🟡 A9 | 变异靶应对齐：靶在 SemanticReranker 排序，JournalTest 是接缝 | **采纳**：两测试分开表述 | §五 M3 |
| 🟡 A10 | 明确 512 token 截断策略 | **采纳**：截尾保留最新语义（无命中位置可用） | §三 |

## 一、方案总览

| 部件 | 职责 | 位置 |
|---|---|---|
| **P1 EmbeddingClient** | llama.cpp `/v1/embeddings` 封装：payload 构造（**批量** input 数组）/ 响应解析 / 余弦 / 错误映射（纯 JVM 零网络） | 新增 `llama/EmbeddingClient.java`（M1 草稿已写，批量已内建） |
| **P2 EmbeddingServerManager** | 8081 第二 llama-server，bge-small-zh-v1.5（GGUF int8 ~24MB）；懒启动→healthz-on-call→空闲 30min 退出 | 新增 `llama/EmbeddingServerManager.java` |
| **P3 检索增强** | `Journal.search` 方案 B 改造 + `SearchReranker` 接口 + `SemanticReranker` 实现 | 改 `agent/Journal.java`；新增接口与实现 |

## 二、检索流程（方案 B，A1+A2 落点）

```
search(query):
  ① 子串粗筛全量 → 命中集合 S
  ② if |S| >= K(=3, 可配):
         return S 按 ts 倒序 + seq 次级键 → topN   # 保底路径：整段不许动（含 seq 键），与现状逐字节一致
  ③ else（子串命中不足 → 语义补充）:
         C = 最近 30 天 / ≤50 条记忆（取条数小者，单批 batch）
         Vq = embed(query + BGE 指令前缀)      # A6：query 加前缀
         Vc = batch embed(C)                   # A2：一次请求 ≤50，几十 ms 级
         sim[i] = cosine(Vq, Vc[i])
         语义命中 = {i | sim[i] >= THRESHOLD(=0.5, 可配)} 按 sim 降序
         取 top(N - |S|) 条
         结果 = S(ts 倒序) 前置 + 语义命中(sim 降序) 后置 → 截 topN(≤50)
  ④ 语义层失败（server 未就绪/超时/异常）→ 返回 S 结果 + 异步预热，不阻塞（A4）
```

**为什么这样对**：
- 保底路径（②）在子串命中充足时**零开销**，行为与现状一致（A5 排序影响仅发生在语义补充路径）。
- 语义补充（③）只在子串命中 <K 时触发，代价上界 = 1 次 ≤50 条 batch embed（几十 ms）。
- M4 正例成立：「凌晨三点才睡」近期写入 → 搜「睡眠不足」子串命中 0(<K) → 补最近 50 条 → batch embed → cosine 高 → 命中。

## 三、关键实现点

| 点 | 决定 |
|---|---|
| **批量（A2）** | `buildEmbeddingPayload(model, List<String>)` 用 input 数组（已实现）；单请求 ≤50 条，M1 测试补批量用例 |
| **截断（A3+A10）** | 候选 embed 文本超 768 字符（~512 token 安全值）→ **截尾**保留最新语义（方案 B 无命中位置，不用 ±N 窗口）；常量可调 |
| **query 前缀（A6）** | `SemanticReranker` 对 query 文本加 `为这个句子生成表示以用于检索相关文章：`，候选不加 |
| **阈值（A5）** | `cosine ≥ 0.5` 才计入语义命中（可配），低于阈值的候选丢弃——防完全无关的子串候选被前置 |
| **首启（A4）** | `rerank` 内 `ensureRunning(awaitMs ≤ 1000)`；超时/未就绪 → 返回 null（Journal 回退）+ 后台异步预热；测试用 fake healthz 未就绪验证回退不阻塞 |
| **排序合并（A5）** | 子串命中 ts 倒序在前、语义命中 sim 降序在后；结果顶到 ≤50。语义补充路径的排序变化对 2 个调用方的影响见 §四 |

## 四、Journal.search 调用方清单（A5 已 grep 实证）

| 调用方 | 位置 | 排序影响评估 |
|---|---|---|
| `MemoryToolProvider`（F3 记忆工具） | `toolprovider/MemoryToolProvider.java:351` | **正向**：agent 记忆工具按相关性排更合理；子串命中在前不损失精确性 |
| `MovInboundServer`（serve HTTP /search） | `serve/MovInboundServer.java:419` | 需确认前端/调用方是否依赖 ts 序分组展示；保底路径（②）不触发时顺序与现状一致，风险仅限语义补充路径 |

## 五、接口设计（审查重点）

```java
// agent 包（Journal 同包）
public interface SearchReranker {
    /** 给定搜索词与候选文本，返回候选下标重排顺序（高相似在前）。
     *  允许返回子集——被阈值过滤的候选下标不出现；子集内保持高相似在前（流程③阈值丢弃语义）。
     *  返回 null 表示不重排（Journal 保持原排序）。实现必须容错，任何异常返回 null。 */
    List<Integer> rerank(String query, List<String> texts);
}
// Journal 内静态注入，默认 null（不注入 = 现状逐字节一致）
public static void setSearchReranker(SearchReranker r);
```

- `SemanticReranker`（llama 包，实现）：**query 加前缀 + 批量 embed + cosine 排序 + 阈值 + 截断 + 首启回退**，全异常 catch 返回 null。
- Journal 只认接口，不依赖 llama 包（零网络纪律）。

## 六、改动文件清单

**新增**：`llama/EmbeddingClient.java`（M1 ✅ 草稿）、`llama/EmbeddingServerManager.java`（M2）、`llama/SemanticReranker.java`（M3）、`llama/EmbeddingClientTest.java`（M1）、`llama/EmbeddingServerManagerTest.java`（M2）、`llama/SemanticRerankerTest.java`（M3）。
**修改**：`agent/Journal.java`（M3：接口 + search 方案 B）、`agent/JournalTest.java`（M3：接缝用例）。
**不动**：前端、`causal/`、`serve/`、`LlamaServerManager`（M2 拷贝结构不抽父类）。

## 七、分期与验收

| 期 | 交付物 | 验收 |
|---|---|---|
| **M1** | EmbeddingClient + 测试 | payload 结构 / **批量多向量解析按 index** / 非法 null / cosine（同向=1·正交=0·反向=-1·零向量=0）/ mapError 全分支 |
| **M2** | EmbeddingServerManager + 测试 | decide 状态机（REUSE/WAIT/NO_INSTALL/START）/ healthz 假探针零网络 / 空闲超时决策 |
| **M3** | SearchReranker + SemanticReranker + Journal 方案 B + 测试 | **接缝测试（JournalTest）**：注入 fake reranker 验证「注入后按返回序重排 / 不注入 = 现状逐字节一致（**含 ts+seq 次级键排序**） / reranker 返回 null 回退 / reranker 返回子集按序取」；**实现测试（SemanticRerankerTest，A9 靶点）**：cosine 排序·阈值过滤·query 前缀·截断——变异恒零向量/恒等余弦 → 排序断言必红；A4 首启回退用例 |
| **M4** | 真机验证 | 正例：「凌晨三点才睡」近期写入，搜「睡眠不足」命中；反例：无关不误召回（阈值过滤）；子串保底路径（命中 ≥K）顺序与现状一致；logcat 见 embedding 调用/回退日志；证据链（触发截图→logcat→结果截图） |

**全量红线**：编译 + 全量单测绿；单测零网络（注入构造）；桥错误统一信封；新代码必配新测试。

## 八、决策与依赖

| 项 | 决定 |
|---|---|
| 模型文件（A7） | **桌面下载** bge-small-zh-v1.5 GGUF（int8）→ `adb push` 到 `filesDir/models/embedding/`（平板内下载 24MB 不稳定） |
| 派单（A8） | 登记 **TASKBOARD 新工单**（查验员派单制），M1 草稿已写、派单成本低 |
| 8081 端口 | 与 serve 纪律一致（127.0.0.1 + Bearer token），无占用 |
| K / THRESHOLD / 时间窗 | K=3、THRESHOLD=0.5、窗口 30 天，均常量可配，M4 实测调参 |

## 九、明确不做（v1）

- 不做全量语义索引缓存（留 v2）；不做 ±N 命中上下文窗口（方案 B 无命中位置）；不碰因果引擎/记忆三层/serve/前端；不做云端 embedding（隐私红线）；不引入新外部依赖。
