# 调研：TencentDB Agent Memory — 对话/文档/代码 → 4 类可复用记忆资产的转换机制

> 日期：2026-08-07｜对象：`TencentDB-Agent-Memory`（腾讯云开源，MIT，Node≥22，feat/server_team 分支）
> 定位：面向 **Agent 团队** 的记忆中枢（Memory Hub）——让经验沉淀、流动、被下一位 Agent 直接继承。

## 〇、四类资产总览

| 资产 | 输入 | 输出 | 归属模块 |
|---|---|---|---|
| **Chat Memory** | 对话消息 | 分层记忆（L0-L3） | MemoryCore `src/core/conversation` + persona/scene |
| **Skill** | 对话 + 工具调用 | 可复用 Skill（版本/触发/步骤/验证） | MemoryCore `src/core/skill` |
| **Wiki** | 文档/文件 | 结构化页面 + 链接图 | MemoryKnowledge `src/engines/wiki` |
| **CodeGraph** | 代码库 | 符号/调用关系/影响路径 | MemoryKnowledge `src/engines/code` |

## 一、Chat Memory：对话 → 分层记忆（L0-L3）

**转换链路**：原始对话 → 逐层沉淀 → 独立 Agent 记忆。

| 层 | 机制 | 核心文件 |
|---|---|---|
| **L0 Conversation** | 常驻记录原始对话消息到本地 JSONL；`sanitizeText`/`stripCodeBlocks` 清洗（去代码块/敏感） | `core/conversation/l0-recorder.ts` |
| **L1 Atom** | 从 L0 提取原子事实（偏好/决策/交互历史），带 `source_message_ids` 溯源 | 分层 pipeline |
| **L2 Scenario** | `scene-extractor` 按场景（filename-normalizer/scene-format）组织原子事实 | `core/scene/` |
| **L3 Persona** | `persona-generator` + 触发器，聚合形成人设画像（"这人是谁/偏好什么"） | `core/persona/` |

**核心设计**：记忆不是"聊天记录仓库"，是**分层沉淀**——原始对话存 L0，逐层提炼到人设 L3；每个 Agent 创建即独立记忆，换 session 不必重新自我介绍。

## 二、Skill：对话/工具调用 → 可复用 Skill

**转换链路**：对话归档 → 常驻 worker 抽取 → LLM 生成候选 → 审核 → 落库/配装。

- **extract-worker 常驻循环**：`BRPOP task` → 抢 extract-lock → 读归档 → `SkillExtractor.extract` → `sink.applyCandidates` → 删 task（并发：agent 级锁 + tasks-mutex）
- **LLM 抽取**：`skill-extractor.ts`（候选结构）+ 抽取/审核 prompts（`SKILL_REVIEW_PROMPT` 等）——对话+工具调用 → 提炼可复用流程
- **Skill 形态**：不只是 Prompt——有**版本 / 资源文件 / 触发边界 / 执行步骤 / 验证规则**；个人私有 → 审核 → 团队分享 → 配装给其他 Agent

**核心设计**：跑通一次的做法（排障/Review/上线检查）提炼成资产，"练会一次，全队可用"。

## 三、Wiki：文档 → 结构化知识图

**转换链路**：文档 → ingest-v2 引擎 → 结构化页面 + 链接图 → 检索。

- **ingest-v2**：解析 `frontmatter`（title/type/sources/description）+ wikilink 内联
- **存储**：SQLite 三表——`wiki_fts`（全文）+ `page_meta`（页面元信息）+ `graph_edge`（链接边）；写走独立事务连接
- **图谱查询**：小图从 `graph_edge` 临时构建内存 graphology 实例做**多跳 BFS**（`graph-search.ts`）
- **Agent 用途**：搜索/阅读文档，不必先读完所有目录

**核心设计**：RAG 解决"能查到什么"，Wiki 解决"文档结构与关系"——结构化页面 + 链接图谱。

## 四、CodeGraph：代码 → 符号/调用/影响

**转换链路**：代码库 → 索引符号/文件/调用关系 → 影响路径查询。

- **engines/code**：索引代码符号、文件、调用关系与影响路径
- **Agent 用途**：查 callers/callees、改代码前先做 **impact analysis**（"改了可能影响哪"）
- **Source-fetcher**：导入已有代码库/文档/对话 Session，自动处理

**核心设计**：不只告诉 Agent"代码在这"，还告诉它"改动的影响范围"。

## 五、共性机制（四类资产共享）

1. **分层沉淀**：L0-L3（对话）/ 提取-审核-配装（Skill）/ ingest→graph（Wiki/CodeGraph）——都是"原始 → 提炼 → 结构化"
2. **资产化治理**：Owner / 版本 / 状态 / 可见性 / 使用次数 / Agent 绑定统一管理
3. **团队共享 + ACL**：`private`（Owner）/ `team`（全队）/ `restricted`（User/Role/Agent ACL 精确授权）
4. **冷启动友好**：导入已有代码库/文档/会话 → 自动生成四类资产 → Agent"先读档再开工"
5. **跨框架解耦**：记忆资产与 Agent 框架解耦，可跨 Hermes/OpenClaw/Claude Code/CodeBuddy 迁移

## 六、与 MOV 记忆层的对照

| 维度 | TencentDB Agent Memory | MOV |
|---|---|---|
| 形态 | 服务端集中式 Memory Hub（Node/服务器） | 端侧 journal 事件溯源 + memoryCover 覆盖 |
| 记忆分层 | L0-L3（对话→人设） | L1 草案/L2 精炼/L3 策展（记忆三层） |
| 技能 | Skill 库（版本/审核/团队共享） | SkillActivator（assets/skills，单机） |
| 团队 | 多 Agent 共享 + ACL 面板 | 单人个人成长伴侣（无团队维度） |
| 知识图 | Wiki + CodeGraph（文档/代码） | journal 按内容检索（C2） |

**同构问题**：都做"Agent 记忆资产化 + 复用"；TencentDB 的层级沉淀/L0-L3 与 MOV 记忆三层同构；其 Wiki/CodeGraph/ACL 是 MOV 未覆盖的（团队/知识图维度）。MOV 的 C2 检索 ≈ 其 RAG 层，但缺文档结构图/代码影响分析。
