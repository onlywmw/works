# REPORT：Hermes 阶段3 规划验收准备 — 2026-08-03

> 目的：供后续审查员逐一核对本阶段工作。每动作 → 证据（commit/doc）→ 依据，逐条对应。
> 角色：P2 线（计划评审 + 验收标准制定 + 派单准备）。
> 输入：`docs/PLAN_HERMES_SLIM_PHASE3.md`（计划，待拆派单）。

---

## 一、干了什么（逐条 + 证据）

| # | 动作 | 产物/证据 | 关键依据 |
|---|---|---|---|
| 1 | 评审 PLAN_HERMES_SLIM_PHASE3 骨架 | 评审结论：方向对、拆件干净、依赖顺序正确 | DESIGN_HERMES_SERVE §九 + HERMES_ANATOMY |
| 2 | **指出 A0 架构缺口**：MOV 无入站 HTTP 监听，反向通道「复用 127.0.0.1 双向」无地基 | 计划 §件 A0（MOV 入站监听）已补为独立件 | 实测：MOV 只有出站 OkHttp，无入站监听 |
| 3 | 给严格验收标准（定级/变异/假覆盖/真机固定四步/打回格式） | PLAN §八 验收标准（严格版） | ACCEPTANCE_PLAYBOOK（不信自报信实物/招2 变异/招3 假覆盖四形态/招4 真机） |
| 4 | 补**截屏点击验证 + 证据链**模板（触发截图→logcat→中间态截图→结果截图+断言对照） | PLAN §八 证据链模板 + 点击验证（真实点击前后对比） | 招4「断言与截图一一对应」+ DEVICE_ACCEPTANCE DV |
| 5 | 补件 C 的 **C2 journal 检索不退化**（真工作量，设计先行） | PLAN §件 C 已改（C2 按内容检索 + C4 删平行库在 C2 后） | journal append-only 语义 ≠ hermes_state FTS（:5443） |
| 6 | 补 **禁网两条腿**成文（任务工具网/推理网分开测） | PLAN §四 禁网语义 | M5 实证：network=false 只拦任务工具，infer 走 MOV 出网 |
| 7 | 更新计划入库（A0 拆分 + §八 标准） | commit **fa47dcb** | 采纳评审反馈 |
| 8 | 拆 5 件派单（A0/A/B/C/D 按依赖顺序） | commit **c8977e9**（5 个 TASKS_*.md） | PLAN §五 依赖：A0→A→B/C→D |

## 二、关键决策依据（审查点）

1. **A0 独立成件**：MOV 无入站监听是反向通道的真缺口；A0 是 B/C（推理/记忆回调）的地基，必须独立可验（真机 curl 闭环），不依赖 hermes agent。
2. **证据链铁律**：L2+ 真机项必产证据链，链断一环 = 打回；截图与断言一一对应；时间戳与 logcat 对齐。防「断言 X、截图证明 Y」。
3. **C2 检索不退化**：journal 是 append-only 事件流 + 回放投影，语义 ≠ hermes_state 的 FTS 检索库；直接删平行库会让 `session_search` 退化，必须先在 journal 侧补按内容检索（C4 删平行库守死在 C2 落地后）。
4. **禁网两条腿**：network=false 只拦任务「工具」的网络操作（LD_PRELOAD 禁网库挂任务子进程），infer 是 MOV 侧 LLM 能力天然出网——两条腿分开测，不许拿一条腿的结论套另一条。
5. **A4 拆三步防断 M1**：先 curl 通 A0/A1 → 再动 agent 工具层跑 M1 剧本 → 最后裁 registry.py，任何一步红回退。

## 三、派单一览（审查员可逐件核对）

| 派单 | 归属 | 依赖 | 核心验收（可验实物） |
|---|---|---|---|
| TASKS_P2_HERMES_SLIM_A0 | P2 | 无 | MOV 入站监听 8388 真机 curl；401 fail-closed；变异（端点恒空必红） |
| TASKS_P2_HERMES_SLIM_A | P2 | A0 | MOV ToolRegistry 执行 logcat；/tools 真实清单；DANGEROUS 两侧验；A4 拆三步 |
| TASKS_P2_HERMES_SLIM_B | P2 | A0 | /infer 走 MOV BridgeAi；禁网两条腿分开验；model_tools grep 清零 |
| TASKS_P6_HERMES_SLIM_C | P6 | A0 | 双端同读 journal；C2 检索不退化（正反例）；C4 删库在 C2 后 |
| TASKS_P6_HERMES_SLIM_D | P6 | A/B/C | 闭包最小集 16→<10（模块清单成文）；--version 正常；M1 全链不回归 |

## 四、边界声明

- **不碰 MOV 本体**：ToolRegistry/Journal/BridgeAi 只调不改（阶段3 只收 Hermes 平行实现，MOV 侧是真理源）。
- **假覆盖四形态对照**已入每件派单：① mock 喂答案 ② 虚构数据路径（**A0 回调链路用 fake 端点当生产 = 最大坑**）③ 字面量比较 ④ 测试重写被测逻辑。
- **变异测试**每件必红（带真实计数）：A0 恒空 / A 跳闸 / B 恒回 / C 假 journal。

## 五、证据文件索引

- 计划：`docs/PLAN_HERMES_SLIM_PHASE3.md`（fa47dcb）
- 派单：`docs/TASKS_P2_HERMES_SLIM_A0.md` / `A.md` / `B.md` / `docs/TASKS_P6_HERMES_SLIM_C.md` / `D.md`（c8977e9）
- 设计依据：`docs/DESIGN_HERMES_SERVE.md`（§九演进路线）、`docs/HERMES_ANATOMY.md`、`docs/ACCEPTANCE_PLAYBOOK.md`

## 六、A0 交付与独立自验（2026-08-03 追加）

**A0 交付**：`ea3139a`（serve/MovInboundServer.java，127.0.0.1:8388）+ `26c1785`（任务板状态），已 push main，git fetch 自查在 main 线性。

**交付方验收**：五证齐（起服 / 工具调用真 ToolRegistry / 鉴权 fail-closed / 信封 / 单测+变异），`assembleDebug test` 739 tests, 0 failures, 0 errors（18 skipped）。写入派单 doc `TASKS_P2_HERMES_SLIM_A0.md` 验收结论区。

**P2 独立自验**（不信自报，复核交付方声明）：

| 复核项 | 结果 | 证据 |
|---|---|---|
| commit 在 main | ✅ | `git log` 见 ea3139a + 26c1785 线性 |
| 落点文件 | ✅ | `serve/MovInboundServer.java`（12.8KB）+ `MovInboundServerTest.java`（7.2KB）存在 |
| 代码实现 | ✅ | 读代码：127.0.0.1:8388 bind + 来源校验双保险；X-Mov-Token fail-closed；healthz 免鉴权；/infer//memory 预留 404；`ToolRegistry.find().handler.run()` 分发；统一信封 `{ok,data}/{ok,error}`；dispatch 纯逻辑可测 |
| 单测 | ✅ | `MovInboundServerTest` 11/11 全过（路由/鉴权/信封/预留/来源校验） |
| 变异（亲杀） | ✅ | invokeTool 变异为恒空 → **11 tests completed, 3 failed**（与交付方声明完全一致）→ 还原绿 |
| 全量 | ✅ | `assembleDebug test` BUILD SUCCESSFUL：**1478 tests（debug+release 合计 = 739×2）, 0 failures, 0 errors, 36 skipped（18×2）** |

**自验结论**：A0 交付声明逐条核实属实，测试是真覆盖（变异亲杀复现）。审查员可直接按上表复核。

## 七、A 交付与独立自验（2026-08-03 追加）

**A 交付**：`35b66f5`（工具统一）+ `65d05bf`（任务板），已 push main，git fetch 自查在 main 线性。

**交付方验收**：四子项实证（A1 serve 代理 / A2 invokeTool / A3 /tools 填真 112 工具 / A4 换路）+ M1 不回归；`assembleDebug test` 749 tests, 0 failures（18 skipped）+ pytest 28 全绿。写入派单 doc `TASKS_P2_HERMES_SLIM_A.md` 验收结论区。

**P2 独立自验**：

| 复核项 | 结果 | 证据 |
|---|---|---|
| commit 在 main | ✅ | `git log` 见 35b66f5 + 65d05bf 线性 |
| A2 HermesClient.invokeTool | ✅ | `HermesClientTest` 16/16 全过（含 A2 +6 项信封测试：buildInvokePayload/parseInvokeResult 成功失败/空/garbage） |
| A1 serve 代理 | ✅ | 读 mov_serve.py：`@app.post("/tools/{name}/invoke")` → 转发 `MOV_A0`（127.0.0.1:8388） |
| A3 /tools 填真 | ✅ | `MOV_TOOLS_MANIFEST = /exchange/mov-tools.json`（write 到 /exchange）+ test_mov_serve.py 有 manifest 测试 |
| A4 命名映射 | ✅ | 读 tools/registry.py：`_MOV_TOOL_MAP = {"terminal": ("shell.exec", lambda a: {"cmd": a.get("command","")…`——命名不匹配实锤，映射换路不改 agent 提示词 |
| pytest | ✅ | test_mov_serve.py **28 passed** |
| 变异（亲杀） | ✅ | `parseInvokeResult` 恒成功 mutant → **16 tests completed, 1 failed**（失败信封测试红）→ 还原绿 |
| 全量 | ✅ | 754 debug tests, 0 failures, 0 errors（18 skipped）——构建被并发 `--stop` 打断（非测试失败，XML 已写出） |

**自验结论**：A 交付声明四子项属实，测试真覆盖（A2 信封变异亲杀复现）。边界（A4 step3 深化 + A5/双超时仅 ACTION 工具不换路）已入派单验收结论，审查员可按表复核。

## 八、记忆层 v2 交付与自验（2026-08-03，P6 并行计划）

**计划文件**：`docs/TASKS_P6_MEMORY_COVER_2026-08-03.md`（读取时按需覆盖，DESIGN_MEMORY_LAYERS v2 §六）。

**交付方**：3 文件 +121 行（Journal.memoryCover/COVER_BUDGET_DEFAULT=20/coverVerbatim + BridgeKernel memory.cover + JournalMemoryDraftTest +5），工作区未提交。

**P2 独立自验**：

| 项 | 结果 | 证据 |
|---|---|---|
| 预算内逐字 | ✅ | 算法读码：n ≤ budget 全逐字，needsCompress=false |
| 超预算塌缩 | ✅ | `collapsedN=n-budget` 条→1 行确定性摘要（数量/最早日期/kind）+ 最新 budget 条逐字，总行数=budget+1 |
| 不丢原文（修正③） | ✅ | memoryDrafts 只读不删，覆盖只影响"读到什么" |
| 纯算法 | ✅ | 无模型调用，前台可跑 |
| Kernel 入口 | ✅ | BridgeKernel `memory.cover` → journal.memoryCover，统一信封 |
| 单测 | ✅ | JournalMemoryDraftTest 22/22（原 17 + 新 5） |
| 变异/全量 | ⏸️ | 被 P6 并发 `MovInboundServerTest:97` 构造器断卡住（非本件失败），P6 修后补验 |

**诚实边界**：本幕只做确定性部分；needsCompress=true 待 L3 模型提炼（单独派单）；原文长在 journal 永不丢。

## 九、遗留/待办

- **A0 ✅ / A ✅ 已交付自验**；**B（LLM 收编）/ C（记忆统一）待派**（吃 A0 通道，可并行）。
- **记忆层 v2 ✅ 已自验**（变异/全量待 P6 修 MovInboundServerTest 断后补）。
- **M5 安全验收**（P2 队列）待派。
- D（裁剪）待 A/B/C 验收后派。
